// The first rule packages: engineering fixtures and declared profiles for the systems the harmonic-systems report
// asks for (§4), each validated as it loads (packages.js) and labelled for what it is not. They are data: plain objects
// a file could hold, with nothing that runs.
import {rulePackage} from './packages.js';

const c=value=>({kind:'cents',value});
const r=(numerator,denominator=1)=>({kind:'ratio',numerator:String(numerator),denominator:String(denominator)});
const octave=r(2);
const chromatic=Array.from({length:12},(_,step)=>({id:`c${step}`,interval:c(100*step)}));

// ---- Barry Harris: the sixth-diminished fixture ----------------------------------------------------------------------
// The union of the declared chord tones C-E-G-A and D-F-A♭-B, alternating harmonic roles as a scale of chords: each
// step of the eight-note scale moves every voice to its neighbour in the scale, and a sixth chord and a diminished
// seventh alternate (§4.4). Its tuning preferences give the sixth chord a just third, fifth and sixth, and the
// diminished chord pure minor thirds (6:5), all four -- which cannot close an octave (§6.5, T05). Its policy protects
// the diminished chord's symmetry, the four equal minor thirds Harris's movement relies on (any of its notes can lead),
// so each 6:5 is tempered by a quarter of the 62.565-cent excess and the realization reports all four as tempered.
// Preferring only three of them tempered none of those three and left the whole excess in the fourth: a 253-cent
// minor third, heard as a wolf (the first render, 25 September 2026).
export const HARRIS_SIXTH_DIMINISHED=rulePackage({
  id:'harris-sixth-diminished-fixture',version:'1.0.0',
  provenance:{status:'engineering-fixture',sources:[{title:'Howard Rees, The Barry Harris Workshop Video (and associated materials)',note:'primary pedagogical material for authoring and checking the rules; not reproduced here (report R19)'}],
    notes:'A transparent engineering fixture: the union of C-E-G-A and D-F-Ab-B with alternating labelled harmonic roles. It is not "the Barry Harris method": minor-sixth, dominant, borrowing and advanced movement need separately verified rules (report §4.4).'},
  scope:{description:'The major sixth-diminished scale of chords in one key, as an engineering fixture.',
    supported:['alternating I6 and vii°7 on scale steps','block motion by one scale step','just-intonation preferences per role'],
    unsupported:['minor sixth-diminished','dominant sixth-diminished','borrowing','drop voicings','the method as taught']},
  period:octave,referenceId:'tonic',
  degrees:[{id:'1',interval:c(0)},{id:'2',interval:c(200)},{id:'3',interval:c(400)},{id:'4',interval:c(500)},{id:'5',interval:c(700)},
    {id:'b6',interval:c(800)},{id:'6',interval:c(900)},{id:'7',interval:c(1100)}],
  structures:[
    {id:'I6',root:'root',roles:[{role:'root',degree:'1',required:true},{role:'third',degree:'3',required:true},{role:'fifth',degree:'5',required:false},{role:'sixth',degree:'6',required:true}]},
    {id:'vii-dim7',root:'root',roles:[{role:'root',degree:'7',required:true},{role:'third',degree:'2',required:true},{role:'fifth',degree:'4',required:true},{role:'seventh',degree:'b6',required:true}]},
  ],
  collections:[{id:'sixth-diminished',degrees:['1','2','3','4','5','b6','6','7']}],
  contexts:[{id:'sixth',structures:['I6'],collection:'sixth-diminished'},{id:'diminished',structures:['vii-dim7'],collection:'sixth-diminished'}],
  start:['sixth'],
  transformations:[{id:'scale-step',kind:'collection-translation',collection:'sixth-diminished',steps:[1,-1]}],
  transitions:[{from:'sixth',to:'diminished',via:'scale-step'},{from:'diminished',to:'sixth',via:'scale-step'}],
  rules:[
    {id:'harris-roles',type:'required-roles',strength:'hard',explanation:'Each chord keeps its required roles; the sixth chord may omit its fifth.'},
    {id:'harris-block',type:'preserve-block',strength:'hard',transformation:'scale-step',explanation:'Every voice moves to its neighbour in the scale: a scale of chords, not re-voiced chords.'},
    {id:'harris-common-tones',type:'hold-common-tones',strength:'soft',weight:1},
    {id:'harris-close',type:'max-span',strength:'hard',cents:1200,explanation:'Close position: the voices within an octave, as the scale of chords is first played; drop voicings are outside this fixture\'s scope.'},
  ],
  tuning:[
    {structure:'I6',role:'third',alternatives:[{id:'just-third',offsetCents:[-20,6],prefer:[{above:'root',interval:r(5,4),weight:1}]}]},
    {structure:'I6',role:'fifth',alternatives:[{id:'just-fifth',offsetCents:[-6,6],prefer:[{above:'root',interval:r(3,2),weight:1}]}]},
    {structure:'I6',role:'sixth',alternatives:[{id:'just-sixth',offsetCents:[-20,6],prefer:[{above:'root',interval:r(5,3),weight:.8}]}]},
    {structure:'vii-dim7',role:'root',alternatives:[{id:'pure-minor-third',offsetCents:[-40,40],prefer:[{above:'seventh',interval:r(6,5),weight:1}]}]},
    {structure:'vii-dim7',role:'third',alternatives:[{id:'pure-minor-third',offsetCents:[-40,40],prefer:[{above:'root',interval:r(6,5),weight:1}]}]},
    {structure:'vii-dim7',role:'fifth',alternatives:[{id:'pure-minor-third',offsetCents:[-40,40],prefer:[{above:'third',interval:r(6,5),weight:1}]}]},
    {structure:'vii-dim7',role:'seventh',alternatives:[{id:'pure-minor-third',offsetCents:[-40,40],prefer:[{above:'fifth',interval:r(6,5),weight:1}]}]},
    {structure:'vii-dim7',protectSymmetry:['root','third','fifth','seventh']},
  ],
  examples:{positive:[{contexts:['sixth','diminished','sixth','diminished','sixth'],note:'a scale of chords rising through the eight-note scale'}],
    negative:[{contexts:['sixth','sixth'],note:'two sixth chords in a row are not a step of the scale of chords'}]},
});

// ---- Planing: exact and collection-relative ---------------------------------------------------------------------------
// Two operators, kept apart (§4.7): exact planing translates the block and keeps every internal interval to the cent;
// diatonic planing moves every voice the same number of steps in a collection, keeping its degree pattern and letting
// its acoustic intervals change.
export const PLANING=rulePackage({
  id:'planing-fixture',version:'1.0.0',
  provenance:{status:'engineering-fixture',sources:[{title:'Vincent Persichetti, Twentieth-Century Harmony (1961), chapter on planing'}],
    notes:'The report\'s proposed package contract for planing (§4.7): the two operators and their invariants, nothing of any repertoire.'},
  scope:{description:'A labelled block moved exactly or within a diatonic collection.',supported:['exact planing by any interval','diatonic planing by 1 or 2 steps'],unsupported:['mixed planing','held voices outside the block']},
  period:octave,referenceId:'tonic',
  degrees:chromatic,
  structures:[{id:'major-triad',root:'root',roles:[{role:'root',degree:'c0',required:true},{role:'third',degree:'c4',required:true},{role:'fifth',degree:'c7',required:true}]}],
  collections:[{id:'diatonic',degrees:['c0','c2','c4','c5','c7','c9','c11']}],
  contexts:[{id:'exact',structures:['major-triad']},{id:'diatonic',structures:['major-triad'],collection:'diatonic'}],
  start:['exact','diatonic'],
  transformations:[
    {id:'exact-planing',kind:'exact-translation',by:'any',block:'all'},
    {id:'diatonic-planing',kind:'collection-translation',collection:'diatonic',steps:[1,-1,2,-2]},
  ],
  transitions:[{from:'exact',to:'exact',via:'exact-planing'},{from:'diatonic',to:'diatonic',via:'diatonic-planing'}],
  rules:[
    {id:'exact-block',type:'preserve-block',strength:'hard',transformation:'exact-planing',scope:{contexts:['exact']}},
    {id:'diatonic-block',type:'preserve-block',strength:'hard',transformation:'diatonic-planing',scope:{contexts:['diatonic']}},
  ],
  examples:{positive:[{contexts:['exact','exact','exact']},{contexts:['diatonic','diatonic']}],negative:[{contexts:['exact','diatonic']}]},
});

// ---- Neo-Riemannian P, L, R on C major, as guarded role maps ------------------------------------------------------------
// Each transformation's domain is the structure it maps from (§4.6, T07): applied to a quartal chord it is an
// unsupported domain, not an invented triadic analysis.
export const NEO_RIEMANNIAN=rulePackage({
  id:'neo-riemannian-fixture',version:'1.0.0',
  provenance:{status:'engineering-fixture',sources:[{title:'Richard Cohn, Audacious Euphony (2012)'},{title:'Callender, Quinn and Tymoczko, Generalized Voice-Leading Spaces, Science 320 (2008)'}],
    notes:'P, L and R from C major only, as guarded role maps; a transposing package is a later step.'},
  scope:{description:'P, L and R from C major.',supported:['P, L, R from C major','common tones held as the maps say'],unsupported:['other roots','seventh chords','quartal or cluster structures']},
  period:octave,referenceId:'tonic',
  degrees:chromatic,
  structures:[
    {id:'C',root:'root',roles:[{role:'root',degree:'c0',required:true},{role:'third',degree:'c4',required:true},{role:'fifth',degree:'c7',required:true}]},
    {id:'c',root:'root',roles:[{role:'root',degree:'c0',required:true},{role:'third',degree:'c3',required:true},{role:'fifth',degree:'c7',required:true}]},
    {id:'e',root:'root',roles:[{role:'root',degree:'c4',required:true},{role:'third',degree:'c7',required:true},{role:'fifth',degree:'c11',required:true}]},
    {id:'a',root:'root',roles:[{role:'root',degree:'c9',required:true},{role:'third',degree:'c0',required:true},{role:'fifth',degree:'c4',required:true}]},
    {id:'quartal',roles:[{role:'lower',degree:'c0',required:true},{role:'middle',degree:'c5',required:true},{role:'upper',degree:'c10',required:true}]},
  ],
  contexts:[{id:'major',structures:['C']},{id:'parallel',structures:['c']},{id:'leading-tone',structures:['e']},{id:'relative',structures:['a']},{id:'quartal',structures:['quartal']}],
  start:['major','quartal'],
  transformations:[
    {id:'P',kind:'role-map',from:'C',to:'c',mapping:{root:'root',third:'third',fifth:'fifth'},holds:['root','fifth']},
    {id:'L',kind:'role-map',from:'C',to:'e',mapping:{root:'fifth',third:'root',fifth:'third'},holds:['third','fifth']},
    {id:'R',kind:'role-map',from:'C',to:'a',mapping:{root:'third',third:'fifth',fifth:'root'},holds:['root','third']},
  ],
  transitions:[{from:'major',to:'parallel',via:'P'},{from:'major',to:'leading-tone',via:'L'},{from:'major',to:'relative',via:'R'}],
  rules:[{id:'plr-roles',type:'required-roles',strength:'hard'},{id:'plr-common',type:'hold-common-tones',strength:'soft',weight:2}],
  examples:{positive:[{contexts:['major','parallel']},{contexts:['major','relative']}],negative:[{contexts:['quartal','parallel']}]},
});

// ---- Collection 2779: a catalogue designation ---------------------------------------------------------------------
export const COLLECTION_2779=rulePackage({
  id:'collection-2779',version:'1.0.0',
  provenance:{status:'catalogue-designation',sources:[{title:'Ian Ring, A Study of Musical Scales: scale 2779',url:'https://ianring.com/musictheory/scales/2779'}],
    notes:'Ian Ring labels collection 2779, {0,1,3,4,6,7,9,11}, "Shostakovich". A catalogue designation, not evidence that one set captures Shostakovich\'s harmonic practice (report §4.8).'},
  scope:{description:'The collection {0,1,3,4,6,7,9,11} as material.',supported:['membership'],unsupported:['progressions, centres or voice leading attributed to Shostakovich']},
  period:octave,referenceId:'tonic',degrees:chromatic,
  collections:[{id:'2779',degrees:['c0','c1','c3','c4','c6','c7','c9','c11']}],
  contexts:[{id:'collection',collection:'2779'}],start:['collection'],transitions:[{from:'collection',to:'collection'}],
});

// ---- Maqam rast: a declared test profile ------------------------------------------------------------------------------
// Rast's notes in 24-EDO approximations, and its B half-flat taken as B flat descending: direction-dependent material
// for a protected modal line (T09). A declared test profile until a practitioner validates it: a 24-EDO table is not
// maqam fidelity (§4.2).
export const MAQAM_RAST_TEST_PROFILE=rulePackage({
  id:'maqam-rast-test-profile',version:'0.1.0',
  provenance:{status:'declared-test-profile',tradition:'Arabic maqam: rast (a declared test profile, awaiting review)',sources:[{title:'MaqamWorld: Maqam Rast',url:'https://www.maqamworld.com/en/maqam/rast.php'}],
    notes:'A declared test profile: 24-EDO approximations of rast (E and B half-flat at 350 and 1050 cents) and its descending B flat. Not maqam fidelity; awaiting practitioner review. Arabic rast only: not Turkish makam or Persian dastgah (report §4.2).'},
  scope:{description:'A line in rast, ascending and descending, for protected-melody tests.',supported:['ascending and descending material','the descending B flat'],unsupported:['ajnas modulation','sayr','intonation profiles','ornament trajectories']},
  period:octave,referenceId:'qarar',
  degrees:[{id:'rast',interval:c(0)},{id:'dukah',interval:c(200)},{id:'sikah',interval:c(350)},{id:'jaharkah',interval:c(500)},{id:'nawa',interval:c(700)},
    {id:'husayni',interval:c(900)},{id:'awj',interval:c(1050)},{id:'ajam',interval:c(1000)}],
  collections:[{id:'ascending',degrees:['rast','dukah','sikah','jaharkah','nawa','husayni','awj']},{id:'descending',degrees:['rast','dukah','sikah','jaharkah','nawa','husayni','ajam']}],
  contexts:[{id:'ascending',collection:'ascending'},{id:'descending',collection:'descending'}],
  start:['ascending','descending'],
  transitions:[{from:'ascending',to:'ascending'},{from:'ascending',to:'descending'},{from:'descending',to:'descending'},{from:'descending',to:'ascending'}],
  rules:[{id:'melody-protected',type:'protect-voice',strength:'hard',voice:'melody',explanation:'The modal line is protected: the accompaniment adapts to it, never it to the accompaniment.'}],
});

// ---- A 3:1 period, and none ---------------------------------------------------------------------------------------------
// Bohlen-Pierce: a tritave period and just degrees, its "major" triad 3:5:7 (T18). And the harmonic series with no
// period: partials that never repeat by any interval.
export const BOHLEN_PIERCE=rulePackage({
  id:'bohlen-pierce-fixture',version:'1.0.0',
  provenance:{status:'engineering-fixture',sources:[{title:'Mathews, Pierce, Reeves and Roberts, Theoretical and experimental explorations of the Bohlen-Pierce scale, JASA 84 (1988)'}],notes:'A non-octave period: nothing here may reduce by 2:1.'},
  scope:{description:'The just Bohlen-Pierce scale and its 3:5:7 triad.',supported:['the tritave period'],unsupported:['BP tempering','BP modes']},
  period:r(3),referenceId:'tonic',
  degrees:[[1,1],[27,25],[25,21],[9,7],[7,5],[75,49],[5,3],[9,5],[49,25],[15,7],[7,3],[63,25],[25,9]].map(([n,d],step)=>({id:`bp${step}`,interval:r(n,d)})),
  structures:[{id:'bp-major',root:'root',roles:[{role:'root',degree:'bp0',required:true},{role:'third',degree:'bp6',required:true},{role:'fifth',degree:'bp10',required:true}]}],
  contexts:[{id:'bp',structures:['bp-major']}],start:['bp'],transitions:[{from:'bp',to:'bp'}],
});
export const HARMONIC_SERIES=rulePackage({
  id:'harmonic-series-fixture',version:'1.0.0',
  provenance:{status:'engineering-fixture',notes:'No period: partials 1 to 16 of one fundamental, which repeat by no interval.'},
  scope:{description:'Partials of one fundamental as degrees.',supported:['an otonal chord 4:5:6:7'],unsupported:['any period']},
  period:null,referenceId:'fundamental',
  degrees:Array.from({length:16},(_,index)=>({id:`h${index+1}`,interval:r(index+1)})),
  structures:[{id:'otonal',root:'fourth',roles:[{role:'fourth',degree:'h4',required:true},{role:'fifth',degree:'h5',required:true},{role:'sixth',degree:'h6',required:true},{role:'seventh',degree:'h7',required:true}]}],
  contexts:[{id:'series',structures:['otonal']}],start:['series'],transitions:[{from:'series',to:'series'}],
});

export const FIXTURE_PACKAGES=Object.freeze([HARRIS_SIXTH_DIMINISHED,PLANING,NEO_RIEMANNIAN,COLLECTION_2779,MAQAM_RAST_TEST_PROFILE,BOHLEN_PIERCE,HARMONIC_SERIES]);
