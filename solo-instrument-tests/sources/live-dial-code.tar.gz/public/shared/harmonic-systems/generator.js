// The explicit generator (the harmonic-systems report, §5, §7.4, §8.2): a bounded search over a rule package's grammar
// for the next few chords, each a voicing with its roles labelled, reached by a transition and the transformation it
// uses, and kept only if the package's hard rules hold. It returns a plan and an honest status, never plays one.
//
// - Candidates are made the way each transformation says. A collection translation moves every block voice the same
//   number of steps on its collection (the Harris scale of chords, diatonic planing); an exact translation moves the
//   block by one interval, every internal interval kept; a role map (P, L, R) holds and moves roles as it declares, and
//   only from the structure it is defined on: applied to anything else it is an unsupported domain, recorded as such,
//   not an invented analysis (T07). A reflection mirrors the voices in its scope about its axis, placed by its register
//   policy, and keeps each voice's identity. A transition with no transformation re-voices the next chord.
// - Voicings cover their structure's required roles (optional ones may be left out), keep voices in order within their
//   ranges, and hold protected voices exactly where they were given (a melody the harmony adapts around, T09). A voice
//   may rest or enter, at an explicit cost: no voice is deleted for free (T08).
// - The search is a beam, stratified by context and transformation so that near-duplicates of one choice cannot crowd
//   out the only path to a later arrival (§5.2), bounded by the package's limits, a node budget and a deadline.
// - Every rejected candidate leaves an explanation: the rules it broke, where, and why (§8.3). Two hard rules that
//   cannot both hold leave both named (T19).
// - The status says what is known (§7.4, T20): 'validated' (a plan that passes the validator from scratch;
//   `optimalityProven` only when nothing was pruned), 'infeasible' (no plan exists: only when nothing was pruned),
//   'unknown' (none found before the budget or deadline, which proves nothing), 'invalid' (the request itself is), and
//   'unsupported' (it asks for a transformation outside its domain).
import {periodCents,degreeCents,structureOf,contextOf,transformationOf,transitionsFrom} from './packages.js';
import {intervalCents} from './pitch-intent.js';
import {validatePlan,collectionPositions,VALIDATION} from './validator.js';

// ---- Choices ---------------------------------------------------------------------------------------------------
export const GENERATOR=Object.freeze({
  beam:8,                    // states kept after each step
  voicingsKept:48,           // re-voicings kept per structure, the least motion first
  enumerationCap:20000,      // voicings enumerated per structure at most (past it, the search says it was truncated)
  motionPerSemitone:1,       // the cost of a voice moving a semitone: the unit every other cost is in
  birthCost:3,               // a voice entering, and one falling silent: never free (T08)
  deathCost:3,
  explanationsKept:32,
  translationRange:1,        // exact translations searched within this many periods either way (an 'any' interval)
  aimPerSemitone:1,          // a step's cost for each semitone its voicing's mean pitch lies from the request's aim
});

const tol=VALIDATION.pitchToleranceCents;
const reduce=(value,period)=>((value%period)+period)%period;

// ---- Pitches of a degree, and labelling ------------------------------------------------------------------------
// Every pitch of a degree within a range, at a transposition, period by period (just the one pitch with no period).
export function pitchesOnDegree(pkg,degree,{tonicCents,offsetCents=0,range,spend=()=>true}){
  const base=tonicCents+offsetCents+degreeCents(pkg,degree),period=periodCents(pkg),[low,high]=range,out=[];
  if(period===null)return base>=low-tol&&base<=high+tol?[base]:[];
  for(let k=Math.ceil((low-base)/period-1e-9);base+k*period<=high+tol;k++){if(!spend())break;out.push(base+k*period);}
  return out;
}
// The role and degree a pitch has in a structure at a transposition, or none.
export function roleOf(pkg,structure,cents,{tonicCents,offsetCents=0}){
  const period=periodCents(pkg),relative=cents-tonicCents-offsetCents;
  for(const member of structure.roles){
    const d=degreeCents(pkg,member.degree),distance=period===null?Math.abs(relative-d):Math.min(reduce(relative-d,period),period-reduce(relative-d,period));
    if(distance<=tol)return {role:member.role,degree:member.degree};
  }
  return {role:null,degree:null};
}
const labelled=(pkg,structure,voice,cents,frame)=>({voice,cents,...(Number.isFinite(cents)?roleOf(pkg,structure,cents,frame):{role:null,degree:null})});

// ---- Voicings ---------------------------------------------------------------------------------------------------
// Every voicing of a structure: one pitch (or a rest) per voice, voices in order low to high and never crossing or in
// unison, fixed voices exactly where given, required roles covered. {voicings, truncated}.
export function enumerateVoicings(pkg,structureId,{tonicCents,offsetCents=0,voices,fixed={},cap=GENERATOR.enumerationCap,spend=()=>true}){
  const structure=structureOf(pkg,structureId),frame={tonicCents,offsetCents};
  const required=structure.roles.filter(member=>member.required).map(member=>member.role);
  let budgetStopped=false;
  const work=()=>{const ok=spend();budgetStopped||=!ok;return ok;};
  const options=voices.map(voice=>{
    if(!work())return [];
    if(Number.isFinite(fixed[voice.id]))return [labelled(pkg,structure,voice.id,fixed[voice.id],frame)];
    const notes=structure.roles.flatMap(member=>pitchesOnDegree(pkg,member.degree,{tonicCents,offsetCents,range:voice.range,spend:work})
      .map(cents=>({voice:voice.id,cents,role:member.role,degree:member.degree})));
    return [{voice:voice.id,cents:null,role:null,degree:null},...notes.sort((a,b)=>a.cents-b.cents)];
  });
  const out=[];let truncated=false;
  const walk=(index,chosen,last,covered)=>{
    if(truncated||!work())return;
    const uncovered=required.filter(role=>!covered.has(role)).length;
    if(uncovered>voices.length-index)return;                         // too few voices left to cover what is required
    if(index===voices.length){
      if(uncovered===0&&chosen.some(note=>Number.isFinite(note.cents))){if(out.length>=cap){truncated=true;return}out.push(chosen.slice())}
      return;
    }
    for(const note of options[index]){
      if(Number.isFinite(note.cents)&&note.cents<=last+tol)continue;   // in order, no unisons, no crossing
      const next=note.role!==null&&!covered.has(note.role)?new Set([...covered,note.role]):covered;
      chosen.push(note);walk(index+1,chosen,Number.isFinite(note.cents)?note.cents:last,next);chosen.pop();
    }
  };
  walk(0,[],-Infinity,new Set);
  return {voicings:out,truncated:truncated||budgetStopped};
}

// ---- Moves between steps ----------------------------------------------------------------------------------------
const motionCost=(from,to)=>{
  let cost=0,births=0,deaths=0;
  const before=new Map(from.voicing.filter(note=>Number.isFinite(note.cents)).map(note=>[note.voice,note.cents]));
  for(const note of to.voicing){
    const was=before.get(note.voice),now=Number.isFinite(note.cents);
    if(now&&was!==undefined)cost+=Math.abs(note.cents-was)/100*GENERATOR.motionPerSemitone;
    else if(now)births++;
    else if(was!==undefined)deaths++;
  }
  return {cost:cost+births*GENERATOR.birthCost+deaths*GENERATOR.deathCost,births,deaths};
};
const pitchOf=(step,voice)=>step.voicing.find(note=>note.voice===voice)?.cents;

// The steps a transition can take from a step: [{step}|{explanation}].
function successors(pkg,previous,transition,{tonicCents,voices,fixed,protectedPitches,spend}){
  const target=contextOf(pkg,transition.to),out=[];
  const frame=offsetCents=>({tonicCents,offsetCents});
  const make=(structureId,offsetCents,voicing,lineage=previous.lineage??null)=>({context:target.id,structure:structureId,offsetCents,via:transition.via??null,
    ...(lineage&&Object.keys(lineage).length?{lineage}:{}),voicing});
  if(!transition.via){
    for(const structureId of target.structures){
      const {voicings,truncated}=enumerateVoicings(pkg,structureId,{tonicCents,offsetCents:previous.offsetCents,voices,fixed,spend});
      const steps=voicings.map(voicing=>make(structureId,previous.offsetCents,voicing,null));
      const motion=new Map(steps.map(step=>[step,motionCost(previous,step).cost]));steps.sort((a,b)=>motion.get(a)-motion.get(b));
      out.push(...steps.slice(0,GENERATOR.voicingsKept).map(step=>({step,truncated:truncated||steps.length>GENERATOR.voicingsKept})));
    }
    if(!target.structures.length)out.push({explanation:{kind:'no-structure',detail:`${target.id} holds no chord to voice`}});
    return out;
  }
  const transformation=transformationOf(pkg,transition.via);
  const sounding=previous.voicing.filter(note=>Number.isFinite(note.cents));
  const inBlock=note=>transformation.block==='all'||transformation.block===undefined||transformation.block.includes(note.role);
  if(transformation.kind==='collection-translation'){
    const collection=pkg.collections.find(item=>item.id===transformation.collection),period=periodCents(pkg);
    const position=collectionPositions(pkg,collection,{tonicCents,offsetCents:previous.offsetCents,period});
    const orderedDegrees=collection.degrees.map(id=>({id,cents:degreeCents(pkg,id)})).sort((a,b)=>a.cents-b.cents),members=orderedDegrees.map(entry=>entry.cents);
    const pitchAt=index=>{
      if(period===null)return index>=0&&index<members.length?tonicCents+previous.offsetCents+members[index]:null;
      const periods=Math.floor(index/members.length);
      return tonicCents+previous.offsetCents+members[index-periods*members.length]+periods*period;
    };
    for(const stepsBy of transformation.steps){
      if(!spend())break;
      const moved=new Map;let off=null;
      for(const note of sounding){
        if(!inBlock(note)){moved.set(note.voice,note.cents);continue}
        const at=position(note.cents);
        if(at===null){off=note.voice;break}
        moved.set(note.voice,pitchAt(at+stepsBy));
      }
      if(off){out.push({explanation:{kind:'off-collection',via:transformation.id,detail:`${off} is not on ${collection.id}, so the block cannot move within it`}});continue}
      const beyond=voices.find(voice=>moved.has(voice.id)&&(moved.get(voice.id)<voice.range[0]-tol||moved.get(voice.id)>voice.range[1]+tol));
      if(beyond){out.push({explanation:{kind:'out-of-range',via:transformation.id,detail:`moving ${stepsBy} step${Math.abs(stepsBy)===1?'':'s'} on ${collection.id} takes ${beyond.id} outside its range`}});continue}
      const reached=target.structures.map(structureId=>{
        const structure=structureOf(pkg,structureId);
        const voicing=voices.map(voice=>labelled(pkg,structure,voice.id,moved.get(voice.id)??null,frame(previous.offsetCents)));
        return {structureId,voicing};
      }).find(({structureId,voicing})=>structureOf(pkg,structureId).roles.every(member=>!member.required||voicing.some(note=>note.role===member.role))&&
        voicing.every(note=>!Number.isFinite(note.cents)||note.role!==null));
      if(reached){out.push({step:make(reached.structureId,previous.offsetCents,reached.voicing)});continue}
      // No declared chord of the target is reached, but the target holds the moved block itself: collection-relative
      // planing, whose identity is its degree pattern, not its chord quality (C E G to D F A is the same block a step
      // up, §4.7). The roles are kept on their moved degrees, and the step records how far the block has moved.
      if(target.structures.includes(previous.structure)){
        const degreeAt=cents=>{const at=position(cents);return at===null?null:orderedDegrees[((at%members.length)+members.length)%members.length].id};
        const voicing=voices.map(voice=>{
          const note=previous.voicing.find(item=>item.voice===voice.id),cents=moved.get(voice.id);
          if(!note||!Number.isFinite(cents))return {voice:voice.id,cents:null,role:null,degree:null};
          return inBlock(note)?{voice:voice.id,cents,role:note.role,degree:degreeAt(cents)}:{...note};
        });
        const lineage={...(previous.collectionLineage??{})};lineage[collection.id]=(lineage[collection.id]??0)+stepsBy;
        out.push({step:{...make(previous.structure,previous.offsetCents,voicing),collectionLineage:lineage}});continue;
      }
      out.push({explanation:{kind:'not-reached',via:transformation.id,detail:`moving ${stepsBy} step${Math.abs(stepsBy)===1?'':'s'} on ${collection.id} makes no chord of ${target.id}`}});
    }
    return out;
  }
  if(transformation.kind==='exact-translation'){
    const period=periodCents(pkg)??1200,span=period*GENERATOR.translationRange;
    const deltas=transformation.by!=='any'?transformation.by.map(spec=>intervalCents(spec)):
      (()=>{const found=new Set;outer:for(const a of pkg.degrees)for(const b of pkg.degrees){if(!spend())break outer;const d=degreeCents(pkg,a.id)-degreeCents(pkg,b.id);for(const shift of [d,d-period,d+period])if(Math.abs(shift)>tol&&Math.abs(shift)<=span)found.add(+shift.toFixed(6));}return [...found].sort((a,b)=>Math.abs(a)-Math.abs(b)||a-b);})();
    const structureId=previous.structure,whole=transformation.block==='all';
    if(!target.structures.includes(structureId)){out.push({explanation:{kind:'not-reached',via:transformation.id,detail:`${target.id} does not hold ${structureId}, the block being translated`}});return out}
    for(const delta of deltas){
      if(!spend())break;
      const lineage={...(previous.lineage??{})},voicing=voices.map(voice=>{
        const note=previous.voicing.find(item=>item.voice===voice.id);
        if(!note||!Number.isFinite(note.cents))return {voice:voice.id,cents:null,role:null,degree:null};
        if(!inBlock(note))return {...note};
        if(!whole)lineage[voice.id]=(lineage[voice.id]??0)+delta;
        return {...note,cents:note.cents+delta};
      });
      if(voicing.some((note,index)=>Number.isFinite(note.cents)&&(note.cents<voices[index].range[0]-tol||note.cents>voices[index].range[1]+tol)))continue;
      out.push({step:make(structureId,whole?previous.offsetCents+delta:previous.offsetCents,voicing,whole?null:lineage)});
    }
    if(!out.length)out.push({explanation:{kind:'out-of-range',via:transformation.id,detail:'no translation keeps the block inside its voices\' ranges'}});
    return out;
  }
  if(transformation.kind==='reflection'){
    // The voices in scope, by where they sound now: the highest is the melody, the lowest the bass.
    const period=periodCents(pkg),axis=tonicCents+previous.offsetCents+intervalCents(transformation.axis),ordered=[...sounding].sort((a,b)=>a.cents-b.cents);
    const low=ordered[0]?.voice,high=ordered.at(-1)?.voice,scope=transformation.scope,policy=transformation.registerPolicy;
    const inScope=note=>scope==='entire-layer'||(scope==='melody'?note.voice===high:scope==='chord'?note.voice!==low&&note.voice!==high:note.voice!==high);
    const moved=new Map;
    for(const voice of voices){
      const note=previous.voicing.find(item=>item.voice===voice.id);
      if(!note||!Number.isFinite(note.cents))continue;
      if(!inScope(note)){moved.set(voice.id,note.cents);continue}
      let cents=2*axis-note.cents;
      if(policy!=='strict-mirror'){
        cents+=period*Math.round((note.cents-cents)/period);            // its class, nearest the old pitch
        if(policy==='voice-range-revoice'){
          while(cents<voice.range[0]-tol&&cents+period<=voice.range[1]+tol)cents+=period;
          while(cents>voice.range[1]+tol&&cents-period>=voice.range[0]-tol)cents-=period;
        }
      }
      moved.set(voice.id,cents);
    }
    const beyond=voices.find(voice=>moved.has(voice.id)&&(moved.get(voice.id)<voice.range[0]-tol||moved.get(voice.id)>voice.range[1]+tol));
    if(beyond){out.push({explanation:{kind:'out-of-range',via:transformation.id,detail:`reflecting (${policy}) takes ${beyond.id} outside its range`}});return out}
    const reached=target.structures.map(structureId=>{
      const structure=structureOf(pkg,structureId);
      return {structureId,voicing:voices.map(voice=>labelled(pkg,structure,voice.id,moved.get(voice.id)??null,frame(previous.offsetCents)))};
    }).find(({structureId,voicing})=>structureOf(pkg,structureId).roles.every(member=>!member.required||voicing.some(note=>note.role===member.role))&&
      voicing.every(note=>!Number.isFinite(note.cents)||note.role!==null));
    if(reached)out.push({step:make(reached.structureId,previous.offsetCents,reached.voicing,null)});
    else out.push({explanation:{kind:'not-reached',via:transformation.id,detail:`the reflection of ${previous.structure} is no chord of ${target.id}`}});
    return out;
  }
  // A role map, only from the structure it is defined on (T07).
  if(previous.structure!==transformation.from){
    out.push({explanation:{kind:'unsupported-domain',via:transformation.id,detail:`${transformation.id} is defined on ${transformation.from}, not ${previous.structure}: an unsupported domain, not a triad to be invented`}});
    return out;
  }
  const to=structureOf(pkg,transformation.to),voicing=voices.map(voice=>{
    const note=previous.voicing.find(item=>item.voice===voice.id);
    if(!note||!Number.isFinite(note.cents)||note.role===null)return {voice:voice.id,cents:null,role:null,degree:null};
    const role=transformation.mapping[note.role],member=to.roles.find(item=>item.role===role);
    if(transformation.holds.includes(note.role))return {voice:voice.id,cents:note.cents,role,degree:member.degree};
    const candidates=pitchesOnDegree(pkg,member.degree,{tonicCents,offsetCents:previous.offsetCents,range:voice.range,spend});
    const nearest=candidates.sort((a,b)=>Math.abs(a-note.cents)-Math.abs(b-note.cents))[0];
    return nearest===undefined?{voice:voice.id,cents:null,role:null,degree:null}:{voice:voice.id,cents:nearest,role,degree:member.degree};
  });
  out.push({step:make(to.id,previous.offsetCents,voicing)});
  return out;
}

// ---- The search -----------------------------------------------------------------------------------------------------
// request: {start: {context, structure?, offsetCents?, pitches?: {voice: cents}, after?: {voice: cents} (the voicing
// sounding before it, which the start is led from)}, steps: [{context?, via?}...] (one per
// step after the start), voices: [{id, range: [lowCents, highCents]}] low to high, tonicCents (the package's reference
// in the performance's cents, 100 to a MIDI step), protectedPitches: {voice: [cents for each step, the start first]},
// budget: {nodes, deadlineMs, now}, beam, exhaustive (no pruning at all: the oracle for tiny cases), aim: {cents, weight}
// (a register: each step costs `weight`, GENERATOR.aimPerSemitone by default, for every semitone its voicing's mean
// pitch lies from `cents`; where moves cost alike, as a scale of chords' steps up and down do, it chooses the way)}.
// Every voice stays inside its range, however a step is made: the validator checks it too.
export function generate(pkg,request){
  const explanations=[],note=explanation=>{if(explanations.length<GENERATOR.explanationsKept)explanations.push(Object.freeze(explanation))};
  let problem,budget;
  try{problem=normalizeRequest(pkg,request);budget=searchBudget(pkg,request.budget)}catch(error){return Object.freeze({status:'invalid',detail:String(error.message),explanations:Object.freeze([])})}
  const {voices,tonicCents,protectedPitches,steps,start,exhaustive,aim}=problem;
  const beam=exhaustive?Infinity:request.beam??GENERATOR.beam;
  let nodes=0,work=0,pruned=false,truncated=false,stopped=null,incumbent=null;
  const spend=()=>{
    if(stopped)return false;
    if(work>=budget.work){stopped='work-limit';return false;}
    const now=budget.now();
    if(!Number.isFinite(now)){stopped='invalid-clock';return false;}
    if(now>budget.deadline){stopped='deadline';return false;}
    work++;return true;
  };
  const remember=state=>{if(state.plan.length===steps.length+1&&(!incumbent||state.cost<incumbent.cost))incumbent=state;};
  const fixedAt=index=>Object.fromEntries(Object.entries(protectedPitches).filter(([,list])=>Number.isFinite(list[index])).map(([voice,list])=>[voice,list[index]]));
  const scored=plan=>validatePlan(pkg,plan,{tonicCents,protectedPitches,voices});
  // How far a step's voicing sits from the register the request aims at (none without an aim).
  const aimCost=step=>{
    if(!aim)return 0;
    const pitches=step.voicing.filter(item=>Number.isFinite(item.cents)).map(item=>item.cents);
    return pitches.length?aim.weight*Math.abs(pitches.reduce((a,b)=>a+b,0)/pitches.length-aim.cents)/100:0;
  };

  // The start: given pitches labelled, or every voicing of the start context's structures.
  let frontier=[];
  const startContext=contextOf(pkg,start.context);
  const startStructures=start.structure?[start.structure]:startContext.structures;
  for(const structureId of startStructures){
    if(!spend())break;
    const structure=structureOf(pkg,structureId),offsetCents=start.offsetCents??0;
    const voicings=start.pitches?[voices.map(voice=>labelled(pkg,structure,voice.id,start.pitches[voice.id]??null,{tonicCents,offsetCents}))]:
      (()=>{const found=enumerateVoicings(pkg,structureId,{tonicCents,offsetCents,voices,fixed:fixedAt(0),cap:exhaustive?Infinity:GENERATOR.enumerationCap,spend});truncated||=found.truncated;return found.voicings})();
    for(const voicing of voicings){
      if(!spend())break;
      const step={context:startContext.id,structure:structureId,offsetCents,via:null,voicing};
      const check=scored([step]);
      if(!check.ok){note({step:0,context:startContext.id,ruleIds:check.hardFailures.map(item=>item.ruleId),detail:check.hardFailures[0].detail});continue}
      // The start's own cost: its soft rules, and how spread it is (a compact start leaves the voices room to move),
      // and every voice asked for and left silent, as a voice falling silent costs (T08: a three-note start is not a
      // free four-voice one); after a voicing already sounding (start.after: {voice: cents}), how far the voices move
      // to it instead.
      const pitches=voicing.filter(item=>Number.isFinite(item.cents)).map(item=>item.cents);
      const lead=start.after?motionCost({voicing:voices.map(voice=>({voice:voice.id,cents:start.after[voice.id]??null}))},step).cost:
        (pitches.at(-1)-pitches[0])/1200+(voicing.length-pitches.length)*GENERATOR.deathCost;
      const candidate={plan:[step],cost:check.softTotal+lead+aimCost(step),soft:check.softTotal};frontier.push(candidate);remember(candidate);
    }
  }
  if(!exhaustive&&frontier.length>beam){pruned=true;frontier=prune(frontier,beam)}

  for(let index=1;index<=steps.length&&frontier.length&&!stopped;index++){
    const wanted=steps[index-1],next=[];
    for(const state of frontier){
      const previous=state.plan.at(-1);
      const options=transitionsFrom(pkg,previous.context).filter(transition=>(!wanted.context||transition.to===wanted.context)&&(!wanted.via||transition.via===wanted.via));
      if(!options.length)note({step:index,context:previous.context,kind:'no-transition',detail:`no transition from ${previous.context}${wanted.context?` to ${wanted.context}`:''}${wanted.via?` by ${wanted.via}`:''}`});
      const total=transitionsFrom(pkg,previous.context).reduce((sum,transition)=>sum+transition.weight,0);
      for(const transition of options){
        for(const candidate of successors(pkg,previous,transition,{tonicCents,voices,fixed:fixedAt(index),protectedPitches,spend})){
          if(candidate.explanation){note({step:index,from:previous.context,to:transition.to,...candidate.explanation});continue}
          truncated||=Boolean(candidate.truncated);
          if(!spend())break;
          if(nodes>=budget.nodes){stopped='node-limit';break}nodes++;
          const plan=[...state.plan,candidate.step],check=scored(plan);
          if(!check.ok){
            const breaking=check.hardFailures.filter(item=>item.step===index||item.type==='resolve');
            // A transformed candidate was shaped by the rules that keep its block: name them beside the rules it broke,
            // so a conflict between two hard rules reads as one (T19).
            const shapedBy=transition.via?pkg.rules.filter(rule=>rule.type==='preserve-block'&&rule.transformation===transition.via&&rule.strength==='hard').map(rule=>rule.id):[];
            note({step:index,from:previous.context,to:transition.to,via:transition.via??null,ruleIds:[...new Set(breaking.map(item=>item.ruleId))],
              ...(shapedBy.length?{shapedBy}:{}),detail:breaking.map(item=>item.detail).join('; ')});
            continue;
          }
          const move=motionCost(previous,candidate.step);
          const validated={plan,cost:state.cost+move.cost+GENERATOR.motionPerSemitone*-Math.log(transition.weight/total)+(check.softTotal-state.soft)+aimCost(candidate.step),soft:check.softTotal};next.push(validated);remember(validated);
        }
        if(stopped)break;
      }
      if(stopped)break;
    }
    if(!exhaustive&&next.length>beam){pruned=true;frontier=prune(next,beam)}else frontier=next.sort((a,b)=>a.cost-b.cost);
  }

  const complete=[...frontier.filter(state=>state.plan.length===steps.length+1),...(incumbent?[incumbent]:[])].sort((a,b)=>a.cost-b.cost);
  const searched=Object.freeze({nodes,work,workLimit:budget.work,pruned,truncated,stopped});
  // The inputs the plan was made from have changed while it was made: whatever it found answers a question no longer
  // asked (T20). The caller's snapshot hash, compared at the end.
  if(request.snapshot&&request.snapshot.hash!==request.snapshot.current?.())return Object.freeze({status:'stale',detail:'the snapshot changed during planning',searched});
  const unsupportedOnly=explanations.length&&explanations.every(item=>item.kind==='unsupported-domain');
  if(!complete.length){
    if(stopped)return Object.freeze({status:'unknown',reason:stopped,explanations:Object.freeze(explanations),searched});
    if(unsupportedOnly)return Object.freeze({status:'unsupported',detail:explanations[0].detail,explanations:Object.freeze(explanations),searched});
    // No plan, and nothing was pruned: none exists within the package as modelled. Anything pruned, and it is unknown.
    return Object.freeze({status:pruned||truncated?'unknown':'infeasible',...(pruned||truncated?{reason:'pruned'}:{}),explanations:Object.freeze(explanations),searched});
  }
  const best=complete[0],report=validatePlan(pkg,best.plan,{tonicCents,protectedPitches,voices});
  if(!report.ok)return Object.freeze({status:'invalid',detail:'the search returned a plan its validator rejects',report,searched});
  return Object.freeze({status:'validated',plan:Object.freeze(best.plan.map(step=>Object.freeze(step))),cost:best.cost,optimalityProven:!pruned&&!truncated&&!stopped,budgetExhausted:Boolean(stopped),report,
    explanations:Object.freeze(explanations),searched,packageVersions:Object.freeze({[pkg.id]:pkg.version})});
}

// Keep `size` states: the best of each context and transformation first, so no one choice fills the beam, then the
// cheapest of the rest.
function prune(states,size){
  const sorted=[...states].sort((a,b)=>a.cost-b.cost),kept=[],seen=new Set;
  for(const state of sorted){const last=state.plan.at(-1),key=`${last.context}|${last.via}`;if(!seen.has(key)&&kept.length<size){seen.add(key);kept.push(state)}}
  for(const state of sorted)if(kept.length<size&&!kept.includes(state))kept.push(state);
  return kept.sort((a,b)=>a.cost-b.cost);
}

function normalizeRequest(pkg,request){
  if(!request||typeof request!=='object')throw new TypeError('A request is an object');
  const voices=request.voices;
  if(!Array.isArray(voices)||!voices.length||voices.length>16)throw new TypeError('A request names 1 to 16 voices');
  voices.forEach((voice,index)=>{
    if(typeof voice.id!=='string'||!Array.isArray(voice.range)||voice.range.length!==2||!voice.range.every(Number.isFinite)||voice.range[0]>voice.range[1])throw new TypeError(`Voice ${index} needs an id and a range`);
  });
  const count=request.steps??0;
  if(!Array.isArray(count)&&(!Number.isSafeInteger(count)||count<0||count>64))throw new TypeError('Steps must be an integer in0..64 or an array');
  const steps=Array.isArray(count)?count:Array.from({length:count},()=>({}));
  if(steps.length>64)throw new TypeError('At most 64 steps are planned at once');
  if(!request.start||typeof request.start.context!=='string')throw new TypeError('A request starts in a context');
  contextOf(pkg,request.start.context);
  const protectedPitches=request.protectedPitches??{};
  for(const [voice,list] of Object.entries(protectedPitches)){
    if(!voices.some(item=>item.id===voice))throw new TypeError(`A protected voice ${voice} is not one of the request's voices`);
    if(!Array.isArray(list)||list.length>steps.length+1)throw new TypeError(`${voice}'s protected pitches are one per step at most`);
  }
  const tonicCents=request.tonicCents??0;
  if(!Number.isFinite(tonicCents))throw new TypeError('A tonic is a finite number of cents');
  let aim=null;
  if(request.aim!==undefined&&request.aim!==null){
    const weight=request.aim.weight??GENERATOR.aimPerSemitone;
    if(!Number.isFinite(request.aim.cents)||!Number.isFinite(weight)||weight<0)throw new TypeError('An aim is a finite pitch in cents and a weight of zero or more');
    aim={cents:request.aim.cents,weight};
  }
  return {voices,steps,start:request.start,protectedPitches,tonicCents,exhaustive:Boolean(request.exhaustive),aim};
}

export const pitchOfVoice=pitchOf;
// What a move from one step to the next costs: motion, and every voice that enters or falls silent (T08).
export const stepCost=motionCost;

// The deadline retains the existing absolute clock convention. It is checked
// cooperatively; validation, bounded per-item work and scheduling can overrun it.
function searchBudget(pkg,input={}){
  const nodes=input.nodes??pkg.limits.searchNodes,work=input.work??1000000,
    deadline=input.deadlineMs??Infinity,now=input.now??(()=>performance.now());
  if(!Number.isSafeInteger(nodes)||nodes<0||nodes>10000000||!Number.isSafeInteger(work)||work<1||work>10000000)
    throw new TypeError('Search nodes/work must be finite bounded integer budgets');
  if(!(Number.isFinite(deadline)||deadline===Infinity)||typeof now!=='function')throw new TypeError('Invalid deadline/clock');
  return {nodes,work,deadline,now};
}
