// A part's own time over the shared tick: any tempo relation to the ensemble, held, glided to another, and left
// (RESEARCH_BACKLOG, "A part's tempo relation made interpolable in full"). A stream whose beat is a whole number of
// shared ticks (rhythm-vocabulary.js streamOf) relates to the ensemble only as the ensemble's subdivision over its own:
// under a subdivision of 2, as 2:1, 2:3 or 1:2, never 3:2 or 5:4. Here a part's position, counted in its own ticks, is a
// function of the shared tick, in pieces that each begin on a whole shared tick:
//   - a hold at a rate (the part's ticks a shared tick), any positive rational;
//   - a glide from one rate to another over D shared ticks, the rate moving in proportion to shared time (a linear
//     accelerando or ritardando against the band), then held at the second.
// A piece's position is computed in closed form from its own beginning, never accumulated, and at every whole shared
// tick it is an exact rational (BigInt): a part neither drifts nor rounds to the shared grid. Which of its ticks fall in
// which shared tick is decided exactly; only where each falls inside its shared tick is a float, for the audio.
// The shared tick stays the only clock, and the band's rubato maps it to seconds (rubato-clocks.js), so a part keeps its
// relation to the band's beat through the band's rubato. Inside one shared tick the band's tempo is that tick's.

const big=value=>typeof value==='bigint'?value:BigInt(value);
const gcd=(a,b)=>{a=a<0n?-a:a;b=b<0n?-b:b;while(b)[a,b]=[b,a%b];return a};
// A rational, [numerator, denominator] as BigInts, reduced, its denominator positive.
export function rational(n,d=1n){
  n=big(n);d=big(d);
  if(d===0n)throw new RangeError('A rational\'s denominator is not zero');
  if(d<0n){n=-n;d=-d}
  const g=gcd(n,d)||1n;return Object.freeze([n/g,d/g]);
}
const add=([a,b],[c,d])=>rational(a*d+c*b,b*d),sub=([a,b],[c,d])=>rational(a*d-c*b,b*d);
const mul=([a,b],[c,d])=>rational(a*c,b*d),div=([a,b],[c,d])=>rational(a*d,b*c);
export const compare=([a,b],[c,d])=>{const x=a*d-c*b;return x<0n?-1:x>0n?1:0};
const floor=([n,d])=>{const q=n/d;return n%d!==0n&&n<0n?q-1n:q};
const ceil=([n,d])=>-floor([-n,d]);
// A rational as the nearest number: its whole part, then its fraction, so a large position keeps its fraction's
// digits. A denominator past 2^53 (many glides' worth) takes its fraction to 2^-53 by BigInt division.
const SCALE=1n<<53n;
export const toNumber=([n,d])=>{const whole=floor([n,d]),rest=n-whole*d;return Number(whole)+(d<=SCALE?Number(rest)/Number(d):Number(rest*SCALE/d)/Number(SCALE))};
const ZERO=rational(0),HALF=rational(1,2);
// The most of a part's ticks that one shared tick may hold, and the largest denominator a rate may have.
export const PART_TIME_LIMITS=Object.freeze({ticksPerSharedTick:64,denominator:1<<20,pieces:256});

// A positive rational from [p, q], two positive whole numbers (or from a rational already made).
export function rateOf(value){
  if(Array.isArray(value)&&value.length===2&&value.every(each=>typeof each==='bigint')&&value[0]>0n&&value[1]>0n)return rational(value[0],value[1]);
  if(!Array.isArray(value)||value.length!==2||!value.every(Number.isSafeInteger)||!(value[0]>0&&value[1]>0))
    throw new RangeError('A rate is [p, q], two positive whole numbers');
  const rate=rational(value[0],value[1]);
  if(rate[1]>BigInt(PART_TIME_LIMITS.denominator))throw new RangeError(`A rate's denominator is at most ${PART_TIME_LIMITS.denominator}`);
  if(compare(rate,rational(PART_TIME_LIMITS.ticksPerSharedTick))>0)throw new RangeError(`A rate is at most ${PART_TIME_LIMITS.ticksPerSharedTick} ticks a shared tick`);
  return rate;
}
function piece(at,start,from,to=from,ticks=0){
  if(!Number.isSafeInteger(ticks)||ticks<0)throw new RangeError('A glide lasts a whole number of shared ticks');
  return Object.freeze({at,start,from,to:ticks?to:from,ticks});
}
// A time map from the shared tick `anchor`, where the part is at its own tick 0, at `rate`.
export function timeMap({anchor=0,rate=[1,1]}={}){
  if(!Number.isSafeInteger(anchor))throw new RangeError('A time map begins on a whole shared tick');
  return Object.freeze({anchor,pieces:Object.freeze([piece(anchor,ZERO,rateOf(rate))])});
}
// The piece in force at shared tick t: the last to begin at or before it (searched from the latest, where a part's
// clock asks). A map keeps its last PIECES pieces; a tick before the first of them is refused, never guessed.
function pieceAt(map,t){
  for(let index=map.pieces.length-1;index>=0;index--)if(map.pieces[index].at<=t)return map.pieces[index];
  if(t<map.anchor)throw new RangeError('A time map is not asked before its anchor');
  throw new RangeError('A time map keeps its latest pieces only: this tick is before them');
}
// A piece's position x shared ticks after it begins (x rational, not negative), exactly: in a glide,
// start + from·x + (to − from)·x² / 2D.
function positionIn(p,x){
  if(!p.ticks)return add(p.start,mul(p.from,x));
  const D=rational(p.ticks);
  if(compare(x,D)>=0)return add(add(p.start,mul(D,mul(add(p.from,p.to),HALF))),mul(p.to,sub(x,D)));
  return add(add(p.start,mul(p.from,x)),div(mul(sub(p.to,p.from),mul(x,x)),mul(rational(2),D)));
}
// Its rate x whole shared ticks after it begins, exactly: from + (to − from)·x / D in a glide.
function rateIn(p,x){
  if(x>=p.ticks)return p.to;
  return add(p.from,div(mul(sub(p.to,p.from),rational(x)),rational(p.ticks)));
}
// The part's position, in its own ticks, at the whole shared tick t, exactly (0 at the map's anchor).
export function positionAt(map,t){
  if(!Number.isSafeInteger(t))throw new RangeError('A position is asked at a whole shared tick');
  const p=pieceAt(map,t);
  return positionIn(p,rational(Math.max(0,t-p.at)));
}
// The part's position at a shared position t that need not be whole (a number, taken exactly as the binary fraction
// it is), through the piece in force there, a glide's quadratic kept: positionAt between whole ticks, never rounded to
// one.
export function positionAtShared(map,t){
  if(Number.isSafeInteger(t))return positionAt(map,t);
  if(!Number.isFinite(t))throw new RangeError('A position is asked at a finite shared position');
  let n=t,d=1n;while(!Number.isInteger(n)){n*=2;d*=2n}
  const p=pieceAt(map,t),x=sub(rational(BigInt(n),d),rational(p.at));
  return positionIn(p,compare(x,ZERO)<0?ZERO:x);
}
// The same map for authored symbolic positions. Keep the caller's exact fraction throughout; converting it to a
// floating point shared position first would change the rhythm that notation is supposed to preserve.
export function positionAtRational(map,value){
  const t=rational(...value);
  for(let index=map.pieces.length-1;index>=0;index--){
    const p=map.pieces[index],x=sub(t,rational(p.at));
    if(compare(x,ZERO)>=0)return positionIn(p,x);
  }
  throw new RangeError('Symbolic position is before the time map\'s retained pieces');
}
// The part's rate at the whole shared tick t, exactly.
export function rateAt(map,t){const p=pieceAt(map,t);return rateIn(p,Math.max(0,t-p.at))}
// A composed rate and its derivative at an exact shared position. Used to transform tempo instructions without
// inverting a quadratic to a rounded shared tick. Both answers are exact rational ticks per shared tick (and its
// derivative); a completed glide has zero derivative.
export function rateAtRational(map,value){
  const t=rational(...value);
  for(let index=map.pieces.length-1;index>=0;index--){
    const p=map.pieces[index],x=sub(t,rational(p.at));
    if(compare(x,ZERO)<0)continue;
    if(!p.ticks||compare(x,rational(p.ticks))>=0)return {rate:p.to,slope:ZERO};
    const slope=div(sub(p.to,p.from),rational(p.ticks));
    return {rate:add(p.from,mul(slope,x)),slope};
  }
  throw new RangeError('Symbolic rate is before the time map\'s retained pieces');
}
// Where, in shared ticks after its piece begins, the part reaches its own tick k, as a number. In a glide it is
// x = 2Δ / (from + rate(x)), where rate(x) = √(from² + 2Δ(to − from)/D) and Δ is k less the piece's start: the stable
// root, whose sum never cancels.
function shiftOf(p,k){
  const target=rational(k),delta=sub(target,p.start);
  if(!p.ticks)return toNumber(div(delta,p.from));
  const D=rational(p.ticks),reached=positionIn(p,D);
  if(compare(target,reached)>=0)return p.ticks+toNumber(div(sub(target,reached),p.to));
  const a=toNumber(p.from),b=toNumber(p.to),d=toNumber(delta);
  return 2*d/(a+Math.sqrt(a*a+2*d*(b-a)/p.ticks));
}
// Where the part's own tick k falls, in shared ticks (a number): positionAt's inverse.
export function sharedAt(map,k){
  const target=rational(k);
  for(let index=map.pieces.length-1;index>=0;index--){const p=map.pieces[index];if(compare(p.start,target)<=0)return p.at+shiftOf(p,k)}
  throw new RangeError('A time map keeps its latest pieces only: this tick is before them');
}
// The part's ticks falling in the shared tick t, [t, t + 1): each its own tick, where in t it falls (0 <= fraction <
// 1), and the part's rate there (a number; `exact`, a rational, where the rate is held). A tick k is in t exactly when
// position(t) <= k < position(t + 1).
export function ticksIn(map,t){
  const from=positionAt(map,t),to=positionAt(map,t+1),first=ceil(from),end=ceil(to),p=pieceAt(map,t),out=[];
  for(let k=first;k<end;k++){
    const x=shiftOf(p,k),fraction=Math.min(Math.max(0,x-(t-p.at)),1-Number.EPSILON),held=!p.ticks||x>=p.ticks;
    const rate=held?toNumber(p.to):toNumber(p.from)+(toNumber(p.to)-toNumber(p.from))*x/p.ticks;
    out.push({tick:Number(k),fraction,rate,...(held?{exact:p.to}:{})});
  }
  return out;
}
// The map changed from the whole shared tick `at`: held at `rate`, or glided to `to` over `ticks` shared ticks from
// `from`, or from its rate there where `from` is not given (no jump of tempo). The part's position there is kept.
export function changed(map,{at,rate=null,from=null,to=null,ticks=0}){
  if(!Number.isSafeInteger(at)||at<map.anchor)throw new RangeError('A change begins on a whole shared tick, at or after the map\'s anchor');
  const current=pieceAt(map,at),start=positionAt(map,at),here=rateIn(current,Math.max(0,at-current.at));
  const next=rate?piece(at,start,rateOf(rate)):piece(at,start,from?rateOf(from):here,rateOf(to),ticks);
  // A change replaces what the map said from `at` on; the pieces before it are kept, the latest of them.
  return Object.freeze({anchor:map.anchor,pieces:Object.freeze([...map.pieces.filter(each=>each.at<at),next].slice(-PART_TIME_LIMITS.pieces))});
}
// Whether the map is gliding at the whole shared tick t, and how far through: {from, to, progress} or null.
export function glideAt(map,t){
  const p=pieceAt(map,t),x=t-p.at;
  return p.ticks&&x>=0&&x<p.ticks?{from:p.from,to:p.to,progress:x/p.ticks,ticks:p.ticks,at:p.at}:null;
}
