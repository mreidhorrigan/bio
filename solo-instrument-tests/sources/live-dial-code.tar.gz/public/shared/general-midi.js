// General MIDI's programs, and the one nearest each voice family (shared/articulation.js FAMILIES), for a bot playing
// an external instrument: a bot that plays a pluck asks a General MIDI synthesizer for a guitar, one that plays a pad for
// a pad, and a bot that changes its instrument changes the program with it (audio.js midiNote).
//
// A program is asked for only when a bot's MIDI program setting says so. 'none' (the default) leaves the receiving
// instrument's own: a DAW's plugins and a hardware synthesizer's patches are the player's to choose, and a Program
// Change would replace them. 'gm' follows the family of each note. A number (0-127, the wire's value; General MIDI
// counts them 1-128) is that program, whatever the bot plays.

// General MIDI Level 1's instruments, by wire value (0-127).
export const GM_PROGRAMS=Object.freeze([
  'Acoustic Grand Piano','Bright Acoustic Piano','Electric Grand Piano','Honky-tonk Piano','Electric Piano 1','Electric Piano 2','Harpsichord','Clavi',
  'Celesta','Glockenspiel','Music Box','Vibraphone','Marimba','Xylophone','Tubular Bells','Dulcimer',
  'Drawbar Organ','Percussive Organ','Rock Organ','Church Organ','Reed Organ','Accordion','Harmonica','Tango Accordion',
  'Acoustic Guitar (nylon)','Acoustic Guitar (steel)','Electric Guitar (jazz)','Electric Guitar (clean)','Electric Guitar (muted)','Overdriven Guitar','Distortion Guitar','Guitar harmonics',
  'Acoustic Bass','Electric Bass (finger)','Electric Bass (pick)','Fretless Bass','Slap Bass 1','Slap Bass 2','Synth Bass 1','Synth Bass 2',
  'Violin','Viola','Cello','Contrabass','Tremolo Strings','Pizzicato Strings','Orchestral Harp','Timpani',
  'String Ensemble 1','String Ensemble 2','SynthStrings 1','SynthStrings 2','Choir Aahs','Voice Oohs','Synth Voice','Orchestra Hit',
  'Trumpet','Trombone','Tuba','Muted Trumpet','French Horn','Brass Section','SynthBrass 1','SynthBrass 2',
  'Soprano Sax','Alto Sax','Tenor Sax','Baritone Sax','Oboe','English Horn','Bassoon','Clarinet',
  'Piccolo','Flute','Recorder','Pan Flute','Blown Bottle','Shakuhachi','Whistle','Ocarina',
  'Lead 1 (square)','Lead 2 (sawtooth)','Lead 3 (calliope)','Lead 4 (chiff)','Lead 5 (charang)','Lead 6 (voice)','Lead 7 (fifths)','Lead 8 (bass + lead)',
  'Pad 1 (new age)','Pad 2 (warm)','Pad 3 (polysynth)','Pad 4 (choir)','Pad 5 (bowed)','Pad 6 (metallic)','Pad 7 (halo)','Pad 8 (sweep)',
  'FX 1 (rain)','FX 2 (soundtrack)','FX 3 (crystal)','FX 4 (atmosphere)','FX 5 (brightness)','FX 6 (goblins)','FX 7 (echoes)','FX 8 (sci-fi)',
  'Sitar','Banjo','Shamisen','Koto','Kalimba','Bag pipe','Fiddle','Shanai',
  'Tinkle Bell','Agogo','Steel Drums','Woodblock','Taiko Drum','Melodic Tom','Synth Drum','Reverse Cymbal',
  'Guitar Fret Noise','Breath Noise','Seashore','Bird Tweet','Telephone Ring','Helicopter','Applause','Gunshot',
]);

// Each family's nearest General MIDI instrument (ours): the instrument General MIDI names for the same thing where it has
// one, otherwise the one made the same way (plucked, struck, bowed, blown, swelled). The drums have none: a drum part
// plays General MIDI's drum notes on its channel, which takes no program. MemoryBOT's preview has no instrument of its
// own, and leaves the channel's.
export const FAMILY_PROGRAMS=Object.freeze({
  pluck:25,        // Acoustic Guitar (steel): bright at the pick, darkening as it rings
  keys:0,          // Acoustic Grand Piano
  epiano:4,        // Electric Piano 1: the tine piano
  bass:33,         // Electric Bass (finger)
  synthBass:39,    // Synth Bass 2 (acid takes Synth Bass 1, so the two stay apart)
  acid:38,         // Synth Bass 1: the resonant, accented synthesizer bass
  synthPluck:81,   // Lead 2 (sawtooth): a loop's sequenced line (General MIDI has no plucked synthesizer)
  lead:80,         // Lead 1 (square)
  bowed:48,        // String Ensemble 1 (a section covers any register a bot plays in)
  pad:89,          // Pad 2 (warm): detuned voices, a filter that opens with the swell
  drone:95,        // Pad 8 (sweep): it drifts rather than swells
  organ:16,        // Drawbar Organ
  bell:14,         // Tubular Bells
  partials:93,     // Pad 6 (metallic): a held body of partials
  fmTexture:98,    // FX 3 (crystal): FM's inharmonic shimmer
  wind:73,         // Flute
  texture:99,      // FX 4 (atmosphere): swells and fades, nothing struck
  resonant:104,    // Sitar: plucked, with its strings' resonance
  noise:122,       // Seashore: filtered noise, faded in and out
  preview:null,
  kick:null,tom:null,snareBody:null,snareWires:null,hat:null,clap:null,shaker:null,
});

export const MIDI_PROGRAM_MODES=Object.freeze(['none','gm']);
// A program setting as the engine keeps it: 'none', 'gm', or a program's wire value. Accepts a program number as a
// string (a form's value) too.
export function midiProgramSetting(value='none'){
  if(value===null||value===undefined||value==='')return 'none';
  if(MIDI_PROGRAM_MODES.includes(value))return value;
  const program=typeof value==='string'&&/^\d+$/.test(value.trim())?Number(value):value;
  if(Number.isInteger(program)&&program>=0&&program<=127)return program;
  throw new RangeError(`A MIDI program setting is 'none', 'gm' or a program from 0 to 127, not ${JSON.stringify(value)}`);
}
// The program a note on `family` asks for under `setting`, or null for none.
export function programFor(setting,family){
  const chosen=midiProgramSetting(setting);
  if(chosen==='none')return null;
  if(chosen==='gm')return FAMILY_PROGRAMS[family]??null;
  return chosen;
}
// A program's name as General MIDI counts it: "26 Acoustic Guitar (steel)".
export const programLabel=program=>`${program+1} ${GM_PROGRAMS[program]}`;
