import {FUTURE_LIMITS as LIMITS,identifier,number,frozenJson,knownFields} from './planning-data.js';

export const UNKNOWN='unknown';
const comparisons=new Set(['eq','neq','lt','lte','gt','gte']);
export function validateGuard(value,inputs) {
  let nodes=0;
  const visit=(node,depth)=>{
    if(++nodes>LIMITS.guardNodes||depth>LIMITS.guardDepth||!node||typeof node!=='object'||Array.isArray(node))throw new Error('Guard budget or shape is invalid');
    knownFields(node,node.op==='constant'?['op','value']:node.op==='not'?['op','arg']:
      ['and','or'].includes(node.op)?['op','args']:node.op==='present'?['op','input']:['op','input','value'],'guard');
    if(node.op==='constant') {
      if(typeof node.value!=='boolean')throw new Error('Guard constant must be boolean');
      return {op:node.op,value:node.value};
    }
    if(node.op==='not')return {op:'not',arg:visit(node.arg,depth+1)};
    if(node.op==='and'||node.op==='or') {
      if(!Array.isArray(node.args)||!node.args.length||node.args.length>8)throw new Error('Guard requires 1–8 operands');
      return {op:node.op,args:node.args.map(arg=>visit(arg,depth+1))};
    }
    const input=identifier(node.input,'guard input'),contract=inputs.find(value=>value.name===input);
    if(!contract)throw new Error('Guard references an undeclared input');
    if(node.op==='present')return {op:'present',input};
    if(!comparisons.has(node.op))throw new Error('Unknown guard operation');
    if(typeof node.value!==contract.type)throw new Error('Guard literal/input type mismatch');
    if(contract.type==='number')number(node.value,'guard value',{min:-Number.MAX_VALUE,max:Number.MAX_VALUE});
    if(!['eq','neq'].includes(node.op)&&contract.type!=='number')throw new Error('Ordering guards require numeric inputs');
    return {op:node.op,input,value:node.value};
  };
  return frozenJson(visit(value,0)).data;
}
export function evaluateGuard(guard,snapshot) {
  if(guard.op==='constant')return guard.value;
  if(guard.op==='not'){const result=evaluateGuard(guard.arg,snapshot);return result===UNKNOWN?UNKNOWN:!result;}
  if(guard.op==='and'||guard.op==='or') {
    const values=guard.args.map(arg=>evaluateGuard(arg,snapshot));
    if(guard.op==='and')return values.includes(false)?false:values.includes(UNKNOWN)?UNKNOWN:true;
    return values.includes(true)?true:values.includes(UNKNOWN)?UNKNOWN:false;
  }
  const input=snapshot.inputs.find(value=>value.name===guard.input);
  if(!input||!['known','absent'].includes(input.state))return UNKNOWN;
  if(guard.op==='present')return input.state==='known';
  if(input.state!=='known')return UNKNOWN;
  switch(guard.op) {
    case 'eq':return input.value===guard.value;
    case 'neq':return input.value!==guard.value;
    case 'lt':return input.value<guard.value;
    case 'lte':return input.value<=guard.value;
    case 'gt':return input.value>guard.value;
    case 'gte':return input.value>=guard.value;
    default:throw new Error('Unknown validated guard');
  }
}
export function evaluateDecision(overplan,snapshot) {
  const results=overplan.branches.map(branch=>({branchId:branch.id,priority:branch.priority,result:evaluateGuard(branch.guard,snapshot)}));
  if(results.some(value=>value.result===UNKNOWN))return {outcome:overplan.unknownOutcome,reason:'unknown-input',results};
  const chosen=results.filter(value=>value.result===true).sort((a,b)=>b.priority-a.priority)[0];
  return {outcome:chosen?.branchId||overplan.noMatchOutcome,reason:chosen?'matched':'no-match',results};
}
