// What mh_MemoryBOT keeps is decided by evidence of use, not by arrival order.
//
// The store used to be a queue: the oldest complete record was dropped when the
// limit was reached. That throws away the motif another bot has been quoting all
// evening in favour of the phrase a pad captured four bars ago, because app.js
// flushMotif publishes every bot's captured phrase at every phrase boundary.
// Most of that traffic is passagework nobody ever asks for again.
//
// So every stored motif carries a ledger of the protocol messages that actually
// touched it, and eviction reads that ledger. The ordering is lexicographic on
// a tier first, so the distinction the ensemble cares about is categorical and
// cannot be eroded by time:
//
//   3 pinned  a human imported this clip by hand
//   2 shared  at least one OTHER bot retrieved, replayed or developed it
//   1 self    only its own author has come back to it
//   0 unused  captured passagework nothing has ever used
//
// A tier is never lost, so a motif that earned use in the first minute is still
// held an hour later; only unused passagework expires. Inside a tier, records
// are ordered by an accumulated use credit (monotone, saturating) plus a decaying
// freshness term, and exact ties break on motifId. Nothing depends on Map
// insertion order, so two identical message sequences evict identical records.

const LN2=Math.LN2;
const clamp=(value,low,high)=>value<low?low:value>high?high:value;
const round=(value,places=6)=>Number(Number(value).toFixed(places));
const positiveInteger=(value,name)=>{
  const number=Math.trunc(Number(value));
  if(!Number.isFinite(number)||number<1)throw new RangeError(`${name} must be a positive integer`);
  return number;
};
const positiveNumber=(value,name)=>{
  const number=Number(value);
  if(!Number.isFinite(number)||number<=0)throw new RangeError(`${name} must be a positive number`);
  return number;
};
const weight=(value,name)=>{
  const number=Number(value);
  if(!Number.isFinite(number)||number<0)throw new RangeError(`${name} must be a nonnegative number`);
  return number;
};

// Bounds the direct transfer path in shared/memory-transfer.js and the bounded
// query response in shared/motifs.js queryMotifs. Restated here so the capacity
// derivation can be read in one place.
export const MEMORY_TRANSFER_LIMITS=Object.freeze({
  chunkChars:6000,maxChunks:12000,maxBytes:32*1024*1024,responseLimit:32,
  shareLinkBytes:65536,shareLinkChars:12000,
});

// Measured with scripts/measure-motif-capacity.mjs (node 26 / V8, headless
// Chrome 140, macOS arm64, 2026-09-15). Re-run it after any change to the motif
// schema, to AudioEngine.captureUMP's expression sampling, or to the browser
// baseline, and update these numbers rather than the derived capacity.
export const MOTIF_CAPACITY_MEASUREMENTS=Object.freeze({
  // A validated schema-2 record with no events: motifId, frozen metadata,
  // timebase and fingerprint. Measured over 2000 records.
  recordOverheadBytes:2180,
  // Retained V8 heap for one {time,packet:[w0..w3]} event, averaged over the
  // four phrase shapes the ensemble publishes (48, 304, 513 and 1409 events).
  bytesPerEvent:168,
  // The same event serialized for /agent/memory/transfer.
  jsonBytesPerEvent:51,
  // Mean captured-phrase length across those four shapes was 569 events;
  // 512 is the power of two just below it and the figure the policy uses.
  typicalCaptureEvents:512,
  // What a tab can hold. Headless Chrome reports a ~4 GiB jsHeapSizeLimit on
  // this desktop, but the binding case is a phone, where the whole page is
  // reclaimed long before that. 256 MiB is the conservative working budget for
  // the entire page, and the motif library is one subsystem beside the audio
  // graph, the worklets, the sample banks, the visualizers and the protocol
  // trace, so it gets an eighth of it.
  conservativeTabHeapBytes:256*1024*1024,
  storeHeapBudgetBytes:32*1024*1024,
  // Kept from the previous hand-set limit: the store-wide event ceiling that
  // bounds a few very dense clips independently of the record count.
  eventCapacity:262144,
});

// capacity = how many typical captured phrases fit the heap budget, also
// bounded by the store-wide event ceiling, rounded down to a power of two so
// the number reads as a budget rather than as a measurement artefact.
export function deriveMotifCapacity(measurements=MOTIF_CAPACITY_MEASUREMENTS){
  const bytesPerMotif=measurements.recordOverheadBytes+measurements.typicalCaptureEvents*measurements.bytesPerEvent,
    byHeap=Math.floor(measurements.storeHeapBudgetBytes/bytesPerMotif),
    byEvents=Math.floor(measurements.eventCapacity/measurements.typicalCaptureEvents),
    binding=Math.max(1,Math.min(byHeap,byEvents));
  return Object.freeze({bytesPerMotif,byHeap,byEvents,
    binding:byHeap<=byEvents?'tab heap budget':'store event ceiling',
    capacity:Math.max(1,2**Math.floor(Math.log2(binding))),
    // Above this the library alone would claim the whole conservative tab
    // budget; a policy message asking for more is refused rather than obeyed.
    ceiling:Math.max(1,Math.floor(measurements.conservativeTabHeapBytes/bytesPerMotif))});
}

// What the transfer paths can move, for the same measured motif.
export function motifTransferBudget(measurements=MOTIF_CAPACITY_MEASUREMENTS){
  const jsonBytesPerMotif=measurements.typicalCaptureEvents*measurements.jsonBytesPerEvent,
    responseBytes=MEMORY_TRANSFER_LIMITS.responseLimit*jsonBytesPerMotif;
  return Object.freeze({
    responseLimit:MEMORY_TRANSFER_LIMITS.responseLimit,jsonBytesPerMotif,responseBytes,
    headroom:MEMORY_TRANSFER_LIMITS.maxBytes/responseBytes,
    chunksPerResponse:Math.ceil(responseBytes/MEMORY_TRANSFER_LIMITS.chunkChars),
    // One motif still has to fit a single direct message beside 31 others.
    perMotifCeilingBytes:Math.floor(MEMORY_TRANSFER_LIMITS.maxBytes/MEMORY_TRANSFER_LIMITS.responseLimit),
    perMotifCeilingEvents:Math.floor(MEMORY_TRANSFER_LIMITS.maxBytes/MEMORY_TRANSFER_LIMITS.responseLimit/measurements.jsonBytesPerEvent),
    // Share links carry the roster and setup, never the library: the compact
    // codec refuses more than 65536 bytes before compression.
    shareLinkMotifs:Math.floor(MEMORY_TRANSFER_LIMITS.shareLinkBytes/jsonBytesPerMotif),
  });
}

const DERIVED=deriveMotifCapacity();

// How each protocol signal counts. `promotes` is what separates a motif that
// has been used from passagework that has merely been seen: a query result was
// offered to a bot, which is not the same as a bot doing anything with it.
export const MOTIF_USE_KINDS=Object.freeze({
  offered:{weight:.02,promotes:false},    // returned by /agent/memory/query
  restated:{weight:.05,promotes:false},   // stored again, byte-identical
  retrieved:{weight:.5,promotes:true},    // /agent/memory/get by motifId
  derived:{weight:1,promotes:true},       // /agent/memory/playing mode 'derived'
  replayed:{weight:1.5,promotes:true},    // /agent/memory/playing mode 'replay'
  developed:{weight:1.25,promotes:true},  // stored motif names it as parentMotifId
  broadcast:{weight:.75,promotes:true},   // MemoryBot.broadcastMotif
  recurred:{weight:.05,promotes:false},   // its author played it again: exposure, not a new record
});
export const MOTIF_USE_NAMES=Object.freeze(Object.keys(MOTIF_USE_KINDS));
export const MOTIF_TIERS=Object.freeze(['unused','self','shared','pinned']);
export const MOTIF_ORIGINS=Object.freeze(['passagework','published','developed','imported']);

export const MOTIF_RETENTION_DEFAULTS=Object.freeze({
  capacity:DERIVED.capacity,
  eventCapacity:MOTIF_CAPACITY_MEASUREMENTS.eventCapacity,
  // A motif nothing has touched keeps about half its freshness over a
  // ten-minute improvisation; a used motif keeps its tier regardless.
  halfLifeMs:600000,
  // Use by another bot is the signal the ensemble cares about. Use by the
  // author is real but weaker: a bot quoting itself is not circulation.
  foreignWeight:1,
  ownWeight:.35,
  // A 'derived' report names the source notes actually matched. Eight distinct
  // notes is treated as full use of the motif; more adds nothing further.
  coverageFull:8,
  useWeights:Object.freeze(Object.fromEntries(Object.entries(MOTIF_USE_KINDS).map(([name,kind])=>[name,kind.weight]))),
  maxActorsPerMotif:64,
  evictionLogLimit:64,
  // A 'derived' report names the source notes it matched. Their union is kept
  // so a view can mark the phrase fragments the ensemble has quoted, not only
  // count them; a dense clip stops contributing once it has said enough.
  maxQuotedNotesPerMotif:512,
  // Memory across seconds (the extreme-aesthetics report's §5.3, E20). New records an author may add, per second of
  // elapsed time, with a burst: at the capacity above and eight authors at the rate, the densest texture turns the
  // store over in about a minute at the quickest. Ours. The rate assumes captures a phrase long (app.js flushes at
  // phrase boundaries, four bars): a bot flushing every bar at 120 BPM sits exactly at it, so captures a bar or shorter
  // are heard, and only some of them stored.
  admissionsPerSecond:.5,
  admissionBurst:4,
  // Records held for the form (its themes, its opening's lines) rank above all but pinned ones, at most so many.
  salientLimit:48,
  // Compact identities kept after their records' events are gone, so a motive that comes back is known again.
  identityLimit:1024,
});

// The single adjustment point. STOCHASTIC_CONFIG.memory spreads these, and
// /agent/memory/policy passes overrides straight through here at runtime, so
// no capacity is ever written as a literal at a call site.
export function motifRetentionPolicy(overrides={}){
  const source=overrides&&typeof overrides==='object'?overrides:{};
  // `limit` is the historical name for the same knob.
  const capacity=positiveInteger(source.capacity??source.limit??MOTIF_RETENTION_DEFAULTS.capacity,'capacity');
  if(capacity>DERIVED.ceiling)throw new RangeError(`capacity above ${DERIVED.ceiling} exceeds the measured tab budget for a motif library`);
  const useWeights={...MOTIF_RETENTION_DEFAULTS.useWeights};
  for(const [name,value] of Object.entries(source.useWeights||{})){
    if(!(name in useWeights))throw new RangeError(`Unknown motif use kind: ${name}`);
    useWeights[name]=weight(value,`useWeights.${name}`);
  }
  return Object.freeze({
    capacity,
    eventCapacity:positiveInteger(source.eventCapacity??MOTIF_RETENTION_DEFAULTS.eventCapacity,'eventCapacity'),
    halfLifeMs:positiveNumber(source.halfLifeMs??MOTIF_RETENTION_DEFAULTS.halfLifeMs,'halfLifeMs'),
    foreignWeight:weight(source.foreignWeight??MOTIF_RETENTION_DEFAULTS.foreignWeight,'foreignWeight'),
    ownWeight:weight(source.ownWeight??MOTIF_RETENTION_DEFAULTS.ownWeight,'ownWeight'),
    coverageFull:positiveNumber(source.coverageFull??MOTIF_RETENTION_DEFAULTS.coverageFull,'coverageFull'),
    useWeights:Object.freeze(useWeights),
    maxActorsPerMotif:positiveInteger(source.maxActorsPerMotif??MOTIF_RETENTION_DEFAULTS.maxActorsPerMotif,'maxActorsPerMotif'),
    evictionLogLimit:positiveInteger(source.evictionLogLimit??MOTIF_RETENTION_DEFAULTS.evictionLogLimit,'evictionLogLimit'),
    maxQuotedNotesPerMotif:positiveInteger(source.maxQuotedNotesPerMotif??MOTIF_RETENTION_DEFAULTS.maxQuotedNotesPerMotif,'maxQuotedNotesPerMotif'),
    admissionsPerSecond:positiveNumber(source.admissionsPerSecond??MOTIF_RETENTION_DEFAULTS.admissionsPerSecond,'admissionsPerSecond'),
    admissionBurst:positiveInteger(source.admissionBurst??MOTIF_RETENTION_DEFAULTS.admissionBurst,'admissionBurst'),
    salientLimit:positiveInteger(source.salientLimit??MOTIF_RETENTION_DEFAULTS.salientLimit,'salientLimit'),
    identityLimit:positiveInteger(source.identityLimit??MOTIF_RETENTION_DEFAULTS.identityLimit,'identityLimit'),
  });
}

const emptyCounts=()=>Object.fromEntries(MOTIF_USE_NAMES.map(name=>[name,0]));

export class MotifRetention{
  // `now` is injected so a test — or a seeded replay — can drive the decay
  // exactly. Nothing here calls Math.random, and the only ordering input is
  // the ledger, never the order a Map happens to hold.
  constructor(policy={},{now=Date.now}={}){
    this.policy=motifRetentionPolicy(policy);
    this.now=typeof now==='function'?now:()=>now;
    this.entries=new Map;this.evictions=[];this.revision=0;this.buckets=new Map;
  }
  // Whether `author` may add a record now: a bucket per author, refilled at admissionsPerSecond up to admissionBurst,
  // on the retention clock (elapsed time; a render's virtual time). A dense run that would pass it adds exposure to what
  // it repeats and nothing else, so it cannot turn the store over faster than the bound (§5.3).
  admissionAllowed(author,at=this.now()){
    const id=String(author||''),{admissionsPerSecond:rate,admissionBurst:burst}=this.policy;
    const bucket=this.buckets.get(id)??{tokens:burst,at};
    bucket.tokens=Math.min(burst,bucket.tokens+Math.max(0,at-bucket.at)/1000*rate);bucket.at=at;
    const allowed=bucket.tokens>=1;if(allowed)bucket.tokens-=1;
    this.buckets.set(id,bucket);
    // Bounded like everything a long session accumulates, at one bucket an identity: the authors longest silent go first.
    if(this.buckets.size>this.policy.identityLimit){const oldest=[...this.buckets].sort((a,b)=>a[1].at-b[1].at||(a[0]<b[0]?-1:1))[0][0];this.buckets.delete(oldest)}
    return allowed;
  }
  // A record the form needs (a theme, the opening's line): held above everything but a pinned record, whatever its use.
  // At most salientLimit; past it, the least evidenced salient record goes back to its tier.
  setSalient(motifId,reason='held for the form'){
    const entry=this.entries.get(String(motifId));
    if(!entry)return false;
    if(entry.salience===reason)return true;
    entry.salience=String(reason);this.revision++;
    const salient=[...this.entries.values()].filter(other=>other.salience);
    if(salient.length>this.policy.salientLimit){
      const at=this.now(),weakest=salient.filter(other=>other!==entry).sort((a,b)=>this.useCredit(a)+this.freshness(a,at)-(this.useCredit(b)+this.freshness(b,at))||(a.motifId<b.motifId?-1:1))[0];
      if(weakest)weakest.salience=null;
    }
    return true;
  }
  clearSalient(motifId){const entry=this.entries.get(String(motifId));if(entry?.salience){entry.salience=null;this.revision++}}
  // The order eviction reads: pinned, then held for the form, then the tiers of use.
  rank(entry){const tier=this.tier(entry);return tier===3?4:entry.salience?3:tier}
  configure(overrides={}){
    this.policy=motifRetentionPolicy({...this.policy,...overrides,
      useWeights:{...this.policy.useWeights,...(overrides.useWeights||{})}});
    this.revision++;return this.policy;
  }
  // A newly stored motif. `origin` classifies where it came from, which is the
  // only thing known before anything has used it.
  admit(motif,{origin='published',at=this.now(),actor=''}={}){
    const motifId=String(motif?.motifId??motif),
      author=String(motif?.metadata?.author??motif?.author??''),
      existing=this.entries.get(motifId);
    if(existing){
      existing.author=author||existing.author;
      if(origin==='imported')existing.origin='imported';
      existing.restoredAt=at;this.revision++;return existing;
    }
    const entry={motifId,author,origin:MOTIF_ORIGINS.includes(origin)?origin:'published',
      storedAt:at,storedBy:String(actor||author||''),lastUseAt:0,
      counts:emptyCounts(),actors:new Map,coverage:0,quoted:new Set,droppedActors:0,droppedCredit:0,tierReached:0,tokens:[]};
    this.entries.set(motifId,entry);this.revision++;return entry;
  }
  forget(motifId){this.entries.delete(String(motifId));this.revision++}
  entry(motifId){return this.entries.get(String(motifId))}
  // Accrue one piece of evidence. `token` deduplicates the repeated status
  // reports a single sustained playback sends.
  record(motifId,kind,{actor='',at=this.now(),coverage=0,noteIndices=null,token=''}={}){
    const entry=this.entries.get(String(motifId)),definition=MOTIF_USE_KINDS[kind];
    if(!entry||!definition)return null;
    if(token){
      if(entry.tokens.includes(token))return entry;
      entry.tokens.push(token);if(entry.tokens.length>32)entry.tokens.shift();
    }
    // An unauthored motif belongs to nobody, so anyone using it is another bot.
    const id=String(actor||'unknown'),foreign=id!==entry.author;
    // Credited first, trimmed after: a new actor trimmed before its use was credited was dropped at zero, and its
    // repeated uses never accumulated (the mathematical audit's M06).
    let record=entry.actors.get(id);
    if(!record){record={actor:id,foreign,counts:emptyCounts(),lastAt:at};entry.actors.set(id,record)}
    record.foreign=foreign;record.counts[kind]++;record.lastAt=at;
    entry.counts[kind]++;entry.lastUseAt=Math.max(entry.lastUseAt,at);
    const notes=Math.trunc(Number(coverage)||0);
    if(notes>entry.coverage)entry.coverage=notes;
    // Which notes, and not only how many: a view marks the fragments another
    // bot has quoted long after the playback that quoted them has ended. Only
    // foreign use counts, because a bot quoting itself is not circulation.
    if(foreign&&Array.isArray(noteIndices))for(const value of noteIndices){
      if(entry.quoted.size>=this.policy.maxQuotedNotesPerMotif)break;
      const index=Math.trunc(Number(value));
      if(Number.isFinite(index)&&index>=0)entry.quoted.add(index);
    }
    // The tier it has reached, kept apart from the records retained, so trimming them never demotes it.
    entry.tierReached=Math.max(entry.tierReached??0,this.liveTier(entry));
    this.trimActors(entry);
    this.revision++;return entry;
  }
  // An ensemble is bounded but a long session is not: keep the most credited
  // actors and count the rest, breaking ties on the actor id so two identical
  // runs drop the same one.
  trimActors(entry){
    if(entry.actors.size<=this.policy.maxActorsPerMotif)return;
    const ranked=[...entry.actors.values()].sort((left,right)=>
      this.actorCredit(entry,left)-this.actorCredit(entry,right)||(left.actor<right.actor?-1:left.actor>right.actor?1:0));
    // What a dropped actor had given still counts toward the motif's credit, as a bounded summary.
    while(entry.actors.size>this.policy.maxActorsPerMotif){const dropped=ranked.shift();
      entry.droppedCredit=(entry.droppedCredit??0)+this.actorCredit(entry,dropped);entry.actors.delete(dropped.actor);entry.droppedActors++}
  }
  actorCredit(entry,record){
    const {useWeights,foreignWeight,ownWeight,coverageFull}=this.policy,
      actorWeight=record.foreign?foreignWeight:ownWeight;
    let credit=0;
    for(const name of MOTIF_USE_NAMES){
      const count=record.counts[name];
      if(!count)continue;
      // log2 saturation: one use is worth a full weight, a run of them keeps
      // adding but with diminishing returns, so a single chatty player cannot
      // outrank material several bots have each picked up.
      const coverageBonus=name==='derived'?1+clamp(entry.coverage/coverageFull,0,1):1;
      credit+=useWeights[name]*actorWeight*coverageBonus*Math.log2(1+count);
    }
    return credit;
  }
  useCredit(entry){
    let credit=entry.droppedCredit??0;
    for(const record of entry.actors.values())credit+=this.actorCredit(entry,record);
    // Several different bots picking a motif up is stronger evidence than one
    // bot picking it up several times.
    let foreign=0;for(const record of entry.actors.values())if(record.foreign&&this.promoted(record))foreign++;
    return credit*(1+.5*Math.max(0,foreign-1));
  }
  promoted(record){return MOTIF_USE_NAMES.some(name=>MOTIF_USE_KINDS[name].promotes&&record.counts[name]>0)}
  // The bots other than the author that have actually taken a motif up, in a
  // fixed order. Three answers read this one list — the eviction tier, the
  // sentence explaining it, and whatever a view draws — so it is derived in one
  // place instead of being filtered again at each call site.
  usingActors(entry){
    return [...entry.actors.values()].filter(record=>record.foreign&&this.promoted(record))
      .sort((left,right)=>left.actor<right.actor?-1:left.actor>right.actor?1:0);
  }
  // A tier is never lost: the tier reached (tierReached) stands whatever records have since been trimmed. The tier had
  // been recomputed from the retained actors, and trimming the sole foreign one turned "shared" into "self".
  tier(entry){
    if(entry.origin==='imported')return 3;
    return Math.max(entry.tierReached??0,this.liveTier(entry));
  }
  liveTier(entry){
    if(entry.origin==='imported')return 3;
    let self=false;
    for(const record of entry.actors.values()){
      if(!this.promoted(record))continue;
      if(record.foreign)return 2;
      self=true;
    }
    return self?1:0;
  }
  // Freshness only orders records inside one tier; it never demotes a tier.
  freshness(entry,at){
    const idle=Math.max(0,at-Math.max(entry.storedAt,entry.restoredAt||0,entry.lastUseAt));
    return Math.exp(-LN2*idle/this.policy.halfLifeMs);
  }
  standing(motifId,at=this.now()){
    const entry=this.entries.get(String(motifId));
    if(!entry)return null;
    const tier=this.tier(entry),credit=this.useCredit(entry),freshness=this.freshness(entry,at);
    return {motifId:entry.motifId,author:entry.author,origin:entry.origin,tier,tierName:MOTIF_TIERS[tier],
      rank:this.rank(entry),salience:entry.salience??null,
      credit:round(credit),freshness:round(freshness),score:round(credit+freshness),
      uses:{...entry.counts},totalUses:MOTIF_USE_NAMES.reduce((total,name)=>total+entry.counts[name],0),
      usingBots:this.usingActors(entry).map(record=>record.actor),
      coverage:entry.coverage,storedAt:entry.storedAt,lastUseAt:entry.lastUseAt,droppedActors:entry.droppedActors,
      rationale:this.rationale(entry,tier)};
  }
  // What a view needs in order to signify use: whether anything other than the
  // author has come back for this motif, which bots did, what each of them did
  // with it, and which notes they quoted. standing() answers the eviction
  // question and spends a score and a sentence doing it; a library grid asks
  // this narrower one about every clip on screen, several times a second.
  // `self` is an id to leave out of `users`: the library's own bot, previewing
  // a clip for whoever is watching. Eviction counts that as use by another bot
  // whenever the author is someone else — an imported file, say — and for
  // keeping material that is right; but on screen it would claim the ensemble
  // had taken up a clip the person at the controls had merely listened to.
  usage(motifId,{self=''}={}){
    const entry=this.entries.get(String(motifId));
    if(!entry)return null;
    const tier=this.tier(entry);
    return {motifId:entry.motifId,author:entry.author,origin:entry.origin,tier,tierName:MOTIF_TIERS[tier],
      users:this.usingActors(entry).filter(record=>record.actor!==String(self))
        .map(record=>({actor:record.actor,lastAt:record.lastAt,
          uses:MOTIF_USE_NAMES.reduce((total,name)=>total+record.counts[name],0),
          kinds:MOTIF_USE_NAMES.filter(name=>MOTIF_USE_KINDS[name].promotes&&record.counts[name]>0)})),
      // Its author coming back to it is real use, and it is not circulation.
      ownUse:[...entry.actors.values()].some(record=>!record.foreign&&this.promoted(record)),
      offered:entry.counts.offered,coverage:entry.coverage,
      quotedNotes:[...entry.quoted].sort((left,right)=>left-right),
      lastUseAt:entry.lastUseAt,droppedActors:entry.droppedActors};
  }
  rationale(entry,tier=this.tier(entry)){
    const using=this.usingActors(entry).map(record=>record.actor);
    const played=entry.counts.replayed+entry.counts.derived;
    if(tier===3)return `Imported by hand${entry.author?` as ${entry.author}`:''}; held until a human removes it.`;
    if(entry.salience)return `Held for the form (${entry.salience}), above everything but a pinned record.`;
    if(tier===2)return `Used by ${using.length} other ${using.length===1?'bot':'bots'} (${using.join(', ')}): `
      +`${played} playback report${played===1?'':'s'}, ${entry.counts.retrieved} direct retrieval${entry.counts.retrieved===1?'':'s'}, `
      +`${entry.counts.developed} development${entry.counts.developed===1?'':'s'}.`;
    if(tier===1)return `Only ${entry.author||'its author'} has come back to it: ${played} playback report${played===1?'':'s'}. `
      +'Kept above unused capture, released before anything other bots use.';
    return entry.origin==='passagework'
      ?`Captured passagework no bot has used; offered ${entry.counts.offered} time${entry.counts.offered===1?'':'s'} without being taken up.`
      :`Stored but never used; offered ${entry.counts.offered} time${entry.counts.offered===1?'':'s'}.`;
  }
  // Numeric eviction keys avoid explanations and actor-id sorting for every candidate.
  // `rank` orders them: the tier of use, with a record held for the form above all but pinned ones.
  evictionKey(motifId,at=this.now()){
    const entry=this.entries.get(String(motifId));
    return {motifId:String(motifId),tier:entry?this.tier(entry):0,rank:entry?this.rank(entry):0,
      score:entry?round(this.useCredit(entry)+this.freshness(entry,at)):0};
  }
  evictionKeys(ids,at=this.now()){
    return [...ids].map(id=>this.evictionKey(id,at)).sort((a,b)=>a.rank-b.rank||a.score-b.score||
      (a.motifId<b.motifId?-1:a.motifId>b.motifId?1:0));
  }
  evictionVictim(ids,at=this.now()){
    let best=null;for(const id of ids){const key=this.evictionKey(id,at);
      if(!best||key.rank<best.rank||key.rank===best.rank&&(key.score<best.score||key.score===best.score&&key.motifId<best.motifId))best=key}
    return best;
  }
  // Worst first. Rank, then score, then motifId — no insertion order anywhere,
  // so the same message sequence always culls the same records.
  evictionOrder(ids,at=this.now()){
    return [...ids].map(id=>this.standing(id,at)??
        {motifId:String(id),tier:0,rank:0,credit:0,freshness:0,score:0,uses:emptyCounts(),rationale:'No retention record; treated as unused.'})
      .sort((left,right)=>left.rank-right.rank||left.score-right.score||
        (left.motifId<right.motifId?-1:left.motifId>right.motifId?1:0));
  }
  // Called by the store once a record has actually been dropped.
  evict(motifId,reason='capacity',at=this.now()){
    const standing=this.standing(motifId,at);
    this.forget(motifId);
    const record={...(standing||{motifId:String(motifId)}),verdict:'culled',reason,at,
      rationale:standing?`Culled (${reason}) at tier ${standing.tierName}: ${standing.rationale}`:`Culled (${reason}).`};
    this.evictions.push(record);
    while(this.evictions.length>this.policy.evictionLogLimit)this.evictions.shift();
    return record;
  }
  // The whole ledger: per-motif use counts, the score, and why each record
  // survived or died. usage() is the narrower answer a library grid draws from.
  // This module draws nothing.
  report(ids=[...this.entries.keys()],at=this.now()){
    const motifs=this.evictionOrder(ids,at).map(standing=>({...standing,verdict:'retained'})).reverse(),
      tiers=Object.fromEntries(MOTIF_TIERS.map(name=>[name,0]));
    for(const motif of motifs)tiers[motif.tierName]++;
    return {policy:this.policy,revision:this.revision,at,tiers,
      tracked:this.entries.size,motifs,evicted:this.evictions.slice().reverse()};
  }
}

// ---- Identities across seconds (the extreme-aesthetics report's §5.3, E20) ------------------------------------------

// A motive's identity, kept apart from its record: its author, its notes (their pitches to the cent) and its rhythm
// (the fingerprint's onsets), so that neither its controllers nor its articulation make it a new thing, while the same
// shape at another pitch does: a transposition is a development, not a recurrence. With it, its family, how often it
// has been heard, and when first and last, on both clocks: score coordinates (beats) for its relations, elapsed time
// for recency, neither replacing the other. An identity outlives its record's events, so a motive that returns after
// the store has let the record go is known as the one heard before. Bounded: past identityLimit, the least heard of
// those whose records are gone go first, then the longest unheard. `notes`: the motif's notes (motifs.js motifNotes).
export function identityKey(motif,notes){
  const pitches=(Array.isArray(notes)?notes:[]).map(note=>(Array.isArray(note?.pitches)?note.pitches:[note?.pitch]).map(Number)
    .filter(Number.isFinite).map(pitch=>Math.round(pitch*100)/100)).filter(chord=>chord.length);
  if(pitches.length<2)return null;
  return `${String(motif?.metadata?.author??motif?.author??'')}|${JSON.stringify(pitches)}|${JSON.stringify(motif?.fingerprint?.onsetRatios??[])}`;
}
export class MotifIdentities{
  constructor({limit=MOTIF_RETENTION_DEFAULTS.identityLimit}={}){this.limit=positiveInteger(limit,'identityLimit');this.identities=new Map}
  get(key){return key?this.identities.get(key)??null:null}
  // A record stored under `key`: a new identity, or a known one taking the new record.
  describe(motif,key,{family,at,beats=null}={}){
    if(!key)return null;
    const known=this.identities.get(key);
    if(known){known.motifId=motif.motifId;known.exposure++;known.lastHeardAt=at;known.lastHeardBeats=beats;known.returns++;return known}
    const identity={key,motifId:motif.motifId,author:String(motif.metadata?.author??''),family:String(family??motif.motifId),
      exposure:1,returns:0,firstHeardAt:at,lastHeardAt:at,firstHeardBeats:beats,lastHeardBeats:beats};
    this.identities.set(key,identity);this.trim(motif.motifId);
    return identity;
  }
  // Heard again with its record still held: exposure, not a record.
  heard(key,{at,beats=null}={}){
    const identity=this.identities.get(key);if(!identity)return null;
    identity.exposure++;identity.lastHeardAt=at;identity.lastHeardBeats=beats;return identity;
  }
  trim(keep,live=()=>false){
    if(this.identities.size<=this.limit)return;
    const ranked=[...this.identities.values()].filter(identity=>identity.motifId!==keep)
      .sort((a,b)=>Number(live(a))-Number(live(b))||a.exposure-b.exposure||a.lastHeardAt-b.lastHeardAt||(a.key<b.key?-1:1));
    while(this.identities.size>this.limit&&ranked.length)this.identities.delete(ranked.shift().key);
  }
  report(){return [...this.identities.values()].sort((a,b)=>b.exposure-a.exposure||(a.key<b.key?-1:1)).map(identity=>({...identity}))}
}
