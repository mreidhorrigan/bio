// Only the WAN envelope is new. Payloads are original protocol/OSC/UMP bytes.
// All lengths and numeric frame fields are unsigned, big endian. See
// research/multinet-protocol.md. This module runs unchanged in Node and browsers.
export const WIRE_VERSION = 1;
export const LIFECYCLE_EXTENSION = 'lifecycle-v1';
export const INVITATION_EXTENSION = 'invitations-v1';
export const WIRE_LIMITS = Object.freeze({
  frameBytes: 262144, records: 64, metadataBytes: 4096,
  payloadBytes: 65536, controlBytes: 4096, recipients: 8,
});
const MAGIC = 0x4d424e54; // MBNT
const encoder = new TextEncoder(), decoder = new TextDecoder('utf-8', {fatal: true});
const kinds = new Set(['protocol', 'clock', 'control', 'bulk']);
const codecs = new Set(['json', 'osc', 'ump', 'opaque']);
export function wireId(value, name = 'identity') {
  if (typeof value !== 'string' || !/^[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}$/.test(value))
    throw new TypeError(`Invalid ${name}`);
  return value;
}
export function qualifyBot(host, bot) { return `${wireId(host, 'host')}::${wireId(bot, 'bot')}`; }
export function byteView(value) {
  if (value instanceof Uint8Array) return value;
  if (value instanceof ArrayBuffer) return new Uint8Array(value);
  if (ArrayBuffer.isView(value)) return new Uint8Array(value.buffer, value.byteOffset, value.byteLength);
  throw new TypeError('Binary payload required');
}
export function jsonBytes(value) { return encoder.encode(JSON.stringify(value)); }
export function readJsonBytes(value, limit = WIRE_LIMITS.payloadBytes) {
  const bytes = byteView(value);
  if (bytes.byteLength > limit) throw new RangeError('JSON payload exceeds limit');
  return JSON.parse(decoder.decode(bytes));
}
export function validateEnvelope(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new TypeError('Envelope required');
  const {room, host, incarnation, bot, seq, kind, codec} = value;
  for (const [name, id] of Object.entries({room, host, incarnation, bot})) wireId(id, name);
  if (!Number.isSafeInteger(seq) || seq < 1) throw new TypeError('Invalid sequence');
  if (!kinds.has(kind) || !codecs.has(codec)) throw new TypeError('Unsupported required envelope semantics');
  const to = value.to ?? [];
  if (!Array.isArray(to) || to.length > WIRE_LIMITS.recipients || new Set(to).size !== to.length)
    throw new TypeError('Invalid recipients');
  to.forEach(id => wireId(id, 'recipient'));
  // Do not reinterpret a remote monotonic timestamp as this process's clock.
  // This is a maximum *local queue residence* budget, not an end-to-end promise.
  const ttlMs = value.ttlMs ?? 250;
  if (!Number.isFinite(ttlMs) || ttlMs < 1 || ttlMs > 5000) throw new TypeError('Invalid queue TTL');
  const allowed = new Set(['room', 'host', 'incarnation', 'bot', 'seq', 'kind', 'codec', 'to', 'ttlMs']);
  if (Object.keys(value).some(key => !allowed.has(key))) throw new TypeError('Unknown required envelope field');
  return {room, host, incarnation, bot, seq, kind, codec, to: [...to], ttlMs};
}
export function encodeBatch(records) {
  if (!Array.isArray(records) || !records.length || records.length > WIRE_LIMITS.records)
    throw new RangeError('Invalid batch record count');
  let size = 8;
  const parts = records.map(({envelope, payload}) => {
    const clean = validateEnvelope(envelope), metadata = jsonBytes(clean), bytes = byteView(payload);
    if (metadata.length > WIRE_LIMITS.metadataBytes || bytes.length > WIRE_LIMITS.payloadBytes ||
        (['clock', 'control'].includes(clean.kind) && bytes.length > WIRE_LIMITS.controlBytes))
      throw new RangeError('Record exceeds limit');
    size += 8 + metadata.length + bytes.length;
    if (size > WIRE_LIMITS.frameBytes) throw new RangeError('Frame exceeds limit');
    return {metadata, bytes};
  });
  const out = new Uint8Array(size), view = new DataView(out.buffer);
  view.setUint32(0, MAGIC); view.setUint16(4, WIRE_VERSION); view.setUint16(6, parts.length);
  let offset = 8;
  for (const {metadata, bytes} of parts) {
    view.setUint32(offset, metadata.length); view.setUint32(offset + 4, bytes.length); offset += 8;
    out.set(metadata, offset); offset += metadata.length;
    out.set(bytes, offset); offset += bytes.length;
  }
  return out;
}
export function decodeBatch(input) {
  const bytes = byteView(input);
  if (bytes.length < 8 || bytes.length > WIRE_LIMITS.frameBytes) throw new RangeError('Invalid frame size');
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  if (view.getUint32(0) !== MAGIC || view.getUint16(4) !== WIRE_VERSION)
    throw new TypeError('Unsupported wire version');
  const count = view.getUint16(6);
  if (!count || count > WIRE_LIMITS.records) throw new RangeError('Invalid record count');
  let offset = 8;
  const records = [];
  for (let i = 0; i < count; i++) {
    if (offset + 8 > bytes.length) throw new RangeError('Truncated record header');
    const m = view.getUint32(offset), n = view.getUint32(offset + 4); offset += 8;
    if (!m || m > WIRE_LIMITS.metadataBytes || n > WIRE_LIMITS.payloadBytes || offset + m + n > bytes.length)
      throw new RangeError('Invalid record length');
    const envelope = validateEnvelope(readJsonBytes(bytes.subarray(offset, offset + m), WIRE_LIMITS.metadataBytes));
    offset += m;
    if (['clock', 'control'].includes(envelope.kind) && n > WIRE_LIMITS.controlBytes)
      throw new RangeError('Control record exceeds limit');
    records.push({envelope, payload: bytes.slice(offset, offset + n)}); offset += n;
  }
  if (offset !== bytes.length) throw new RangeError('Trailing frame bytes');
  return records;
}

// A sliding window rejects duplicates AND arbitrarily old sequences, without
// forgetting old admission merely because a bounded LRU filled up. Reordering
// inside the retained window is permitted. Different identical notes have
// different sequence identities and are never deduplicated by payload hash.
export class SequenceWindow {
  constructor(width = 4096) { this.width = width; this.high = 0; this.seen = new Set(); }
  accept(sequence) {
    if (!Number.isSafeInteger(sequence) || sequence < 1 || sequence <= this.high - this.width || this.seen.has(sequence)) return false;
    this.high = Math.max(this.high, sequence); this.seen.add(sequence);
    for (const old of this.seen) if (old <= this.high - this.width) this.seen.delete(old);
    return true;
  }
  snapshot() { return {high: this.high, seen: [...this.seen].sort((a,b) => a-b)}; }
  restore({high, seen}) {
    if (!Number.isSafeInteger(high) || high < 0 || !Array.isArray(seen) || seen.length > this.width ||
      seen.some(x => !Number.isSafeInteger(x) || x < 1 || x > high || x <= high - this.width))
      throw new TypeError('Invalid sequence checkpoint');
    this.high = high; this.seen = new Set(seen);
  }
}
