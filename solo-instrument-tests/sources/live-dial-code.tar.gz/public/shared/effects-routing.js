// Another bot's audio through an effects bot's chain (the second queue's "Shared audio routing"). ae_effectsBOT's
// original ran live input (`adc~`) through ten AudioUnit effects, a ring modulator and allpass reverbs
// (research/native-audio-bots-design.md); its browser port only sounds a monitor note. effects_clodbot does the
// original's work on the ensemble's own parts: it says, to whoever mixes (a render's session, the page), which part it
// processes and how, and the mixer sends that part, after its fader, into the effects bot's own channel, where the chain
// is. The part plays on as it was; the effect is added beside it, as the original's was beside the player in the room.
//
// A request, at EFFECTS_ADDRESS:
//   {source: a channel, a role ('lead', 'pad') or a bot's id, as the desk names channels; send: 0-1, how much of it the
//    chain hears; drive: {amount 0-1, tone Hz}; tone: {lowHz, highHz} (the chain's band, a high-pass and a low-pass);
//    chorus: {rateHz, depthMs}; delay, reverb: 0-1, the chain's own sends to the ensemble's delay and reverb;
//    glideSeconds: how long the chain takes to get there}.
// Each field is optional; one not said is left as it is.
import {driveSmallSignalGain} from '../insert-chain.js';

// ---- Choices ---------------------------------------------------------------------------------------------------------
export const EFFECTS_ADDRESS='/agent/effects';
export const EFFECTS=Object.freeze({
  // The chain on the effects bot's channel, in order: the original's AUDistortion, the drive's own input gain taken back
  // after it (so a quiet part comes out as loud as it went in, and a loud one pressed), its band (the AU presets'
  // filters), and AUPitch's and AUNewTimePitch's movement as a chorus; its AUDelay and ChamberVerb are the channel's
  // sends to the ensemble's delay and reverb.
  chain:Object.freeze(['drive','gain','eq','chorus']),
  // The bands' ends (the channel EQ's high-pass and low-pass), and the chorus's widest movement (ours).
  lowestHz:20,highestHz:20000,mostDepthMs:12,
});
const unit=value=>Math.max(0,Math.min(1,Number(value)));
const finite=value=>Number.isFinite(Number(value));

// A request made safe: unknown fields refused, numbers bounded.
export function effectsRequest(value={}){
  const known=['source','send','drive','tone','chorus','delay','reverb','glideSeconds'];
  for(const key of Object.keys(value??{}))if(!known.includes(key))throw new RangeError(`no effects field ${key}: ${known.join(', ')}`);
  const out={};
  if(value.source!==undefined){if(typeof value.source!=='string'||!value.source)throw new TypeError('an effects source is a channel, a role or a bot');out.source=value.source}
  for(const key of ['send','delay','reverb'])if(value[key]!==undefined){if(!finite(value[key]))throw new RangeError(`${key}: from 0 to 1`);out[key]=unit(value[key])}
  if(value.drive){out.drive={};if(finite(value.drive.amount))out.drive.amount=unit(value.drive.amount);if(finite(value.drive.tone))out.drive.tone=Math.max(200,Math.min(18000,Number(value.drive.tone)))}
  if(value.tone){out.tone={};for(const key of ['lowHz','highHz'])if(finite(value.tone[key]))out.tone[key]=Math.max(EFFECTS.lowestHz,Math.min(EFFECTS.highestHz,Number(value.tone[key])))}
  if(value.chorus){out.chorus={};if(finite(value.chorus.rateHz))out.chorus.rateHz=Math.max(0,Math.min(12,Number(value.chorus.rateHz)));if(finite(value.chorus.depthMs))out.chorus.depthMs=Math.max(0,Math.min(EFFECTS.mostDepthMs,Number(value.chorus.depthMs)))}
  if(finite(value.glideSeconds))out.glideSeconds=Math.max(0,Math.min(30,Number(value.glideSeconds)));
  return Object.freeze(out);
}

// The channels a name means in a mixer: that channel, every channel of that role, or every channel of that bot
// (bot:<id>:<key>), as the desk resolves a masking permission's names (live-desk.js channelsNamed).
export function channelsNamed(mixer,name){
  if(mixer.tracks.has(name))return [name];
  return [...mixer.tracks].filter(([id,track])=>!track.bus&&(track.role===name||String(id).startsWith(`bot:${name}:`))).map(([id])=>id);
}

// A request applied to a mixer: the chain built on the effects bot's channel (`effectsId`) the first time, each source
// channel sending to it, the chain's settings and sends moved over the glide from `atSeconds`. `state` keeps what was
// built for each effects channel (a Map the caller holds); `channelsFor(name)` resolves a source where the host names
// its channels otherwise (the page's are its bots' instances). Returns {effectsId, sources, built}.
export async function applyEffects(mixer,{effectsId,request,atSeconds=mixer.context.currentTime,state=new Map,channelsFor=name=>channelsNamed(mixer,name)}={}){
  const said=effectsRequest(request),track=mixer.tracks.get(effectsId);
  if(!track)throw new Error(`no channel ${effectsId} for the effects`);
  let held=state.get(effectsId),built=false;
  if(!held){
    held={inserts:{},sources:new Set,send:0};state.set(effectsId,held);built=true;
    for(const kind of EFFECTS.chain){
      const options=kind==='drive'?{amount:0,tone:12000}:kind==='chorus'?{rateHz:.5,depthMs:0,delayMs:14}:{};
      const insertId=await track.addInsert(kind,options);held.inserts[kind]=track.inserts.get?.(insertId)?.processor??null;
    }
  }
  const seconds=said.glideSeconds??.05;
  if(said.source){
    const sources=channelsFor(said.source).filter(id=>id!==effectsId&&mixer.tracks.has(id));
    for(const id of held.sources)if(!sources.includes(id))mixer.tracks.get(id)?.sendTo?.(effectsId,0,{seconds,atSeconds});
    held.sources=new Set(sources);
  }
  if(said.send!==undefined)held.send=said.send;
  for(const id of held.sources)mixer.tracks.get(id)?.sendTo(effectsId,held.send,{seconds,atSeconds});
  if(said.drive){
    held.inserts.drive?.set?.(said.drive);
    // The drive's gain on a quiet signal (insert-chain.js driveSmallSignalGain), taken back after it.
    if(said.drive.amount!==undefined)held.inserts.gain?.set?.({gain:1/driveSmallSignalGain(said.drive.amount)});
  }
  // The band's ends as the channel EQ's pass filters: a frequency of 0 turns one off (insert-chain.js channelEq).
  if(said.tone)held.inserts.eq?.set?.({...(said.tone.lowHz!==undefined?{highpass:{hz:said.tone.lowHz>EFFECTS.lowestHz?said.tone.lowHz:0}}:{}),
    ...(said.tone.highHz!==undefined?{lowpass:{hz:said.tone.highHz<EFFECTS.highestHz?said.tone.highHz:0}}:{})},{atSeconds,seconds});
  if(said.chorus)held.inserts.chorus?.set?.(said.chorus);
  const sends={};if(said.delay!==undefined)sends.delay=said.delay;if(said.reverb!==undefined)sends.reverb=said.reverb;
  if(Object.keys(sends).length)track.set(sends,{seconds,atSeconds});
  return {effectsId,sources:[...held.sources],built};
}
