// The numbers a share link (link-codec.js, version 3) writes for bots, mixer settings and effect settings, in place of
// their names. A link made today must open the same bots whenever it is opened, so these lists only grow: a new bot or
// setting is appended, and nothing is removed, renamed or moved (an entry no longer used stays, as a protocol buffer's
// retired field number does). A name not listed still goes into a link, spelt out, only longer.
// test/compact-links.test.mjs checks that every registered bot and every setting is listed, and that the lists as they
// were first written are unchanged.
export const LINK_BOT_IDS=Object.freeze([
  'conductor','modal','miles','swingChord','methenyChord','mozartChord','bowed','drone','pad','newDrone','mhDrone',
  'sequencer','papMelody2','laverne','resynth','papMelody','papMelody4','dampPiano','counterpoint','ornament',
  'msynth','rsynth','multiSynth','reichGuitar','methenyMelody','seasonsArpy','seasonsBrokenChord','seasonsChord',
  'seasonsDrone','seasonsSussy','vinyl','sweeper','fmTexture','tonic','wind','bleep','whiny','groan','wub',
  'atmosphere','texture','granu','chichichi','derivations','decider','blank','monitorMessages','reassignMessages',
  'valenceArousal','midiAnalyzer','midiBot','midiGuitarInput','video','webBot','serverBot','templateBot','xProducer',
  'xChord','xDrum','xdrum_clodbot','xBass','xPad','xPerc','xSequencer','tangerineDream','walkingBass',
  'walkingbass_clodbot','romantic_clodbot','impressionist_clodbot','jazzvoicing_clodbot','hindemith_clodbot',
  'interlockdrum_clodbot','riff_clodbot','motifprofiler_clodbot','eBass','snapBass','synthBass','splatterBass',
  'rhodes','beat','jazzBeat','cleanBeat','clumpyBeat','noiseBeat','newBeat','houseBeat','perc','papPerc','mhBeat',
  'mhBeatsynth','sampleBeat','autechre','prockRock','rungler','analyzer','effects','memory','harmonyPulse','contour',
  'space','plex','form','tune','coord','manage','granular','midiInput','listener','response','profiler',
  // Added since the list was first written.
  'form_clodbot','riffmotif_clodbot','harris_clodbot','meterform_clodbot','feedback_clodbot','papperc_clodbot','edit_clodbot','formant_clodbot','clodbot_singerbot','clodbot_singerbot_en','ornament_clodbot','msynth_clodbot','rsynth_clodbot','multisynth_clodbot','reichguitar_clodbot','methenymelody_clodbot','autechre_clodbot','wind_clodbot','atmosphere_clodbot','texture_clodbot','granu_clodbot','derivations_clodbot','seasonsbrokenchord_clodbot','seasonsdrone_clodbot',
  // Forks of ported bots with the audit's other findings (27 September 2026), one a line.
  'mhdrone_clodbot',
  'xbass_clodbot',
  'newbeat_clodbot',
  'chichichi_clodbot',
  'valencearousal_clodbot',
  'drone_clodbot',
  'tangerinedream_clodbot',
  'atonal_clodbot',
  'mirror_clodbot',
  'vivier_clodbot',
  'polyscalar_clodbot',
  'powerloop_clodbot',
  'modalline_clodbot',
  'papmelody_clodbot','effects_clodbot','audioanalyzer_clodbot','harmonypulse_clodbot','meterspace_clodbot','bowedstring_clodbot','piano_clodbot','flute_clodbot','tunespace_clodbot','harmonyspace_clodbot','guitar_clodbot','languagespace_clodbot','mass_clodbot','stylespace_clodbot','mallets_clodbot','kalimba_clodbot','steelpan_clodbot','timeline_clodbot','shaker_clodbot','conguero_clodbot','timpani_clodbot','gong_clodbot','talkingdrum_clodbot','harp_clodbot','accordion_clodbot','harpsichord_clodbot','strings_clodbot','plex_clodbot','manage_clodbot','profile_clodbot',
  'acousmatic_clodbot',
  'woodwind_clodbot','brass_clodbot','battery_clodbot',
]);
export const LINK_MIX_KEYS=Object.freeze([
  'dry','pan','reverb','delay','compression','plugin','drive','chorus','room'
]);
export const LINK_EFFECT_KEYS=Object.freeze([
  'reverbSeconds','reverbTone','reverbReturn','delayBeats','delayFeedback','delayTone','delayReturn',
  'compressionThreshold','compressionRatio','compressionAttack','compressionRelease','compressionReturn',
  'driveAmount','driveTone','driveReturn','chorusRateHz','chorusDepthMs','chorusDelayMs','chorusReturn','reverbType',
  'reverbPredelayMs','reverbBassRatio','reverbTrebleRatio','reverbLowCut','reverbWidth','roomType','roomSeconds',
  'roomPredelayMs','roomTone','roomReturn','delayMode','delayMs','delayLowCut','driveType','compressionMode',
  'compressionKnee','compressionMakeup','limiterCeiling',
  // Added since the list was first written.
  'mixFeedback','mixFeedbackDrive','mixFeedbackDriveAmount','mixFeedbackDelayMs','mixFeedbackBandHz','mixFeedbackBandDb','mixFeedbackBandQ',
  'mixFeedbackRoughness'
]);
