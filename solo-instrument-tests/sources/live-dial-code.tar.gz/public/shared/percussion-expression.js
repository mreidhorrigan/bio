// What a drum stroke is beyond how hard it lands, and what that does to the sound, whichever voice plays it.
//
// A drummer's expressive means are not velocity alone. The same drum is struck at its centre or out towards its edge, on
// its head or on head and rim together (a rimshot), with the stick laid across it (a cross stick), pressed into a buzz;
// a hi-hat stands anywhere from shut to wide open, is struck on its top with the tip or on its edge with the shank, or
// is closed with the foot; a ride is played on its bow, its bell or its edge; a hand stops a drum or lets it ring; a
// drum is tuned. The Groove MIDI Dataset shows ten drummers using all of these all the time (MEASURED below): in the
// median take a sixth of the snare strokes are ghost notes at a third of the backbeat, a sixth of the snare strokes are
// rimshots, the hat's edge carries the beats and its tip the offbeats, and an open hat is closed again about an
// eighth later.
//
// A stroke here is a strike: {stroke, position, openness, damping, tuning, tuneTo, pressure}, every field optional. It becomes a
// tone: a change of level, brightness, ring, noise and pitch against the piece as it sounds unstruck by any of this --
// so a hit that names none of it sounds exactly as it always has. The kit's own synthesized voices take the tone as the
// overrides of their shapes (strikeShape: articulation.js's slots), a sampled kit as its layer, filter, rate and
// envelope (synths/drum-kit.js), and MIDI 2 as per-note controllers and the stroke's General MIDI note (#74 brightness,
// #71 timbre as the strike position, the Pitch 7.9 attribute for a tuned drum).
//
// Pure functions and plain data, as articulation.js is: the Max for Live runtime and the renderers import this.
// research/percussion-expression-references.md has every source; the numbers without one are ours and say so.

// ---- where a membrane is struck -------------------------------------------------------------------------------------
//
// A point strike excites each mode of a membrane in proportion to the mode's displacement where it lands (Fletcher &
// Rossing 1998, ch. 3 and 18): at the centre only the axisymmetric modes answer, and towards the rim the lowest mode's
// share falls away while the modes with nodal diameters take over. For the ideal membrane the lowest mode's amplitude
// goes as J0(2.405 r/a): against a stroke a third of the way out (POSITION_REFERENCE, the full-bodied stroke), the
// centre has 1.2 dB more body and nine tenths of the way out 16.5 dB less. The spectral centroid of the first fourteen
// modes rises by about 0.4 octaves from centre to edge (our fit, BRIGHTNESS_PER_POSITION; the truncated sum is not
// monotone point by point, and the fit is taken through its ends). Position is r/a, 0 the centre and 1 the rim.
export const POSITION_REFERENCE=0.3;
const BRIGHTNESS_PER_POSITION=0.43; // octaves of the voice's filter per unit of r/a
const BODY_FLOOR_DB=-18; // ours: the stroke still sounds the drum, a rim-side hit keeping some body in its first mode
const J01=2.404826,J11=3.831706; // the first zeros of J0 and J1
// The (1,1) mode stands J11/J01 = 1.594 times above the (0,1): a hand drum's bass stroke, a palm in the centre, sounds
// the lowest mode that its open stroke at the edge leaves to the ones above.
export const BASS_STROKE_SEMITONES=-12*Math.log2(J11/J01);

// ---- the drummers, measured ------------------------------------------------------------------------------------------
//
// From the Groove MIDI Dataset v1.0.0's train split (897 takes, 358,290 strokes; Gillick, Roberts, Engel, Eck & Bamman
// 2019, doi:10.48550/arXiv.1905.06118, CC BY 4.0), by scripts/measure-drum-expression.mjs on 25 September 2026; the
// validation split's figures are beside them where they differ (research/derived/drum-expression-gmd-*.json).
// Velocities relative to the take's median for that instrument; "places" are the beat (beat1..beat4) and the
// sixteenths (e, and, a) and triplet eighths (trip1, trip2) within it, in 4/4 grooves.
export const MEASURED=Object.freeze({
  source:'Groove MIDI Dataset v1.0.0, train split (scripts/measure-drum-expression.mjs, 2026-09-25)',
  // The median velocity at each place, over the take's median for the instrument.
  accents:Object.freeze({
    kick:Object.freeze({beat1:1.144,beat2:1.026,beat3:1.052,beat4:1.060,e:.839,and:1.018,a:.879,trip1:.905,trip2:.784}),
    snare:Object.freeze({beat1:1,beat2:1.063,beat3:1,beat4:1.104,e:.906,and:1.043,a:.974,trip1:.756,trip2:.951}),
    hat:Object.freeze({beat1:1.211,beat2:1.296,beat3:1.081,beat4:1.296,e:.778,and:.977,a:.837,trip1:.796,trip2:.930}),
    ride:Object.freeze({beat1:1.038,beat2:1.177,beat3:1,beat4:1.132,e:.890,and:.957,a:.857,trip1:.904,trip2:.946}),
    tom:Object.freeze({beat1:1.088,beat2:1.048,beat3:1.103,beat4:1.041,e:.943,and:1,a:.891,trip1:.947,trip2:1}),
  }),
  // How much velocity varies among strokes a drummer means alike (one take, instrument and place): the median
  // coefficient of variation. The snare's weak places mix ghosts and accents, so its backbeats (0.13-0.16) are the
  // figure for a stroke repeated.
  spread:Object.freeze({
    kick:Object.freeze({beat:.18,off:.21}),snare:Object.freeze({beat:.14,off:.14}),
    hat:Object.freeze({beat:.20,off:.37}),ride:Object.freeze({beat:.20,off:.26}),tom:Object.freeze({beat:.20,off:.24}),
  }),
  // Ghost notes: snare strokes under half the take's backbeat. A median take has 17% of its snare strokes ghosts
  // (validation 13%), at 0.32 of the backbeat (validation 0.34; quartiles 0.25-0.38), mostly on the e, the a and the
  // first triplet.
  ghost:Object.freeze({share:.17,overBackbeat:.32,places:Object.freeze(['e','a','trip1','and'])}),
  // Which part of each instrument is struck, and how hard against the instrument's median.
  parts:Object.freeze({
    snare:Object.freeze({head:.767,rim:.162,crossStick:.071}),
    hat:Object.freeze({tip:.445,shank:.555}),
    ride:Object.freeze({bow:.852,bell:.107,edge:.042}),
  }),
  partVelocity:Object.freeze({snareRim:1.53,snareHead:.93,snareCrossStick:1.12,hatTip:.76,hatShank:1.16,rideBell:1.07}),
  // Rimshots fall on the backbeats and the eighth between them: beat 2 20%, beat 4 19%, the "and" 24%.
  rimPlaces:Object.freeze({beat2:.199,beat4:.186,and:.245,a:.109,e:.088}),
  // How far open the hi-hat is when struck open (1 minus the TD-11's pedal over its closed value, 90): wide open for
  // 35-46% of open strokes, the rest spread down to barely open. It is closed again a median 0.46 beats later
  // (validation 0.48; quartiles 0.16-0.95).
  openHat:Object.freeze({wideOpenShare:.40,openness:Object.freeze({p25:.19,p50:.66,p75:1}),closedAfterBeats:.46}),
  // Flams: the grace note a median 26 ms before its stroke (quartiles 18-33) at 0.64 of its velocity (0.48-0.81), ten
  // in every thousand snare strokes. Rolls (four or more strokes under 90 ms apart): a median 52 ms apart.
  flam:Object.freeze({seconds:.026,graceOverMain:.64,perStroke:.010}),
  roll:Object.freeze({seconds:.052}),
});
// The places in a beat the measurements name, as fractions of it; the bar's beats by their index.
const PLACES_IN_BEAT=Object.freeze([[1/2,'and'],[1/4,'e'],[3/4,'a'],[1/3,'trip1'],[2/3,'trip2']]),PLACE_TOLERANCE=1e-6;
const BEAT_PLACES=Object.freeze(['beat1','beat2','beat3','beat4']);

// ---- the pieces and their strokes ------------------------------------------------------------------------------------
//
// Each piece: its strokes, each with the General MIDI note a drum module plays for it and the tone it has (levelDb,
// brightness in octaves, decay and noise as factors, pitch in semitones, attack as a factor); the stroke a hit is
// without one; and for membranes, the position a stroke has when it names none (the reference, so nothing changes).
// Tones are ours unless a comment names a measurement: a rimshot is the head and the rim at once, louder and cracking,
// a cross stick the stick's shoulder on the rim with the tip resting on the head, a buzz the stick pressed so it
// bounces on the head; a hat's shank strikes its edge and sounds fuller than its tip on the top; a ride's bell is a
// pitched ping with little wash, its edge the wash itself.
export const PIECES=Object.freeze({
  kick:{membrane:true,defaultStroke:'head',strokes:{head:{note:36}}},
  snare:{membrane:true,defaultStroke:'head',strokes:{
    head:{note:38},
    rim:{note:40,levelDb:4,brightness:.9,decay:1.2,noise:1.7,attack:.6},
    crossStick:{note:37,levelDb:-5,brightness:.7,decay:.3,noise:.15,pitch:12,wires:.1},
    buzz:{note:38,levelDb:-4,brightness:.2,decay:2.2,noise:1.2,attack:3,wires:1.6},
    // A roll held for its note's length (an orchestral snare drum's, its recording where a kit has one: synths/drum-kit.js).
    roll:{note:38,levelDb:-3,brightness:.1,decay:3,noise:1.6,attack:2.5,wires:1.5},
  }},
  tom:{membrane:true,defaultStroke:'head',strokes:{head:{note:45},rim:{note:45,levelDb:3,brightness:.8,decay:1.1,noise:1.8,attack:.6}}},
  // Hand drums: the open tone struck at the edge with the fingers, a slap cupped at the edge, the bass a palm in the
  // centre (the lowest mode: BASS_STROKE_SEMITONES), a muted stroke held down against the head. Each keeps its drum's
  // note, but a muted high conga has its own (MUTED_CONGA_NOTES). And the time a tumbao keeps (conga.js): the heel of
  // the hand rocked onto the head's centre, a low thud the hand damps, and the fingertips' tip at the edge, damped too
  // (ours: quieter than a muted stroke, as filler is).
  conga:{membrane:true,defaultStroke:'open',strokes:{
    open:{},slap:{levelDb:2,brightness:1.2,decay:.45,noise:2.2,pitch:1},
    mute:{levelDb:-4,brightness:-.3,decay:.3,noise:1.1},bass:{levelDb:1,brightness:-1,decay:.7,noise:.6,pitch:BASS_STROKE_SEMITONES,position:0},
    heel:{levelDb:-8,brightness:-.8,decay:.25,noise:.5,position:0},tip:{levelDb:-9,brightness:-.2,decay:.2,noise:.9},
  }},
  hat:{membrane:false,defaultStroke:'tip',strokes:{
    tip:{note:42},shank:{note:42,levelDb:1.3,brightness:-.25,decay:1.1,noise:1.2},
    pedal:{note:44,levelDb:-7,brightness:-.4,decay:.35,noise:.7},splash:{note:44,levelDb:-2,brightness:-.1,decay:1,noise:1},
  }},
  ride:{membrane:false,defaultStroke:'bow',strokes:{
    bow:{note:51},bell:{note:53,levelDb:2,brightness:.7,decay:1.3,noise:.45,pitch:7},edge:{note:59,levelDb:1,brightness:-.5,decay:1.4,noise:1.6},
  }},
  // A choke: the hand that grabs the crash to stop it (the odd/prime rudiments report's T19). It sounds nothing of its own
  // and takes a hand; a crash left to ring takes none.
  crash:{membrane:false,defaultStroke:'edge',strokes:{edge:{note:49},bow:{note:57,levelDb:-2,brightness:.2,decay:.8,noise:.8},choke:{note:49,silences:true}}},
  clap:{membrane:false,defaultStroke:'hands',strokes:{hands:{note:39}}},
  // Hand and orchestral percussion: a hit, a roll held for its note's length (a triangle's, a tambourine's), and a
  // suspended cymbal's swell to its peak (strike.peakIn: the seconds until it peaks), each its recording where a kit
  // has one (synths/drum-kit.js).
  perc:{membrane:false,defaultStroke:'hit',strokes:{hit:{note:56},roll:{levelDb:-3,decay:3,noise:1.4,attack:2},swell:{levelDb:-6,decay:4,attack:6}}},
});
const MUTED_CONGA_NOTES=Object.freeze({63:62}); // the open high conga's muted note; the low conga has none
// A hat opened this far or more is the open hat, 46, and less the closed hat, 42.
const OPEN_HAT_OPENNESS=.5,HAT_NOTES=Object.freeze({open:46,closed:42});
// Which piece a kit sound is (audio.js DRUM_KIT's kinds), and for the toms' General MIDI notes, the hand drums'.
const KIND_PIECES=Object.freeze({kick:'kick',softKick:'kick',snare:'snare',brush:'snare',clap:'clap',closedHat:'hat',openHat:'hat',
  ride:'ride',crash:'crash',tom:'tom',perc:'perc'});
const HAND_DRUM_NOTES=Object.freeze([60,61,62,63,64]);
// The piece a General MIDI drum note is, for a recorded hit that knows only its note.
const NOTE_PIECES=Object.freeze({35:'kick',36:'kick',37:'snare',38:'snare',40:'snare',39:'clap',42:'hat',44:'hat',46:'hat',
  49:'crash',52:'crash',55:'crash',57:'crash',51:'ride',53:'ride',59:'ride',41:'tom',43:'tom',45:'tom',47:'tom',48:'tom',50:'tom',
  60:'conga',61:'conga',62:'conga',63:'conga',64:'conga'});
// A drum retuned by at most two octaves.
const TUNING_LIMIT=24;
// A drum tuned to a note. The user, 26 September 2026: "Tuning the kick drum (not far) to a note that resonates with each
// harmony, or at least with the current section or tonic", and "the point is to ensure that even those kicks that aren't
// extremely pitched are still in tune with, or at least not out of tune with, the ensemble. It's a detail-oriented
// professional mixing technique". A drummer names the notes (a strike's `tuneTo`: pitch classes in the harmony's own
// tuning, the most resonant first: resonantNotes); the drum's voice, which knows its own pitch (shared/drum-pitches.js,
// audio.js DRUM_KIT), is retuned to the first it reaches within mostSemitones. A voice that does not know its pitch (a
// plugin's) is left as it is. "Not far" is two and a half semitones either way: the widest gap between neighbouring tones
// of a major, minor or augmented triad, or of any seventh chord, is a fourth, so every pitch lies that near one of their
// tones, and no nearer limit always reaches one (a recording played at most 15% faster or slower). A bare diminished
// triad's tritone leaves three semitones in its middle, and a kick there stays as it is (a diminished seventh over it). A chord tone is its root's nth harmonic when within a sixth of a tone of it (the
// harmonic seventh lies 31 cents under a tempered minor seventh), searched to the 64th (ours).
export const TUNE_TO=Object.freeze({mostSemitones:2.5,harmonicCents:100/3,mostHarmonic:64});
// Each drum's tuning: which of the notes it takes, and how far it goes for one. The user, 26 September 2026: "The tuned
// bass drum sounds great. Do likewise for snare and toms but make only quite minor adjustments to the snare, tuning it
// to the nearest reasonably in-tune note."
//   first    the first of the notes it reaches, the most resonant with the harmony's root first: the kick, and likewise
//            the toms and the hand drums (their shells ring a clearer pitch than a kick's), within TUNE_TO.mostSemitones
//   nearest  the nearest of them, the more resonant where two are as near: the snare, whose wires hide its pitch, moved
//            at most a semitone, the smallest step between two notes (every note of a scale lies within a semitone of
//            one of the scale's own; a snare further from every note of the harmony than that stays as it is)
// A drum not named here (a hat, a cymbal, a shaker) is not tuned.
export const TUNING=Object.freeze({
  kick:Object.freeze({pick:'first',semitones:TUNE_TO.mostSemitones}),
  tom:Object.freeze({pick:'first',semitones:TUNE_TO.mostSemitones}),
  conga:Object.freeze({pick:'first',semitones:TUNE_TO.mostSemitones}),
  snare:Object.freeze({pick:'nearest',semitones:1}),
});
// A piece's tuning, or null for a drum not tuned.
export const tuningRule=piece=>TUNING[piece]??null;
const SEMITONES=12,CENTS=100;
// Ours: a hand or a pedal stopping the sound shortens its decay towards a sixth (DAMPED_DECAY), and its release no
// further than DAMPED_RELEASE_FLOOR; pressure lengthens a buzz by up to BUZZ_PRESSURE_DECAY more and raises a hand
// drum by up to PRESSED_SEMITONES (a talking drum's squeeze is a fifth and more).
const DAMPED_DECAY=.83,DAMPED_RELEASE_FLOOR=.3,BUZZ_PRESSURE_DECAY=1,PRESSED_SEMITONES=2;
// Ours: a layer's noise filter follows eight tenths of the stroke's brightness; a snare's wires ring as the square root
// of the stroke's wires and answer a third of the body's change where the head was struck.
const NOISE_BRIGHTNESS_SHARE=.8,WIRE_DECAY_POWER=.5,WIRE_BODY_SHARE=.3;
// The tone layers of the membranes: where the lowest mode sounds.
const BODY_FAMILIES=Object.freeze(['kick','tom','snareBody']);
// #74's range: an octave of brightness either way is a quarter of it.
const BRIGHTNESS_OCTAVES_PER_HALF=2;

const clamp=(value,low,high)=>Math.max(low,Math.min(high,value));
const clamp01=value=>clamp(Number(value)||0,0,1);
const finite=(value,fallback=null)=>Number.isFinite(Number(value))&&value!==null&&value!==''?Number(value):fallback;
const decibels=ratio=>20*Math.log10(ratio),gainOf=db=>10**(db/20);

// J0 series through k=12, ONLY on the membrane domain |x|<=2.404826.
// Exact truncation <3.111e-18; Float64 and physical-model errors are separate.
function besselJ0(x){const ratio=-x*x/4;let term=1,sum=1;for(let k=1;k<=12;k++){term*=ratio/(k*k);sum+=term}return sum}
const J0_REFERENCE=besselJ0(J01*POSITION_REFERENCE);
// The lowest mode's level at a position against the reference position, in dB.
export function membraneBodyDb(position){
  return Math.max(BODY_FLOOR_DB,decibels(Math.max(gainOf(BODY_FLOOR_DB),Math.abs(besselJ0(J01*clamp01(position)))/J0_REFERENCE)));
}
// The brightness a position adds against the reference position, in octaves of the voice's filter.
export const membraneBrightness=position=>BRIGHTNESS_PER_POSITION*(clamp01(position)-POSITION_REFERENCE);

// The metrical places the measurements are kept by, for a tick in a bar: the downbeat and the bar's other beats, and
// within a beat its halves, quarters and thirds. Other meters are read the same way from their beats (felt beats in a
// compound meter: the dotted quarter is the beat and its eighths are the triplet places); a bar of more than four beats
// takes the second, third and fourth beats' places in turn. Returns null between them.
export function metricPlace(tickInBar,beatTicks){
  const beat=Math.max(1,Math.round(beatTicks)),at=Math.max(0,Math.round(tickInBar)),index=Math.floor(at/beat),within=(at%beat)/beat;
  if(within===0)return BEAT_PLACES[index===0?0:1+(index-1)%(BEAT_PLACES.length-1)];
  return PLACES_IN_BEAT.find(([fraction])=>Math.abs(within-fraction)<PLACE_TOLERANCE)?.[1]??null;
}
export const onBeat=place=>typeof place==='string'&&place.startsWith('beat');
// A drummer's accent at a place, for an instrument the measurements have (1 elsewhere).
export const measuredAccent=(instrument,place)=>MEASURED.accents[instrument]?.[place]??1;
// How much a stroke meant alike varies, at a place.
export const measuredSpread=(instrument,place)=>{const spread=MEASURED.spread[instrument];return spread?spread[onBeat(place)?'beat':'off']:0};

export function pieceOf(kind,{note=null,piece=null}={}){
  if(piece&&PIECES[piece])return piece;
  if(kind==='tom'&&HAND_DRUM_NOTES.includes(Number(note)))return 'conga';
  return KIND_PIECES[kind]??'perc';
}
export const strokesOf=piece=>Object.keys(PIECES[piece]?.strokes??{});
export const pieceForNote=note=>NOTE_PIECES[Math.round(Number(note))]??'perc';

// A strike as given (any field missing, or null), checked: a stroke the piece has, positions and amounts in range.
// Returns null for no strike at all, so a caller can tell "as it always was" from anything else.
export function normalizeStrike(piece,strike){
  if(!strike||typeof strike!=='object')return null;
  const definition=PIECES[piece]??PIECES.perc,out={};
  if(strike.stroke!=null){if(!definition.strokes[strike.stroke])throw new RangeError(`A ${piece} has no "${strike.stroke}" stroke (it has ${strokesOf(piece).join(', ')})`);out.stroke=strike.stroke}
  for(const key of ['position','openness','damping','pressure']){const value=finite(strike[key]);if(value!==null)out[key]=clamp01(value)}
  const peakIn=finite(strike.peakIn);if(peakIn!==null&&peakIn>=0)out.peakIn=peakIn;
  const tuning=finite(strike.tuning);if(tuning!==null)out.tuning=clamp(tuning,-TUNING_LIMIT,TUNING_LIMIT);
  if(Array.isArray(strike.tuneTo)){const notes=strike.tuneTo.map(value=>finite(value)).filter(value=>value!==null).map(pitchClassOf);if(notes.length)out.tuneTo=notes}
  return Object.keys(out).length?out:null;
}

const pitchClassOf=pitch=>((pitch%SEMITONES)+SEMITONES)%SEMITONES;
// The retuning (semitones) that brings a drum sounding `own` (MIDI, fractional) to one of `tuneTo` by the nearest octave,
// by its rule (TUNING: the first it reaches, or the nearest, within the rule's semitones; the kick's when none is given);
// 0 when it reaches none, or knows no pitch of its own.
export function tuningToward(tuneTo,own,rule=TUNING.kick){
  if(!Array.isArray(tuneTo)||!Number.isFinite(own))return 0;
  const reach=rule.semitones??rule.mostSemitones;let nearest=null;
  for(const note of tuneTo){
    if(!Number.isFinite(note))continue;
    const shift=pitchClassOf(note-own+SEMITONES/2)-SEMITONES/2;
    if(Math.abs(shift)>reach+1e-9)continue;
    if(rule.pick!=='nearest')return shift;
    if(nearest===null||Math.abs(shift)<Math.abs(nearest)-1e-9)nearest=shift;
  }
  return nearest??0;
}
// A harmony's pitch classes (fractional, in its own tuning), the most resonant with its root first: each ranked by the
// first harmonic of the root's series it lies within TUNE_TO.harmonicCents of (the root the 1st, its fifth the 3rd, a
// major third the 5th, a harmonic seventh the 7th, a major second the 9th, a minor third the 19th), those no harmonic
// reaches after them in their own order; then the tonic, if it is given and not among them.
export function resonantNotes(pitchClasses,root,{tonic=null,choices=TUNE_TO}={}){
  const notes=[...new Set((pitchClasses??[]).filter(Number.isFinite).map(pitchClassOf))];
  if(Number.isFinite(root)){
    const harmonics=[];
    for(let n=1;n<=choices.mostHarmonic;n++)harmonics.push((SEMITONES*CENTS*Math.log2(n))%(SEMITONES*CENTS));
    const rank=note=>{const cents=CENTS*pitchClassOf(note-root);
      for(let i=0;i<harmonics.length;i++){const apart=Math.abs(cents-harmonics[i]);if(Math.min(apart,SEMITONES*CENTS-apart)<=choices.harmonicCents)return i+1}
      return Infinity};
    const ranked=notes.map((note,index)=>({note,index,rank:rank(note)}));
    ranked.sort((a,b)=>a.rank===b.rank?a.index-b.index:a.rank-b.rank);
    notes.splice(0,notes.length,...ranked.map(entry=>entry.note));
  }
  if(Number.isFinite(tonic)&&!notes.some(note=>Math.abs(note-pitchClassOf(tonic))<1e-9))notes.push(pitchClassOf(tonic));
  return notes;
}

// What a strike does to the sound: {levelDb, brightness (octaves), decay, noise, attack (factors), pitch (semitones),
// openness (a hat's, 0 shut to 1 wide open, or null), note (the General MIDI note to record), stroke, position}.
// `note` is the hit's own note; a stroke other than the piece's usual one records its own (a rimshot 40), and a hat
// opened half way or more is the open hat, 46, unless the caller named the note it plays (`explicit`).
export function strikeTone(piece,strike,{note=null,explicit=false,openness=null,sounding=null}={}){
  const definition=PIECES[piece]??PIECES.perc,normal=normalizeStrike(piece,strike)??{},stroke=normal.stroke??definition.defaultStroke,
    tone=definition.strokes[stroke]??{},own=stroke!==definition.defaultStroke&&Number.isFinite(tone.note);
  const out={stroke,levelDb:tone.levelDb??0,brightness:tone.brightness??0,decay:tone.decay??1,noise:tone.noise??1,attack:tone.attack??1,
    wires:tone.wires??1,pitch:(tone.pitch??0)+(normal.tuning??0),note:own?tone.note:note,position:null,openness:null};
  // Tuned to a note, where the voice knows the pitch it sounds (`sounding`, MIDI): retuned from wherever the stroke put it,
  // by the piece's rule (a drum with none is not tuned).
  const rule=tuningRule(piece);
  if(rule&&normal.tuneTo&&Number.isFinite(sounding))out.pitch+=tuningToward(normal.tuneTo,sounding+out.pitch,rule);
  if(piece==='conga'&&(stroke==='mute'||stroke==='heel'||stroke==='tip'))out.note=MUTED_CONGA_NOTES[note]??note;
  // Where a membrane was struck, against the full-bodied stroke: the body's level and the brightness above it.
  const position=normal.position??tone.position??null;
  if(definition.membrane&&position!==null){out.position=position;out.body=membraneBodyDb(position);out.brightness+=membraneBrightness(position)}
  // A hi-hat's opening, from shut (0) to wide open (1); a pedal stroke is the hat closed with the foot.
  if(piece==='hat'){out.openness=stroke==='pedal'?0:normal.openness??openness;
    if(!explicit&&stroke!=='pedal'&&out.openness!==null)out.note=out.openness>=OPEN_HAT_OPENNESS?HAT_NOTES.open:HAT_NOTES.closed}
  if(normal.damping)out.decay*=1-DAMPED_DECAY*normal.damping;
  // Pressure on a buzz packs its bounces (a longer, denser buzz); on a hand drum it presses the head.
  if(normal.pressure){if(stroke==='buzz')out.decay*=1+BUZZ_PRESSURE_DECAY*normal.pressure;else if(piece==='conga'||piece==='tom')out.pitch+=PRESSED_SEMITONES*normal.pressure}
  return out;
}

// ---- the tone as a synthesized voice's shape --------------------------------------------------------------------------
//
// A layer of the kit's own voices (articulation.js families) with the tone laid on: `values` are the family's slots for
// this hit (noteShape(...).values), and the result is the overrides that differ. A tone of nothing returns {}.
// A hat's opening moves between its closed and open shapes (`closed` and `open`: the family's values for each), on a
// log scale of time, as the ring of a real hat does between them.
export function strikeShape(family,values,tone,{closed=null,open=null}={}){
  if(!tone||!values)return {};
  const out={},scale=(key,factor)=>{if(Number.isFinite(values[key])&&factor!==1)out[key]=values[key]*factor};
  if(family==='hat'&&tone.openness!==null&&closed&&open){
    const between=(key)=>{const a=closed[key],b=open[key];if(Number.isFinite(a)&&Number.isFinite(b)&&a>0&&b>0)out[key]=a*(b/a)**tone.openness};
    for(const key of ['decay','release'])between(key);
    if(Number.isFinite(closed.noiseSustain)&&Number.isFinite(open.noiseSustain))out.noiseSustain=closed.noiseSustain+(open.noiseSustain-closed.noiseSustain)*tone.openness;
  }
  const octaves=tone.brightness;
  if(octaves){scale('cutoff',2**octaves);scale('noiseCutoff',2**(NOISE_BRIGHTNESS_SHARE*octaves))}
  const decay=tone.decay*(family==='snareWires'?tone.wires**WIRE_DECAY_POWER:1);
  if(decay!==1){
    for(const key of ['decay','filterDecay','noiseDecay']){const current=out[key]??values[key];if(Number.isFinite(current)&&current>0)out[key]=current*decay}
    if(decay<1&&Number.isFinite(values.release))out.release=(out.release??values.release)*Math.max(DAMPED_RELEASE_FLOOR,decay);
  }
  const noise=tone.noise*(family==='snareWires'?tone.wires:1);
  if(noise!==1)scale('noiseLevel',noise);
  if(tone.attack!==1)scale('attack',tone.attack);
  return out;
}
// The tone's level for a layer, as a gain: the stroke's level, the body's where it was struck (the membrane's lowest
// mode is the tone layer of a kick, a tom or a snare's shell; its wires answer less and a noise layer not at all), and a
// snare's wires by its stroke (a cross stick barely moves them).
export function strikeGain(family,tone){
  if(!tone)return 1;
  const body=Number.isFinite(tone.body)?(family==='snareWires'?WIRE_BODY_SHARE:BODY_FAMILIES.includes(family)?1:0)*tone.body:0;
  return gainOf(tone.levelDb+body)*(family==='snareWires'?tone.wires:1);
}

// ---- the tone as MIDI ---------------------------------------------------------------------------------------------------
//
// Per-note controllers, as MIDI 2 carries them (articulation.js has the rest): #74 brightness, 0.5 the piece as it is and
// a quarter of the range an octave of its filter either way; #71 timbre, the strike position (0 the centre, 1 the rim)
// as MMA RP-021's bipolar harmonic content, centred on the full-bodied stroke. Null where the strike says nothing.
export function strikeControllers(tone){
  if(!tone)return {brightness:null,timbre:null};
  return {brightness:tone.brightness?clamp01(1/2+tone.brightness/(2*BRIGHTNESS_OCTAVES_PER_HALF)):null,
    timbre:tone.position===null?null:clamp01(1/2+(tone.position-POSITION_REFERENCE)/(2*(1-POSITION_REFERENCE)))};
}
