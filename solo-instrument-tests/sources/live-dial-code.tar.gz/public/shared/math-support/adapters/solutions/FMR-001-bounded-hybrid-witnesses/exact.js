// Research arithmetic: exact represented rationals, bounded bit growth, no silent float conversion.
export class ArithmeticLimit extends Error {}
export class WorkLimit extends Error {}
const BITS=2048, abs=n=>n<0n?-n:n;
const gcd=(a,b)=>{a=abs(a);b=abs(b);while(b)[a,b]=[b,a%b];return a};
const bits=n=>abs(n).toString(2).length;
const parseInteger=value=>{
  if(typeof value==='bigint'){if(bits(value)>BITS)throw new ArithmeticLimit('integer bit limit');return value}
  if(typeof value==='number'&&Number.isSafeInteger(value))return BigInt(value);
  if(typeof value==='string'&&value.length<=620&&/^[+-]?\d+$/.test(value)){
    const n=BigInt(value);if(bits(n)>BITS)throw new ArithmeticLimit('integer bit limit');return n;
  }
  throw new TypeError('exact integer required');
};
export class Q {
  constructor(n,d=1n){
    n=parseInteger(n);d=parseInteger(d);if(d===0n)throw new RangeError('zero denominator');
    if(d<0n){n=-n;d=-d}const g=gcd(n,d);this.n=n/g;this.d=d/g;Object.freeze(this);
  }
  static of(value){
    if(value instanceof Q)return value;
    if(typeof value==='string'){
      const parts=value.split('/');if(parts.length>2)throw new TypeError('rational must be integer or n/d');
      return new Q(parts[0],parts[1]??1n);
    }
    return new Q(value);
  }
  static result(n,d){
    // Inputs to arithmetic are capped; intermediate products have at most twice that size.
    const g=gcd(n,d);return new Q(n/g,d/g);
  }
  add(value){const b=Q.of(value);return Q.result(this.n*b.d+b.n*this.d,this.d*b.d)}
  sub(value){return this.add(Q.of(value).neg())}
  mul(value){const b=Q.of(value);return Q.result(this.n*b.n,this.d*b.d)}
  div(value){const b=Q.of(value);if(b.n===0n)throw new RangeError('division by zero');return Q.result(this.n*b.d,this.d*b.n)}
  neg(){return new Q(-this.n,this.d)}
  abs(){return this.n<0n?this.neg():this}
  cmp(value){const b=Q.of(value),d=this.n*b.d-b.n*this.d;return d<0n?-1:d>0n?1:0}
  eq(value){return this.cmp(value)===0}
  floor(){const q=this.n/this.d;return this.n<0n&&this.n%this.d?q-1n:q}
  ceil(){return -this.neg().floor()}
  toString(){return this.d===1n?String(this.n):`${this.n}/${this.d}`}
  toJSON(){return this.toString()}
  valueOf(){throw new TypeError('Q requires explicit comparison; canonical values stay exact')}
}
export const ZERO=new Q(0),ONE=new Q(1);
export const sum=values=>values.reduce((a,b)=>a.add(b),ZERO);
export function boundedInt(value,name,min,max){
  if(!Number.isSafeInteger(value)||value<min||value>max)throw new TypeError(`${name} must be in [${min},${max}]`);
  return value;
}
export function id(value,name='id'){
  if(typeof value!=='string'||!value.length||value.length>256)throw new TypeError(`invalid ${name}`);return value;
}
export function distinct(values,name,max=4096){
  if(!Array.isArray(values)||values.length>max)throw new RangeError(`${name} size limit`);
  for(let i=0;i<values.length;i++){if(!Object.hasOwn(values,i))throw new TypeError(`sparse ${name}`);id(values[i],name);}
  if(new Set(values).size!==values.length)throw new TypeError(`duplicate ${name}`);
  return values;
}
// Bound traversal BEFORE JSON serialization. Reject sparse arrays, cycles, accessors
// and undeclared object types. Limits describe accepted input, not JS heap accounting.
export function preflight(input){
  let items=0,characters=0;const active=new Set;
  const visit=(value,depth)=>{
    if(++items>32768||depth>20)throw new RangeError('plain input traversal limit');
    if(typeof value==='string'){characters+=value.length;if(characters>262144)throw new RangeError('plain input text limit');return}
    if(value===null||typeof value==='boolean')return;
    if(typeof value==='number'){if(!Number.isFinite(value))throw new TypeError('nonfinite plain input');return}
    if(typeof value==='bigint'){parseInteger(value);return}
    if(value instanceof Q)return;
    if(!value||typeof value!=='object'||active.has(value))throw new TypeError('acyclic plain input required');
    active.add(value);
    const field=key=>{const d=Object.getOwnPropertyDescriptor(value,key);if(!d||!Object.hasOwn(d,'value'))throw new TypeError('dense own data fields required');visit(d.value,depth+1);};
    if(Array.isArray(value)){
      if(value.length>16384)throw new RangeError('plain input array limit');
      for(let i=0;i<value.length;i++)field(String(i));
    }else{
      if(![Object.prototype,null].includes(Object.getPrototypeOf(value)))throw new TypeError('plain objects required');
      for(const key in value)if(Object.hasOwn(value,key)){characters+=key.length;if(characters>262144)throw new RangeError('plain input text limit');field(key);}
    }
    active.delete(value);
  };
  visit(input,0);return input;
}
export class Budget {
  constructor({operations=100000,milliseconds=100,now=()=>performance.now()}={}){
    this.limit=boundedInt(operations,'operations',0,1000000);
    if(typeof milliseconds!=='number'||!Number.isFinite(milliseconds)||milliseconds<0||milliseconds>60000)throw new TypeError('invalid milliseconds');
    if(typeof now!=='function')throw new TypeError('now must be a monotonic clock');
    this.now=now;this.started=now();if(!Number.isFinite(this.started))throw new TypeError('clock must return finite milliseconds');this.milliseconds=milliseconds;this.used=0;
  }
  tick(n=1){
    this.used+=n;
    const elapsed=this.now()-this.started;if(!Number.isFinite(elapsed)||elapsed<0)throw new TypeError('clock must remain finite and monotonic');
    if(this.used>this.limit||elapsed>=this.milliseconds)throw new WorkLimit('work or elapsed-time budget exhausted');
  }
  elapsed(){return this.now()-this.started}
}
export const failure=error=>({status:error instanceof WorkLimit?'budget-exhausted-no-witness':error instanceof ArithmeticLimit?'arithmetic-budget-exhausted':'invalid-model',reason:error.message});
export function boundedRun(options,run){
  let budget;
  try{budget=new Budget(options);budget.tick(0);const result=run(budget),elapsedMs=budget.elapsed();return {...result,budgetExhausted:Boolean(result.budgetExhausted)||elapsedMs>=budget.milliseconds,operations:budget.used,elapsedMs}}
  catch(error){return {...failure(error),...(budget?{operations:budget.used,elapsedMs:budget.elapsed()}:{}),budgetExhausted:error instanceof WorkLimit||error instanceof ArithmeticLimit};}
}
