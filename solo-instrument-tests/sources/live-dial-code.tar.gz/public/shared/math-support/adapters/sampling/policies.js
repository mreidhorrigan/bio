// Explicit opt-in laws for source-faithful bots. The legacy defaults are
// supplied by the owning adapter; no existing RNG stream is silently changed.
import {Q} from '../solutions/FMR-001-bounded-hybrid-witnesses/exact.js';
import {unitRandom} from '../../../../stochastic-algorithms.js';
const MAX_BITS=2048;
const bounded=value=>{if(value.toString(2).length>MAX_BITS)throw new RangeError('Sampling integer bit budget');return value;};
const integer=(value,low,high)=>{if(!Number.isSafeInteger(value)||value<low||value>high)throw new RangeError('Sampling dimension budget');return value;};
export function prepareLegacyChoice(values,weights){
  if(!Array.isArray(values)||!Array.isArray(weights)||values.length>65536||weights.length>65536)throw new RangeError('Finite plain distribution required');
  const outputs=values.slice(),usable=Array.from(weights,value=>{const n=Number(value);return Number.isFinite(n)&&n>0?n:0;});
  let total=0;for(const weight of usable)total+=weight;
  return Object.freeze({version:'legacy-prepared-choice-v1',draw(rng){
    if(!outputs.length||outputs.length!==usable.length||!(total>0))return outputs[0];
    let chosen=unitRandom(rng)*total,last=0;
    for(let i=0;i<usable.length;i++){const weight=usable[i];if(!weight)continue;last=i;chosen-=weight;if(chosen<=0)return outputs[i];}
    return outputs[last];
  }});
}
// Revision ownership is explicit: mutation must advance the owner's revision.
export class DistributionPlans {
  #plans=new Map;
  get(key,revision,values,weights){
    if(typeof key!=='string'||!key||typeof revision!=='string'||!revision)throw new TypeError('Distribution key and immutable revision required');
    const previous=this.#plans.get(key);if(previous?.revision===revision)return previous.plan;
    const plan=prepareLegacyChoice(values,weights);if(!previous&&this.#plans.size>=64)this.#plans.delete(this.#plans.keys().next().value);
    this.#plans.set(key,{revision,plan});return plan;
  }
}
export function stableRankIndexV2(length,base,unit){
  integer(length,1,Number.MAX_SAFE_INTEGER);
  if(!Number.isFinite(base)||base<=0||!Number.isFinite(unit)||unit<0||unit>1)throw new RangeError('Positive base and unit value required');
  if(unit===0)return 0;if(unit===1)return length-1;
  const log=Math.log(base),position=base===1?unit:base<1?Math.expm1(unit*log)/Math.expm1(log):
    Math.exp((unit-1)*log)*(-Math.expm1(-unit*log))/(-Math.expm1(-log));
  return Math.max(0,Math.min(length-1,Math.floor(position*length)));
}
export function boundaryStep(value,delta,{low=0,high=1,law}={}){
  const width=high-low,next=value+delta;
  if(![value,delta,low,high,width,next].every(Number.isFinite)||width<=0)throw new RangeError('Finite ordered boundary required');
  if(law==='clip')return Math.max(low,Math.min(high,next));
  if(law==='wrap'){
    if(!Number.isFinite(next-low))throw new RangeError('Boundary arithmetic overflow');
    let remainder=(next-low)%width;if(remainder<0)remainder+=width;return low+remainder;
  }
  if(law==='reflect'){
    const period=2*width;if(!Number.isFinite(period)||!Number.isFinite(next-low))throw new RangeError('Boundary arithmetic overflow');
    let remainder=(next-low)%period;if(remainder<0)remainder+=period;return low+width-Math.abs(width-remainder);
  }
  throw new RangeError('Explicit clip/wrap/reflect law required');
}
export function cappedBernoulliExpectation(trials,cap,probability,{forceOne=true}={}){
  integer(trials,0,4096);integer(cap,0,128);const p=probability;
  if(!Number.isFinite(p)||p<0||p>1)throw new RangeError('Gate probability required');
  cap=Math.min(cap,trials);if(!cap)return 0;
  const mass=new Float64Array(cap+1);mass[0]=1;
  for(let i=0;i<trials;i++){
    mass[cap]+=p*mass[cap-1];
    for(let j=cap-1;j>0;j--)mass[j]=(1-p)*mass[j]+p*mass[j-1];
    mass[0]*=1-p;
  }
  let expected=forceOne?mass[0]:0;for(let j=1;j<=cap;j++)expected+=j*mass[j];return expected;
}
export function exactRankBelow(total,nextWord,{maxAttempts=64}={}){
  if(typeof total!=='bigint'||total<=0n)throw new RangeError('Positive exact total required');bounded(total);integer(maxAttempts,1,1024);
  if(total===1n)return {ok:true,rank:0n,words:0};
  const bits=(total-1n).toString(2).length,words=Math.ceil(bits/32),mask=(1n<<BigInt(bits))-1n;
  for(let attempt=0;attempt<maxAttempts;attempt++){
    let rank=0n;
    for(let i=0;i<words;i++){const word=nextWord();integer(word,0,0xffffffff);rank=(rank<<32n)|BigInt(word);}
    rank&=mask;if(rank<total)return {ok:true,rank,words:(attempt+1)*words};
  }
  return {ok:false,reason:'random-word-budget',words:maxAttempts*words};
}
export function prepareCompositions(total,parts=[2,3],{maxOperations=100000}={}){
  integer(total,0,4096);integer(maxOperations,1,1000000);
  if(!Array.isArray(parts)||!parts.length||parts.length>64)throw new RangeError('Finite composition parts required');
  const choices=[...new Set(parts.map(p=>integer(p,1,4096)))].sort((a,b)=>a-b),counts=Array(total+1).fill(0n);counts[0]=1n;
  let operations=0;
  for(let r=1;r<=total;r++)for(const part of choices){if(++operations>maxOperations)throw new RangeError('Composition work budget');if(part<=r)counts[r]=bounded(counts[r]+counts[r-part]);}
  const unrank=rank=>{
    if(typeof rank!=='bigint'||rank<0n||rank>=counts[total])throw new RangeError('Composition rank outside domain');
    const result=[];let remaining=total;
    while(remaining){let selected=false;for(const part of choices){if(part>remaining)break;const mass=counts[remaining-part];if(rank<mass){result.push(part);remaining-=part;selected=true;break;}rank-=mass;}if(!selected)throw new Error('Invalid composition count invariant');}
    return result;
  };
  return Object.freeze({version:'uniform-complete-compositions-v1',total:counts[total],operations,unrank,
    sample(nextWord,options){if(!counts[total])return {ok:false,reason:'no-composition'};const draw=exactRankBelow(counts[total],nextWord,options);return draw.ok?{...draw,value:unrank(draw.rank)}:draw;}});
}
// Exact conditional finite-form distribution. Rational probabilities apply to
// independent voices, with the source's half-probability after a previous rest.
// Denominators are constant across a row, so integer suffix masses preserve the
// complete law after the explicitly selected form constraints are imposed.
export function prepareBinaryForms(sections,probabilities,{nonempty='whole-form',adjacentDistinct=false,maxOperations=100000}={}){
  integer(sections,1,32);integer(maxOperations,1,1000000);
  if(!['whole-form','each-section','allow-rests'].includes(nonempty))throw new RangeError('Explicit rest policy required');
  if(!Array.isArray(probabilities)||probabilities.length<1||probabilities.length>8)throw new RangeError('One to eight rational probabilities required');
  const ps=probabilities.map(Q.of);if(ps.some(p=>p.cmp(0)<0||p.cmp(1)>0))throw new RangeError('Probabilities outside [0,1]');
  const states=1<<ps.length,memo=new Map,weights=new Map;let operations=0;
  const tick=()=>{if(++operations>maxOperations)throw new RangeError('Form work budget');};
  const weight=(previous,state)=>{
    const key=previous+':'+state;if(weights.has(key))return weights.get(key);
    let value=1n;
    for(let voice=0;voice<ps.length;voice++){
      tick();const p=ps[voice],denominator=2n*p.d,numerator=previous!==null&&!(previous&(1<<voice))?p.n:2n*p.n;
      value=bounded(value*((state&(1<<voice))?numerator:denominator-numerator));
    }
    weights.set(key,value);return value;
  };
  const legal=(previous,state)=>!(nonempty==='each-section'&&state===0)&&!(adjacentDistinct&&previous!==null&&state===previous);
  const mass=(remaining,previous,heard)=>{
    if(!remaining)return nonempty==='whole-form'&&!heard?0n:1n;
    const key=remaining+':'+previous+':'+heard;if(memo.has(key))return memo.get(key);
    let total=0n;
    for(let state=0;state<states;state++){tick();if(legal(previous,state))total=bounded(total+weight(previous,state)*mass(remaining-1,state,heard||state!==0));}
    memo.set(key,total);return total;
  };
  const total=mass(sections,null,false);
  const unrank=rank=>{
    if(typeof rank!=='bigint'||rank<0n||rank>=total)throw new RangeError('Form rank outside domain');
    const form=[];let previous=null,heard=false;
    for(let remaining=sections;remaining>0;remaining--){
      let selected=false;
      for(let state=0;state<states;state++)if(legal(previous,state)){
        const tail=mass(remaining-1,state,heard||state!==0),branch=weight(previous,state)*tail;
        if(rank<branch){rank%=tail;form.push(Array.from({length:ps.length},(_,voice)=>(state>>voice)&1));previous=state;heard||=state!==0;selected=true;break;}
        rank-=branch;
      }
      if(!selected)throw new Error('Invalid form count invariant');
    }
    return form;
  };
  return Object.freeze({version:'conditional-binary-form-v1',total,operations,unrank,
    sample(nextWord,options){if(!total)return {ok:false,reason:'empty-form-policy'};const draw=exactRankBelow(total,nextWord,options);return draw.ok?{...draw,value:unrank(draw.rank)}:draw;}});
}
export function hazardProbability(rate,elapsed){
  if(!Number.isFinite(rate)||rate<0||!Number.isFinite(elapsed)||elapsed<0)throw new RangeError('Finite nonnegative rate and elapsed units required');
  return -Math.expm1(-rate*elapsed);
}
// Cumulative exact expected counts. A cap is a capacity refusal: it does not
// silently discard fractional mass or make the requested rate tempo dependent.
export class ExactGrainAccumulator {
  #mass=new Q(0);
  advance(ratePerSecond,elapsedSeconds,{capacity=14}={}){
    integer(capacity,0,1000000);const rate=Q.of(ratePerSecond),elapsed=Q.of(elapsedSeconds);
    if(rate.cmp(0)<0||elapsed.cmp(0)<0)throw new RangeError('Nonnegative rate/time required');
    const next=this.#mass.add(rate.mul(elapsed)),count=next.floor();
    if(count>BigInt(capacity))return {ok:false,reason:'capacity',requested:count.toString(),remainder:this.#mass.toString()};
    this.#mass=next.sub(count);return {ok:true,count:Number(count),remainder:this.#mass.toString()};
  }
  reset(){this.#mass=new Q(0);}
}
// Admission adapter for a declared event-count budget. This enforces actual
// count reservations; it is separate from density/energy/occupancy controls.
export class EnsembleEventBudget {
  #epoch=null;#remaining=0;#reservations=new Map;
  begin(epoch,count){integer(epoch,0,Number.MAX_SAFE_INTEGER);integer(count,0,1000000);if(this.#epoch!==null&&epoch<=this.#epoch)throw new Error('Budget epochs must increase');this.#epoch=epoch;this.#remaining=count;this.#reservations.clear();}
  reserve(epoch,id,count){integer(count,0,1000000);if(epoch!==this.#epoch)return {ok:false,reason:'stale-epoch'};if(typeof id!=='string'||!id)throw new TypeError('Event identity required');if(this.#reservations.has(id))return {ok:false,reason:'duplicate'};if(count>this.#remaining)return {ok:false,reason:'capacity'};this.#remaining-=count;this.#reservations.set(id,count);return {ok:true,remaining:this.#remaining};}
}
// Owning entry points: the caller names a law, and refusal remains visible.
export function additiveGroupingForAgent({policy='legacy',legacy,prepared,nextWord,...options}){
  if(policy==='legacy')return {ok:true,value:legacy()};
  if(policy!=='uniform-complete-compositions-v1'||prepared?.version!==policy)throw new Error('Unknown grouping policy');
  return prepared.sample(nextWord,options);
}
export function binaryFormForAgent({policy='legacy',legacy,prepared,nextWord,...options}){
  if(policy==='legacy')return {ok:true,value:legacy()};
  if(policy!=='conditional-binary-form-v1'||prepared?.version!==policy)throw new Error('Unknown form policy');
  return prepared.sample(nextWord,options);
}
