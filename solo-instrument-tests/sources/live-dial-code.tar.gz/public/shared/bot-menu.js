export const BOT_MENU_GROUPS = Object.freeze([
  ["polyphonic", "Polyphonic · independent simultaneous pitches"],
  ["monophonic", "Monophonic · one pitched note at a time"],
  ["percussive", "Percussive & unpitched"],
  ["silent", "Silent · messages only"],
  ["incomplete", "Incomplete, experimental or templates"],
]);

export function botMenuGroup(definition) {
  if (!definition?.id) throw new TypeError("Bot definition requires an id");
  return definition.performanceType || "incomplete";
}
