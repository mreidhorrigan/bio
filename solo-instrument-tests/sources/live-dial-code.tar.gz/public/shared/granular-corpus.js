import { unitRandom } from './stochastic.js';

// A grain corpus is a pre-graphed sound library: an offline analyser slices source
// recordings at onsets, measures each slice, and records which slice follows which.
// The browser only selects and schedules; it never re-analyses audio. See
// docs/GRANULAR_CORPUS.md for the offline half and the interchange format.
export const GRANULAR_CORPUS_SCHEMA=1;
// Pitch-class snapping folds to the nearest octave, so a fold can never exceed a
// tritone. Callers asking for more are clamped rather than silently given less.
export const MAX_PITCH_SHIFT=6;

const plainObject=value=>!!value&&typeof value==='object'&&!Array.isArray(value);
const finite=(value,name)=>{
  const number=Number(value);
  if(!Number.isFinite(number))throw new TypeError(`${name} must be a finite number`);
  return number;
};
const bounded=(value,name,minimum,maximum)=>{
  const number=finite(value,name);
  if(number<minimum||number>maximum)throw new TypeError(`${name} must be between ${minimum} and ${maximum}`);
  return number;
};
const nonEmptyString=(value,name)=>{
  const text=String(value??'').trim();
  if(!text)throw new TypeError(`${name} is required`);
  return text;
};
// Pitch stays a floating-point semitone at every hop. The offline analysis resolves
// better than a cent, so rounding to a MIDI key here would discard the whole point of
// the corpus; null means "measured as unpitched", never "rounded away".
const optionalPitch=(value,name)=>{
  if(value==null)return null;
  return bounded(value,name,0,127);
};
const optionalNumber=(value,name)=>value==null?null:finite(value,name);

export const pitchClassOf=pitch=>{
  if(pitch==null)return null;
  const value=Number(pitch);
  return Number.isFinite(value)?((value%12)+12)%12:null;
};
// Fold an interval to the nearest octave without rounding the remainder: the cents
// survive, only the register moves.
export const foldToNearestOctave=semitones=>{
  const value=finite(semitones,'semitones');
  return value-Math.round(value/12)*12;
};
export const centsBetween=(from,to)=>(Number(to)-Number(from))*100;

function parseSource(value,name){
  if(!plainObject(value))throw new TypeError(`${name} must be an object`);
  const contiguity=String(value.contiguity??'free'),synchrony=String(value.synchrony??'free');
  if(!['free','preserve'].includes(contiguity))throw new TypeError(`${name}.contiguity must be free or preserve`);
  if(!['free','preserve'].includes(synchrony))throw new TypeError(`${name}.synchrony must be free or preserve`);
  const attribution=value.attribution==null?null:(()=>{
    if(!plainObject(value.attribution))throw new TypeError(`${name}.attribution must be an object`);
    return Object.freeze({
      name:String(value.attribution.name??''),author:String(value.attribution.author??''),
      license:String(value.attribution.license??''),url:String(value.attribution.url??'')
    });
  })();
  return Object.freeze({
    id:nonEmptyString(value.id,`${name}.id`),
    audio:nonEmptyString(value.audio,`${name}.audio`),
    durationSeconds:bounded(value.durationSeconds,`${name}.durationSeconds`,0,Number.MAX_SAFE_INTEGER),
    sampleRate:bounded(value.sampleRate,`${name}.sampleRate`,1,768000),
    channels:bounded(value.channels,`${name}.channels`,1,64),
    layout:String(value.layout??'mono'),contiguity,synchrony,attribution
  });
}

function parseGrain(value,name,sources){
  if(!plainObject(value))throw new TypeError(`${name} must be an object`);
  const source=nonEmptyString(value.source,`${name}.source`);
  const owner=sources.get(source);
  if(!owner)throw new TypeError(`${name} references unknown source ${source}`);
  const offsetSeconds=bounded(value.offsetSeconds,`${name}.offsetSeconds`,0,owner.durationSeconds);
  const durationSeconds=finite(value.durationSeconds,`${name}.durationSeconds`);
  if(durationSeconds<=0)throw new TypeError(`${name}.durationSeconds must be positive`);
  // A grain that reads past its source would silently shorten at playback, which turns
  // a deterministic corpus into a device-dependent one. Reject it at the boundary.
  if(offsetSeconds+durationSeconds>owner.durationSeconds+1e-6)
    throw new TypeError(`${name} extends past the end of source ${source}`);
  const pitchSemitones=optionalPitch(value.pitchSemitones,`${name}.pitchSemitones`);
  const centsOffset=value.centsOffset==null
    ?(pitchSemitones==null?null:(pitchSemitones-Math.round(pitchSemitones))*100)
    :finite(value.centsOffset,`${name}.centsOffset`);
  return Object.freeze({
    id:nonEmptyString(value.id,`${name}.id`),source,
    channel:bounded(value.channel??0,`${name}.channel`,0,owner.channels-1),
    offsetSeconds,durationSeconds,pitchSemitones,
    pitchClass:pitchClassOf(pitchSemitones),centsOffset,
    f0Hz:optionalNumber(value.f0Hz,`${name}.f0Hz`),
    secondaryPitchSemitones:optionalPitch(value.secondaryPitchSemitones,`${name}.secondaryPitchSemitones`),
    polyphony:bounded(value.polyphony??1,`${name}.polyphony`,1,16),
    salience:bounded(value.salience??0,`${name}.salience`,0,1),
    confidence:bounded(value.confidence??0,`${name}.confidence`,0,1),
    voicedFraction:bounded(value.voicedFraction??0,`${name}.voicedFraction`,0,1),
    centsSpread:bounded(value.centsSpread??0,`${name}.centsSpread`,0,12000),
    inharmonicity:optionalNumber(value.inharmonicity,`${name}.inharmonicity`),
    rmsDb:finite(value.rmsDb??-120,`${name}.rmsDb`),
    centroidHz:optionalNumber(value.centroidHz,`${name}.centroidHz`),
    flatness:bounded(value.flatness??0,`${name}.flatness`,0,1),
    crestDb:finite(value.crestDb??0,`${name}.crestDb`),
    noiseScore:bounded(value.noiseScore??0,`${name}.noiseScore`,0,1),
    background:Boolean(value.background),
    next:value.next==null?null:String(value.next),
    syncGroup:value.syncGroup==null?null:String(value.syncGroup)
  });
}

const isParsed=value=>plainObject(value)&&Object.isFrozen(value)&&Array.isArray(value.grains)&&Object.isFrozen(value.grains);

export function parseGranularCorpus(value){
  if(isParsed(value))return value;
  if(!plainObject(value))throw new TypeError('Granular corpus must be an object');
  if(value.schemaVersion!==GRANULAR_CORPUS_SCHEMA)
    throw new TypeError(`Unsupported granular corpus schema ${value.schemaVersion}`);
  if(value.pitchUnits!=='semitones')
    throw new TypeError('Granular corpus must declare pitchUnits "semitones"');
  if(!Array.isArray(value.sources)||!value.sources.length)throw new TypeError('Granular corpus requires sources');
  if(!Array.isArray(value.grains)||!value.grains.length)throw new TypeError('Granular corpus requires grains');
  const sources=new Map();
  value.sources.forEach((entry,position)=>{
    const source=parseSource(entry,`sources[${position}]`);
    if(sources.has(source.id))throw new TypeError(`Duplicate source id ${source.id}`);
    sources.set(source.id,source);
  });
  const grains=value.grains.map((entry,position)=>parseGrain(entry,`grains[${position}]`,sources));
  const byId=new Map();
  for(const grain of grains){
    if(byId.has(grain.id))throw new TypeError(`Duplicate grain id ${grain.id}`);
    byId.set(grain.id,grain);
  }
  for(const grain of grains)
    if(grain.next!=null&&!byId.has(grain.next))throw new TypeError(`Grain ${grain.id} links to unknown successor ${grain.next}`);
  if(Number.isFinite(Number(value.grainCount))&&Number(value.grainCount)!==grains.length)
    throw new TypeError(`Declared grainCount ${value.grainCount} does not match ${grains.length} grains`);
  return Object.freeze({
    schemaVersion:GRANULAR_CORPUS_SCHEMA,pitchUnits:'semitones',
    name:String(value.name??'granular-corpus'),generator:String(value.generator??''),
    origin:Object.freeze({...(plainObject(value.origin)?value.origin:{})}),
    grainCount:grains.length,sources:Object.freeze([...sources.values()]),grains:Object.freeze(grains)
  });
}

export function indexGranularCorpus(value){
  const corpus=parseGranularCorpus(value),byId=new Map(),bySource=new Map(),pitched=[],unpitched=[],foreground=[];
  for(const grain of corpus.grains){
    byId.set(grain.id,grain);
    if(!bySource.has(grain.source))bySource.set(grain.source,[]);
    bySource.get(grain.source).push(grain);
    (grain.pitchSemitones==null?unpitched:pitched).push(grain);
    // The offline detector marks probably-just-room-tone slices. They are legitimate as a
    // continuation inside a contiguous run, never as a standalone event.
    if(!grain.background)foreground.push(grain);
  }
  return Object.freeze({
    corpus,sources:new Map(corpus.sources.map(source=>[source.id,source])),byId,bySource,
    grains:corpus.grains,pitched:Object.freeze(pitched),unpitched:Object.freeze(unpitched),
    foreground:Object.freeze(foreground)
  });
}

export function grainChain(index,grain,limit=8){
  const start=typeof grain==='string'?index.byId.get(grain):grain,out=[];
  let current=start;
  while(current&&out.length<Math.max(1,limit)){out.push(current);current=current.next==null?null:index.byId.get(current.next)}
  return out;
}

export function filterGrains(index,{
  pitchedOnly=false,unpitchedOnly=false,includeBackground=false,
  minSalience=0,maxSalience=1,minDurationSeconds=0,maxDurationSeconds=Infinity,
  minConfidence=0,maxNoiseScore=1,sources=null
}={}){
  const allowed=sources?new Set(sources):null;
  return (includeBackground?index.grains:index.foreground).filter(grain=>
    (!pitchedOnly||grain.pitchSemitones!=null)&&(!unpitchedOnly||grain.pitchSemitones==null)&&
    grain.salience>=minSalience&&grain.salience<=maxSalience&&
    grain.durationSeconds>=minDurationSeconds&&grain.durationSeconds<=maxDurationSeconds&&
    grain.confidence>=minConfidence&&grain.noiseScore<=maxNoiseScore&&
    (!allowed||allowed.has(grain.source)));
}

// The shift that moves a grain's own measured pitch onto `target`, octave-agnostic. The
// return value is an exact float: a 37.5-cent grain asked for a 12.5-cent target yields
// exactly -0.25 semitones, not a rounded key difference.
export function grainPitchShift(grain,target,{maxShift=MAX_PITCH_SHIFT}={}){
  const natural=grain?.pitchSemitones;
  if(natural==null||target==null||!Number.isFinite(Number(target)))return null;
  const shift=foldToNearestOctave(Number(target)-natural),limit=Math.min(MAX_PITCH_SHIFT,Math.max(0,Number(maxShift)));
  return Math.abs(shift)<=limit?shift:null;
}

// Best shift for a grain that carries two measured pitches (the analyser's multi-F0
// case): anchor the primary on each target, then score how well every pitch lands, so a
// polyphonic grain is voiced toward the chord rather than only its loudest partial.
export function grainChordShift(grain,targets,{maxShift=MAX_PITCH_SHIFT}={}){
  const pitches=[grain?.pitchSemitones,grain?.secondaryPitchSemitones].filter(value=>value!=null),
    wanted=(Array.isArray(targets)?targets:[targets]).map(Number).filter(Number.isFinite);
  if(!pitches.length||!wanted.length)return null;
  let best=null;
  for(const target of wanted){
    const shift=grainPitchShift(grain,target,{maxShift});
    if(shift==null)continue;
    let score=0;
    for(const pitch of pitches)
      score+=Math.min(...wanted.map(other=>Math.abs(foldToNearestOctave(pitch+shift-other))));
    if(!best||score<best.score||(score===best.score&&Math.abs(shift)<Math.abs(best.shift)))best={shift,score};
  }
  return best?best.shift:null;
}

export function nearestPitchedGrains(index,target,{limit=8,maxShift=MAX_PITCH_SHIFT,pool=null}={}){
  if(target==null)return [];
  const wanted=Number(target),requested=Math.max(1,limit),capacity=Number.isNaN(requested)?0:Math.trunc(requested);
  if(!Number.isFinite(wanted)||capacity===0)return [];
  const source=pool||index.pitched,heap=[];
  // Same octave-folded distance, then decreasing salience, then increasing id.
  // Stable input order resolves identical records in an explicitly supplied pool.
  const compare=(a,b)=>a.distance-b.distance||b.grain.salience-a.grain.salience||
    (a.grain.id<b.grain.id?-1:a.grain.id>b.grain.id?1:0)||a.order-b.order;
  const down=()=>{
    let at=0;
    for(;;){
      let worst=at,left=2*at+1,right=left+1;
      if(left<heap.length&&compare(heap[left],heap[worst])>0)worst=left;
      if(right<heap.length&&compare(heap[right],heap[worst])>0)worst=right;
      if(worst===at)return;
      [heap[at],heap[worst]]=[heap[worst],heap[at]];at=worst;
    }
  };
  let order=0;
  for(const grain of source){
    const position=order++,shift=grainPitchShift(grain,wanted,{maxShift});
    if(shift==null)continue;
    const entry={grain,shift,distance:Math.abs(shift),order:position};
    if(heap.length<capacity){
      heap.push(entry);let at=heap.length-1;
      while(at){const parent=Math.floor((at-1)/2);if(compare(heap[at],heap[parent])<=0)break;
        [heap[at],heap[parent]]=[heap[parent],heap[at]];at=parent;}
    }else if(compare(entry,heap[0])<0){heap[0]=entry;down();}
  }
  return heap.sort(compare).map(({grain,shift,distance})=>({grain,shift,distance}));
}

const usageKey=grain=>`${grain.source}@${grain.offsetSeconds}`;

// A port of the offline composer's selector. Three pressures act on a salience-biased
// tournament: do not recycle the same slice, prefer the slice that naturally follows the
// last one taken from its source (so the corpus tends to traverse a recording in its own
// order), and prefer a slice whose own measured pitch already sits on a requested pitch.
// The last one is the point of the whole design: harmony is organised out of the
// recordings' real pitches rather than forced onto them by retuning.
export function createGrainSelector(index,{
  random=unitRandom,candidates=3,repetitionPenalty=.7,orderReward=.5,pitchReward=.5,
  orderWindowSeconds=3,pitchToleranceSemitones=.5,maxShift=MAX_PITCH_SHIFT,pool=null
}={}){
  const draws=Math.max(1,Math.trunc(candidates)),grains=pool||index.foreground;
  if(!grains.length)throw new TypeError('Grain selector needs a non-empty pool');
  const used=new Map(),lastOffset=new Map();
  const score=(grain,targets)=>{
    let value=grain.salience-repetitionPenalty*(used.get(usageKey(grain))||0);
    const previous=lastOffset.get(grain.source);
    if(previous!=null&&previous<grain.offsetSeconds&&grain.offsetSeconds<=previous+orderWindowSeconds)value+=orderReward;
    if(targets.length&&grain.pitchSemitones!=null){
      const distance=Math.min(...targets.map(target=>Math.abs(foldToNearestOctave(target-grain.pitchSemitones))));
      if(distance<pitchToleranceSemitones)value+=pitchReward;
    }
    return value;
  };
  return {
    pool:grains,
    reset(){used.clear();lastOffset.clear();return this},
    select({pitches=[]}={}){
      const targets=(Array.isArray(pitches)?pitches:[pitches]).map(Number).filter(Number.isFinite);
      let best=null,bestScore=-Infinity;
      for(let draw=0;draw<draws;draw++){
        const grain=grains[Math.min(grains.length-1,Math.floor(random()*grains.length))],value=score(grain,targets);
        if(value>bestScore){best=grain;bestScore=value}
      }
      used.set(usageKey(best),(used.get(usageKey(best))||0)+1);
      lastOffset.set(best.source,best.offsetSeconds);
      const shift=targets.length?grainChordShift(best,targets,{maxShift}):null;
      return{
        grain:best,score:bestScore,shift,
        // The pitch this grain will actually sound at: its own measurement plus an exact
        // fractional shift. Null when the grain has no measured pitch to move.
        pitchSemitones:best.pitchSemitones==null?null:best.pitchSemitones+(shift||0)
      };
    }
  };
}

// Assemble a window of grains: a density in grains per second becomes seeded onset times,
// each filled by the selector. Times are seconds from the window start, so the caller maps
// them onto whatever clock position the ensemble is at.
export function planGrainCloud(index,{
  seconds=1,grainsPerSecond=8,pitches=[],selector=null,random=unitRandom,jitter=.35,maxGrains=512,...options
}={}){
  const span=Math.max(0,Number(seconds)||0),rate=Math.max(0,Number(grainsPerSecond)||0);
  if(!span||!rate)return [];
  const picker=selector||createGrainSelector(index,{random,...options}),
    interval=1/rate,spread=Math.max(0,Math.min(1,Number(jitter)||0)),events=[];
  let at=0;
  while(at<span&&events.length<Math.max(1,maxGrains)){
    const chosen=picker.select({pitches});
    events.push({
      at,grain:chosen.grain,shift:chosen.shift,pitchSemitones:chosen.pitchSemitones,
      durationSeconds:Math.min(chosen.grain.durationSeconds,span-at)
    });
    at+=interval*(1+(random()*2-1)*spread);
  }
  return events;
}
