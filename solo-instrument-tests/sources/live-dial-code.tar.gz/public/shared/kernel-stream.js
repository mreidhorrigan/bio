// A compact kernel stream (the extreme-aesthetics report's §7.3 and M2): a sound kernel repeated at a rate, an
// extratone kick at 30 Hz, a pulsar train, a tremolo of grains, sent as one program and realized a window at a time,
// never one message per kernel for its whole length.
//
// **Its rate is its own** (§2.1): hertz, constant or gliding in straight lines between points, not a tempo. Kernel k
// sounds where the stream's phase, the integral of its rate, reaches k. The instants are found in closed form per
// segment, so a window's kernels are the same however the stream is cut into windows (E22). The rate is bounded, a
// segment may glide steeply or not at all, and no division by zero follows (E23).
//
// **It is electronic** (§8.2): its kernels have no limbs, and it is never a loophole for a fill a drummer could not
// play. A window holding more kernels than the renderer takes, or kernels closer than one sample, is refused
// explicitly (E24), unless the program authorizes an aggregate (heard as fused texture), which the result says. It is
// never a silent merge.
//
// **Its variation is reproducible** (the rudiments report's T29): a kernel's jitter comes from the stream's seed and the
// kernel's index, whatever window it falls in.

// ---- Choices ---------------------------------------------------------------------------------------------------------
export const KERNEL_STREAM=Object.freeze({
  // The fastest rate a stream may ask (Hz), the most kernels one window may realize, and the most rate points.
  maxRateHz:400,maxWindowKernels:2048,maxPoints:256,
  // The renderer's resolution: kernels closer than a sample at this rate cannot be told apart.
  sampleRate:48000,
});
const EPSILON=1e-12;

// A stream: {id, kernel ({kind: 'drum' | 'tone' | 'noise', piece?, pitch?, instrument? (a tone's articulation.js family,
// synthPluck unless named), seconds}), start (s), duration (s), rate
// ({hz} or {points: [[seconds from start, hz], ...]}), jitterSeconds, seed, gainDb, accent ({every, gainDb})?,
// aggregate (true: a window past the renderer's resolution may be realized as fused texture)}. Validated, frozen.
export function kernelStream({id,kernel,start=0,duration,rate,jitterSeconds=0,seed=1,gainDb=0,accent=null,aggregate=false,choices=KERNEL_STREAM}){
  if(typeof id!=='string'||!id)throw new TypeError('a stream has an id');
  if(!kernel||!['drum','tone','noise'].includes(kernel.kind)||!(kernel.seconds>0))throw new TypeError('a stream\'s kernel: drum, tone or noise, of a positive length');
  if(kernel.instrument!==undefined&&(kernel.kind!=='tone'||typeof kernel.instrument!=='string'||!kernel.instrument))throw new TypeError('only a tone kernel names an instrument, by its family');
  if(!(Number.isFinite(start)&&duration>0))throw new RangeError('a stream starts and lasts a positive time');
  const points=rate?.points??(Number.isFinite(rate?.hz)?[[0,rate.hz],[duration,rate.hz]]:null);
  if(!points||points.length<2||points.length>choices.maxPoints)throw new RangeError(`a rate is {hz} or 2 to ${choices.maxPoints} points`);
  for(let i=0;i<points.length;i++){
    const [at,hz]=points[i];
    if(!(Number.isFinite(at)&&hz>0&&hz<=choices.maxRateHz))throw new RangeError(`a rate point is [seconds, hz] with 0 < hz <= ${choices.maxRateHz}`);
    if(i>0&&!(at>=points[i-1][0]))throw new RangeError('rate points in time order');
  }
  if(points[0][0]!==0||points.at(-1)[0]<duration-EPSILON)throw new RangeError('a rate covers the stream, from 0 to its duration');
  // Jitter moves a kernel less than half the shortest gap, so kernels never swap places (E23).
  const fastest=Math.max(...points.map(([,hz])=>hz));
  if(!(jitterSeconds>=0&&jitterSeconds<1/(2*fastest)))throw new RangeError(`jitter from 0 to under half the shortest gap (${1/(2*fastest)} s), so kernels keep their order`);
  if(accent&&!(Number.isInteger(accent.every)&&accent.every>0&&Number.isFinite(accent.gainDb)))throw new RangeError('an accent every so many kernels, by so many dB');
  return Object.freeze({id,kernel:Object.freeze({...kernel}),start,duration,points:Object.freeze(points.map(point=>Object.freeze([...point]))),
    jitterSeconds,seed,gainDb,accent:accent?Object.freeze({...accent}):null,aggregate:Boolean(aggregate),provenance:'electronic'});
}

// The stream's phase (kernels counted) at a time from its start: the integral of its rate, in closed form.
function phaseAt(points,t){
  let phase=0;
  for(let i=1;i<points.length;i++){
    const [t0,r0]=points[i-1],[t1,r1]=points[i];
    if(t<=t0)break;
    const span=Math.min(t,t1)-t0,slope=t1>t0?(r1-r0)/(t1-t0):0;
    phase+=r0*span+slope*span*span/2;
    if(t<=t1)break;
  }
  return phase;
}
// The time from the start at which the phase reaches `target`, within segment i (its phase at its start `base`).
function timeInSegment(points,i,base,target){
  const [t0,r0]=points[i-1],[t1,r1]=points[i],slope=t1>t0?(r1-r0)/(t1-t0):0,need=target-base;
  if(Math.abs(slope)<EPSILON)return t0+need/r0;
  // r0·x + slope·x²/2 = need, the root with x >= 0, in the form that loses no precision as slope nears zero.
  return t0+2*need/(r0+Math.sqrt(Math.max(0,r0*r0+2*slope*need)));
}
// A kernel's jitter: uniform in ±jitterSeconds, from the seed and the kernel's index alone.
function jitterOf(stream,index){
  if(!stream.jitterSeconds)return 0;
  let h=(Math.imul(stream.seed|0,0x9E3779B1)^Math.imul(index+1,0x85EBCA77))>>>0;
  h=Math.imul(h^(h>>>15),0x2C1B3C6D)>>>0;h=Math.imul(h^(h>>>12),0x297A2D39)>>>0;h=(h^(h>>>15))>>>0;
  return (h/0x100000000*2-1)*stream.jitterSeconds;
}

// How many voices the stream keeps sounding where it is fastest (§6.3: expected active tails ≈ attack rate × tail): an
// estimate of the renderer's occupancy, not of what is heard. Each drum or noise kernel is a voice of its own, the ones
// before ringing on (rate × length); a tone kernel of one pitch is the same key struck again, which lets the last one
// go, so it holds about one voice and its release, however fast it repeats. {voices, model}
export function expectedVoices(stream){
  const fastest=Math.max(...stream.points.map(([,hz])=>hz));
  return stream.kernel.kind==='tone'?Object.freeze({voices:1,model:'one key, struck again'})
    :Object.freeze({voices:fastest*stream.kernel.seconds,model:'each kernel a voice, the ones before ringing on'});
}

// The kernels sounding in [from, to) (seconds, the stream's own clock), in order:
// {status: 'ok' | 'aggregate' | 'refused', kernels: [{index, seconds, gainDb}], reason?}.
// Kernel k is placed by its phase, then its own jitter, so a window's kernels match the whole stream's.
export function expandStream(stream,{from,to},{choices=KERNEL_STREAM}={}){
  if(!(Number.isFinite(from)&&to>from))throw new RangeError('a window from a time to a later one');
  const lo=Math.max(from,stream.start),hi=Math.min(to,stream.start+stream.duration);
  if(!(hi>lo))return {status:'ok',kernels:[]};
  const points=stream.points,a=lo-stream.start,b=hi-stream.start,first=Math.ceil(phaseAt(points,a)-EPSILON),last=Math.ceil(phaseAt(points,b)-EPSILON)-1;
  const count=Math.max(0,last-first+1);
  // The renderer's resolution: too many kernels, or kernels closer than a sample.
  const fastest=Math.max(...points.map(([,hz])=>hz)),tooClose=1/fastest<1/choices.sampleRate;
  if(count>choices.maxWindowKernels||tooClose){
    const reason=count>choices.maxWindowKernels?`${count} kernels in the window, more than the renderer takes (${choices.maxWindowKernels})`:`kernels closer than a sample at ${choices.sampleRate} Hz`;
    return stream.aggregate?{status:'aggregate',kernels:[],reason:`${reason}: realized as fused texture, as the program allows`}:{status:'refused',kernels:[],reason};
  }
  const kernels=[];let segment=1,base=0;
  for(let k=first;k<=last;k++){
    // The segment the kernel's phase falls in, and the phase at its start.
    while(segment<points.length-1&&phaseAt(points,points[segment][0])<=k+EPSILON){base=phaseAt(points,points[segment][0]);segment++}
    const at=timeInSegment(points,segment,base,k),seconds=stream.start+at+jitterOf(stream,k);
    const accented=stream.accent&&k%stream.accent.every===0;
    kernels.push({index:k,seconds,gainDb:stream.gainDb+(accented?stream.accent.gainDb:0)});
  }
  return {status:'ok',kernels};
}
