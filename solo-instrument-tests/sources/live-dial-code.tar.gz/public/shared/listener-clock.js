// The clock a listener schedules itself on. LiveDesk, LiveAutoMix, LoopGuard and LiveModulation
// sample and decide on timers; live those are setInterval on the wall clock, which is fine in a
// page and impossible in an offline render, where the audio graph has no wall clock — a timer
// that fires on real time would sample audio that has not been rendered, or was rendered long
// ago. So the scheduling is a seam: `{every(ms, fn) → cancel, now() → seconds}`. This is the
// default, today's behaviour exactly; an offline engine passes one that runs on render time
// (render/node/render-timers.mjs renderClock(), the chrome engine's suspend points).
//
// `owner` is whatever has the audio `context` (the listener itself, whose `context` getter
// reaches its mixer's), read lazily because a listener may be built before its mixer plays.
export function wallClock(owner=null){
  return {
    every(ms,fn){const timer=setInterval(fn,ms);return ()=>clearInterval(timer)},
    now(){return owner?.context?.currentTime??0},
  };
}
