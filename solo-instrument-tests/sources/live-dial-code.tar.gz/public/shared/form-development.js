// How far through its form a plan is. A form placed in bars (the clock and the plan both say where they are in bars) is
// walked section by section, each at its own phrase length (mh_PlexBOT's sections carry one), else the plan's, else the
// clock's. Dividing every bar played by one phrase length put bar 4 of two two-bar phrases followed by eight-bar ones
// back in the first section (the mathematical audit's B10). The sections already played are fixed, so revising a later
// one never reinterprets them. Without bars, the transport's phrase count.
export function formProgress(plan,clock={}){
  const sections=plan?.payload?.sections||[],phrasesOf=section=>Math.max(1,Number(section?.phrases)||1),
    total=sections.reduce((sum,section)=>sum+phrasesOf(section),0),
    fallbackBars=Math.max(1,Number(plan?.payload?.phraseBars)||Number(clock.meter?.phraseBars)||1),
    barsOf=section=>Math.max(1,Number(section?.phraseBars)||fallbackBars),
    barBased=Number.isFinite(Number(clock.bar))&&Number.isFinite(Number(plan?.appliesAt?.bar));
  let local=0,cursor=0,index=0;
  if(barBased){
    let bars=Math.max(0,Number(clock.bar)-Number(plan.appliesAt.bar));
    if(!sections.length)local=Math.floor(bars/fallbackBars);
    for(;index<sections.length;index++){
      const span=phrasesOf(sections[index])*barsOf(sections[index]);
      if(bars<span||index===sections.length-1){local=cursor+Math.floor(bars/barsOf(sections[index]));break}
      bars-=span;cursor+=phrasesOf(sections[index]);
    }
  }else{
    local=Math.max(0,Math.max(0,Number(clock.phrase)||0)-(Number(plan?.appliesAt?.phrase)||0));
    for(;index<sections.length-1;index++){const length=phrasesOf(sections[index]);if(local<cursor+length)break;cursor+=length}
  }
  index=Math.min(index,Math.max(0,sections.length-1));
  const section=sections[index]||null,length=phrasesOf(section);
  return{formPlanId:plan?.planId||null,revision:plan?.revision||1,phrase:local,totalPhrases:total,sectionIndex:index,sectionRole:section?.role||null,sectionProgress:Math.min(1,Math.max(0,(local-cursor)/length)),overallProgress:total?Math.min(1,local/total):0};
}
export function reviseFutureForm(plan,clock,adjustment={}){
  const sections=(plan?.payload?.sections||[]).map(section=>({...section})),progress=formProgress(plan,clock),operation=adjustment.operation||'extend-current';
  if(operation==='extend-current'&&sections[progress.sectionIndex])sections[progress.sectionIndex].phrases=Math.max(1,Number(sections[progress.sectionIndex].phrases)||1)+Math.max(1,Number(adjustment.phrases)||1);
  else if(operation==='insert-next'){sections.splice(progress.sectionIndex+1,0,{role:adjustment.role||'development',phrases:Math.max(1,Number(adjustment.phrases)||1),rationale:adjustment.rationale||'Inserted during performance in response to ensemble development.'})}
  else if(operation==='replace-future'&&Array.isArray(adjustment.sections))sections.splice(progress.sectionIndex+1,Infinity,...adjustment.sections.map(section=>({...section})));
  else throw new TypeError(`Unsupported form adjustment: ${operation}`);
  return{...plan.payload,sections,adjustment:{...adjustment,at:progress}};
}
