const LIVE_DENOMINATORS = Object.freeze([1, 2, 4, 8, 16]);

const integer = (value, fallback) => {
  value = Number(value);
  return Number.isInteger(value) && value > 0 ? value : fallback;
};

/**
 * Translate a Musebot meter and tempo into the time signature and tempo that make Live's bars and beats fall where
 * the ensemble's do.
 *
 * The two count tempo differently. Every Musebot clock (server.js, public/client-ensemble.js,
 * public/render/transport.js) ticks every 60 / bpm / subdivision seconds and ends a bar after numerator x subdivision
 * ticks: `bpm` is PULSES a minute and a bar is `numerator` pulses long, whatever the denominator says. The denominator
 * is notation. Live counts its tempo in quarter notes whatever the signature, so a pulse written as a 1/d note lasts
 * (4 / d) x 60 / tempo there. For the two to agree on a signature of n/d, Live's tempo has to be bpm x 4 / d: an
 * ensemble playing 5/8 at 96 appears in Live as 5/8 at 48, and its bars last the same 3.125 seconds. (Until 19
 * September 2026 this assumed the ensemble counted quarter notes too, which put Live's bars at twice the speed of the
 * bots' in any /8 meter. Nobody saw it because only a PlexBOT loaded in Live ever wrote to Live.)
 *
 * The numerator is a musical pulse count, not a fraction to reduce: ten pulses stay ten pulses. A denominator Live
 * cannot show (it has 1, 2, 4, 8 and 16) becomes the nearest one it can, and the tempo is what keeps each pulse and
 * the whole bar the length they are: 10/5 at 120 becomes 10/4 at 120. A tempo outside Live's 20-999 moves to the
 * next nearest denominator instead: 7/16 at 60 would need a tempo of 15, so it becomes 7/8 at 30. A numerator above
 * Live's 99 is cut to 99 and the tempo keeps the bar's length.
 */
export function translateMeterForLive(meter = {}, bpm = 120) {
  const sourceNumerator = integer(meter.numerator, 4);
  const sourceDenominator = integer(meter.denominator, 4);
  const sourceBpm = Math.max(1, Number(bpm) || 120);
  const barDurationSeconds = (sourceNumerator * 60) / sourceBpm;
  const numerator = Math.min(99, sourceNumerator);
  // A bar of numerator/denominator in Live lasts numerator x (4 / denominator) x 60 / tempo seconds.
  const tempoFor = (denominator) => (numerator * 4 * 60) / (denominator * barDurationSeconds);
  const representation =
    LIVE_DENOMINATORS.map((denominator) => ({
      denominator,
      tempo: tempoFor(denominator),
      distance: Math.abs(Math.log2(denominator / sourceDenominator)),
    }))
      .filter((candidate) => candidate.tempo >= 20 && candidate.tempo <= 999)
      .sort(
        (left, right) =>
          left.distance - right.distance ||
          Math.abs(Math.log2(left.denominator / 4)) - Math.abs(Math.log2(right.denominator / 4)),
      )[0] || { denominator: 4, tempo: Math.max(20, Math.min(999, tempoFor(4))) };
  return {
    numerator,
    denominator: representation.denominator,
    tempo: representation.tempo,
    source: {
      numerator: sourceNumerator,
      denominator: sourceDenominator,
      tempo: sourceBpm,
    },
    tempoAdjusted: Math.abs(representation.tempo - sourceBpm) > 1e-9,
    barDurationSeconds,
  };
}

export { LIVE_DENOMINATORS };
