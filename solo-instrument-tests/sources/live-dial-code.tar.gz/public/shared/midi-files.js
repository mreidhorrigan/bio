// JZZ owns file parsing/writing. Musebots owns timebase, metadata and direct
// exchange. MIDI 1 conversion is an import adapter, never the stored note model.
import {JZZ,DEFAULT_TPQ,deserializeUMP,serializeUMP,umpPacket,timedUMP,initializeMidi2} from './ump.js';
import {frozenJson,knownFields} from './planning-data.js';

const fromMessage=message=>deserializeUMP(Uint8Array.from(message));
const bytesOf=data=>typeof data==='string'?Uint8Array.from(data,c=>c.charCodeAt(0)):data instanceof Uint8Array?data:new Uint8Array(data);
function checkedFile(data) {
  const bytes=bytesOf(data);
  if(!bytes.length||bytes.length>32*1024*1024)throw new RangeError('MIDI file must contain 1 byte to 32 MB');
  return bytes;
}
let nextFile=1;
const fileId=name=>`import:${name||'motif'}:${globalThis.crypto?.randomUUID?.()||`${Date.now().toString(36)}:${nextFile++}`}`;

export function importMidi2Clip(data,{name='Imported MIDI 2 motif',motifId=fileId(name),author='import'}={}) {
  const bytes=checkedFile(data),clip=new JZZ.MIDI.Clip(bytes);
  const warnings=clip.validate()||[];
  // JZZ deliberately recovers damaged files. Imports must not quietly accept a
  // missing/truncated packet, header, or ending as a lossless successful import.
  if(warnings.some(w=>/Incomplete|No Start|No End|Missing Ticks|Bad Ticks|Unexpected|Repeated Start|Repeated End/i.test(w.msg)))
    throw new Error(`Invalid MIDI Clip: ${warnings.map(w=>w.msg).join('; ')}`);
  const events=Array.from(clip).filter(m=>!m.isEndClip()).map(m=>({time:m.tt,packet:fromMessage(m)}));
  const header=Array.from(clip.header).map(m=>({time:m.tt,packet:Array.from(fromMessage(m))}));
  return {schemaVersion:2,motifId,metadata:{name,author,sourceFormat:'midi2-clip',clipHeader:header,
    endTime:clip.at(-1)?.tt||0,importWarnings:warnings.map(w=>w.msg)},
    timebase:{ticksPerQuarterNote:clip.ppqn},events:timedUMP(events)};
}

// maxEvents is the caller's, because the ceiling that suits a browser holding a
// motif is not the one that suits a renderer writing a whole performance: a
// three-minute pad carrying per-note vibrato runs to six figures of packets.
// JZZ's Clip.add finds its insertion point by scanning from index 0, so adding a
// whole performance in time order is quadratic: 64k events take 1.9 s, and a
// 326k-event pad carrying per-note vibrato would take the better part of a
// minute. A render's events are already in time order, so they are appended
// directly and the end marker kept last, which is byte-identical (a test pins
// that against add()) and linear. Anything out of order takes the slow path,
// because then the sorting add() does is the whole point of calling it.
// timedUMP has already refused anything out of order, so appending IS sorted
// insertion here; add() is kept as the path for a clip shape this does not
// recognise.
// A Delta Clockstamp is 20 bits, so consecutive events can be at most 1,048,575 ticks apart -- 58 seconds at 112 bpm
// and 9600 PPQN -- and JZZ writes exactly one per event, so a longer silence could not be written at all: a performer
// rested by mh_ManageBOT for a minute, or one that first plays two minutes in, lost its whole clip. The format's own
// answer is a NOOP utility message partway across: it means nothing and carries the clock forward. Fillers go before
// a late first event, between distant ones, and before an end marker that sits long after the last note.
const MAX_DELTA_TICKS=0xfffff;
function bridge(entries,from,to){
  for(let at=from+MAX_DELTA_TICKS;at<to;at+=MAX_DELTA_TICKS){const filler=JZZ.UMP.noop();filler.tt=at;entries.push(filler)}
}
function appendClip(clip,events,add,endTime=0){
  const entries=clip._orig;
  if(typeof entries?.push!=='function'||typeof entries?.pop!=='function'){
    for(const event of events)add(clip,event);
    clip.at(-1).tt=Math.max(clip.at(-1).tt,endTime);
    return;
  }
  const last=entries.length?entries[entries.length-1]:null,
    end=last?.isEndClip?.()?entries.pop():null;
  let previous=0;
  for(const event of events){bridge(entries,previous,event.time);add(clip,event,entries);previous=event.time}
  if(end){
    end.tt=Math.max(end.tt||0,previous,endTime);
    bridge(entries,previous,end.tt);
    entries.push(end);
  }
}

export function exportMidi2Clip(motif,{maxEvents}={}) {
  const clip=new JZZ.MIDI.Clip(),tpq=motif.timebase?.ticksPerQuarterNote||DEFAULT_TPQ;
  if(!Number.isInteger(tpq)||tpq<1||tpq>65535)throw new RangeError('MIDI Clip ticks per quarter note must be 1..65535');
  clip.ppqn=tpq;
  const add=(target,event,entries)=>{
    if(!Number.isSafeInteger(event.time)||event.time<0)throw new RangeError('Clip timestamps must be integer ticks; rescale the timebase explicitly before export');
    const message=JZZ.UMP(Array.from(serializeUMP(event.packet)));
    if(message.isDelta()||message.isTicksPQN()||message.isStartClip()||message.isEndClip())
      throw new Error('Clip structural messages belong in the timebase/header, not musical events');
    // `entries` is the append path: the same message, stamped and pushed.
    if(entries){message.tt=event.time;entries.push(message)}
    else target.add(event.time,message);
  };
  for(const event of motif.metadata?.clipHeader||[])add(clip.header,event);
  appendClip(clip,timedUMP(motif.events,maxEvents?{maxEvents}:{}),add,Number(motif.metadata?.endTime)||0);
  return clip.toUint8Array();
}

export async function midi1Converter(options) {
  return midi1StreamConverter(await initializeMidi2(options));
}

export function midi1StreamConverter(codec) {
  if(typeof codec?.fromMidi1!=='function')throw new TypeError('An initialized MIDI 2 codec is required');
  const channels=Array.from({length:16},()=>({bank:[0,0],bankSet:false,rpn:[127,127],nrpn:[127,127],kind:null,msb:null,pendingTime:null}));
  let converted=[];
  const container=JZZ.M1M2().connect(message=>converted.push(fromMessage(message)));
  const parameter=(state,channel,time,lsb=0)=>{
    if(!state.kind||state.msb===null)return [];
    const selected=state[state.kind];if(selected[0]===127&&selected[1]===127)return [];
    const data=(state.msb<<7)|lsb,low=data&8191;
    const value=((data<<18)|(data>8192?(low<<5)|(low>>>8):0))>>>0;
    return [{time,packet:fromMessage(JZZ.UMP[state.kind==='rpn'?'umpRPN':'umpNRPN'](0,channel,...selected,value))}];
  };
  const flush=(state,channel)=>{
    if(state.pendingTime===null)return [];
    const output=parameter(state,channel,state.pendingTime);state.pendingTime=null;return output;
  };
  function convert(message,time) {
    converted=[];let before=[];
    if(message[0]>=0x80&&message[0]<0xf0) {
      const channel=message[0]&15,status=message[0]>>4,state=channels[channel],number=message[1],value=message[2];
      if(status===11) {
        if(number===0||number===32){state.bank[number===0?0:1]=value;state.bankSet=true;return flush(state,channel)}
        if([101,100,99,98].includes(number)){
          before=flush(state,channel);state.kind=number>=100?'rpn':'nrpn';
          state[state.kind][number===101||number===99?0:1]=value;return before;
        }
        if(number===6){before=flush(state,channel);state.msb=value;state.pendingTime=time;return before}
        if(number===38){state.pendingTime=null;return parameter(state,channel,time,value)}
        // CC96/97 remain Control Change. They must not be reinterpreted as
        // MIDI 2 relative RPN/NRPN (UMP Appendix D.3.3).
      }
      before=flush(state,channel);
      if(status===12&&state.bankSet)return [...before,{time,packet:fromMessage(JZZ.UMP.umpProgram(0,channel,number,...state.bank))}];
      const raw=(0x20000000|(message[0]<<16)|(message[1]<<8)|(message[2]||0))>>>0;
      const packet=codec.fromMidi1(raw);if(!packet)throw new Error('Unsupported MIDI 1 channel voice message');
      return [...before,{time,packet}];
    }
    container.send(message);return converted.map(packet=>({time,packet}));
  }
  convert.flush=()=>channels.flatMap((state,channel)=>flush(state,channel));
  // Live harmonic replay needs these persistent selections as well as note
  // state. This checkpoint covers the adapter's MIDI 1 channel conversion;
  // it is not a parser checkpoint for fragmented SysEx or a file byte stream.
  convert.channelCheckpoint=()=>frozenJson({version:1,kind:'midi1-channel-conversion',channels}).data;
  convert.restoreChannelCheckpoint=value=>{
    knownFields(value,['version','kind','channels'],'MIDI 1 channel checkpoint');
    if(value.version!==1||value.kind!=='midi1-channel-conversion'||!Array.isArray(value.channels)||value.channels.length!==16)
      throw new TypeError('Invalid MIDI 1 channel checkpoint');
    const byte=value=>Number.isInteger(value)&&value>=0&&value<=127;
    const restored=value.channels.map(state=>{
      knownFields(state,['bank','bankSet','rpn','nrpn','kind','msb','pendingTime'],'MIDI 1 channel state');
      if(['bank','rpn','nrpn'].some(key=>!Array.isArray(state[key])||state[key].length!==2||!state[key].every(byte))||
        typeof state.bankSet!=='boolean'||![null,'rpn','nrpn'].includes(state.kind)||
        !(state.msb===null||byte(state.msb))||!(state.pendingTime===null||Number.isFinite(state.pendingTime))||
        state.pendingTime!==null&&state.msb===null)throw new TypeError('Invalid MIDI 1 channel state');
      return {...state,bank:[...state.bank],rpn:[...state.rpn],nrpn:[...state.nrpn]};
    });
    // Validate all channels before changing any live state.
    channels.splice(0,channels.length,...restored);converted=[];
  };
  return convert;
}

export async function importMidi1File(data,{name='Imported MIDI motif',author='import',...codecOptions}={}) {
  const smf=new JZZ.MIDI.SMF(checkedFile(data)),warnings=smf.validate()||[];
  if(warnings.some(w=>/Incomplete|Bad header|Unexpected end/i.test(w.msg)))throw new Error(`Invalid MIDI file: ${warnings.map(w=>w.msg).join('; ')}`);
  const tracks=Array.from(smf).filter(track=>track.type==='MTrk'||Array.isArray(track));
  const groups=smf.type===2?tracks.map(track=>[track]):[tracks],motifs=[];
  for(let sequence=0;sequence<groups.length;sequence++) {
    const convert=await midi1Converter(codecOptions),events=[],metadataEvents=[],sysex=new Map();
    const source=groups[sequence].flatMap((track,trackIndex)=>Array.from(track).map((message,index)=>({message,trackIndex,index})))
      .sort((a,b)=>a.message.tt-b.message.tt||a.trackIndex-b.trackIndex||a.index-b.index);
    const tpq=smf.ppqn||DEFAULT_TPQ;
    let previous=0,musicalTicks=0,microsPerQuarter=500000,endTime=0;
    for(const {message,trackIndex} of source) {
      let time=message.tt;
      if(!smf.ppqn) {
        const fps=smf.fps===29?30000/1001:smf.fps;
        musicalTicks+=(time-previous)/(fps*smf.ppf)*1e6/microsPerQuarter*tpq;
        previous=time;time=Math.round(musicalTicks);
      }
      endTime=Math.max(endTime,time);
      if(message.ff!==undefined) {
        metadataEvents.push({time,track:trackIndex,type:message.ff,data:Array.from(message.dd||'',c=>c.charCodeAt(0))});
        if(message.ff===0x51) {
          microsPerQuarter=message.getTempo();
          events.push({time,packet:fromMessage(JZZ.UMP.umpTempo(0,microsPerQuarter*100))});
        } else if(message.ff===0x58) {
          const data=Array.from(message.dd,c=>c.charCodeAt(0));
          if(data.length>=2)events.push({time,packet:fromMessage(JZZ.UMP.umpTimeSignature(0,`${data[0]}/${2**data[1]}`))});
        }
        continue;
      }
      let input=message;
      if(message[0]===0xf0||message[0]===0xf7) {
        if(message[0]===0xf0)sysex.set(trackIndex,[0xf0]);
        const pending=sysex.get(trackIndex);
        if(!pending)throw new Error('Standalone SMF F7 escape is not a complete MIDI message');
        pending.push(...message.slice(1));
        if(pending.at(-1)!==0xf7)continue;
        input=JZZ.MIDI(pending);sysex.delete(trackIndex);
      }
      events.push(...convert(input,time));
    }
    if(sysex.size)throw new Error('MIDI file ends inside a SysEx message');
    events.push(...convert.flush());events.sort((a,b)=>a.time-b.time);
    motifs.push({schemaVersion:2,motifId:fileId(name),timebase:{ticksPerQuarterNote:tpq},
      metadata:{name:groups.length>1?`${name} — sequence ${sequence+1}`:name,author,sourceFormat:'smf',
        sourceType:smf.type,endTime,sourceTimebase:smf.ppqn?{ppqn:smf.ppqn}:{fps:smf.fps,ppf:smf.ppf},
        smfMetadata:metadataEvents,importWarnings:warnings.map(w=>w.msg)},events:timedUMP(events)});
  }
  return motifs;
}

export async function importMidiFile(data,options={}) {
  const bytes=checkedFile(data),signature=String.fromCharCode(...bytes.slice(0,8));
  if(signature==='SMF2CLIP')return [importMidi2Clip(bytes,options)];
  if(signature.startsWith('MThd')||signature.startsWith('RIFF'))return importMidi1File(bytes,options);
  throw new Error('Choose a MIDI 2.0 Clip (.midi2) or Standard MIDI File (.mid/.midi).');
}
