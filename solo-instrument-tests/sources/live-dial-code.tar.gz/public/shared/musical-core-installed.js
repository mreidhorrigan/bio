// The bots' musical core in Rust (musical-core.js) installed wherever the bots are loaded: agents.js imports this
// first, so the live page, the offline renders in Node and in Chrome and the live band plan their counterpoint, canons,
// fugues' answers and profile audits in Rust -- the JavaScript's choices, the same from the same draws
// (test/musical-core-*.test.mjs), made faster. In Node it is compiled and installed as this module loads, before any bot
// plans; a page compiles it and installs it when it has it (pages that start bots wait for it: app.js, offline-page.js),
// from the bytes a bundle carries (globalThis.MUSEBOTS_WASM_ASSETS: the offline demo, the signal towers) or else
// fetched. Should it still not be had, the JavaScript plans, the same music, and the console says so once, where the
// host has one: the native plug-in's QuickJS has neither a console nor WebAssembly, and a warning there had stopped its
// bundle loading at all.
// -> musicalCoreReady: the core installed, or null.
import {loadMusicalCore,installMusicalCore,musicalCoreFrom} from './musical-core.js';

const declined=error=>{globalThis.console?.warn(`musical_core.wasm is not installed (${error?.message??error}): the JavaScript plans, the same choices`);return null};
const installed=core=>{installMusicalCore(core);return core};
export const MUSICAL_CORE_ASSET='wasm/musical-core/musical_core.wasm';

export const musicalCoreReady=(()=>{
  try{
    const carried=globalThis.MUSEBOTS_WASM_ASSETS?.[MUSICAL_CORE_ASSET];
    if(carried)return loadMusicalCore({bytes:Uint8Array.from(atob(carried),c=>c.charCodeAt(0))}).then(installed,declined);
    const url=new URL(`../${MUSICAL_CORE_ASSET}`,import.meta.url),fs=globalThis.process?.getBuiltinModule?.('node:fs');
    if(fs&&url.protocol==='file:')return Promise.resolve(installed(musicalCoreFrom(fs.readFileSync(url))));
    return loadMusicalCore({url}).then(installed,declined);
  }catch(error){return Promise.resolve(declined(error))}
})();
