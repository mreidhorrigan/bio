// Rhythm vocabulary: named cycles, exact durations, and streams in polymeter (RESEARCH_BACKLOG, the second queue: "the
// rhythm vocabulary's implementation"; research/rhythm-vocabulary-and-polymeter.md).
//
// Three layers, kept apart as the specification asks:
// - **Durations, exact.** A span is a positive rational, and a cycle is a tree of spans: a leaf, a sequence, a division
//   of its span by weights, a repeat. Unequal beats and nested tuplets close exactly, and need no fixed number of ticks
//   to a beat until they reach the clock (`spansOf`, `gridOf`).
// - **Named records**, each a cycle of a named tradition, with its source. A tala's record holds its components (the
//   angas of a Carnatic tala, the vibhags of a Hindustani taal) and their hand gestures. A clave's record holds its
//   onsets and its direction. A record is never inferred from a pattern: a Euclidean rhythm is not a clave because its
//   onsets match one. A tradition's terms (laghu and drutam; sam, tali and khali) stay with that tradition.
// - **The clock.** A record becomes a meter the ensemble's clock runs (`meterOfTala`, `withClave`), carrying the cycle's
//   gesture for each beat, so every bot hears it beat by beat (meter.cjs `clockContext`: `gesture`, `sam`). Streams in
//   polymeter run cycles of their own against the shared tick and re-align at a tick found exactly (`streamClock`,
//   `realignment`).

// ---- Exact rationals ------------------------------------------------------------------------------------------------
const gcd=(a,b)=>{a=Math.abs(a);b=Math.abs(b);while(b)[a,b]=[b,a%b];return a};
const lcm=(a,b)=>a/gcd(a,b)*b;
// A rational as [numerator, denominator] in lowest terms, the denominator positive. Takes [n, d], an integer, or "n/d".
export function ratio(value,denominator=1){
  let n=value,d=denominator;
  if(Array.isArray(value))[n,d]=value;
  else if(typeof value==='string'){const match=value.trim().match(/^(-?\d+)(?:\s*\/\s*(\d+))?$/);if(!match)throw new RangeError(`Not a rational: ${value}`);n=Number(match[1]);d=Number(match[2]??1)}
  if(!Number.isSafeInteger(n)||!Number.isSafeInteger(d)||d===0)throw new RangeError(`Not a rational: ${JSON.stringify(value)}`);
  if(d<0){n=-n;d=-d}
  const g=gcd(n,d)||1;
  return Object.freeze([n/g,d/g]);
}
export const add=(a,b)=>ratio(a[0]*b[1]+b[0]*a[1],a[1]*b[1]);
export const sub=(a,b)=>ratio(a[0]*b[1]-b[0]*a[1],a[1]*b[1]);
export const mul=(a,b)=>ratio(a[0]*b[0],a[1]*b[1]);
export const div=(a,b)=>ratio(a[0]*b[1],a[1]*b[0]);
export const compare=(a,b)=>a[0]*b[1]-b[0]*a[1];
export const toNumber=a=>a[0]/a[1];
const positive=(value,what)=>{const r=ratio(value);if(r[0]<=0)throw new RangeError(`${what} must be positive`);return r};

// ---- Duration trees -------------------------------------------------------------------------------------------------
// A node is one of:
//   {kind: 'leaf', duration, ...data}              a span, carrying whatever it names (a gesture, a label)
//   {kind: 'sequence', children}                   its children one after another
//   {kind: 'divide', duration, weights, children?} its span divided by rational weights; each child, or a leaf, takes
//                                                  its share (a tuplet: `weights: [1, 1, 1]` over a beat)
//   {kind: 'repeat', child, times}                 its child `times` over
// Placed in a span not its own (a divide's share), a node is scaled to fit it, so tuplets nest to any depth.
export function spanOf(node){
  if(node?.kind==='leaf')return positive(node.duration,'A leaf\'s duration');
  if(node?.kind==='sequence'){
    if(!Array.isArray(node.children)||!node.children.length)throw new RangeError('A sequence needs children');
    return node.children.reduce((sum,child)=>add(sum,spanOf(child)),ratio(0));
  }
  if(node?.kind==='divide')return positive(node.duration,'A division\'s duration');
  if(node?.kind==='repeat'){
    if(!Number.isSafeInteger(node.times)||node.times<1)throw new RangeError('A repeat needs a positive whole count');
    return mul(spanOf(node.child),ratio(node.times));
  }
  throw new RangeError(`Not a duration node: ${JSON.stringify(node)?.slice(0,80)}`);
}
// The leaves of a tree, each with its exact start and duration: [{start, duration, path, ...data}], `path` the child
// indices from the root. `start` and `span` place the tree (its own span, from 0, by default).
export function spansOf(node,{start=ratio(0),span=null,path=[]}={}){
  const own=spanOf(node),target=span??own,out=[];
  if(node.kind==='leaf'){const {kind,duration,...data}=node;out.push(Object.freeze({start,duration:target,path:Object.freeze([...path]),...data}));return out}
  if(node.kind==='sequence'){
    const scale=div(target,own);let at=start;
    node.children.forEach((child,index)=>{const length=mul(spanOf(child),scale);out.push(...spansOf(child,{start:at,span:length,path:[...path,index]}));at=add(at,length)});
    return out;
  }
  if(node.kind==='divide'){
    const weights=(node.weights??node.children?.map(()=>1)??[]).map(weight=>positive(weight,'A weight'));
    if(!weights.length)throw new RangeError('A division needs weights or children');
    if(node.children&&node.children.length!==weights.length)throw new RangeError('A division has a weight for each child');
    const total=weights.reduce(add,ratio(0));let at=start;
    weights.forEach((weight,index)=>{
      const length=mul(target,div(weight,total)),child=node.children?.[index]??{kind:'leaf',duration:length};
      out.push(...spansOf(child,{start:at,span:length,path:[...path,index]}));at=add(at,length);
    });
    return out;
  }
  const length=div(target,ratio(node.times));
  for(let k=0;k<node.times;k++)out.push(...spansOf(node.child,{start:add(start,mul(length,ratio(k))),span:length,path:[...path,k]}));
  return out;
}
// The coarsest grid every leaf's start and end falls on: {unit (a rational), total (the cycle in units), starts and
// lengths (in units)}. A clock plays the tree with `unit` as a tick.
export function gridOf(spans){
  const values=spans.flatMap(leaf=>[leaf.start,leaf.duration]).filter(value=>value[0]!==0);
  if(!values.length)throw new RangeError('Nothing to lay on a grid');
  const unit=ratio(values.reduce((g,value)=>gcd(g,value[0]),0),values.reduce((l,value)=>lcm(l,value[1]),1));
  const units=value=>{const count=div(value,unit);if(count[1]!==1)throw new RangeError('Off the grid');return count[0]};
  const last=spans.at(-1),total=units(add(last.start,last.duration));
  return Object.freeze({unit,total,starts:Object.freeze(spans.map(leaf=>units(leaf.start))),lengths:Object.freeze(spans.map(leaf=>units(leaf.duration)))});
}

// ---- Named records --------------------------------------------------------------------------------------------------
const KRISHNASWAMY_WELLS=Object.freeze({citation:'Jagdish A. Krishnaswamy and Robert Wells, "A Novel Generative Paradigm for Carnatic Rhythmic Composition", Analytical Approaches to Music of South Asia 1 (2023)',
  uri:'https://southasia.iftawm.org/wp-content/uploads/KrishnaswamyWells_Article.pdf',accessed:'2026-09-28'});
const TOUSSAINT=Object.freeze({citation:'Godfried T. Toussaint, The Geometry of Musical Rhythm: What Makes a "Good" Rhythm Good? (CRC Press, 2013), and "The Euclidean algorithm generates traditional musical rhythms", Bridges (2005)',
  uri:'https://cgm.cs.mcgill.ca/~godfried/publications/banff.pdf',accessed:'2026-09-28'});
const VURKAC=Object.freeze({citation:'Mehmet Vurkaç, "A Cross-Cultural Grammar for Temporal Harmony in Afro-Latin Musics: Clave, Partido-Alto and Other Timelines", Current Musicology 94 (2012)',
  uri:'https://doi.org/10.7916/cm.v0i94.5234',accessed:'2026-07-24'});
// The Hindustani structures are the standard ones Clayton's study sets out (sam, tali and khali; the theka), checked
// against the encyclopedia articles, whose own sources are thin (one each), as those articles say.
const CLAYTON=Object.freeze({citation:'Martin Clayton, Time in Indian Music: Rhythm, Metre, and Form in North Indian Rāg Performance (Oxford University Press, 2000)',uri:null,accessed:null});
const wikipedia=(title,accessed='2026-09-28')=>Object.freeze({citation:`"${title}", Wikipedia`,uri:`https://en.wikipedia.org/wiki/${title}`,accessed});

// A Carnatic nadai: the subdivisions of a beat at its first speed; each speed doubles them. Madhyama kala, the speed
// most reference calculations use, is the third (Krishnaswamy and Wells 2023, ¶¶16-20, Table 1).
export const NADAI=Object.freeze({caturasra:1,tisra:3,khanda:5,misra:7,sankirna:9,'sampurna-khanda':10});
export const nadaiSubdivisions=(nadai='caturasra',speed=3)=>{
  const base=NADAI[nadai];if(!base)throw new RangeError(`Unknown nadai: ${nadai}`);
  if(!Number.isInteger(speed)||speed<1||speed>6)throw new RangeError('A speed is 1 to 6');
  return base*2**(speed-1);
};

// The bols of the thekas here that sound the bayan (the resonant left-hand drum), and those that do not.
export const THEKA_BAYAN=Object.freeze({dha:true,dhin:true,dhi:true,ta:false,tin:false,ti:false,na:false});
const tala=(record)=>{
  const beats=record.components.reduce((sum,component)=>sum+component.beats,0);
  if(record.theka&&(record.theka.length!==beats||record.theka.some(bol=>!(bol in THEKA_BAYAN))))throw new RangeError(`${record.id}: a theka is a known bol for each beat`);
  return Object.freeze({kind:'tala',license:'metadata-only',...record,...(record.theka?{theka:Object.freeze([...record.theka])}:{}),
    components:Object.freeze(record.components.map(component=>Object.freeze({...component,gestures:component.gestures?Object.freeze([...component.gestures]):null})))});
};
const clave=(record)=>Object.freeze({kind:'clave',license:'metadata-only',...record,onsets:Object.freeze([...record.onsets])});

export const RHYTHM_VOCABULARY=Object.freeze(Object.fromEntries([
  // Ādi tāḷa: "8 beats of equal duration ... grouped into three angas of 4, 2, and 2 beats" (¶15). A laghu's beats are a
  // clap and finger counts from the little finger, a drutam's a clap and a wave (Figure 1, shown there for tisra
  // triputa's laghu of three: clap, pinky, ring).
  tala({id:'carnatic.adi',tradition:'Carnatic',name:'Ādi tāḷa',source:KRISHNASWAMY_WELLS,
    components:[{kind:'laghu',beats:4,gestures:['clap','pinky','ring','middle']},{kind:'drutam',beats:2,gestures:['clap','wave']},{kind:'drutam',beats:2,gestures:['clap','wave']}]}),
  // Tiśra tripuṭa tāḷa: "seven-beat cycles divided into angas of lengths 3, 2, and 2", each beat marked by its kriyā:
  // clap, pinky, ring; clap, wave; clap, wave (Figure 1).
  tala({id:'carnatic.tisra-triputa',tradition:'Carnatic',name:'Tiśra tripuṭa tāḷa',source:KRISHNASWAMY_WELLS,
    components:[{kind:'laghu',beats:3,gestures:['clap','pinky','ring']},{kind:'drutam',beats:2,gestures:['clap','wave']},{kind:'drutam',beats:2,gestures:['clap','wave']}]}),
  // Rūpaka tāḷa as the source takes it: "3 beats of equal duration" (¶15), "a 3-beat rhythmic cycle with 4 subdivisions
  // per beat" (¶3). The source gives no kriyās for it, so none are claimed.
  tala({id:'carnatic.rupaka',tradition:'Carnatic',name:'Rūpaka tāḷa',source:KRISHNASWAMY_WELLS,
    components:[{kind:'beats',beats:3,gestures:null}]}),
  // Miśra cāpu tāḷa, a cāpu tāḷa, "whose beats vary in duration" (¶12), as the source takes it: "one long beat (three
  // subdivisions) followed by two shorter beats (two subdivisions)", seven subdivisions a cycle (note 3; "miṣra cāpu
  // tāḷa in tiṣra naḍai, totalling 21 subdivisions per cycle"). Other artists count it as seven equal beats (note 3).
  // No kriyās are claimed.
  tala({id:'carnatic.misra-capu',tradition:'Carnatic',name:'Miśra cāpu tāḷa',source:KRISHNASWAMY_WELLS,
    components:[{kind:'long',beats:1,units:3,gestures:null},{kind:'short',beats:2,units:2,gestures:null}]}),
  // Hindustani taals: vibhags, each begun with a clap (tali; the cycle's first, sam, marked X) or a wave (khali, "empty",
  // marked 0), the other matras ungestured; and the theka, the taal's stroke names (bols) a matra each. Where a bol
  // sounds the bayan, the left-hand bass drum (dha, dhin, dhi), and where it does not (ta, tin, ti, na) is the theka's
  // own (THEKA_BAYAN), so a part's bass can follow it: the khali vibhag is where it thins.
  // Teentaal: 16 matras, 4+4+4+4, marked X 2 0 3.
  tala({id:'hindustani.teentaal',tradition:'Hindustani',name:'Tīntāl',source:[CLAYTON,wikipedia('Teental')],
    components:[{kind:'vibhag',role:'tali',marker:'X',beats:4,gestures:['sam',null,null,null]},{kind:'vibhag',role:'tali',marker:'2',beats:4,gestures:['tali',null,null,null]},
      {kind:'vibhag',role:'khali',marker:'0',beats:4,gestures:['khali',null,null,null]},{kind:'vibhag',role:'tali',marker:'3',beats:4,gestures:['tali',null,null,null]}],
    theka:['dha','dhin','dhin','dha','dha','dhin','dhin','dha','dha','tin','tin','ta','ta','dhin','dhin','dha']}),
  // Jhaptaal: 10 matras, 2+3+2+3, marked X 2 0 3.
  tala({id:'hindustani.jhaptaal',tradition:'Hindustani',name:'Jhaptāl',source:[CLAYTON,wikipedia('Jhaptal')],
    components:[{kind:'vibhag',role:'tali',marker:'X',beats:2,gestures:['sam',null]},{kind:'vibhag',role:'tali',marker:'2',beats:3,gestures:['tali',null,null]},
      {kind:'vibhag',role:'khali',marker:'0',beats:2,gestures:['khali',null]},{kind:'vibhag',role:'tali',marker:'3',beats:3,gestures:['tali',null,null]}],
    theka:['dhi','na','dhi','dhi','na','ti','na','dhi','dhi','na']}),
  // Clave: an orienting timeline with a direction, not five marked slots (Vurkaç 2012). Onsets on sixteen pulses, as
  // Toussaint writes them: son x..x..x...x.x..., rumba x..x...x..x.x..., bossa nova x..x..x...x..x... The 2-3 side is
  // the same timeline begun at its other half.
  clave({id:'afro-cuban.son-clave-3-2',tradition:'Afro-Cuban',name:'Son clave, 3-2',pulses:16,onsets:[0,3,6,10,12],direction:'3-2',source:[TOUSSAINT,VURKAC]}),
  clave({id:'afro-cuban.son-clave-2-3',tradition:'Afro-Cuban',name:'Son clave, 2-3',pulses:16,onsets:[2,4,8,11,14],direction:'2-3',source:[TOUSSAINT,VURKAC]}),
  clave({id:'afro-cuban.rumba-clave-3-2',tradition:'Afro-Cuban',name:'Rumba clave, 3-2',pulses:16,onsets:[0,3,7,10,12],direction:'3-2',source:[TOUSSAINT,VURKAC]}),
  clave({id:'afro-cuban.rumba-clave-2-3',tradition:'Afro-Cuban',name:'Rumba clave, 2-3',pulses:16,onsets:[2,4,8,11,15],direction:'2-3',source:[TOUSSAINT,VURKAC]}),
  clave({id:'brazilian.bossa-nova-clave',tradition:'Brazilian',name:'Bossa nova clave',pulses:16,onsets:[0,3,6,10,13],direction:null,source:[TOUSSAINT]}),
].map(record=>[record.id,record])));

export const vocabularyRecord=id=>{const record=RHYTHM_VOCABULARY[id];if(!record)throw new RangeError(`No rhythm vocabulary record ${id}`);return record};

// A tala's cycle as a duration tree: a sequence of its components, each a sequence of beats (leaves of one beat, each
// carrying its gesture and its component), each beat divided by the nadai's subdivisions when one is given.
// A cāpu tāḷa's beat lasts its `units` subdivisions, and is divided into as many times the nadai's.
export function talaTree(record,{subdivisions=null}={}){
  const beat=(component,index)=>{
    const units=component.units??1,leaf={kind:'leaf',duration:ratio(units),component:component.kind,gesture:component.gestures?.[index]??null},parts=units*(subdivisions||1);
    return parts>1?{kind:'divide',duration:ratio(units),weights:Array(parts).fill(1),children:Array.from({length:parts},(_,k)=>({...leaf,duration:ratio(1),...(k?{gesture:null}:{})}))}:leaf;
  };
  return {kind:'sequence',children:record.components.map(component=>({kind:'sequence',children:Array.from({length:component.beats},(_,index)=>beat(component,index))}))};
}
// A tala as the meter the ensemble's clock runs: its beats (aksharas, matras) the meter's beats, its components the
// groups, the nadai and speed the ticks to a beat, and each beat's gesture carried with it. The tempo counts beats.
// Each beat also carries its component's role (a Hindustani vibhag's, tali or khali) or kind (a Carnatic anga's: laghu,
// drutam). The nadai names a Carnatic subdivision; a Hindustani taal takes the same counts (caturasra: four a matra).
// A cāpu tāḷa's beats are unequal (a component's `units`, the subdivisions in each of its beats): its meter's beats are
// then the subdivisions, each beat of the tala a group of them, and a beat's gesture on its first subdivision.
export function meterOfTala(record,{nadai='caturasra',speed=3,denominator=4,phraseBars=4}={}){
  if(record?.kind!=='tala')throw new TypeError('Not a tala record');
  if(record.components.some(component=>(component.units??1)!==1))return unequalMeter(record,{nadai,speed,denominator,phraseBars});
  const groups=record.components.map(component=>component.beats),numerator=groups.reduce((a,b)=>a+b,0);
  const gestures=record.components.flatMap(component=>component.gestures??Array(component.beats).fill(null));
  const componentOfBeat=record.components.flatMap(component=>Array(component.beats).fill(component.role??component.kind));
  return {numerator,denominator,groups,subdivision:nadaiSubdivisions(nadai,speed),phraseBars,label:`${record.name} (${groups.join('+')})`,
    vocabulary:{id:record.id,tradition:record.tradition,name:record.name,gestures,componentOfBeat,nadai,speed,
      ...(record.theka?{bass:record.theka.map(bol=>THEKA_BAYAN[bol])}:{})}};
}
function unequalMeter(record,{nadai,speed,denominator,phraseBars}){
  const beats=record.components.flatMap(component=>Array.from({length:component.beats},(_,index)=>({units:component.units??1,kind:component.role??component.kind,gesture:component.gestures?.[index]??null})));
  const groups=beats.map(beat=>beat.units),numerator=groups.reduce((a,b)=>a+b,0);
  const gestures=beats.flatMap(beat=>[beat.gesture,...Array(beat.units-1).fill(null)]),componentOfBeat=beats.flatMap(beat=>Array(beat.units).fill(beat.kind));
  return {numerator,denominator,groups,subdivision:nadaiSubdivisions(nadai,speed),phraseBars,label:`${record.name} (${groups.join('+')})`,
    vocabulary:{id:record.id,tradition:record.tradition,name:record.name,gestures,componentOfBeat,nadai,speed,unequalBeats:true}};
}
// Unequal beats, by their rational weights ([1, 3/2, 1], or a cāpu tāḷa's beats of unequal subdivisions): the meter
// whose beats are the weights' common unit and whose groups are the beats. The notated denominator grows with the
// unit (half a quarter is an eighth), and the felt beats are the groups (meter-tactus.js feltBeats).
export function meterOfWeights(weights,{denominator=4,subdivision=1,phraseBars=4,label=null}={}){
  const spans=spansOf({kind:'sequence',children:weights.map(weight=>({kind:'leaf',duration:positive(weight,'A beat weight')}))}),grid=gridOf(spans);
  const scale=grid.unit[1]/grid.unit[0];
  if(!Number.isInteger(scale)||(denominator*scale)%1)throw new RangeError('A beat weight must divide a beat into whole units');
  return {numerator:grid.total,denominator:denominator*scale,groups:[...grid.lengths],subdivision,phraseBars,label:label??`${grid.lengths.join('+')}/${denominator*scale}`};
}
// A meter carrying a clave: its onsets on the bar's ticks (the clave's pulses must land on them), its direction and its
// record. -> a new meter.
export function withClave(meter,record){
  if(record?.kind!=='clave')throw new TypeError('Not a clave record');
  const pulses=(Number(meter.numerator)||4)*(Number(meter.subdivision)||4),scale=pulses/record.pulses;
  if(!Number.isInteger(scale))throw new RangeError(`${record.name}'s ${record.pulses} pulses do not fall on a bar of ${pulses} ticks`);
  return {...meter,rhythm:{...(meter.rhythm??{}),clave:record.onsets.map(onset=>onset*scale),direction:record.direction,vocabulary:record.id}};
}

// ---- Gestures through flat messages ---------------------------------------------------------------------------------
// OSC and the protocol's positional arguments carry flat lists: a cycle's gestures go as its id, then each beat's
// component and gesture ('-' where a beat has none), and come back as they were.
export function flattenGestures(vocabulary){
  const out=[String(vocabulary.id),vocabulary.gestures.length];
  vocabulary.gestures.forEach((gesture,index)=>out.push(String(vocabulary.componentOfBeat?.[index]??'-'),gesture??'-'));
  return out;
}
export function unflattenGestures(values){
  const [id,count,...rest]=values;
  if(!Number.isInteger(count)||rest.length!==2*count)throw new RangeError('A flattened cycle is its id, its beat count, and a component and gesture for each beat');
  const componentOfBeat=[],gestures=[];
  for(let k=0;k<count;k++){componentOfBeat.push(rest[2*k]==='-'?null:rest[2*k]);gestures.push(rest[2*k+1]==='-'?null:rest[2*k+1])}
  return {id,gestures,componentOfBeat};
}
// ---- Streams in polymeter -------------------------------------------------------------------------------------------
// A stream is a cycle of its own over the ensemble's shared tick: `cycleTicks` long, beginning at the shared tick
// `anchor`, its own meter for what its bots count. The shared clock is the only clock; a stream's place is computed
// from the shared tick, exactly, so streams never drift from each other.
export function streamOf(meter,{anchor=0,id=null}={}){
  const cycleTicks=(Number(meter.numerator)||4)*(Number(meter.subdivision)||4);
  if(!Number.isSafeInteger(anchor))throw new RangeError('A stream\'s anchor is a whole tick');
  return Object.freeze({id:id??meter.label??`${meter.numerator}/${meter.denominator}`,meter,cycleTicks,anchor});
}
// Where a stream is at the shared `tick`: its cycle (counted from its anchor; negative before it) and its tick in the
// cycle.
export function streamPosition(stream,tick){
  const since=tick-stream.anchor,cycle=Math.floor(since/stream.cycleTicks);
  return {cycle,tickInCycle:since-cycle*stream.cycleTicks};
}
// The first shared tick at or after `from` where every stream begins a cycle together, and how often they do: the
// least common multiple of their cycles, where their anchors allow one (a congruence solved exactly; null where they
// never meet, as cycles of 4 and 6 anchored an odd tick apart).
export function realignment(streams,{from=0}={}){
  let modulus=1,residue=0;
  for(const stream of streams){
    const m=stream.cycleTicks,r=((stream.anchor%m)+m)%m,g=gcd(modulus,m);
    if((r-residue)%g!==0)return null;
    // residue + modulus·k ≡ r (mod m): k ≡ (r - residue)/g · inverse(modulus/g) (mod m/g).
    const mg=m/g,k=mulMod(((r-residue)/g%mg+mg)%mg,inverse((modulus/g)%mg,mg),mg);
    residue=residue+modulus*k;modulus=modulus/g*m;residue=((residue%modulus)+modulus)%modulus;
  }
  const first=from<=residue?residue-Math.floor((residue-from)/modulus)*modulus:residue+Math.ceil((from-residue)/modulus)*modulus;
  return {every:modulus,at:first};
}
const mulMod=(a,b,m)=>Number((BigInt(a)*BigInt(b))%BigInt(m));
function inverse(a,m){
  if(m===1)return 0;
  let [r0,r1,s0,s1]=[a,m,1,0];
  while(r1){const q=Math.floor(r0/r1);[r0,r1]=[r1,r0-q*r1];[s0,s1]=[s1,s0-q*s1]}
  if(r0!==1)throw new RangeError('No inverse');
  return ((s0%m)+m)%m;
}
// The clock as a stream's bots hear it: its own meter, its cycle as the bar, its tick in the cycle as the tick in the
// bar, and its beat, group and gesture there; the shared tick unchanged. `clockContext` is meter.cjs's.
// Its tempo is its own beat's (2a, 28 September 2026). A beat is its meter's subdivision in shared ticks, and a tick
// lasts 60 / bpm / subdivision (meter-tactus.js secondsPerTick). So a stream whose beat is another number of ticks than
// the ensemble's plays at that ratio of the ensemble's tempo, a part's own metric modulation (tempoRatio, its beats'
// rate over the ensemble's), and its tick lasts exactly what the shared tick lasts. Before, a stream kept the ensemble's
// bpm under its own subdivision, and a bot timing notes from its stream's clock had ticks the wrong length wherever the
// two subdivisions differed. A stream of the ensemble's subdivision is as it was.
export function streamClock(clock,stream,clockContext){
  // (A clock that is already this stream's, as a bot's own interpretation hears one its host has given it.)
  if(clock.stream&&clock.stream.id===stream.id&&clock.stream.anchor===stream.anchor&&clock.stream.cycleTicks===stream.cycleTicks)return clock;
  const {cycle,tickInCycle}=streamPosition(stream,clock.tick);
  const shared=Number(clock.meter?.subdivision),own=Number(stream.meter?.subdivision),related=shared>0&&own>0&&shared!==own;
  const bpm=related?Number(clock.bpm)*shared/own:clock.bpm,g=related?gcd(shared,own):1;
  // (And where the ensemble stands, for what is the piece's rather than the part's: its ending, Closure's.)
  return {...clockContext({tick:clock.tick,bpm,meter:stream.meter,bar:cycle,tickInBar:tickInCycle}),
    stream:{id:stream.id,cycleTicks:stream.cycleTicks,anchor:stream.anchor,...(related?{tempoRatio:[shared/g,own/g]}:{})},
    ensemble:{bar:clock.bar,tickInBar:clock.tickInBar,meter:clock.meter}};
}
