// Exact rationals for the vocal path (docs/VOCALS.md): beat positions and pitch ratios.
//
// A rational is a frozen {n, d}: decimal-string integers, d > 0, n signed. They are BigInt underneath, so a 64-digit
// ratio from a tuning file and a 5/7-beat tuplet both survive every round trip untouched (report §7.1, §10.1: "large
// exact ratio strings without symbolic loss"; "no accumulated floating-point beat drift"). A rational is kept as it was
// written; reduce() is explicit, because 10/8 and 5/4 can be different spellings of the same interval.
//
// Input forms: {n, d} with integer strings or safe integers, "n/d", an integer, or a finite number, which is read as the
// decimal its author wrote (0.25 → 1/4, 1.5 → 3/2, 0.3333 → 3333/10000). A triplet is {n:1, d:3}, never 0.3333.
const INTEGER=/^-?(0|[1-9][0-9]*)$/;
const big=(text,label)=>{
  if(typeof text==='bigint')return text;
  if(typeof text==='number'){if(!Number.isSafeInteger(text))throw new RangeError(`${label} must be an integer`);return BigInt(text)}
  if(typeof text!=='string'||!INTEGER.test(text))throw new RangeError(`${label} must be a decimal integer string`);
  return BigInt(text);
};
const make=(n,d)=>{
  if(d===0n)throw new RangeError('A rational needs a non-zero denominator');
  if(d<0n){n=-n;d=-d}
  return Object.freeze({n:n.toString(),d:d.toString()});
};
function fromDecimal(value,label){
  if(!Number.isFinite(value))throw new RangeError(`${label} must be finite`);
  if(Number.isSafeInteger(value))return make(BigInt(value),1n);
  const text=String(value);
  if(/e/i.test(text))throw new RangeError(`${label} ${text} is too large or small to read as a decimal; give {n, d}`);
  const [whole,fraction='']=text.replace('-','').split('.'),sign=value<0?-1n:1n;
  return make(sign*BigInt(whole+fraction),10n**BigInt(fraction.length));
}
export function rational(value,label='value'){
  if(value&&typeof value==='object'&&'n' in value&&'d' in value)return make(big(value.n,`${label}.n`),big(value.d,`${label}.d`));
  if(typeof value==='string'&&value.includes('/')){
    const [n,d,...rest]=value.split('/');if(rest.length)throw new RangeError(`${label} must be n/d`);
    return make(big(n.trim(),`${label} numerator`),big(d.trim(),`${label} denominator`));
  }
  if(typeof value==='string')return make(big(value.trim(),label),1n);
  if(typeof value==='bigint')return make(value,1n);
  if(typeof value==='number')return fromDecimal(value,label);
  throw new TypeError(`${label} must be a rational ({n, d}, "n/d", or a number)`);
}
const parts=value=>{const r=rational(value);return[BigInt(r.n),BigInt(r.d)]};
const gcd=(a,b)=>{a=a<0n?-a:a;b=b<0n?-b:b;while(b){[a,b]=[b,a%b]}return a};
export function reduce(value){const [n,d]=parts(value),g=gcd(n,d)||1n;return make(n/g,d/g)}
export function add(a,b){const [an,ad]=parts(a),[bn,bd]=parts(b);return reduce(make(an*bd+bn*ad,ad*bd))}
export function subtract(a,b){const [an,ad]=parts(a),[bn,bd]=parts(b);return reduce(make(an*bd-bn*ad,ad*bd))}
export function multiply(a,b){const [an,ad]=parts(a),[bn,bd]=parts(b);return reduce(make(an*bn,ad*bd))}
export function divide(a,b){const [an,ad]=parts(a),[bn,bd]=parts(b);if(bn===0n)throw new RangeError('Division by zero');return reduce(make(an*bd,ad*bn))}
export function compare(a,b){const [an,ad]=parts(a),[bn,bd]=parts(b),left=an*bd,right=bn*ad;return left<right?-1:left>right?1:0}
export const equals=(a,b)=>compare(a,b)===0;
export const isPositive=value=>BigInt(rational(value).n)>0n;
export const isZero=value=>BigInt(rational(value).n)===0n;
export const ZERO=make(0n,1n),ONE=make(1n,1n);
// log2 of a positive BigInt to double precision, however many digits it has: the top 53 bits carry the mantissa.
export function log2Integer(value){
  const integer=big(value,'integer');if(integer<=0n)throw new RangeError('log2 needs a positive integer');
  const bits=integer.toString(2).length;
  if(bits<=53)return Math.log2(Number(integer));
  const shift=bits-53;return shift+Math.log2(Number(integer>>BigInt(shift)));
}
// |n|/d as a mantissa in [0.5, 2) and a binary exponent, from one integer division carried to 64 bits: exact to double
// precision whatever the size of the terms. (Subtracting two large logarithms is not: two 200-bit logs lose ~1e-14.)
function split(n,d){
  const magnitude=n<0n?-n:n,exponent=magnitude.toString(2).length-d.toString(2).length,shift=64-exponent;
  const scaled=shift>=0?(magnitude<<BigInt(shift))/d:magnitude/(d<<BigInt(-shift));
  return {mantissa:Number(scaled)*2**-64,exponent};
}
export function log2Rational(value){
  const r=rational(value),n=BigInt(r.n);if(n<=0n)throw new RangeError('log2 needs a positive rational');
  const {mantissa,exponent}=split(n,BigInt(r.d));
  return exponent+Math.log2(mantissa);
}
// The nearest double: one IEEE division when both terms are safe integers, otherwise the 64-bit quotient above.
export function toNumber(value){
  const r=rational(value),n=BigInt(r.n),d=BigInt(r.d);
  const safe=x=>(x<0n?-x:x)<=BigInt(Number.MAX_SAFE_INTEGER);
  if(safe(n)&&safe(d))return Number(n)/Number(d);
  if(n===0n)return 0;
  const {mantissa,exponent}=split(n,d),magnitude=mantissa*2**exponent;
  return n<0n?-magnitude:magnitude;
}
export const text=value=>{const r=rational(value);return r.d==='1'?r.n:`${r.n}/${r.d}`};
// floor(value × scale) and round-half-up(value × scale) in exact arithmetic, for placing a rational beat on an integer grid.
export function floorScaled(value,scale){const [n,d]=parts(value),s=big(scale,'scale'),q=(n*s)/d,r=(n*s)%d;return q-(r<0n?1n:0n)}
export function roundScaled(value,scale){const [n,d]=parts(value),s=big(scale,'scale');return floorScaled(make(2n*n*s+d,2n*d),1)}
