import { DEFAULT_TPQ, timedUMP, inspectUMP, noteOn, bendSemitones, bend32, perNoteController } from './ump.js';
import { notesToUMP, umpNotes } from './ump-events.js';
import { MotifRetention, motifRetentionPolicy, MOTIF_CAPACITY_MEASUREMENTS } from './motif-retention.js';
import {bandTempo,bandMeter} from './opening-time.js';
import {Rational} from '../transcript/rational.js';

const round=(value,places=6)=>Number(Number(value).toFixed(places));
const clone=value=>JSON.parse(JSON.stringify(value));
// Only objects produced here are immutable enough to cache by identity.
const validatedMotifs=new WeakSet(),decodedNotes=new WeakMap(),fingerprintKeys=new WeakMap();
const keysOf=motif=>{let keys=fingerprintKeys.get(motif);if(!keys){keys={intervals:JSON.stringify(motif.fingerprint.intervals),contour:JSON.stringify(motif.fingerprint.contour)};if(validatedMotifs.has(motif))fingerprintKeys.set(motif,keys)}return keys};
function freezeDeep(value) {
  if(value&&typeof value==='object'){Object.values(value).forEach(freezeDeep);Object.freeze(value)}
  return value;
}
export function motifNotes(motif) {
  if(validatedMotifs.has(motif)&&decodedNotes.has(motif))return decodedNotes.get(motif);
  if(motif.schemaVersion===2||motif.events?.[0]?.packet){
    const notes=umpNotes(motif.events,{...motif.timebase,header:motif.metadata?.clipHeader,endTime:motif.metadata?.endTime??motif.events.at(-1)?.time??0});
    // (Each note's written onset and length, where its clip carries its players' (ump-events.js UmpMotifCapture): quarters
    // from the clip's first onset, exact, fractions' strings.)
    const written=motif.metadata?.written;
    if(Array.isArray(written)){const order=new Map(noteOns(motif.events).map((event,k)=>[event,k]));
      for(const note of notes){const mark=written[order.get(note.on)];if(mark){note.written=mark.at;note.writtenQuarters=mark.quarters}}}
    if(validatedMotifs.has(motif)){freezeDeep(notes);decodedNotes.set(motif,notes)}return notes;
  }
  return motif.events||[];
}
const noteOns=events=>events.filter(event=>inspectUMP(event.packet).kind==='noteOn');
export function motifFingerprint(events,timebase) {
  const cells=events[0]?.packet?umpNotes(events,timebase):events;
  const notes=cells.flatMap(event=>Array.isArray(event.pitches)?event.pitches:[event.pitch]).map(Number).filter(Number.isFinite),
    onsets=cells.map(event=>Number(event.at)).filter(Number.isFinite),durations=cells.map(event=>Number(event.duration)||0);
  const intervals=notes.slice(1).map((note,index)=>round(note-notes[index])),span=Math.max(1e-9,(onsets.at(-1)??0)-(onsets[0]??0));
  return {intervals,onsetRatios:onsets.map(onset=>round((onset-(onsets[0]??0))/span)),durationRatios:durations.map(duration=>round(duration/span)),contour:intervals.map(value=>Math.sign(value))};
}
export function validateMotif(value) {
  if(validatedMotifs.has(value))return value;
  if(!value||typeof value!=='object'||!String(value.motifId||value.id||''))throw new TypeError('Motif requires motifId');
  const timebase={ticksPerQuarterNote:DEFAULT_TPQ,...value.timebase};
  if(!Number.isInteger(timebase.ticksPerQuarterNote)||timebase.ticksPerQuarterNote<1||timebase.ticksPerQuarterNote>65535)throw new RangeError('Motif timebase must be 1..65535 ticks per quarter note');
  const canonical=value.events?.[0]?.packet!==undefined||(value.schemaVersion===2&&Array.isArray(value.events)&&value.events.length===0);
  if(value.schemaVersion===2&&!canonical)throw new TypeError('MIDI 2 motifs require timestamped UMP events');
  const events=canonical?timedUMP(value.events):notesToUMP(value.events||[],timebase);
  const metadata=clone(value.metadata||{});
  if(metadata.clipHeader)metadata.clipHeader=timedUMP(metadata.clipHeader);
  if(metadata.endTime!==undefined&&(!Number.isSafeInteger(metadata.endTime)||metadata.endTime<0))throw new RangeError('Clip end time must be nonnegative integer ticks');
  if(metadata.written!==undefined&&(!Array.isArray(metadata.written)||metadata.written.length!==noteOns(events).length||
    !metadata.written.every(mark=>mark===null||typeof mark?.at==='string'&&typeof mark.quarters==='string'&&Rational.of(mark.at).sign()>=0&&Rational.of(mark.quarters).sign()>0)))
    throw new TypeError('A clip\'s written onsets are, per note, a nonnegative onset and a positive length in quarters, or null');
  for(const key of ['author','createdAt','tags','parents','name','parentMotifId','transformation'])
    if(value[key]!==undefined)metadata[key]=clone(value[key]);
  const result={schemaVersion:2,motifId:String(value.motifId||value.id),metadata:freezeDeep(metadata),
    timebase:freezeDeep(timebase),events:Object.freeze(events),fingerprint:freezeDeep(motifFingerprint(events,timebase))};
  // Read-only migration conveniences. JSON has one metadata object and one UMP
  // event sequence; historical consumers never define the persistent schema.
  for(const key of ['author','createdAt','tags','parents','name','parentMotifId','transformation'])
    Object.defineProperty(result,key,{get:()=>result.metadata[key],enumerable:false});
  validatedMotifs.add(result);return Object.freeze(result);
}
const withoutWritten=({written,...rest})=>rest;
export function transformMotif(value,{transpose=0,timeScale=1,invert=false,retrograde=false}={}) {
  if(!Number.isFinite(transpose)||!Number.isFinite(timeScale)||timeScale<=0)throw new RangeError('Motif transformation needs finite transpose and positive timeScale');
  const source=validateMotif(value),notes=motifNotes(source),anchor=notes[0]?.pitch??60;
  const end=Math.max(source.events.at(-1)?.time||0,source.metadata.endTime||0),times=new Map(),pitches=new Map(notes.map(note=>[note.on,note.pitch]));
  const changedPitch=pitch=>anchor+(invert?anchor-pitch:pitch-anchor)+transpose;
  if(retrograde)for(const note of notes)if(note.off){times.set(note.on,end-note.off.time);times.set(note.off,end-note.on.time)}
  if(retrograde)for(const event of source.events){const m=inspectUMP(event.packet);
    if(['perNoteBend','perNoteController'].includes(m.kind))throw new Error('Retrograde of per-note state requires a terminal-state arrangement');
    if(m.kind==='perNoteManagement'){const next=notes.find(note=>note.key===m.key&&note.on.time>=event.time);if(next)times.set(event,times.get(next.on)??end-event.time)}
    if(m.kind==='registeredController'&&m.note===0&&m.attribute===7)times.set(event,0);
    else if(['control','channelBend','channelPressure','registeredController','program'].includes(m.kind))throw new Error('Retrograde of a clip with channel state needs an explicit musical arrangement');
  }
  const events=source.events.map(event=>{
    const m=inspectUMP(event.packet);let packet=event.packet;
    if(m.kind==='noteOn'&&(transpose||invert)){
      if(![0,3].includes(m.attribute))throw new Error('Cannot retune a manufacturer/profile-specific Note On attribute without interpreting it');
      packet=noteOn({group:m.group,channel:m.channel,note:m.note,velocity:m.velocity,
        pitch:changedPitch(pitches.get(event)??m.pitch)});
    }
    else if(invert&&['perNoteBend','channelBend'].includes(m.kind))packet=[event.packet[0],bend32(-bendSemitones(m.data))];
    else if(m.kind==='perNoteController'&&m.attribute===3&&(transpose||invert)){
      const pitch=changedPitch(m.data/0x2000000);if(pitch<0||pitch>=128)throw new RangeError('Transformed per-note pitch is out of range');
      packet=perNoteController({group:m.group,channel:m.channel,note:m.note,index:3,value:Math.round(pitch*0x2000000)});
    }
    return {time:Math.round((retrograde?(times.get(event)??end-event.time):event.time)*timeScale),packet};
  }).sort((a,b)=>a.time-b.time);
  return validateMotif({...source,motifId:`${source.motifId}:development`,events,
    // (Its written onsets kept where its times are -- transposed or inverted -- else left behind: a scaled or reversed
    // clip's times are its ticks', not its players'.)
    metadata:{...(timeScale===1&&!retrograde?source.metadata:withoutWritten(source.metadata)),endTime:Math.round(end*timeScale),parentMotifId:source.motifId,transformation:{transpose,timeScale,invert,retrograde},timeQuantization:{unit:'tick',rule:'nearest integer after represented scaling',maxErrorFromRepresentedEndpoint:.5,exactInverse:false}}});
}
export class MotifMemory {
  // `policy` is a number for the historical `new MotifMemory(8)` form, or a
  // retention policy object. Capacity is never a literal here: the default
  // comes from the measured budget in motif-retention.js.
  constructor(policy,{retention,now}={}){
    this.retention=retention||new MotifRetention(
      motifRetentionPolicy(typeof policy==='object'&&policy?policy:policy===undefined?{}:{capacity:policy}),{now});
    this.motifs=new Map;this.eventCount=0;this.revision=0;
  }
  get limit(){return this.retention.policy.capacity}
  set limit(value){this.retention.configure({capacity:value})}
  get eventCapacity(){return this.retention.policy.eventCapacity}
  // The library's heap, estimated from what it actually holds (each record's measured overhead, each event's measured
  // bytes), and the budget it must stay inside: the measured store budget, or the capacity asked for at typical motifs
  // where that is larger. The count and event ceilings alone let dense clips run past the heap model (the mathematical
  // audit's M07). An estimate, not a bound on any engine's heap.
  get estimatedBytes(){return this.motifs.size*MOTIF_CAPACITY_MEASUREMENTS.recordOverheadBytes+this.eventCount*MOTIF_CAPACITY_MEASUREMENTS.bytesPerEvent}
  get byteBudget(){const {storeHeapBudgetBytes,recordOverheadBytes,bytesPerEvent,typicalCaptureEvents}=MOTIF_CAPACITY_MEASUREMENTS;
    return Math.max(storeHeapBudgetBytes,this.limit*(recordOverheadBytes+typicalCaptureEvents*bytesPerEvent))}
  within(){return this.motifs.size<=this.limit&&this.eventCount<=this.eventCapacity&&this.estimatedBytes<=this.byteBudget}
  remember(value,context={}){
    const motif=validateMotif(value);this.eventCount-=this.motifs.get(motif.motifId)?.events.length||0;
    this.motifs.delete(motif.motifId);this.motifs.set(motif.motifId,motif);this.eventCount+=motif.events.length;
    this.retention.admit(motif,context);this.evict();
    this.revision++;return motif;
  }
  // Capacity is enforced by the retention ledger, not by arrival order: the
  // least-evidenced record goes first, and an identical message sequence always
  // drops the same records.
  evict(reason='capacity'){
    if(this.within())return [];
    const culled=[];
    const at=this.retention.now(),first=this.retention.evictionVictim(this.motifs.keys(),at);
    const firstMotif=first&&this.motifs.get(first.motifId);
    const oneEnough=firstMotif&&this.motifs.size-1<=this.limit&&this.eventCount-firstMotif.events.length<=this.eventCapacity&&
      this.estimatedBytes-MOTIF_CAPACITY_MEASUREMENTS.recordOverheadBytes-firstMotif.events.length*MOTIF_CAPACITY_MEASUREMENTS.bytesPerEvent<=this.byteBudget;
    const victims=oneEnough?[first]:this.retention.evictionKeys(this.motifs.keys(),at);
    for(const {motifId} of victims){
      if(this.within())break;
      const motif=this.motifs.get(motifId);if(!motif)continue;
      this.eventCount-=motif.events.length;this.motifs.delete(motifId);
      culled.push(this.retention.evict(motifId,reason,at));
    }
    if(culled.length)this.revision++;
    return culled;
  }
  get(id){return this.motifs.get(id)}
  recent(limit=16){return [...this.motifs.values()].slice(-limit)}
  matching({intervals,contour}={}){return this.recent(this.limit).filter(motif=>(!intervals||keysOf(motif).intervals===JSON.stringify(intervals))&&(!contour||keysOf(motif).contour===JSON.stringify(contour)))}
}
// Eligibility, and then a choice. The filters are the requester's hard terms
// and none of them moves; what follows them used to be `.slice(-8)`, which
// answered every question with whatever had been captured most recently.
//
// `choose` receives the whole eligible population and returns the answer. It is
// passed in rather than imported so this module stays free of the retention
// ledger a ranker reads -- see shared/motif-ranking.js and MemoryBot. Without
// one the old newest-first answer stands, which is what a caller holding no
// ledger (a test, a browser of the library) should still get.
// `limit` carries no default of its own: a request that names no size is asking
// for the configured one, and a literal here would quietly outrank the policy.
export function queryMotifs(memory,{motifId,author,tags,contour,intervals,limit}={},
  {choose,defaultLimit=8,maxLimit=32}={}) {
  const requestedTags=(Array.isArray(tags)?tags:tags?[tags]:[]).map(String);
  const eligible=memory.recent(memory.limit).filter(motif=>
    (!motifId||motif.motifId===String(motifId))&&(!author||motif.author===String(author))&&
    (!requestedTags.length||requestedTags.every(tag=>(motif.tags||[]).includes(tag)))&&
    (!contour||keysOf(motif).contour===JSON.stringify(contour))&&
    (!intervals||keysOf(motif).intervals===JSON.stringify(intervals))
  );
  const bound=Math.max(1,Math.min(maxLimit,Math.trunc(Number(limit)||defaultLimit)));
  return choose?choose(eligible,bound):eligible.slice(-bound);
}

const NON_MUSICAL_EVENT_KINDS=new Set([
  'audio_context','rendered_pitch','expressive_note','pitched','tuning_plan',
  'midi_route_collision','mpe_voice_limit'
]);

export class SelectiveMotifCapture{
  constructor(limit=128){this.limit=Math.max(8,Math.trunc(limit));this.events=[]}
  add(event,clock={}){
    if(!event||NON_MUSICAL_EVENT_KINDS.has(event.kind))return false;
    const pitches=(Array.isArray(event.notes)?event.notes:Array.isArray(event.pitches)?event.pitches:[event.note])
      .map(Number).filter(Number.isFinite);
    if(!pitches.length)return false;
    const subdivision=clock.meter?.subdivision||bandMeter().subdivision,bpm=clock.bpm||bandTempo(),
      offsetTicks=(Number(event.offset)||0)*bpm*subdivision/60,
      at=Math.round(((Number(clock.tick)||0)+offsetTicks)*4)/4,
      duration=Math.max(.25,Math.round((Number(event.duration)||0)*bpm*subdivision/60*4)/4),
      velocity=Math.max(0,Math.min(1,Number(event.velocity??event.accent??.65)||.65)),
      existing=this.events.find(item=>item.at===at&&Math.abs(item.duration-duration)<=.25);
    if(existing){
      existing.pitches=[...new Set([...existing.pitches,...pitches])].sort((a,b)=>a-b);
      existing.velocity=Math.max(existing.velocity,velocity);
      return true;
    }
    this.events.push({at,duration,pitches:[...new Set(pitches)].sort((a,b)=>a-b),velocity});
    if(this.events.length>this.limit)this.events.shift();
    return true;
  }
  flush(){
    if(!this.events.length)return[];
    const start=this.events[0].at,events=this.events.map(event=>({...event,at:event.at-start}));
    this.events=[];return events;
  }
}

// A motif's top line: its notes grouped by onset (within an eighth of a quarter note, a strummed chord's spread), the
// highest of each group. [{at (quarter notes), pitch, index (in the notes given)}].
export function topLine(notes){
  const onsets=notes.map((note,index)=>({note,index})).filter(({note})=>Number.isFinite(note.at)&&(note.pitches??[note.pitch]).some(Number.isFinite))
    .sort((a,b)=>a.note.at-b.note.at),line=[];
  for(const {note,index} of onsets){
    const pitch=Math.max(...(note.pitches??[note.pitch]).filter(Number.isFinite)),last=line.at(-1);
    if(last&&note.at-last.start<.125){if(pitch>last.pitch){last.pitch=pitch;last.index=index;}}else line.push({at:note.at,start:note.at,pitch,index,written:note.written});
  }
  return line.map(({at,pitch,index,written})=>({at,pitch,index,...(written!=null?{written}:{})}));
}
// A theme's line as a motif plan carries it (mh_MemoryBOT's: {motifId, line}), each note naming the stored motif it is
// from beside its index there, so that a player taking it up can say which of its notes it played (/agent/memory/playing).
export function storedLine(theme){
  const line=Array.isArray(theme?.line)?theme.line:[];
  return typeof theme?.motifId==='string'&&theme.motifId?line.map(note=>({...note,motifId:theme.motifId})):line;
}
