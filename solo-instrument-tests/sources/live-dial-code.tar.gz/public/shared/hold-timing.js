// Time stopped at one pulse (a hold: clock-hold.js), in every bot's sound (the rubato report's holds as a mode, §9.6;
// taken on 0f's terms, SESSIONS.md 28 September). The clocks stop at the held pulse: it sounds when it would have, and
// the next comes after the hold and the held pulse's own length. A bot plays in score time, so its notes are mapped
// here, as the clocks map their pulses:
// - A note after the held pulse's attack moves by the hold: the rest of that pulse comes after it. Within half a pulse
//   of the attack a note is the attack's (a strum's spread, a grace, a flam): the pulse is the clock's grid.
// - A note held to the end of the held pulse's own length, or past it, is held the hold longer: a pad's chord on a
//   fermata. One released within its pulse (a staccato note, a hat) is released as it was.
// - A cued hold's length is not known until its cue. A note after its attack is not played, since its time is not
//   known. A note held over it is given the bound and released where the next pulse, which says the hold's length
//   (`held.ends`), puts its end. An engine sending MIDI cannot let a note go early (its note-off is sent as it is
//   played), so there such a note keeps its own length rather than sounding on to the bound over the re-entry.
// - A hold whose band rests (`band: 'rest'`, a cadenza's): a note held past the held pulse's own length ends there, and
//   so does one already sounding, so that the soloist is alone.
// A hold declared ahead (/broadcast/hold, which a host passes on: hearHold) reaches the notes that cross it from before
// its pulse. Notes placed before it was declared cannot be held longer: an engine can release a note early, not lengthen
// it. Every call a bot makes is placed where it is made. A free call ({free: true}: a cadenza's notes, a drummer's pickup)
// is in the hold's own time and is left alone, and so is a call made after its tick has sounded (a reaction to a message
// during a hold). A call's notes are placed by its anchor where it names one (performed-timing.js: a grace by its
// principal), else each by its own offset.
//
// installHoldTiming(audio) wraps an engine (audio.js AudioEngine) for one bot; the render's host and the page install it
// on every bot's, the ports' too, as they give each bot the clock (beginTick), so no bot needs to know of it. The first
// of the engine's note calls a bot's call reaches places the note; the ones it makes in turn (voice's planNote and
// scheduleDsp) take the duration it was given. What was done is kept in `audio.holdTiming.log`.
import {holdTick,normalizeHold} from './clock-hold.js';
import {secondsPerTick} from './meter-tactus.js';

export const HOLD_TIMING=Object.freeze({
  // A note within this share of a pulse after the held pulse's attack is the attack's.
  attackShare:.5,
  // What was done, kept for inspection.
  kept:64,
});
// The engine's note calls (audio.js): where each takes its note's duration and its offset (seconds after the tick). A
// plan (planNote) is needed by the call that asked for it, so it is never withheld: the call's own scheduling is. A note
// given its time outright (scheduleDsp's atSeconds) is left where it was put.
const NOTE_CALLS=Object.freeze({
  voice:{duration:1,offset:args=>args[4]},
  planNote:{duration:1,offset:args=>args[2]?.offset,kept:true},
  scheduleDsp:{duration:2,offset:args=>args[4],given:args=>args[7]?.atSeconds!=null},
  captureUMP:{duration:1,offset:args=>args[3]},
  midiNote:{duration:1,offset:args=>args[4]},
  sampleFile:{duration:4,offset:args=>args[3]},
  noise:{duration:0,offset:args=>args[3]},
});
const UNWRAPPED=new Set(['constructor','eventStart','beginTick']);
const HOLDS_KEPT=32;
const freeOf=args=>args.some(arg=>arg&&typeof arg==='object'&&arg.free===true);
const anchorOf=args=>{for(const arg of args)if(arg&&typeof arg==='object'&&Number.isFinite(arg.anchorOffset))return arg.anchorOffset;return null};

// What a hold does to a note `offset` seconds after its tick, lasting `duration` and placed by `basis` (its call's
// anchor, else its own offset). The hold's pulse is `at` seconds after the tick, with its `seconds` (null where it is
// cued), `bound`, `band` and the pulse's length `perTick`. -> {shift, duration}, and `drop` where the note is not
// played, `extended` where it is to be released at the re-entry, `held` or `rested` where its length changed.
export function heldNote({offset,duration,basis=offset},{at,seconds,bound,band='sustain',perTick}){
  if(basis>at+HOLD_TIMING.attackShare*perTick)return seconds==null?{drop:true,shift:0,duration}:{shift:seconds,duration};
  const through=at+perTick;
  if(!(duration>0)||offset+duration<through-1e-9)return {shift:0,duration};
  if(band==='rest')return {shift:0,duration:Math.max(0,through-offset),rested:true};
  return seconds==null?{shift:0,duration:duration+bound,extended:true}:{shift:0,duration:duration+seconds,held:true};
}

// The hold a call at this pulse reaches: the one the pulse begins, else the next declared, `at` seconds ahead in this
// bar's meter and tempo (a meter changing before it moves it, and the notes crossing it are placed by this bar's).
function holdAround(holds,clock){
  const perTick=secondsPerTick(clock),begins=clock?.held?.begins;
  if(begins)return {id:begins.id,at:0,seconds:begins.cued?null:Number(begins.seconds),bound:Number(begins.bound??begins.seconds),band:begins.band??'sustain',perTick};
  const meter=clock?.meter;
  if(!meter||!Number.isInteger(clock.bar)||!Number.isFinite(clock.tickInBar))return null;
  for(const hold of holds){
    const tick=holdTick(hold,meter),ahead=tick===null?null:(hold.bar-clock.bar)*meter.pulsesPerBar+tick-clock.tickInBar;
    if(ahead>0)return {id:hold.id,at:ahead*perTick,seconds:hold.known?hold.seconds:null,bound:hold.bound,band:hold.band??'sustain',perTick};
  }
  return null;
}
// A declared hold that will be held: a possible one only where it is chosen, or its default is to hold.
const willHold=hold=>!hold.optional||(hold.selected??hold.branch)==='hold';
const passedBy=(hold,clock)=>{const tick=holdTick(hold,clock.meter);return hold.bar<clock.bar||hold.bar===clock.bar&&(tick===null||tick<=clock.tickInBar)};

export function installHoldTiming(audio){
  if(!audio||typeof audio!=='object'||typeof audio.eventStart!=='function'||audio.holdTiming)return audio;
  const state={holds:[],extended:[],clock:null,active:false,depth:0,noteDepth:0,call:null,log:[]};
  const log=entry=>{state.log.push(Object.freeze(entry));if(state.log.length>HOLD_TIMING.kept)state.log.shift()};
  const refresh=()=>{state.active=Boolean(state.clock?.held?.begins||state.holds.some(willHold)||state.extended.length)};
  const define=(name,value)=>Object.defineProperty(audio,name,{value,configurable:true,writable:true,enumerable:false});
  define('holdTiming',state);
  // A hold declared, or a possible one's branch, as the room hears it.
  define('hearHold',message=>{
    const value=message?.args?.[0];
    if(message?.address==='/broadcast/hold'){
      let hold;try{hold=normalizeHold(value)}catch{return}
      state.holds=[...state.holds.filter(other=>other.id!==hold.id),hold].sort((a,b)=>a.bar-b.bar||a.beat-b.beat||a.subdivision-b.subdivision).slice(0,HOLDS_KEPT);
    }else if(message?.address==='/broadcast/holdSelected'&&typeof value?.id==='string'){
      const hold=state.holds.find(other=>other.id===value.id);if(hold)hold.selected=value.branch==='hold'?'hold':'continue';
    }else return;
    refresh();
  });
  // Each pulse: the hold it ends lets go of the notes held to its bound, where its length puts their ends; the holds
  // passed or begun are the clock's from here; a hold whose band rests ends what is still sounding. (Let go through
  // releaseNotes, as every early release is, so that a transcript hears it: transcript/capture.js tapEngine.)
  const beginTick=audio.beginTick;
  if(typeof beginTick==='function')define('beginTick',function(tick,bpm,subdivision,clock={}){
    const out=beginTick.apply(this,arguments),ends=clock?.held?.ends,begins=clock?.held?.begins;
    state.clock=clock;
    if(ends)state.extended=state.extended.filter(note=>{
      if(note.id!==ends.id)return true;
      const at=note.endsAt+(Number(ends.seconds)||0);
      if(this.releaseNotes?.((_,identity)=>identity===note.identity,{atSeconds:at})?.length)log({tick,id:note.id,released:note.identity,at});
      return false;
    });
    if(clock?.meter)state.holds=state.holds.filter(hold=>hold.id!==begins?.id&&!passedBy(hold,clock));
    if(begins?.band==='rest'&&typeof this.releaseNotes==='function'){
      const through=Number(this.eventTime)+secondsPerTick(clock);
      if(Number.isFinite(through))
        for(const note of this.releaseNotes(note=>note.startedAt<through-1e-9,{atSeconds:through})??[])log({tick,id:begins.id,rested:note.identity,at:through});
    }
    refresh();
    return out;
  });
  const clockNow=engine=>{try{const now=engine.clockTime?.();return Number.isFinite(now)?now:null}catch{return null}};
  const wrap=(name,fn)=>{
    const spec=NOTE_CALLS[name];
    return function(...args){
      if(!state.active)return fn.apply(this,args);
      const top=state.depth===0;let restore=null;
      if(top){
        // Placed where it is made: not a free call, and before its tick sounds.
        const clock=state.clock,now=clockNow(this),sounded=now!==null&&Number.isFinite(this.eventTime)&&now>this.eventTime;
        const around=clock&&!freeOf(args)&&!sounded?holdAround(state.holds.filter(willHold),clock):null;
        state.call={around,anchor:anchorOf(args),tick:clock?.tick};
        if(around?.seconds!=null){
          const own=Object.hasOwn(this,'eventStart'),original=this.eventStart,call=state.call;
          this.eventStart=function(offset=0){
            const at=Number(offset)||0,basis=call.anchor??at;
            return original.call(this,at)+(basis>around.at+HOLD_TIMING.attackShare*around.perTick?around.seconds:0);
          };
          restore=()=>{if(own)this.eventStart=original;else delete this.eventStart};
        }
      }
      let placed=null,offset=0,duration=0;
      const around=state.call?.around;
      if(spec&&state.noteDepth===0&&around&&!spec.given?.(args)){
        offset=Number(spec.offset(args))||0;duration=Number(args[spec.duration]);
        if(Number.isFinite(duration)){
          placed=heldNote({offset,duration,basis:state.call.anchor??offset},around);
          // (Nothing can let it go early where the engine sends MIDI: its own length, not the bound.)
          if(placed.extended&&this.mode==='midi'){log({tick:state.call.tick,id:around.id,unheld:name,offset,reason:'MIDI: no early release'});placed={shift:0,duration}}
          if(placed.drop&&!spec.kept){
            log({tick:state.call.tick,id:around.id,dropped:name,offset});
            if(top){restore?.();state.call=null}
            return undefined;
          }
          if(placed.duration!==duration){args[spec.duration]=placed.duration;log({tick:state.call.tick,id:around.id,[placed.rested?'rested':'held']:name,offset,from:duration,to:placed.duration})}
          else if(placed.shift)log({tick:state.call.tick,id:around.id,moved:name,offset,by:placed.shift});
        }
      }
      state.depth++;if(spec)state.noteDepth++;
      try{
        const out=fn.apply(this,args);
        // Held to a cued hold's bound: let go at the re-entry (beginTick, the pulse that ends the hold).
        if(placed?.extended&&Number.isFinite(out)&&out>0&&Number.isFinite(this.eventTime))
          state.extended.push({id:around.id,identity:out,endsAt:this.eventTime+offset+duration});
        return out;
      }finally{state.depth--;if(spec)state.noteDepth--;if(top){restore?.();state.call=null}}
    };
  };
  // Every method of the engine's own (its prototype chain), as it stands on this one: where a host has set its own in
  // its place (a render's report of its samples), that. What else a host keeps on the engine (a hook, a class such as
  // the AudioWorkletNode a grain voice or a singer is built with) is not the engine's call, and is left as it is.
  const names=new Set;
  for(let proto=Object.getPrototypeOf(audio);proto&&proto!==Object.prototype;proto=Object.getPrototypeOf(proto))
    for(const name of Object.getOwnPropertyNames(proto))if(typeof Object.getOwnPropertyDescriptor(proto,name).value==='function')names.add(name);
  const isClass=fn=>/^class[\s{]/.test(Function.prototype.toString.call(fn));
  for(const name of names){const fn=audio[name];if(!UNWRAPPED.has(name)&&typeof fn==='function'&&!isClass(fn))define(name,wrap(name,fn))}
  return audio;
}
