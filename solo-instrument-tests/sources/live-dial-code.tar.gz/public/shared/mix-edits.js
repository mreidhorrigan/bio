// Edits in the mix, asked for by bots: the decorations a producer makes between sections from what was just played -- a
// stutter, a rewind, a tape stop (public/edits-worklet.js). The user, 26 September 2026: "7. Effects that can only be done
// as postprocessing, such as reverses (again think Linkin Park and its vinyl-inspired short-term sample repetitions and
// other in-the-mix decorations)."
//
// A bot asks with /agent/edit {kind, what, seconds, inSeconds, slice, bar, why}, or {prepare: true} ahead of its first:
//   kind       'repeat' (the slice just before, over and over), 'reverse' (what came just before, backwards) or
//              'tapeStop' (the programme slowing to a halt)
//   what       'all', the whole mix (the default), or a group (submix.js: drums, bass, keys, lead, texture), where the
//              desk has its bus
//   seconds    how long (MIX_EDITS.shortestSeconds to longestSeconds); inSeconds, from how long after the tick it is sent
//              on (0: that tick, as it is heard); slice, a repeat's (MIX_EDITS.slice); bar and why, for the log
// The desk's side (MixEdits) schedules it on the mixer (EnsembleMixer.edit) from the moment the host gives, as MixCuts
// cuts: a render the tick's own time as it is heard, a page its clock's.
import {SUBMIX,submixBus} from '../../experiments/mix-desk/submix.js';
import {EDIT_KINDS} from '../edits.js';

// ---- Choices ---------------------------------------------------------------------------------------------------------
export const MIX_EDITS=Object.freeze({
  // The shortest and the longest edit, and how far ahead one may be asked for (ours: as a cut's; an edit reads the past,
  // and the worklet keeps eight seconds of it).
  shortestSeconds:.05,longestSeconds:4,furthestSeconds:16,
  // A repeat's slice when none is asked (ours: a sixteenth at 120 bpm), and its shortest and longest.
  slice:.125,shortestSlice:.02,longestSlice:1,
});

export class MixEdits {
  constructor(mixer,{log=null,choices=MIX_EDITS}={}){
    if(!mixer||typeof mixer.edit!=='function')throw new TypeError('MixEdits needs the mixer (EnsembleMixer)');
    this.mixer=mixer;this.log=log;this.choices=choices;this.edits=[];
  }
  target(what){
    if(what===undefined||what==='all')return 'all';
    const bus=SUBMIX.groups[what]?submixBus(what):null;
    return bus&&this.mixer.tracks.get(bus)?.bus?bus:null;
  }
  // A request, at `start` (context seconds: when the tick it was sent on is heard). Returns what was scheduled, or why
  // not; the insert's own readiness is logged when it comes.
  request(request,{start,source=null}={}){
    const choices=this.choices,refuse=why=>{const record={kind:'edit',refused:why,source,request};this.log?.(record);return record};
    if(!request||typeof request!=='object')return refuse('an edit is {kind, seconds}');
    if(request.prepare){const target=this.target(request.what);if(target)this.mixer.edit(target,null,{prepare:true}).catch(error=>refuse(error.message));return {kind:'edit',prepared:target}}
    if(!EDIT_KINDS.includes(request.kind))return refuse(`an edit is ${EDIT_KINDS.join(', ')}, not ${JSON.stringify(request.kind)}`);
    const seconds=Number(request.seconds),inSeconds=Number(request.inSeconds??0),slice=Number(request.slice??choices.slice);
    if(!Number.isFinite(seconds)||seconds<choices.shortestSeconds||seconds>choices.longestSeconds)
      return refuse(`an edit lasts ${choices.shortestSeconds} to ${choices.longestSeconds} seconds, not ${request.seconds}`);
    if(!Number.isFinite(inSeconds)||inSeconds<0||inSeconds>choices.furthestSeconds)return refuse(`an edit begins 0 to ${choices.furthestSeconds} seconds ahead`);
    if(!Number.isFinite(slice)||slice<choices.shortestSlice||slice>choices.longestSlice)return refuse(`a slice is ${choices.shortestSlice} to ${choices.longestSlice} seconds`);
    if(!Number.isFinite(start))return refuse('the host has no time for it');
    const target=this.target(request.what);
    if(!target)return refuse(`no bus for ${JSON.stringify(request.what)}: edit the whole mix, or a group the desk has grouped`);
    const from=start+inSeconds,until=from+seconds;
    const record={kind:'edit',edit:request.kind,target,from:+from.toFixed(4),until:+until.toFixed(4),...(request.kind==='repeat'?{slice}:{}),source,
      ...(Number.isFinite(Number(request.bar))?{bar:Number(request.bar)}:{}),...(request.why?{why:String(request.why)}:{})};
    this.mixer.edit(target,{kind:request.kind,from,until,slice}).catch(error=>refuse(error.message));
    this.edits.push(record);this.log?.(record);
    return record;
  }
}
