// How a mix is made, as a set of approaches an engineer would recognise -- a concert recording's
// hall, a studio pop mix's plate and glue, a dance mix's pumping sidechain, a dub mix's springs and
// tape echoes, an ambient wash -- each a whole recipe rather than a knob: which reverb and how
// long, what is compressed and how, what goes to which bus, how loud each part sits.
//
// Plain data and arithmetic, with no audio and no model in it: an approach is chosen from the
// character vector (public/shared/aesthetic.js) or by name, and planned for a tempo, the same way
// every time. Anything can supply the vector -- a preset, a bot, the genre lexicon, the page, an
// LM -- and without one nothing here is asked. public/mix-approach.js applies a plan to a mixer.
//
// **Where the numbers come from.** Measured values where a study measured them, marked with the
// source (research/expression-and-mixing-references.md has each in full); our choice otherwise,
// marked "ours". The measured anchors are gathered in MEASURED so they are read in one place:
//
//   reverb time falls with tempo in pop: 2 s preferred only at 67 bpm, 0.5-0.7 s at 84-105,
//     0.2-0.4 s at 120-143 (Pestana, Reiss & Barbosa 2017); fitted here as 2 exp(-0.0296 (bpm-67))
//   pre-delay: more than 30-40 ms preferred in pop listening tests (Pestana & Reiss 2014); at most
//     20 ms in an intimate hall (Hyde 2019, after Beranek)
//   reverb send filtered at about 200 Hz and 5 kHz, no kick or bass sent (Pestana & Reiss 2014)
//   reverb loudness: -14 LU below the mix preferred by skilled listeners, -9 LU or wetter always
//     judged too wet (De Man, McNally & Reiss 2017; Pestana & Reiss 2014)
//   compression ratios 1.6-3.1:1 from a model fitted to engineers' choices: vocals 1.8-2.3, bass
//     2.1-2.4, kit drums 2.2-2.6, with a knee of half the threshold, 9-17 dB (Ma, De Man, Pestana,
//     Black & Reiss 2015); vocal attack about 6 ms and release 100-150 ms, drum attack about
//     19 ms (Giannoulis, Massberg & Reiss 2013)
//   mix-bus compression the norm, about 3 dB of gain reduction (Pestana & Reiss 2014)
//   a -1 dBTP ceiling (EBU R 128)
//   echo on the eighth note, the quarter note below about 70 bpm (Pestana et al. 2017)
//   slapback 80-140 ms (Sun Studio 134-137 ms: Halmrast 2019)
//   parts' loudness against the mix: lead vocal -2.7 LU, drums -6.5 to -8.5, bass -8 to -9 (De Man,
//     Leonard, King & Reiss 2014; De Man 2017)
//   kick, snare, bass and lead centred, and wider mixes rated lower (De Man et al. 2014, 2015)
//   side-chain pumping: ratio 16:1 or more, fastest attack, the release setting when the swell
//     returns (Price 2008, practitioner)
import {aesthetic} from './aesthetic.js';
import {ROLES} from './articulation.js';
import {bandTempo} from './opening-time.js';

// REVERB_TYPES' order (public/reverb-design.js), by name, without importing the designer here.
const REVERB = Object.freeze({legacy: 0, booth: 1, ambience: 2, room: 3, chamber: 4, hall: 5, plate: 6, cathedral: 7, spring: 8, gated: 9});
const DELAY = Object.freeze({line: 0, pingPong: 1, tape: 2});
const DRIVE = Object.freeze({tanh: 0, tape: 1, tube: 2, fuzz: 3, crush: 4});
const clamp = (value, low, high) => Math.max(low, Math.min(high, value));
const lerp = (from, to, at) => from + (to - from) * clamp(at, 0, 1);
const round = (value, places = 3) => Math.round(value * 10 ** places) / 10 ** places;

export const MEASURED = Object.freeze({
  popReverbSeconds: bpm => clamp(2 * Math.exp(-0.0296 * (bpm - 67)), 0.3, 2.2),
  echoBeats: bpm => bpm < 70 ? 1 : 0.5,
  popPredelayMs: 35,
  hallPredelayMs: 20,
  sendLowCut: 200,
  sendTone: 5000,
  restrainedWetLu: -14,
  tooWetLu: -9,
  glueReductionDb: 3,
  ceilingDb: -1,
  lead: Object.freeze({ratio: 2.1, attack: 0.006, release: 0.12}),
  drums: Object.freeze({ratio: 2.4, attack: 0.019, release: 0.1}),
  bass: Object.freeze({ratio: 2.3}),
  kneeDb: 10,
  slapbackMs: Object.freeze([80, 140]),
  balanceLu: Object.freeze({lead: -2.7, drums: -7.5, bass: -8.5}),
  pump: Object.freeze({ratio: 16, threshold: -25, attack: 0.0005}),
});

// A pumping duck's release, from the practitioner's rule that the release sets when the swell
// returns: back within a decibel of full by the next beat. The gain recovers exponentially in dB,
// so from a 9 dB duck that is ln(9) time constants in a beat.
export const pumpRelease = (bpm, depthDb = 9) => (60 / bpm) / Math.log(Math.max(1.5, depthDb));

// Each approach's place among the aesthetic axes: the mean of the genres it is named for, as the
// genre lexicon (public/data/aesthetic-lexicon.json, from Every Noise at Once and the FMA) places
// them on the observed axes, with a space the approach itself is about. Rounded to two places.
const SIGNATURES = Object.freeze({
  natural:    {genres: ['classical'], attack: 0.23, mechanism: 0, tonality: 0.94, darkness: 1, space: 0.6},
  intimate:   {genres: ['singer-songwriter', 'folk', 'soul'], attack: 0.59, mechanism: 0.28, tonality: 0.75, darkness: 0.73, space: 0.2},
  studio:     {genres: ['pop', 'rock', 'indie rock', 'funk', 'r&b'], attack: 0.53, mechanism: 0.6, tonality: 0.61, darkness: 0.42, space: 0.4},
  electronic: {genres: ['house', 'techno', 'deep house', 'edm', 'trance'], attack: 0.77, mechanism: 0.97, tonality: 0.62, darkness: 0.31, space: 0.45},
  dub:        {genres: ['dub', 'reggae', 'dub techno'], attack: 0.93, mechanism: 0.77, tonality: 0.79, darkness: 0.28, space: 0.8},
  ambient:    {genres: ['ambient', 'drone', 'dark ambient'], attack: 0.14, mechanism: 0.35, tonality: 0.7, darkness: 0.98, space: 0.95},
  lofi:       {genres: ['lo-fi', 'lo-fi beats', 'trip hop', 'hip hop'], attack: 0.66, mechanism: 0.62, tonality: 0.66, darkness: 0.5, space: 0.35},
  industrial: {genres: ['industrial', 'noise', 'power electronics', 'metal', 'punk'], attack: 0.16, mechanism: 0.58, tonality: 0.15, darkness: 0.31, space: 0.35},
  eighties:   {genres: ['synthpop', 'new wave'], attack: 0.49, mechanism: 0.85, tonality: 0.52, darkness: 0.36, space: 0.55},
  dreamy:     {genres: ['shoegaze', 'dream pop', 'chillwave'], attack: 0.23, mechanism: 0.67, tonality: 0.62, darkness: 0.54, space: 0.8},
});
// How much each axis decides which approach is meant. Space most, because it is what the choice of
// reverb is; noise against pitch next, because a noise mix wants drive and a pitched one does not;
// brightness least, because its measurement covers the fewest genres (aesthetic.js). Ours.
const WEIGHTS = Object.freeze({attack: 1, mechanism: 1, tonality: 1.2, darkness: 0.5, space: 1.5});
export const APPROACH_NAMES = Object.freeze(Object.keys(SIGNATURES));

export function approachDistance(name, vector) {
  const value = aesthetic(vector), signature = SIGNATURES[name];
  let sum = 0;
  for (const [axis, weight] of Object.entries(WEIGHTS)) sum += weight * (value[axis] - signature[axis]) ** 2;
  return Math.sqrt(sum);
}
// The approach a character is nearest; ties go to the earlier name, so it is always the same one.
export function approachFor(vector) {
  let best = APPROACH_NAMES[0], distance = Infinity;
  for (const name of APPROACH_NAMES) {
    const d = approachDistance(name, vector);
    if (d < distance - 1e-12) {best = name; distance = d}
  }
  return best;
}

// A channel strip for one role. Every field optional: hpf and lpf in Hz (0 off); dynamics for the
// zero-latency processor, with the gain reduction its threshold is steered toward; sends to the
// shared effects other than the long reverb, whose share the desk's space duty sets and this only
// weights; width; and the part's loudness against the mix, which the desk's balance aims at.
const strip = (fields = {}) => Object.freeze({hpf: 0, lpf: 0, dynamics: null, sends: {}, reverbWeight: 1, width: 1, balanceLu: null, drive: null, ...fields});
const compress = (ratio, attack, release, targetDb, extra = {}) => ({mode: 'compress', ratio, attack, release, knee: MEASURED.kneeDb, threshold: -20, targetDb, ...extra});

// ---- the approaches ---------------------------------------------------------------------------
// Each takes the character (for how far along its own range to go) and the tempo, and returns
// the whole plan. `v` is the full vector; `bpm` the tempo.
const RECIPES = {
  // A concert recording: one hall everyone is in, nothing compressed, the balance the players make.
  natural(v, bpm) {
    const hall = v.space >= 0.45;
    return {
      describe: 'a concert hall, uncompressed: the players in one room, balanced as they play',
      effects: {reverbType: hall ? REVERB.hall : REVERB.chamber, reverbSeconds: hall ? round(1.95 * lerp(0.85, 1.15, v.space), 2) : 1.5,
        reverbPredelayMs: MEASURED.hallPredelayMs, reverbLowCut: 60, reverbTone: 9000, reverbWidth: 1},
      busCompression: null, wetLu: -12,
      roles: {default: strip({hpf: 30}), bass: strip({hpf: 28, reverbWeight: 0.6}), drums: strip({hpf: 0, reverbWeight: 0.7})},
      // A concert is heard from the hall: the kit from the audience's side of it, the middle of the room back; and its
      // drums as the players play them, with no punch (experiments/mix-desk/punch.js).
      kit: {perspective: 'audience', distance: 0.5}, punch: false,
    };
  },
  // Close and dry: a small room, the voice-like part compressed as a vocal is, gentle glue.
  intimate(v, bpm) {
    return {
      describe: 'close and dry: a small room, the lead held steady as a voice is',
      effects: {reverbType: REVERB.ambience, reverbSeconds: round(lerp(0.35, 0.6, v.space), 2), reverbPredelayMs: 6,
        reverbLowCut: 150, reverbTone: 7000, delayMs: 120, delayFeedback: 0.05, delayTone: 5000, delayLowCut: 200},
      busCompression: {ratio: 1.5, attack: 0.03, release: 0.3, knee: 6, thresholdDb: -14, targetReductionDb: 1.5}, wetLu: -16,
      roles: {
        default: strip({hpf: 90}),
        lead: strip({hpf: 110, dynamics: compress(2, MEASURED.lead.attack, MEASURED.lead.release, 3), width: 0.7, balanceLu: MEASURED.balanceLu.lead, sends: {delay: 0.08}}),
        bass: strip({hpf: 35, dynamics: compress(MEASURED.bass.ratio, 0.015, 0.08, 3), width: 0, reverbWeight: 0, balanceLu: MEASURED.balanceLu.bass}),
        drums: strip({dynamics: compress(2, MEASURED.drums.attack, MEASURED.drums.release, 2), reverbWeight: 0.5, balanceLu: MEASURED.balanceLu.drums}),
      },
      punch: false,
    };
  },
  // The contemporary studio mix: a plate timed to the tempo, a room for the kit, an eighth-note
  // echo on the lead, every part compressed within the measured ratios, glue on the bus.
  studio(v, bpm) {
    return {
      describe: 'a studio mix: a plate timed to the tempo, a room on the kit, the parts compressed and glued',
      effects: {reverbType: REVERB.plate, reverbSeconds: round(MEASURED.popReverbSeconds(bpm) * lerp(0.9, 1.4, v.space), 2),
        reverbPredelayMs: MEASURED.popPredelayMs, reverbLowCut: MEASURED.sendLowCut, reverbTone: MEASURED.sendTone,
        roomType: REVERB.room, roomSeconds: -1, roomTone: 8000, roomReturn: 0.6,
        delayMode: DELAY.line, delayMs: -1, delayBeats: MEASURED.echoBeats(bpm), delayFeedback: 0.25, delayTone: 4500, delayLowCut: MEASURED.sendLowCut},
      busCompression: {ratio: 2, attack: 0.03, release: 0.3, knee: 6, thresholdDb: -14, targetReductionDb: MEASURED.glueReductionDb}, wetLu: MEASURED.restrainedWetLu,
      roles: {
        drums: strip({hpf: 30, dynamics: compress(MEASURED.drums.ratio, MEASURED.drums.attack, MEASURED.drums.release, 4), sends: {room: 0.35}, reverbWeight: 0.4, balanceLu: MEASURED.balanceLu.drums}),
        bass: strip({hpf: 35, dynamics: compress(MEASURED.bass.ratio, 0.015, 0.08, 4), width: 0, reverbWeight: 0, balanceLu: MEASURED.balanceLu.bass}),
        lead: strip({hpf: 120, dynamics: compress(MEASURED.lead.ratio, MEASURED.lead.attack, MEASURED.lead.release, 4), width: 0.7, sends: {delay: 0.18}, balanceLu: MEASURED.balanceLu.lead}),
        keys: strip({hpf: 100, dynamics: compress(2, 0.01, 0.15, 2), width: 1.1, sends: {delay: 0.06, room: 0.1}, balanceLu: -10}),
        pad: strip({hpf: 150, width: 1.3, reverbWeight: 1.2, balanceLu: -11}),
        texture: strip({hpf: 200, width: 1.3, reverbWeight: 1.3, sends: {delay: 0.12}, balanceLu: -12}),
      },
      buses: [{id: 'bus:drums', roles: ['drums'], strip: strip({dynamics: compress(4, 0.01, 0.15, 3)})}],
    };
  },
  // A dance mix: everything that holds a note steps back each time the kick lands, the reverb is
  // kept out of the low end, the echo bounces between the sides on the dotted eighth.
  electronic(v, bpm) {
    const depth = 9, release = round(pumpRelease(bpm, depth), 3);
    return {
      describe: 'a dance mix: bass and pads pumping under the kick, a clean low end, ping-pong echoes',
      effects: {reverbType: REVERB.hall, reverbSeconds: round(MEASURED.popReverbSeconds(bpm) * lerp(1.2, 3, v.space), 2), reverbPredelayMs: 30,
        reverbLowCut: 300, reverbTone: 6000, reverbWidth: 1.2, roomType: REVERB.ambience, roomSeconds: -1, roomReturn: 0.5,
        delayMode: DELAY.pingPong, delayMs: -1, delayBeats: 0.75, delayFeedback: 0.35, delayTone: 5000, delayLowCut: 300},
      busCompression: {ratio: 4, attack: 0.01, release: 0.1, knee: 6, thresholdDb: -12, targetReductionDb: MEASURED.glueReductionDb}, wetLu: -13,
      roles: {
        drums: strip({hpf: 0, dynamics: compress(4, MEASURED.drums.attack, 0.08, 4), sends: {room: 0.2}, reverbWeight: 0.3, balanceLu: -5.5}),
        bass: strip({hpf: 30, dynamics: compress(4, 0.01, 0.08, 4), width: 0, reverbWeight: 0, balanceLu: -7}),
        lead: strip({hpf: 150, dynamics: compress(2.5, MEASURED.lead.attack, MEASURED.lead.release, 3), sends: {delay: 0.25}, balanceLu: -4}),
        keys: strip({hpf: 150, width: 1.2, sends: {delay: 0.1}, balanceLu: -10}),
        pad: strip({hpf: 200, width: 1.4, reverbWeight: 1.2, balanceLu: -10}),
        texture: strip({hpf: 250, width: 1.5, reverbWeight: 1.3, sends: {delay: 0.2}, balanceLu: -11}),
      },
      sidechain: {from: 'drums', to: ['bass', 'pad', 'keys'], keyFilterHz: 150,
        dynamics: {mode: 'duck', ratio: MEASURED.pump.ratio, threshold: MEASURED.pump.threshold, attack: MEASURED.pump.attack, release, range: depth, knee: 2}},
    };
  },
  // Dub: the springs and the tape echo are instruments; the bass is big, dry and in the middle.
  dub(v, bpm) {
    return {
      describe: 'a dub mix: a spring tank and a tape echo played as instruments, the bass big and dry',
      effects: {reverbType: REVERB.spring, reverbSeconds: 2.2, reverbPredelayMs: 0, reverbLowCut: 250, reverbTone: 5000,
        delayMode: DELAY.tape, delayMs: -1, delayBeats: bpm < 90 ? 0.75 : 0.5, delayFeedback: round(lerp(0.5, 0.7, v.space), 2),
        delayTone: 3000, delayLowCut: 250, driveType: DRIVE.tape, driveAmount: 0.25, driveTone: 4000},
      busCompression: {ratio: 2, attack: 0.03, release: 0.3, knee: 6, thresholdDb: -14, targetReductionDb: 2}, wetLu: -10,
      roles: {
        drums: strip({hpf: 0, dynamics: compress(3, MEASURED.drums.attack, MEASURED.drums.release, 3), sends: {delay: 0.3, drive: 0.15}, reverbWeight: 0.8, balanceLu: -6.5}),
        bass: strip({hpf: 30, dynamics: compress(2.5, 0.015, 0.1, 3), width: 0, reverbWeight: 0, balanceLu: -5}),
        keys: strip({hpf: 150, sends: {delay: 0.35}, reverbWeight: 1.2, balanceLu: -9}),
        lead: strip({hpf: 150, sends: {delay: 0.4}, balanceLu: -4}),
        pad: strip({hpf: 200, sends: {delay: 0.15}, balanceLu: -11}),
        texture: strip({hpf: 250, sends: {delay: 0.3}, reverbWeight: 1.3, balanceLu: -11}),
      },
    };
  },
  // Ambient: a long room, pre-delayed so the notes stay clear of it, the wash beyond what a pop
  // listener calls too wet, because the wash is the music. Nothing compressed.
  ambient(v, bpm) {
    const cathedral = v.space > 0.8;
    return {
      describe: 'an ambient wash: a long room, moving pads, nothing compressed',
      effects: {reverbType: cathedral ? REVERB.cathedral : REVERB.hall, reverbSeconds: round(lerp(3.5, 8, v.space), 2), reverbPredelayMs: 40,
        reverbLowCut: 150, reverbTone: 7000, reverbWidth: 1.3, chorusRateHz: 0.3, chorusDepthMs: 4, chorusReturn: 0.5,
        delayMode: DELAY.tape, delayMs: -1, delayBeats: bpm < 70 ? 1 : 1.5, delayFeedback: 0.45, delayTone: 3500, delayLowCut: 200},
      busCompression: {ratio: 1.5, attack: 0.03, release: 0.6, knee: 12, thresholdDb: -12, targetReductionDb: 1}, wetLu: -7,
      roles: {
        default: strip({hpf: 60}),
        pad: strip({hpf: 80, width: 1.5, sends: {chorus: 0.25, delay: 0.15}, reverbWeight: 1.2}),
        texture: strip({hpf: 120, width: 1.6, sends: {chorus: 0.2, delay: 0.35}, reverbWeight: 1.3}),
        lead: strip({hpf: 120, sends: {delay: 0.3}}),
        bass: strip({hpf: 30, width: 0, reverbWeight: 0.4}),
      },
      kit: {perspective: 'audience', distance: 0.6}, punch: false,
    };
  },
  // Lo-fi: a sampler's bandwidth, tape's saturation and wobble, a small room, hard glue.
  lofi(v, bpm) {
    return {
      describe: 'lo-fi: a sampler’s bandwidth, tape saturation, a small room, heavy glue',
      effects: {reverbType: REVERB.ambience, reverbSeconds: 0.5, reverbPredelayMs: 8, reverbLowCut: 250, reverbTone: 3500,
        delayMode: DELAY.tape, delayMs: -1, delayBeats: MEASURED.echoBeats(bpm), delayFeedback: 0.3, delayTone: 2800, delayLowCut: 250,
        driveType: DRIVE.tape, driveAmount: 0.35, driveTone: 3500, chorusRateHz: 0.5, chorusDepthMs: 2},
      busCompression: {ratio: 4, attack: 0.03, release: 0.15, knee: 6, thresholdDb: -16, targetReductionDb: 4.5}, wetLu: -15,
      roles: {
        default: strip({hpf: 90, lpf: 9000, width: 0.9}),
        drums: strip({hpf: 40, lpf: 10000, dynamics: compress(4, 0.03, 0.1, 5), sends: {drive: 0.25}, reverbWeight: 0.5, balanceLu: -6}),
        bass: strip({hpf: 35, lpf: 6000, width: 0, reverbWeight: 0, balanceLu: -8}),
        keys: strip({hpf: 120, lpf: 7000, width: 0.9, sends: {drive: 0.2, chorus: 0.15}, balanceLu: -8}),
        lead: strip({hpf: 150, lpf: 8000, sends: {delay: 0.15}, balanceLu: -5}),
      },
    };
  },
  // Industrial: grit is the point. Fuzz, a hard-compressed parallel copy of the kit, a gated room.
  industrial(v, bpm) {
    const grit = round(lerp(0.3, 0.7, 1 - v.tonality), 2);
    return {
      describe: 'industrial: fuzz, a gated room, a hard-crushed parallel kit',
      effects: {reverbType: REVERB.room, reverbSeconds: 0.7, reverbPredelayMs: 6, reverbLowCut: 200, reverbTone: 6000,
        roomType: REVERB.gated, roomSeconds: -1, roomReturn: 0.7,
        driveType: DRIVE.fuzz, driveAmount: grit, driveTone: 5000, driveReturn: 0.6,
        compressionMode: 1, compressionThreshold: -30, compressionRatio: 8, compressionAttack: 0.001, compressionRelease: 0.1,
        compressionKnee: 3, compressionMakeup: 12, compressionReturn: 0.6},
      busCompression: {ratio: 4, attack: 0.01, release: 0.12, knee: 6, thresholdDb: -14, targetReductionDb: 4}, wetLu: -14,
      roles: {
        drums: strip({hpf: 30, dynamics: compress(4, 0.01, 0.1, 5), sends: {room: 0.4, compression: 0.5, drive: 0.3}, reverbWeight: 0.3, balanceLu: -6}),
        bass: strip({hpf: 35, dynamics: compress(4, 0.01, 0.08, 4), sends: {drive: 0.35}, width: 0, reverbWeight: 0, balanceLu: -7}),
        texture: strip({hpf: 150, sends: {drive: 0.4}, balanceLu: -8}),
        lead: strip({hpf: 150, dynamics: compress(3, MEASURED.lead.attack, MEASURED.lead.release, 4), sends: {drive: 0.2}, balanceLu: -4}),
        default: strip({hpf: 120, sends: {drive: 0.25}}),
      },
    };
  },
  // The 1980s: a gated room on the kit, its hold an eighth note; a big plate; chorus on the keys.
  eighties(v, bpm) {
    return {
      describe: 'the 1980s: a gated room on the kit, a big plate, chorused keys',
      effects: {reverbType: REVERB.plate, reverbSeconds: round(lerp(1.5, 2.4, v.space), 2), reverbPredelayMs: 25, reverbLowCut: MEASURED.sendLowCut, reverbTone: 7000,
        roomType: REVERB.gated, roomSeconds: -1, roomReturn: 0.8, chorusRateHz: 0.8, chorusDepthMs: 3,
        delayMode: DELAY.line, delayMs: -1, delayBeats: MEASURED.echoBeats(bpm), delayFeedback: 0.2, delayTone: 5000, delayLowCut: MEASURED.sendLowCut},
      busCompression: {ratio: 2, attack: 0.01, release: 0.3, knee: 6, thresholdDb: -14, targetReductionDb: MEASURED.glueReductionDb}, wetLu: -11,
      roles: {
        drums: strip({hpf: 30, dynamics: compress(4, MEASURED.drums.attack, MEASURED.drums.release, 5), sends: {room: 0.6}, reverbWeight: 0.3, balanceLu: MEASURED.balanceLu.drums}),
        bass: strip({hpf: 35, dynamics: compress(MEASURED.bass.ratio, 0.015, 0.08, 4), width: 0, sends: {chorus: 0.2}, reverbWeight: 0, balanceLu: MEASURED.balanceLu.bass}),
        keys: strip({hpf: 120, width: 1.3, sends: {chorus: 0.3}, balanceLu: -9}),
        lead: strip({hpf: 120, dynamics: compress(MEASURED.lead.ratio, MEASURED.lead.attack, MEASURED.lead.release, 4), sends: {delay: 0.2}, balanceLu: MEASURED.balanceLu.lead}),
        pad: strip({hpf: 150, width: 1.3, sends: {chorus: 0.2}, balanceLu: -11}),
        texture: strip({hpf: 200, width: 1.3, balanceLu: -12}),
      },
    };
  },
  // Dream pop and shoegaze: a long hall, chorus and tape drive on everything that holds a chord.
  dreamy(v, bpm) {
    return {
      describe: 'a dreamy wall: a long hall, chorus and tape drive on everything that holds a chord',
      effects: {reverbType: REVERB.hall, reverbSeconds: round(lerp(2.5, 4.5, v.space), 2), reverbPredelayMs: 30, reverbLowCut: MEASURED.sendLowCut, reverbTone: 6000,
        reverbWidth: 1.2, chorusRateHz: 0.4, chorusDepthMs: 4, driveType: DRIVE.tape, driveAmount: 0.3, driveTone: 5000,
        delayMode: DELAY.tape, delayMs: -1, delayBeats: 0.75, delayFeedback: 0.4, delayTone: 3500, delayLowCut: 200},
      busCompression: {ratio: 2, attack: 0.03, release: 0.3, knee: 6, thresholdDb: -14, targetReductionDb: 2.5}, wetLu: -8,
      roles: {
        drums: strip({hpf: 30, dynamics: compress(3, MEASURED.drums.attack, MEASURED.drums.release, 3), reverbWeight: 0.6, balanceLu: -8}),
        bass: strip({hpf: 35, width: 0, reverbWeight: 0.2, balanceLu: -9}),
        keys: strip({hpf: 120, width: 1.3, sends: {chorus: 0.35, drive: 0.25}, balanceLu: -8}),
        pad: strip({hpf: 120, width: 1.5, sends: {chorus: 0.35, drive: 0.2}, reverbWeight: 1.2, balanceLu: -9}),
        texture: strip({hpf: 150, width: 1.5, sends: {chorus: 0.3, delay: 0.2}, balanceLu: -10}),
        lead: strip({hpf: 120, sends: {delay: 0.2}, balanceLu: -4}),
      },
      // A wall of sound is heard from the audience, some way off (the user: "a 'wall of sound' is usually from an
      // audience perspective, a certain distance away, I think").
      kit: {perspective: 'audience', distance: 0.6},
    };
  },
};
// Where a kit is heard from (shared/kit-channels.js KIT_PERSPECTIVES) and how far back its drums stand at the least, 0
// to 1: the drummer's seat and close, unless an approach says otherwise. The user, 26 September 2026: "If all other
// things are equal, the mixbot should favour placing individual drums from the drummer's perspective (with the option
// to influence and change this preference depending on intended aesthetics".
const KIT_VIEW = Object.freeze({perspective: 'drummer', distance: 0});

const SEND_KEYS = ['room', 'delay', 'chorus', 'drive', 'compression'];
const ACCOMPANIMENT_LU = -10;

// A voice featured, whatever the approach balances the rest at (the owner, 3 October 2026: "where voice is involved, it
// should be mixed in such a way that it cuts through the rest of the texture. Otherwise, we can't assess
// intelligibility properly"; "This is especially true for solo voices, as choral voices receive more reinforcement
// already"): while a voice sings, its parts together sit this many LU against every other part sounding together --
// `solo`, one singer's, as far above them as the lead vocal the measurements were read on is (De Man et al. 2014: 2.7 LU
// under the mix, so the rest 3.3 under it: 0.6 LU above), `choir`, a choir's of `singers` or more, under them (ours), and
// between as its singers grow from one to that many (live-desk.js vocalBalanceLu).
const LEAD_OVER_REST = MEASURED.balanceLu.lead - 10 * Math.log10(1 - 10 ** (MEASURED.balanceLu.lead / 10));
export const VOICE_FEATURE = Object.freeze({solo: +LEAD_OVER_REST.toFixed(2), choir: -2, singers: 4});
// Its share of the way from solo to choir, by its singers: none for one, all from `singers` on, by their doublings.
export const voiceFeatureLu = singers => {
  const share = Math.max(0, Math.min(1, Math.log2(Math.max(1, singers)) / Math.log2(VOICE_FEATURE.singers)));
  return VOICE_FEATURE.solo + (VOICE_FEATURE.choir - VOICE_FEATURE.solo) * share;
};

// A part's place in the balance, in LU against the mix (a plan's roles, above): its role's. While a singing voice is in
// the band (`voiced`), an instrumental lead is no longer the featured part: a mix puts the lead vocal alone at the front
// (De Man et al. 2014), so it steps back to where the approach balances the band's other melodic instruments, its keys
// (ours). Without a voice, the lead is the lead.
export function roleBalanceLu(roles, role, voiced = false) {
  const own = (roles?.[role || 'other'] ?? roles?.other)?.balanceLu ?? null;
  if (role === 'lead' && voiced && Number.isFinite(roles?.keys?.balanceLu)) return roles.keys.balanceLu;
  return own;
}

/**
 * The plan for an approach: by name, or the one nearest a character.
 *
 * @param which   an APPROACH_NAMES name, or a character vector
 * @param options bpm (the tempo; 108 when unknown), vector (the character, when `which` is a name)
 * @returns {approach, describe, bpm, effects, busCompression, wetLu, roles, buses, sidechain, kit, punch}: `kit`, where
 *   a kit's drums are heard from ({perspective: 'drummer' | 'audience', distance: 0-1}: KIT_VIEW unless the approach
 *   says); `punch`, the drums' punch it asks a desk for (experiments/mix-desk/punch.js): true, false or its own settings.
 *   `roles` has an entry for every role in articulation.js ROLES and one for a channel whose role
 *   is not known yet ('other'): the approach's own, or its default, or a plain strip.
 */
export function planApproach(which, {bpm = bandTempo(), vector = null} = {}) {
  const name = typeof which === 'string' ? which : approachFor(which);
  if (!RECIPES[name]) throw new Error(`No mix approach called ${name}. Known: ${APPROACH_NAMES.join(', ')}`);
  const v = aesthetic(typeof which === 'string' ? vector || SIGNATURES[name] : which), tempo = clamp(Number(bpm) || 108, 30, 300);
  const recipe = RECIPES[name](v, tempo), fallback = recipe.roles.default || strip();
  // An approach that balances parts at their own loudnesses gives every part one: a part it does
  // not name sits where an accompanying part does (ours), since a part with none would be balanced
  // as loud as the mix itself -- above the lead.
  const balanced = Object.values(recipe.roles).some(role => Number.isFinite(role.balanceLu));
  const roles = {};
  for (const role of [...ROLES, 'other']) {
    // A singing voice is the lead the measurements were read on: mixed with the approach's lead strip unless it names one.
    const chosen = recipe.roles[role] || (role === 'vocal' ? recipe.roles.lead : null) || fallback;
    roles[role] = Object.freeze({...chosen, balanceLu: balanced ? chosen.balanceLu ?? ACCOMPANIMENT_LU : null,
      sends: Object.freeze(Object.fromEntries(SEND_KEYS.map(key => [key, chosen.sends?.[key] ?? 0])))});
  }
  // Every send this approach does not use is closed, and every effect setting it does not name is
  // the type's own, so moving from one approach to another leaves nothing behind.
  const effects = {reverbPredelayMs: -1, reverbBassRatio: -1, reverbTrebleRatio: -1, reverbLowCut: 20, reverbWidth: 1,
    delayMode: 0, delayMs: -1, delayLowCut: 20, driveType: 0, compressionMode: 0, compressionKnee: -1, compressionMakeup: 0,
    limiterCeiling: MEASURED.ceilingDb, ...recipe.effects};
  return Object.freeze({
    approach: name, describe: recipe.describe, bpm: tempo,
    effects: Object.freeze(effects),
    busCompression: recipe.busCompression ? Object.freeze({...recipe.busCompression}) : null,
    wetLu: recipe.wetLu,
    roles: Object.freeze(roles),
    buses: Object.freeze((recipe.buses || []).map(bus => Object.freeze({...bus}))),
    sidechain: recipe.sidechain ? Object.freeze({...recipe.sidechain}) : null,
    kit: Object.freeze({...KIT_VIEW, ...(recipe.kit || {})}),
    punch: recipe.punch === undefined ? true : recipe.punch && typeof recipe.punch === 'object' ? Object.freeze({...recipe.punch}) : Boolean(recipe.punch),
  });
}
