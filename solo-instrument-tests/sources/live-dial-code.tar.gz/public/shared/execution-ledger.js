// What actually sounded, by occurrence: the memorable-motifs report's ticket 5 ("Only actual authorized execution
// contributes to the performance history ... A partial occurrence is not a complete presentation. Aggregate actual
// event IDs against protected core requirements"), 7a's renderer side, in the shape 0f agreed (SESSIONS.md, 28
// September 22:45).
//
// A bot planning an occurrence of a motif family puts it on the notes it strikes (note-language.js strikeWith's record):
// on the occurrence's first note, `{occurrence: {id, family, events: [...], core: [...]}, event}`, declaring it once;
// on each other note, `{occurrence: id, event}`. The host reports each note that actually began (its start reached, and
// not released before it: render/bot-host.js), and the ledger keeps them:
//   - idempotent: a note reported twice, or an event struck twice in one occurrence, counts once;
//   - a presentation is complete when every core event sounded, partial when some event did and a core one did not;
//     nothing more (the report's §13.5: executed is not audible, audible not noticed, noticed not remembered);
//   - a declaration made again the same is the same; made otherwise, it is refused, never merged.
// It never learns from a note that did not sound: speculative plans, queued and abandoned alternatives never reach it.

const LIMITS=Object.freeze({occurrences:4096,events:256});
const isId=value=>typeof value==='string'&&value.length>0&&value.length<=200;
const sameList=(a,b)=>a.length===b.length&&a.every((value,index)=>value===b[index]);

export class ExecutionLedger{
  constructor(){this.occurrences=new Map;this.pending=new Map;this.refusals=[];}
  // An occurrence declared: {id, family, events, core (events, where not given)}. -> true, or false with its refusal.
  declare(value){
    const {id,family,events,core=events}=value??{};
    const refuse=reason=>{this.refusals.push({id:isId(id)?id:null,reason});if(this.refusals.length>64)this.refusals.shift();return false};
    if(!isId(id)||!isId(family))return refuse('an occurrence has an id and a family');
    if(!Array.isArray(events)||!events.length||events.length>LIMITS.events||!events.every(isId)||new Set(events).size!==events.length)return refuse('its events are distinct ids');
    if(!Array.isArray(core)||!core.every(event=>events.includes(event)))return refuse('its core is among its events');
    const known=this.occurrences.get(id);
    if(known)return known.family===family&&sameList(known.events,events)&&sameList(known.core,[...core])||refuse(`${id} was declared otherwise`);
    if(this.occurrences.size>=LIMITS.occurrences)return refuse('the ledger is full');
    const occurrence={id,family,events:[...events],core:[...core],executed:new Map};
    this.occurrences.set(id,occurrence);
    // Notes reported before their declaration arrived, taken now.
    for(const record of this.pending.get(id)??[])this.take(occurrence,record);
    this.pending.delete(id);
    return true;
  }
  // A note that began: {occurrence (an id, or its declaration), event, identity, atSeconds, tick}.
  executed(record){
    const declared=record?.occurrence&&typeof record.occurrence==='object'?record.occurrence:null;
    if(declared)this.declare(declared);
    const id=declared?declared.id:record?.occurrence;
    if(!isId(id)||!isId(record?.event))return false;
    const occurrence=this.occurrences.get(id);
    if(!occurrence){const waiting=this.pending.get(id)??[];if(waiting.length<LIMITS.events)waiting.push(record);this.pending.set(id,waiting);return false}
    return this.take(occurrence,record);
  }
  take(occurrence,record){
    if(!occurrence.events.includes(record.event))return false;
    if(occurrence.executed.has(record.event))return false;
    occurrence.executed.set(record.event,{identity:record.identity??null,atSeconds:Number.isFinite(record.atSeconds)?record.atSeconds:null,tick:Number.isSafeInteger(record.tick)?record.tick:null});
    return true;
  }
  // One occurrence's presentation: its events that sounded, and whether its core is whole.
  presentation(id){
    const occurrence=this.occurrences.get(id);if(!occurrence)return null;
    const executed=occurrence.events.filter(event=>occurrence.executed.has(event)),complete=occurrence.core.every(event=>occurrence.executed.has(event));
    return {id,family:occurrence.family,executed,complete:complete&&executed.length>0,partial:executed.length>0&&!complete,
      firstAt:executed.length?Math.min(...executed.map(event=>occurrence.executed.get(event).atSeconds??Infinity)):null};
  }
  // A family's presentations, in the order they began: how many sounded at all, how many whole.
  presentations(family){
    const list=[...this.occurrences.values()].filter(occurrence=>family===undefined||occurrence.family===family).map(occurrence=>this.presentation(occurrence.id))
      .filter(presentation=>presentation.executed.length).sort((a,b)=>(a.firstAt??0)-(b.firstAt??0)||(a.id<b.id?-1:1));
    return {any:list.length,complete:list.filter(p=>p.complete).length,partial:list.filter(p=>p.partial).length,list};
  }
  // Its history, the same for the same notes however they were reported.
  toJSON(){
    return [...this.occurrences.values()].sort((a,b)=>a.id<b.id?-1:a.id>b.id?1:0).map(occurrence=>({id:occurrence.id,family:occurrence.family,
      events:occurrence.events,core:occurrence.core,executed:occurrence.events.filter(event=>occurrence.executed.has(event)).map(event=>({event,...occurrence.executed.get(event)}))}));
  }
}
