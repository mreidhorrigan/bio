// The space of pitch collections, interpolable: a harmony's regime as the collection it moves in (the user's stress
// test, 28 September 2026: "interpolate continuously between different harmonic/tuning/stylistic regimes"). A
// collection is a tuning's form (tuning-space.js): its pitch classes in semitones above its tonic, sorted, the first 0,
// within its period. So between any two there is a collection at any fraction t, each class matched to its partner
// with the least motion: a diatonic scale halfway to the whole-tone scale is a scale whose classes lie halfway, in
// quarter tones and between; and a bot may jump, or stop anywhere between.
//
// The collections it draws come from the pitch languages' own constructions (docs/PITCH_LANGUAGES.md), each with the
// parameters that make a family of them:
// - moments of symmetry: a window of a generator in an octave (pitch-languages/mos.js), its generator anywhere from
//   680 to 720 cents (meantone's fifths to beyond the pure fifth) or from 340 to 360 (neutral thirds), five or seven
//   notes, any of its modes;
// - the symmetric collections: whole-tone, octatonic, hexatonic;
// - the harmonic series: its partials 8 to 16, octave-reduced;
// - a combination-product set: the hexany of 1, 3, 5, 7 (pitch-languages/cps.js);
// - a Xenakis sieve on the chromatic lattice (pitch-languages/sieves.js);
// - rast's 24-EDO approximation, and Bohlen-Pierce's modes in the tritave (pitch-languages/bohlen-pierce.js).
//
// Two windows of one generator's chain with the same pattern (the same numbers of large and small steps: two modes of
// the diatonic, a meantone major and a Pythagorean lydian, two pentatonic positions) are joined along the chain
// (pitch-languages/chain-paths.js, the owner's musical-space research of 29 September): one note inflected at a time,
// each keeping its degree, the generator moving between theirs; every other pair by the least-motion morph.
import {interpolateTuning,tuningOf} from './tuning-space.js';
import {alongChain} from './pitch-languages/chain-paths.js';
import {generatorWindow} from './pitch-languages/mos.js';
import {onPitchLattice} from './pitch-languages/sieves.js';
import {combinationProductSet} from './pitch-languages/cps.js';
import {BP_MODES,BP_STEP_CENTS,TRITAVE_CENTS} from './pitch-languages/bohlen-pierce.js';

const fromCents=(cents,period=12)=>{const system=[...new Set(cents.map(c=>+(((c/100)%period+period)%period).toFixed(6)))].sort((a,b)=>a-b);return system[0]===0?system:[0,...system.filter(x=>x>0)]};
const SYMMETRIC=Object.freeze({'whole-tone':[0,2,4,6,8,10],octatonic:[0,1,3,4,6,7,9,10],hexatonic:[0,1,4,5,8,9]});
const SIEVES=Object.freeze([{or:[{mod:3,residue:0},{mod:4,residue:1}]},{or:[{mod:5,residue:0},{mod:3,residue:2}]},{or:[{mod:4,residue:0},{mod:6,residue:1},{mod:3,residue:2}]}]);
// [family, weight] (ours).
export const COLLECTION_FAMILIES=Object.freeze([['mos',4],['symmetric',2],['harmonic',1],['hexany',1],['sieve',1],['rast',1],['bohlen-pierce',1]].map(Object.freeze));

const weighted=(list,random)=>{let draw=random()*list.reduce((sum,[,weight])=>sum+weight,0);for(const [value,weight] of list){draw-=weight;if(draw<=0)return value}return list.at(-1)[0]};
// A collection from anywhere in the space: {system, period, label}.
export function drawCollection(random){
  const family=weighted(COLLECTION_FAMILIES,random);
  if(family==='mos'){
    const neutral=random()<.3,generatorCents=neutral?340+20*random():680+40*random(),size=neutral?7:random()<.5?5:7,down=Math.floor(random()*size);
    const window=generatorWindow({generatorCents,size,down});
    return {system:fromCents(window.degrees.map(degree=>degree.cents)),period:12,label:`${size} of ${generatorCents.toFixed(1)}-cent generators, mode ${down}`,
      ...(window.kind==='mos'?{mos:mosOf(generatorCents,size,-down,window.counts)}:{})};
  }
  if(family==='symmetric'){const names=Object.keys(SYMMETRIC),name=names[Math.floor(random()*names.length)];return {system:[...SYMMETRIC[name]],period:12,label:name}}
  if(family==='harmonic')return {system:fromCents(Array.from({length:9},(_,k)=>1200*Math.log2((8+k)/8))),period:12,label:'partials 8 to 16'};
  if(family==='hexany')return {system:fromCents(combinationProductSet([1,3,5,7],2).items.map(item=>item.cents)),period:12,label:'the 1-3-5-7 hexany'};
  if(family==='sieve'){const index=Math.floor(random()*SIEVES.length);return {system:fromCents(onPitchLattice(SIEVES[index],{from:0,to:11}).map(item=>item.cents)),period:12,label:`sieve ${index+1}`}}
  if(family==='rast')return {system:[0,2,3.5,5,7,9,10.5],period:12,label:'rast (24-EDO)'};
  const names=Object.keys(BP_MODES),name=names[Math.floor(random()*names.length)],steps=[...BP_MODES[name].steps.replace(/\s/g,'')].map(Number);
  let at=0;const cents=[0];for(const step of steps.slice(0,-1)){at+=step;cents.push(at*BP_STEP_CENTS)}
  return {system:fromCents(cents,TRITAVE_CENTS/100),period:TRITAVE_CENTS/100,label:`Bohlen-Pierce ${BP_MODES[name].name}`};
}
// A window's place on its chain, kept with the collection (chain-paths.js): its generator, size, lowest generator (from
// the tonic; fractional between windows), period and step pattern.
const mosOf=(generatorCents,size,low,counts,periodCents=1200)=>Object.freeze({generatorCents,size,low,periodCents,counts:Object.freeze({...counts})});
export const onOneChain=(a,b)=>Boolean(a?.mos&&b?.mos&&a.mos.size===b.mos.size&&a.mos.periodCents===b.mos.periodCents&&a.mos.counts.L===b.mos.counts.L&&a.mos.counts.s===b.mos.counts.s);
// The collection t of the way from a to b: along the chain where both are windows of one pattern, else by least motion.
export function interpolateCollection(a,b,t){
  const label=t===0?a.label:t===1?b.label:`${t.toFixed(1)} from ${a.label} to ${b.label}`;
  if(onOneChain(a,b)){
    if(t===0||t===1)return {...(t===0?a:b),system:[...(t===0?a:b).system],label};
    const along=alongChain(a.mos,b.mos,t);
    return {system:fromCents(along.degrees.map(degree=>degree.cents),along.periodCents/100),period:along.periodCents/100,label,path:'chain',
      mos:mosOf(along.generatorCents,along.size,along.low,a.mos.counts,along.periodCents)};
  }
  const between=interpolateTuning(a,b,t);
  return {...between,label};
}
// A collection's pitches over a register: every class of it, in every period from the tonic, within [low, high].
// A collection as an equal division of the octave has it (`division` steps an octave): each of its pitch classes, and its
// period, the division's nearest step -- the collection a harmony planned in that division takes (a fifth-generated
// mode's 31-equal meantone, the harmonic series' 31-equal approximation), its classes kept distinct. A choice of the
// harmony planned, never a rounding of a pitch a player was given. -> the collection, its `division` said.
export function onDivision(collection,division){
  const n=Math.round(Number(division));if(!Number.isFinite(n)||n<1||!collection)return collection;
  const {system,period}=tuningOf(collection),step=12/n,near=x=>+(Math.round(x/step)*step).toFixed(6),p=Math.max(step,near(period));
  const classes=[...new Set(system.map(pc=>+(((near(pc)%p)+p)%p).toFixed(6)))].sort((a,b)=>a-b);
  return {...collection,system:classes,period:p,division:n,label:`${collection.label??'a collection'}, in ${n} equal steps an octave`};
}
export function collectionPitches(collection,{tonic=60,low=48,high=79}={}){
  const {system,period}=tuningOf(collection),out=[];
  for(let k=Math.floor((low-tonic)/period)-1;tonic+k*period<=high;k++)for(const pc of system){const pitch=tonic+k*period+pc;if(pitch>=low-1e-9&&pitch<=high+1e-9)out.push(+pitch.toFixed(6))}
  return [...new Set(out)].sort((x,y)=>x-y);
}
