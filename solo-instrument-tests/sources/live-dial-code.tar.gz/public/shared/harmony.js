import { weightedChoice } from './stochastic.js';

export const chordIntervals=shape=>String(shape).split('_').map(Number).filter(Number.isFinite);
export const transposeChord=(shape,root,base=60)=>chordIntervals(shape).map(interval=>base+root+interval);

export function weightedPitchClass(weights){
  const values=Array.from({length:12},(_,index)=>index),usable=values.map(index=>Math.max(0,Number(weights?.[index])||0));
  return usable.some(Boolean)?weightedChoice(values,usable):0;
}

export function corpusInitialShape(corpus){
  const shapes=Object.keys(corpus||{}),weights=shapes.map(shape=>Math.max(0,Number(corpus[shape]?.initial)||0));
  return shapes.length?(weights.some(Boolean)?weightedChoice(shapes,weights):shapes[0]):'0_3_7';
}

export function harmonyTransitions(record={}){
  return Object.entries(record).filter(([key,value])=>key.endsWith('>')&&!key.startsWith('>')&&Array.isArray(value)).map(([key,weights])=>({shape:key.slice(0,-1),weights}));
}

export function corpusNextChord(corpus,currentShape){
  const transitions=harmonyTransitions(corpus?.[currentShape]),usable=transitions.filter(item=>item.weights.some(value=>Number(value)>0));
  if(!usable.length){const shape=corpusInitialShape(corpus);return{shape,root:weightedPitchClass(corpus?.[shape]?.initial)}}
  const totals=usable.map(item=>item.weights.reduce((sum,value)=>sum+Math.max(0,Number(value)||0),0)),selected=weightedChoice(usable,totals);
  return{shape:selected.shape,root:weightedPitchClass(selected.weights)};
}

export function observedDuration(record={},fallback=1){
  const raw=Array.isArray(record.duration)?record.duration:record.duration==null?[]:[record.duration],counts=new Map;
  // Map preserves first occurrence order and therefore the existing seeded draw.
  for(const item of raw){const value=Number(item);if(Number.isFinite(value)&&value>0)counts.set(value,(counts.get(value)||0)+1);}
  return counts.size?weightedChoice([...counts.keys()],[...counts.values()]):fallback;
}

export function normalizeProbabilityVector(values,length=12){
  const vector=Array.from({length},(_,index)=>Math.max(0,Number(values?.[index])||0)),maximum=Math.max(...vector,0);return maximum?vector.map(value=>value/maximum):vector;
}

export function parseChordPlan(values){
  const input=Array.isArray(values)?values:[values],groups=[];for(const value of input){if(Array.isArray(value)){const notes=value.map(Number).filter(Number.isFinite);if(notes.length)groups.push(notes);continue}const notes=String(value??'').replace(/^"|"$/g,'').trim().split(/[ _]+/).map(Number).filter(Number.isFinite);if(notes.length)groups.push(notes)}return groups;
}
