// The noise of a player's actions, and of everything else a performance does that a human would not do exactly (the
// owner, 1 November 2026: "Noise is necessary anywhere a human player acts. It should usually be quite slight, but it
// should be adjustable. It should also be subject to an adjustable frequency profile, where such is also true of the
// human player's action. The noise is adjustable by temperature values. It has a dithering function (e.g., breaking up
// comb filtering that results from overprecise frequency alignment at fine layers). We need multiple layers of
// temperature values, according to a hierarchical system. All noise in our system is seeded, for determinism").
// research/NOISE_AND_TEMPERATURE.md has the design, the sources and what is still unmeasured.
//
// **One source, counter-based.** A stream is named by its path (band/section/seat/action/parameter); its draw at an
// index comes from the piece's seed, the path and the index alone -- lowbias32 (C. Wellons, "Prospecting for hash
// functions", 2018, public domain), a few integer operations that native/strings-model/musebots-noise.h and the winds'
// engine repeat bit for bit -- so a stream is the same live and offline, and adding a stream moves no other. A normal
// deviate from two uniforms (G. E. P. Box and M. E. Muller, "A note on the generation of random normal deviates", Ann.
// Math. Statist. 29 (1958) 610-611, doi:10.1214/aoms/1177706645): its uniforms the same bits in every language, its
// deviates and shaped streams the same to the last digits of each language's logarithm, cosine and power
// (test/noise.test.mjs holds the C++ to 1e-12).
//
// **Its spectrum, the action's.** White deviates shaped by a profile: a power law, its power falling as 1/f^beta between
// `low` and `high` (Hz, or per event for a stream drawn once an event), flat below `low` and falling as 1/f^2 above
// `high`, made by one-pole low-passes an octave apart, each from its own white stream, weighted by the law at their
// corners (so a beta of 0 is white to `high`, 2 a drift); and a tremor, a resonance at `tremor.hz`
// of bandwidth hz/q, carrying `tremor.share` of the variance. Each filter begun from its own stationary state, so a
// stream has its whole variance from its first draw. Out: unit variance, scaled by the action's measured deviation
// (`sd`, in its unit, or a share of the value where its unit is one) and by its temperature.
//
// **Temperatures, layered.** A tree of temperatures ({value, <child>: subtree | number}, `*` standing for any child): a
// path's temperature the product of every layer's down it -- the piece's, a section's, a seat's, an action's, a
// parameter's -- each 1 where none is given. 1 is a measured player's noise, 0 none (the exact machine), above 1 more.
//
// **Dither.** A fixed deviate a path keeps for the whole piece (its draw at index 0), so that what a performance builds
// out of exact values -- a seat's tuning, a mode's frequency, a delay's length, a contact point at a whole fraction of a
// string -- is never exactly aligned with another's.
import {fnv1a} from './fnv1a.js';

const TWO32=2**32,TWO20=2**20,TWO52=2**52;

// lowbias32: a 32-bit integer's bits mixed (Wellons's constants, as published).
export function lowbias32(x){
  x=(x^x>>>16)>>>0;x=Math.imul(x,0x7feb352d)>>>0;x=(x^x>>>15)>>>0;x=Math.imul(x,0x846ca68b)>>>0;return (x^x>>>16)>>>0;
}
// A path's key: its segments joined by '/', FNV-1a.
export const noiseKey=path=>fnv1a(Array.isArray(path)?path.join('/'):String(path));
// A stream's base, from the seed (an integer under 2^32, or a text hashed) and its key.
export const noiseBase=(seed,key)=>lowbias32((lowbias32(typeof seed==='number'?seed>>>0:fnv1a(String(seed)))^key)>>>0);
// The 32 bits a stream draws at counter c (an integer under 2^53).
function word(base,c){
  const hi=Math.floor(c/TWO32)>>>0,lo=(c-hi*TWO32)>>>0;
  return lowbias32((lowbias32((base^hi)>>>0)^lowbias32(lo))>>>0);
}
// Uniform in (0, 1) at an index: 52 bits from the stream's two words there, and a half (so every step exact, in any
// language's doubles, and never 0 or 1).
export function uniformAt(base,index,sub=0){
  const c=index*4+sub*2;
  return (word(base,c)*TWO20+(word(base,c+1)>>>12)+.5)/TWO52;
}
// A standard normal deviate at an index (Box and Muller, its cosine).
export function normalAt(base,index){
  return Math.sqrt(-2*Math.log(uniformAt(base,index,0)))*Math.cos(2*Math.PI*uniformAt(base,index,1));
}

// A path's temperature in a tree of them: the product of each layer's value down the path.
export function temperatureAt(tree,path){
  const segments=Array.isArray(path)?path:String(path).split('/');
  let t=1,at=tree;
  const own=node=>typeof node==='number'?node:(node&&typeof node==='object'&&Number.isFinite(node.value)?node.value:1);
  t*=own(at);
  for(const segment of segments){
    if(!at||typeof at!=='object')break;
    at=Object.hasOwn(at,segment)?at[segment]:at['*'];
    if(at===undefined)break;
    t*=own(at);
  }
  if(!(t>=0))throw new RangeError(`temperature of ${segments.join('/')}: ${t} (each layer's 0 or more)`);
  return t;
}

// A profile's sections: one-pole low-passes an octave apart from `low` to `high` (bilinear, so each falls to nothing at
// half the rate), each weighted by the power law at its corner times the half octaves either side of it, the lowest also
// standing for the law's tail below `low` (low^-beta/(2-beta): flat below it) and the highest for its tail above `high`
// (high^-beta/beta), so that the sum falls as 1/f^beta to the band's edges -- a beta of 0 the top one alone, white to
// `high`; 2 the bottom one alone, a drift; and the tremor's resonance. -> {sections, tremor, power, share}: each section
// {k, a, weight}, the variances that make the whole unit.
export function shaping({beta=0,low,high,tremor=null},rate){
  if(!(rate>0))throw new RangeError(`noise rate ${rate}`);
  if(!(low>0&&high>=low&&high<rate/2))throw new RangeError(`noise band ${low}-${high} at rate ${rate} (0 < low <= high < rate/2)`);
  if(!(beta>=0&&beta<=2))throw new RangeError(`noise beta ${beta} (0 to 2)`);
  const corners=[];
  for(let f=low;f<high*(1-1e-9);f*=2)corners.push(f);
  corners.push(high);
  const n=corners.length,span=k=>Math.log(corners[k+1]/corners[k]);
  const weights=corners.map((f,k)=>{
    if(beta<=0)return k===n-1?1:0;
    if(beta>=2)return k===0?1:0;
    let w=f**-beta*((k>0?span(k-1):0)+(k<n-1?span(k):0))/2;
    if(k===0)w+=low**-beta/(2-beta);
    if(k===n-1)w+=high**-beta/beta;
    return w;
  });
  const sections=corners.map((f,k)=>{
    const t=Math.tan(Math.PI*f/rate),a=(1-t)/(1+t);
    return {k,hz:f,a,weight:weights[k],variance:weights[k]*(1-a)/2};
  }).filter(s=>s.weight>0);
  const power=sections.reduce((s,x)=>s+x.variance,0);
  let resonance=null;
  const share=tremor&&tremor.share>0?tremor.share:0;
  if(share){
    if(!(tremor.share<=1&&tremor.hz>0&&tremor.hz<rate/2&&tremor.q>0))throw new RangeError(`noise tremor ${JSON.stringify(tremor)}`);
    const theta=2*Math.PI*tremor.hz/rate,r=Math.exp(-Math.PI*(tremor.hz/tremor.q)/rate),p1=2*r*Math.cos(theta),p2=-r*r;
    const variance=(1-p2)/((1+p2)*((1-p2)**2-p1**2));
    resonance={hz:tremor.hz,p1,p2,variance,rho:p1/(1-p2)};
  }
  return {sections,power,tremor:resonance,share};
}

// A stream of shaped noise, unit variance: its seed, its path, its rate (draws a second, or 1 for one an event) and its
// profile. next() -> its next deviate; skip(n) passes over n, drawn as they would have been.
export class NoiseStream{
  constructor({seed,path,rate,profile}){
    this.path=Array.isArray(path)?path.join('/'):String(path);
    this.shape=shaping(profile,rate);
    const base=k=>noiseBase(seed,noiseKey(`${this.path}#${k}`));
    this.bases=this.shape.sections.map(s=>base(s.k));
    this.index=0;
    // (Each section begun from its stationary state: its last input, and its output, (1-a)/2 of that input and the rest
    // of its variance, (1-a^2)/4, drawn apart.)
    const start=noiseBase(seed,noiseKey(`${this.path}#start`));
    this.last=this.shape.sections.map(s=>normalAt(start,2*s.k+1));
    this.state=this.shape.sections.map((s,j)=>(1-s.a)/2*this.last[j]+Math.sqrt((1-s.a*s.a)/4)*normalAt(start,2*s.k));
    this.gains=this.shape.sections.map(s=>Math.sqrt(s.weight/this.shape.power));
    const t=this.shape.tremor;
    if(t){
      this.tremorBase=base('tremor');
      const y2=Math.sqrt(t.variance)*normalAt(start,1000),y1=t.rho*y2+Math.sqrt(t.variance*(1-t.rho*t.rho))*normalAt(start,1001);
      this.tremorState=[y1,y2];
    }
  }
  next(){
    const i=this.index++,{sections,share,tremor}=this.shape;
    let power=0;
    for(let k=0;k<sections.length;k++){
      const a=sections[k].a,x=normalAt(this.bases[k],i);
      this.state[k]=a*this.state[k]+(1-a)/2*(x+this.last[k]);
      this.last[k]=x;
      power+=this.gains[k]*this.state[k];
    }
    if(!tremor)return power;
    const [y1,y2]=this.tremorState,y=tremor.p1*y1+tremor.p2*y2+normalAt(this.tremorBase,i);
    this.tremorState=[y,y1];
    return Math.sqrt(1-share)*power+Math.sqrt(share)*y/Math.sqrt(tremor.variance);
  }
  skip(n){for(let k=0;k<n;k++)this.next();return this}
}

// A value as a player gives it: `value` moved by its noise -- a share of it where the action's deviation is a share
// (`relative`), else by the deviation itself -- scaled by the temperature. (A deviate past four of its deviations is
// held there: a player's hand never jumps.)
export function played(value,deviate,{sd,relative=false},temperature=1){
  const n=Math.max(-4,Math.min(4,deviate))*sd*temperature;
  return relative?value*(1+n):value+n;
}

// A fixed deviate a path keeps for the piece, its deviation `sd` times its temperature.
export const dither=(seed,path,sd,temperature=1)=>Math.max(-4,Math.min(4,normalAt(noiseBase(seed,noiseKey(path)),0)))*sd*temperature;

// A profile between two, at t from 0 to 1: its deviation, band and tremor by their logarithms, its beta and share
// straight (everything interpolable: CLAUDE.md).
export function profileBetween(a,b,t){
  const lin=(x,y)=>x+(y-x)*t,log=(x,y)=>Math.exp(lin(Math.log(x),Math.log(y)));
  const tremor=a.tremor||b.tremor?{hz:log(a.tremor?.hz??b.tremor.hz,b.tremor?.hz??a.tremor.hz),q:log(a.tremor?.q??b.tremor.q,b.tremor?.q??a.tremor.q),
    share:lin(a.tremor?.share??0,b.tremor?.share??0)}:null;
  return {...(a.sd!==undefined&&b.sd!==undefined?{sd:log(a.sd,b.sd)}:{}),beta:lin(a.beta??0,b.beta??0),low:log(a.low,b.low),high:log(a.high,b.high),tremor};
}
