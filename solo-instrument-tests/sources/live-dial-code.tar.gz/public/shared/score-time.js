// Authored rhythm, in rational ticks on a named axis. This is not a playback clock: seconds, tempo, rubato,
// articulation and scheduling delays never enter this value. A producer supplies both boundaries before performing
// the note. JSON keeps the fractions, and changes of axis map both boundaries, not just the onset.
import {Rational} from '../transcript/rational.js';
import {NOTE_TYPES} from './note-values.js';

export const ENSEMBLE_SCORE_AXIS='ensemble';
export class MissingScoreTime extends TypeError {
  constructor(note){
    super(`Missing symbolic score time for ${note?.voice??note?.id??'note'}; its producer must supply scoreTime`);
    this.code='MISSING_SCORE_TIME';
  }
}
export function scoreTime(at,duration,{axis=ENSEMBLE_SCORE_AXIS}={}){
  if(typeof axis!=='string'||!axis.length)throw new TypeError('A score-time axis needs an identifier');
  const start=Rational.of(at),length=Rational.of(duration);
  if(length.sign()<=0)throw new RangeError('An authored note has a positive symbolic duration');
  return Object.freeze({axis,at:start.toString(),duration:length.toString()});
}
// An unmeasured ornament is attached to an authored event boundary, ordered among its companions. Its printed
// value is independent of its sounding length. Before-graces attach to the onset, after-graces to the ending.
export function graceTime(at,{anchor,order,type,dots=0,slash=true,placement='before',axis=ENSEMBLE_SCORE_AXIS}={}){
  if(typeof anchor!=='string'||!anchor||!Number.isSafeInteger(order))throw new TypeError('A grace needs an anchor event and an integer order');
  if(!NOTE_TYPES.some(([name])=>name===type)||!Number.isSafeInteger(dots)||dots<0)throw new TypeError('A grace needs a written note value');
  if(!['before','after'].includes(placement)||typeof slash!=='boolean'||typeof axis!=='string'||!axis)throw new TypeError('Invalid grace attachment');
  return Object.freeze({kind:'grace',axis,at:Rational.of(at).toString(),anchor,order,type,dots,slash,placement});
}
// A note played freely inside a hold (a cadenza's, under its fermata: shared/clock-hold.js, bots/lib/modules/cadenza.js)
// has no metrical value at all: it is placed at its hold's tick, named by its hold and ordered within it, and the score
// leaves it to the player, marking the hold. Its gestures' beats are its own time's, not the bar's: never ticks.
export function freeTime(at,{hold,order,axis=ENSEMBLE_SCORE_AXIS}={}){
  if(typeof hold!=='string'||!hold||!Number.isSafeInteger(order))throw new TypeError('A free note needs its hold and an integer order');
  if(typeof axis!=='string'||!axis)throw new TypeError('A score-time axis needs an identifier');
  return Object.freeze({kind:'free',axis,at:Rational.of(at).toString(),hold,order});
}
export function readScoreTime(note,{axis=null}={}){
  if(!note?.scoreTime)throw new MissingScoreTime(note);
  const value=note.scoreTime,at=Rational.of(value.at);
  if(axis!==null&&value.axis!==axis)throw new RangeError(`Score time is on ${value.axis}, expected ${axis}`);
  if(value.kind==='grace')return {axis:value.axis,at,duration:Rational.ZERO,end:at,grace:graceTime(at,value)};
  if(value.kind==='free')return {axis:value.axis,at,duration:Rational.ZERO,end:at,free:freeTime(at,value)};
  if(value.kind!=null)throw new TypeError('Unknown symbolic time kind');
  const duration=Rational.of(value.duration);
  if(typeof value.axis!=='string'||!value.axis.length||duration.sign()<=0)throw new TypeError('Invalid symbolic score time');
  return {axis:value.axis,at,duration,end:at.add(duration)};
}
// Audio may carry events with no notation (an imported waveform, for example). It preserves a supplied symbolic
// interval here; a score consumer uses readScoreTime, which refuses an absent interval instead of inventing one.
export function scoreTimeFields(note){
  if(!note?.scoreTime)return {};
  const {at,duration,axis,grace,free}=readScoreTime(note);
  if(note.scoreArpeggio!=null&&typeof note.scoreArpeggio!=='boolean')throw new TypeError('A written arpeggio is an explicit boolean choice');
  return {scoreTime:grace??free??scoreTime(at,duration,{axis}),...(note.scoreId!=null?{scoreId:String(note.scoreId)}:{}),
    ...(note.scoreArpeggio!=null?{scoreArpeggio:note.scoreArpeggio}:{})};
}
// A symbolic mapping changes an interval through its two endpoints. In particular, a varying tempo relation cannot
// transform a duration by multiplying it by the rate at the onset. Performance warps do not call this function.
export function mapScoreTime(value,map,{axis=value.axis}={}){
  const {at,end,grace,free}=readScoreTime({scoreTime:value}),start=Rational.of(map(at));
  if(grace)return graceTime(start,{...grace,axis});
  if(free)return freeTime(start,{...free,axis});
  const finish=Rational.of(map(end));
  return scoreTime(start,finish.sub(start),{axis});
}
export function shiftScoreTime(value,offset,{axis=value.axis}={}){
  const delta=Rational.of(offset);
  return mapScoreTime(value,at=>at.add(delta),{axis});
}
export function scaleScoreTime(value,ratio,{axis=value.axis}={}){
  const rate=Rational.of(ratio);
  if(rate.sign()<=0)throw new RangeError('A symbolic time scale is positive');
  return mapScoreTime(value,at=>at.mul(rate),{axis});
}
export function reverseScoreTime(value,about){
  const {at,end,grace,free}=readScoreTime({scoreTime:value}),last=Rational.of(about);
  if(grace)return graceTime(last.sub(at),{...grace,placement:grace.placement==='before'?'after':'before',order:-grace.order});
  if(free)return freeTime(last.sub(at),{...free,order:-free.order});
  return scoreTime(last.sub(end),end.sub(at),{axis:value.axis});
}

// A synchronous performance scope. Delayed instrument callbacks must snapshot it when their note is planned.
export function withScoreTime(target,value,perform){
  const event=value?.scoreTime?value:{scoreTime:value};
  const symbolic=scoreTimeFields(event),before=target.scoreTime,id=target.scoreId,arpeggio=target.scoreArpeggio;
  if(!symbolic.scoreTime)throw new MissingScoreTime(event);
  target.scoreTime=symbolic.scoreTime;
  target.scoreId=event.scoreId;
  target.scoreArpeggio=symbolic.scoreArpeggio;
  try{return perform()}finally{target.scoreTime=before;target.scoreId=id;target.scoreArpeggio=arpeggio}
}

// A composer's event lifetimes, separate from sounding identities. A new event can end its group's previous events;
// another group or score axis continues independently. Only performed events are registered, so unused candidate
// voicings never send revisions. Capture's ScoreRevisions below receives these decisions, including deferred notes.
export class ScoreEvents{
  constructor(prefix='event'){this.prefix=prefix;this.serial=0;this.events=new Map}
  create(at,duration,{axis=ENSEMBLE_SCORE_AXIS,group='line',replace=false}={}){
    return {scoreId:`${this.prefix}:${++this.serial}`,scoreTime:scoreTime(at,duration,{axis}),group,replace};
  }
  perform(audio,event,play){
    const {at,axis}=readScoreTime(event),group=event.group??'line';
    if(event.replace)this.finish(audio,at,{axis,group});
    for(const [id,entry] of this.events){const own=readScoreTime(entry);if(own.axis===axis&&own.end.le(at))this.events.delete(id)}
    this.events.set(event.scoreId,event);return withScoreTime(audio,event,play);
  }
  revise(audio,event,end){
    const before=readScoreTime(event);
    event.scoreTime=scoreTime(before.at,Rational.of(end).sub(before.at),{axis:before.axis});
    this.events.set(event.scoreId,event);audio.reviseScore?.(event);
  }
  finish(audio,at,{axis=ENSEMBLE_SCORE_AXIS,group='line'}={}){
    for(const event of this.events.values()){
      const own=readScoreTime(event);
      if((event.group??'line')===group&&own.axis===axis&&own.at.lt(at)&&own.end.gt(at))this.revise(audio,event,at);
    }
  }
}

// Only a composer revises an authored event. Acoustic releases cannot call this operation. Identity is local to a
// performing voice; a revision replaces the interval while retaining pitch, performance timing and articulation.
export function reviseScoreEvent(notes,{voice,scoreId,scoreTime:value}){
  if(typeof scoreId!=='string'||!scoreId)throw new TypeError('A score revision needs an event identifier');
  const replacement=scoreTimeFields({scoreTime:value}),interval=readScoreTime(replacement),changed=[];
  if(interval.grace)throw new TypeError('An end revision requires a metrical interval');
  for(const note of notes){
    if(note.voice!==voice)continue;
    if(note.scoreTime?.kind==='grace'&&note.scoreTime.anchor===scoreId){
      const {grace}=readScoreTime(note);
      if(grace.axis!==interval.axis)throw new RangeError('A grace and its revised anchor share an axis');
      note.scoreTime=graceTime(grace.placement==='before'?interval.at:interval.end,grace);changed.push(note);continue;
    }
    if(note.scoreId!==scoreId)continue;
    const previous=readScoreTime(note);
    if(previous.axis!==interval.axis||!previous.at.eq(interval.at))throw new RangeError('An end revision keeps its authored onset and axis');
    note.scoreTime=replacement.scoreTime;
    // (Where its player breathed inside it, shares of its written length (wind-seat.js breathPlaces), the same places as
    // shares of its length revised: one past its new end never breathed, the note let go there; one on it, a breath after
    // it. Kept as shares of the length it was played at, a flute's note written 476 ticks and ended at 101 by the next
    // had been cut into slivers, its breath at 70 written at 15.)
    if(Array.isArray(note.breaths)&&interval.duration.sign()>0){
      const scale=previous.duration.div(interval.duration),kept=[];
      for(const share of note.breaths){const at=Rational.of(share).mul(scale);if(at.lt(Rational.ONE))kept.push(at.toString());else if(at.eq(Rational.ONE))note.breathAfter=true}
      if(kept.length)note.breaths=kept;else delete note.breaths;
    }
    changed.push(note);
  }
  return changed;
}

// Revisions can arrive before a deferred sample reports its note. Retain the latest composed interval and apply it
// when that event arrives; scheduling order must not undo a composer's decision.
export class ScoreRevisions{
  constructor(){this.latest=new Map}
  key({voice,scoreId}){return JSON.stringify([voice,String(scoreId)])}
  revise(notes,event){
    readScoreTime(event);
    if(typeof event.scoreId!=='string'||!event.scoreId)throw new TypeError('A score revision needs an event identifier');
    const changed=reviseScoreEvent(notes,event);
    this.latest.set(this.key(event),{...event,...scoreTimeFields(event)});
    return changed;
  }
  apply(note){
    const id=note.scoreTime?.kind==='grace'?note.scoreTime.anchor:note.scoreId;
    if(id!=null){const revision=this.latest.get(this.key({...note,scoreId:id}));if(revision)reviseScoreEvent([note],revision)}
    return note;
  }
  prune(before){for(const [key,event] of this.latest)if(Number.isFinite(event.bar)&&event.bar<before)this.latest.delete(key)}
}
