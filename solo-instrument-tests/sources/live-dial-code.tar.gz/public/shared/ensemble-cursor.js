// A metrical cursor describes the NEXT pulse in the primary's monotonic time.
// Recipients and immutable forecasts use this same advancement rule. Each
// subdivision interval is a constant-period segment; tempo curves choose the
// period of subsequent intervals without resetting accumulated phase. A hold
// (clock-hold.js) at a pulse puts its seconds between that pulse and the rest of
// it: a cued one's bound until its cue comes, the latest it can be. Inside a
// rubato span (rubato-clocks.js) a pulse lasts what the span's map says; the
// cursor's tempo stays its own until the span ends, and then goes on at its last
// density, so a span's extremes never leave the meter's range in a cursor.
import {tempoInRange} from './tempo-range.js';
import {authoredBpmAt} from './score-tempo.js';
import {curveTempo} from './tempo-curve.js';
import {holdAtPulse,holdSeconds} from './clock-hold.js';
import {cursorRubatoPulse} from './rubato-clocks.js';

export function advanceCursor(state) {
  const s=state;
  holdAtPulse(s,s.at);
  const rubato=cursorRubatoPulse(s,s.at);
  if(rubato?.bpm)s.bpm=rubato.bpm;
  const interval=rubato?.seconds??60/s.bpm/s.meter.subdivision;
  if(s.holding)s.holding.pulseSeconds=interval;
  s.at+=interval+holdSeconds(s);
  s.tick++;s.tickInBar++;
  if(s.tickInBar>=s.meter.pulsesPerBar){s.tickInBar=0;s.bar++;}
  if(s.tickInBar===0) {
    if(s.pendingMeter&&s.bar>=s.pendingMeter.targetBar){s.meter=s.pendingMeter.meter;s.pendingMeter=null;}
    if(s.pendingTempo&&s.bar>=s.pendingTempo.targetBar){
      s.curve={...s.pendingTempo,startBpm:s.bpm,startBar:s.bar};s.pendingTempo=null;
    }
    if(s.inputTempoCommit&&s.bar>=s.inputTempoCommit.endBar)s.inputTempoCommit=null;
  }
  if(s.curve) {
    const c=s.curve,x=c.durationBars===0?1:Math.max(0,Math.min(1,(s.bar+s.tickInBar/s.meter.pulsesPerBar-c.startBar)/c.durationBars));
    s.bpm=curveTempo(c,x);
    if(x===1)s.curve=null;
  }
  authoredBpmAt(s);
  if(s.tickInBar%s.meter.subdivision===0)s.beat++;
  return s;
}

export const cursorBeat=cursor=>cursor.beat+(cursor.tickInBar%cursor.meter.subdivision)/cursor.meter.subdivision;

// A curve's tempi are in the meter's range (the notated beat's, or its named tempo unit's, shared/tempo-range.js): the
// cursor's meter, or the one it is about to change to.
const inRange=(bpm,state)=>tempoInRange(bpm,state.meter)||Boolean(state.pendingMeter?.meter)&&tempoInRange(bpm,state.pendingMeter.meter);
export function validateCursorCurves(state) {
  for(const value of [state.pendingTempo,state.curve])if(value&&(
    !Number.isFinite(value.targetBpm)||!inRange(value.targetBpm,state)||
    !Number.isSafeInteger(value.durationBars)||value.durationBars<0||value.durationBars>1024||
    !['linear','easeInOut','exponential'].includes(value.shape)))throw new Error('Invalid tempo curve');
  if(state.pendingTempo&&(!Number.isSafeInteger(state.pendingTempo.targetBar)||state.pendingTempo.targetBar<0))
    throw new Error('Invalid tempo boundary');
  if(state.curve&&(!Number.isFinite(state.curve.startBpm)||!inRange(state.curve.startBpm,state)||
    !Number.isSafeInteger(state.curve.startBar)||state.curve.startBar<0||state.curve.startBar>state.bar))
    throw new Error('Invalid active tempo curve');
}
