import {FUTURE_LIMITS as LIMITS,actor,actorKey,sameActor,checkOrigin,frozenJson,planReference,planKey,
  occurrenceKey,planAuthor,validateTimedPlan,PreparedContentCache,number,dataDigest} from './planning-data.js';
import {PlanningRecovery,ordinaryRecoveryRecords} from './planning-recovery.js';
import {TempoTimelineRegistry} from './tempo-timeline.js';

const hasActor=(plan,participant)=>plan.scope.participants.some(value=>sameActor(value,participant));
const finalKey=plan=>occurrenceKey(plan);
const originOf=message=>actor({id:message.source,incarnation:message.sourceIncarnation});
const frozen=value=>frozenJson(value).data;

// Reusable by any bot. No DOM, socket, timer, AudioContext, or conductor import.
// Call advance from the host's ordinary maintenance pump, not from an audio
// callback. prepareMaterial is a pure synchronous adapter; content retrieval
// happens separately and can be asynchronous.
export class FuturePlanningRuntime {
  constructor({identity,timeline,clock,send=()=>{},authorizeAuthor=(author)=>sameActor(author,identity),
    loadContent,prepareMaterial=value=>value,execute,cleanup=()=>{},onFact=()=>{},
    monotonicNow=()=>performance.now()/1000,cache=new PreparedContentCache()}={}) {
    this.identity=actor(identity);this.timelines=new TempoTimelineRegistry(timeline);this.clock=clock;this.send=send;this.authorizeAuthor=authorizeAuthor;
    this.loadContent=loadContent;this.prepareMaterial=prepareMaterial;this.execute=execute;this.cleanup=cleanup;this.onFact=onFact;
    this.monotonicNow=monotonicNow;this.cache=cache;this.records=new Map();this.finals=new Map();this.cancellations=new Map();
    this.pendingFinals=new Map();this.tombstones=new Map();this.facts=[];this.recordBytes=0;this.preparedBytes=0;
    this.generation=0;this.stopped=false;this.rejoinAt=-Infinity;
    this.recovery=new PlanningRecovery(this);
    this.contentWaiters=new Map();
    this.metrics={publications:0,duplicates:0,conflicts:0,rejected:0,preparationMs:[],admissions:0,misses:0};
  }
  get timeline(){return this.timelines.current;}
  resolveTimeline(placement){return this.timelines.resolve(placement);}
  pendingBeatLimit(now){return now===null?LIMITS.futureBeats:Math.max(...[...this.timelines.maps.values()].map(map=>map.beatAtReference(Math.max(now,map.anchor?.reference??-Infinity))))+LIMITS.futureBeats;}
  pendingStartReference(value){return Math.max(...[...this.timelines.maps.values()].map(map=>value.startBeat<(map.anchor?.beat??-Infinity)?-Infinity:map.referenceAtBeat(value.startBeat)));}
  installTimeline(value,options={}){
    const installed=this.timelines.install(value,{...options,now:this.now()});
    if(installed)this.emit('tempo-map-installed',{tempoId:this.timeline.id,tempoRevision:this.timeline.revision,effectiveBeat:this.timeline.effectiveBeat});
    return installed;
  }
  reconcileTimelines(values,{authorized=false}={}){
    const added=this.timelines.reconcile(values,{authorized});
    if(added.length)this.emit('tempo-maps-recovered',{tempoId:this.timeline.id,tempoRevision:this.timeline.revision,count:added.length});
    return added;
  }
  now(){try{const value=this.clock.now();return Number.isFinite(value)?value:null;}catch{return null;}}
  ready(){return !this.stopped&&this.clock.ready()===true;}
  emit(type,details={}) {
    const fact=frozen({type,atReference:this.now(),...details});this.facts.push(fact);
    if(this.facts.length>LIMITS.diagnostics)this.facts.shift();this.onFact(fact);return fact;
  }
  transition(record,state,details={}) {
    if(record.state===state&&record.reason===details.reason)return;
    record.state=state;record.reason=details.reason;
    record.statusSequence=(record.statusSequence||0)+1;
    const fact={version:2,plan:planReference(record.plan),recipient:this.identity,state,sequence:record.statusSequence,atReference:this.now(),...details};
    this.emit('recipient',fact);
    if(hasActor(record.plan,this.identity))this.send('/broadcast/plan/status',[fact]);
  }
  reject(error,value) {this.metrics.rejected++;this.emit('rejected',{reason:error.message,...(value?.planId?{planId:value.planId}:{})});return {ok:false,reason:error.message};}
  async receive(message,origin) {
    if(message?.address?.startsWith('/agent/planning/')) {
      try{return await this.recovery.receive(message,origin?actor(origin):originOf(message));}
      catch(error){return this.reject(error);}
    }
    if(message?.args?.[0]?.version!==2)return {ignored:true};
    try {
      const value=message.args[0],source=origin?actor(origin):originOf(message);
      switch(message.address) {
        case '/broadcast/plan':return await this.ingestPlan(value,source);
        case '/broadcast/plan/commit':return this.ingestFinal(value,source);
        case '/broadcast/plan/status':return this.ingestStatus(value,source);
        case '/broadcast/plan/cancel':return this.ingestCancel(value,source);
        default:return {ignored:true};
      }
    } catch(error){return this.reject(error,message.args?.[0]);}
  }
  checkPlacement(plan) {
    const timeline=this.resolveTimeline(plan);
    if(timeline.anchor)for(const field of ['startBeat','endBeat','prepareByBeat','commitByBeat','windowStartBeat','windowEndBeat','snapshotCloseBeat','selectionByBeat'])
      if(plan[field]!==undefined)timeline.checkCoverage(plan[field]);
    const start=timeline.referenceAtBeat(plan.startBeat),commit=timeline.referenceAtBeat(plan.commitByBeat);
    if(start-commit<LIMITS.acceptanceSeconds-1e-9)throw new Error('Final acceptance must close at least 500 ms before output');
    const now=this.now();
    if(now!==null&&plan.startBeat-timeline.beatAtReference(now)>LIMITS.futureBeats)throw new Error('Plan exceeds the retained future horizon');
    return timeline;
  }
  // Each plan visited once: grey while its dependencies are open (a dependency reached again while grey is a cycle),
  // and the longest chain below it remembered, so the depth limit counts the longest path even where a shorter one was
  // found first. Copying the path at every step visited each shared ancestor once for every path to it: 48 plans in six
  // layers took 299,592 lookups (the mathematical audit's I03). A dependency not yet here is not an error.
  checkDependencies(key,plan) {
    const open=new Set(),below=new Map();
    const visit=(current,depth)=>{
      if(depth>LIMITS.depth)throw new Error('Plan dependency depth exceeded');
      if(open.has(current))throw new Error('Plan dependency cycle');
      if(below.has(current)){if(depth+below.get(current)>LIMITS.depth)throw new Error('Plan dependency depth exceeded');return below.get(current)}
      const found=current===key?plan:this.records.get(current)?.plan;
      if(!found){below.set(current,0);return 0}
      open.add(current);
      let height=0;
      for(const dependency of found.dependencies)height=Math.max(height,1+visit(planKey(dependency.plan),depth+1));
      open.delete(current);below.set(current,height);
      return height;
    };
    visit(key,0);
  }
  async ingestPlan(input,origin,{awaitPreparation=true}={}) {
    const plan=validateTimedPlan(input),key=planKey(plan),json=frozenJson(plan);
    checkOrigin(planAuthor(plan),origin);
    if(!this.authorizeAuthor(planAuthor(plan),plan))throw new Error('This recipient has not authorized the plan author');
    if(this.tombstones.has(key))return {ok:false,reason:'retired-plan'};
    const previous=this.records.get(key);
    if(previous) {
      if(previous.canonical!==json.canonical){this.metrics.conflicts++;throw new Error('Immutable plan revision conflicts with existing content');}
      this.metrics.duplicates++;return {ok:true,duplicate:true,record:previous};
    }
    // A retained record owns its exact map even after a checkpoint retires that
    // revision from lookup. Only new plans need to resolve available coverage.
    const timeline=this.checkPlacement(plan);
    if(this.records.size>=LIMITS.records||this.recordBytes+json.bytes>LIMITS.totalRecordBytes)throw new Error('Plan retention budget exhausted');
    this.checkDependencies(key,plan);
    const record={plan,timeline,key,canonical:json.canonical,bytes:json.bytes,state:'new',prepared:null,preparedBytes:0,preparing:null,
      statuses:new Map(),final:null,cancel:null,handle:null,generation:this.generation};
    this.records.set(key,record);this.recordBytes+=json.bytes;this.metrics.publications++;
    this.transition(record,'received');
    const pending=this.pendingFinals.get(key);this.pendingFinals.delete(key);
    if(pending)for(const item of pending)try{this.ingestFinal(item.value,item.origin);}catch(error){this.reject(error);}
    const preparing=this.prepare(record);if(awaitPreparation)await preparing;this.tryAccept(record);
    return {ok:true,record};
  }
  dependenciesReady(record) {
    return record.plan.dependencies.every(dependency=>{
      const parent=this.records.get(planKey(dependency.plan));
      return Boolean(parent?.prepared&&(dependency.type==='prepared-plan'||parent.final));
    });
  }
  async content(reference) {
    if(reference.format==='rest')return Object.freeze({rest:true});
    let material=this.cache.get(reference);
    if(!material) {
      if(!this.loadContent)throw new Error('Required content is unavailable');
      let resolve;
      const recovered=new Promise(done=>{resolve=done}),waiters=this.contentWaiters.get(reference.digest)||new Set();
      if(this.contentWaiters.size>=16&&!this.contentWaiters.has(reference.digest))throw new Error('Content recovery wait budget exhausted');
      waiters.add(resolve);this.contentWaiters.set(reference.digest,waiters);
      try {
        material=await Promise.race([Promise.resolve().then(()=>this.loadContent(reference)).then(value=>this.cache.put(value,reference)).then(entry=>entry.data),recovered]);
      }finally{waiters.delete(resolve);if(!waiters.size)this.contentWaiters.delete(reference.digest);}
    }
    return material;
  }
  async prepare(record) {
    if(!hasActor(record.plan,this.identity)||record.prepared||record.preparing||this.stopped||record.cancel)return;
    const now=this.now(),deadline=record.timeline.referenceAtBeat(record.plan.prepareByBeat);
    if(now!==null&&now>deadline){this.transition(record,'expired',{reason:'preparation-deadline'});return;}
    if(!this.dependenciesReady(record)){this.transition(record,'waiting',{reason:'exact-dependencies'});return;}
    const generation=this.generation;
    record.preparing=(async()=>{
      try {
        const content=await this.content(record.plan.content);
        record.actionId=`plan:${(await dataDigest({sessionId:record.plan.sessionId,epoch:record.plan.epoch,
          author:record.plan.author,authorIncarnation:record.plan.authorIncarnation,occurrenceId:record.plan.occurrenceId})).digest}`;
        if(generation!==this.generation||this.stopped||record.cancel)return;
        const started=this.monotonicNow(),prepared=this.prepareMaterial(content,record.plan,record.timeline);
        if(prepared?.then)throw new Error('Preparation recipes must be synchronous and isolated from live state');
        const elapsed=(this.monotonicNow()-started)*1000;
        if(elapsed>250)throw new Error('Branch preparation exceeded its CPU budget');
        const data=frozenJson(prepared,{bytes:LIMITS.preparedBytes,depth:24});
        if(this.preparedBytes+data.bytes>LIMITS.preparedBytes)throw new Error('Prepared branch memory budget exhausted');
        const finished=this.now();
        if(finished===null||finished>deadline)throw new Error('Content/preparation missed its deadline');
        this.preparedBytes+=data.bytes;record.preparedBytes=data.bytes;record.prepared=data.data;
        this.metrics.preparationMs.push(elapsed);if(this.metrics.preparationMs.length>256)this.metrics.preparationMs.shift();
        this.transition(record,'prepared',{preparationMs:elapsed,preparedBytes:data.bytes});
        this.tryAccept(record);
      } catch(error){record.retryAfter=(this.now()??Infinity)+1;this.transition(record,'waiting',{reason:error.message});}
      finally {record.preparing=null;}
    })();
    await record.preparing;
  }
  ingestStatus(input,origin) {
    const value=frozen(input),recipient=actor(value.recipient);checkOrigin(recipient,origin);
    const record=this.records.get(planKey(value.plan));if(!record)return {ok:false,reason:'unknown-plan'};
    if(!hasActor(record.plan,recipient))throw new Error('Readiness source is outside the execution membership');
    if(!['received','waiting','prepared','accepted','admitting','scheduled','executed','completed','expired','cancelling','cancelled','degraded'].includes(value.state))throw new Error('Unknown recipient fact');
    number(value.sequence,'recipient status sequence',{min:1,integer:true});
    const previous=record.statuses.get(actorKey(recipient));
    if(previous&&value.sequence<=previous.sequence) {
      if(value.sequence===previous.sequence&&value.state!==previous.state)throw new Error('Conflicting recipient status sequence');
      return {ok:true,duplicate:true};
    }
    record.statuses.set(actorKey(recipient),value);return {ok:true};
  }
  allPrepared(record) {
    return record.plan.scope.participants.every(participant=>sameActor(participant,this.identity)?Boolean(record.prepared)&&['prepared','accepted','admitting','scheduled','executed','completed'].includes(record.state):
      ['prepared','accepted','admitting','scheduled','executed','completed'].includes(record.statuses.get(actorKey(participant))?.state));
  }
  ingestFinal(input,origin,{selectionAuthorized=false}={}) {
    const value=frozen(input);
    if(value.version!==2||value.kind!=='plan-commit')throw new Error('Invalid final plan record');
    const ref=planReference(value.plan),record=this.records.get(planKey(ref));
    checkOrigin(actor(value.selector),origin);
    if(!record) {
      const now=this.now();
      number(value.startBeat,'pending final target',{max:this.pendingBeatLimit(now)});
      if(this.pendingFinals.size>=64)throw new Error('Pending final budget exhausted');
      const key=planKey(ref),items=this.pendingFinals.get(key)||[];
      if(items.length>=4)throw new Error('Too many unresolved final records');
      items.push({value,origin});this.pendingFinals.set(key,items);return {ok:false,reason:'plan-not-received'};
    }
    const plan=record.plan;
    checkOrigin(plan.selector,origin);
    if(plan.decision&&!selectionAuthorized)throw new Error('An alternative requires its overplan final selection');
    if(value.startBeat!==plan.startBeat||value.membershipId!==plan.scope.membershipId)throw new Error('Final target or membership mismatch');
    const key=finalKey(plan),serialized=frozenJson(value).canonical,previous=this.finals.get(key);
    if(previous) {
      if(previous.canonical!==serialized){this.metrics.conflicts++;throw new Error('Conflicting final for the same occurrence');}
      record.final=previous.value;this.tryAccept(record);this.metrics.duplicates++;return {ok:true,duplicate:true};
    }
    if(this.finals.size>=4096)throw new Error('Final retention budget exhausted');
    this.finals.set(key,{value,canonical:serialized,endReference:record.timeline.referenceAtBeat(plan.endBeat)});
    record.final=value;this.emit('final-received',{plan:ref,selector:origin});this.tryAccept(record);return {ok:true};
  }
  tryAccept(record) {
    if(!record.final||!hasActor(record.plan,this.identity)||['accepted','admitting','scheduled','executed','completed','cancelling','cancelled','expired','degraded'].includes(record.state))return;
    const now=this.now(),deadline=record.timeline.referenceAtBeat(record.plan.commitByBeat);
    if(now!==null&&now>deadline){this.metrics.misses++;this.transition(record,'expired',{reason:'final-acceptance-deadline'});return;}
    if(!record.prepared||!this.ready()||record.cancel)return;
    // One executor owns one clip bus in this first implementation. Overlaps
    // require a separate executor; cleanup must not silence unrelated plans.
    for(const other of this.records.values())if(record.plan.kind==='motif'&&other.plan.kind==='motif'&&other!==record&&hasActor(other.plan,this.identity)&&
      ['accepted','admitting','scheduled','executed'].includes(other.state)&&
      other.timeline.referenceAtBeat(other.plan.startBeat)<record.timeline.referenceAtBeat(record.plan.endBeat)&&
      record.timeline.referenceAtBeat(record.plan.startBeat)<other.timeline.referenceAtBeat(other.plan.endBeat)) {
      this.transition(record,'expired',{reason:'overlapping-execution'});return;
    }
    this.transition(record,'accepted',{executionBoundary:'recipient-plan-buffer'});
  }
  ingestCancel(input,origin) {
    const value=frozen(input),ref=planReference(value.plan),record=this.records.get(planKey(ref));
    if(!record)throw new Error('Cancellation requires its exact plan revision');
    if(value.version!==2||value.kind!=='plan-cancel'||(!sameActor(origin,planAuthor(record.plan))&&!sameActor(origin,record.plan.selector)))throw new Error('Unauthorized cancellation');
    const atBeat=number(value.atBeat,'cancellation beat',{min:0,max:record.plan.endBeat}),now=this.now();
    if(now===null||record.timeline.referenceAtBeat(atBeat)-now<LIMITS.acceptanceSeconds)throw new Error('Cancellation missed its acceptance boundary');
    const key=planKey(record.plan),json=frozenJson(value),old=this.cancellations.get(key);
    if(old&&old.canonical!==json.canonical)throw new Error('Conflicting cancellation');
    if(!old)this.cancellations.set(key,{...json,endReference:record.timeline.referenceAtBeat(record.plan.endBeat)});
    record.cancel=value;record.cancelOrigin=actor(origin);
    if(atBeat<=record.plan.startBeat&&!record.handle)this.transition(record,'cancelled',{reason:'future-cancellation'});
    return {ok:true};
  }
  async publish(plan) {
    const result=await this.ingestPlan(plan,this.identity);
    this.send('/broadcast/plan',[result.record.plan]);
    if(hasActor(result.record.plan,this.identity))this.send('/broadcast/plan/status',[{version:2,plan:planReference(result.record.plan),recipient:this.identity,
      state:result.record.state,sequence:result.record.statusSequence,atReference:this.now()}]);
    return result.record.plan;
  }
  commit(ref) {
    const record=this.records.get(planKey(ref));if(!record)throw new Error('Unknown plan');
    if(!this.allPrepared(record))throw new Error('Not every named executor has prepared the plan');
    const value=frozen({version:2,kind:'plan-commit',plan:planReference(record.plan),selector:this.identity,
      startBeat:record.plan.startBeat,membershipId:record.plan.scope.membershipId});
    this.ingestFinal(value,this.identity);this.send('/broadcast/plan/commit',[value]);return value;
  }
  advance() {
    if(this.stopped)return;
    this.recovery.advance();
    const now=this.now();if(now===null)return;
    for(const record of this.records.values()) {
      const start=record.timeline.referenceAtBeat(record.plan.startBeat),end=record.timeline.referenceAtBeat(record.plan.endBeat);
      if(record.cancel&&record.handle&&!record.cleanupStarted&&record.timeline.referenceAtBeat(record.cancel.atBeat)-now<=LIMITS.horizonSeconds) {
        record.cleanupStarted=true;const generation=this.generation;
        this.transition(record,'cancelling',{executionBoundary:'renderer-request'});
        Promise.resolve().then(()=>this.cleanup(record.handle,{atReference:record.timeline.referenceAtBeat(record.cancel.atBeat),plan:record.plan})).then(reply=>{
          if(generation!==this.generation)return;
          if(!reply?.ok)throw new Error('Renderer did not acknowledge cleanup');
          this.transition(record,'cancelled',{reason:'scheduled-release',executionBoundary:reply.executionBoundary});
        }).catch(error=>{if(generation===this.generation){record.handle.stop?.();this.transition(record,'degraded',{reason:error.message});}});
        continue;
      }
      if(!record.prepared&&!record.preparing&&(record.retryAfter??0)<=now&&!['expired','cancelling','cancelled','degraded'].includes(record.state))void this.prepare(record);
      this.tryAccept(record);
      if(record.state==='accepted') {
        if(start-now<LIMITS.submissionSeconds||start<this.rejoinAt){this.metrics.misses++;this.transition(record,'expired',{reason:'missed-onset'});continue;}
        if(!this.ready()||start-now>LIMITS.horizonSeconds)continue;
        this.admit(record);
      }
      if(end<now&&!record.final&&!['cancelled','expired'].includes(record.state))this.transition(record,'expired',{reason:'missing-final-omit'});
    }
    this.prune(now);
  }
  admit(record) {
    if(record.handle||record.state!=='accepted')return;
    if(record.plan.kind==='intention'){this.transition(record,'completed',{executionBoundary:'intention-only'});return;}
    if(record.plan.kind==='rest'){this.transition(record,'completed',{executionBoundary:'explicit-rest'});return;}
    this.transition(record,'admitting',{executionBoundary:'renderer-request'});
    const generation=this.generation;
    try {
      if(!this.execute)throw new Error('No capable renderer is attached');
      const handle=this.execute(record.prepared,record.plan,{
        actionId:record.actionId,timeline:record.timeline,
        onExecuted:event=>{
          if(generation!==this.generation||record.state==='cancelled')return;
          if(event?.executionBoundary!=='wasm-rendered-frame')return;
          this.transition(record,'executed',{executionBoundary:event.executionBoundary,actionId:event.actionId,
            renderedContextSeconds:event.renderedContextSeconds});
        },
        onCompleted:()=>{if(generation===this.generation&&record.state==='executed')this.transition(record,'completed',{executionBoundary:'renderer-completion'});},
        onFailure:reason=>{if(generation===this.generation)this.transition(record,'degraded',{reason:String(reason)});},
      });
      if(!handle||!handle.admission?.then)throw new Error('Renderer must return a real admission acknowledgement');
      record.handle=handle;
      handle.admission.then(reply=>{
        if(generation!==this.generation)return;
        if(!reply?.ok||reply.executionBoundary!=='wasm-queue')throw new Error('Renderer did not acknowledge audio queue admission');
        this.metrics.admissions++;
        if(record.state==='admitting')this.transition(record,'scheduled',{executionBoundary:reply.executionBoundary});
      }).catch(error=>{if(generation!==this.generation)return;handle.stop?.();this.transition(record,'degraded',{reason:error.message});});
    } catch(error){this.transition(record,'degraded',{reason:error.message});}
  }
  resetRenderer(reason='renderer-reset') {
    this.generation++;
    const now=this.now();this.rejoinAt=now===null?Infinity:this.timeline.referenceAtBeat(this.timeline.futureBoundary(Math.max(now,this.timeline.anchor?.reference??-Infinity),2));
    for(const record of this.records.values())if((record.handle||record.prepared)&&!['completed','expired','cancelled'].includes(record.state)) {
      record.handle?.stop?.();this.transition(record,'degraded',{reason});
    }
    this.emit('rejoin-required',{reason,rejoinAt:Number.isFinite(this.rejoinAt)?this.rejoinAt:null});
  }
  recoverySummary(){return {plans:[...this.records.keys()],overplans:[],content:[...this.cache.entries.keys()]};}
  recoveryRecords(known){return ordinaryRecoveryRecords(this,known);}
  requestRecovery(peer){return this.recovery.request(peer);}
  async recoverContent(value) {
    const record=[...this.records.values()].find(record=>record.plan.content.digest===value.digest&&record.plan.content.bytes===value.bytes);
    if(!record)throw new Error('Recovered content requires a known immutable reference');
    const entry=await this.cache.put(value.data,record.plan.content);
    for(const resolve of this.contentWaiters.get(entry.digest)||[])resolve(entry.data);
    return {ok:true};
  }
  pinnedTimelines(){return [...this.records.values()].map(record=>record.timeline);}
  checkpoint() {
    // This is a participant-held audit/recovery export, not an authenticated
    // network message and not permission to resurrect an old renderer epoch.
    const pinned=new Map(this.pinnedTimelines().map(map=>[JSON.stringify([map.sessionId,map.epoch,map.id,map.revision]),{...map}]));
    return frozenJson({version:1,identity:this.identity,timeline:{...this.timeline},tempoMaps:this.timelines.snapshot(),
      pinnedTempoMaps:[...pinned.values()],atReference:this.now(),
      generation:this.generation,rejoinAt:Number.isFinite(this.rejoinAt)?this.rejoinAt:null,
      plans:[...this.records.values()].map(r=>({plan:r.plan,state:r.state,reason:r.reason||null,
        actionId:r.actionId||null,final:r.final,cancel:r.cancel,cancelOrigin:r.cancelOrigin||null,recipients:[...r.statuses.values()]})),
      tombstones:[...this.tombstones],finals:[...this.finals],cancellations:[...this.cancellations],
      content:[...this.cache.entries.values()].map(({digest,bytes,data})=>({digest,bytes,data})),
      facts:this.facts},{bytes:32*1024*1024,items:2*1024*1024,depth:24}).data;
  }
  prune(now) {
    const removedContent=new Set();
    const needed=new Set([...this.records.values()].filter(r=>r.timeline.referenceAtBeat(r.plan.endBeat)>=now)
      .flatMap(r=>r.plan.dependencies.map(d=>planKey(d.plan))));
    for(const [key,record]of this.records)if(record.timeline.referenceAtBeat(record.plan.endBeat)+16<now&&!needed.has(key)&&!record.preparing) {
      if(this.tombstones.size>=4096)continue;
      this.records.delete(key);this.recordBytes-=record.bytes;this.preparedBytes-=record.preparedBytes;
      if(record.plan.content.digest)removedContent.add(record.plan.content.digest);
      this.tombstones.set(key,now+LIMITS.retentionSeconds);
    }
    for(const [key,expiry]of this.tombstones)if(expiry<now)this.tombstones.delete(key);
    for(const map of [this.finals,this.cancellations])for(const [key,entry]of map)if(entry.endReference+LIMITS.retentionSeconds<now)map.delete(key);
    for(const [key,items]of this.pendingFinals)if(items.every(item=>this.pendingStartReference(item.value)<now))this.pendingFinals.delete(key);
    const retainedContent=new Set([...this.records.values()].map(r=>r.plan.content.digest));
    for(const digest of removedContent)if(!retainedContent.has(digest))this.cache.remove(digest);
  }
  pendingDeadlines() {
    if(this.stopped)return [];
    const deadlines=[];
    for(const record of this.records.values()) {
      if(['completed','expired','cancelled','degraded'].includes(record.state))continue;
      const plan=record.plan,timeline=record.timeline,local=hasActor(plan,this.identity),selector=sameActor(plan.selector,this.identity);
      let phase,atBeat;
      if(record.cancel&&record.handle&&!record.cleanupStarted){
        phase='cleanup-submission';atBeat=timeline.beatAtReference(timeline.referenceAtBeat(record.cancel.atBeat)-LIMITS.submissionSeconds);
      }else if((local&&!record.prepared)||(selector&&!record.final&&!this.allPrepared(record))){
        phase='preparation';atBeat=plan.prepareByBeat;
      }else if((local&&!['accepted','admitting','scheduled','executed','cancelling'].includes(record.state))||(selector&&!record.final)){
        phase='final-acceptance';atBeat=plan.commitByBeat;
      }else if(local&&record.state==='accepted'){
        phase='execution-admission';atBeat=timeline.beatAtReference(timeline.referenceAtBeat(plan.startBeat)-LIMITS.submissionSeconds);
      }
      if(phase)deadlines.push({kind:'plan',reference:planReference(plan),phase,atBeat,atReference:timeline.referenceAtBeat(atBeat)});
    }
    return deadlines;
  }
  nextDeadline() {
    const deadline=this.pendingDeadlines().sort((a,b)=>a.atReference-b.atReference)[0];
    if(!deadline)return null;
    const now=this.now();
    return {...deadline,secondsRemaining:now===null?null:deadline.atReference-now,overdue:now===null?null:deadline.atReference<now};
  }
  status() {return {identity:this.identity,records:this.records.size,recordBytes:this.recordBytes,preparedBytes:this.preparedBytes,
    contentBytes:this.cache.bytes,ready:this.ready(),generation:this.generation,recovery:this.recovery.status(),metrics:{...this.metrics},
    nextDeadline:this.nextDeadline(),
    plans:[...this.records.values()].map(r=>({plan:planReference(r.plan),state:r.state,reason:r.reason||null,
      startBeat:r.plan.startBeat,prepared:Boolean(r.prepared),final:Boolean(r.final),recipients:[...r.statuses.values()]}))};}
  stop(){this.stopped=true;this.recovery.close();this.resetRenderer('runtime-stopped');}
}
