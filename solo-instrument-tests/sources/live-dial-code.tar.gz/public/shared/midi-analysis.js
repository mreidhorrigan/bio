const mean=values=>values.length?values.reduce((sum,value)=>sum+value,0)/values.length:0;
const deviation=values=>{const average=mean(values);return values.length?Math.sqrt(mean(values.map(value=>(value-average)**2))):0};
const clip=value=>Math.max(0,Math.min(1,Number(value)||0));

export class MidiFeatureAnalyzer {
  constructor({windowMs=2000,pitchRange=[36,96],bendRange=48,now=()=>performance.now()}={}){
    this.windowMs=windowMs;this.pitchRange=pitchRange;this.bendRange=bendRange;this.now=now;this.bends=Array(16).fill(8192);this.active=new Map;this.notes=[];this.onsets=[];
  }
  receive(bytes,time=this.now()){
    const [status=0,data1=0,data2=0]=bytes,kind=status&0xf0,channel=status&15;
    if(kind===0xe0){this.bends[channel]=(data2<<7)|data1;return}
    const key=`${channel}:${data1}`;
    if(kind===0x90&&data2>0){
      const pitch=data1+(this.bends[channel]-8192)/8192*this.bendRange,event={pitch,velocity:data2,onset:time,channel,note:data1};
      this.active.set(key,event);this.onsets.push(time);return;
    }
    if(kind===0x80||(kind===0x90&&data2===0)){const event=this.active.get(key);if(event){this.active.delete(key);this.notes.push({...event,duration:Math.max(0,time-event.onset)})}}
  }
  snapshot(time=this.now(),tempo=120){
    const cutoff=time-this.windowMs;this.notes=this.notes.filter(note=>note.onset>=cutoff);this.onsets=this.onsets.filter(onset=>onset>=cutoff);
    const sounding=[...this.notes,...[...this.active.values()].filter(note=>note.onset>=cutoff).map(note=>({...note,duration:time-note.onset}))],pitches=sounding.map(note=>note.pitch),velocities=sounding.map(note=>note.velocity),durations=sounding.map(note=>note.duration),onsetIntervals=this.onsets.slice(1).map((value,index)=>value-this.onsets[index]),intervals=pitches.slice(1).map((value,index)=>Math.abs(value-pitches[index])),beatMs=60000/Math.max(1,tempo),range=Math.max(1,this.pitchRange[1]-this.pitchRange[0]);
    const raw=[mean(pitches),deviation(pitches),mean(intervals),mean(velocities),deviation(velocities),mean(durations),deviation(durations),mean(onsetIntervals),deviation(onsetIntervals),this.active.size];
    const normalized=[clip((raw[0]-this.pitchRange[0])/range),clip(raw[1]/range),clip(raw[2]/range),clip(raw[3]/127),clip(raw[4]/127),clip(raw[5]/beatMs),clip(raw[6]/beatMs),clip(raw[7]/beatMs),clip(raw[8]/beatMs),clip(raw[9]/10)];
    const complexity=clip(mean([normalized[1],normalized[2],normalized[4],normalized[6],normalized[8]])),consistency=clip(1-mean([normalized[1],normalized[4],normalized[6],normalized[8]]));
    return{raw,normalized,complexity,consistency,eventCount:sounding.length};
  }
  clear(){this.active.clear();this.notes.length=0;this.onsets.length=0;this.bends.fill(8192)}
}
