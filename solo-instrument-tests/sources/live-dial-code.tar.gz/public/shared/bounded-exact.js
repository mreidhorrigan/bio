// RUB-002's arithmetic contract (research/rubato-replanning/arithmetic.py), for its kernels in production: exact
// rationals in BigInts, 256-bit inputs, 8192-bit derived values, and charged work. Past a limit it refuses (Refused, with
// its kind) and never rounds, and a refusal is not a finding about the music. Floats are never taken silently: a
// number that is not an integer is refused, and a float the caller means is converted where it is said (exactOfNumber).
// Values are frozen {n, d}, reduced, d > 0. A model's identity is the SHA-256 of the candidates' canonical JSON. Used by
// density-envelope.js (P180), rubato-game.js (P177-P179) and rubato-allocation.js (P172-P176).

export const EXACT_LIMITS = Object.freeze({inputBits: 256, workBits: 8192, work: 100000, maxWork: 500000});

// Kinds: 'invalid-input', 'arithmetic-budget' (a value past its bits), 'work-budget' (the charged work spent), and the
// solvers' own ('row-budget', 'stale-context', 'out-of-model').
export class Refused extends Error {
  constructor(message, {kind = 'invalid-input'} = {}) { super(message); this.name = 'Refused'; this.kind = kind; }
}
export class Budget {
  constructor(limit = EXACT_LIMITS.work) {
    if (!Number.isInteger(limit) || limit < 0 || limit > EXACT_LIMITS.maxWork) throw new Refused(`Work limit must be an integer in 0..${EXACT_LIMITS.maxWork}`);
    this.limit = limit; this.used = 0;
  }
  charge(amount = 1) {
    if (!Number.isInteger(amount) || amount < 0) throw new Error('Invalid internal work charge');
    if (amount > this.limit - this.used) throw new Refused('Exact work budget exhausted', {kind: 'work-budget'});
    this.used += amount;
  }
}

const magnitude = n => n < 0n ? -n : n;
export const bitsOf = n => n === 0n ? 0 : magnitude(n).toString(2).length;
const gcd = (a, b) => { a = magnitude(a); b = magnitude(b); while (b) [a, b] = [b, a % b]; return a; };
// A reduced fraction, unchecked: for values already within their bits.
export function fraction(n, d = 1n) {
  if (d < 0n) { n = -n; d = -d; }
  const g = gcd(n, d) || 1n;
  return Object.freeze({n: n / g, d: d / g});
}
export const ZERO = fraction(0n), ONE = fraction(1n), TWO = fraction(2n);
const capped = (x, bits, message) => { if (Math.max(bitsOf(x.n), bitsOf(x.d)) > bits) throw new Refused(message, {kind: 'arithmetic-budget'}); return x; };
// A derived value, within the work bits.
export const bounded = x => capped(x, EXACT_LIMITS.workBits, `Rational work value exceeds ${EXACT_LIMITS.workBits} bits`);
export const add = (a, b) => bounded(fraction(a.n * b.d + b.n * a.d, a.d * b.d));
export const sub = (a, b) => bounded(fraction(a.n * b.d - b.n * a.d, a.d * b.d));
export const mul = (a, b) => bounded(fraction(a.n * b.n, a.d * b.d));
export const div = (a, b) => { if (b.n === 0n) throw new Refused('Zero divisor'); return bounded(fraction(a.n * b.d, a.d * b.n)); };
export const neg = a => fraction(-a.n, a.d);
export const abs = a => a.n < 0n ? neg(a) : a;
export const compare = (a, b) => { const x = a.n * b.d - b.n * a.d; return x < 0n ? -1 : x > 0n ? 1 : 0; };
export const equal = (a, b) => a.n === b.n && a.d === b.d;
// Python's max(a, b) and min(a, b): the first unless the second is strictly beyond it.
export const max = (a, b) => compare(b, a) > 0 ? b : a;
export const min = (a, b) => compare(b, a) < 0 ? b : a;
export const sum = values => values.reduce((total, value) => add(total, value), ZERO);
export function dot(a, b) {
  if (a.length !== b.length) throw new Refused('Mismatched dot-product dimensions');
  return sum(a.map((value, i) => mul(value, b[i])));
}
// Exact text, as Python writes a Fraction: "n" or "n/d".
export const exactText = x => x.d === 1n ? `${x.n}` : `${x.n}/${x.d}`;
// A float near an exact value, for the places seconds are evaluated (both scaled together, so a ratio of long integers
// keeps its precision).
export function floatOfExact({n, d}) {
  const shift = BigInt(Math.max(0, Math.max(bitsOf(n), bitsOf(d)) - 1000));
  return Number(n >> shift) / Number(d >> shift);
}

const integer = value => typeof value === 'bigint' ? value : Number.isSafeInteger(value) ? BigInt(value) : null;
// An exact rational from its spelling: a safe integer or a BigInt, "n/d", an exact decimal ("0.25", "1e-3"), [n, d], or
// {n, d}; within `bits` (the inputs' 256, or the derived values' 8192 when a result is read back).
export function exactOf(value, {bits = EXACT_LIMITS.inputBits} = {}) {
  let x;
  if (typeof value === 'bigint' || typeof value === 'number') {
    const n = integer(value);
    if (n === null) throw new Refused(Number.isFinite(value) && !Number.isInteger(value)
      ? `${value} is not exact: a float is converted where it is said (exactOfNumber)` : `${value} is not an exact integer`);
    x = fraction(n);
  } else if (typeof value === 'string') {
    if (!(value.length >= 1 && value.length <= (bits === EXACT_LIMITS.inputBits ? 160 : 6000))) throw new Refused('Invalid exact rational spelling');
    const quotient = value.match(/^([+-]?[0-9]+)\/([0-9]+)$/);
    const decimal = value.match(/^([+-]?)(?:([0-9]+)(?:\.([0-9]*))?|\.([0-9]+))(?:[eE]([+-]?[0-9]{1,3}))?$/);
    if (quotient) {
      const d = BigInt(quotient[2]);
      if (d === 0n) throw new Refused('Invalid rational');
      x = fraction(BigInt(quotient[1]), d);
    } else if (decimal) {
      const [, sign, whole = '', part = decimal[4] ?? '', , exponent = '0'] = decimal;
      if (Math.abs(Number(exponent)) > 256) throw new Refused('Exponent conversion cap', {kind: 'arithmetic-budget'});
      const shift = Number(exponent) - part.length, digits = BigInt((whole + part) || '0') * (sign === '-' ? -1n : 1n);
      x = shift >= 0 ? fraction(digits * 10n ** BigInt(shift)) : fraction(digits, 10n ** BigInt(-shift));
    } else throw new Refused('Invalid exact rational spelling');
  } else if (Array.isArray(value) && value.length === 2 && integer(value[0]) !== null && integer(value[1]) !== null) {
    if (integer(value[1]) === 0n) throw new Refused('Invalid rational');
    x = fraction(integer(value[0]), integer(value[1]));
  } else if (value && typeof value === 'object' && !Array.isArray(value) && integer(value.n) !== null && integer(value.d) !== null) {
    if (integer(value.d) === 0n) throw new Refused('Invalid rational');
    x = fraction(integer(value.n), integer(value.d));
  } else throw new Refused('Use a bounded integer, a BigInt, [n, d], or exact rational or decimal text');
  return capped(x, bits, 'Rational input bit cap');
}
// A float as the decimal JavaScript writes for it (the shortest that reads back as the same number): a density or a
// time the map holds as a float, taken exactly at its word.
export function exactOfNumber(value) {
  if (!Number.isFinite(value)) throw new Refused(`${value} is not a finite number`);
  return exactOf(String(value));
}

const isExactValue = value => value !== null && typeof value === 'object' && typeof value.n === 'bigint' && typeof value.d === 'bigint' && value.d > 0n;
// ---- Identities: SHA-256 of Python's json.dumps(..., sort_keys=True, separators=(',', ':')), as the candidates hash ----
// (A record or an array is written by the core where one is installed: the same text.)
export function pythonJson(value) {
  if (core && value !== null && typeof value === 'object') { const text = core.pythonJson(value); if (text !== null) return text; }
  return json(value);
}
function json(value) {
  if (value === null || value === undefined) return 'null';
  if (typeof value === 'boolean') return value ? 'true' : 'false';
  if (typeof value === 'number') return String(value);
  if (typeof value === 'string') return JSON.stringify(value).replace(/[\u0080-￿]/g, c => `\\u${c.charCodeAt(0).toString(16).padStart(4, '0')}`);
  if (isExactValue(value)) return json(exactText(value));
  if (Array.isArray(value)) return `[${value.map(json).join(',')}]`;
  return `{${Object.keys(value).sort().map(key => `${json(key)}:${json(value[key])}`).join(',')}}`;
}
const K = new Uint32Array([0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01,
  0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa,
  0x5cb0a9dc, 0x76f988da, 0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138,
  0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85, 0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624,
  0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3, 0x748f82ee, 0x78a5636f,
  0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2]);
// The hash, and pythonJson's text of a record or an array, run faster where a core is installed (shared/musical-core.js:
// their Rust port, the same hex and the same text; research/RUST_PORT_STATE.md). -> the core it replaced.
let core = null;
export function useExactCore(given = null) { const previous = core; core = given; return previous; }
// A synchronous SHA-256 of a string's UTF-8 bytes, as hex (a browser's crypto.subtle is asynchronous).
export function sha256(text) {
  if (core) return core.sha256(text);
  const bytes = new TextEncoder().encode(text), length = bytes.length, blocks = Math.ceil((length + 9) / 64), data = new Uint8Array(blocks * 64);
  data.set(bytes); data[length] = 0x80;
  const view = new DataView(data.buffer), bits = length * 8;
  view.setUint32(data.length - 8, Math.floor(bits / 2 ** 32)); view.setUint32(data.length - 4, bits >>> 0);
  const h = new Uint32Array([0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19]), w = new Uint32Array(64);
  const rotate = (x, n) => (x >>> n) | (x << (32 - n));
  for (let block = 0; block < blocks; block++) {
    for (let t = 0; t < 16; t++) w[t] = view.getUint32(block * 64 + t * 4);
    for (let t = 16; t < 64; t++) {
      const s0 = rotate(w[t - 15], 7) ^ rotate(w[t - 15], 18) ^ (w[t - 15] >>> 3), s1 = rotate(w[t - 2], 17) ^ rotate(w[t - 2], 19) ^ (w[t - 2] >>> 10);
      w[t] = (w[t - 16] + s0 + w[t - 7] + s1) >>> 0;
    }
    let [a, b, c, d, e, f, g, k] = h;
    for (let t = 0; t < 64; t++) {
      const t1 = (k + (rotate(e, 6) ^ rotate(e, 11) ^ rotate(e, 25)) + ((e & f) ^ (~e & g)) + K[t] + w[t]) >>> 0;
      const t2 = ((rotate(a, 2) ^ rotate(a, 13) ^ rotate(a, 22)) + ((a & b) ^ (a & c) ^ (b & c))) >>> 0;
      k = g; g = f; f = e; e = (d + t1) >>> 0; d = c; c = b; b = a; a = (t1 + t2) >>> 0;
    }
    h[0] += a; h[1] += b; h[2] += c; h[3] += d; h[4] += e; h[5] += f; h[6] += g; h[7] += k;
  }
  return [...h].map(value => value.toString(16).padStart(8, '0')).join('');
}
