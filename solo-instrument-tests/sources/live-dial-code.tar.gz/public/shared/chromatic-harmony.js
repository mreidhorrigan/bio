// Chords as a voice-leading bot hears them, and the relations of chromatic harmony between them.
//
// - identifyChord: a pool of pitch classes as a chord: its root, quality, and the roles its tones play (third, fifth,
//   seventh), the rest as extensions. The root a listener or chord bot names wins where it is given.
// - Neo-Riemannian transformations of consonant triads (Cohn 1998, 2012): P (parallel: C major to C minor), L
//   (leading-tone exchange: C major to E minor), R (relative: C major to A minor), each moving one voice by a step and
//   holding two, and their compounds: the chromatic mediants (C major to E major, LP; to A flat major, PL), the slide
//   (C major to C sharp minor, LPR), the hexatonic pole (C major to A flat minor, LPL). High-Romantic harmony moves by
//   these as much as by fifths: chords a third apart, held together by common tones and semitone motion.
// - How functional a succession is: a root falling a fifth is the tonal cadence's motion; chords of one diatonic
//   collection a step or third apart are tonal too; chromatic mediants, slides and poles are Romantic; a chord shape
//   moved in parallel outside any collection (planing) is impressionist. A running measure lets a Romantic bot blend
//   toward the impressionist where the harmony it hears stops functioning.
// - Planing: a voicing moved in parallel, exactly (real planing) or within a collection (diatonic planing), as Debussy
//   moves chords (Persichetti 1961).
// - Non-chord tones between voicings, as Romantic dissonance treats them: suspensions held over a change and resolved
//   down by step, appoggiaturas on the beat resolved by step, passing tones filling a third.
const modulo=(value,period)=>((value%period)+period)%period;
const pcOf=(value,period=12)=>Math.round(modulo(value,period)*1e6)/1e6;
const near=(a,b,period=12,tolerance=.2)=>{const d=modulo(a-b,period);return Math.min(d,period-d)<=tolerance};

// Chord qualities as intervals above the root, and their roles (third, fifth, seventh). A prior favours the common.
export const CHORD_QUALITIES=Object.freeze({
  major:Object.freeze({intervals:[0,4,7],prior:1}),
  minor:Object.freeze({intervals:[0,3,7],prior:1}),
  diminished:Object.freeze({intervals:[0,3,6],prior:.6}),
  augmented:Object.freeze({intervals:[0,4,8],prior:.4}),
  'dominant-seventh':Object.freeze({intervals:[0,4,7,10],prior:.9}),
  'major-seventh':Object.freeze({intervals:[0,4,7,11],prior:.8}),
  'minor-seventh':Object.freeze({intervals:[0,3,7,10],prior:.85}),
  'half-diminished':Object.freeze({intervals:[0,3,6,10],prior:.6}),
  'diminished-seventh':Object.freeze({intervals:[0,3,6,9],prior:.5}),
  'minor-major-seventh':Object.freeze({intervals:[0,3,7,11],prior:.3}),
  'major-sixth':Object.freeze({intervals:[0,4,7,9],prior:.5}),
  'minor-sixth':Object.freeze({intervals:[0,3,7,9],prior:.4}),
  sus4:Object.freeze({intervals:[0,5,7],prior:.5}),
  sus2:Object.freeze({intervals:[0,2,7],prior:.35}),
  'seventh-sus4':Object.freeze({intervals:[0,5,7,10],prior:.45}),
  'dominant-seventh-flat-five':Object.freeze({intervals:[0,4,6,10],prior:.25}),
  'augmented-seventh':Object.freeze({intervals:[0,4,8,10],prior:.25}),
});
const roleOf=interval=>[3,4].includes(interval)?'third':[6,7,8].includes(interval)?'fifth':[9,10,11].includes(interval)?'seventh':[2,5].includes(interval)?'suspension':null;
// What a tone beyond a quality costs, by its interval above the root: a ninth, thirteenth or eleventh is an extension
// chords take; an altered ninth or thirteenth less often; anything else (a second third, a second seventh) rarely.
const EXTENSION_COST=Object.freeze({2:.5,9:.55,5:.6,6:.7,1:.9,3:.9,8:.95});

// A chord from pitch classes: {root, quality, pitchClasses, third, fifth, seventh, extensions, bass}. `root` (a
// named root: a performer chord's label, a chord bot's) and `bass` (the lowest tone sounding) weigh the choice. A
// quality's tones missing count against it, tones beyond it (extensions) less. Returns null for an empty pool.
export function identifyChord(pitchClasses,{root=null,bass=null,period=12}={}){
  const pcs=[...new Set((pitchClasses??[]).filter(Number.isFinite).map(pc=>pcOf(pc,period)))];
  if(!pcs.length)return null;
  let best=null;
  for(const candidate of pcs)for(const [quality,{intervals,prior}] of Object.entries(CHORD_QUALITIES)){
    const tones=intervals.map(step=>pcOf(candidate+step,period)),held=tones.filter(tone=>pcs.some(pc=>near(pc,tone,period))).length;
    const extras=pcs.filter(pc=>!tones.some(tone=>near(pc,tone,period))),missing=intervals.length-held;
    const extraCost=extras.reduce((sum,pc)=>sum+(EXTENSION_COST[Math.round(pcOf(pc-candidate,period))]??1.3),0);
    // The fifth may be left out of a chord with a seventh, as voicings leave it.
    const fifthMissing=intervals.length>3&&!pcs.some(pc=>near(pc,candidate+intervals[2],period));
    const score=held*2-(missing-(fifthMissing?1:0))*2.2-(fifthMissing?.6:0)-extraCost+Math.log(prior)*.8
      +(root!==null&&near(candidate,root,period)?2.5:0)+(bass!==null&&near(candidate,bass,period)?.6:0);
    if(!best||score>best.score+1e-9)best={score,root:candidate,quality,tones,intervals};
  }
  const find=role=>{const i=best.intervals.findIndex(step=>roleOf(step)===role);if(i<0)return null;const tone=best.tones[i];return pcs.some(pc=>near(pc,tone,period))?tone:null};
  return {root:best.root,quality:best.quality,pitchClasses:pcs,third:find('third'),fifth:find('fifth'),seventh:find('seventh'),
    extensions:pcs.filter(pc=>!best.tones.some(tone=>near(pc,tone,period))).map(pc=>pcOf(pc-best.root,period)).sort((a,b)=>a-b),
    bass:bass===null?null:pcOf(bass,period),score:+best.score.toFixed(3)};
}
// A performer chord's label (harmony-model.js vocabulary: 'C-major', 'Fs-minor', 'Bb-major') as its root and quality.
const NAMES={C:0,Cs:1,Db:1,D:2,Ds:3,Eb:3,E:4,F:5,Fs:6,Gb:6,G:7,Gs:8,Ab:8,A:9,As:10,Bb:10,B:11};
export function parseChordLabel(label){
  const m=/^([A-G](?:s|b)?)-(major|minor)$/.exec(String(label??''));
  return m&&NAMES[m[1]]!==undefined?{root:NAMES[m[1]],quality:m[2]}:null;
}

// Consonant triads: {root, quality: 'major'|'minor'}.
export const triadPitchClasses=({root,quality})=>(quality==='major'?[0,4,7]:[0,3,7]).map(step=>(root+step)%12);
export function neoRiemannian(triad,op){
  const {root,quality}=triad,major=quality==='major';
  if(!['major','minor'].includes(quality))throw new TypeError('Neo-Riemannian transformations act on major and minor triads');
  if(op==='P')return {root,quality:major?'minor':'major'};
  if(op==='L')return major?{root:(root+4)%12,quality:'minor'}:{root:(root+8)%12,quality:'major'};
  if(op==='R')return major?{root:(root+9)%12,quality:'minor'}:{root:(root+3)%12,quality:'major'};
  throw new TypeError(`A Neo-Riemannian transformation is P, L or R, not ${op}`);
}
// Compounds: N (Nebenverwandt, RLP: C major to F minor), S (slide, LPR: C major to C sharp minor), H (hexatonic pole,
// LPL: C major to A flat minor).
export const COMPOUND_TRANSFORMATIONS=Object.freeze({N:'RLP',S:'LPR',H:'LPL'});
export function transformTriad(triad,ops){
  let current=triad;
  for(const op of String(ops))current=COMPOUND_TRANSFORMATIONS[op]?transformTriad(current,COMPOUND_TRANSFORMATIONS[op]):neoRiemannian(current,op);
  return current;
}
// The shortest string of P, L and R taking one triad to another (up to `depth` steps), '' for the same triad, or null.
const triadPathCache=new Map();
export function triadRelation(from,to,{depth=4}={}){
  const canonical=t=>Number.isInteger(t?.root)&&t.root>=0&&t.root<12&&['major','minor'].includes(t.quality);
  if(canonical(from)&&canonical(to)&&Number.isInteger(depth)&&depth>=0){
    const key=t=>`${t.root}:${t.quality}`,id=key(from);
    if(!triadPathCache.has(id)){
      const paths=new Map([[id,'']]),queue=[from];
      for(let at=0;at<queue.length;at++){const triad=queue[at],before=paths.get(key(triad));for(const op of 'PLR'){
        const next=neoRiemannian(triad,op),name=key(next);if(!paths.has(name)){paths.set(name,before+op);queue.push(next);}}}
      triadPathCache.set(id,paths);
    }
    const path=triadPathCache.get(id).get(key(to));return path!==undefined&&path.length<=depth?path:null;
  }
  return triadRelationDirect(from,to,{depth});
}
function triadRelationDirect(from,to,{depth=4}={}){
  const key=t=>`${t.root}:${t.quality}`,goal=key(to);
  let frontier=[{triad:from,ops:''}];const seen=new Set([key(from)]);
  if(key(from)===goal)return '';
  for(let level=0;level<depth;level++){
    const next=[];
    for(const {triad,ops} of frontier)for(const op of 'PLR'){const t=neoRiemannian(triad,op),k=key(t);if(k===goal)return ops+op;if(!seen.has(k)){seen.add(k);next.push({triad:t,ops:ops+op});}}
    frontier=next;
  }
  return null;
}
// Chromatic mediants: two major (or two minor) triads whose roots are a third apart (Cohn 2012; Kopp 2002's
// "chromatic mediant" relation), sharing one tone or none.
export function chromaticMediant(a,b){
  return a.quality===b.quality&&['major','minor'].includes(a.quality)&&[3,4,8,9].includes(modulo(b.root-a.root,12));
}

// The smallest total motion between two pitch-class sets of one size, each voice to one of the other's (Tymoczko 2011):
// over every pairing in rotation of the sorted sets, and every transposition by octaves of their difference.
export function pcVoiceLeading(a,b,{period=12}={}){
  const x=[...a].map(pc=>pcOf(pc,period)).sort((p,q)=>p-q),y=[...b].map(pc=>pcOf(pc,period)).sort((p,q)=>p-q);
  if(x.length!==y.length||!x.length)return null;
  let best=null;
  for(let r=0;r<y.length;r++){
    const moves=x.map((pc,i)=>{let d=modulo(y[(i+r)%y.length]-pc,period);if(d>period/2)d-=period;return d});
    // All voices may shift by an octave's worth together only as a whole; the pairing in rotation is what varies.
    const total=moves.reduce((sum,d)=>sum+Math.abs(d),0);
    if(!best||total<best.total-1e-9)best={total,moves,pairs:x.map((pc,i)=>[pc,y[(i+r)%y.length]])};
  }
  return best;
}

// Whether two sets of pitch classes lie together in one diatonic collection (any of the twelve).
export function sharedDiatonic(a,b){
  const both=[...new Set([...a,...b].map(pc=>pcOf(pc,12)))];
  for(let t=0;t<12;t++){const collection=[0,2,4,5,7,9,11].map(step=>(t+step)%12);if(both.every(pc=>collection.some(c=>near(pc,c))))return t;}
  return null;
}

// How a succession sounds, as a kind and a functional weight (1: a root falling a fifth; 0: planing outside a key).
export function successionKind(from,to){
  if(!from||!to)return null;
  const step=modulo(Math.round(to.root-from.root),12),sameQuality=from.quality===to.quality,shared=sharedDiatonic(from.pitchClasses,to.pitchClasses)!==null;
  if(step===0)return from.quality===to.quality?{kind:'same',weight:null}:{kind:'mixture',weight:.45};
  if(step===5)return {kind:'falling-fifth',weight:1};
  if(step===7)return {kind:'rising-fifth',weight:.75};
  if(step===6)return from.seventh!==null&&from.quality==='dominant-seventh'?{kind:'tritone-substitute',weight:.5}:{kind:'tritone',weight:.1};
  if([2,10].includes(step))return shared?{kind:'diatonic-step',weight:.6}:sameQuality?{kind:'planing',weight:0}:{kind:'chromatic-step',weight:.2};
  if([1,11].includes(step))return step===11&&from.quality==='major'&&to.quality!=='diminished'&&!shared?{kind:'neapolitan',weight:.35}:sameQuality?{kind:'planing',weight:0}:{kind:'chromatic-step',weight:.15};
  // Thirds.
  if(shared)return {kind:'diatonic-third',weight:.5};
  if(chromaticMediant(from,to))return {kind:'chromatic-mediant',weight:.2};
  return {kind:'chromatic-third',weight:.1};
}

// A running measure of how functional the harmony heard is: the mean weight of its recent successions, the latest
// counting most (each earlier one `memory` as much). Starts at `prior`: a harmony heard as tonal until it is not.
// A pair of chords cannot show planing (two major triads a step apart are IV and V of a key); a chain can: a chord
// shape moved again by the same step, as C major, D major, E major move, is planing, whatever each pair could be.
export function createFunctionality({memory=.75,prior=.7}={}){return {memory,value:prior,count:0,last:null,step:null,kinds:[]}}
export function hearSuccession(state,chord){
  if(!chord)return state;
  let kind=successionKind(state.last,chord);
  if(!kind||kind.weight===null)return {...state,last:chord};
  const step=modulo(Math.round(chord.root-state.last.root),12);
  if(state.step!==null&&step===state.step&&[1,2,10,11,3,4,8,9].includes(step)&&chord.quality===state.last.quality&&state.lastQuality===chord.quality)kind={kind:'planing',weight:0};
  const value=state.memory*state.value+(1-state.memory)*kind.weight;
  return {...state,value,count:state.count+1,last:chord,step,lastQuality:state.last.quality,kinds:[...state.kinds.slice(-15),kind.kind]};
}
// How far a Romantic bot moves toward the impressionist: none while the harmony is functional (at `functional` or
// above), wholly once it is not (at `nonFunctional` or below).
export function impressionistBlend(functionality,{functional=.55,nonFunctional=.2}={}){
  return Math.max(0,Math.min(1,(functional-functionality)/(functional-nonFunctional)));
}

// Real planing: the voicing's intervals kept exactly, moved so that its top voice (or bottom, `voice: 'bottom'`)
// arrives at `target`.
export function planeReal(voicing,target,{voice='top'}={}){
  const shift=target-(voice==='bottom'?voicing[0]:voicing.at(-1));
  return voicing.map(pitch=>pitch+shift);
}
// Diatonic planing: each voice moved `steps` scale steps within the collection (pitch classes); a voice off the
// collection first goes to its nearest member. The chord's qualities change as the collection gives them.
// Each pitch snapped to its nearest member of the collection, then moved `steps` along it. The nearest member is looked
// for in the neighbouring periods too, and the period it is found in is kept: within the pitch's own period alone,
// 71.9 over C major's triad snapped to 67 when 72 is nearer (the mathematical audit's I02). A tie keeps the pitch's own
// period, and the lower member within it, as before; where the nearest member was in the same period nothing changes.
export function planeDiatonic(voicing,steps,collection,{period=12}={}){
  const scale=[...new Set(collection.map(pc=>pcOf(pc,period)))].sort((a,b)=>a-b),n=scale.length;
  return voicing.map(pitch=>{
    const octave=Math.floor(pitch/period);
    let index=0,carry=0,bestDistance=Infinity;
    for(const shift of [0,-1,1])scale.forEach((member,i)=>{const d=Math.abs((octave+shift)*period+member-pitch);if(d<bestDistance){bestDistance=d;index=i;carry=shift}});
    const target=index+steps,octaves=Math.floor(target/n);
    return (octave+carry+octaves)*period+scale[modulo(target,n)];
  });
}

// Non-chord tones between two voicings of the same size (the voices paired), as Romantic dissonance treats them.
// - suspensions: a voice held over the change, a step (one or two semitones) above where it goes, and not a tone of
//   the chord arrived at; it resolves down by step. `chord`: the new chord's pitch classes.
// - appoggiaturas: a voice whose new note could be reached from a step above (or a semitone below), the dissonance
//   struck on the beat in its place; the top voice first.
// - passing tones: a voice moving a third (three or four semitones) filled by the tone between, within `collection`
//   where one is given, else chromatically by a semitone from the note it leaves.
export function suspensions(from,to,chord,{period=12}={}){
  const out=[];
  for(let i=0;i<to.length;i++){
    const drop=from[i]-to[i];
    if(drop>.5&&drop<2.5&&!chord.some(pc=>near(pcOf(from[i],period),pc,period)))out.push({voice:i,hold:from[i],resolve:to[i]});
  }
  return out;
}
export function appoggiaturas(to,chord,{period=12,collection=null,within=false}={}){
  const out=[];
  for(let i=to.length-1;i>=0;i--){
    // The step above within the collection; the semitone below (chromatic), or with `within` the step below within it.
    const inCollection=step=>collection.some(pc=>near(pcOf(to[i]+step,period),pc,period));
    const above=to[i]+(collection?[1,2].find(inCollection)??2:2),below=to[i]-(within&&collection?[1,2].find(step=>inCollection(-step))??1:1);
    for(const note of [above,below])if(!chord.some(pc=>near(pcOf(note,period),pc,period))&&!to.some((pitch,j)=>j!==i&&Math.abs(pitch-note)<1.5)){out.push({voice:i,note,resolve:to[i]});break;}
  }
  return out;
}
export function passingTones(from,to,{period=12,collection=null}={}){
  const out=[];
  for(let i=0;i<to.length;i++){
    const move=to[i]-from[i],size=Math.abs(move);if(size<2.5||size>4.5)continue;
    const direction=Math.sign(move),inCollection=collection?[1,2].map(step=>from[i]+direction*step).filter(p=>Math.abs(to[i]-p)>=.9&&collection.some(pc=>near(pcOf(p,period),pc,period))):[];
    out.push({voice:i,from:from[i],note:inCollection[0]??from[i]+direction*(size>3.5?2:1),to:to[i]});
  }
  return out;
}
