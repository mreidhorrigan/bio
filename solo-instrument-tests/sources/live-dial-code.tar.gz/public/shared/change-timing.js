// When a meter or tempo change asked for applies: the second argument of /broadcast/timeSignature and
// /broadcast/tempoCurve. 'opening' (before the first pulse), 'nextBar', 'nextPhrase', or 'bar:<n>', at bar n (Musebots
// 3.0: a conductor that plans ahead hands each section over some bars before it, where a networked room needs seconds
// to agree a meter: ensemble-conductor.js, plex_clodbot). A bar already reached means the next bar; a networked room
// that cannot agree by then takes the first bar it can. A transport that has never heard of 'bar:<n>' reads it as
// 'nextBar', as it reads any word it does not know.
// How far ahead a networked room must hear a change to agree it (ensemble-conductor.js): a meter at the first bar line
// this many seconds after the primary hears it (its window closing 1.5 s before), a tempo at the first a second after.
export const METER_NOTICE_SECONDS=2.1,TEMPO_NOTICE_SECONDS=1;
export const whenBar=mode=>{const found=typeof mode==='string'?/^bar:(\d{1,9})$/.exec(mode):null;return found?Number(found[1]):null};
export const atBar=bar=>`bar:${Math.max(0,Math.floor(Number(bar)||0))}`;
