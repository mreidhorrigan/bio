// A formal-state vector (the extreme-aesthetics report's §5.1, M4): the form's state kept apart from how many notes a
// second are sounding, so that a passage can become structurally clearer without becoming slower or sparser (E21), and
// no bot reads notesPerSecond as formal energy.
//
// Its fields are annotations and model features, proxies that need validation, not perceptual facts read off MIDI (§5.1).
// Each is counted from what was heard over a window of elapsed seconds, or said by the form itself. A field nothing
// has spoken to is null, unknown rather than zero.
//   recognizableReturns  returns heard in the window: remembered material presented again, a section returning home
//   materialNovelty      the share of the window's material heard as new (null until any material is heard)
//   groupingAmbiguity    the share of the parts' groupings that differ from the meter's (0 all agree)
//   anchorStability      1 with no tempo or meter change in the window, falling with each
//   harmonicChangeRate   chord changes a second
//   texturalChangeRate   parts entering or leaving, a second
//   attackDensity        onsets heard a second (null where no voice reports its onsets): the surface, kept apart
//   contrastHistory      the tension step at each section change so far, most recent last (at most historyLength)
//   elapsedSeconds, pendingArrival (seconds to the next section, or null), endingState ('open', 'committed', 'closing')

// ---- Choices ---------------------------------------------------------------------------------------------------------
export const FORMAL_STATE=Object.freeze({
  // The window rates and counts are taken over (ours: four bars at 60 bpm, two phrases at 120).
  windowSeconds:16,
  // The anchor's fall for each tempo or meter change in the window (ours: four changes and it has none left).
  anchorPerChange:.25,
  // How many section changes the contrast history keeps, and the most events a window keeps of each kind.
  historyLength:16,mostEvents:4096,
  endingStates:Object.freeze(['open','committed','closing']),
});
const KINDS=Object.freeze(['onset','chord','entry','return','novel','known','anchor']);

export class FormalState{
  constructor({choices=FORMAL_STATE}={}){this.choices=choices;this.events=new Map(KINDS.map(kind=>[kind,[]]));this.contrast=[];this.groupings=new Map;this.lastTension=null;this.onsetsHeard=false}
  // An event of `kind` heard at `at` (elapsed seconds): kept for the window, bounded.
  heard(kind,at){
    if(!this.events.has(kind))throw new RangeError(`no formal event ${kind}: ${KINDS.join(', ')}`);
    const list=this.events.get(kind);list.push(at);if(list.length>this.choices.mostEvents)list.shift();
    if(kind==='onset')this.onsetsHeard=true;
  }
  // A part's grouping (its groups in beats), against the meter's (`meterGroups`).
  heardGrouping(part,groups,meterGroups){this.groupings.set(String(part),(groups??[]).join('+')!==(meterGroups??[]).join('+'))}
  forgetPart(part){this.groupings.delete(String(part))}
  // A section begun, its tension (0-1): the step from the last joins the contrast history.
  section(tension){
    if(Number.isFinite(tension)){if(this.lastTension!==null){this.contrast.push(Math.round((tension-this.lastTension)*1000)/1000);if(this.contrast.length>this.choices.historyLength)this.contrast.shift()}this.lastTension=tension}
  }
  count(kind,at){const from=at-this.choices.windowSeconds;return this.events.get(kind).filter(time=>time>from&&time<=at).length}
  // The vector now (at: elapsed seconds). `pendingArrival` (seconds to the next section, or null) and `endingState` are
  // the form's to say.
  snapshot(at,{pendingArrival=null,endingState='open'}={}){
    const window=this.choices.windowSeconds,rate=kind=>Math.round(this.count(kind,at)/window*1000)/1000;
    const novel=this.count('novel',at),known=this.count('known',at),parts=[...this.groupings.values()];
    if(!this.choices.endingStates.includes(endingState))throw new RangeError(`an ending state is ${this.choices.endingStates.join(', ')}`);
    return Object.freeze({
      recognizableReturns:this.count('return',at),
      materialNovelty:novel+known?Math.round(novel/(novel+known)*1000)/1000:null,
      groupingAmbiguity:parts.length?Math.round(parts.filter(Boolean).length/parts.length*1000)/1000:null,
      anchorStability:Math.max(0,1-this.count('anchor',at)*this.choices.anchorPerChange),
      harmonicChangeRate:rate('chord'),texturalChangeRate:rate('entry'),
      attackDensity:this.onsetsHeard?rate('onset'):null,
      contrastHistory:Object.freeze([...this.contrast]),
      elapsedSeconds:Math.round(at*1000)/1000,pendingArrival,endingState,
    });
  }
}
