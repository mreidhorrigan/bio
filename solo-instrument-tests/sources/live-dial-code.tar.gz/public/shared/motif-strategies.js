// Sixteen ways of choosing which stored motifs answer a query, switchable at
// runtime, one per method in the survey in
// research/MEMORYBOT_RANKING_RESEARCH.md. Several of them are expected to be
// musically poor: `shuffle` is a control, `oldest` is a control, `popular` is
// the challenger the survey says a contextual model has to beat before its
// complexity is justified. They are here so the default can be compared against
// something rather than asserted, and so the same library can be heard under
// different ideas of what "best" means.
//
// Every strategy is handed the *same* prepared candidates: one evidence pass,
// one content read, the ledger as it stood before this answer was credited. A
// comparison between two of them is therefore a comparison of how they choose
// and not of what they were told. None of them writes anything.
//
// Determinism holds across all of them: no Math.random anywhere, exact score
// comparisons, and every sort ends in a locale-independent motifId tiebreak, so
// one message sequence always produces one slate. `shuffle` is a hash of the
// request, not a generator, for the same reason.
//
// The bracketed sources are the register at the end of the research memo.

import {insistentSlate} from './motif-insistence.js';
import {selectLazyCoverage} from './lazy-coverage.js';
import {MOTIF_STRATEGY_NAMES, bounded, byRelevance, finishSlate, prepareCandidates,
  motifRankingPolicy, selectByRelevance, shapeSimilarity, dppKernel} from './motif-ranking.js';

const clamp=(value,low,high)=>value<low?low:value>high?high:value;
const round=(value,places=6)=>Number(Number(value).toFixed(places));
const byId=(left,right)=>left<right?-1:left>right?1:0;
// Every ordering ends here, so no strategy can inherit an accident of iteration.
const ordered=(entries,score)=>[...entries]
  .map(entry=>{entry.score=round(score(entry));return entry})
  .sort((left,right)=>right.score-left.score||byId(left.motifId,right.motifId));

// Stable bounded selection, with the same rounded score/id order as ordered().
// O(N log k) score comparisons, O(k) retained entries; explanations follow selection.
const orderedTop=(entries,limit,score)=>{
  const compare=(a,b)=>b.score-a.score||byId(a.motifId,b.motifId),heap=[];
  const down=at=>{for(;;){let child=2*at+1;if(child>=heap.length)return;
    if(child+1<heap.length&&compare(heap[child+1],heap[child])>0)child++;
    if(compare(heap[child],heap[at])<=0)return;
    [heap[at],heap[child]]=[heap[child],heap[at]];at=child}};
  for(const entry of entries){entry.score=round(score(entry));
    if(heap.length<limit){heap.push(entry);let i=heap.length-1;
      while(i){const parent=(i-1)>>1;if(compare(heap[i],heap[parent])<=0)break;
        [heap[i],heap[parent]]=[heap[parent],heap[i]];i=parent}}
    else if(limit&&compare(entry,heap[0])<0){heap[0]=entry;down(0)}}
  return heap.sort(compare);
};

// ---- symbols ---------------------------------------------------------------
// Intervals are floats and stay floats. What follows quantizes a *copy* of them
// to a quarter-tone so that n-grams, a Markov model and a description length
// have something discrete to count -- a comparison grid, never a stored pitch.
// The ensemble tunes in quarter-tones and finer, so this is already lossy about
// what it hears; that is a property of the symbolic methods, and a reason none
// of them is the default.
function symbolsOf(entry,policy){
  if(!entry.symbols)entry.symbols=entry.shape.intervals.slice(0,policy.descriptorLength)
    .map(interval=>Math.round(interval/policy.symbolStep));
  return entry.symbols;
}
function ngramsOf(entry,policy){
  if(!entry.ngrams){
    const symbols=symbolsOf(entry,policy),size=policy.ngramLength,grams=new Set();
    for(let index=0;index+size<=symbols.length;index++)grams.add(symbols.slice(index,index+size).join(','));
    entry.ngrams=grams;
  }
  return entry.ngrams;
}
// Frieler's generalized n-gram similarity, in its simplest normalized form: how
// much of the larger of the two clips the shared figures account for. Exact
// matching is brittle to ornament and to tuning noise, which is the point of
// having the alignment strategy beside it.                                 [S1]
//
// Two clips are compared at a common order: the policy's length, or the shorter
// clip's own where one is shorter than that. At the policy's length two short
// clips have no figures at all, and were found identical however they moved
// (the mathematical audit's M05); a clip with no interval is the same only as
// another with none.
function ngramsAt(entry,policy,size){
  if(size===policy.ngramLength)return ngramsOf(entry,policy);
  const symbols=symbolsOf(entry,policy),grams=new Set();
  for(let index=0;index+size<=symbols.length;index++)grams.add(symbols.slice(index,index+size).join(','));
  return grams;
}
function ngramSimilarity(left,right,policy){
  const a=symbolsOf(left,policy).length,b=symbolsOf(right,policy).length;
  if(!a||!b)return a===b?1:0;
  const size=Math.min(policy.ngramLength,a,b),first=ngramsAt(left,policy,size),second=ngramsAt(right,policy,size);
  let shared=0;
  for(const gram of first)if(second.has(gram))shared++;
  return shared/Math.max(first.size,second.size);
}
// Edit distance over interval sequences with a continuous substitution cost, so
// a quarter-tone ornament costs a fraction of an edit and a leap costs a whole
// one. Rolling row: O(min(Q,L)) memory, both sides bounded by descriptorLength.
//                                                                          [S2]
function alignmentSimilarity(left,right,policy){
  let a=left.shape.intervals.slice(0,policy.descriptorLength),
    b=right.shape.intervals.slice(0,policy.descriptorLength);
  if(!a.length&&!b.length)return 1;
  if(!a.length||!b.length)return 0;
  if(b.length>a.length)[a,b]=[b,a];
  let previous=Array.from({length:b.length+1},(_,index)=>index);
  for(let i=1;i<=a.length;i++){
    const row=[i];
    for(let j=1;j<=b.length;j++){
      const substitution=Math.min(1,Math.abs(a[i-1]-b[j-1])/policy.alignmentScale);
      row[j]=Math.min(previous[j]+1,row[j-1]+1,previous[j-1]+substitution);
    }
    previous=row;
  }
  return 1-clamp(previous[b.length]/Math.max(a.length,b.length),0,1);
}
// A description length, not a compression. Real geometric compression inherits
// the discovery cost of SIATEC and belongs offline; this counts how much of a
// clip's figural content repeats, which is the property that made compression
// ratio interesting. The survey rejects it as a global ranking target and it is
// here to be compared, not believed.                                       [S6]
function compressionRatio(entry,policy){
  const symbols=symbolsOf(entry,policy);
  if(symbols.length<2)return 0;
  const grams=ngramsOf(entry,policy),total=Math.max(1,symbols.length-policy.ngramLength+1);
  const distinct=new Set(symbols).size;
  return round(.5*(1-grams.size/total)+.5*(1-distinct/symbols.length));
}
// A bounded variable-order Markov model over the whole eligible population, and
// each clip's mean information content under it: -log2 P(symbol | context),
// averaged, so a long clip is not surprising merely for being long. Smoothed,
// so an unseen continuation costs a large number rather than an infinite one.
//
// This is an IDyOM-shaped measure, not IDyOM: one viewpoint, one timescale, no
// long-term/short-term combination. Information content is realized surprise
// and entropy is uncertainty before the event; neither is a reward, and more
// surprising is not better. `targetInformation` exists so that can be tested
// rather than assumed.                                                     [S7]
function markovModel(entries,policy){
  const counts=new Map(),totals=new Map(),alphabet=new Set();
  for(const entry of entries){
    const symbols=symbolsOf(entry,policy);
    for(const symbol of symbols)alphabet.add(symbol);
    for(let index=0;index<symbols.length;index++)
      for(let order=0;order<=policy.markovOrder;order++){
        if(index<order)continue;
        const context=symbols.slice(index-order,index).join(','),key=`${order}|${context}`;
        const table=counts.get(key)||new Map();
        table.set(symbols[index],(table.get(symbols[index])||0)+1);
        counts.set(key,table);totals.set(key,(totals.get(key)||0)+1);
      }
  }
  return {counts,totals,alphabet:Math.max(1,alphabet.size)};
}
// A clip is scored under the library without itself (leave one clip out): its own counts are taken back out of the
// model's, so it is not rewarded for explaining itself (the mathematical audit's M03). A context only it had is none.
function informationContent(entry,model,policy){
  const symbols=symbolsOf(entry,policy);
  if(!symbols.length)return 0;
  const own=markovModel([entry],policy);
  let bits=0;
  for(let index=0;index<symbols.length;index++){
    // The longest context this symbol has, down to none: a bounded stand-in for
    // the order mixture a full model would compute.
    let probability=0;
    for(let order=Math.min(policy.markovOrder,index);order>=0;order--){
      const key=`${order}|${symbols.slice(index-order,index).join(',')}`,table=model.counts.get(key);
      if(!table)continue;
      const total=(model.totals.get(key)||0)-(own.totals.get(key)||0);
      if(total<=0)continue;
      const seen=(table.get(symbols[index])||0)-(own.counts.get(key)?.get(symbols[index])||0);
      probability=(seen+policy.markovSmoothing)/(total+policy.markovSmoothing*model.alphabet);
      break;
    }
    if(!(probability>0))probability=1/model.alphabet;
    bits+=-Math.log2(probability);
  }
  return bits/symbols.length;
}
// Coverage buckets: where the clip sits, how dense it is, and whether it needs
// microtones. Categories rather than pairwise similarity is what keeps the
// submodular objective at O(N K C) instead of needing an N-by-N kernel.  [S14]
// Where it sits is its pitch centre, in bands over C1 to C7 (REGISTER_RANGE); how
// dense, its onsets a quarter note, in bands up to four (DENSITY_TOP); a clip with
// no pitch or no length in an "unknown" band of its own. Span and note count had
// stood in for them, so two equal spans an octave apart shared a register and four
// notes in a bar or in a minute a density (the mathematical audit's M03).
export const REGISTER_RANGE=Object.freeze([24,96]),DENSITY_TOP=4;
function categoriesOf(entry,policy){
  if(!entry.categories){
    const centre=entry.evidence.centre,rate=entry.evidence.rate,band=(share,bands)=>Math.min(bands-1,Math.floor(clamp(share,0,.999)*bands));
    const register=Number.isFinite(centre)?band((centre-REGISTER_RANGE[0])/(REGISTER_RANGE[1]-REGISTER_RANGE[0]),policy.registerBands):'unknown',
      density=Number.isFinite(rate)?band(rate/DENSITY_TOP,policy.densityBands):'unknown';
    entry.categories=[`register:${register}`,`density:${density}`,
      `tuning:${entry.evidence.microtonal?'micro':'twelve'}`,`from:${entry.motif.metadata?.author||'unknown'}`];
  }
  return entry.categories;
}
// A deterministic permutation: FNV-1a over the seed, the request and the id.
// No generator, no state, nothing shared with the bots that make the music --
// the control condition has to be reproducible from the message stream alone.
function shuffleKey(entry,context,policy){
  let hash=2166136261;
  for(const character of `${policy.shuffleSeed}:${context.requestId||''}:${entry.motifId}`){
    hash^=character.charCodeAt(0);hash=Math.imul(hash,16777619);
  }
  return (hash>>>0)/4294967296;
}
// What "like this" means. A request may name a motif (`query.like`); otherwise
// the most relevant candidate stands in, so the strategy is defined even when
// nothing was named. A named anchor is left out of its own answer: the bot
// asking for material like something already has that something.
function anchorFor(scored,context){
  const named=context.like?scored.find(entry=>entry.motifId===String(context.like)):null;
  return {entry:named||scored[0]||null,named:Boolean(named)};
}
const without=(entries,anchor)=>anchor.named?entries.filter(entry=>entry!==anchor.entry):entries;
// How much a clip is likely to push: how much of it there is, and how far it
// travels. A crude reading of energy, and the one thing the two form strategies
// have in common -- they disagree about what the music wants, not about this.
const energyOf=entry=>.5*entry.features.substance+.5*clamp((entry.evidence.span||0)/12,0,1);
// Plain words for the relations, for an explanation a person reads.
const PRESENTATION_LABELS=Object.freeze({first:'sound for the first time',
  immediate:'restate what was just heard',persistent:'keep a running layer going',
  returned:'come back after an absence',transformed:'come back changed',
  roleRecurrence:'recur as this kind of section',allusion:'allude to earlier material'});

// ---- the strategies --------------------------------------------------------

export const MOTIF_STRATEGIES=Object.freeze({
  // The contextual feature model with a diversity pass. The default, and the
  // one everything else exists to test.                              [S11, S13]
  relevance:{
    summary:'contextual features, then maximal marginal relevance',
    select:(scored,context,policy)=>selectByRelevance(scored,context,policy)
      .map(entry=>Object.assign(entry,{reason:entry.displaced?`kept for contrast with ${entry.displaced}`:''})),
  },
  // What a query did before any of this existed. The baseline every claim about
  // ranking has to be measured against, kept runnable rather than described.
  newest:{
    summary:'the most recent captures that matched, as a query answered before ranking',
    select:(scored,context,policy)=>orderedTop(scored,bounded(context,policy),entry=>entry.order)
      .map(entry=>Object.assign(entry,{reason:'the most recent material that matched'})),
  },
  oldest:{
    summary:'the oldest surviving captures: a control, and an archivist',
    select:(scored,context,policy)=>orderedTop(scored,bounded(context,policy),entry=>-entry.order)
      .map(entry=>Object.assign(entry,{reason:'the oldest material still held'})),
  },
  // A control condition. Reproducible, and deliberately without any idea of
  // what is good -- if a strategy cannot beat this, it is not choosing.
  shuffle:{
    summary:'a seeded permutation, as a control',
    select:(scored,context,policy)=>orderedTop(scored,bounded(context,policy),entry=>shuffleKey(entry,context,policy))
      .map(entry=>Object.assign(entry,{reason:'drawn by a seeded shuffle, on no evidence at all'})),
  },
  // Raw popularity: total uses by other bots, no context, no saturation. The
  // survey keeps it as a challenger precisely because a contextual model has to
  // be shown to be worth more than counting.                           [S9, S10]
  popular:{
    summary:'total uses by other bots, uncorrected for exposure or context',
    select:(scored,context,policy)=>orderedTop(scored,bounded(context,policy),entry=>entry.evidence.uses)
      .map(entry=>Object.assign(entry,{reason:entry.evidence.uses
        ?`used ${entry.evidence.uses} time${entry.evidence.uses===1?'':'s'} in all`:'never used by anyone'})),
  },
  // Popularity with an uncertainty bonus, in the UCB1 shape: a clip nobody has
  // been offered is worth something for being unknown. Deterministic, as the
  // survey notes UCB can be -- the bonus is an arithmetic function of the
  // counts, not a sample.                                             [S16, S17]
  ucb:{
    summary:'uptake plus an uncertainty bonus for material nothing has tried',
    select:(scored,context,policy)=>{
      const offers=scored.reduce((total,entry)=>total+entry.evidence.offered,0);
      return orderedTop(scored,bounded(context,policy),entry=>{
        const value=entry.evidence.adopters/(entry.evidence.adopters+1);
        return value+policy.explorationBonus*Math.sqrt(Math.log(1+offers)/(1+entry.evidence.offered));
      }).map(entry=>Object.assign(entry,{reason:entry.evidence.offered
        ?`uptake against ${entry.evidence.offered} chance${entry.evidence.offered===1?'':'s'}`
        :'never offered, so its value is unknown'}));
    },
  },
  // More like this one.                                                     [S1]
  ngram:{
    summary:'shared figures with a named motif, by n-gram coincidence',
    select:(scored,context,policy)=>{
      const anchor=anchorFor(scored,context);
      if(!anchor.entry)return [];
      return orderedTop(without(scored,anchor),bounded(context,policy),entry=>ngramSimilarity(entry,anchor.entry,policy))
        .map(entry=>Object.assign(entry,{reason:`shares figures with ${anchor.entry.motifId}`}));
    },
  },
  // More like this one, forgiving about ornament and tuning.                [S2]
  alignment:{
    summary:'closest to a named motif by edit distance over intervals',
    select:(scored,context,policy)=>{
      const anchor=anchorFor(scored,context);
      if(!anchor.entry)return [];
      return orderedTop(without(scored,anchor),bounded(context,policy),entry=>alignmentSimilarity(entry,anchor.entry,policy))
        .map(entry=>Object.assign(entry,{reason:`a near alignment with ${anchor.entry.motifId}`}));
    },
  },
  // Anything but this one. Not from the survey as a retrieval method: it is the
  // musical inverse of the two above, and an ensemble asks for contrast at
  // least as often as it asks for more of the same.
  contrast:{
    summary:'least like a named motif',
    select:(scored,context,policy)=>{
      const anchor=anchorFor(scored,context);
      if(!anchor.entry)return [];
      return orderedTop(without(scored,anchor),bounded(context,policy),entry=>1-shapeSimilarity(entry.shape,anchor.entry.shape,policy))
        .map(entry=>Object.assign(entry,{reason:`as unlike ${anchor.entry.motifId} as the library holds`}));
    },
  },
  // Material that repeats itself: ostinati, sequences, figures with a shape.
  //                                                                        [S6]
  compression:{
    summary:'the most repetitive material, by a description-length proxy',
    select:(scored,context,policy)=>orderedTop(scored,bounded(context,policy),entry=>compressionRatio(entry,policy))
      .map(entry=>Object.assign(entry,{reason:'its figures repeat within the clip'})),
  },
  // Material the library does not predict.                                  [S7]
  expectancy:{
    summary:'information content under a bounded Markov model of the library',
    select:(scored,context,policy)=>{
      const model=markovModel(scored,policy);
      const bits=new Map(scored.map(entry=>[entry,informationContent(entry,model,policy)]));
      // Against the declared alphabet: a symbol's bits over those of a uniform guess among the library's symbols, the
      // same reference whatever else is in the query (min-max scaling across the query had moved with every unrelated
      // candidate; the mathematical audit's M03). Capped at one: an unseen continuation can cost more than a guess.
      const reference=Math.log2(Math.max(2,model.alphabet));
      return orderedTop(scored,bounded(context,policy),entry=>{
        const normalized=clamp(bits.get(entry)/reference,0,1);
        return 1-Math.abs(normalized-policy.targetInformation);
      }).map(entry=>Object.assign(entry,{reason:`${bits.get(entry).toFixed(2)} bits a symbol under the library without it`}));
    },
  },
  // A slate that represents the library rather than its best corner: greedy
  // maximisation of covered categories, weighted by how much of the library
  // each category accounts for. Monotone and submodular over a ground set of
  // categories, which is where the classic greedy guarantee applies.     [S14]
  coverage:{
    summary:'a slate covering as much of the library’s variety as it can',
    select:(scored,context,policy)=>{
      const limit=bounded(context,policy),weights=new Map();
      for(const entry of scored)for(const category of categoriesOf(entry,policy))
        weights.set(category,(weights.get(category)||0)+1);
      // Coverage plus relevance/1000 is the objective; the modular term is not merely a tie rule.
      return selectLazyCoverage(scored,{limit,categories:entry=>categoriesOf(entry,policy),
        weights:new Map([...weights].map(([key,value])=>[key,value/scored.length])),modular:entry=>entry.relevance/1000});
    },
  },
  // The determinantal point process's other idea: a set is good when its
  // quality vectors span a volume, so quality and diversity are one quantity
  // rather than two traded off by a lambda. This is the greedy MAP
  // approximation with an incremental Cholesky, not a sample from the DPP --
  // sampling is not an ordered answer.                                    [S15]
  // Its kernel is dppKernel, positive semidefinite by construction; MMR's similarity, with its family floor by max, is
  // not (the mathematical audit's M01). Qualities are taken relative to the most relevant candidate, so they stay finite
  // at any accepted determinantalQuality; the MAP is unchanged by that common factor. Once no candidate adds volume
  // (the slate spans all the candidates do), the rest of the answer is filled by relevance and says so, rather than
  // passing zero-volume choices off as new directions.
  determinantal:{
    summary:'the slate spanning the largest volume, by greedy DPP MAP',
    select:(scored,context,policy)=>{
      const limit=bounded(context,policy),top=Math.max(...scored.map(entry=>entry.relevance)),quality=new Map(scored.map(entry=>
        [entry,Math.exp(policy.determinantalQuality*(entry.relevance-top))]));
      const gains=new Map(scored.map(entry=>[entry,quality.get(entry)**2*dppKernel(entry.shape,entry.shape,policy)])),
        vectors=new Map(scored.map(entry=>[entry,[]])),results=[],remaining=new Set(scored),
        spanned=1e-12*Math.max(0,...gains.values());
      while(results.length<limit&&remaining.size){
        let best=null,bestGain=-Infinity;
        for(const entry of remaining){
          const gain=gains.get(entry);
          if(gain>bestGain||(gain===bestGain&&best&&byId(entry.motifId,best.motifId)<0)){best=entry;bestGain=gain}
        }
        if(!(bestGain>spanned)){
          // Nothing left adds a direction: the most relevant of the rest, labelled.
          for(const entry of remaining)if(entry.relevance>best.relevance||(entry.relevance===best.relevance&&byId(entry.motifId,best.motifId)<0))best=entry;
          remaining.delete(best);
          best.score=round(Math.log(Math.max(bestGain,Number.MIN_VALUE)));
          best.reason='repeats a direction the answer already covers: the candidates span no more';
          results.push(best);continue;
        }
        remaining.delete(best);
        best.score=round(Math.log(bestGain));
        best.reason='adds a direction the answer did not already cover';
        results.push(best);
        const pivot=Math.sqrt(bestGain),chosen=vectors.get(best);
        for(const entry of remaining){
          const similarity=dppKernel(entry.shape,best.shape,policy);
          let dot=0;const own=vectors.get(entry);
          for(let index=0;index<chosen.length;index++)dot+=own[index]*chosen[index];
          const projection=(quality.get(entry)*quality.get(best)*similarity-dot)/pivot;
          own.push(projection);
          gains.set(entry,Math.max(gains.get(entry)-projection*projection,0));
        }
      }
      return results;
    },
  },
  // The one strategy that reads where the music has got to. FormBOT broadcasts
  // its sections and which one is current, so MemoryBot can know the role
  // without a protocol change; the role's tension is what the material is
  // matched against, and its closure decides whether familiar material or
  // rested material is wanted. A hypothesis about form, and testable as one.
  form:{
    summary:'material matched to the tension and closure of the current section',
    select:(scored,context,policy)=>{
      const tension=Number(context.tension),closure=clamp(Number(context.closure)||0,0,1);
      if(!Number.isFinite(tension))return ordered(scored,entry=>entry.relevance)
        .map(entry=>Object.assign(entry,{reason:context.role
          ?`nothing here knows what tension ${context.role} wants, so relevance decides`
          :'no section has been announced, so relevance decides'}));
      return ordered(scored,entry=>{
        const familiar=closure*entry.features.taken+(1-closure)*entry.features.rest;
        return .5*(1-Math.abs(energyOf(entry)-tension))+.3*familiar+.2*entry.relevance;
      }).map(entry=>Object.assign(entry,{
        reason:`matched to ${context.role||'this section'} at tension ${tension.toFixed(2)}`}));
    },
  },
  // What this appearance would DO, which is a different question from how much
  // the material has been used. A motif that has been absent for a long stretch
  // under other material would RETURN; one that has been running underneath
  // throughout would merely CONTINUE; a shortened one would ALLUDE. Those are
  // different formal acts even when the notes are identical, and a use count
  // cannot tell them apart -- which is why this reads the presentation history
  // and not the ledger.
  //
  // Nothing is labelled. The relation is recomputed for this moment, because
  // the same clip would be doing something else an hour later. A role the
  // policy has no opinion about produces no preference rather than a guess, and
  // says so.
  //
  // Diversity here depends on the relation, not on a global novelty rule: a
  // family that is currently a reference layer is exempt from the redundancy
  // penalty, because penalising a drone for resembling itself is the one thing
  // a continuing layer must not be punished for.
  formal:{
    summary:'material whose next appearance would do what this section is for',
    select:(scored,context,policy)=>{
      const history=context.history,role=String(context.role||''),
        atBeats=Number(context.atBeats)||0;
      if(typeof history?.relate!=='function')return ordered(scored,entry=>entry.relevance)
        .map(entry=>Object.assign(entry,{reason:'nothing has sounded yet, so relevance decides'}));
      const wanted=policy.relationsForRole[role]||null;
      const relations=new Map(scored.map(entry=>[entry,history.relate({motif:entry.motif,
        family:entry.shape.family,atBeats,role,notes:entry.evidence.notes,phraseBeats:context.phraseBeats})]));
      const fit=entry=>{
        if(!wanted)return entry.relevance;
        const seen=relations.get(entry);
        if(wanted.includes(seen.relation))return 1;
        if(seen.also.some(name=>wanted.includes(name)))return policy.secondaryRelation;
        return 0;
      };
      const ranked=ordered(scored,entry=>
        policy.formalWeight*fit(entry)+(1-policy.formalWeight)*entry.relevance)
        .map(entry=>{
          const seen=relations.get(entry);
          entry.reason=wanted
            ?`would ${PRESENTATION_LABELS[seen.relation]||seen.relation} here, and ${role} wants `
              +`${wanted.join(' or ')}: ${seen.because}`
            :`nothing here knows what kind of return ${role||'this section'} wants; ${seen.because}`;
          return entry;
        });
      // The diversity pass, exempting reference layers.
      const limit=bounded(context,policy),results=[],taken=[];
      for(const entry of ranked){
        if(results.length>=limit)break;
        const persistent=relations.get(entry).relation==='persistent';
        if(!persistent){
          let redundancy=0;
          for(const chosen of taken)redundancy=Math.max(redundancy,shapeSimilarity(entry.shape,chosen.shape,policy));
          if(redundancy>policy.lambda&&results.length)continue;
          entry.redundancy=round(redundancy);
        }
        taken.push(entry);results.push(entry);
      }
      return results;
    },
  },
  // The other theory of form, and the one to compare `form` against: not what
  // this section is called but how far through the piece it is. /broadcast/form
  // /progress carries an overall 0..1 from both form bots, and it is the only
  // figure in the protocol that says how far through anything the music is --
  // there is no total duration anywhere, in seconds or in bars.
  //
  // The shape is an arch, which is where the ensemble's own form archetypes put
  // most of their weight: energy rises to the middle and settles by the end,
  // and material that has been heard before is wanted more as the piece closes.
  // A guess about form, deliberately a different guess from `form`.
  arc:{
    summary:'material shaped to how far through the form the music has got',
    select:(scored,context,policy)=>{
      const progress=Number(context.progress);
      if(!Number.isFinite(progress))return ordered(scored,entry=>entry.relevance)
        .map(entry=>Object.assign(entry,{
          reason:'nothing has said how far through the form this is, so relevance decides'}));
      const target=Math.sin(Math.PI*progress);
      return ordered(scored,entry=>{
        const familiar=progress*entry.features.taken+(1-progress)*entry.features.rest;
        return .5*(1-Math.abs(energyOf(entry)-target))+.3*familiar+.2*entry.relevance;
      }).map(entry=>Object.assign(entry,{
        reason:`${Math.round(progress*100)}% through the form, which wants energy ${target.toFixed(2)}`}));
    },
  },
});

// The dispatcher. A request may name a strategy; an unknown name falls back to
// the configured one rather than failing the query, because a bot from another
// build asking for something this one has never heard of is not an error.
export function selectMotifs(candidates=[],context={},policy=motifRankingPolicy()){
  const limit=bounded(context,policy);
  const scored=prepareCandidates(candidates,context,policy).sort(byRelevance);
  const requested=String(context.strategy||''),
    name=Object.hasOwn(MOTIF_STRATEGIES,requested)?requested:policy.strategy;
  const baseline=MOTIF_STRATEGIES[name].select(scored,{...context,limit},policy).slice(0,limit);
  const results=insistentSlate(scored,baseline,{limit,maxResults:policy.maxResults});
  return {considered:scored.length,limit,strategy:name,
    results:finishSlate(results,scored.length,policy)};
}

// Declared in motif-ranking.js so the policy can refuse a name it cannot run;
// implemented here. Nothing keeps the two in step but this, and a test.
export const MOTIF_STRATEGY_SUMMARIES=Object.freeze(Object.fromEntries(
  MOTIF_STRATEGY_NAMES.map(name=>[name,MOTIF_STRATEGIES[name]?.summary||''])));
