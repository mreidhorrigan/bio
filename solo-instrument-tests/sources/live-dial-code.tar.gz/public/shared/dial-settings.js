// A live dial's settings as a file (the owner, 3 November 2026: "We also need a way to save and load settings on the
// web page - which will allow me to show you settings that work, including for convincing attacks, saving potential
// extensive debugging loops - and must expose the settings of the player bot"): what the page's family says its
// settings are -- the winds' dial's (native/openwind/dial.mjs /settings), the strings' page's own (native/live/
// strings.js settings) -- each with its player bot's, the words written to keep it and what the page heard, as JSON.
// The Mac's page and the website's write the same file, and each loads either's.
export const SETTINGS_FORMAT='musebots-live-dial-settings',SETTINGS_VERSION=1;
const FAMILIES=['strings','winds'];

// The file's text: -> JSON, one setting a line where it is short.
export function settingsFile({family,model,settings,words='',heard=null,page=null,at=new Date()}){
  if(!FAMILIES.includes(family)||typeof model!=='string'||!settings||typeof settings!=='object')throw new Error('a family, its instrument and its settings');
  return `${JSON.stringify({format:SETTINGS_FORMAT,version:SETTINGS_VERSION,saved:at.toISOString(),family,model,words,heard,page,settings},null,1)}\n`;
}
// Its name: the instrument and when it was saved, as the renders name theirs (20261103T225501).
export const settingsFileName=(model,at=new Date())=>`${model} ${at.toISOString().replace(/[-:]/g,'').replace(/\.\d+Z$/,'')} settings.json`;
// A file read back: -> {family, model, settings, words, heard, saved}, or why it is not one.
export function readSettingsFile(text){
  let got;try{got=JSON.parse(text)}catch{throw new Error('not a settings file: not JSON')}
  if(got?.format!==SETTINGS_FORMAT)throw new Error(`not a settings file (its format not "${SETTINGS_FORMAT}")`);
  if(!(got.version>=1&&got.version<=SETTINGS_VERSION))throw new Error(`a settings file of version ${got.version}: this page reads to ${SETTINGS_VERSION}`);
  if(!FAMILIES.includes(got.family)||typeof got.model!=='string'||!got.settings||typeof got.settings!=='object')throw new Error('a settings file with no family, instrument or settings');
  return got;
}
