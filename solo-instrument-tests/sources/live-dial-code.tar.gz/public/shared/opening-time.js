// The piece's time before anyone sets it: its meter, tempo, phrase, tala and density, drawn from the piece's seed (the
// owner, 1 October 2026: "fixing a default seed is ok, but all those other things need to be seed-derived; no default
// talas, et cetera"). Every transport began in 4/4 at 108 with phrases of four bars, every bot on the tala 3+2+2+3 at a
// density of .65, and the originals each on their own cell, whatever the seed. The harmony's opening is
// opening-harmony.js's; this is the rest of it.
//
// - Its meter: drawn from the whole space of meters (meter-space.js drawMeter: numerators to 40, power-of-two and
//   irrational denominators, groupings of its own, the talas' cycles), as meterspace_clodbot draws its homes -- which
//   meters is never restricted (the owner, 4 October 2026); its tempo counted in quarters (OPENING_TIME.reference: the
//   research reports' tempo unit), so that a long bar may run as fast as it must to be felt.
// - Its tempo: where its meter is felt (felt-tempo.js: its bar no longer than a listener hears as one group, a level of
//   it at a beat heard as one), log-uniform there, at the favored beats where it can be -- "107/32 could still appear if
//   its tempo is fast enough to make it feelable" (the owner). A meter felt at no tempo is no meter but a hypermetrical
//   cycle (written as bars of its felt groups: notation/score.js), its tempo then where its bar is one the band plays.
// - Its phrase: a length in seconds drawn (OPENING_TIME.phraseSeconds), in whole bars of the meter at its tempo, as
//   meterspace_clodbot makes a home's (1 to OPENING_TIME.phraseBarsAtMost). Where a spec or a room gives the meter and
//   tempo but no phrase, phraseBarsFor makes it the same way from the seed's phrase length.
// - Its tala: the meter's groups, which is what a bot's tala is (framework/agent.js, the groups a meter answers).
// - Its density: drawn (OPENING_TIME.density).
// A default seed may be fixed (render/spec.js DEFAULT_SEED); what it draws varies with it.
import {createRandomStream,ensembleSeed} from '../random-source.js';
import {drawGrouping,drawMeter,METER_SPACE} from './meter-space.js';
import {readingClockWindow} from './meter-reading.js';
import {feltTempi,feltTempo} from './felt-tempo.js';
import {tempoRange} from './tempo-range.js';

// ---- Choices ---------------------------------------------------------------------------------------------------------
// The seed where none is given: a render's (render/spec.js), and a room's before its session (ours; the owner: "fixing
// a default seed is ok").
export const DEFAULT_SEED=20260916;
export const OPENING_TIME=Object.freeze({
  // A phrase's length, in seconds, drawn log-uniform between these (ours: about meterspace_clodbot's eight).
  phraseSeconds:Object.freeze([5,13]),
  // A phrase's bars at most (ours: meterspace_clodbot's).
  phraseBarsAtMost:8,
  // The band's density before any is heard, drawn between these (ours).
  density:Object.freeze([.35,.85]),
  // The note a drawn meter's tempo counts (tempo-range.js tempoUnit): the quarter, as the research reports count every
  // tempo (research/meter/MUSEBOTS_METER_SELECTION_RESEARCH_REPORT.md: "All BPM values below mean quarter-note BPM").
  reference:4,
});
const CACHED=64;

const logUniform=(low,high,u)=>low*(high/low)**u;
// A bar's seconds at `bpm`: the clock's bpm counts the meter's own note (tempo-display.js).
const barSeconds=(meter,bpm)=>meter.numerator*60/bpm;
// The tempi at which `meter` is played: where it is felt (felt-tempo.js; a reading's own window where it has one),
// [low, high] across them; where it is felt at none, a hypermetrical cycle's -- where its bar is one the band plays
// (METER_SPACE.barSeconds) within its range, or that range's end nearest it.
export function playableTempi(meter){
  if(meter.metricReading){const window=readingClockWindow(meter);if(window)return window}
  const felt=feltTempi(meter);if(felt.length)return [felt[0][0],felt.at(-1)[1]];
  return cycleTempi(meter);
}
function cycleTempi(meter){
  const [low,high]=tempoRange(meter),[shortest,longest]=METER_SPACE.barSeconds;
  const from=Math.max(low,meter.numerator*60/longest),to=Math.min(high,meter.numerator*60/shortest);
  if(from<=to)return [from,to];
  const point=to<low?low:high;return [point,point];
}
// A phrase's whole bars of `meter` at `bpm`, about `seconds` long.
export function phraseBarsFor(meter,bpm,seconds){
  return Math.max(1,Math.min(OPENING_TIME.phraseBarsAtMost,Math.round(seconds/barSeconds(meter,bpm))));
}

// For a transport given part of its time (a render spec, a room): a tempo for `meter` and a grouping of `numerator`
// units, drawn from the seed as the opening's are.
export function tempoFor(meter,seed){
  const stream=createRandomStream(`${seed}:opening-tempo`),random=()=>stream.next();
  if(meter.metricReading){const window=readingClockWindow(meter);if(window)return +logUniform(window[0],window[1],random()).toFixed(3)}
  const felt=feltTempo(meter,random);if(felt!=null)return felt;
  const [low,high]=cycleTempi(meter);return +logUniform(low,high,random()).toFixed(3);
}
export function groupingFor(numerator,seed){
  const stream=createRandomStream(`${seed}:opening-grouping:${numerator}`);
  return drawGrouping(numerator,()=>stream.next());
}

// For a clock that lacks its tempo or phrase (a part's own, a test's): the band's opening's, from the seed of the bots
// being made, else the page's or the render's (random-source.js ensembleSeed). Never a tempo or phrase written here.
export const bandTempo=()=>openingTime(ensembleSeed()).bpm;
export const bandPhraseBars=()=>openingTime(ensembleSeed()).meter.phraseBars;
// The band's opening meter, for a clock whose meter lacks a field: {numerator, denominator, groups, subdivision,
// phraseBars, pulsesPerBar}.
export const bandMeter=()=>{const meter=openingTime(ensembleSeed()).meter;return {...meter,pulsesPerBar:meter.numerator*meter.subdivision}};

// The clock at `tick` in the band's opening time, for a bot ticked with none (a test's): its bar, phrase, beat and group
// as a transport's clockContext (meter.cjs) gives them.
export function openingClock(seed,tick=0){
  const {meter,bpm}=openingTime(seed),pulses=meter.numerator*meter.subdivision,tickInBar=((tick%pulses)+pulses)%pulses,bar=Math.floor(tick/pulses),beat=Math.floor(tickInBar/meter.subdivision);
  let at=0,group=0,groupBeat=beat,groupStart=false;
  for(const [index,size] of meter.groups.entries()){if(beat>=at&&beat<at+size){group=index;groupBeat=beat-at;groupStart=tickInBar===at*meter.subdivision}at+=size}
  return {tick,bar,phrase:Math.floor(bar/meter.phraseBars),tickInBar,beat,subdivision:tickInBar%meter.subdivision,group,groupBeat,barStart:tickInBar===0,
    beatStart:tickInBar%meter.subdivision===0,groupStart,phraseStart:tickInBar===0&&bar%meter.phraseBars===0,bpm,meter:{...meter,groups:[...meter.groups],pulsesPerBar:pulses}};
}

const openings=new Map;
// The piece's time from its seed: {meter: {numerator, denominator, groups, subdivision, phraseBars, label}, bpm,
// phraseSeconds, tala, density}. The same seed gives the same to every bot and transport that asks.
export function openingTime(seed){
  const key=String(seed);if(openings.has(key))return openings.get(key);
  const stream=createRandomStream(`${key}:opening-time`),random=()=>stream.next();
  const drawn={...drawMeter(random),tempoUnit:OPENING_TIME.reference},felt=feltTempo(drawn,random),bpm=felt??(([low,high])=>+logUniform(low,high,random()).toFixed(3))(cycleTempi(drawn));
  const phraseSeconds=+logUniform(...OPENING_TIME.phraseSeconds,random()).toFixed(3);
  const [least,most]=OPENING_TIME.density,density=+(least+(most-least)*random()).toFixed(3);
  const meter=Object.freeze({numerator:drawn.numerator,denominator:drawn.denominator,groups:Object.freeze([...drawn.groups]),subdivision:drawn.subdivision,
    phraseBars:phraseBarsFor(drawn,bpm,phraseSeconds),label:drawn.label,tempoUnit:drawn.tempoUnit,...(drawn.tala?{tala:drawn.tala}:{})});
  const opening=Object.freeze({meter,bpm,phraseSeconds,tala:meter.groups,density});
  openings.set(key,opening);if(openings.size>CACHED)openings.delete(openings.keys().next().value);
  return opening;
}
