// The rendezvous of independently playing pieces (RESEARCH_BACKLOG "Conductors that negotiate, not elect"): Codex's
// reviewed candidate (research/conductor-negotiation/rendezvous.mjs, CND-001, proofs P136-P142 in its PROOFS.md), taken
// into production code unchanged in its mathematics, so the research copy and its recorded hashes stay as they were
// (test/ensemble-rendezvous.test.mjs checks the two agree). It chooses, for pieces each arriving at a future downbeat
// (`anchor`, in one shared reference coordinate) after one of their allowed numbers of old-meter bars, a constant bridge
// tempo each, so all arrive together at one time T, minimizing their largest tempo distortion; its witness checker
// verifies a plan independently. Exact rationals at its boundary: integer strings, "n/d", safe integers or BigInts.
import {Q, ONE, boundedInt, id, preflight, boundedRun} from './math-support/adapters/solutions/FMR-001-bounded-hybrid-witnesses/exact.js';

const min=(a,b)=>a.cmp(b)<=0?a:b;
const max=(a,b)=>a.cmp(b)>=0?a:b;
const readQ=value=>{
  if(!['string','number','bigint'].includes(typeof value))throw new TypeError('Primitive rational encoding required');
  return Q.of(value);
};
const positive=(value,name)=>{
  const q=readQ(value);if(q.cmp(0)<=0)throw new RangeError(`${name} must be positive`);return q;
};
function fields(value,names,label){
  if(!value||typeof value!=='object'||Array.isArray(value))throw new TypeError(`${label} object required`);
  if(Reflect.ownKeys(value).some(key=>!names.includes(key))||names.some(key=>{
    const descriptor=Object.getOwnPropertyDescriptor(value,key);
    return !descriptor?.enumerable||!Object.hasOwn(descriptor,'value');
  }))
    throw new TypeError(`Unexpected or missing ${label} field`);
}
function denseArray(value,name,limit){
  if(!Array.isArray(value)||Object.getPrototypeOf(value)!==Array.prototype)throw new TypeError(`Plain ${name} array required`);
  boundedInt(value.length,`${name} count`,1,limit);
  if(Reflect.ownKeys(value).length!==value.length+1)throw new TypeError(`Unexpected ${name} array properties`);
  const copy=[];
  for(let i=0;i<value.length;i++){
    const d=Object.getOwnPropertyDescriptor(value,String(i));
    if(!d?.enumerable||!Object.hasOwn(d,'value'))throw new TypeError(`Dense ${name} data entries required`);
    copy.push(d.value);
  }
  return copy;
}

function prepare(input,budget){
  preflight(input);
  fields(input,['referenceEpoch','earliest','deadline','participants'],'rendezvous');
  id(input.referenceEpoch,'referenceEpoch');
  const earliest=readQ(input.earliest),deadline=readQ(input.deadline);
  if(earliest.cmp(deadline)>0)throw new RangeError('Reversed rendezvous window');
  const sources=denseArray(input.participants,'participants',8);
  const seen=new Set();
  const participants=sources.map(p=>{
    budget.tick();fields(p,['id','anchor','beatsPerBar','bpm','minBpm','maxBpm','bars'],'participant');
    id(p.id);if(seen.has(p.id))throw new TypeError('Duplicate participant');seen.add(p.id);
    const anchor=readQ(p.anchor),bpm=positive(p.bpm,'bpm');
    const low=positive(p.minBpm,'minBpm'),high=positive(p.maxBpm,'maxBpm');
    if(low.cmp(high)>0)throw new RangeError('Reversed BPM bounds');
    const beatsPerBar=boundedInt(p.beatsPerBar,'beatsPerBar',1,4096);
    const bars=denseArray(p.bars,'allowed bars',64).map(k=>boundedInt(k,'bars',1,4096)).sort((a,b)=>a-b);
    if(new Set(bars).size!==bars.length)throw new TypeError('Duplicate bar count');
    return {id:p.id,anchor,bpm,low,high,beatsPerBar,bars};
  });
  return {referenceEpoch:input.referenceEpoch,earliest,deadline,participants};
}

// Each input bar count contributes at most two endpoints. At equal coordinates
// starts precede the coverage check, which precedes ends: intervals are CLOSED.
function witnessAtFactor(model,factor,budget){
  const events=[];
  model.participants.forEach((p,index)=>{
    const slow=max(p.low,p.bpm.div(factor)),fast=min(p.high,p.bpm.mul(factor));
    if(slow.cmp(fast)>0)return;
    for(const bars of p.bars){
      budget.tick();const beats=Q.of(p.beatsPerBar).mul(bars),duration=beats.mul(60);
      const lo=max(model.earliest,p.anchor.add(duration.div(fast)));
      const hi=min(model.deadline,p.anchor.add(duration.div(slow)));
      if(lo.cmp(hi)<=0){
        const interval={index,bars,beats,duration};
        events.push({time:lo,start:true,interval},{time:hi,start:false,interval});
      }
    }
  });
  events.sort((a,b)=>{budget.tick();return a.time.cmp(b.time);});
  const active=model.participants.map(()=>new Map());let covered=0;
  for(let first=0;first<events.length;){
    budget.tick();let end=first+1;
    while(end<events.length&&events[end].time.eq(events[first].time)){budget.tick();end++;}
    for(let j=first;j<end;j++){
      budget.tick();const {start,interval}=events[j];
      if(start){const set=active[interval.index];if(!set.size)covered++;set.set(interval.bars,interval);}
    }
    if(covered===model.participants.length){
      const time=events[first].time;
      const participants=model.participants.map((p,index)=>{
        // Explicit deterministic tie: the fewest admitted bars at this time.
        const bars=Math.min(...active[index].keys()),interval=active[index].get(bars);
        const bridgeBpm=interval.duration.div(time.sub(p.anchor));
        return {id:p.id,anchor:p.anchor.toString(),bars,beats:interval.beats.toString(),
          bridgeBpm:bridgeBpm.toString(),distortion:max(bridgeBpm.div(p.bpm),p.bpm.div(bridgeBpm)).toString()};
      });
      const distortion=participants.reduce((r,p)=>max(r,Q.of(p.distortion)),ONE);
      return {referenceEpoch:model.referenceEpoch,time:time.toString(),distortion:distortion.toString(),participants};
    }
    for(let j=first;j<end;j++){
      budget.tick();const {start,interval}=events[j];
      if(!start){const set=active[interval.index];set.delete(interval.bars);if(!set.size)covered--;}
    }
    first=end;
  }
  return null;
}

const defaultBudget=options=>({operations:250000,milliseconds:1000,...options});
function run(options,body){
  const result=boundedRun(defaultBudget(options),body);
  // Polling is cooperative, so check the helper's final elapsed-budget flag too.
  // No completed mathematical status escapes a resource refusal.
  if(result.budgetExhausted&&!['budget-exhausted-no-witness','arithmetic-budget-exhausted'].includes(result.status))
    return {status:'budget-exhausted-no-witness',reason:'Final elapsed-time check exceeded budget',
      budgetExhausted:true,operations:result.operations,elapsedMs:result.elapsedMs};
  return result;
}

export function decideRendezvous(input,factor,options={}){
  return run(options,budget=>{
    preflight(factor);
    const model=prepare(input,budget),rho=positive(factor,'factor');
    if(rho.cmp(ONE)<0)throw new RangeError('Factor must be at least one');
    const witness=witnessAtFactor(model,rho,budget);
    return {status:witness?'feasible':'infeasible-at-factor',factor:rho.toString(),witness};
  });
}

// No floating logs, square roots or unproved epsilon decisions. The returned
// bracket concerns the global optimum over ALL supplied bar choices.
export function solveRendezvous(input,{iterations=32,...options}={}){
  return run(options,budget=>{
    boundedInt(iterations,'bisections',0,128);
    const model=prepare(input,budget);
    let witness=witnessAtFactor(model,ONE,budget);
    if(witness)return {status:'optimal',lower:'1',upper:'1',lowerInclusive:true,iterations:0,witness};
    // This factor exposes each participant's entire hard tempo interval.
    let high=model.participants.reduce((r,p)=>max(r,max(p.bpm.div(p.low),p.high.div(p.bpm))),ONE);
    witness=witnessAtFactor(model,high,budget);
    if(!witness)return {status:'infeasible',reason:'No common boundary within the supplied window and bar choices'};
    let low=ONE;
    for(let i=0;i<iterations;i++){
      budget.tick();const mid=low.add(high).div(2),candidate=witnessAtFactor(model,mid,budget);
      if(candidate){high=mid;witness=candidate;}else low=mid;
    }
    // The particular rational witness can tighten the feasible upper bound.
    high=Q.of(witness.distortion);
    return {status:'optimality-bracket',lower:low.toString(),upper:high.toString(),lowerInclusive:false,iterations,witness};
  });
}

// Check a supplied witness independently of endpoint enumeration. This proves
// represented-model FEASIBILITY only, never the claimed optimality bracket,
// source identity, clock calibration, consent, or successful delivery.
export function checkRendezvousWitness(input,witness,options={}){
  return run(options,budget=>{
    const model=prepare(input,budget);preflight(witness);
    fields(witness,['referenceEpoch','time','distortion','participants'],'witness');
    if(witness.referenceEpoch!==model.referenceEpoch)throw new Error('Wrong reference epoch');
    const time=readQ(witness.time),rho=positive(witness.distortion,'distortion');
    if(time.cmp(model.earliest)<0||time.cmp(model.deadline)>0)throw new Error('Outside rendezvous window');
    const choices=denseArray(witness.participants,'witness participants',8);
    if(choices.length!==model.participants.length)
      throw new Error('Wrong witness membership');
    let actual=ONE;
    model.participants.forEach((p,index)=>{
      budget.tick();const w=choices[index];
      fields(w,['id','anchor','bars','beats','bridgeBpm','distortion'],'participant witness');
      if(w.id!==p.id||!readQ(w.anchor).eq(p.anchor)||!p.bars.includes(w.bars))throw new Error('Wrong participant choice');
      const beats=Q.of(p.beatsPerBar).mul(w.bars),bpm=positive(w.bridgeBpm,'bridge BPM');
      if(!readQ(w.beats).eq(beats)||bpm.cmp(p.low)<0||bpm.cmp(p.high)>0||time.cmp(p.anchor)<=0||
        !time.sub(p.anchor).mul(bpm).eq(beats.mul(60)))throw new Error('Invalid bridge equality or tempo');
      const distortion=max(bpm.div(p.bpm),p.bpm.div(bpm));
      if(!distortion.eq(readQ(w.distortion)))throw new Error('Wrong participant distortion');
      actual=max(actual,distortion);
    });
    if(!actual.eq(rho))throw new Error('Wrong maximum distortion');
    return {status:'verified-feasible',distortion:actual.toString()};
  });
}
