// Making a character take effect, without rewriting a single bot.
//
// PlexBOT reads `CONFIG.plex` and TuneBOT reads `CONFIG.tune` at the moment they decide --
// not at construction -- so a character can reach them by moving the config under them. That
// is the whole trick, and it is worth being explicit about why it is the right one here:
//
//   * No bot changes. Ninety-seven ports stay exactly as they are, which matters because
//     their behaviour is the archive, not an implementation detail.
//   * It is reversible. `apply` returns a handle that puts every value back, so a character
//     is a state the ensemble can leave as well as enter.
//   * Relative structure survives. PlexBOT's roles differ from each other on purpose --
//     `climax` is more complex than `establish` -- so a character moves the whole set toward
//     its target and keeps the shape rather than flattening every role to one number.
//
// The projections themselves live in ./aesthetic.js. This file only decides where the
// numbers land, and how to undo them.
import {aesthetic, formAesthetic, tuningAesthetic, mixAesthetic, describeAesthetic} from './aesthetic.js';

// How far a character is allowed to pull a per-role table away from its authored value.
// Not 1: the authored tables carry musical judgement that a nine-axis summary does not, and
// a character should colour them rather than replace them.
const ROLE_PULL = 0.65;

const pull = (from, to, amount) => from + (to - from) * amount;
const clamp01 = value => Math.max(0, Math.min(1, value));

// Re-weight a discrete choice table so the options nearest `wanted` are likelier, without
// ever setting a weight to zero -- a character narrows the field, it does not close it.
function weightToward(values, weights, wanted, sharpness = 2.2) {
  const span = Math.max(...values) - Math.min(...values) || 1;
  const shaped = values.map((value, index) => {
    const distance = Math.abs(value - wanted) / span;
    return Math.max(0.02, weights[index] * Math.exp(-sharpness * distance));
  });
  const total = shaped.reduce((sum, value) => sum + value, 0);
  return shaped.map(value => Math.round((value / total) * 1000) / 1000);
}

function snapshot(config) {
  return {
    tune: {...config.tune},
    plex: {
      roleComplexity: {...config.plex.roleComplexity},
      continuity: {...config.plex.continuity},
      sectionPhraseWeights: [...config.plex.sectionPhraseWeights],
      numeratorWeights: [...config.plex.numeratorWeights],
    },
  };
}

/**
 * Point the ensemble at a character.
 *
 * @param vector  nine axes, 0..1; anything missing sits at the middle
 * @param config  the live STOCHASTIC_CONFIG the bots read
 * @param desk    an optional LiveDesk, which takes its own projection
 * @returns a handle carrying what was applied and a `restore()` that undoes it
 */
export function applyCharacter(vector, {config, desk = null} = {}) {
  const value = aesthetic(vector);
  if (!config) throw new TypeError('applyCharacter needs the live config');
  const before = snapshot(config);
  const form = formAesthetic(value), tuning = tuningAesthetic(value), mix = mixAesthetic(value);

  // ---- TuneBOT. Direct: these are the parameter names the tuner already takes, and the
  // projection has already accounted for the fact that three of them are cost weights whose
  // direction is inverted. See ./aesthetic.js.
  Object.assign(config.tune, {
    purity: tuning.purity,
    complexity: tuning.complexity,
    primeSoftness: tuning.primeSoftness,
    oddLimit: tuning.oddLimit,
    continuity: tuning.continuity,
    grounding: tuning.grounding,
  });

  // ---- PlexBOT. Its role tables are relative statements -- climax is more complex than
  // establish -- so each role moves toward the character's target by the same fraction and
  // the ordering between roles survives.
  for (const [role, authored] of Object.entries(before.plex.roleComplexity))
    config.plex.roleComplexity[role] = Math.round(
      clamp01(pull(authored, form.targetComplexity, ROLE_PULL)) * 1000) / 1000;
  for (const [role, authored] of Object.entries(before.plex.continuity))
    config.plex.continuity[role] = Math.round(
      clamp01(pull(authored, 1 - form.changeProbability, ROLE_PULL)) * 1000) / 1000;

  // How long a section runs, and how far a metre may travel from the last one.
  config.plex.sectionPhraseWeights = weightToward(
    config.plex.sectionPhrases, before.plex.sectionPhraseWeights, form.phrasesPerSection);
  // A uniform piece stays near the simple numerators; a varied one is allowed the whole row.
  const homeNumerator = 4 + Math.round(form.targetComplexity * 9);
  config.plex.numeratorWeights = form.numeratorSpread > 0.8
    ? [...before.plex.numeratorWeights]
    : weightToward(config.plex.numerators, before.plex.numeratorWeights, homeNumerator,
      2.2 * (1 - form.numeratorSpread) + 0.4);

  // ---- The desk, if one is running. It owns its own application.
  if (desk?.setAesthetic) desk.setAesthetic(value);

  return {
    vector: value,
    describe: describeAesthetic(value),
    applied: {tuning, form, mix: mix.rules},
    restore() {
      Object.assign(config.tune, before.tune);
      Object.assign(config.plex.roleComplexity, before.plex.roleComplexity);
      Object.assign(config.plex.continuity, before.plex.continuity);
      config.plex.sectionPhraseWeights = before.plex.sectionPhraseWeights;
      config.plex.numeratorWeights = before.plex.numeratorWeights;
      desk?.clearAesthetic?.();
    },
  };
}

// The message that tells the room. Every bot receives it through the framework and projects
// it for itself, so the character is a fact about the ensemble rather than a private setting
// held by whoever happened to issue it.
export function characterMessage(vector, {source = 'lm', reason = ''} = {}) {
  const value = aesthetic(vector);
  return {
    address: '/broadcast/character',
    args: [{
      version: 1, vector: value, describe: describeAesthetic(value),
      source, ...(reason ? {reason} : {}),
    }],
  };
}
