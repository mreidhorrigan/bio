// A hold as the clocks keep it (RESEARCH_BACKLOG "P2 — rubato", holds; 2a's terms, SESSIONS.md 28 September): time
// stopped at one pulse. The pulse sounds when it would have; the next comes after the hold and that pulse's own length,
// as the timing map puts them (timing-map.js: timeAt is the held note's attack, timeAfter the re-entry). Every clock
// keeps it alike: the room's and a render's (client-ensemble.js, render/transport.js), the server's (server.js), and
// the networked conductor's cursor (ensemble-cursor.js).
//
//   /broadcast/hold {id, bar, beat, subdivision, seconds}   a hold of known length
//   /broadcast/hold {id, bar, beat, subdivision, bound, preferred, leadSeconds}
//                                                           a hold its cue ends: within its bound, the re-entry prepared
//                                                           leadSeconds after the cue; at the bound without one, the
//                                                           music goes on there
//   /broadcast/holdRelease {id, inSeconds}                  the cue, taken inSeconds from when it arrives (0: now)
//   /broadcast/holdReady {id, inSeconds}                    a participant needing time before a cued re-entry: ready
//                                                           inSeconds from now. The re-entry waits for the latest who
//                                                           spoke, up to the bound (resumeDecision, waitForReady);
//                                                           silence is no constraint
//   /broadcast/hold {..., band: 'sustain' | 'rest'}          what the band does through it (hold-timing.js): its notes
//                                                           held over it, a fermata's (the default), or silent under a
//                                                           soloist, a cadenza's
//   /broadcast/hold {..., optional: true, branch, decideBeats}  a possible hold (the rubato report's §12.5, prepared
//                                                           branches): held or not as chosen by /broadcast/holdSelect
//                                                           {id, branch: 'hold' | 'continue'} up to decideBeats beats
//                                                           before its pulse (1 unless given), else its default branch
// The clock says what it decided, to everyone alike, so that no participant guesses from a cue it heard late:
//   /broadcast/holdResume {id, inSeconds, decision, reason, revision}  the re-entry, inSeconds from its sending; again,
//                                                           a revision on, if readiness moves it later before its
//                                                           last leadSeconds (after that it is committed)
//   /broadcast/holdSelected {id, branch, chosen}            a possible hold's branch, chosen or its default
// bar, beat and subdivision count from 0, as a clock message does (beat and subdivision 0 unless given). A hold's
// pulse is the first of its bar, beat and subdivision in the meter that bar is in.
//
// A bot can tell a hold from a clock that has stopped: the pulse where a hold begins carries
// held: {begins: {id, seconds, cued, bound, leadSeconds, band}}, and the first after it held: {ends: {id, seconds}}. A
// pad or a singer can sustain through a fermata rather than learn from a silence that something broke.
import {resumeDecision} from './timing-map.js';

export const HOLD_LIMITS=Object.freeze({mostSeconds:600,mostPending:32});
export const BRANCHES=Object.freeze(['hold','continue']);
// What the band does through a hold: its notes held over it, or silent (hold-timing.js).
export const BANDS=Object.freeze(['sustain','rest']);
const EPOCH='clock';
const count=(value,label)=>{const number=value==null?0:Number(value);if(!Number.isSafeInteger(number)||number<0)throw new RangeError(`A hold's ${label} is a whole number from 0`);return number};
const seconds=(value,label)=>{const number=Number(value);if(!Number.isFinite(number)||number<=0||number>HOLD_LIMITS.mostSeconds)throw new RangeError(`A hold's ${label} is a number of seconds above 0, at most ${HOLD_LIMITS.mostSeconds}`);return number};

// A declared hold, as the clocks keep it. A piece that ends at a hold (the timing map's 'end' fallback) is the
// session's end, not a clock's: a clock's cued hold goes on at its bound.
export function normalizeHold(value){
  if(!value||typeof value!=='object')throw new TypeError('A hold is an object: {id, bar, beat, subdivision, seconds} or {..., bound}');
  const id=typeof value.id==='string'?value.id.trim():'';
  if(!/^[A-Za-z0-9_.:\-]{1,128}$/.test(id))throw new RangeError('A hold names its occurrence: an id of letters, digits and _.:-');
  const out={id,bar:count(value.bar,'bar'),beat:count(value.beat,'beat'),subdivision:count(value.subdivision,'subdivision')};
  const lead=value.leadSeconds==null?0:Number(value.leadSeconds);
  if(value.seconds!=null){Object.assign(out,{known:true,seconds:seconds(value.seconds,'length')});out.bound=out.seconds}
  else{
    if(value.fallback!=null&&value.fallback!=='release')throw new RangeError('A clock\'s cued hold goes on at its bound (fallback release): a piece ending at a hold is the session\'s end');
    Object.assign(out,{known:false,bound:seconds(value.bound,'bound'),fallback:'release'});
    out.seconds=value.preferred==null?out.bound:seconds(value.preferred,'preferred length');
    if(out.seconds>out.bound)throw new RangeError('A cued hold\'s preferred length is within its bound');
  }
  if(!(Number.isFinite(lead)&&lead>=0&&lead<=out.bound))throw new RangeError('A re-entry\'s preparation is within its hold\'s bound');
  out.leadSeconds=lead;
  // A fermata's band holds its notes over it; a cadenza's rests under the soloist (cadenza.js says so).
  const band=value.band??'sustain';
  if(!BANDS.includes(band))throw new RangeError(`What the band does through a hold is ${BANDS.join(' or ')}`);
  out.band=band;
  if(value.optional!=null&&typeof value.optional!=='boolean')throw new RangeError('A hold is optional or not (true or false)');
  if(value.optional){
    const branch=value.branch??'continue';
    if(!BRANCHES.includes(branch))throw new RangeError(`A possible hold's default is ${BRANCHES.join(' or ')}`);
    Object.assign(out,{optional:true,branch,decideBeats:count(value.decideBeats??1,'decideBeats'),selected:null});
  }
  return out;
}

// Where a hold's pulse falls in its bar, in the meter that bar is in; null where the bar has no such pulse.
export const holdTick=(hold,meter)=>{const tick=hold.beat*meter.subdivision+hold.subdivision;return hold.subdivision<meter.subdivision&&tick<meter.pulsesPerBar?tick:null};
// Whether a hold's pulse has passed: before the pulse the clock is at (not yet emitted), or no later than the last one
// it emitted. (A page or a render delivers a pulse before it advances: a bot answering it with a hold on that very pulse
// is too late, and is told so rather than kept for a pulse that never comes.)
const before=(hold,bar,tickInBar,meter)=>hold.bar<bar||hold.bar===bar&&(holdTick(hold,meter)??Infinity)<tickInBar;
const passed=(hold,state)=>before(hold,state.bar,state.tickInBar,state.meter)||
  Boolean(state.lastPulse)&&before(hold,state.lastPulse.bar,state.lastPulse.tickInBar+1,state.meter);

// A hold declared to a clock (state: bar, tickInBar, meter, holds). Refused: a pulse already passed or held, an id
// already declared, more than HOLD_LIMITS.mostPending waiting. -> {queued: hold} or {rejected: reason}.
export function queueHold(state,value){
  let hold;try{hold=normalizeHold(value)}catch(error){return {rejected:error.message}}
  const holds=state.holds??=[];
  // (A clock's bar and tickInBar are the pulse it emits next, so that pulse may still be held.)
  if(passed(hold,state))return {rejected:`bar ${hold.bar}, beat ${hold.beat}, subdivision ${hold.subdivision} has passed`};
  if(holds.some(other=>other.id===hold.id)||state.holding?.id===hold.id)return {rejected:`a hold ${hold.id} is already declared`};
  if(holds.some(other=>other.bar===hold.bar&&other.beat===hold.beat&&other.subdivision===hold.subdivision))return {rejected:'that pulse is already held'};
  if(holds.length>=HOLD_LIMITS.mostPending)return {rejected:`at most ${HOLD_LIMITS.mostPending} holds wait at once`};
  holds.push(hold);holds.sort((a,b)=>a.bar-b.bar||a.beat-b.beat||a.subdivision-b.subdivision);
  return {queued:hold};
}

// The pulse a clock is at: the hold it ends (the one begun at the pulse before) and the one it begins, as the clock
// message's `held` field, or null. Read without changing anything (the networked conductor announces the pulse it
// emits from a copy of its cursor).
// (A possible hold begins only on its branch 'hold': the one chosen, else its default, due by its pulse at the latest.)
const branchOf=hold=>hold.optional?hold.selected??hold.branch:'hold';
const beginning=state=>{const next=(state.holds??[]).find(hold=>!passed(hold,state));return next&&next.bar===state.bar&&holdTick(next,state.meter)===state.tickInBar&&branchOf(next)==='hold'?next:null};
export function heldAt(state){
  const ended=state.holding?{id:state.holding.id,seconds:holdLength(state.holding)}:null,begins=beginning(state);
  if(!ended&&!begins)return null;
  return {...(begins?{begins:{id:begins.id,seconds:begins.seconds,cued:!begins.known,...(begins.known?{}:{bound:begins.bound}),leadSeconds:begins.leadSeconds,band:begins.band??'sustain'}}:{}),
    ...(ended?{ends:ended}:{})};
}
// The pulse about to be emitted, at `at` seconds in the clock's own time: the hold it begins is kept as state.holding
// until the next pulse, which ends it. Holds whose pulse has passed unheld (a meter change took it away) are dropped.
// -> the clock message's `held` field, or null.
export function holdAtPulse(state,at){
  // A possible hold's choice falls due: its default where none was chosen.
  for(const hold of [...(state.holds??[])])if(hold.optional&&hold.selected===null&&due(hold,state.bar,state.tickInBar,state.meter))decideBranch(state,hold,hold.branch,false);
  const held=heldAt(state),holds=state.holds??=[];
  state.holding=null;
  while(holds.length&&(passed(holds[0],state)||holds[0].bar===state.bar&&holdTick(holds[0],state.meter)===state.tickInBar&&branchOf(holds[0])!=='hold'))holds.shift();
  if(held?.begins){const begins=holds.shift();state.holding={...begins,startedAt:at,resumeAt:begins.known?at+begins.seconds:null,cueAt:null,ready:{},revision:0}}
  if(held?.ends)state.holdEndedBar=state.bar;
  // Emitted: a hold declared for this pulse from now on is too late (passed).
  state.lastPulse={bar:state.bar,tickInBar:state.tickInBar};
  return held;
}
const holdLength=holding=>(holding.resumeAt??holding.startedAt+holding.bound)-holding.startedAt;

// Following leaves the clock's time alone around a hold (2a's terms): while one is held, and for the rest of the bar
// its re-entry is in, the ensemble resumes at the map's tempo, not at a follower's estimate of the gap; and no
// evidence window reaches past a hold declared ahead of it (holdAhead: a hold at or before that bar).
export const holdQuiet=state=>Boolean(state.holding)||state.holdEndedBar===state.bar;
export const holdAhead=(state,bar)=>Boolean(state.holding)||(state.holds??[]).some(hold=>hold.bar<=bar);
// The hold the last pulse began, while no re-entry is decided: a cued hold waiting for its cue.
export const awaitingCue=state=>Boolean(state.holding&&state.holding.resumeAt===null);
// The seconds between the held pulse and its own length's start, as far as the clock knows at `now`: a known hold's
// length, a cued one's to its re-entry, or to its bound while it waits (the latest it can be). 0 without a hold.
export function holdSeconds(state,now=-Infinity){
  const holding=state.holding;if(!holding)return 0;
  if(holding.resumeAt===null&&now>=holding.startedAt+holding.bound)holding.resumeAt=holding.startedAt+holding.bound;
  return holdLength(holding);
}
// The cue for the hold the clock is in, arriving at `now` (the clock's seconds): its re-entry is the timing map's
// (resumeDecision: leadSeconds after the cue, never past the bound). -> {resumeAt} or {rejected: reason}.
// Whether a possible hold's choice is due at the pulse (bar, tickInBar): its pulse less decideBeats beats, in the
// meter the clock is in.
function due(hold,bar,tickInBar,meter){
  const tick=holdTick(hold,meter);if(tick===null)return hold.bar<=bar;
  const perBar=meter.pulsesPerBar,at=bar*perBar+tickInBar;
  return at>=hold.bar*perBar+tick-hold.decideBeats*meter.subdivision;
}
const announce=(state,address,value)=>(state.holdAnnouncements??=[]).push({address,args:[value]});
// What the clock has decided since it last said so, for it to send (protocol messages from the clock).
export function takeAnnouncements(state){const out=state.holdAnnouncements??[];state.holdAnnouncements=[];return out}
function decideBranch(state,hold,branch,chosen){
  hold.selected=branch;
  if(branch==='continue')state.holds=(state.holds??[]).filter(each=>each!==hold);
  announce(state,'/broadcast/holdSelected',{id:hold.id,branch,chosen});
}
// A possible hold's branch, chosen before it falls due. -> {selected} or {rejected}.
export function selectHold(state,value){
  const id=typeof value?.id==='string'?value.id:'',branch=value?.branch;
  if(!BRANCHES.includes(branch))return {rejected:`a branch is ${BRANCHES.join(' or ')}`};
  const hold=(state.holds??[]).find(each=>each.id===id);
  if(!hold)return {rejected:state.holding?.id===id?`hold ${id} has begun`:`no hold ${id} is declared`};
  if(!hold.optional)return {rejected:`hold ${id} is not a possible one`};
  if(hold.selected!==null)return {rejected:`hold ${id} is decided already (${hold.selected})`};
  if(state.lastPulse&&due(hold,state.lastPulse.bar,state.lastPulse.tickInBar,state.meter))return {rejected:`hold ${id}'s choice was due ${hold.decideBeats} beat(s) before it`};
  decideBranch(state,hold,branch,true);
  return {selected:branch};
}
// The re-entry of the hold the clock is in, from its cue and the readiness said (resumeDecision, waiting for the ready
// up to the bound), announced.
const committed=(holding,now)=>holding.resumeAt!==null&&now>=holding.resumeAt-holding.leadSeconds;
function decideResume(state,holding,now){
  const decision=resumeDecision({hold:{id:holding.id,bound:holding.bound,leadSeconds:holding.leadSeconds,fallback:'release'},startedAt:holding.startedAt,
    now,cue:{epoch:EPOCH,hold:holding.id,at:holding.cueAt},epoch:EPOCH,ready:holding.ready??{},required:Object.keys(holding.ready??{}),waitForReady:true});
  holding.resumeAt=decision.at;holding.cued=decision.decision==='resume'?'cue':'bound';holding.revision=(holding.revision??0)+1;
  announce(state,'/broadcast/holdResume',{id:holding.id,inSeconds:Math.max(0,decision.at-now),decision:decision.decision,reason:decision.reason,revision:holding.revision});
  return decision;
}
// A participant's readiness for the re-entry of the hold the clock is in: `sender`, the instance saying it. Before a
// cue it is kept; after one it may move the re-entry later, up to its commitment. -> {ready, resumeAt?} or {rejected}.
export function readyHold(state,sender,value,now){
  const id=typeof value?.id==='string'?value.id:'',holding=state.holding,delay=value?.inSeconds==null?0:Number(value.inSeconds);
  if(!Number.isFinite(delay)||delay<0||delay>HOLD_LIMITS.mostSeconds)return {rejected:'readiness\'s inSeconds is a number of seconds from 0'};
  if(!holding||holding.id!==id)return {rejected:state.holds?.some(hold=>hold.id===id)?`hold ${id} has not begun`:`no hold ${id} is held`};
  if(holding.known)return {rejected:`hold ${id} has its length already`};
  if(committed(holding,now))return {rejected:`hold ${id}'s re-entry is committed`};
  (holding.ready??={})[String(sender||'a participant')]=now+delay;
  if(holding.cueAt===null||holding.cueAt===undefined)return {ready:now+delay};
  const before=holding.resumeAt;decideResume(state,holding,now);
  return {ready:now+delay,resumeAt:holding.resumeAt,moved:holding.resumeAt!==before};
}
export function releaseHold(state,value,now){
  const id=typeof value?.id==='string'?value.id:'',holding=state.holding;
  const delay=value?.inSeconds==null?0:Number(value.inSeconds);
  if(!Number.isFinite(delay)||delay<0||delay>HOLD_LIMITS.mostSeconds)return {rejected:'a cue\'s inSeconds is a number of seconds from 0'};
  if(!holding||holding.id!==id)return {rejected:state.holds?.some(hold=>hold.id===id)?`hold ${id} has not begun`:`no hold ${id} is held`};
  if(holding.known)return {rejected:`hold ${id} has its length already`};
  if(holding.resumeAt!==null)return {rejected:`hold ${id} is already released`};
  holding.cueAt=now+delay;
  const decision=decideResume(state,holding,now);
  return {resumeAt:decision.at,decision:decision.decision,reason:decision.reason};
}
// A clock that has committed the next pulse's time (a render's timeline, at the end of the held pulse's step) takes a
// cued hold's bound as its re-entry if no cue has come: a later cue is refused, not a timeline rewritten.
export function settleHold(state){
  const holding=state.holding;
  if(awaitingCue(state)){
    holding.resumeAt=holding.startedAt+holding.bound;holding.cued='bound';holding.revision=(holding.revision??0)+1;
    announce(state,'/broadcast/holdResume',{id:holding.id,inSeconds:0,decision:'fallback',reason:'the hold reached its bound',revision:holding.revision});
  }
  return holdSeconds(state);
}
// A cursor's holds as another conductor sends them (ensemble-conductor.js, ensemble-tempo-map.js): each well formed, the
// one in progress within its bound. Throws on one that is not.
const ID=/^[A-Za-z0-9_.:\-]{1,128}$/;
function checkHoldFields(hold){
  const whole=value=>Number.isSafeInteger(value)&&value>=0,length=value=>Number.isFinite(value)&&value>0&&value<=HOLD_LIMITS.mostSeconds;
  if(!hold||typeof hold!=='object'||typeof hold.id!=='string'||!ID.test(hold.id)||!whole(hold.bar)||!whole(hold.beat)||!whole(hold.subdivision)||
    typeof hold.known!=='boolean'||!length(hold.seconds)||!length(hold.bound)||hold.seconds>hold.bound||hold.known&&hold.seconds!==hold.bound||
    !(Number.isFinite(hold.leadSeconds)&&hold.leadSeconds>=0&&hold.leadSeconds<=hold.bound)||hold.band!=null&&!BANDS.includes(hold.band))throw new TypeError('Invalid hold');
}
export function validateCursorHolds(state){
  if(state.holds!=null){
    if(!Array.isArray(state.holds)||state.holds.length>HOLD_LIMITS.mostPending)throw new TypeError('Invalid holds');
    state.holds.forEach(checkHoldFields);
    if(new Set(state.holds.map(hold=>hold.id)).size!==state.holds.length)throw new TypeError('Invalid holds');
  }
  const holding=state.holding;
  if(holding!=null){
    checkHoldFields(holding);
    if(!Number.isFinite(holding.startedAt)||holding.resumeAt!==null&&!(Number.isFinite(holding.resumeAt)&&holding.resumeAt>=holding.startedAt&&holding.resumeAt<=holding.startedAt+holding.bound+1e-9)||
      holding.pulseSeconds!=null&&!(Number.isFinite(holding.pulseSeconds)&&holding.pulseSeconds>0))throw new TypeError('Invalid hold in progress');
  }
}
// A clock's holds as they stand, for its status.
export const holdStatus=state=>({waiting:(state.holds??[]).map(({id,bar,beat,subdivision,known,seconds,bound})=>({id,bar,beat,subdivision,known,seconds,bound})),
  holding:state.holding?{id:state.holding.id,startedAt:state.holding.startedAt,resumeAt:state.holding.resumeAt}:null});
