// Attention among the band (the user, 28 September 2026: "a concept of attention allocation among the band: a variable
// overall attention budget (that will change per style), and individual performers' shares of it, with a solo budgeted
// maximum attention and thus license to do attention-grabbing things like play simultaneously fast and loud").
//
// The currency is measured, not named by instrument: the power of a part's attacks, the energy of its notes' onsets in a
// short window over the window's length, in decibels. Loud claims more; so does fast (twice the notes claim as much as
// 3 dB louder); fast and loud together claim the most, the two added in decibels, as a band's energy adds.
//   - A part's typical claim is what it plays when nothing asks otherwise: its measured density (the casting profile's,
//     notes a quarter) at the section's tempo, at the synth's middling velocity.
//   - The section's budget is the band's typical claims summed, moved by the style (its aesthetic character: spiky
//     attacks and restless motion raise it, a spacious one lowers it) and by the form's tension there.
//   - The shares sum to one. How unequal they are is the section's hierarchy: at 0 each part's share is its typical
//     claim's part of the band's, so everyone plays as it would; toward 1 a soloist's share grows to the most a share may
//     be, and the others' shrink together.
//   - A part's allowance is the budget times its share (in decibels, the budget plus ten times the share's logarithm),
//     with the headroom a part's accents take over its mean. A part over its allowance gives back loudness first (the
//     drummer's give-back: a busy fill lighter than its groove), none where its share covers it: so a soloist may play
//     fast and loud at once, and the band behind it plays lighter.
// Every term is continuous (the user: "everything must be interpolable"): a budget, a hierarchy and shares between any
// two. Not in it yet, and named so: a part's distance from its own register, its timbre's brightness, and its novelty
// against what it just played, each of which a listener's attention follows too (a steady groove claims less than its
// power says, a new figure more).
import {velocityAmplitude} from './articulation.js';

export const ATTENTION=Object.freeze({
  // The window a claim is measured over (s): about a felt beat at an ordinary tempo, short enough that a fast run's
  // burst is its own, long enough to hold several of its notes.
  windowSeconds:.5,
  // A note's level by its velocity (articulation.js: the synth's square law over 30 dB), and the velocity a part's
  // typical claim is taken at (the curve's pivot).
  velocityRangeDb:30,velocityExponent:2,typicalVelocity:.7,
  // A part with no measured density: notes a second by its layer (ours: a line's, a groove's, a pad's).
  unmeasured:Object.freeze({melody:2,beat:6,bass:2,filler:1.5,texture:1,default:1.5}),
  // How far the style and the form move the budget either way (dB), and the headroom a part's accents take over its
  // typical claim (ours, until listening says).
  styleDb:4,formDb:6,headroomDb:3,
  // The largest share a soloist takes, and the least any performer keeps.
  mostShare:.85,leastShare:.02,
});
const clamp=(x,low,high)=>Math.max(low,Math.min(high,x));
const finite=(value,name)=>{if(!Number.isFinite(value))throw new RangeError(`${name} is a number, not ${value}`);return value};
const dB=power=>10*Math.log10(Math.max(1e-12,power));

// A note's attack energy, relative to one at full velocity.
export const noteEnergy=(velocity,{choices=ATTENTION}={})=>velocityAmplitude(clamp(Number(velocity)||0,0,1),choices.velocityRangeDb,choices.velocityExponent)**2;

// What a part's notes claim: the most power of their attacks in any window of `windowSeconds` (dB; 0 is a note a second
// at full velocity), where it was, and the window's rate and mean level. notes: [{at (s), velocity}].
// -> {claimDb, at, rate (notes a second there), levelDb (their mean energy there)} or null where nothing sounds.
export function claimOf(notes,{windowSeconds=ATTENTION.windowSeconds,choices=ATTENTION}={}){
  const list=(notes??[]).filter(note=>Number.isFinite(note?.at)&&Number(note.velocity)>0).map(note=>({at:note.at,energy:noteEnergy(note.velocity,{choices})})).sort((a,b)=>a.at-b.at);
  if(!list.length)return null;
  let best=null,sum=0,j=0;
  for(let i=0;i<list.length;i++){
    sum+=list[i].energy;
    while(list[i].at-list[j].at>=windowSeconds-1e-12){sum-=list[j].energy;j++}
    if(!best||sum>best.sum+1e-15)best={sum,at:list[j].at,count:i-j+1};
  }
  return {claimDb:dB(best.sum/windowSeconds),at:best.at,rate:best.count/windowSeconds,levelDb:dB(best.sum/best.count)};
}

// A part's typical claim (dB) at `quarterBpm`: its measured density (a casting declaration's, notes a quarter; the middle
// of its range), else its layer's notes a second, at the typical velocity.
export function typicalClaimDb(declaration,{quarterBpm=108,choices=ATTENTION}={}){
  const density=Array.isArray(declaration?.density)&&declaration.density.every(Number.isFinite)?(declaration.density[0]+declaration.density[1])/2:null;
  const perSecond=density!=null?density*finite(quarterBpm,'a tempo')/60:choices.unmeasured[declaration?.layer]??choices.unmeasured.default;
  return dB(perSecond*noteEnergy(choices.typicalVelocity,{choices}));
}

// A section's budget (dB): its band's typical claims summed, moved by the style and the form. typical: [dB] each
// performer's; character: an aesthetic character's axes (aesthetic.js, each 0 to 1; a missing one is neutral); tension:
// the form's for the section (0 to 1).
export function attentionBudget({typical=[],character=null,tension=.5,choices=ATTENTION}={}){
  const axis=name=>Number.isFinite(character?.[name])?clamp(character[name],0,1):.5;
  const style=((axis('attack')-.5)+(.5-axis('continuity'))-(axis('space')-.5))*2/3;
  const band=typical.length?dB(typical.reduce((sum,value)=>sum+10**(finite(value,'a typical claim')/10),0)):0;
  return band+choices.styleDb*style+choices.formDb*2*(clamp(finite(tension,'a tension'),0,1)-.5);
}

// The section's shares: performers [{id, typicalDb}], a soloist among them or null, and the hierarchy (0 to 1). At 0
// each share is the part's typical claim's part of the band's; toward 1 the soloist's grows to the most a share may be
// and the others shrink in proportion. -> {id: share}, summing to one, none below the least.
export function attentionShares(performers,{soloist=null,hierarchy=0,choices=ATTENTION}={}){
  const entries=[...new Map((performers??[]).map(entry=>[entry.id,10**(finite(entry.typicalDb,'a typical claim')/10)])).entries()];
  if(!entries.length)return Object.freeze({});
  const total=entries.reduce((sum,[,power])=>sum+power,0),natural=new Map(entries.map(([id,power])=>[id,power/total]));
  const h=clamp(Number(hierarchy)||0,0,1),solo=natural.has(soloist)?soloist:null;
  const shares={};
  if(!solo)for(const [id,share] of natural)shares[id]=share;
  else{
    const from=natural.get(solo),to=Math.max(from,entries.length>1?choices.mostShare:1),soloShare=from+(to-from)*h,rest=1-from;
    for(const [id,share] of natural)shares[id]=id===solo?soloShare:rest>0?share*(1-soloShare)/rest:0;
  }
  // Nobody below the least share, the rest scaled so they still sum to one.
  const floor=Math.min(choices.leastShare,1/entries.length),ids=Object.keys(shares),low=ids.filter(id=>shares[id]<floor),high=ids.filter(id=>shares[id]>=floor);
  const highSum=high.reduce((sum,id)=>sum+shares[id],0),left=1-floor*low.length;
  for(const id of low)shares[id]=floor;
  for(const id of high)shares[id]*=highSum>0?left/highSum:1;
  return Object.freeze(shares);
}

// A solo's course to its climax (0 to 1 over the solo's span): rising from where it starts to its peak late in the solo,
// and falling some way after it, as a soloist builds and releases (ours, until listening says). The drummer's solo and
// the melody's can share it.
export const SOLO_ARC=Object.freeze({start:.25,peak:.8,end:.55});
export function soloArc(progress,{arc=SOLO_ARC}={}){
  const p=clamp(Number(progress)||0,0,1);
  if(p<=arc.peak){const x=p/arc.peak;return arc.start+(1-arc.start)*x*x*(3-2*x)}
  const x=(p-arc.peak)/(1-arc.peak);return 1-(1-arc.end)*x*x*(3-2*x);
}
// How far a part's allowance lets it go beyond its typical claim, from 0 (no more than typical) to 1 (`reachDb` more),
// and how far it is below it (dB, 0 where it is not): the soloist's license and the band's give-back, for a part that
// shapes its playing by one number.
export function licenseReach({allowance,typicalDb,reachDb=6,choices=ATTENTION}){
  const margin=finite(allowance,'an allowance')-choices.headroomDb-finite(typicalDb,'a typical claim');
  return Object.freeze({reach:clamp(margin/reachDb,0,1),belowDb:Math.max(0,-margin)});
}
// A part's allowance (dB): the budget plus ten times its share's logarithm, and the headroom its accents take.
export const allowanceDb=(budgetDb,share,{choices=ATTENTION}={})=>finite(budgetDb,'a budget')+dB(clamp(Number(share)||0,1e-6,1))+choices.headroomDb;

// A passage's license: how far its claim is over the part's allowance (dB; 0 where it fits), given back as loudness.
export function license({claimDb,allowance}){
  const over=Math.max(0,finite(claimDb,'a claim')-finite(allowance,'an allowance'));
  return Object.freeze({fits:over<=1e-9,overDb:over,giveBackDb:over});
}
// The most velocity a part may play at `rate` notes a second within its allowance.
export function loudestAt({allowance,rate,choices=ATTENTION}){
  const energy=10**((finite(allowance,'an allowance')-dB(Math.max(1e-6,finite(rate,'a rate'))))/10);
  if(energy>=1)return 1;
  const p=Math.max(1,choices.velocityExponent),a=10**(-Math.max(1,choices.velocityRangeDb)/(20*p)),amplitude=Math.sqrt(energy);
  return clamp((amplitude**(1/p)-a)/(1-a),0,1);
}
// The most notes a second a part may play at `velocity` within its allowance.
export const quickestAt=({allowance,velocity,choices=ATTENTION})=>10**((finite(allowance,'an allowance')-dB(noteEnergy(velocity,{choices})))/10);
