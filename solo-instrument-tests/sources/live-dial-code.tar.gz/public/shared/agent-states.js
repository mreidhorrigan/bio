// A room's roster as its bots announce themselves on `/broadcast/agentState`, keyed by instance. A bot first announces
// under its definition id, before the room confirms its instance (`/system/instance`); the provisional entry gives way
// to the confirmed one and never replaces it. Shared by the bots that watch who is playing (mh_CoordBOT, ManageBOT).
export function recordAgentState(states,state){
  if(!state?.instanceId)return;
  const provisional=state.instanceId===state.definitionId;
  if(provisional){
    const final=[...states.values()].find(candidate=>
      candidate.definitionId===state.definitionId&&
      candidate.instanceId!==candidate.definitionId
    );
    if(final)return;
  }else if(state.definitionId)states.delete(state.definitionId);
  states.set(state.instanceId,state);
}
