// An ordered chain of inserts, which is the thing a workstation has and this mixer did not.
//
// Until now every processor here was a **parallel send**: the channel fans out to a reverb, a
// delay, a compressor, and the returns sum back. That is one of the two ways a desk is wired
// and it cannot express the other. A send cannot say *distort, then filter the distortion*,
// because the distortion never sees the filter's output and the filter never sees the
// distortion's. Order is the whole content of that instruction, and a send has no order.
//
// So: a chain. A list of processors between one point and another, in an order the caller
// decides and can change while sound is passing through. Three properties follow from doing
// it properly, and all three are things a DAW has:
//
//   * **Arbitrary order.** `[gate, drive, filter]` and `[drive, filter, gate]` are different
//     sounds and both are reachable. Reordering is a method, not a rebuild.
//   * **Repeats.** Two gates at different points in one chain is ordinary — gate, then
//     saturate, then gate again to catch what the saturation lifted. Entries are identified
//     by an id the chain issues, never by kind.
//   * **Mixed kinds.** A Faust worklet, a WAM plugin and a plain Web Audio node sit in one
//     list, because the chain only requires `input` and `output` endpoints.
//
// **Why it owns its own endpoints.** The chain builds `entry` and `exit` gain nodes and
// rewires only between them. The alternative -- rewiring the caller's nodes -- means calling
// `disconnect()` on a node that also feeds the sends, which would silently tear down half the
// mixer every time somebody reordered an insert.
//
// **Bypass keeps its position.** A bypassed entry is skipped in the wiring but stays in the
// list, because the point of bypass is to hear the chain without it and then put it back.

import {driveCurve, driveIsAsymmetric, ramp, widthMatrix} from './mixer-parts.js';
import {createFormantFilter} from './formants.js';

let counter = 0;
const nextId = kind => `${kind}-${++counter}`;

export class InsertChain {
  /**
   * @param context  an AudioContext or OfflineAudioContext
   * @param onChange called after every rewire, with the current list
   */
  constructor(context, {onChange = null} = {}) {
    this.context = context;
    this.entry = context.createGain();
    this.exit = context.createGain();
    this.entries = [];
    this.onChange = onChange;
    this.rebuild();
  }

  /**
   * Add a processor.
   *
   * @param processor {input, output?, name?, kind?, set?, dispose?, parameters?}
   *   `output` defaults to `input`, which is the usual case: one node that is both.
   * @param at  where to put it; appended when omitted. Negative counts from the end.
   */
  add(processor, {at = null, bypass = false} = {}) {
    if (!processor?.input) throw new TypeError('An insert needs an input node');
    const kind = processor.kind || processor.name || 'insert';
    const record = {
      id: processor.id || nextId(kind),
      kind,
      name: processor.name || kind,
      input: processor.input,
      output: processor.output || processor.input,
      set: processor.set || null,
      parameters: processor.parameters || [],
      dispose: processor.dispose || null,
      bypass: Boolean(bypass),
      // The whole processor, for what the chain itself has no use for: a dynamics insert's key.
      processor,
    };
    const index = at === null ? this.entries.length
      : Math.max(0, Math.min(this.entries.length, at < 0 ? this.entries.length + at : at));
    this.entries.splice(index, 0, record);
    this.rebuild();
    return record.id;
  }

  remove(id) {
    const index = this.entries.findIndex(entry => entry.id === id);
    if (index < 0) return false;
    const [record] = this.entries.splice(index, 1);
    this.rebuild();
    // Disposed after rewiring, never before: a node removed from a live graph while it is
    // still connected is a click.
    try { record.output.disconnect() } catch {}
    try { record.input.disconnect() } catch {}
    try { record.dispose?.() } catch {}
    return true;
  }

  move(id, to) {
    const from = this.entries.findIndex(entry => entry.id === id);
    if (from < 0) return false;
    const [record] = this.entries.splice(from, 1);
    const index = Math.max(0, Math.min(this.entries.length, to < 0 ? this.entries.length + to : to));
    this.entries.splice(index, 0, record);
    this.rebuild();
    return true;
  }

  // Reorder by naming the order. Ids left out keep their relative order at the end, so a
  // caller that knows about three of five inserts cannot accidentally drop the other two.
  setOrder(ids) {
    const named = ids.map(id => this.entries.find(entry => entry.id === id)).filter(Boolean);
    const rest = this.entries.filter(entry => !named.includes(entry));
    this.entries = [...named, ...rest];
    this.rebuild();
    return this.list();
  }

  setBypass(id, bypass = true) {
    const record = this.entries.find(entry => entry.id === id);
    if (!record) return false;
    record.bypass = Boolean(bypass);
    this.rebuild();
    return true;
  }

  // Set parameters on one insert, by the id the chain issued. Two instances of the same kind
  // are addressed separately, which is the point of having ids at all.
  setParameters(id, values) {
    const record = this.entries.find(entry => entry.id === id);
    if (!record?.set) return false;
    record.set(values);
    return true;
  }

  get(id) { return this.entries.find(entry => entry.id === id) || null }

  list() {
    return this.entries.map(({id, kind, name, bypass, parameters}, index) =>
      ({id, kind, name, bypass, index, parameters: parameters.length}));
  }

  get length() { return this.entries.length }

  // Disconnect everything this chain owns, then wire entry -> … -> exit through whatever is
  // not bypassed. Rebuilding wholesale rather than splicing is deliberate: the splice cases
  // (first, last, only, bypassed neighbour) are where a graph edit goes wrong, and there is
  // nothing to gain from being clever with a list this short.
  rebuild() {
    try { this.entry.disconnect() } catch {}
    for (const record of this.entries) { try { record.output.disconnect() } catch {} }
    let previous = this.entry;
    for (const record of this.entries) {
      if (record.bypass) continue;
      previous.connect(record.input);
      previous = record.output;
    }
    previous.connect(this.exit);
    this.onChange?.(this.list());
    return this;
  }

  // Take the chain apart. The entry and exit nodes stay, because the caller is connected to
  // them and a chain that is empty is still a chain.
  clear() {
    const records = [...this.entries];
    this.entries = [];
    this.rebuild();
    for (const record of records) {
      try { record.output.disconnect() } catch {}
      try { record.input.disconnect() } catch {}
      try { record.dispose?.() } catch {}
    }
    return this;
  }
}

// ---------------------------------------------------------------------------
// Everything that can go in a chain, behind one call.
//
// A caller asking for a gate should not have to know that a gate is a Faust worklet while a
// drive is three Web Audio nodes and a plugin is a WAM. The offline renderer especially
// should not: one shape is the whole point of building the four missing processors with the
// compiler that already built the other three.

export const INSERT_KINDS = Object.freeze({
  gate: {faust: 'gate', name: 'Noise gate'},
  bitcrusher: {faust: 'bitcrusher', name: 'Bitcrusher'},
  transient: {faust: 'transient', name: 'Transient shaper'},
  multiband: {faust: 'multiband', name: 'Multiband compressor'},
  compressor: {faust: 'compressor', name: 'Compressor'},
  filter: {faust: 'moogladder', name: 'Moog filter'},
  reverb: {faust: 'fdnreverb', name: 'FDN reverb'},
  drive: {native: true, name: 'Drive'},
  chorus: {native: true, name: 'Chorus'},
  gain: {native: true, name: 'Gain'},
  // The channel strip a desk has, which the chain lacked: an EQ, dynamics that can be keyed by
  // another channel, and stereo width.
  eq: {native: true, name: 'Channel EQ'},
  dynamics: {worklet: true, name: 'Dynamics'},
  // A producer's edits from the recent past -- a stutter, a rewind, a tape stop -- scheduled to the frame (edits.js).
  edits: {worklet: 'edits', name: 'Edits'},
  width: {native: true, name: 'Stereo width'},
  // A voice's formants over a sound, moved from vowel to vowel (formants.js).
  formant: {native: true, name: 'Formant filter'},
  wam: {plugin: true, name: 'WAM plugin'},
});
export const INSERT_KIND_NAMES = Object.freeze(Object.keys(INSERT_KINDS));

// Shared with the mixer's own drive send -- one curve, so the insert and the send are the
// same effect in two places rather than two effects that resemble each other.
// The tanh drive's gain on a quiet signal: its input gain, 1 + 6 amount, times its curve's slope at the centre (the
// curve is tanh(k x) / tanh(k), k = 40 amount, so the slope is k / tanh(k)). What a caller takes back after it to leave a
// quiet part as loud as it was (shared/effects-routing.js).
export function driveSmallSignalGain(amount) {
  const a = Math.max(0, Math.min(1, Number(amount) || 0)), k = a * 40;
  return (1 + a * 6) * (k < 1e-6 ? 1 : k / Math.tanh(k));
}
export function saturationCurve(amount, samples = 2048) {
  const curve = new Float32Array(samples), k = Math.max(0, Math.min(1, amount)) * 40, normalization = Math.tanh(k);
  for (let index = 0; index < samples; index++) {
    const x = (index * 2) / (samples - 1) - 1;
    curve[index] = k < 1e-6 ? x : Math.tanh(k * x) / normalization;
  }
  return curve;
}

// ---- the channel EQ ------------------------------------------------------------------------
// A desk's: a high-pass, a low shelf, three peaks, a high shelf and a low-pass. Every band is a
// ramped parameter, and off is exact -- a band at 0 dB is the identity, and a pass filter that was
// never switched on is a peaking band at 0 dB rather than a filter at the edge of hearing. Once
// on, switching it off sweeps it to the edge (10 Hz, or near Nyquist) instead of snapping the
// filter's type while sound passes through it.
export const EQ_BANDS = Object.freeze(['highpass', 'lowShelf', 'low', 'mid', 'high', 'highShelf', 'lowpass']);
export const CHANNEL_EQ = Object.freeze({
  highpass: {hz: 0, slope: 12}, lowShelf: {hz: 120, gainDb: 0}, low: {hz: 250, gainDb: 0, q: 1},
  mid: {hz: 1000, gainDb: 0, q: 1}, high: {hz: 4000, gainDb: 0, q: 1}, highShelf: {hz: 8000, gainDb: 0}, lowpass: {hz: 0, slope: 12},
});
const BUTTERWORTH = {12: [Math.SQRT1_2], 24: [0.5411961, 1.3065630]};
function channelEq(context, options = {}) {
  const top = context.sampleRate * 0.45, edge = band => band === 'highpass' ? 10 : top;
  const filters = {}, state = {};
  const input = context.createGain();
  let previous = input;
  const connect = node => {previous.connect(node); previous = node; return node};
  for (const band of EQ_BANDS) {
    state[band] = {...CHANNEL_EQ[band], on: false};
    if (band === 'highpass' || band === 'lowpass') {
      filters[band] = [0, 1].map(() => {
        const filter = context.createBiquadFilter(); filter.type = 'peaking'; filter.gain.value = 0; return connect(filter);
      });
    } else {
      const filter = context.createBiquadFilter();
      filter.type = band === 'lowShelf' ? 'lowshelf' : band === 'highShelf' ? 'highshelf' : 'peaking';
      filter.frequency.value = CHANNEL_EQ[band].hz; filter.gain.value = 0;
      if (filter.type === 'peaking') filter.Q.value = CHANNEL_EQ[band].q;
      filters[band] = [connect(filter)];
    }
  }
  const set = (values = {}, {atSeconds = context.currentTime, seconds = 0.05} = {}) => {
    for (const band of EQ_BANDS) {
      const wanted = values[band];
      if (!wanted) continue;
      const current = state[band];
      if (band === 'highpass' || band === 'lowpass') {
        const hz = Number(wanted.hz ?? current.hz), slope = Number(wanted.slope ?? current.slope) >= 24 ? 24 : 12;
        const qs = BUTTERWORTH[slope], on = hz > 0;
        filters[band].forEach((filter, index) => {
          const active = on && index < qs.length;
          if (active && filter.type === 'peaking') {filter.type = band; filter.frequency.setValueAtTime(edge(band), atSeconds)}
          if (filter.type !== 'peaking') {
            filter.Q.setValueAtTime(active ? qs[index] : Math.SQRT1_2, atSeconds);
            ramp(filter.frequency, active ? Math.max(10, Math.min(top, hz)) : edge(band), atSeconds, seconds);
          }
        });
        state[band] = {...current, hz: on ? hz : 0, slope, on};
        continue;
      }
      const [filter] = filters[band];
      if (wanted.hz !== undefined) ramp(filter.frequency, Math.max(10, Math.min(top, Number(wanted.hz))), atSeconds, seconds);
      if (wanted.gainDb !== undefined) ramp(filter.gain, Math.max(-24, Math.min(24, Number(wanted.gainDb))), atSeconds, seconds);
      if (wanted.q !== undefined && filter.type === 'peaking') ramp(filter.Q, Math.max(0.1, Math.min(18, Number(wanted.q))), atSeconds, seconds);
      state[band] = {...current, ...Object.fromEntries(Object.entries(wanted).map(([key, value]) => [key, Number(value)]))};
    }
    return settings();
  };
  const settings = () => Object.fromEntries(EQ_BANDS.map(band => [band, {...state[band]}]));
  set(options, {seconds: 0});
  return {input, output: previous, kind: 'eq', name: 'Channel EQ', set, settings,
    parameters: EQ_BANDS.map(address => ({address, ...CHANNEL_EQ[address]})),
    dispose() {for (const list of Object.values(filters)) for (const filter of list) {try {filter.disconnect()} catch {}}
      try {input.disconnect()} catch {}}};
}

function nativeInsert(context, kind, options = {}) {
  if (kind === 'gain') {
    const node = context.createGain();
    node.gain.value = Number(options.gain ?? 1);
    return {input: node, output: node, kind, name: 'Gain',
      set: values => { if (values?.gain !== undefined) node.gain.value = Number(values.gain) }};
  }
  if (kind === 'drive') {
    const input = context.createGain(), shaper = context.createWaveShaper();
    const tone = context.createBiquadFilter(), dc = context.createBiquadFilter();
    shaper.oversample = '4x';
    tone.type = 'lowpass';
    tone.frequency.value = Number(options.tone ?? 5200);
    // A type other than the tanh (mixer-parts.js DRIVE_TYPES); an asymmetric one leaves a DC
    // offset that the highpass after it takes out.
    let type = options.type ?? 'tanh', amount = Number(options.amount ?? 0.4);
    const curve = () => type === 'tanh' || type === 0 ? saturationCurve(amount) : driveCurve(type, amount);
    dc.type = 'highpass'; dc.frequency.value = 5; dc.Q.value = Math.SQRT1_2;
    shaper.curve = curve();
    input.gain.value = 1 + amount * 6;
    input.connect(shaper);
    // Spliced in only once a type needs it, so a tanh drive is exactly the drive it always was.
    let blocking = false;
    const route = () => {
      if (blocking || !driveIsAsymmetric(type)) return;
      try {shaper.disconnect(tone)} catch {}
      shaper.connect(dc).connect(tone); blocking = true;
    };
    if (driveIsAsymmetric(type)) route(); else shaper.connect(tone);
    return {input, output: tone, kind, name: 'Drive',
      set: values => {
        if (values?.type !== undefined) {type = values.type; route()}
        if (values?.amount !== undefined) {amount = Number(values.amount); input.gain.value = 1 + amount * 6}
        if (values?.type !== undefined || values?.amount !== undefined) shaper.curve = curve();
        if (values?.tone !== undefined) tone.frequency.value = Number(values.tone);
      }};
  }
  if (kind === 'eq') return channelEq(context, options);
  if (kind === 'formant') return createFormantFilter(context, options);
  if (kind === 'width') {
    const width = widthMatrix(context, options.width ?? 1);
    return {...width, set: values => {if (values?.width !== undefined) width.set(values.width, context.currentTime, values.seconds ?? 0.05)}};
  }
  if (kind === 'chorus') {
    const input = context.createGain(), delay = context.createDelay(0.06);
    const lfo = context.createOscillator(), depth = context.createGain();
    const output = context.createGain();
    lfo.type = 'sine';
    lfo.frequency.value = Number(options.rateHz ?? 0.6);
    depth.gain.value = Number(options.depthMs ?? 3.2) / 1000;
    delay.delayTime.value = Number(options.delayMs ?? 14) / 1000;
    lfo.connect(depth).connect(delay.delayTime);
    input.connect(delay).connect(output);
    try { lfo.start() } catch {}
    return {input, output, kind, name: 'Chorus',
      dispose: () => { try { lfo.stop() } catch {} },
      set: values => {
        if (values?.rateHz !== undefined) lfo.frequency.value = Number(values.rateHz);
        if (values?.depthMs !== undefined) depth.gain.value = Number(values.depthMs) / 1000;
        if (values?.delayMs !== undefined) delay.delayTime.value = Number(values.delayMs) / 1000;
      }};
  }
  throw new Error(`No native insert called ${kind}`);
}

/**
 * Build one insert. Async because a Faust worklet and a WAM both have to be fetched.
 *
 * @param kind  a key of INSERT_KINDS
 * @param options  passed to the processor; `url` for a WAM, parameter values for the rest
 */
export async function createInsert(context, kind, options = {}) {
  const spec = INSERT_KINDS[kind];
  if (!spec) throw new Error(`No insert called ${kind}. Known: ${INSERT_KIND_NAMES.join(', ')}`);
  if (spec.native) return nativeInsert(context, kind, options);
  if (spec.worklet === 'edits') {
    const {createEdits} = await import('./edits.js');
    return createEdits(context, options);
  }
  if (spec.worklet) {
    const {createDynamics} = await import('./dynamics.js');
    const dynamics = await createDynamics(context, options);
    return {...dynamics, kind};
  }
  if (spec.plugin) {
    const {createEffectPlugin} = await import('./effect-plugins.js');
    const plugin = await createEffectPlugin(context, options);
    return {input: plugin.input, output: plugin.input, kind, name: plugin.name,
      parameters: [], dispose: () => plugin.disconnect(),
      set: values => plugin.setParameters(values)};
  }
  const {loadFaustEffect} = await import('../experiments/faust/faust-node.js');
  const loaded = await loadFaustEffect(context, spec.faust, {base: options.base ?? ''});
  // Faust addresses its parameters by path (`/gate/threshold`). A caller naming the bare
  // parameter is answered too, because requiring the path leaks the program's own name into
  // every call site.
  const address = name => (String(name).startsWith('/') ? name : `/${spec.faust}/${name}`);
  return {
    input: loaded.node, output: loaded.node, kind, name: spec.name,
    parameters: loaded.parameters,
    dispose: () => loaded.dispose(),
    set: values => loaded.set(Object.fromEntries(
      Object.entries(values || {}).map(([name, value]) => [address(name), Number(value)]))),
  };
}
