// BufferedClock's timeFor() contract, answered from the transport's tick map. It ignores `now`
// and never re-anchors, so tempo curves and render-quantum jitter cannot move events off the grid.
export class TimelineClock {
  constructor({transport,lookahead=transport?.lookahead??0.25}={}){
    if(typeof transport?.secondsAtTick!=='function')throw new TypeError('TimelineClock needs an OfflineTransport');
    this.transport=transport;this.lookahead=lookahead;
  }
  reset(){}
  // Ticks the transport has not reached yet extrapolate from the latest known tick at the given tempo.
  timeFor(tick,bpm,now,subdivision=4){
    const transport=this.transport,anchor=Math.max(0,Math.min(Math.floor(Number(tick))||0,transport.latestTick)),seconds=transport.secondsAtTick(anchor);
    return(tick===anchor?seconds:seconds+(tick-anchor)*60/bpm/subdivision)+this.lookahead;
  }
}
