import {AudioEngine} from '../audio.js';
import {mixSettings} from '../shared/sound-settings.js';
import {registerRenderEngine} from './engines.js';
import {TimelineClock} from './timeline-clock.js';
import {bandTempo} from '../shared/opening-time.js';

// 'score' engine: bots run exactly as in an audio render, but no audio exists. Voices end at a capturing
// dspNode (HeadlessBot's onNote reports them), and the context and mixer are inert stand-ins that accept
// every call AudioEngine, EnsembleMixer users and HeadlessBot make. A bot whose sound is audio it renders and places
// itself (its definition's placedNotes: a singer's phrases) plays its samples output here with none of that audio
// made: told so by its audio's notesOnly, it reports each note as it places it (reportRenderedNote), as it does where
// the audio is made.
export const SCORE_CAPABILITIES=Object.freeze({audio:false,samples:false,stems:false,effects:false,outputs:Object.freeze(['synth']),placedNotes:true});

const PARAM_METHODS=['setValueAtTime','linearRampToValueAtTime','exponentialRampToValueAtTime','setTargetAtTime','setValueCurveAtTime','cancelScheduledValues','cancelAndHoldAtTime'];
export function scoreParam(value=0){
  const param={value,defaultValue:value,minValue:-3.4028234663852886e38,maxValue:3.4028234663852886e38};
  for(const method of PARAM_METHODS)param[method]=()=>param;
  return param;
}

// Nodes keep plain settable fields and AudioParam-shaped params; connect() returns its target so chains read as live.
class ScoreNode {
  constructor(context,params={},fields={}){
    Object.assign(this,{context,numberOfInputs:1,numberOfOutputs:1,channelCount:2,channelCountMode:'max',channelInterpretation:'speakers'},fields);
    for(const [name,value] of Object.entries(params))this[name]=scoreParam(value);
  }
  connect(destination){return destination}
  disconnect(){}
}
// Sources never end: nothing is rendered, so there is no end to reach.
class ScoreSource extends ScoreNode {
  constructor(context,params,fields){super(context,params,{numberOfInputs:0,onended:null,...fields})}
  start(){}
  stop(){}
  addEventListener(){}
  removeEventListener(){}
}
class ScoreAnalyser extends ScoreNode {
  constructor(context){super(context,{},{fftSize:2048,smoothingTimeConstant:.8,minDecibels:-100,maxDecibels:-30})}
  get frequencyBinCount(){return this.fftSize/2}
  getFloatTimeDomainData(array){array.fill(0)}
  getByteTimeDomainData(array){array.fill(128)}
  getFloatFrequencyData(array){array.fill(-Infinity)}
  getByteFrequencyData(array){array.fill(0)}
}

export class ScoreContext {
  constructor({sampleRate=48000}={}){
    if(!(sampleRate>0))throw new TypeError('ScoreContext needs a positive sampleRate');
    Object.assign(this,{sampleRate,currentTime:0,state:'running',baseLatency:0,outputLatency:0});
    this.destination=new ScoreNode(this,{},{numberOfOutputs:0,maxChannelCount:2});
  }
  setTime(seconds){
    const time=Number(seconds);if(!Number.isFinite(time))throw new TypeError(`setTime() needs finite seconds, not ${seconds}`);
    this.currentTime=time;
  }
  createGain(){return new ScoreNode(this,{gain:1})}
  createBiquadFilter(){return new ScoreNode(this,{frequency:350,detune:0,Q:1,gain:0},{type:'lowpass'})}
  createDynamicsCompressor(){return new ScoreNode(this,{threshold:-24,knee:30,ratio:12,attack:.003,release:.25},{reduction:0})}
  createAnalyser(){return new ScoreAnalyser(this)}
  createStereoPanner(){return new ScoreNode(this,{pan:0})}
  createDelay(maxDelayTime=1){return new ScoreNode(this,{delayTime:0},{maxDelayTime})}
  createWaveShaper(){return new ScoreNode(this,{},{curve:null,oversample:'none'})}
  createConvolver(){return new ScoreNode(this,{},{buffer:null,normalize:true})}
  createChannelSplitter(outputs=6){return new ScoreNode(this,{},{numberOfOutputs:outputs})}
  createChannelMerger(inputs=6){return new ScoreNode(this,{},{numberOfInputs:inputs})}
  createOscillator(){return new ScoreSource(this,{frequency:440,detune:0},{type:'sine',setPeriodicWave(){}})}
  createBufferSource(){return new ScoreSource(this,{playbackRate:1,detune:0},{buffer:null,loop:false,loopStart:0,loopEnd:0})}
  createConstantSource(){return new ScoreSource(this,{offset:1})}
  createPeriodicWave(){return {}}
  createBuffer(channels,length,sampleRate=this.sampleRate){
    const data=Array.from({length:channels},()=>new Float32Array(length));
    return {numberOfChannels:channels,length,sampleRate,duration:length/sampleRate,getChannelData:index=>data[index],
      copyFromChannel(target,index,offset=0){target.set(data[index].subarray(offset,offset+target.length))},
      copyToChannel(source,index,offset=0){data[index].set(source,offset)}};
  }
  resume(){return Promise.resolve()}
  suspend(){return Promise.resolve()}
  close(){this.state='closed';return Promise.resolve()}
}

// EnsembleMixer's surface without audio: track(id) with input/pan/dry/sends and set(), plus the mixer-level calls.
export class ScoreMixer {
  constructor(context,{bpm=bandTempo()}={}){
    Object.assign(this,{context,bpm,tracks:new Map,settings:{}});
    this.output=context.createGain();
    for(const name of ['reverb','delay','compression','plugin'])this[`${name}Input`]=context.createGain();
  }
  track(id,settings={}){
    if(this.tracks.has(id))return this.tracks.get(id);
    const context=this.context,sends=Object.fromEntries(['reverb','delay','compression','plugin'].map(name=>[name,context.createGain()]));
    const track={id,input:context.createGain(),pan:context.createStereoPanner(),dry:context.createGain(),sends,settings:mixSettings(settings),
      set:(values={})=>{track.settings=mixSettings({...track.settings,...values});return {...track.settings}},
      disconnect:()=>{this.tracks.delete(id)}};
    this.tracks.set(id,track);
    return track;
  }
  setMix(id,values={}){return this.tracks.get(id)?.set(values)}
  setTempo(bpm){this.bpm=Math.max(30,Math.min(300,Number(bpm)||bandTempo()))}
  setEffects(values={}){this.settings={...this.settings,...values};return {...this.settings}}
  snapshot(){return {settings:{...this.settings},tracks:Object.fromEntries([...this.tracks].map(([id,track])=>[id,{...track.settings}]))}}
  dispose(){this.tracks.clear()}
}

// The dspNode contract of wasm-dsp.js createDspNode. Voices are counted and handed to onEvents; nothing sounds.
// admit() captures through the same private path as schedule(), so a wrapper on schedule never sees a voice twice.
export function scoreDspNode({context,onEvents}={}){
  let released=false,generation=0,events=0;
  const listeners=new Set,capture=list=>{if(released||!Array.isArray(list))return;events+=list.length;onEvents?.(list)};
  return {
    backend:'score',
    capabilities:{liveControls:true,admissionAck:true,executionFrameAck:false},
    get generation(){return generation},
    get events(){return events},
    get released(){return released},
    connect:destination=>destination,
    schedule(list){capture(list)},
    async admit(list){
      if(released)throw new Error('Renderer has been released');
      capture(list);
      return {ok:true,accepted:(list||[]).map(event=>event?.actionId).filter(Boolean),duplicates:[],generation,atContextSeconds:context?.currentTime??0,executionBoundary:'score'};
    },
    onExecution(listener){listeners.add(listener);return ()=>listeners.delete(listener)},
    silence(){generation++},
    disconnect(){if(released)return;released=true;listeners.clear();generation++},
  };
}

// A started AudioEngine on a score context, clocked by the transport. The session also uses this for bots rendered with
// output "none", so their decisions match an audible render.
export async function createScoreAudio({context,soundSeed,transport,synthesizer,synthOptions,onEvents}={}){
  if(!context)throw new TypeError('createScoreAudio needs a score context');
  const audio=new AudioEngine({context,seed:soundSeed,synthesizer,synthOptions,device:'unbounded',dspFactory:target=>scoreDspNode({context:target,onEvents})});
  if(transport)audio.clock=new TimelineClock({transport});
  await audio.startOffline();
  return audio;
}

export async function createScoreEngine({spec,sink=null,environment={}}={}){
  const context=new ScoreContext({sampleRate:spec?.sampleRate??48000}),mixer=new ScoreMixer(context,{bpm:spec?.transport?.bpm??bandTempo()});
  const clips=[],captured=environment?.captureEvents?[]:null;
  return {
    name:'score',capabilities:SCORE_CAPABILITIES,context,mixer,sink,clips,captured,
    async createAudio({botSpec={},soundSeed,transport,trackId,definition=null,onNote}={}){
      const output=botSpec.output??'synth';
      // As the engine contract has it for message-only bots; a session gives "none" bots its own silent audio.
      if(output==='none')return null;
      const placed=output==='samples'&&definition?.placedNotes===true;
      if(output!=='synth'&&!placed)throw new Error(`The score engine renders "synth" bots only, and the notes of a bot that places its own, not "${output}" (use output "none" for decisions only)`);
      const onEvents=captured?list=>{for(const event of list)captured.push({trackId,event})}:undefined;
      const audio=await createScoreAudio({context,soundSeed,transport,synthesizer:botSpec.synthesizer,synthOptions:botSpec.synthOptions,onEvents});
      if(placed){audio.notesOnly=true;audio.reportRenderedNote=event=>onNote?.(event)}
      return audio;
    },
    async placeClip(clip,{renderSeconds,fileSeconds,frame}={}){clips.push({id:clip?.id,renderSeconds,fileSeconds,frame})},
    setTime(renderSeconds){context.setTime(renderSeconds)},
    async renderUntil(renderSeconds){context.setTime(renderSeconds)},
    async finish(){},
    async dispose(){mixer.dispose();await context.close()},
  };
}

registerRenderEngine('score',createScoreEngine,{capabilities:SCORE_CAPABILITIES,description:'decisions and notes only, no audio: the fastest way to test bots'});
