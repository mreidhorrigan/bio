import {createRandomStream} from '../random-source.js';
import {createCueScheduler} from './hearing.js';
import {describePosition} from './spec.js';

// Bookkeeping for RenderSession: when bots join and leave, where clips land, and which hearing adapters still listen.
export const LOOKAHEAD=.25;
const EPSILON=1e-9,botLabel=({index,spec},field)=>`bots[${index}] "${spec.id}" ${field}`;

// Preroll is trimmed in whole frames (outputs.js trimPreroll), so a file time maps to render frames the same way.
export const prerollFrames=(sampleRate,lookahead=LOOKAHEAD)=>Math.round(lookahead*sampleRate);
export const renderFrame=(fileSeconds,sampleRate,lookahead=LOOKAHEAD)=>prerollFrames(sampleRate,lookahead)+Math.round(fileSeconds*sampleRate);

// Seconds a clip sounds: durationSeconds, cut short by the end of its file after offsetSeconds. null when neither is known.
export function clipAudibleSeconds(clip,decoded){
  const frames=decoded?.channels?.[0]?.length,available=Number.isFinite(frames)&&decoded.sampleRate>0?Math.max(0,frames/decoded.sampleRate-(clip.offsetSeconds||0)):Infinity;
  const seconds=Math.min(clip.durationSeconds??Infinity,available);
  return Number.isFinite(seconds)?seconds:null;
}

// PCM for a spec clip {generate: {type, seconds, frequency, channels}} at -6 dBFS; noise is seeded, so renders repeat.
export function generateClipAudio({type,seconds,frequency=440,channels=2}={},sampleRate,{seed=0}={}){
  if(!(sampleRate>0)||!(seconds>0)||!Number.isInteger(channels)||channels<1)throw new RangeError('A generated clip needs a sample rate, positive seconds and a channel count');
  const frames=Math.round(seconds*sampleRate),data=Array.from({length:channels},()=>new Float32Array(frames));
  if(type==='sine'){
    const step=2*Math.PI*frequency/sampleRate;
    for(let i=0;i<frames;i++){const value=.5*Math.sin(step*i);for(const channel of data)channel[i]=value}
  }else if(type==='noise'){
    const stream=createRandomStream(`${seed}:clip-noise`);
    for(let i=0;i<frames;i++)for(const channel of data)channel[i]=stream.next()-.5;
  }else if(type!=='silence')throw new RangeError(`Unknown generated clip type "${type}"`);
  return {sampleRate,channels:data,frames};
}

// A beat past the end of its bar only fails once that bar's meter is known, mid-render; label names the spec entry.
function locate(transport,position,label){
  try{return transport.resolvePosition(position)}
  catch(error){if(!label)throw error;throw new RangeError(`${label} at ${describePosition(position)}: ${error.message}`,{cause:error})}
}
// Joins and leaves act at the first step at or after their position: a step is the only place a bot can enter or go.
export function reachedAt(transport,position,tick,label){
  const resolved=locate(transport,position,label);
  return resolved&&(resolved.tick<tick||resolved.tick===tick&&resolved.fraction<EPSILON)?resolved:null;
}
// A clip starts in the step whose window [musicSeconds[k], musicSeconds[k+1]) holds its position. Asked after endStep(),
// when that window is exact.
export function startsIn(transport,position,tick,label){
  const resolved=locate(transport,position,label);
  return resolved&&resolved.tick<=tick?resolved:null;
}

export class RenderTimeline {
  constructor({spec,transport,lookahead=transport?.lookahead??LOOKAHEAD}={}){
    if(typeof transport?.resolvePosition!=='function')throw new TypeError('RenderTimeline needs an OfflineTransport');
    Object.assign(this,{spec,transport,lookahead,sampleRate:spec.sampleRate});
    // waiting → joining → joined → left; skipped when it would leave before joining, failed when start() rejected.
    this.bots=spec.bots.map((bot,index)=>({index,spec:bot,state:'waiting',host:null,audio:null}));
    // clip is the object engines and adapters see: the spec clip plus placement {fileSeconds, renderSeconds} once placed.
    this.clips=spec.clips.map((clip,index)=>({index,id:clip.id,spec:clip,clip:{...clip,placement:null},decoded:null,audibleSeconds:clipAudibleSeconds(clip,null),placement:null,endFileSeconds:null,adapters:[]}));
    this.cues=spec.cues.length?createCueScheduler(spec.cues,transport,{label:'cue'}):null;
  }
  setDecoded(entry,decoded){entry.decoded=decoded;entry.audibleSeconds=clipAudibleSeconds(entry.spec,decoded)}
  setAdapters(entry,adapters){entry.adapters=adapters.map(({name,adapter})=>({name,adapter,retired:false}))}
  // A bot that listens first ({when: 'following'}) is due when readyToEnter(tick, join) says so (the render session
  // knows the conductor's beat), or at its latest position.
  dueJoins(tick){
    return this.bots.filter(entry=>{
      if(entry.state!=='waiting')return false;
      const join=entry.spec.join;
      const due=join.when==='following'?Boolean(this.readyToEnter?.(tick,join,entry))||Boolean(join.latest&&reachedAt(this.transport,join.latest,tick,botLabel(entry,'join.latest'))):
        reachedAt(this.transport,join,tick,botLabel(entry,'join'));
      if(!due)return false;
      if(entry.spec.leave&&reachedAt(this.transport,entry.spec.leave,tick,botLabel(entry,'leave'))){entry.state='skipped';return false}
      return true;
    });
  }
  dueLeaves(tick){return this.bots.filter(entry=>entry.state==='joined'&&entry.spec.leave&&reachedAt(this.transport,entry.spec.leave,tick,botLabel(entry,'leave')))}
  // Clips starting in this step, in time order (spec order breaks ties).
  dueClips(tick){
    const due=[];
    for(const entry of this.clips)if(!entry.placement){const resolved=startsIn(this.transport,entry.spec.at,tick,`clips[${entry.index}] "${entry.id}"`);if(resolved)due.push({entry,resolved})}
    return due.sort((a,b)=>a.resolved.musicSeconds-b.resolved.musicSeconds||a.entry.index-b.entry.index);
  }
  place(entry,resolved,tick){
    const fileSeconds=resolved.musicSeconds,renderSeconds=fileSeconds+this.lookahead;
    entry.placement={tick,fraction:resolved.fraction,fileSeconds,renderSeconds,frame:renderFrame(fileSeconds,this.sampleRate,this.lookahead)};
    entry.clip.placement={fileSeconds,renderSeconds};
    entry.endFileSeconds=entry.audibleSeconds==null?null:fileSeconds+entry.audibleSeconds;
    return entry.placement;
  }
  // Global cues, then every clip's adapters in spec and hear order; send(message, via) runs as each one is produced.
  hear(context,send){
    if(this.cues){for(const message of this.cues.onTick(context))send(message,'cue');if(!this.cues.pending.length)this.cues=null}
    for(const entry of this.clips)for(const item of entry.adapters){
      if(item.retired)continue;
      for(const message of item.adapter.onTick(context)||[])send(message,`clip:${entry.id}:${item.name}`);
      item.retired=this.finished(entry,item.adapter,context);
    }
  }
  // Adapters listen from the start (they gate themselves on placement). A cue list retires when it is empty; a
  // listening adapter after the first beat at or past the clip's end, so bots hear it fall silent.
  finished(entry,adapter,{musicSeconds,clock}){
    if(adapter.done===true)return true;
    const pending=adapter.pending;
    if(Array.isArray(pending))return !pending.length&&!('endSeconds' in adapter);
    return entry.endFileSeconds!=null&&musicSeconds>=entry.endFileSeconds-EPSILON&&clock?.beatStart!==false;
  }
  warnings(){
    const warnings=[];
    for(const {index,spec,state} of this.bots){
      if(state==='waiting')warnings.push(spec.join.when==='following'?`bots[${index}] "${spec.id}" never joined: the conductor never held the followed beat for ${spec.join.beats} beats`+
        (spec.join.latest?`, and ${describePosition(spec.join.latest)} is not before the end of the render`:''):`bots[${index}] "${spec.id}" never joined: ${describePosition(spec.join)} is not before the end of the render`);
      if(state==='skipped')warnings.push(`bots[${index}] "${spec.id}" never joined: it leaves at ${describePosition(spec.leave)}, no later than it joins at ${describePosition(spec.join)}`);
    }
    for(const {index,id,spec,placement,adapters} of this.clips){
      if(!placement)warnings.push(`clips[${index}] "${id}" was not placed: ${describePosition(spec.at)} is not before the end of the render`);
      for(const {name,adapter} of adapters)if(adapter.pending?.length)warnings.push(`clips[${index}] "${id}" ${name}: ${adapter.pending.length} cue(s) never delivered, the first at ${describePosition(adapter.pending[0].at)}`);
    }
    if(this.cues?.pending.length)warnings.push(`cues: ${this.cues.pending.length} cue(s) never delivered, the first at ${describePosition(this.cues.pending[0].at)}`);
    return warnings;
  }
}
