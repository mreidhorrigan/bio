import {ClientEnsemble} from '../client-ensemble.js';
import {settleHold} from '../shared/clock-hold.js';

const EPSILON=1e-9;

// A ClientEnsemble stepped by the renderer instead of setTimeout. musicSeconds[k] integrates
// exactly what schedule() waits live: 60/bpm/subdivision at pulse k's own tempo and meter (pulseInterval), and a hold
// at pulse k (shared/clock-hold.js) between its attack and the rest of it: tickHolds[k] seconds. Inside a rubato span
// (shared/rubato-clocks.js) a pulse is where the span's own map puts it, counted from the span's start, so nothing
// accumulates there: the same spec gives the same times. A hold inside a span pauses it: the pulses after the hold are
// the map's, moved by exactly the holds' seconds since the span began.
export class OfflineTransport extends ClientEnsemble {
  constructor(meterApi=globalThis.MusebotMeter,{bpm,meter,lockTempo=false,lockMeter=false,lookahead=0.25}={}){
    super(meterApi,{bpm,meter});
    // A pulse's notes sound exactly one lookahead after it is emitted (TimelineClock).
    Object.assign(this,{lockTempo:Boolean(lockTempo),lockMeter:Boolean(lockMeter),lookahead,outputDelaySeconds:lookahead,ignored:[],tickSeconds:[0],tickIntervals:[],tickScoreBpms:[],tickHolds:[],barStarts:[0],barMeters:[this.meter],timers:[],renderSeconds:0,tempoStep:null});
    this.meterNow=()=>this.now();this.meterTimeDomain='render-seconds';
    // Local tempo following runs on render time too, and is pumped once per step (beginStep), not on a wall-clock timer.
    const following=this.localTempoFollowing,renderNow=()=>this.now();
    following.now=renderNow;following.clock.referenceTime=renderNow;this.followingPumped=false;
  }
  // A render's clock runs on its render time: a cue arriving during a held pulse's step is taken then. Its re-entry is
  // the timeline's (endStep), with no timer to wait on.
  clockSeconds(){return this.now()}
  // A pulse is emitted at its grid time exactly, which a span's map starts from.
  pulseSeconds(){return this.musicSeconds}
  resumeHold(){}
  // When the next pulse is emitted, in render milliseconds, as a live scheduler's nextAt: its sound lands one lookahead
  // later. Nothing is scheduled while the room is empty. The value is derived from the grid, so assignments are ignored.
  get nextAt(){return this.clients?.size&&this.tickSeconds?this.positionAt(this.tick).musicSeconds*1000:0}
  set nextAt(value){}
  startFollowingPump(){this.followingPumped=true}
  pumpFollowing(){
    const following=this.localTempoFollowing;
    if(!this.followingPumped||!following.controller.enabled)return;
    try{following.pump()}catch(error){following.controller.disable(error.message)}
  }
  schedule(){}
  start(){}
  stop(){}
  // **A pulse reaches the bots that publish before the bots that play.** A broadcast is delivered in the order the
  // bots joined, which in a render is the order of names in the spec -- so whether a melody bot heard the harmony
  // before choosing its first note depended on whether it was listed above or below the chord bot. Measured: with
  // papMelody, counterpoint and drone listed first, all three struck bar 1 beat 1 from their own fallback pools (G and
  // C) and ae_ModalChordBOT then announced D F A-flat C. Listed after it, all three were in the chord.
  //
  // A live room cannot order its network and answers this with a setup phase instead. A render can simply be right:
  // `clockRank(client)` gives each client a rank, lower first, and join order breaks ties, so it stays deterministic.
  // Only clock pulses are ordered. Protocol messages are delivered as they are sent, because their order IS the
  // conversation.
  broadcast(message,room){
    if(message?.type!=='clock'||typeof this.clockRank!=='function')return super.broadcast(message,room);
    const ordered=[...this.clients].map(([socket,client],index)=>({socket,client,index,rank:Number(this.clockRank(client))||0}))
      .sort((left,right)=>left.rank-right.rank||left.index-right.index);
    let data;for(const {socket,client} of ordered)if((!room||client.room===room)&&this.clients.has(socket))socket.deliver(message,data??=JSON.stringify(message));
  }
  // A new ensemble session (the roster emptied and refilled) must not rewind the render timeline.
  prepare(options={}){
    const {tick,bar,tickInBar}=this,previous=this.session.startedAt,prepared=super.prepare(options);
    if(previous!==prepared.startedAt){Object.assign(this,{tick,bar,tickInBar});this.invalidateTempo({tempoCurve:null})}
    return prepared;
  }
  get latestTick(){return this.tickSeconds.length-1}
  get musicSeconds(){return this.tickSeconds[Math.min(this.tick,this.latestTick)]}
  get currentInterval(){return 60/this.bpm/this.meter.subdivision}
  secondsAtTick(tick){return Number.isInteger(tick)&&tick>=0&&tick<this.tickSeconds.length?this.tickSeconds[tick]:null}
  // beginStep() runs the pulse's updateTempo() early, and pulse() does not run it again. Messages delivered in
  // between still reach the pulse as they do live: replacing the curve that run started, or restarting the
  // session, makes pulse() recompute the tick's tempo from the state it had before beginStep().
  updateTempo(){
    if(this.tempoStep?.tick===this.tick)return;
    const {bpm,tempoCurve,pendingTempoCurve}=this;
    this.tempoStep={tick:this.tick,bpm,tempoCurve,stale:false};
    super.updateTempo();
    this.tempoStep.started=Boolean(pendingTempoCurve)&&this.pendingTempoCurve!==pendingTempoCurve;
  }
  invalidateTempo(changes){if(this.tempoStep?.tick===this.tick)Object.assign(this.tempoStep,changes,{stale:true})}
  pulse(){
    const step=this.tempoStep;
    if(step?.tick===this.tick&&step.stale)Object.assign(this,{bpm:step.bpm,tempoCurve:step.tempoCurve,tempoStep:null});
    return super.pulse();
  }
  beginStep(){
    if(this.tick!==this.latestTick)throw new Error(`beginStep() at tick ${this.tick} needs endStep() for tick ${this.latestTick}`);
    // Following first: a ramp it accepts starts at a later bar line, so it never changes the tempo worked out next.
    this.pumpFollowing();
    this.updateTempo();
    return{tick:this.tick,bar:this.bar,tickInBar:this.tickInBar,musicSeconds:this.musicSeconds,bpm:this.bpm,meter:this.meter,provisionalInterval:this.currentInterval};
  }
  endStep(){
    const tick=this.latestTick;
    if(this.tick!==tick+1)throw new Error(`endStep() needs exactly one pulse() after tick ${tick} (transport is at tick ${this.tick})`);
    // (The pulse's own interval, read in pulse() before its bar advanced: client-ensemble.js.) A hold at the pulse comes
    // between its attack and the rest of it. A cued hold is settled here: its cue, if one came during the step (a bot
    // that answers the held pulse, naming inSeconds), or its bound; the timeline is committed, so a later cue is refused.
    const interval=this.pulseInterval??this.currentInterval,hold=settleHold(this),musicSeconds=this.tickSeconds[tick],
      spanHolds=this.rubatoNext!=null?(this.spanHoldSeconds=(this.spanHoldSeconds??0)+hold):0,
      nextMusicSeconds=this.rubatoNext!=null?this.rubatoNext+spanHolds:musicSeconds+hold+interval;
    this.announceHolds();
    this.tickIntervals.push(interval);this.tickScoreBpms.push(this.pulseScoreBpm);this.tickHolds.push(hold);this.tickSeconds.push(nextMusicSeconds);
    if(this.tickInBar===0){this.barStarts[this.bar]=this.tick;this.barMeters[this.bar]=this.meter}
    return{tick,musicSeconds,nextMusicSeconds,interval,...(hold?{holdSeconds:hold,holdId:this.holding.id}:{})};
  }
  // exact is false while the grid time is extrapolated at the current tempo (the tick is not reached yet).
  resolvePosition(position={}){
    const latest=this.latestTick,split=value=>{const whole=Math.round(value),ticks=Math.abs(value-whole)<EPSILON?whole:value,tick=Math.floor(ticks);return[tick,ticks-tick]};
    if(position.bar!=null){
      const bar=Number(position.bar),beat=position.beat==null?1:Number(position.beat);
      if(!Number.isInteger(bar)||bar<1)throw new RangeError(`Bar must be a whole number from 1, not ${position.bar}`);
      // Checked before the bar is reached, so a bad beat fails at once instead of never resolving.
      if(!Number.isFinite(beat)||beat<1)throw new RangeError(`Beat must be a number from 1, not ${position.beat}`);
      const start=this.barStarts[bar-1];if(start==null)return null;
      const meter=this.barMeters[bar-1],[tick,fraction]=split((beat-1)*meter.subdivision);
      if(tick>=meter.pulsesPerBar)throw new RangeError(`Beat ${position.beat} is outside bar ${bar}, which has ${meter.pulsesPerBar/meter.subdivision} beats (${meter.label})`);
      return this.positionAt(start+tick,fraction);
    }
    if(position.tick!=null){
      const value=Number(position.tick);
      if(!Number.isFinite(value)||value<0)throw new RangeError(`Tick must be a number from 0, not ${position.tick}`);
      return this.positionAt(...split(value));
    }
    if(position.seconds!=null){
      const seconds=Number(position.seconds),times=this.tickSeconds;
      if(!Number.isFinite(seconds)||seconds<0)throw new RangeError(`Seconds must be a number from 0, not ${position.seconds}`);
      if(seconds+EPSILON>=times[latest]){const [ticks,fraction]=split((seconds-times[latest])/this.currentInterval);return{tick:latest+ticks,fraction,musicSeconds:seconds,exact:ticks===0&&fraction===0}}
      let low=0,high=latest-1;
      while(low<high){const middle=(low+high+1)>>1;if(times[middle]<=seconds+EPSILON)low=middle;else high=middle-1}
      // Inside a hold the score does not move: the held pulse's own position, never one invented between.
      const hold=this.tickHolds[low]??0,offset=seconds-times[low]-hold;
      return{tick:low,fraction:offset<EPSILON?0:offset/this.tickIntervals[low],musicSeconds:seconds,exact:true};
    }
    throw new TypeError('A position needs bar (and beat), tick or seconds');
  }
  positionAt(tick,fraction=0){
    const latest=this.latestTick;
    // A position after a held pulse's attack is after its hold.
    if(tick<latest)return{tick,fraction,musicSeconds:this.tickSeconds[tick]+(fraction>0?this.tickHolds[tick]??0:0)+fraction*this.tickIntervals[tick],exact:true};
    return{tick,fraction,musicSeconds:this.tickSeconds[latest]+(tick-latest+fraction)*this.currentInterval,exact:tick===latest&&fraction===0};
  }
  musicSecondsAt(position){return this.resolvePosition(position)?.musicSeconds??null}
  at(renderSeconds,fn){
    const time=Number(renderSeconds);
    if(!Number.isFinite(time)||typeof fn!=='function')throw new TypeError('at() needs finite render seconds and a callback');
    const timer={time,fn};let index=this.timers.length;
    while(index>0&&this.timers[index-1].time>time)index--;
    this.timers.splice(index,0,timer);
    return()=>{const at=this.timers.indexOf(timer);if(at>=0)this.timers.splice(at,1)};
  }
  // Timers added while firing run in the same call when they are already due. The nanosecond tolerance keeps
  // now()+n*interval on its own tick although musicSeconds accumulates rounding.
  fireDue(renderSeconds){
    const time=Number(renderSeconds);if(!Number.isFinite(time))throw new TypeError('fireDue() needs finite render seconds');
    this.renderSeconds=Math.max(this.renderSeconds,time);let fired=0;
    while(this.timers.length&&this.timers[0].time<=time+EPSILON){const timer=this.timers.shift();fired++;timer.fn(timer.time)}
    return fired;
  }
  now(){return this.renderSeconds}
  queueTempoCurve(value={},mode='nextBar'){
    if(this.lockTempo){this.ignore('/broadcast/tempoCurve',value,mode);return null}
    const queued=super.queueTempoCurve(value,mode);
    // An opening steps the tempo now. If this tick's tempo had already been worked out, that is the tempo the step
    // replaces, so a later message that makes pulse() recompute the tick starts from the opening and not from before it.
    if(queued?.opening){if(this.tempoStep?.tick===this.tick)Object.assign(this.tempoStep,{bpm:this.bpm,tempoCurve:null});return queued}
    if(this.tempoStep?.started)this.invalidateTempo({});return queued;
  }
  queueMeter(value={},mode='nextBar',publisher){
    if(this.lockMeter){this.ignore('/broadcast/timeSignature',value,mode);return null}
    const queued=super.queueMeter(value,mode,publisher);
    // An opening is applied before the first pulse, so bar 1 IS in that meter and the grid must say so.
    if(queued?.opening)this.barMeters[this.bar]=this.meter;
    return queued;
  }
  ignore(address,value,mode){this.ignored.push({address,value,mode,tick:this.tick,bar:this.bar,musicSeconds:this.musicSeconds})}
}
