// The offline renderer's environment-agnostic API (docs/OFFLINE_RENDERING.md). Importing it registers the built-in
// 'score' engine and the 'cues', 'none', 'features' and 'input' hearing adapters; the 'node' and 'chrome' engines register
// from their own modules.
export {normalizeRenderSpec,RenderSpecError,normalizePosition,positionKey,describePosition,RENDER_SPEC_VERSION,DEFAULT_SEED,BOT_OUTPUTS,STEM_KINDS} from './spec.js';
export {RenderSession,renderSink} from './render-session.js';
export {RenderTimeline,LOOKAHEAD,prerollFrames,renderFrame,clipAudibleSeconds,generateClipAudio} from './timeline.js';
export {OfflineTransport} from './transport.js';
export {TimelineClock} from './timeline-clock.js';
export {installVirtualTime} from './virtual-time.js';
export {HeadlessBot,botTrackId,botSoundSeed} from './bot-host.js';
export {registerRenderEngine,getRenderEngine,listRenderEngines,validateEngine,createRenderEngine,unsupportedFeatures,unsupportedErrors,engineMetadata,engineSpecProblems} from './engines.js';
export {createScoreEngine,createScoreAudio,scoreDspNode,ScoreContext,ScoreMixer,SCORE_CAPABILITIES} from './score-engine.js';
export {registerHearing,getHearing,listHearings,createHearingAdapters,createCueScheduler} from './hearing.js';
export {featuresHearing,FEATURE_ADDRESSES,ANALYSER_DEFAULTS} from './hearing-features.js';
export {renderInputs} from './render-inputs.js';
export {sanitizeFileName,trackFileName,trimPreroll,memorySink,teeSink,registerOutputFormat,getOutputFormat,listOutputFormats,createOutputEncoder,jsonlLog} from './outputs.js';
