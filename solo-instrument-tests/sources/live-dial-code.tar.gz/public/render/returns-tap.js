// The returns stem (outputs.stems "returns"): everything in the mix that no stem holds. That is the shared effects'
// returns -- the reverb, the room, the delay, parallel compression, drive, chorus, the effect plugin -- and any channel
// without a stem of its own. Without it a render's stems do not sum to its mix: a Surge XT band sending to the IEM
// reverb left a quarter of its mix's energy (-15 dB) in no stem at all, and an object stem, taken before the sends'
// effects, carries none of the room it was mixed into.
//
// It is built in the graph as the mix bus less every stemmed channel: the bus into a summing gain, and each stemmed
// channel's own output (its fader, before the bus) into it through a gain of -1. So stems and returns sum to the mix
// bus whatever sits between -- an effect built the first time it is asked for, a width matrix spliced after the reverb,
// a bus -- because nothing between is modelled. The same in both engines, so the chrome engine checks the node engine.
export const RETURNS_TRACK='return:effects';

export function createReturnsTap(context,mixer){
  let sum=null;
  const inverted=new Map();
  return {
    // The node to tap: the summing gain, made on first use.
    node(){
      if(mixer.closed)return null;
      if(!sum){sum=context.createGain();mixer.output.connect(sum)}
      return sum;
    },
    // Take each stemmed channel that exists by now out of the returns. Called where the stems are tapped, so a channel
    // leaves the returns at the moment its stem starts holding it.
    subtract(ids){
      if(mixer.closed||!sum)return;
      for(const id of ids){
        const dry=mixer.tracks.get(id)?.dry??null,known=inverted.get(id);
        if(!dry||known?.dry===dry)continue;
        if(known)try{known.dry.disconnect(known.gain)}catch{/* its channel has gone */}
        const gain=context.createGain();
        gain.gain.value=-1;
        dry.connect(gain);gain.connect(sum);
        inverted.set(id,{dry,gain});
      }
    },
  };
}
