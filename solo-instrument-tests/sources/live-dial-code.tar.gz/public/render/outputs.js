// Sinks receive planar Float32 blocks in render time: begin({sampleRate, tracks}), write(trackId, channels), end().
// A caller may reuse a block's buffers once write() returns, so sinks copy or encode immediately.
const thenable=value=>typeof value?.then==='function';
const settle=results=>results.some(thenable)?Promise.all(results).then(()=>undefined):undefined;
const isFloat32=value=>Object.prototype.toString.call(value)==='[object Float32Array]';

export function sanitizeFileName(value){
  const name=String(value).replace(/[^A-Za-z0-9_.-]+/g,'_').replace(/^\.+/,'_').slice(0,120);
  return name||'_';
}

// 'mix' → mix.wav, 'bot:modal:1' → bots/modal-1.wav, 'clip:tape' → clips/tape.wav, 'fx:reverb' → fx-reverb.wav.
export function trackFileName(id,{extension='.wav'}={}){
  if(typeof id!=='string'||!id)throw new TypeError('trackFileName needs a track id');
  const [kind,...rest]=id.split(':'),parts=rest.map(sanitizeFileName);
  if(kind==='bot'&&parts.length)return `bots/${parts.join('-')}${extension}`;
  if(kind==='clip'&&parts.length)return `clips/${sanitizeFileName(rest.join(':'))}${extension}`;
  if(kind==='return'&&parts.length)return `returns/${parts.join('-')}${extension}`;
  return `${[sanitizeFileName(kind),...parts].join('-')}${extension}`;
}

export function trimPreroll(sink,frames){
  if(!Number.isSafeInteger(frames)||frames<0)throw new RangeError(`trimPreroll needs a whole number of frames, not ${frames}`);
  const dropped=new Map;
  return {
    frames,
    begin(info){dropped.clear();return sink.begin(info)},
    write(id,channels){
      const done=dropped.get(id)||0;
      if(done>=frames)return sink.write(id,channels);
      const length=channels[0]?.length??0,drop=Math.min(length,frames-done);
      dropped.set(id,done+drop);
      if(drop<length)return sink.write(id,channels.map(channel=>channel.subarray(drop)));
    },
    end(){return sink.end()},
  };
}

export function memorySink(){
  const tracks=new Map;let info=null,ended=false;
  const track=id=>{const value=tracks.get(id);if(!value)throw new Error(`Track "${id}" was not declared in begin()`);return value};
  return {
    get info(){return info},
    get ended(){return ended},
    begin(value){
      if(!Number.isFinite(value?.sampleRate)||!Array.isArray(value.tracks))throw new TypeError('begin() needs {sampleRate, tracks}');
      tracks.clear();ended=false;info=value;
      for(const {id,kind,channels} of value.tracks){
        if(typeof id!=='string'||tracks.has(id))throw new Error(`Track id "${id}" is missing or repeated`);
        if(!Number.isInteger(channels)||channels<1)throw new Error(`Track "${id}" needs a positive channel count`);
        tracks.set(id,{id,kind,channels,blocks:Array.from({length:channels},()=>[]),frames:0,joined:null});
      }
    },
    write(id,channels){
      const target=track(id);
      if(ended)throw new Error(`write("${id}") after end()`);
      if(!Array.isArray(channels)||channels.length!==target.channels)throw new Error(`Track "${id}" has ${target.channels} channels, got ${channels?.length}`);
      const length=channels[0].length;
      if(channels.some(channel=>!isFloat32(channel)||channel.length!==length))throw new Error(`Track "${id}" needs Float32Array channels of equal length`);
      // new Float32Array() also copies arrays created in another realm (the vm-hosted worklet).
      channels.forEach((channel,index)=>target.blocks[index].push(new Float32Array(channel)));
      target.frames+=length;target.joined=null;
    },
    end(){ended=true;return {tracks:[...tracks.values()].map(({id,frames})=>({id,frames}))}},
    frames(id){return track(id).frames},
    ids(){return [...tracks.keys()]},
    track(id){
      const target=track(id);
      target.joined||=target.blocks.map(blocks=>{const out=new Float32Array(target.frames);let at=0;for(const block of blocks){out.set(block,at);at+=block.length}return out});
      return target.joined;
    },
  };
}

export function teeSink(...sinks){
  const merge=results=>{
    const tracks=new Map;
    for(const result of results)for(const track of result?.tracks||[])tracks.set(track.id,{...tracks.get(track.id),...track});
    return {tracks:[...tracks.values()]};
  };
  return {
    begin(info){return settle(sinks.map(sink=>sink.begin(info)))},
    write(id,channels){return settle(sinks.map(sink=>sink.write(id,channels)))},
    end(){const results=sinks.map(sink=>sink.end());return results.some(thenable)?Promise.all(results).then(merge):merge(results)},
  };
}

const formats=new Map;
// A format factory is ({sampleRate, channelCount, wav?}) => encoder (or a promise of one):
// {format, extension, sampleRate, channelCount, header(frames) → Uint8Array, encode(channels) → Uint8Array,
//  trailer(frames) → Uint8Array, file(channels) → Uint8Array}.
// header() has the same length for any frame count, so a streaming writer can patch it on close;
// header(frames) + every encode() block + trailer(frames) is byte-identical to file() (RIFF pads odd data to an even size).
export function registerOutputFormat(name,factory,{replace=false}={}){
  if(typeof name!=='string'||!/^[A-Za-z][A-Za-z0-9_.-]{0,63}$/.test(name))throw new TypeError(`Invalid output format name: ${name}`);
  if(typeof factory!=='function')throw new TypeError(`Output format "${name}" needs a factory function`);
  if(formats.has(name)&&!replace)throw new Error(`Output format "${name}" is already registered; pass {replace: true} to override it`);
  formats.set(name,factory);
  return factory;
}
export function getOutputFormat(name){
  if(!formats.has(name))throw new Error(`Unknown output format "${name}" (registered: ${[...formats.keys()].join(', ')||'none'})`);
  return formats.get(name);
}
export const listOutputFormats=()=>[...formats.keys()];
export async function createOutputEncoder(name,options){return getOutputFormat(name)(options)}

// wav.js is loaded on first use; pass {wav} to supply an implementation instead.
const wavFormat=format=>async({sampleRate,channelCount,wav})=>{
  const api=wav||await import('../shared/wav.js'),layout=api.wavLayout?.({sampleRate,channelCount,format});
  return {format,extension:'.wav',sampleRate,channelCount,bytesPerFrame:layout?.blockAlign,
    header:(frames=0)=>api.wavHeader({sampleRate,channelCount,format,frames}),
    encode:channels=>api.encodeFrames(channels,format),
    trailer:(frames=0)=>new Uint8Array(layout?frames*layout.blockAlign%2:0),
    file:channels=>api.encodeWav({sampleRate,channels,format})};
};
for(const format of ['float32','pcm24','pcm16'])registerOutputFormat(format,wavFormat(format));

export function jsonlLog({onLine,keep=true}={}){
  const lines=[];
  return {
    write(record){const line=JSON.stringify(record);if(line===undefined)throw new TypeError('A JSONL record must be JSON-serializable');if(keep)lines.push(line);onLine?.(line);return line},
    lines(){return [...lines]},
    records(){return lines.map(line=>JSON.parse(line))},
    text(){return lines.length?`${lines.join('\n')}\n`:''},
    get size(){return lines.length},
  };
}
