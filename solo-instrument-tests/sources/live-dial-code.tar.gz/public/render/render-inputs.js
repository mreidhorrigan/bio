// A render's clips as audio inputs, which a bot opens as it would a sound card's
// input live. A clip becomes one by naming the 'input' hearing (hear: ['input']):
// the render itself then sends nothing on its behalf, and a listening bot
// (ListenerBot) hears it instead, through the same analysis as a microphone.
//
// Each input is the clip's audible mono signal: its placement, offset, fades and
// gain are the ones the mix uses (clipSource). Its times are render seconds, the
// host clock bots decide on, and a clip sounds one lookahead after its music
// time, as a bot's note does. So at the render's present a bot has heard exactly
// what a live listener could have, and nothing that is still to sound.
//
// ListenerBots claim the inputs in the order they join, one each, in spec order
// of the clips; bot-host.js hands every bot the render's inputs as `inputs`.
// listening: how they hear them (a spec's follow.listening), or null for the listener's defaults.
import {clipSource} from './hearing-features.js';
import {registerHearing} from './hearing.js';
import {clipForesight} from './foresight.js';

// foresight (a spec's foresight: true, foresight.js): each input also offers what its whole clip holds, known before it
// sounds: where its sound ends, its chords and its attacks over the whole take, in render seconds once the clip is placed.
export function renderInputs({sampleRate,transport,lookahead=transport?.lookahead??0,listening=null,foresight=false}) {
  if(!(sampleRate>0)||typeof transport?.now!=='function')throw new TypeError('Render inputs need the render rate and its transport');
  const armed=new Map,claimed=new Set;
  return Object.freeze({
    // What a bot decides at render second t sounds at t + outputDelaySeconds; a listener places what it hears by it.
    now:()=>transport.now(),listening,outputDelaySeconds:lookahead,foresight:Boolean(foresight),
    arm({clip,decoded}){
      const id=`clip:${clip.id}`;
      if(armed.has(id))throw new Error(`Clip "${clip.id}" is already an input`);
      armed.set(id,{name:clip.id,source:clipSource({clip,decoded,sampleRate,transport})});
      return id;
    },
    list:()=>[...armed.entries()].map(([id,{name}])=>({id,name,kind:'audioinput'})),
    // The first armed input no bot has claimed yet, or null.
    claim(){const id=[...armed.keys()].find(value=>!claimed.has(value));if(id)claimed.add(id);return id??null;},
    open(id){
      const input=armed.get(id);
      if(!input)return null;
      // A clip is captured the instant it sounds, and the bots' notes are scheduled on the same clock: no latency.
      const source=input.source;let seen=null;
      return Object.freeze({sampleRate,name:input.name,latencySeconds:0,
        // The whole clip's foresight, in render seconds from its placement: {audibleEnd, chords: [{start, end, label,
        // pitchClasses}], attacks: [seconds]}, or null (no foresight in this render, or the clip not yet placed).
        ...(foresight?{foresight(){
          const start=source.startSeconds;if(start==null)return null;
          seen??=clipForesight({read:(from,count)=>source.readClip(from,count),duration:source.duration,sampleRate,listening});
          return {audibleEnd:start+seen.audibleEnd,chords:seen.chords.map(chord=>({...chord,start:start+chord.start,end:start+chord.end})),
            attacks:seen.attacks.map(at=>+(start+at).toFixed(3))};
        }}:{}),
        // count samples from render second `from`: silent wherever the clip is not sounding.
        read(from,to,count=Math.round((to-from)*sampleRate)){return input.source.addTo(new Float32Array(count),Math.round((from-lookahead)*sampleRate));}});
    },
  });
}

registerHearing('input',({clip,decoded,transport})=>{
  if(!transport?.renderInputs)throw new Error(`Clip "${clip.id}" can be an input only in a render`);
  if(!decoded?.channels?.length)throw new TypeError(`Clip "${clip.id}" needs decoded audio to be an input`);
  transport.renderInputs.arm({clip,decoded});
  return {onTick:()=>[],done:true};
});
