// Foresight: what a whole recording holds, known before it sounds. The user: "add a special offline mode that allows the
// bots to take information from the entire expanse of what will happen, rather than behaving sequentially in time. Don't
// use this 'cheating' mode for simulated-synchronous tests, but it will be useful to get the best functionality of the
// bots in real offline deployment situations."
//
// A render with `foresight: true` (spec.js) gives the bots, for each clip armed as an input (render-inputs.js), what a
// listener could only learn by hearing it through: where its sound ends, and its chords over the whole take, decoded at
// once (Viterbi, as a recognizer decodes a finished recording) rather than filtered forward frame by frame as a live
// listener must. The ListenerBot then announces each chord as it is played rather than after hearing it, and
// form_clodbot ends the piece with the recording. A render without it hears as a live room does, and a test that stands
// for live performance must not use it (render/test-helper.mjs refuses it unless a test of this mode asks).
//
// And its attacks over the whole take, as the listener's own detector would hear them (audio-features.js, the
// listening's detectors): where the person plays and where they rest, known ahead, for the profile that says it
// (profile_clodbot) and the conductor that plans its contingencies on it.
//
// The chords are the listening's own templates (the 24 major and minor triads, audio-chroma.js, and a no-chord class
// for silence and noise), on its chroma at 10 frames a second, with a persistence that makes a change of chord cost what
// staying does not (`stay`); segments shorter than `minimumSeconds` join the one before.
import {ChromaFrames} from '../shared/estimation/audio-chroma.js';
import {FRAME_CHROMA} from '../shared/estimation/audio-frame-analysis.js';
import {TWELVE_TONE_TRIADS} from '../shared/estimation/harmony-model.js';
import {AudioFeatureSource} from '../shared/estimation/audio-features.js';

export const FORESIGHT_DEFAULTS=Object.freeze({fps:10,silenceDb:-45,windowSeconds:.05,stay:.97,sharpness:25,noChordWeight:1e-3,minimumSeconds:.3});

// `read(fromSeconds, count)`: the clip's audible mono signal from `fromSeconds` after its start (its gain and fades
// applied). `listening`: the one followed (its onsetDetector and attackDetector, listening-options.js). Returns
// {audibleEnd (seconds from the clip's start, or 0), chords: [{start, end, label, pitchClasses}], attacks: [seconds]}.
export function clipForesight({read,duration,sampleRate,listening=null},options={}){
  const o={...FORESIGHT_DEFAULTS,...options};
  if(typeof read!=='function'||!(duration>0)||!(sampleRate>0))throw new TypeError('Foresight needs a clip reader, its duration and its rate');
  // Where its sound ends: the last window above silence.
  const window=Math.max(1,Math.round(o.windowSeconds*sampleRate)),threshold=10**(o.silenceDb/20),total=Math.floor(duration*sampleRate);
  // Backward window by window from the end, the last window whatever is left before the start and measured over its own
  // length: stepping from a positive start straight past zero never read the clip's first partial window, so a clip
  // sounding only there was silent (the mathematical audit's I25).
  let audibleEnd=0;
  for(let end=total;end>0;end-=window){
    const at=Math.max(0,end-window),samples=read(at/sampleRate,end-at);let energy=0;for(const value of samples)energy+=value*value;
    if(samples.length&&Math.sqrt(energy/samples.length)>threshold){audibleEnd=Math.min(duration,end/sampleRate);break;}
  }
  // Chroma a frame, each window centred on its frame.
  const frames=new ChromaFrames({sampleRate,...FRAME_CHROMA,smoothing:0}),size=frames.fftSize,labels=TWELVE_TONE_TRIADS.labels;
  const templates=labels.map(label=>{const t=new Float64Array(12);for(const pc of label.pitchClasses)t[pc]=1;const n=Math.hypot(...t);return t.map(v=>v/n)});
  if(!Number.isFinite(o.fps)||o.fps<=0||o.fps>1000||!['drop','retain'].includes(o.partialFrame??'drop'))throw new RangeError('Invalid analysis cadence/tail policy');
  const count=Math.max(0,(o.partialFrame==='retain'?Math.ceil:Math.floor)(audibleEnd*o.fps)),states=labels.length+1,scores=[];
  if(!Number.isSafeInteger(count)||count*states>2000000)throw new RangeError('Viterbi state budget exceeded before feature allocation');
  for(let f=0;f<count;f++){
    const centre=o.partialFrame==='retain'?(f/o.fps+Math.min(audibleEnd,(f+1)/o.fps))/2:(f+.5)/o.fps,start=Math.round(centre*sampleRate)-size/2;
    const samples=start>=0?read(start/sampleRate,size):(()=>{const out=new Float32Array(size);out.set(read(0,size+start),-start);return out})();
    const chroma=frames.chroma(samples),row=new Float64Array(states);
    if(!chroma){row.fill(-Infinity);row[labels.length]=0;scores.push(row);continue;}
    const norm=Math.hypot(...chroma)||1;
    templates.forEach((t,i)=>{let dot=0;for(let pc=0;pc<12;pc++)dot+=t[pc]*chroma[pc];row[i]=o.sharpness*dot/norm});
    let flat=0;for(let pc=0;pc<12;pc++)flat+=chroma[pc]/Math.sqrt(12);row[labels.length]=o.sharpness*flat/norm+Math.log(o.noChordWeight);
    scores.push(row);
  }
  // A move excludes the destination, even when switching is more probable.
  const path=decodeSymmetricScores(scores,{stay:o.stay});
  // Its segments: chords, no chord left out; a segment too short to be one joins the one before.
  const segments=[];
  path.forEach((state,f)=>{const last=segments.at(-1);if(last&&last.state===state)last.end=Math.min(audibleEnd,(f+1)/o.fps);else segments.push({state,start:f/o.fps,end:Math.min(audibleEnd,(f+1)/o.fps)})});
  const merged=[];for(const segment of segments){const last=merged.at(-1);if(last&&(segment.end-segment.start<o.minimumSeconds||last.state===segment.state))last.end=segment.end;else merged.push({...segment})}
  const chords=merged.filter(segment=>segment.state<labels.length).map(({state,start,end})=>({start:+start.toFixed(3),end:+end.toFixed(3),label:labels[state].id,pitchClasses:[...labels[state].pitchClasses]}));
  return {audibleEnd:+audibleEnd.toFixed(3),chords,attacks:clipAttacks({read,sampleRate,audibleEnd,listening})};
}

// The attacks a listener hears in the clip up to its last sound, frame after frame as it would hear them live: the
// second detector's where the listening names one, as the listener passes on (listener-bot.js), and from a frame of the
// silence before it, as a clip placed in a render is heard (an attack is a rise from what came before). -> [seconds]
function clipAttacks({read,sampleRate,audibleEnd,listening}){
  const detectors=Object.fromEntries(['onsetDetector','attackDetector'].filter(key=>listening?.[key]).map(key=>[key,listening[key]]));
  const source=new AudioFeatureSource({sampleRate,...detectors}),size=source.frameSize,last=Math.ceil(audibleEnd*sampleRate),attacks=[];
  for(let at=-size;at<last;at+=size){
    const start=at/sampleRate,end=(at+size)/sampleRate,got=at<0?new Float32Array(size):read(start,size),samples=got.length===size?got:Float32Array.from({length:size},(_,i)=>got[i]??0);
    const features=source.process(samples,{start,end,availableAt:end}),attack='attack' in features?features.attack:features.onset;
    if(attack)attacks.push(+Math.max(0,attack.estimateSeconds).toFixed(3));
  }
  return attacks;
}

export function decodeSymmetricScores(scores,{stay=.97,maxCells=2000000}={}){
  if(!Array.isArray(scores)||!Number.isFinite(stay)||stay<0||stay>1||!Number.isSafeInteger(maxCells)||maxCells<1||maxCells>10000000)throw new TypeError('Invalid Viterbi scores or budget');
  if(!scores.length)return [];
  const states=scores[0].length;if(!states||scores.length*states>maxCells)throw new RangeError('Viterbi state budget exceeded');
  if(scores.some(row=>row.length!==states||Array.from(row).some(x=>typeof x!=='number'||!Number.isFinite(x)&&x!==-Infinity)))throw new TypeError('Viterbi rows require finite log scores or -Infinity');
  const keptLog=states===1?0:Math.log(stay),moveLog=states===1?-Infinity:Math.log((1-stay)/(states-1)),back=[];
  let best=Float64Array.from(scores[0]);
  for(let f=1;f<scores.length;f++){
    let top=0,second=-1;for(let s=1;s<states;s++){if(best[s]>best[top]){second=top;top=s;}else if(second<0||best[s]>best[second])second=s;}
    const next=new Float64Array(states),from=new Int32Array(states);
    for(let s=0;s<states;s++){
      const other=top===s?second:top,kept=best[s]+keptLog,moved=other<0?-Infinity:best[other]+moveLog;
      if(kept>=moved){next[s]=kept+scores[f][s];from[s]=s;}else{next[s]=moved+scores[f][s];from[s]=other;}
    }
    back.push(from);best=next;
  }
  let at=0;for(let s=1;s<states;s++)if(best[s]>best[at])at=s;
  if(!Number.isFinite(best[at]))throw new RangeError('No finite-probability Viterbi path');
  const path=new Array(scores.length);for(let f=path.length-1;f>=0;f--){path[f]=at;if(f)at=back[f-1][at];}
  return path;
}
