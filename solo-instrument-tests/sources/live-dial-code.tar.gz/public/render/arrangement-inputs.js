import {normalizeArrangement,arrangementCoverage} from '../shared/arrangement.js';
import {clipSource} from './hearing-features.js';
import {clipForesight} from './foresight.js';

// One microphone for an entire prepared arrangement, without allocating a mixed
// copy of a whole project. Every clip is still placed independently in the output.
export function arrangementInputs({arrangement,sampleRate,transport,lookahead=transport.lookahead,listening=null,foresight=false}){
  const normalized=normalizeArrangement(arrangement),coverage=Object.freeze(arrangementCoverage(normalized).map(span=>Object.freeze({...span,clipIds:Object.freeze(span.clipIds)}))),
    context=Object.freeze({...normalized,coverage});
  // (Its name the performer's id to the listener that claims it, so an identifier: the title's words joined, else
  // 'arrangement' -- a title with spaces had stopped every render, "Invalid performer".)
  const name=String(normalized.title??'').trim().replace(/[^A-Za-z0-9_.:@/-]+/g,'-').replace(/^[^A-Za-z0-9]+|-+$/g,'').slice(0,256)||'arrangement';
  const sources=new Map;let claimed=false,seen=null;
  const readMusic=(from,count)=>{
    const out=new Float32Array(count),frame=Math.round(from*sampleRate);
    for(const source of sources.values()){
      if(source.startSeconds<from+count/sampleRate&&source.endSeconds>from)source.addTo(out,frame);
    }
    return out;
  };
  return Object.freeze({
    now:()=>transport.now(),listening,outputDelaySeconds:lookahead,foresight:Boolean(foresight),arrangement:context,
    arm({clip,decoded}){
      if(sources.has(clip.id))throw new Error(`Duplicate arrangement input ${clip.id}`);
      sources.set(clip.id,clipSource({clip,decoded,sampleRate,transport,lookahead}));seen=null;
      return 'arrangement';
    },
    list:()=>sources.size?[{id:'arrangement',name,kind:'audioinput'}]:[],
    claim(){if(claimed||!sources.size)return null;claimed=true;return 'arrangement'},
    open(id){
      if(id!=='arrangement'||!sources.size)return null;
      return Object.freeze({sampleRate,name,latencySeconds:0,
        read(from,to,count=Math.round((to-from)*sampleRate)){return readMusic(from-lookahead,count)},
        ...(foresight?{foresight(){
          seen??=clipForesight({read:readMusic,duration:normalized.endSeconds,sampleRate,listening});
          return {...seen,audibleEnd:lookahead+seen.audibleEnd,
            chords:seen.chords.map(chord=>({...chord,start:lookahead+chord.start,end:lookahead+chord.end})),
            ...(seen.attacks?{attacks:seen.attacks.map(at=>at+lookahead)}:{})};
        }}:{}),
      });
    },
  });
}
