import {registerHearing} from './hearing.js';

// 'features' hearing: clip PCM analysed the way the analyzer bot analyses its microphone on trunk.
//
// Live path: AudioEngine.microphone() (public/audio.js) feeds getUserMedia into an AnalyserNode with fftSize 1024
// and default smoothingTimeConstant .8, minDecibels -100, maxDecibels -30. features() reads it on demand:
//   loudness = RMS of getFloatTimeDomainData (the latest 1024 samples)
//   centroid = Σ i·b[i] / Σ b[i] / 512 over getByteFrequencyData bytes b (0 when every byte is 0)
//   activity = min(1, 12·loudness)   arousal = min(1, 8·loudness + .3·centroid)   valence = clamp01(.7 - .35·centroid)
// AudioAnalyzerBot ('analyzer', agents.js) calls features() once per clock.beatStart tick (tickInBar % subdivision
// == 0), so spectrum smoothing advances once per beat, and broadcasts in this order:
//   address              args        listeners on trunk (onMessage handlers)
//   /broadcast/loudness  [loudness]  none (decider reads features().loudness itself but never opens the microphone)
//   /broadcast/centroid  [centroid]  none (wind, wub and granu publish it too)
//   /broadcast/activity  [activity]  midiBot, video
//   /broadcast/arousal   [arousal]   seasonsArpy, seasonsBrokenChord, seasonsChord, seasonsDrone, seasonsSussy, bleep,
//                                    whiny, groan, wub, granu, midiBot, rungler, effects
//   /broadcast/valence   [valence]   whiny, groan, wub, granu, midiBot, rungler, effects
// midiGuitarInput also opens microphone() but only folds loudness into its own smoothed /broadcast/activity next to
// MIDI density and notepool; this adapter reproduces the analyzer, not that bot.
//
// Offline hearing has no latency: at a beat tick k the frame is the fftSize samples of clip audio audible from file
// time musicSeconds[k] (the start of the tick's window), so a clip anchored on a beat is heard on that beat. The clip
// starts at clip.placement.fileSeconds, clip.startFileSeconds, clip.placement.renderSeconds - lookahead, or
// transport.resolvePosition(clip.at), in that order. It plays from offsetSeconds for durationSeconds (default: the
// rest of the file) with gain, linear fadeIn/fadeOut and its mix fader (mix.gain), down-mixed to mono with the
// AnalyserNode speaker rules; it must be decoded at spec.sampleRate. Pan and sends are ignored: a room microphone hears
// the source at its mix level, not the speaker split (a centred StereoPannerNode would cost a mono clip 3 dB).
// All 'features' clips on one transport share one analyser, as one microphone hears the sum: the first adapter called
// for a beat tick returns that beat's messages and the others return none. Nothing is published before the first beat
// whose frame reaches a clip's start (so listeners keep their defaults until then); from there every beat an adapter
// is called for is published, silent frames included, as a microphone would report them.

export const ANALYSER_DEFAULTS=Object.freeze({fftSize:1024,smoothingTimeConstant:.8,minDecibels:-100,maxDecibels:-30});
export const FEATURE_ADDRESSES=Object.freeze({loudness:'/broadcast/loudness',centroid:'/broadcast/centroid',activity:'/broadcast/activity',arousal:'/broadcast/arousal',valence:'/broadcast/valence'});
const LOOKAHEAD=.25,SQRT_HALF=Math.SQRT1_2;

// Web Audio AnalyserNode frequency analysis, with Chrome's float32 storage of the window and smoothed magnitudes.
export class AnalyserFrames {
  constructor({fftSize=1024,smoothingTimeConstant=.8,minDecibels=-100,maxDecibels=-30}={}){
    if(!(Number.isInteger(fftSize)&&fftSize>=32&&fftSize<=32768&&!(fftSize&fftSize-1)))throw new RangeError(`fftSize must be a power of two from 32 to 32768, not ${fftSize}`);
    if(!(minDecibels<maxDecibels))throw new RangeError('minDecibels must be below maxDecibels');
    const n=fftSize,half=n/2,bits=Math.log2(n);
    Object.assign(this,{fftSize,frequencyBinCount:half,smoothingTimeConstant:Math.max(0,Math.min(1,smoothingTimeConstant)),minDecibels,maxDecibels,
      magnitudes:new Float32Array(half),real:new Float64Array(n),imag:new Float64Array(n),window:new Float32Array(n),
      reversed:new Uint32Array(n),cos:new Float64Array(half),sin:new Float64Array(half)});
    // Blackman, alpha .16, over x = i/N as the spec (and Chrome) define it.
    for(let i=0;i<n;i++){const x=i/n;this.window[i]=.42-.5*Math.cos(2*Math.PI*x)+.08*Math.cos(4*Math.PI*x)}
    for(let i=0;i<n;i++){let r=0;for(let b=0,v=i;b<bits;b++,v>>=1)r=r<<1|v&1;this.reversed[i]=r}
    for(let i=0;i<half;i++){this.cos[i]=Math.cos(2*Math.PI*i/n);this.sin[i]=Math.sin(2*Math.PI*i/n)}
  }
  reset(){this.magnitudes.fill(0)}
  // One getByteFrequencyData call on these time-domain samples: window, FFT, smooth with the previous call, dB, bytes.
  byteFrequencyData(samples,out=new Uint8Array(this.frequencyBinCount)){
    const {fftSize:n,real,imag,window,reversed,cos,sin,magnitudes}=this;
    if(samples.length!==n)throw new RangeError(`Expected ${n} time-domain samples, got ${samples.length}`);
    for(let i=0;i<n;i++){real[reversed[i]]=Math.fround(samples[i]*window[i]);imag[i]=0}
    for(let size=2;size<=n;size*=2){
      const half=size/2,step=n/size;
      for(let start=0;start<n;start+=size)for(let k=0;k<half;k++){
        const c=cos[k*step],s=sin[k*step],a=start+k,b=a+half,re=real[b]*c+imag[b]*s,im=imag[b]*c-real[b]*s;
        real[b]=real[a]-re;imag[b]=imag[a]-im;real[a]+=re;imag[a]+=im;
      }
    }
    const k=this.smoothingTimeConstant,min=this.minDecibels,range=1/(this.maxDecibels-min);
    for(let i=0;i<magnitudes.length;i++){
      // As realtime_analyser.cc: the DC bin's imaginary part is zeroed, the smoothed magnitude is float32 and restarts
      // at 0 when it is not finite, and 20·log10 is float32 arithmetic scaled to bytes in double, in this order.
      const smoothed=Math.fround(k*magnitudes[i]+(1-k)*Math.hypot(Math.fround(real[i]),i?Math.fround(imag[i]):0)/n);
      magnitudes[i]=Number.isFinite(smoothed)?smoothed:0;
      const scaled=255*(Math.fround(20*Math.fround(Math.log10(magnitudes[i])))-min)*range;
      out[i]=scaled>255?255:scaled>0?scaled:0;
    }
    return out;
  }
}

// The body of microphone().features(), given what the analyser returned.
export function microphoneFeatures(samples,spectrum){
  let sum=0,weighted=0,total=0;
  for(let i=0;i<samples.length;i++)sum+=samples[i]*samples[i];
  for(let i=0;i<spectrum.length;i++){weighted+=spectrum[i]*i;total+=spectrum[i]}
  const loudness=Math.sqrt(sum/samples.length),centroid=total?weighted/total/spectrum.length:0;
  return{loudness,centroid,activity:Math.min(1,loudness*12),arousal:Math.min(1,loudness*8+centroid*.3),valence:Math.max(0,Math.min(1,.7-centroid*.35))};
}

export const featureMessages=features=>Object.entries(FEATURE_ADDRESSES).map(([name,address])=>({address,args:[features[name]]}));

// AnalyserNode down-mix to mono with channelInterpretation "speakers"; other layouts keep the first channel (discrete).
function monoReader(channels){
  const [a,b,c,,e,f]=channels;
  if(channels.length===2)return i=>.5*(a[i]+b[i]);
  if(channels.length===4)return i=>.25*(a[i]+b[i]+c[i]+channels[3][i]);
  if(channels.length===6)return i=>SQRT_HALF*(a[i]+b[i])+c[i]+.5*(e[i]+f[i]);
  return i=>a[i];
}

export function clipStartSeconds(clip={},transport,lookahead=transport?.lookahead??LOOKAHEAD){
  const placement=clip.placement||{};
  if(Number.isFinite(placement.fileSeconds))return{seconds:placement.fileSeconds,exact:true};
  if(Number.isFinite(clip.startFileSeconds))return{seconds:clip.startFileSeconds,exact:true};
  if(Number.isFinite(placement.renderSeconds))return{seconds:placement.renderSeconds-lookahead,exact:true};
  const resolved=clip.at&&typeof transport?.resolvePosition==='function'?transport.resolvePosition(clip.at):null;
  return resolved?{seconds:resolved.musicSeconds,exact:resolved.exact!==false}:null;
}

// Linear ramps from 0 over fadeIn and back to 0 over fadeOut; overlapping fades take the lower ramp.
export function clipGainAt(seconds,{gain=1,fadeIn=0,fadeOut=0},duration){
  if(!(seconds>=0&&seconds<duration))return 0;
  let shape=1;
  if(fadeIn>0)shape=Math.min(shape,seconds/fadeIn);
  if(fadeOut>0)shape=Math.min(shape,(duration-seconds)/fadeOut);
  return gain*shape;
}

// Adds the clip's audible mono signal for file frames [frame, frame + out.length) into out. Starts snap to the
// nearest frame: an interpolating fractional delay would dull the top octave the byte spectrum measures.
export function clipSource({clip,decoded,sampleRate,transport,lookahead}){
  const channels=decoded?.channels;
  if(!Array.isArray(channels)||!channels.length||typeof channels[0]?.length!=='number')throw new TypeError(`Clip "${clip?.id}" needs decoded PCM channels for 'features' hearing`);
  // Both engines decode clips at the render rate (decodeAudioData does, decodeAudioFile is given it); resampling here would add images the dB spectrum shows.
  if(decoded.sampleRate!==sampleRate)throw new RangeError(`'features' hearing needs clip "${clip.id}" decoded at the render rate ${sampleRate}, not ${decoded.sampleRate}`);
  const frames=channels[0].length,offset=Math.max(0,Math.round((Number(clip.offsetSeconds)||0)*sampleRate)),
    duration=clip.durationSeconds==null?Math.max(0,(frames-offset)/sampleRate):Number(clip.durationSeconds),mono=monoReader(channels),
    fader=Number.isFinite(clip.mix?.gain)?clip.mix.gain:1;
  let start=null;
  const resolve=()=>{if(start?.exact)return start.seconds;const found=clipStartSeconds(clip,transport,lookahead);if(found)start=found;return start?.seconds??null};
  return{
    clip,duration,
    get startSeconds(){return resolve()},
    get endSeconds(){const seconds=resolve();return seconds==null?null:seconds+duration},
    addTo(out,frame){
      const seconds=resolve();if(seconds==null)return out;
      const first=frame-Math.round(seconds*sampleRate);
      for(let i=0;i<out.length;i++){
        const elapsed=first+i,index=elapsed+offset,level=index<frames?fader*clipGainAt(elapsed/sampleRate,clip,duration):0;
        if(level)out[i]+=level*mono(index);
      }
      return out;
    },
    // `count` samples of the clip's audible signal from `fromSeconds` after its start, wherever it is placed (for
    // foresight: the whole take, known before it sounds).
    readClip(fromSeconds,count){
      const out=new Float32Array(count),first=Math.round(fromSeconds*sampleRate);
      for(let i=0;i<count;i++){
        const elapsed=first+i,index=elapsed+offset,level=elapsed>=0&&index<frames?fader*clipGainAt(elapsed/sampleRate,clip,duration):0;
        if(level)out[i]=level*mono(index);
      }
      return out;
    },
  };
}

const isBeatStart=(tick,clock,transport)=>{
  if(typeof clock?.beatStart==='boolean')return clock.beatStart;
  const state=clock&&Number.isInteger(clock.tickInBar)?clock:transport?.tick===tick?transport:null,subdivision=state?.meter?.subdivision||transport?.meter?.subdivision;
  // AudioAnalyzerBot's own default clock when nothing better is known.
  return state&&subdivision?state.tickInBar%subdivision===0:tick%4===0;
};

class ListeningRoom {
  constructor(sampleRate,options){Object.assign(this,{sampleRate,sources:new Map,analyser:new AnalyserFrames(options),lastTick:null,open:false});this.mix=new Float64Array(this.analyser.fftSize);this.samples=new Float32Array(this.analyser.fftSize);this.spectrum=new Uint8Array(this.analyser.frequencyBinCount)}
  hear({tick,musicSeconds,clock},transport){
    if(!Number.isInteger(tick)||tick<0)throw new TypeError(`'features' hearing needs a tick number, not ${tick}`);
    if(tick===this.lastTick)return[];
    this.lastTick=tick;
    if(!isBeatStart(tick,clock,transport))return[];
    const seconds=Number.isFinite(musicSeconds)?musicSeconds:transport?.secondsAtTick?.(tick);
    if(!Number.isFinite(seconds))throw new TypeError(`'features' hearing needs musicSeconds for tick ${tick}`);
    const frame=Math.round(seconds*this.sampleRate),end=frame+this.mix.length;
    if(!this.open&&![...this.sources.values()].some(({startSeconds})=>startSeconds!=null&&Math.round(startSeconds*this.sampleRate)<end))return[];
    this.open=true;this.mix.fill(0);
    for(const source of this.sources.values())source.addTo(this.mix,frame);
    this.samples.set(this.mix);
    return featureMessages(microphoneFeatures(this.samples,this.analyser.byteFrequencyData(this.samples,this.spectrum)));
  }
}
const rooms=new WeakMap;
const roomFor=(transport,sampleRate)=>{
  if(!transport||typeof transport!=='object')return new ListeningRoom(sampleRate,ANALYSER_DEFAULTS);
  let room=rooms.get(transport);
  if(!room)rooms.set(transport,room=new ListeningRoom(sampleRate,ANALYSER_DEFAULTS));
  else if(room.sampleRate!==sampleRate)throw new RangeError(`'features' hearing on one transport needs one sample rate (${room.sampleRate}, not ${sampleRate})`);
  return room;
};

export function featuresHearing({clip,decoded,spec,transport}={}){
  if(!clip||typeof clip!=='object')throw new TypeError("'features' hearing needs a clip");
  const sampleRate=spec?.sampleRate||decoded?.sampleRate;
  if(!(sampleRate>0))throw new TypeError(`'features' hearing for clip "${clip?.id}" needs spec.sampleRate`);
  const room=roomFor(transport,sampleRate),source=clipSource({clip,decoded,sampleRate,transport});
  room.sources.set(clip.id??room.sources.size,source);
  return{
    name:'features',
    // File seconds after which this clip is silent; calling onTick through the next beat lets listeners hear it stop.
    get endSeconds(){return source.endSeconds},
    onTick(context={}){return room.hear(context,transport)},
  };
}

registerHearing('features',featuresHearing);
