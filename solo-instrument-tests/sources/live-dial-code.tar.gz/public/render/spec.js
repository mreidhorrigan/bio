import {readEnsembleLink as readLink} from '../shared/ensemble-link.js';
import {specSettings} from '../shared/spec-settings.js';
import {resolveBotId} from '../framework/bot-registry.js';
import {validateProtocolArgs} from '../shared/protocol-schemas.js';
import pluginConfig from '../shared/plugin-config.js';
import {FX_DEFAULTS,effectSettings} from '../shared/sound-settings.js';
import {tempoFollowingOptions} from '../shared/estimation/tempo-influence.js';
import {listeningOptions} from '../shared/estimation/listening-options.js';
import {AUTO_MIX} from '../../experiments/mix-desk/auto-mix.js';
import {DUTIES,DYNAMICS,LIVE_DESK,PINK} from '../../experiments/mix-desk/live-desk.js';
import {PLACEMENT} from '../../experiments/mix-desk/placement.js';
import {SUBMIX} from '../../experiments/mix-desk/submix.js';
import {LIVE_AUTO_MIX} from '../../experiments/mix-desk/live-auto-mix.js';
import {DEFAULT_METERING,METERING_MODES} from '../../experiments/mix-desk/metering.js';
import {DEFAULT_SEED,openingTime,phraseBarsFor,tempoFor} from '../shared/opening-time.js';
import {normalizeMetricReading,readingTempoWindow} from '../shared/meter-reading.js';
import {sectionLevels} from '../shared/metric-home/sections.js';
import {maskingPermission,mixIntention} from '../shared/mix-intention.js';
import {APPROACH_NAMES} from '../shared/mix-approaches.js';
import {AXIS_NAMES} from '../shared/aesthetic.js';
import {listOutputFormats} from './outputs.js';
import {DURATION_DEFAULTS,durationPolicy} from '../shared/composition-duration.js';
import {FEELS,expressionProfile,feelLocation} from '../shared/performance-timing.js';
import {RHYTHM_VOCABULARY,meterOfTala,withClave} from '../shared/rhythm-vocabulary.js';
import {TEMPO_LIMITS,clockTempo,tempoRange} from '../shared/tempo-range.js';
import {engineMetadata} from './engines.js';
import {normalizeArrangement,arrangementDocument} from '../shared/arrangement.js';

export const RENDER_SPEC_VERSION=1;
export {DEFAULT_SEED};
// Three and a half minutes of music unless the spec says otherwise: long enough to be a piece,
// short enough to render in seconds. The tail is added on top.
export const DEFAULT_LENGTH_SECONDS=210;
export const BOT_OUTPUTS=Object.freeze(['synth','samples','midi','none']),STEM_KINDS=Object.freeze(['bots','clips','returns']);
// What a render writes when outputs.stems is not given. 'returns' (everything in the mix no stem holds: the shared
// effects' returns) is asked for by name, so a render's files are what they were unless someone wants it.
export const DEFAULT_STEM_KINDS=Object.freeze(['bots','clips']);
// Where a stem is taken from the mixer channel.
//   'channel' the channel as it sounds in the mix: stereo, after its inserts, pan and fader
//   'object'  the source itself: mono, after its inserts, before pan and fader -- what a
//             spatialiser wants, since it places a mono signal and cannot place a panned pair
export const STEM_TAPS=Object.freeze(['channel','object']);
// Where the mix file is taken: the mix bus, as always (the delivery stage, render/master.mjs, finds the
// level later), or the mix as a listener hears it, after the bus compressor, the trim and the limiter.
export const MIX_TAPS=Object.freeze(['bus','delivered']);
export const DEFAULT_DESK_ID='mh_DeskBOT';
const TOP=['version','seed','sampleRate','engine','length','tailSeconds','preroll','transport','ensemble','effects','bots','clips','cues','outputs','desk','autoMix','samples','follow','foresight','labels','audience','character','bowedModel','windModel','arrangement'];
// The physical models a render's bowed strings may play (render/node/physical-strings.mjs; offline, node engine only):
// Artifastring, or NESS's bowed string, the shared comparison, played from the same actions and heard through the same
// body (render/synthesis/workers/ness_bowed.py).
export const BOWED_MODELS=Object.freeze(['artifastring','ness']);
// Offline, the winds and brass on their physical models ('models', the default), the woodwinds on their keyed bodies
// ('bodies': each breath group fingered on its tone holes), or their recordings (render/node/physical-models.mjs
// withWindModels).
export const WIND_MODEL_CHOICES=Object.freeze(['models','recordings','bodies']);
// What a bot that owns a bank of recordings does when the spec does not say.
// "prefer" plays the recordings; "synth" takes the bot's first declared mode,
// which is what a share link does and what every render did before this field
// existed. Preferring them is the default because a bot's samples ARE that
// bot's sound — a synthesized stand-in is the substitute, not the other way
// round — and rendering the substitute by default quietly delivered the wrong
// instrument for every one of the fifteen bots that owns recordings.
export const SAMPLE_PREFERENCES=Object.freeze(['prefer','synth']);
const DESK=['id','channels','duties','protect','rules','options','metering','approach','character','kits','intention','permissions'],DESK_RULE_GROUPS={dynamics:DYNAMICS,pink:PINK,placement:PLACEMENT,submix:SUBMIX};
const BOT=['id','key','randomKey','output','mix','join','leave','loadOnly','muted','synth','synthesizer','synthOptions','samplePreset','settings','label','physical'];
// A part's name for its audience (a bot's label, the plans staff's): printed as it is, up to this many characters.
const LABEL_LENGTH=40;
const label=(value,path,fail)=>{const text=typeof value==='string'?value.trim():'';if(!text||text.length>LABEL_LENGTH||/[\u0000-\u001f]/.test(text)){fail(path,`must be a name of 1-${LABEL_LENGTH} characters`);return null}return text};
const CLIP=['id','file','at','offsetSeconds','durationSeconds','gain','mix','fadeIn','fadeOut','hear','cues'];
// The bots a conductor can follow, as live: they hear a performer and report it.
export const FOLLOW_SOURCES=Object.freeze(['listener','midiInput','profile_clodbot']);
const FOLLOW=['bot','key','tempo','harmony','listening','also'];
const OUTPUTS=['dir','mix','stems','stemTap','mixTap','format','midi','decisions','notes','manifest','maxTailSeconds','maxRenderSeconds'];
// `cycle` names a tala of the rhythm vocabulary (shared/rhythm-vocabulary.js), counted in `nadai` at `speed`; `tala`
// the same as the meter space names it (shared/meter-space.js drawMeter), so a meter it draws plays as drawn; `clave`
// names a clave laid on the bar.
const METER=['numerator','denominator','subdivision','phraseBars','groups','rhythm','label','pulsesPerBar','cycle','tala','nadai','speed','clave','tempoUnit','sections','sectionDynamics','metricReading','fixedDenominator'];
const FORMS=['bar','tick','seconds'],LENGTHS=['bars','seconds','ticks'],SENDS=['reverb','delay','compression','plugin'],GENERATORS=['sine','noise','silence'];
// Keys follow the live link and session rules so a spec can always be joined.
const KEY=/^[A-Za-z0-9_-]{1,40}$/,CLIP_ID=/^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$/,NAME=/^[A-Za-z][A-Za-z0-9_.-]{0,63}$/,SYNTH=/^[a-z][a-z0-9-]{0,63}$/;
const POSITION_HELP='{bar, beat?}, {tick} or {seconds}',MAX_DRY=1.5;

export class RenderSpecError extends Error {
  constructor(problems){super(`Invalid render spec:\n${problems.map(({path,message})=>`  ${path||'spec'}: ${message}`).join('\n')}`);this.name='RenderSpecError';this.problems=problems}
}

const isObject=value=>value!==null&&typeof value==='object'&&!Array.isArray(value);
const join=(path,key)=>typeof key==='number'?`${path}[${key}]`:path?`${path}.${key}`:key;
const quoted=items=>items.map(item=>JSON.stringify(item)).join(', ');
const freeze=value=>{if(value&&typeof value==='object'){for(const item of Object.values(value))freeze(item);Object.freeze(value)}return value};
const before=(a,b)=>'tick' in a&&'tick' in b?a.tick<b.tick:'seconds' in a&&'seconds' in b?a.seconds<b.seconds:'bar' in a&&'bar' in b?a.bar<b.bar||a.bar===b.bar&&a.beat<b.beat:true;

function checker(){
  const problems=[],fail=(path,message)=>{problems.push({path,message})};
  const fields=(value,path,keys,reported=[])=>{
    if(value===undefined)return {};
    if(!isObject(value)){fail(path,'must be an object');return {}}
    // "$schema" / "//" keys are the usual JSON comment conventions.
    for(const key of Object.keys(value))if(!keys.includes(key)&&!reported.includes(key)&&!key.startsWith('$')&&!key.startsWith('//'))fail(join(path,key),`is not a known field (expected ${keys.join(', ')})`);
    return value;
  };
  const number=(value,path,{fallback,min=-Infinity,max=Infinity,integer=false,positive=false}={})=>{
    if(value===undefined&&fallback!==undefined)return fallback;
    const range=positive?' greater than 0':min>-Infinity&&max<Infinity?` from ${min} to ${max}`:min>-Infinity?` of at least ${min}`:'';
    const wanted=`${integer?'an integer':'a number'}${range}`;
    if(value===undefined)fail(path,`is required (${wanted})`);
    else if(typeof value!=='number'||!Number.isFinite(value)||integer&&!Number.isInteger(value)||value<min||value>max||positive&&value<=0)fail(path,`must be ${wanted}`);
    else return value;
    return fallback;
  };
  const boolean=(value,path,fallback)=>{if(value===undefined)return fallback;if(typeof value!=='boolean')fail(path,'must be true or false');return value===true};
  const choice=(value,path,choices,fallback)=>{
    if(value===undefined&&fallback!==undefined)return fallback;
    if(!choices.includes(value))fail(path,`${value===undefined?'is required:':'must be'} one of ${quoted(choices)}`);
    return value;
  };
  const array=(value,path)=>{if(value===undefined)return [];if(Array.isArray(value))return value;fail(path,'must be an array');return []};
  const json=(value,path,parents=new Set)=>{
    if(value===null||typeof value==='string'||typeof value==='boolean'||typeof value==='number'&&Number.isFinite(value))return value;
    const array=Array.isArray(value);
    if(!array&&Object.prototype.toString.call(value)!=='[object Object]'){fail(path,'must be plain JSON (string, finite number, boolean, null, array or object)');return null}
    if(parents.has(value)){fail(path,'refers to itself (JSON cannot hold cycles)');return null}
    parents.add(value);
    const copy=array?value.map((item,index)=>json(item,join(path,index),parents)):Object.fromEntries(Object.entries(value).map(([key,item])=>[key,json(item,join(path,key),parents)]));
    parents.delete(value);return copy;
  };
  const position=(value,path)=>{
    if(!isObject(value)){fail(path,value===undefined?`is required: ${POSITION_HELP}`:`must be a position: ${POSITION_HELP}`);return undefined}
    const forms=FORMS.filter(key=>Object.hasOwn(value,key));
    if(forms.length!==1){fail(path,forms.length?`must use exactly one of bar, tick or seconds, not ${forms.join(' and ')}`:`must be a position: ${POSITION_HELP}`);return undefined}
    const [form]=forms;
    if(form!=='bar'&&Object.hasOwn(value,'beat'))fail(join(path,'beat'),'is only allowed with bar');
    fields(value,path,form==='bar'?['bar','beat']:[form],['beat']);
    if(form==='bar')return {bar:number(value.bar,join(path,'bar'),{integer:true,min:1}),beat:number(value.beat,join(path,'beat'),{fallback:1,min:1})};
    if(form==='tick')return {tick:number(value.tick,join(path,'tick'),{integer:true,min:0})};
    return {seconds:number(value.seconds,join(path,'seconds'),{min:0})};
  };
  // gain is the mixer track's dry fader, which sound-settings.js clamps to 0..1.5; out-of-range values are reported, not clamped.
  const mix=(value,path)=>{
    const source=fields(value,path,['pan','gain',...SENDS]),result={pan:number(source.pan,join(path,'pan'),{fallback:0,min:-1,max:1}),gain:number(source.gain,join(path,'gain'),{fallback:1,min:0,max:MAX_DRY})};
    for(const key of SENDS)if(source[key]!==undefined)result[key]=number(source[key],join(path,key),{min:0,max:1});
    return result;
  };
  const cues=(value,path)=>array(value,path).map((cue,index)=>{
    const at=join(path,index);
    if(!isObject(cue)){fail(at,'must be a cue {at, address, args?}');return {}}
    fields(cue,at,['at','address','args']);
    if(typeof cue.address!=='string'||!/^\/\S+$/.test(cue.address))fail(join(at,'address'),'must be an address such as "/broadcast/notepool"');
    if(cue.args!==undefined&&!Array.isArray(cue.args))fail(join(at,'args'),'must be an array');
    // A cue is a protocol message: its arguments take its address's shape (protocol-schemas.js), or the ensemble would
    // refuse it mid-render.
    else if(typeof cue.address==='string'){const checked=validateProtocolArgs(cue.address,cue.args??[]);if(!checked.valid)fail(join(at,'args'),`do not fit ${cue.address}: ${checked.errors.join('; ')}`)}
    return {at:position(cue.at,join(at,'at')),address:cue.address,args:Array.isArray(cue.args)?json(cue.args,join(at,'args')):[]};
  });
  return {problems,fail,fields,number,boolean,choice,array,json,position,mix,cues};
}

export function normalizeRenderSpec(spec,options){
  // sampleBanks(bank) answers whether this environment can actually play that
  // bank. It is resolved HERE, at normalization, rather than left to the
  // engine, so the normalized spec — and the manifest that records it — says
  // which instrument really played. Left out (the browser, where the server
  // serves /samples/), every bank is assumed present.
  const {agents,readEnsembleLink=readLink,meterApi=globalThis.MusebotMeter,engines,hearings,synthesizers,
    sampleBanks=null,formats=listOutputFormats()}=options||{};
  if(!agents||typeof agents!=='object')throw new TypeError('normalizeRenderSpec(spec, {agents}) needs the agent definitions');
  if(!isObject(spec))throw new RenderSpecError([{path:'',message:'must be an object'}]);
  const check=checker(),{problems,fail,fields,number,boolean,choice,array,json,position,mix}=check;
  fields(spec,'',TOP);
  if(spec.version!==RENDER_SPEC_VERSION)fail('version',spec.version===undefined?'is required and must be 1':`must be 1, not ${JSON.stringify(spec.version)}`);
  const sampleRate=number(spec.sampleRate,'sampleRate',{fallback:48000,integer:true,min:8000,max:384000});
  const engine=spec.engine===undefined?'node':spec.engine;
  if(typeof engine!=='string'||!NAME.test(engine))fail('engine','must be an engine name such as "node"');
  else if(engines&&!engines.includes(engine))fail('engine',`unknown engine "${engine}" (registered: ${engines.join(', ')||'none'})`);

  let length;
  if(spec.length===undefined)length={seconds:DEFAULT_LENGTH_SECONDS};
  else if(!isObject(spec.length))fail('length','must be an object: {bars}, {seconds} or {ticks}');
  else{
    const forms=LENGTHS.filter(key=>Object.hasOwn(spec.length,key));
    fields(spec.length,'length',[...LENGTHS,'untilEnding','policy']);
    if(forms.length!==1)fail('length',forms.length?`must use exactly one of bars, seconds or ticks, not ${forms.join(' and ')}`:'must have bars, seconds or ticks');
    else{
      length={[forms[0]]:number(spec.length[forms[0]],join('length',forms[0]),forms[0]==='seconds'?{positive:true}:{integer:true,min:1})};
      // untilEnding: the render is done at the ending the ensemble commits (a closing's bar, or a committed stop:
      // render-session.js hearEnding), its tail after; the length is then the most it plays.
      if(boolean(spec.length.untilEnding,'length.untilEnding',false))length.untilEnding=true;
      // policy: how the ensemble may negotiate the length (docs/COMPOSITION_DURATION.md: the envelope, the prices, the
      // bounds), a human's setting that reaches every bot with the render's end. Only the settings it names are kept;
      // the rest are the bots' own.
      if(spec.length.policy!==undefined){
        if(!isObject(spec.length.policy))fail('length.policy','must be an object of duration policy settings');
        else{
          const named=Object.fromEntries(Object.entries(fields(spec.length.policy,'length.policy',Object.keys(DURATION_DEFAULTS)))
            .filter(([key])=>Object.hasOwn(DURATION_DEFAULTS,key)));
          try{durationPolicy(named);length.policy=Object.freeze(named)}
          catch(error){fail('length.policy',error.message)}
        }
      }
    }
  }

  const source=fields(spec.transport,'transport',['bpm','tempo','meter','lockTempo','lockMeter','feel','expression']);
  // tempo: the rate contract's score coordinate, {bpm, beatUnit} (a tempo of a named note, '1/4' a quarter), for a meter
  // whose tempo counts another note than its own: 107/16 at a quarter of 120 (RESEARCH_BACKLOG P1, "Extreme meters, made
  // perceptible"). The meter then carries the note (tempoUnit), bpm is the clock's, in the meter's own notes (480
  // sixteenths), and the range is the named note's, the rate contract's 30-720 (shared/tempo-range.js). Without it, bpm
  // counts the meter's own note, 40-220, as ever. A normalized spec keeps both, and a bpm given beside a tempo must be its.
  let coordinate=null;
  if(source.tempo!==undefined){
    const tempo=fields(source.tempo,'transport.tempo',['bpm','beatUnit']),unit=Number(/^1\/(\d+)$/.exec(String(tempo.beatUnit??'1/4'))?.[1]);
    if(![1,2,4,8,16,32,64].includes(unit))fail('transport.tempo.beatUnit','must be a note: 1/1, 1/2, 1/4 ... 1/64');
    else coordinate={bpm:number(tempo.bpm,'transport.tempo.bpm',{fallback:120,min:TEMPO_LIMITS.coordinate[0],max:TEMPO_LIMITS.coordinate[1]}),beatUnit:`1/${unit}`,unit};
  }
  // (The range from the meter as given, so that the tempo's problems are reported before the meter's, as ever.)
  const asWritten=isObject(source.meter)?source.meter:{},unit=coordinate?.unit??([1,2,4,8,16,32,64].includes(asWritten.tempoUnit)?asWritten.tempoUnit:null);
  const range={denominator:Number.isInteger(asWritten.denominator)&&asWritten.denominator>0?asWritten.denominator:4,...(unit?{tempoUnit:unit}:{})};
  const [lowest,highest]=tempoRange(range),clock=coordinate?clockTempo(coordinate.bpm,range):null;
  if(clock!==null&&source.bpm!==undefined&&Math.abs(Number(source.bpm)-clock)>1e-9)fail('transport.bpm',`must be the tempo's in the meter's own notes (${clock}), or left out`);
  // What it is not given is the piece's opening's, filled from the seed once the seed is known (openTransport).
  const timeGiven={meter:isObject(source.meter),phrase:isObject(source.meter)&&source.meter.phraseBars!==undefined,bpm:clock!==null||source.bpm!==undefined};
  const bpm=clock??(timeGiven.bpm?number(source.bpm,'transport.bpm',{min:lowest,max:highest}):null);
  const meter=normalizeMeter(coordinate?{...asWritten,tempoUnit:coordinate.unit}:source.meter,'transport.meter',check,meterApi);
  const transport={bpm,meter,
    ...(coordinate?{tempo:{bpm:coordinate.bpm,beatUnit:coordinate.beatUnit}}:{}),
    lockTempo:boolean(source.lockTempo,'transport.lockTempo',false),lockMeter:boolean(source.lockMeter,'transport.lockMeter',false)};
  // feel: the ensemble's timing feel (docs/PERFORMANCE_TIMING.md: 'straight', 'jazz', 'funk', 'hiphop', 'warped', or a
  // point of their space: a blend by weight, {jazz: .5, straight: .5}, or every dimension given), which reaches every bot
  // that plays with the performance layer.
  if(source.feel!==undefined){
    if(!feelLocation(source.feel))fail('transport.feel',`must be one of ${FEELS.join(', ')}, a blend of them by weight, or a point of their space (performance-timing.js FEEL_SPACE)`);
    else transport.feel=source.feel;
  }
  // expression: the rubato report's baseline profiles, each by itself beside the feel (docs/PERFORMANCE_TIMING.md §9):
  // {lean: {instrument, ms, shape: 'arch' | 'onBeats'}, placement: {instrument: ms, or {beat: ms}}}.
  if(source.expression!==undefined&&source.expression!==null){
    try{transport.expression=expressionProfile(source.expression)}catch(error){fail('transport.expression',error.message)}
  }

  const ensemble=fields(spec.ensemble,'ensemble',['link']);
  let link=null,linked=null;
  if(ensemble.link!==undefined&&ensemble.link!==null){
    if(typeof ensemble.link!=='string'||!ensemble.link.trim())fail('ensemble.link','must be an ensemble share link or null');
    else{
      link=ensemble.link;
      try{linked=readEnsembleLink(link,agents);if(!linked)fail('ensemble.link','is not an ensemble share link (it has no e= or bots= parameter)')}
      catch(error){fail('ensemble.link',error.message)}
    }
  }
  const seed=spec.seed===undefined?linked?.seed??DEFAULT_SEED:number(spec.seed,'seed',{integer:true,min:0,max:0xffffffff});
  openTransport(transport,timeGiven,Number.isInteger(seed)?seed:DEFAULT_SEED,meter=>normalizeMeter(meter,'transport.meter',check,meterApi));

  const samplePreference=choice(spec.samples,'samples',SAMPLE_PREFERENCES,'prefer');
  // A default must never name an output the chosen engine cannot render, or a
  // spec would be born invalid — which is exactly what the score engine, whose
  // whole point is to render no audio, would otherwise get handed.
  const declared=(()=>{
    const capabilities=engineMetadata(engine)?.capabilities;
    const resolved=typeof capabilities==='function'?capabilities():capabilities;
    return Array.isArray(resolved?.outputs)?resolved.outputs:null;   // null: unregistered, so allow
  })();
  const samples={preference:samplePreference,
    playable:!declared||declared.includes('samples'),
    available:typeof sampleBanks==='function'?sampleBanks
      :Array.isArray(sampleBanks)?bank=>sampleBanks.includes(bank):()=>true};

  // Each bot's randomKey, the key its draws are made under (its sound seed's, its behaviour's, its instance's): one the
  // spec gives, else its own key where the spec gives one, else its ordinal among the spec's bots of its id, the first
  // free one, so that its draws hold whatever other bots the spec adds, leaves out or reorders (the implementation
  // dossier's A002). The key itself, the room's name for it, still defaults to its position. Unique among the bots of an
  // id.
  const normalizeBots=(list,path)=>{
    const keys=new Map,drawn=new Map,takenBy=id=>drawn.get(id)??drawn.set(id,new Map).get(id);
    const asked=index=>{const value=list[index];return isObject(value)?value:{}};
    const bots=list.map((value,index)=>{
      const bot=normalizeBot(value,index,join(path,index),check,agents,synthesizers,samples),other=keys.get(bot.key);
      if(other!==undefined)fail(join(join(path,index),'key'),`"${bot.key}" is already used by ${join(path,other)}; keys must be unique (they default to the 1-based position)`);
      else if(typeof bot.key==='string')keys.set(bot.key,index);
      // (A key the spec gives keys its draws, unique among its id's as keys are among all.)
      if(typeof bot.id==='string'&&asked(index).randomKey===undefined&&asked(index).key!==undefined&&typeof bot.key==='string'){takenBy(bot.id).set(bot.key,index);bot.randomKey=bot.key}
      return bot;
    });
    bots.forEach((bot,index)=>{
      const own=asked(index).randomKey,at=join(join(path,index),'randomKey');
      if(own===undefined||typeof bot.id!=='string')return;
      const taken=takenBy(bot.id);
      if(typeof own!=='string'||!KEY.test(own))fail(at,'must be a string of 1-40 letters, digits, "_" or "-"');
      else if(taken.has(own))fail(at,`"${own}" already keys the draws of ${join(path,taken.get(own))}, another ${bot.id}`);
      else{taken.set(own,index);bot.randomKey=own}
    });
    const ordinals=new Map;
    bots.forEach((bot,index)=>{
      if(typeof bot.id!=='string'||bot.randomKey!==undefined||asked(index).randomKey!==undefined)return;
      const taken=takenBy(bot.id);let ordinal=(ordinals.get(bot.id)??0)+1;while(taken.has(String(ordinal)))ordinal++;
      ordinals.set(bot.id,ordinal);taken.set(String(ordinal),index);bot.randomKey=String(ordinal);
    });
    return bots;
  };
  const given=array(spec.bots,'bots');
  let bots;
  if(linked){
    bots=normalizeBots(linked.bots.map(linkBot),'ensemble.link.bots');
    // A normalized spec keeps both; allow that only when they agree.
    if(given.length&&JSON.stringify(normalizeBots(given,'bots'))!==JSON.stringify(bots))fail('bots','cannot be combined with ensemble.link; give one or the other');
  }else{
    if(link&&given.length)fail('bots','cannot be combined with ensemble.link; give one or the other');
    bots=normalizeBots(given,'bots');
  }

  const clipIds=new Map;
  const clips=array(spec.clips,'clips').map((value,index)=>{
    const path=join('clips',index),at=key=>join(path,key);
    if(!isObject(value)){fail(path,'must be a clip {id, file, at, ...}');return {}}
    fields(value,path,CLIP);
    if(typeof value.id!=='string'||!CLIP_ID.test(value.id))fail(at('id'),'must be 1-64 letters, digits, "_", "." or "-", starting with a letter or digit');
    else{
      // Clip ids name stem files, which may live on a case-insensitive disk.
      const folded=value.id.toLowerCase(),other=clipIds.get(folded);
      if(other!==undefined)fail(at('id'),`"${value.id}" is already used by clips[${other}] (ignoring case)`);else clipIds.set(folded,index);
    }
    return {id:value.id,file:clipFile(value.file,at('file'),check,sampleRate),at:position(value.at,at('at')),
      offsetSeconds:number(value.offsetSeconds,at('offsetSeconds'),{fallback:0,min:0}),
      durationSeconds:value.durationSeconds===null||value.durationSeconds===undefined?null:number(value.durationSeconds,at('durationSeconds'),{positive:true}),
      gain:number(value.gain,at('gain'),{fallback:1,min:0}),mix:mix(value.mix,at('mix')),
      fadeIn:number(value.fadeIn,at('fadeIn'),{fallback:.005,min:0}),fadeOut:number(value.fadeOut,at('fadeOut'),{fallback:.05,min:0}),
      hear:normalizeHear(value.hear,at('hear'),check,hearings),cues:check.cues(value.cues,at('cues'))};
  });

  const out=fields(spec.outputs,'outputs',OUTPUTS);
  if(out.dir!==undefined&&out.dir!==null&&(typeof out.dir!=='string'||!out.dir.trim()))fail('outputs.dir','must be a directory path or null');
  let stems=[...DEFAULT_STEM_KINDS];
  if(out.stems!==undefined){
    if(!Array.isArray(out.stems))fail('outputs.stems',`must be an array of ${quoted(STEM_KINDS)} ([] for none)`);
    else{
      out.stems.forEach((kind,index)=>{if(!STEM_KINDS.includes(kind))fail(join('outputs.stems',index),`must be one of ${quoted(STEM_KINDS)}`);else if(out.stems.indexOf(kind)!==index)fail(join('outputs.stems',index),`repeats "${kind}"`)});
      stems=STEM_KINDS.filter(kind=>out.stems.includes(kind));
    }
  }
  const mixTap=choice(out.mixTap,'outputs.mixTap',MIX_TAPS,'bus');
  const outputs={dir:typeof out.dir==='string'?out.dir:null,mix:boolean(out.mix,'outputs.mix',true),stems,stemTap:choice(out.stemTap,'outputs.stemTap',STEM_TAPS,'channel'),...(mixTap==='bus'?{}:{mixTap}),format:choice(out.format,'outputs.format',formats,'float32'),
    // One MIDI Clip File per bot, beside its stem: what that bot PLAYED, as MIDI
    // 2.0 UMP. Not a re-transcription of the audio -- it is the same packet
    // stream the synthesizer was handed, so per-note bend, pressure, controller
    // and 16-bit velocity survive, none of which notes.jsonl records.
    midi:boolean(out.midi,'outputs.midi',true),
    decisions:boolean(out.decisions,'outputs.decisions',true),notes:boolean(out.notes,'outputs.notes',true),manifest:boolean(out.manifest,'outputs.manifest',true)};
  // Limits for engines that render on (a ringing tail) or size a buffer up front (chrome); absent means the engine's default.
  if(out.maxTailSeconds!==undefined)outputs.maxTailSeconds=number(out.maxTailSeconds,'outputs.maxTailSeconds',{min:0});
  if(out.maxRenderSeconds!==undefined)outputs.maxRenderSeconds=number(out.maxRenderSeconds,'outputs.maxRenderSeconds',{positive:true});
  const effects=normalizeEffects(spec.effects,check,linked);
  // character (public/shared/aesthetic.js): the piece's stated character, which reaches the players, the desk and the
  // palette together (the extreme-aesthetics report's M4: a noise-based roar was heard out of place in a pitched piece
  // whose character only the desk had been told). The players hear it as /broadcast/character at the start; a desk that
  // names neither an approach nor a character of its own takes it; and the render session applies it to the bots'
  // shared configuration, as the page does.
  const character=spec.character===undefined?undefined:characterAxes(spec.character,'character',check);
  let desk=normalizeDesk(spec.desk,check,bots,clips);const autoMix=normalizeAutoMix(spec.autoMix,check);
  if(desk&&character&&desk.approach===undefined&&desk.character===undefined)desk={...desk,character};
  const follow=normalizeFollow(spec.follow,check,bots,transport);
  // audience "public": a render for public display, whose score and video show only the parts its audience hears (the
  // user: "Public videos should not show the harmony staff that makes no sound"). Otherwise every part is shown.
  if(spec.audience!==undefined&&spec.audience!=='public')fail('audience','must be "public" (a render for public display: its score shows only the parts that sound), or left out');
  // labels: the names of the parts no bot plays, for the audience -- {plans}, the staff of the chords and form above
  // the band (bots' own parts are named by their label).
  let labels=null;
  if(spec.labels!==undefined){
    if(!isObject(spec.labels))fail('labels','must be an object, such as {"plans": "Chords"}');
    else{check.fields(spec.labels,'labels',['plans']);const plans=spec.labels.plans===undefined?null:label(spec.labels.plans,'labels.plans',fail);if(plans)labels={plans}}
  }

  let arrangement=null;
  if(spec.arrangement!==undefined){
    try{arrangement=arrangementDocument(normalizeArrangement(spec.arrangement))}catch(error){fail('arrangement',error.message)}
    if(!transport.lockTempo||!transport.lockMeter)fail('arrangement','requires lockTempo and lockMeter: placements use the project clock');
    if(arrangement&&length?.seconds!==arrangement.endSeconds)fail('length','must equal arrangement.endSeconds');
  }
  const result={version:RENDER_SPEC_VERSION,seed,sampleRate,engine,length,tailSeconds:number(spec.tailSeconds,'tailSeconds',{fallback:4,min:0}),
    preroll:choice(spec.preroll,'preroll',['trim','keep'],'trim'),transport,ensemble:{link},samples:samplePreference,bots,clips,
    cues:[...check.cues(spec.cues,'cues'),...(character?check.cues([{at:{bar:1},address:'/broadcast/character',args:[{vector:character,describe:'the piece\'s stated character'}]}],'character'):[])],
    outputs,...(effects?{effects}:{}),...(arrangement?{arrangement}:{}),
    ...(character?{character}:{}),
    ...(spec.bowedModel!==undefined?{bowedModel:choice(spec.bowedModel,'bowedModel',BOWED_MODELS,undefined)}:{}),
    ...(spec.windModel!==undefined?{windModel:choice(spec.windModel,'windModel',WIND_MODEL_CHOICES,undefined)}:{}),
    ...(desk?{desk}:{}),...(autoMix?{autoMix}:{}),...(follow?{follow}:{}),...(labels?{labels}:{}),...(spec.audience==='public'?{audience:'public'}:{}),
    // foresight (foresight.js): the bots are given what each input clip holds before it sounds. For offline deployments
    // only: a render that stands for live performance must hear as a live room does. Kept only when on.
    ...(boolean(spec.foresight,'foresight',false)?{foresight:true}:{})};
  // (A page that plays them itself -- the studio page, its engines in WebAssembly -- says so: physicalEngines.)
  if(!(options?.physicalEngines??['node']).includes(engine)&&bots.some(bot=>bot.physical))fail('engine',`external physical models require ${(options?.physicalEngines??['node']).join(' or ')}`);
  if(outputs.stems.includes('bots'))stemCollisions(linked?'ensemble.link.bots':'bots',bots,fail);
  if(transport.lockMeter)lockedBeats(result,fail);
  if(problems.length)throw new RenderSpecError(problems);
  return freeze(result);
}

// The transport's time where the spec gives none, from the piece's opening (shared/opening-time.js; the owner, 1 October
// 2026: "fixing a default seed is ok, but all those other things need to be seed-derived; no default talas, et cetera"):
// no meter, the opening's (its groups and phrase with it); no tempo, one drawn for the meter. A default seed may be fixed
// (DEFAULT_SEED); these vary with it. A meter given in part is completed as every transport completes one (meter.cjs
// normalizeMeter), until that is made seed-derived for all of them at once (RESEARCH_BACKLOG, "A meter completed without
// written defaults").
function openTransport(transport,given,seed,complete){
  const time=openingTime(seed);
  if(!given.bpm)transport.bpm=given.meter?tempoFor(transport.meter,seed):time.bpm;
  // (A meter given without its phrase: whole bars about the opening's phrase seconds at its tempo, as the opening's own
  // phrase is made, never meter.cjs's written four bars (RESEARCH_BACKLOG, "A meter completed without written defaults"):
  // a 31-beat bar's four-bar phrase, a minute long, had held harmonypulse_clodbot to a chord a minute.)
  if(given.meter&&!given.phrase)transport.meter={...transport.meter,phraseBars:phraseBarsFor(transport.meter,transport.bpm,time.phraseSeconds)};
  if(given.meter){reviewTempo();return}
  // The opening's meter, completed as a spec's own is (its label, pulses and rhythm: meter.cjs), its phrase made for a
  // tempo the spec gives; a tala it opens in named as a spec names one (its cycle, which gives the transport its
  // gestures too), its beats, groups and ticks the cycle's own.
  const {tala,numerator,groups,subdivision,...opened}=time.meter;
  transport.meter=complete({...opened,...(tala?{cycle:tala}:{numerator,groups:[...groups],subdivision}),phraseBars:given.bpm?phraseBarsFor(time.meter,transport.bpm,time.phraseSeconds):time.meter.phraseBars});
  reviewTempo();
  function reviewTempo(){
    const meter=transport.meter,reading=meter.metricReading;if(!reading)return;
    const range=readingTempoWindow(meter,{candidate:true}),q=transport.bpm*4/meter.denominator;
    // A caller's tempo takes precedence. A prior publication action does not certify a new duration profile.
    if(reading.editorialAction.startsWith('PUBLISH_')&&(!range||q<range[0]||q>range[1]))meter.metricReading={...reading,
      editorialAction:'HOLD_FOR_REVIEW',reason:'The explicit tempo is outside this reading’s new-score duration preference; preserve timing and review support or alternatives.'};
  }
}

function normalizeMeter(value,path,{fail,fields,number,json},meterApi){
  const source=fields(value,path,METER),at=key=>join(path,key);
  const meter={numerator:number(source.numerator,at('numerator'),{fallback:4,integer:true,min:1,max:4096}),denominator:number(source.denominator,at('denominator'),{fallback:4,integer:true,min:1,max:4096}),
    subdivision:number(source.subdivision,at('subdivision'),{fallback:4,integer:true,min:1,max:96}),phraseBars:number(source.phraseBars,at('phraseBars'),{fallback:4,integer:true,min:1,max:1024})};
  // MusebotMeter.normalizeMeter silently replaces bad values; a render spec reports them instead.
  if(source.groups!==undefined){
    if(!Array.isArray(source.groups)||!source.groups.length||source.groups.some(item=>!Number.isInteger(item)||item<1))fail(at('groups'),'must be an array of positive integers');
    else if(source.groups.reduce((sum,item)=>sum+item,0)!==meter.numerator)fail(at('groups'),`must add up to the numerator (${meter.numerator})`);
    else meter.groups=[...source.groups];
  }
  if(source.rhythm!==undefined){if(isObject(source.rhythm))meter.rhythm=json(source.rhythm,at('rhythm'));else fail(at('rhythm'),'must be an object')}
  if(source.label!==undefined){if(typeof source.label==='string')meter.label=source.label;else fail(at('label'),'must be a string')}
  if(source.pulsesPerBar!==undefined&&source.pulsesPerBar!==meter.numerator*meter.subdivision)fail(at('pulsesPerBar'),`must equal numerator × subdivision (${meter.numerator*meter.subdivision})`);
  // tempoUnit: the note the tempo counts where it is not the meter's own (a note's denominator; transport.tempo sets it).
  if(source.tempoUnit!==undefined){if([1,2,4,8,16,32,64].includes(source.tempoUnit))meter.tempoUnit=source.tempoUnit;else fail(at('tempoUnit'),'must be a note\'s denominator: 1, 2, 4 ... 64')}
  // sections, sectionDynamics: a long bar's sections, level by level, and each top-level section's dynamic
  // (metric-home/sections.js, read here whether or not the clock is loaded); meterform_clodbot lays them where none are
  // given, and the piece's drawn opening carries the levels its groups nest in (opening-time.js).
  if(source.sections!==undefined){const levels=sectionLevels({numerator:meter.numerator,sections:source.sections});if(levels)meter.sections=levels.map(level=>[...level]);else fail(at('sections'),'must be levels of sections, each summing to the numerator and nesting in the one above')}
  if(source.sectionDynamics!==undefined){if(meter.sections&&Array.isArray(source.sectionDynamics)&&source.sectionDynamics.length===meter.sections[0].length&&source.sectionDynamics.every(value=>Number.isFinite(value)&&value>0&&value<=2))meter.sectionDynamics=[...source.sectionDynamics];else fail(at('sectionDynamics'),'must be one dynamic (0-2) for each top-level section')}
  // A named cycle sets the beats, groups, ticks to a beat and gestures, and a clave its onsets and direction: given
  // alongside what they set, those must agree.
  const named=kind=>Object.values(RHYTHM_VOCABULARY).filter(record=>record.kind===kind).map(record=>record.id);
  if(source.cycle!==undefined&&source.tala!==undefined&&source.cycle!==source.tala)fail(at('tala'),`names another cycle than cycle (${source.cycle}); give one`);
  const tala=source.cycle??source.tala;
  if(tala!==undefined){
    const record=RHYTHM_VOCABULARY[tala];
    if(record?.kind!=='tala')fail(at(source.cycle!==undefined?'cycle':'tala'),`must be one of ${quoted(named('tala'))}`);
    else try{
      const cycle=meterOfTala(record,{nadai:source.nadai??'caturasra',speed:source.speed??3,denominator:meter.denominator,phraseBars:meter.phraseBars});
      for(const key of ['numerator','subdivision'])if(source[key]!==undefined&&source[key]!==cycle[key])fail(at(key),`is the cycle's (${cycle[key]}); leave it out`);
      if(Array.isArray(source.groups)&&source.groups.join(',')!==cycle.groups.join(','))fail(at('groups'),`are the cycle's (${cycle.groups.join('+')}); leave them out`);
      Object.assign(meter,{numerator:cycle.numerator,groups:cycle.groups,subdivision:cycle.subdivision,vocabulary:cycle.vocabulary},source.label===undefined?{label:cycle.label}:{});
    }catch(error){fail(at(source.speed!==undefined?'speed':'nadai'),error.message)}
  }else for(const key of ['nadai','speed'])if(source[key]!==undefined)fail(at(key),'is a named cycle\'s; name one in cycle');
  if(source.clave!==undefined){
    const record=RHYTHM_VOCABULARY[source.clave];
    if(record?.kind!=='clave')fail(at('clave'),`must be one of ${quoted(named('clave'))}`);
    else try{Object.assign(meter,withClave(meter,record))}catch(error){fail(at('clave'),error.message)}
  }
  if(source.fixedDenominator!==undefined){if(typeof source.fixedDenominator==='boolean')meter.fixedDenominator=source.fixedDenominator;else fail(at('fixedDenominator'),'must be a boolean')}
  if(source.metricReading!==undefined){
    const reading=normalizeMetricReading(source.metricReading,meter.numerator,meter.groups??[]);
    if(reading)meter.metricReading=reading;else fail(at('metricReading'),'must declare positive intended beats, their matching notation groups, reference note and editorial action');
  }
  return typeof meterApi?.normalizeMeter==='function'?json(meterApi.normalizeMeter(meter),path):meter;
}

// Stems are named bots/<id>-<key>.wav, and keys "A" and "a" of one agent would overwrite each other on a case-insensitive disk.
function stemCollisions(path,bots,fail){
  const names=new Map;
  bots.forEach((bot,index)=>{
    if(typeof bot.id!=='string'||typeof bot.key!=='string')return;
    const name=`${bot.id}-${bot.key}`.toLowerCase(),other=names.get(name);
    if(other===undefined)names.set(name,index);
    // An exact repeat is already reported as a duplicate key.
    else if(bots[other].key!==bot.key)fail(join(join(path,index),'key'),`"${bot.key}" and ${join(path,other)}.key "${bots[other].key}" name the same stem file for "${bot.id}" on a case-insensitive disk; use keys that differ in more than case`);
  });
}

// With lockMeter the meter cannot change, so a beat past the end of its bar is known now rather than when the transport reaches it.
function lockedBeats({transport:{meter},bots,clips,cues},fail){
  const {numerator,subdivision}=meter;
  if(!Number.isInteger(numerator)||!Number.isInteger(subdivision))return;
  const check=(position,path)=>{
    if(!isObject(position)||!Number.isFinite(position.beat))return;
    // Same rounding as OfflineTransport.resolvePosition.
    const ticks=(position.beat-1)*subdivision,whole=Math.round(ticks),tick=Math.floor(Math.abs(ticks-whole)<1e-9?whole:ticks);
    if(tick>=numerator*subdivision)fail(join(path,'beat'),`must be below ${numerator+1}: bars have ${numerator} beats and transport.lockMeter keeps the meter fixed`);
  };
  bots.forEach((bot,index)=>{check(bot.join?.when?bot.join.latest:bot.join,`bots[${index}].join${bot.join?.when?'.latest':''}`);check(bot.leave,`bots[${index}].leave`)});
  clips.forEach((clip,index)=>{check(clip.at,`clips[${index}].at`);clip.cues?.forEach((cue,cueIndex)=>check(cue.at,`clips[${index}].cues[${cueIndex}].at`))});
  cues.forEach((cue,index)=>check(cue?.at,`cues[${index}].at`));
}

function normalizeBot(value,index,path,{fail,fields,number,boolean,json,position,mix},agents,synthesizers,samples){
  if(typeof value==='string')value={id:value};
  if(!isObject(value)){fail(path,'must be an agent id or a bot {id, key?, output?, mix?, join?, leave?}');return {}}
  // (A bot's former id is the bot: ManageBOT's `manage` is manage_clodbot.)
  if(typeof value.id==='string')value={...value,id:resolveBotId(value.id,agents)};
  const at=key=>join(path,key);
  fields(value,path,BOT);
  const definition=typeof value.id==='string'&&Object.hasOwn(agents,value.id)?agents[value.id]:null;
  if(!definition)fail(at('id'),unknownAgent(value.id,agents));
  const key=value.key===undefined?String(index+1):value.key;
  if(typeof key!=='string'||!KEY.test(key))fail(at('key'),'must be a string of 1-40 letters, digits, "_" or "-"');
  // Mirrors readEnsembleLink: previewOutputModes wins, the first mode is the default and silence is always allowed.
  const modes=definition?[...(definition.previewOutputModes||definition.outputModes||[])]:null;
  // Except for the one case a share link has no opinion about: a bot that owns
  // a bank of recordings. Its declared modes list "synth" first, so the default
  // used to be a synthesized stand-in for an instrument that has actual
  // recordings sitting on disk. Prefer the recordings, unless the spec says
  // otherwise or this environment cannot reach them.
  // Nor when the entry names a synthesizer. Asking for a particular synth voice IS asking for a synthesized one, and
  // the preference for recordings overrode it: {id: "walkingBass", synth: {id: "wam", ...}} rendered the upright-bass
  // samples with a WAM flute configured and unused. Found by the cross-engine plugin check, whose walkingBass stopped
  // matching Chrome at -77 dB because it had silently stopped being a plugin voice at all.
  const bank=definition?.sampleBank,voiced=value.synth!==undefined||value.synthesizer!==undefined||value.physical!==undefined;
  const recorded=samples?.preference==='prefer'&&samples.playable&&!voiced&&typeof bank==='string'&&bank
    &&modes?.includes('samples')&&samples.available(bank);
  const output=value.output===undefined?(recorded?'samples':modes?.[0]??'none'):value.output??'none';
  if(!BOT_OUTPUTS.includes(output))fail(at('output'),`must be one of ${quoted(BOT_OUTPUTS)}`);
  else if(modes&&output!=='none'&&!modes.includes(output))fail(at('output'),modes.length?`"${value.id}" supports ${quoted([...modes,'none'])}, not "${output}"`:`"${value.id}" only sends messages; use "none"`);
  // join {when: 'following', beats?, latest?}: the bot listens first. It joins on the first beat after the conductor
  // has held the followed performer's beat, phase and tempo, for `beats` beats in a row (beat-sync.js beatLock).
  // If that has not happened by `latest` (a position), it joins then; without one it waits.
  const listenFirst=join=>{
    fields(join,at('join'),['when','beats','latest']);
    if(join.when!=='following')fail(at('join.when'),'must be "following", or give join as a position');
    return {when:'following',beats:number(join.beats,at('join.beats'),{fallback:4,integer:true,min:1,max:32}),
      latest:join.latest===undefined||join.latest===null?null:position(join.latest,at('join.latest'))};
  };
  const joinAt=value.join===undefined?{bar:1,beat:1}:isObject(value.join)&&Object.hasOwn(value.join,'when')?listenFirst(value.join):position(value.join,at('join'));
  const leave=value.leave===undefined||value.leave===null?null:position(value.leave,at('leave'));
  if(joinAt&&!joinAt.when&&leave&&Object.values(joinAt).every(Number.isFinite)&&Object.values(leave).every(Number.isFinite)&&!before(joinAt,leave))fail(at('leave'),'must come after join');
  const bot={id:value.id,key,output,mix:mix(value.mix,at('mix')),join:joinAt,leave,loadOnly:boolean(value.loadOnly,at('loadOnly'),false),muted:boolean(value.muted,at('muted'),false)};
  // settings: what a bot is made with beyond its defaults, as a fork of it is (logic-conflicts.js forkSettings: only the
  // settings a fork may be given), and what its definition lets a spec set (spec-settings.js: a singer's lyrics).
  if(value.settings!==undefined){
    if(!isObject(value.settings))fail(at('settings'),'must be an object of settings, such as {"maqamInflections": true}');
    else{
      const kept=specSettings(value.settings,definition);if(Object.keys(kept).length)bot.settings=kept;
      if(value.settings.meterPolicy!==undefined&&kept.meterPolicy===undefined)fail(join(at('settings'),'meterPolicy'),`must be one of ${quoted(['follow','ignore','polymetric','transform:reverse','transform:rotate','transform:coarsen','transform:fine'])}`);
    }
  }
  // label: the name its part has in the score and the video, for their audience (what it does in the music: "Voice",
  // "Bass"), in place of the bot's own name. A public render names its parts so; others keep the bots' names.
  if(value.label!==undefined){const named=label(value.label,at('label'),fail);if(named)bot.label=named}
  // synth {id, options} is the spec's name for what ensemble links call synthesizer and synthOptions; normalized specs keep the latter.
  let synthesizer=value.synthesizer,synthOptions=value.synthOptions,synthPath=at('synthesizer'),optionsPath=at('synthOptions');
  if(value.synth!==undefined){
    if(value.synthesizer!==undefined||value.synthOptions!==undefined)fail(at('synth'),'cannot be combined with synthesizer or synthOptions; give one form');
    else if(!isObject(value.synth))fail(at('synth'),'must be {id, options?}, such as {"id": "wam", "options": {"url": "vendor/wam/faustFlute/index.js"}}');
    else{
      fields(value.synth,at('synth'),['id','options']);synthesizer=value.synth.id;synthOptions=value.synth.options;synthPath=at('synth.id');optionsPath=at('synth.options');
      if(synthesizer===undefined)fail(synthPath,'is required: a synthesizer id such as "musebots" or "wam"');
    }
  }
  if(synthesizer!==undefined){
    if(typeof synthesizer!=='string'||!SYNTH.test(synthesizer))fail(synthPath,'must be a synthesizer id such as "musebots"');
    else if(synthesizers&&!synthesizers.includes(synthesizer))fail(synthPath,`unknown synthesizer "${synthesizer}" (registered: ${synthesizers.join(', ')||'none'})`);
    bot.synthesizer=synthesizer;
  }
  if(synthOptions!==undefined){
    if(!isObject(synthOptions))fail(optionsPath,'must be an object');
    else{bot.synthOptions=json(synthOptions,optionsPath);pluginOptions(synthesizer,synthOptions,optionsPath,fail)}
  }else if(synthesizer==='wam')fail(at(value.synth!==undefined?'synth':'synthOptions'),'a "wam" synthesizer needs options {url} naming its WAM 2 module');
  else if(synthesizer==='vst3')fail(at(value.synth!==undefined?'synth':'synthOptions'),'a "vst3" synthesizer needs options {path} naming its VST3 plugin');
  if(value.physical!==undefined){
    const p=value.physical,where=at('physical');
    if(!isObject(p))fail(where,'must name a physical backend and model');
    else{
      fields(p,where,['backend','model','set','controls','unsupportedControls']);
      if(!['supercollider','csound','openwind','ness','stk'].includes(p.backend))fail(join(where,'backend'),'must be supercollider, csound, openwind, ness or stk');
      if(typeof p.model!=='string'||!p.model)fail(join(where,'model'),'must name the physical model');
      // (An experimental set's instrument in the played one's stead: render/synthesis/workers/instrument_sets.py.)
      if(p.set!==undefined&&(typeof p.set!=='string'||!/^[a-z0-9][a-z0-9-]*$/.test(p.set)))fail(join(where,'set'),'must name an experimental instrument set (lower-case letters, digits and hyphens)');
      if(p.set!==undefined&&p.backend!=='openwind')fail(join(where,'set'),'an experimental instrument set holds OpenWInD bodies');
      if(p.controls!==undefined&&!isObject(p.controls))fail(join(where,'controls'),'must be an object');
      if(p.unsupportedControls!==undefined&&!['report','error'].includes(p.unsupportedControls))fail(join(where,'unsupportedControls'),'must be report or error');
      if(output!=='synth')fail(at('output'),'a physical instrument requires synth output');
      if(value.synth!==undefined||value.synthesizer!==undefined)fail(where,'cannot also select another synthesizer');
      if(value.id==='bowedstring_clodbot')fail(where,'use the existing Artifastring bowedModel path for this player');
      bot.physical=json(p,where);
    }
  }
  if(value.samplePreset!==undefined){if(typeof value.samplePreset!=='string'||value.samplePreset.length>128)fail(at('samplePreset'),'must be a string of at most 128 characters');bot.samplePreset=value.samplePreset}
  return bot;
}

// What synths/wam.js and plugin-config.js would refuse when the plugin loads, reported before a render starts.
function pluginOptions(synthesizer,options,path,fail){
  if(synthesizer==='wam'&&(typeof options.url!=='string'||!options.url.trim()))fail(join(path,'url'),'is required: the URL of a WAM 2 instrument module, such as "vendor/wam/faustFlute/index.js"');
  if(synthesizer==='vst3'){
    if(typeof options.path!=='string'||!options.path.trim())fail(join(path,'path'),'is required: a VST3 bundle\'s path, or its name in a VST3 folder, such as "Surge XT"');
    if(options.parameters!==undefined&&(!isObject(options.parameters)||Object.values(options.parameters).some(value=>!['number','boolean','string'].includes(typeof value)||typeof value==='number'&&!Number.isFinite(value))))
      fail(join(path,'parameters'),'must map parameter names to numbers, booleans or strings');
    for(const key of ['preset','pluginName'])if(options[key]!==undefined&&(typeof options[key]!=='string'||!options[key].trim()))fail(join(path,key),'must be a non-empty string');
    if(options.dry!==undefined&&typeof options.dry!=='boolean')fail(join(path,'dry'),'must be true or false (true: the patch\'s own reverbs and delays off)');
    if(options.transpose!==undefined&&!(Number.isInteger(options.transpose)&&Math.abs(options.transpose)<=48))
      fail(join(path,'transpose'),'must be a whole number of semitones from -48 to 48 (otherwise the preset\'s measured transposition, render/vst3/pitch.json)');
    if(options.timbre!==undefined&&!(Number.isFinite(options.timbre)&&options.timbre>0&&options.timbre<=96))
      fail(join(path,'timbre'),'must be the semitones a note\'s timbre (CC 74) opens a Surge XT patch\'s filter, over 0 to 96 (a line bot\'s default: render/node/vst3-synth.mjs LINE_TIMBRE_SEMITONES)');
    if(options.velocity!==undefined&&typeof options.velocity!=='boolean')
      fail(join(path,'velocity'),'must be true or false (true, the default: a Surge XT patch with no Velocity > Gain answering by its notes\' family laws, public/shared/velocity-law.js; false: the patch as its author made it)');
  }
  if(synthesizer==='faust-flute'&&options.url!==undefined)fail(join(path,'url'),'is not used by "faust-flute", which plays the vendored flute; use synthesizer "wam" for another module');
  if(options.mpe!==undefined&&typeof options.mpe!=='boolean')fail(join(path,'mpe'),'must be true or false');
  if(options.bendRange!==undefined&&!(Number.isFinite(options.bendRange)&&options.bendRange>0&&options.bendRange<=96))fail(join(path,'bendRange'),'must be a number greater than 0 and at most 96');
  if(options.trimDb!==undefined&&!(Number.isFinite(options.trimDb)&&options.trimDb>=-60&&options.trimDb<=24))fail(join(path,'trimDb'),'must be a number of dB from -60 to 24 (the plugin\'s measured level otherwise, data/wam-levels.js)');
  if(options.channel!==undefined&&!(Number.isInteger(options.channel)&&options.channel>=0&&options.channel<=15))fail(join(path,'channel'),'must be a MIDI channel from 0 to 15 (9 is General MIDI\'s drums)');
  else if(options.channel!==undefined&&options.mpe===true)fail(join(path,'channel'),'is not used with mpe: each MPE note takes a channel of its own');
  if(options.program!==undefined&&!(Number.isInteger(options.program)&&options.program>=0&&options.program<=127))fail(join(path,'program'),'must be a MIDI program from 0 to 127');
  // loadWamPlugin checks the URL only; the state size limit belongs to share links, not renders.
  if(typeof options.url==='string')try{pluginConfig.normalizePluginConfig({url:options.url})}catch(error){fail(join(path,'url'),error.message)}
}

// effects {settings, plugin}: the ensemble sound panel's settings (sound-settings.js ranges, reported rather than clamped) and
// the shared effect plugin, by EFFECT_PLUGINS id, module URL, or (on the desktop) a VST3 effect's path. A spec without
// effects takes an ensemble link's.
function normalizeEffects(value,{fail,fields,number,json},linked){
  if(value===undefined||value===null){
    const plugin=linked?.effectPlugin?.url?{url:linked.effectPlugin.url,...(linked.effectPlugin.state!==undefined?{state:linked.effectPlugin.state}:{})}:null;
    if(!linked?.effects&&!plugin)return undefined;
    return {...(linked.effects?{settings:{...linked.effects}}:{}),...(plugin?{plugin}:{})};
  }
  const source=fields(value,'effects',['settings','plugin']),result={};
  if(source.settings!==undefined){
    const settings=fields(source.settings,'effects.settings',Object.keys(FX_DEFAULTS));
    result.settings={};
    for(const key of Object.keys(FX_DEFAULTS))if(settings[key]!==undefined){
      const [min,max]=[effectSettings({[key]:-Number.MAX_VALUE})[key],effectSettings({[key]:Number.MAX_VALUE})[key]];
      result.settings[key]=number(settings[key],join('effects.settings',key),{min,max});
    }
  }
  if(source.plugin!==undefined){
    const plugin=fields(source.plugin,'effects.plugin',['id','url','path','state','trimDb','parameters','preset','pluginName']);
    if(isObject(source.plugin)){
      const forms=['id','url','path'].filter(key=>plugin[key]!==undefined);
      if(forms.length!==1)fail('effects.plugin',forms.length?`must use one of id, url and path, not ${forms.join(' and ')}`:'must name an effect plugin: {id} such as "faust-ping-pong", {url}, or the {path} of a VST3 effect');
      else if(forms[0]==='id'&&(typeof plugin.id!=='string'||!NAME.test(plugin.id)))fail('effects.plugin.id','must be an effect plugin id such as "faust-ping-pong"');
      else if(forms[0]==='url'&&(typeof plugin.url!=='string'||!plugin.url.trim()))fail('effects.plugin.url','must be the URL of a WAM 2 effect module');
      else if(forms[0]==='path'&&(typeof plugin.path!=='string'||!plugin.path.trim()))fail('effects.plugin.path','must be a VST3 effect\'s path, or its name in a VST3 folder, such as "FdnReverb"');
      result.plugin={[forms[0]]:plugin[forms[0]]};
      // A VST3's options are the VST3 synthesizer's; state is a WAM's.
      if(forms[0]==='path'){
        for(const key of ['parameters','preset','pluginName'])if(plugin[key]!==undefined)result.plugin[key]=json(plugin[key],join('effects.plugin',key));
        if(typeof plugin.path==='string'&&plugin.path.trim())pluginOptions('vst3',result.plugin,'effects.plugin',fail);
        if(plugin.state!==undefined)fail('effects.plugin.state','is a WAM\'s; a VST3 effect takes parameters or a preset');
      }else for(const key of ['parameters','preset','pluginName'])if(plugin[key]!==undefined)fail(join('effects.plugin',key),'is for a VST3 effect (path)');
      if(plugin.state!==undefined&&forms[0]!=='path')result.plugin.state=json(plugin.state,'effects.plugin.state');
      if(plugin.trimDb!==undefined){if(Number.isFinite(plugin.trimDb)&&plugin.trimDb>=-60&&plugin.trimDb<=24)result.plugin.trimDb=plugin.trimDb;else fail('effects.plugin.trimDb','must be a number of dB from -60 to 24');}
      if(typeof plugin.url==='string')try{pluginConfig.normalizePluginConfig({url:plugin.url})}catch(error){fail('effects.plugin.url',error.message)}
    }
  }
  return result;
}

// An aesthetic character (public/shared/aesthetic.js): its axes, each 0 to 1, each checked where it is written.
function characterAxes(value,path,{fail}){
  if(!isObject(value)){fail(path,'must be an object of aesthetic axes, each 0 to 1');return undefined}
  const character={};
  for(const [axis,level] of Object.entries(value)){
    if(!AXIS_NAMES.includes(axis))fail(join(path,axis),`is not an aesthetic axis: ${quoted(AXIS_NAMES)}`);
    else if(typeof level!=='number'||!(level>=0&&level<=1))fail(join(path,axis),'must be a number from 0 to 1');
    else character[axis]=level;
  }
  return character;
}
// desk {id, channels, duties, protect, rules, options}: mh_DeskBOT (experiments/mix-desk/live-desk.js) mixing the render as it
// mixes a live room. Channels and protected channels name mixer tracks: a bot id (every bot of that agent), "id:key" (one bot)
// or "clip:<id>"; rules and options are LiveDesk's, checked against its own tables so a misspelt rule is not silently ignored.
// null or absent: no desk, and no key in the normalized spec.
function normalizeDesk(value,check,bots,clips){
  if(value===undefined||value===null)return undefined;
  const {fail,fields}=check,source=fields(value,'desk',DESK);
  if(!isObject(value))return undefined;
  const id=source.id===undefined?DEFAULT_DESK_ID:source.id;
  if(typeof id!=='string'||!NAME.test(id))fail('desk.id','must be a desk id such as "mh_DeskBOT"');
  let channels='all';
  if(source.channels!==undefined&&source.channels!=='all'){
    if(!Array.isArray(source.channels)||!source.channels.length)fail('desk.channels','must be "all" or a list of channels: bot ids, "id:key" or "clip:<id>"');
    else channels=channelNames(source.channels,'desk.channels',check,bots,clips);
  }
  let duties=[...DUTIES];
  if(source.duties!==undefined){
    if(!Array.isArray(source.duties)||!source.duties.length)fail('desk.duties',`must be a non-empty list from ${quoted(DUTIES)}`);
    else{
      source.duties.forEach((duty,index)=>{if(!DUTIES.includes(duty))fail(join('desk.duties',index),`must be one of ${quoted(DUTIES)}`);else if(source.duties.indexOf(duty)!==index)fail(join('desk.duties',index),`repeats "${duty}"`)});
      duties=DUTIES.filter(duty=>source.duties.includes(duty));
    }
  }
  const protect=source.protect===undefined?[]:Array.isArray(source.protect)?channelNames(source.protect,'desk.protect',check,bots,clips):(fail('desk.protect','must be a list of channels: bot ids, "id:key" or "clip:<id>"'),[]);
  const rules=numberTable(source.rules,'desk.rules',check,LIVE_DESK,DESK_RULE_GROUPS),options=numberTable(source.options,'desk.options',check,AUTO_MIX);
  const metering=check.choice(source.metering,'desk.metering',METERING_MODES,DEFAULT_METERING);
  // How the desk makes the mix (public/shared/mix-approaches.js): an approach by name, or a character whose nearest
  // approach it takes. Neither: the desk only balances, as it always has.
  const approach=source.approach===undefined?undefined:check.choice(source.approach,'desk.approach',APPROACH_NAMES,undefined);
  const character=source.character===undefined?undefined:characterAxes(source.character,'desk.character',check);
  if(approach!==undefined&&character!==undefined)fail('desk.approach','name an approach or a character, not both');
  // What the mix is for from the start, and who may cover whom (public/shared/mix-intention.js; the extreme-aesthetics
  // report's M3): a scene intention's axes, each 0 to 1, and masking permissions naming channels, roles or bots. A form
  // bot may change them as its sections go (/broadcast/mixIntention).
  let intention,permissions;
  if(source.intention!==undefined){
    try{intention=Object.fromEntries(Object.entries(mixIntention(source.intention)).filter(([,level])=>level!==null))}
    catch(error){fail('desk.intention',error.message)}
  }
  if(source.permissions!==undefined){
    if(!Array.isArray(source.permissions))fail('desk.permissions','must be a list of masking permissions: {masker, masked, bands} or {fuse: [...]}');
    else permissions=source.permissions.map((permission,index)=>{try{return maskingPermission(permission)}catch(error){fail(join('desk.permissions',index),error.message);return null}});
  }
  // kits: false keeps each drum bot's kit on one channel even for a desk that places or groups (splitsKits).
  if(source.kits!==undefined&&typeof source.kits!=='boolean')fail('desk.kits','must be true or false');
  return {id,channels,duties,protect,metering,...(rules?{rules}:{}),...(options?{options}:{}),
    ...(approach!==undefined?{approach}:{}),...(character!==undefined?{character}:{}),...(source.kits===false?{kits:false}:{}),
    ...(intention!==undefined?{intention}:{}),...(permissions!==undefined?{permissions}:{})};
}
// Whether a render splits each drum bot's kit into a channel per drum (audio.js splitKit), for its desk to place and
// process each drum: when the desk places or groups the band, unless it says `kits: false`.
export const splitsKits=desk=>Boolean(desk&&desk.kits!==false&&(desk.duties??[]).some(duty=>duty==='placement'||duty==='submix'));

// autoMix {rules, options}: the plain cross-adaptive fader balance (experiments/mix-desk/live-auto-mix.js) on every track.
function normalizeAutoMix(value,check){
  if(value===undefined||value===null)return undefined;
  const source=check.fields(value,'autoMix',['rules','options','metering']);
  if(!isObject(value))return undefined;
  const rules=numberTable(source.rules,'autoMix.rules',check,LIVE_AUTO_MIX),options=numberTable(source.options,'autoMix.options',check,AUTO_MIX);
  const metering=check.choice(source.metering,'autoMix.metering',METERING_MODES,DEFAULT_METERING);
  return {metering,...(rules?{rules}:{}),...(options?{options}:{})};
}

function channelNames(names,path,{fail},bots,clips){
  const known=name=>{
    const [id,...rest]=String(name).split(':');
    if(id==='clip')return clips.some(clip=>clip.id===rest.join(':'));
    return bots.some(bot=>bot.id===id&&(!rest.length||bot.key===rest.join(':')));
  };
  names.forEach((name,index)=>{
    if(typeof name!=='string'||!name)fail(join(path,index),'must be a channel name: a bot id, "id:key" or "clip:<id>"');
    else if(!known(name))fail(join(path,index),`"${name}" names no bot or clip of this render`);
    else if(names.indexOf(name)!==index)fail(join(path,index),`repeats "${name}"`);
  });
  return names.filter(name=>typeof name==='string');
}

// A table of numbers overriding a listener's defaults: only its own keys, each the kind of value the default is (a number, or
// a number list such as the band edges); `groups` are nested tables of the same shape (desk.rules.dynamics, desk.rules.pink).
function numberTable(value,path,{fail,fields},defaults,groups={}){
  if(value===undefined)return undefined;
  const source=fields(value,path,[...Object.keys(defaults),...Object.keys(groups)]);
  if(!isObject(value))return undefined;
  const result={};
  for(const [key,item] of Object.entries(source)){
    if(key.startsWith('$')||key.startsWith('//'))continue;
    const at=join(path,key);
    if(groups[key]){const table=numberTable(item,at,{fail,fields},groups[key]);if(table)result[key]=table;continue}
    if(!(key in defaults))continue;
    if(Array.isArray(defaults[key])){
      if(!Array.isArray(item)||!item.length||item.some(entry=>typeof entry!=='number'||!Number.isFinite(entry)))fail(at,'must be a list of finite numbers');
      else result[key]=[...item];
    }else if(typeof defaults[key]==='boolean'){
      // A rule that is on or off (the desk's soundcheck, its attention on the downbeat, its aims within reach).
      if(typeof item!=='boolean')fail(at,'must be true or false');else result[key]=item;
    }else if(typeof item!=='number'||!Number.isFinite(item))fail(at,'must be a finite number');
    else result[key]=item;
  }
  return result;
}

function unknownAgent(id,agents){
  if(typeof id!=='string'||!id)return 'is required: an agent id such as "modal"';
  const named=Object.entries(agents).find(([,definition])=>definition?.name===id)?.[0],folded=Object.keys(agents).find(key=>key.toLowerCase()===id.toLowerCase());
  return named?`"${id}" is an agent name; use its id "${named}"`:folded?`unknown agent id "${id}" (did you mean "${folded}"?)`:`unknown agent id "${id}"`;
}

function linkBot(bot){
  const mix={pan:bot.mix?.pan??0,gain:bot.mix?.dry??1};
  for(const key of SENDS)if(bot.mix?.[key])mix[key]=bot.mix[key];
  return {id:bot.id,key:bot.key,output:bot.output??'none',mix,loadOnly:bot.loadOnly===true,muted:bot.muted===true,
    ...(bot.synthesizer?{synthesizer:bot.synthesizer}:{}),...(bot.synthOptions?{synthOptions:bot.synthOptions}:{}),...(bot.samplePreset?{samplePreset:bot.samplePreset}:{})};
}

function clipFile(value,path,{fail,fields,number,choice},sampleRate){
  if(typeof value==='string'&&value.trim())return value;
  if(!isObject(value)||!Object.hasOwn(value,'generate')){fail(path,'must be a file path or {generate: {type, seconds, frequency?, channels?}}');return null}
  fields(value,path,['generate']);
  const at=join(path,'generate'),source=fields(value.generate,at,['type','frequency','seconds','channels']);
  const generate={type:choice(source.type,join(at,'type'),GENERATORS),frequency:number(source.frequency,join(at,'frequency'),{fallback:440,positive:true}),
    seconds:number(source.seconds,join(at,'seconds'),{positive:true}),channels:number(source.channels,join(at,'channels'),{fallback:2,integer:true,min:1,max:32})};
  if(generate.frequency>=sampleRate/2)fail(join(at,'frequency'),`must be below half the sample rate (${sampleRate/2})`);
  return {generate};
}

// follow {bot, key?, tempo?, harmony?, listening?}, or false: the ensemble follows the performer a listening bot hears,
// as a live room does once someone starts listening. A listening bot stands for a person playing with the band, and
// following them is its point, so a render with one follows the first (FOLLOW_SOURCES) unless follow says otherwise;
// false has listening bots only observe. tempo (default true) is the conductor following that bot's tempo, true or
// the following options (tempo-influence.js); a render synchronizes beat by beat (alignPhase) unless they say
// otherwise. harmony (default true) has the bot lead the harmony with the chords it hears (a MIDIInputBot once its
// input has a harmonic vocabulary). listening (listening-options.js) is how a ListenerBot hears its input, for
// development comparisons; left out, it hears with the defaults. Following starts once the bot has joined.
// also: more listening bots, [{bot, key?}], whose reports the conductor fuses with the followed one's
// (input-fusion.js): one performer heard twice counts its events once, different performers tighten each other.
// Following starts once every one has joined.
function normalizeFollow(value,check,bots,transport){
  const none=()=>{bots.forEach((bot,index)=>{if(bot.join?.when==='following')check.fail(`bots[${index}].join`,'listens for a held beat, which needs follow');});return null;};
  if(value===false)return none();
  if(value===undefined||value===null){
    const first=bots.find(bot=>FOLLOW_SOURCES.includes(bot.id));
    if(!first)return none();
    value={bot:first.id,...(first.key!==undefined&&first.key!==null?{key:first.key}:{}),...(transport.lockTempo?{tempo:false}:{})};
  }
  const {fail,fields,boolean}=check,source=fields(value,'follow',FOLLOW);
  if(!isObject(value))return null;
  const matches=bots.filter(bot=>bot.id===source.bot&&(source.key===undefined||bot.key===String(source.key)));
  if(typeof source.bot!=='string'||!matches.length)fail('follow.bot',`must name a bot in bots${source.key===undefined?'':` with key "${source.key}"`}`);
  else if(matches.length>1)fail('follow.key',`is needed: bots has ${matches.length} "${source.bot}" bots`);
  else if(!FOLLOW_SOURCES.includes(source.bot))fail('follow.bot',`must be one of ${quoted(FOLLOW_SOURCES)}: only they report a performer's timing`);
  let tempo=null;
  if(source.tempo===undefined||source.tempo===true)tempo={alignPhase:true};
  else if(isObject(source.tempo)){try{tempo={alignPhase:true,...source.tempo};tempoFollowingOptions(tempo)}catch(error){fail('follow.tempo',error.message)}}
  else if(source.tempo!==false)fail('follow.tempo','must be true, false or tempo following options');
  if(tempo&&transport.lockTempo)fail('follow.tempo','cannot follow with transport.lockTempo, which keeps the tempo fixed');
  const harmony=boolean(source.harmony,'follow.harmony',true);
  let listening=null;
  if(source.listening!==undefined){
    if(!['listener','profile_clodbot'].includes(source.bot))fail('follow.listening','needs a ListenerBot ("listener") or its fork profile_clodbot: they hear audio');
    else try{listening=listeningOptions(source.listening)}catch(error){fail('follow.listening',error.message)}
  }
  const also=[];
  if(source.also!==undefined){
    if(!Array.isArray(source.also)||source.also.length>7)fail('follow.also','must be a list of up to seven listening bots to follow with it');
    else source.also.forEach((other,index)=>{
      const at=`follow.also[${index}]`,named=isObject(other)?other:{},found=bots.filter(bot=>bot.id===named.bot&&(named.key===undefined||bot.key===String(named.key)));
      if(!isObject(other)||typeof named.bot!=='string'||!found.length)fail(at,'must name a bot in bots');
      else if(found.length>1)fail(`${at}.key`,`is needed: bots has ${found.length} "${named.bot}" bots`);
      else if(!FOLLOW_SOURCES.includes(named.bot))fail(`${at}.bot`,`must be one of ${quoted(FOLLOW_SOURCES)}: only they report a performer's timing`);
      else if(matches.includes(found[0])||also.some(entry=>entry.bot===named.bot&&entry.key===(found[0].key??null)))fail(at,'is already followed');
      else also.push({bot:named.bot,key:found[0].key??null});
    });
    if(also.length&&!tempo)fail('follow.also','fuses tempo reports, which needs follow.tempo');
  }
  bots.forEach((bot,index)=>{
    if(bot.join?.when!=='following')return;
    if(!tempo?.alignPhase)fail(`bots[${index}].join`,'listens for a held beat, which needs follow.tempo with alignPhase');
    if(matches.includes(bot))fail(`bots[${index}].join`,'cannot wait for the beat of the bot it is: the followed bot must join first');
  });
  return {bot:source.bot,key:matches[0]?.key??null,tempo,harmony,...(listening?{listening}:{}),...(also.length?{also}:{})};
}

function normalizeHear(value,path,{fail},hearings){
  if(value===undefined)return ['cues'];
  const names=typeof value==='string'?[value]:value;
  if(!Array.isArray(names)){fail(path,'must be an array of hearing adapter names');return []}
  names.forEach((name,index)=>{
    const at=join(path,index);
    if(typeof name!=='string'||!NAME.test(name))fail(at,'must be a hearing adapter name such as "cues"');
    else if(names.indexOf(name)!==index)fail(at,`repeats "${name}"`);
    else if(name==='none'&&names.length>1)fail(at,'"none" cannot be combined with other adapters');
    else if(hearings&&!hearings.includes(name))fail(at,`unknown hearing adapter "${name}" (registered: ${hearings.join(', ')||'none'})`);
  });
  return [...names];
}

export function normalizePosition(value,path='at'){
  const check=checker(),position=check.position(value,path);
  if(check.problems.length)throw new RenderSpecError(check.problems);
  return freeze(position);
}
export function positionKey(position){
  if(!isObject(position))throw new TypeError('positionKey needs a position');
  if('tick' in position)return `tick:${position.tick}`;
  if('seconds' in position)return `seconds:${position.seconds}`;
  return `bar:${position.bar}:${position.beat??1}`;
}
export function describePosition(position){
  if(!isObject(position))return 'none';
  if('tick' in position)return `tick ${position.tick}`;
  if('seconds' in position)return `${position.seconds} s`;
  return `bar ${position.bar} beat ${position.beat??1}`;
}
