import {describePosition} from './spec.js';

// A hearing factory is ({clip, decoded, spec, transport}) => adapter, where
// adapter.onTick({tick, musicSeconds, interval, clock}) returns the [{address, args}] to send before that tick's pulse.
const hearings=new Map;

export function registerHearing(name,factory,{replace=false}={}){
  if(typeof name!=='string'||!/^[A-Za-z][A-Za-z0-9_.-]{0,63}$/.test(name))throw new TypeError(`Invalid hearing adapter name: ${name}`);
  if(typeof factory!=='function')throw new TypeError(`Hearing adapter "${name}" needs a factory function`);
  if(hearings.has(name)&&!replace)throw new Error(`Hearing adapter "${name}" is already registered; pass {replace: true} to override it`);
  hearings.set(name,factory);
  return factory;
}
export function getHearing(name){
  if(hearings.has(name))return hearings.get(name);
  throw new Error(`Unknown hearing adapter "${name}" (registered: ${[...hearings.keys()].join(', ')}${name==='features'?'; import public/render/hearing-features.js to add "features"':''})`);
}
export const listHearings=()=>[...hearings.keys()];

export async function createHearingAdapters(context){
  return Promise.all(context.clip.hear.map(async name=>{
    const adapter=await getHearing(name)(context);
    if(typeof adapter?.onTick!=='function')throw new TypeError(`Hearing adapter "${name}" for clip "${context.clip.id}" has no onTick()`);
    return {name,adapter};
  }));
}

// Cues fall on the tick whose window [musicSeconds[k], musicSeconds[k+1]) holds their position. A position that
// resolves late (the adapter started after it) is sent on the next call rather than dropped. A {seconds} cue is
// placed with the tick's provisional interval, so a meter change at the end of that tick can move it by one tick.
export function createCueScheduler(cues=[],transport,{label='cue'}={}){
  if(typeof transport?.resolvePosition!=='function')throw new TypeError('A cue scheduler needs transport.resolvePosition(position)');
  const pending=cues.map((cue,index)=>({cue,index}));
  return {
    onTick({tick}){
      const due=[];
      for(let i=0;i<pending.length;){
        const item=pending[i];let resolved;
        try{resolved=transport.resolvePosition(item.cue.at)}
        catch(error){throw new RangeError(`${label} ${item.index} at ${describePosition(item.cue.at)}: ${error.message}`)}
        // null: a bar the transport has not reached yet.
        if(resolved&&resolved.tick<=tick){due.push({...item,resolved});pending.splice(i,1)}else i++;
      }
      due.sort((a,b)=>a.resolved.tick-b.resolved.tick||(a.resolved.fraction||0)-(b.resolved.fraction||0)||a.index-b.index);
      return due.map(({cue})=>({address:cue.address,args:structuredClone(cue.args),at:cue.at}));
    },
    get pending(){return pending.map(({cue})=>cue)},
  };
}

registerHearing('none',()=>({onTick:()=>[]}));
registerHearing('cues',({clip,transport})=>createCueScheduler(clip.cues,transport,{label:`clip "${clip.id}" cue`}));
