// Engine contract (docs/OFFLINE_RENDERING.md, "Engines"): a factory is async ({spec, sink, environment}) => engine.
const engines=new Map,metadata=new Map;
const METHODS=['createAudio','placeClip','setTime','renderUntil','finish','dispose'];
const FLAGS=['audio','samples','stems','effects'],OUTPUTS=['synth','samples','midi'];
// Synthesizers an audio engine plays when its capabilities do not list them: the ones needing no plugin host.
export const PLAIN_SYNTHESIZERS=Object.freeze(['musebots','web-audio']);

// Registration metadata describes an engine before it is created, so a spec can be checked against it (--dry-run, checkSpec())
// and --list-engines can name it: capabilities (an object, or a function returning one) are checked with unsupportedFeatures();
// problems(spec) replaces that with the engine's own check (one that also needs a tool installed, say); description is printed.
export function registerRenderEngine(name,factory,{replace=false,capabilities=null,problems=null,description=''}={}){
  if(typeof name!=='string'||!/^[A-Za-z][A-Za-z0-9_.-]{0,63}$/.test(name))throw new TypeError(`Invalid render engine name: ${name}`);
  if(typeof factory!=='function')throw new TypeError(`Render engine "${name}" needs a factory function`);
  if(engines.has(name)&&!replace)throw new Error(`Render engine "${name}" is already registered; pass {replace: true} to override it`);
  if(problems!==null&&typeof problems!=='function')throw new TypeError(`Render engine "${name}": problems must be a function of the spec`);
  engines.set(name,factory);metadata.set(name,{capabilities,problems,description:String(description)});
  return factory;
}
export const engineMetadata=name=>metadata.get(name)??null;
export function getRenderEngine(name){
  if(engines.has(name))return engines.get(name);
  const known=[...engines.keys()];
  throw new Error(`Unknown render engine "${name}"; ${known.length?`registered engines: ${known.join(', ')}`:'no engines are registered (import the engine module first)'}`);
}
export const listRenderEngines=()=>[...engines.keys()];

export function validateEngine(engine){
  const problems=[],fail=message=>problems.push(message);
  if(!engine||typeof engine!=='object')throw Object.assign(new TypeError('A render engine factory must return an engine object'),{problems:['engine is not an object']});
  if(typeof engine.name!=='string'||!engine.name)fail('name must be a non-empty string');
  const capabilities=engine.capabilities;
  if(!capabilities||typeof capabilities!=='object')fail('capabilities must be an object like {audio, samples, stems, effects, outputs}');
  else{
    for(const flag of FLAGS)if(typeof capabilities[flag]!=='boolean')fail(`capabilities.${flag} must be true or false`);
    if(!Array.isArray(capabilities.outputs)||capabilities.outputs.some(output=>!OUTPUTS.includes(output)))fail(`capabilities.outputs must be an array of ${OUTPUTS.map(output=>`"${output}"`).join(', ')} ([] for none)`);
    if(capabilities.audio===false&&(capabilities.stems||capabilities.samples||capabilities.effects))fail('capabilities.stems, samples and effects need capabilities.audio');
    // Optional: synthesizers (ids the engine plays, default PLAIN_SYNTHESIZERS), plugins (loads effect plugins, default false),
    // vst3 (hosts VST3 effects, on the desktop; default false) and desk (runs the mixing listeners, spec desk/autoMix, through
    // startListeners()/stopListeners(); default false).
    if(capabilities.synthesizers!==undefined&&(!Array.isArray(capabilities.synthesizers)||capabilities.synthesizers.some(id=>typeof id!=='string')))fail('capabilities.synthesizers must be an array of synthesizer ids');
    if(capabilities.plugins!==undefined&&typeof capabilities.plugins!=='boolean')fail('capabilities.plugins must be true or false');
    if(capabilities.vst3!==undefined&&typeof capabilities.vst3!=='boolean')fail('capabilities.vst3 must be true or false');
    if(capabilities.desk!==undefined&&typeof capabilities.desk!=='boolean')fail('capabilities.desk must be true or false');
    // placedNotes (optional, default false): a bot whose sound is audio it renders and places itself, each note reported
    // as it is placed (its definition's placedNotes: a singer's phrases), has its notes on this engine though its output
    // is not among the engine's -- the score engine's, which renders none of that audio.
    if(capabilities.placedNotes!==undefined&&typeof capabilities.placedNotes!=='boolean')fail('capabilities.placedNotes must be true or false');
    if(capabilities.desk===true)for(const method of ['startListeners','stopListeners'])if(typeof engine[method]!=='function')fail(`${method}() is missing (capabilities.desk is true)`);
  }
  const context=engine.context;
  if(!context||typeof context!=='object')fail('context must be an object with currentTime and sampleRate');
  else{
    if(!Number.isFinite(context.currentTime))fail('context.currentTime must be a finite number');
    if(!(context.sampleRate>0))fail('context.sampleRate must be a positive number');
  }
  // A mixer is how engines expose per-track routing; the score engine has none.
  if(engine.mixer!=null&&typeof engine.mixer.track!=='function')fail('mixer.track(id) must be a function (EnsembleMixer API)');
  if(capabilities?.audio&&engine.mixer==null)fail('mixer is required when capabilities.audio is true');
  for(const method of METHODS)if(typeof engine[method]!=='function')fail(`${method}() is missing`);
  if(problems.length)throw Object.assign(new TypeError(`Render engine "${engine.name??'?'}" does not meet the engine contract:\n  ${problems.join('\n  ')}`),{problems});
  return engine;
}

export async function createRenderEngine(name,options){return validateEngine(await getRenderEngine(name)(options))}

// The errors among unsupportedFeatures(), as a RenderSpecError's problems ({path, message}).
export const unsupportedErrors=(capabilities,spec,name,options)=>unsupportedFeatures(capabilities,spec,name,options).filter(problem=>problem.level==='error').map(({path,message})=>({path,message}));

// Spec features an engine cannot honour, as {path, message, level}: 'error' cannot render, 'warning' renders without it.
// `agents`, the bots' definitions where the caller has them, tells a bot that places its own notes (capabilities.placedNotes).
export function unsupportedFeatures(capabilities,spec,name=spec.engine,{agents=null}={}){
  const problems=[],bots=spec.bots||[],clips=spec.clips||[];
  const placed=bot=>capabilities.placedNotes===true&&agents?.[bot.id]?.placedNotes===true;
  bots.forEach((bot,index)=>{
    if(bot.output!=='none'&&!capabilities.outputs.includes(bot.output)&&!placed(bot))problems.push({path:`bots[${index}].output`,level:'error',message:`the ${name} engine renders ${capabilities.outputs.map(output=>`"${output}"`).join(', ')||'no output'}, not "${bot.output}" (use "none" for decisions only)`});
  });
  // The listeners mix what they hear on the engine's mixer; an engine without audio has nothing for them to hear.
  for(const [key,what] of [['desk','a desk'],['autoMix','the automatic mix']])if(spec[key]&&capabilities.desk!==true)problems.push({path:key,level:'error',message:`the ${name} engine cannot run ${what} (no mixer to listen to); use the node or chrome engine`});
  if(!capabilities.audio)return problems;
  const synthesizers=capabilities.synthesizers??PLAIN_SYNTHESIZERS;
  bots.forEach((bot,index)=>{
    if(bot.output!=='none'&&bot.synthesizer&&!synthesizers.includes(bot.synthesizer))problems.push({path:`bots[${index}].synthesizer`,level:'error',
      message:`the ${name} engine plays ${synthesizers.map(id=>`"${id}"`).join(', ')}, not "${bot.synthesizer}"${bot.synthesizer==='vst3'?' (VST3 instruments play on the node engine, on the desktop)':capabilities.plugins?'':' (plugin synthesizers need the chrome engine)'}`});
  });
  if(spec.effects?.plugin&&capabilities.plugins!==true)problems.push({path:'effects.plugin',level:'error',message:`the ${name} engine cannot load effect plugins; use the chrome engine`});
  else if(spec.effects?.plugin?.path!==undefined&&capabilities.vst3!==true)problems.push({path:'effects.plugin.path',level:'error',message:`the ${name} engine cannot load VST3 effects; they play on the node engine, on the desktop`});
  if(spec.effects?.settings&&!capabilities.effects)problems.push({path:'effects.settings',level:'warning',message:`the ${name} engine has no effects; it renders dry`});
  if(!capabilities.stems&&spec.outputs?.stems?.length)problems.push({path:'outputs.stems',level:'error',message:`the ${name} engine cannot write stems; use []`});
  if(!capabilities.effects)[...bots.map((bot,index)=>[`bots[${index}]`,bot]),...clips.map((clip,index)=>[`clips[${index}]`,clip])].forEach(([path,item])=>{
    for(const send of ['reverb','delay','compression','plugin'])if(item.mix?.[send])problems.push({path:`${path}.mix.${send}`,level:'warning',message:`the ${name} engine has no ${send} send; it renders dry`});
  });
  return problems;
}

// What an engine would refuse in a normalized spec, from its registration metadata, before it is created.
export async function engineSpecProblems(spec,name=spec.engine,options={}){
  const meta=metadata.get(name);
  if(!meta)return [];
  if(meta.problems)return meta.problems(spec);
  const capabilities=typeof meta.capabilities==='function'?meta.capabilities():meta.capabilities;
  return capabilities?unsupportedErrors(capabilities,spec,name,options):[];
}
