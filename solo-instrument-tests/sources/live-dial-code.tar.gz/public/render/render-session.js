import {FeedbackLoops,FEEDBACK_REQUESTS} from '../shared/feedback-loops.js';
import {MixCuts} from '../shared/mix-cuts.js';
import {MixEdits} from '../shared/mix-edits.js';
import {MixFormants} from '../shared/mix-formants.js';
import {MIX_INTENTION_ADDRESS} from '../shared/mix-intention.js';
import {EFFECTS_ADDRESS,applyEffects} from '../shared/effects-routing.js';
import {DESK_SPECTRA,deskSpectraMessage} from '../../experiments/mix-desk/desk-spectra.js';
import {forkSettings} from '../shared/logic-conflicts.js';
import {capabilitiesOf} from '../../experiments/setup-phase/capabilities.js';
import {configureRandomSeed,randomSeed} from '../random-source.js';
import {STOCHASTIC_CONFIG} from '../stochastic-config.js';
import {applyCharacter} from '../shared/aesthetic-apply.js';
import {HeadlessBot,availableModes,botTrackId} from './bot-host.js';
import {createRenderEngine,unsupportedFeatures,validateEngine} from './engines.js';
import {createHearingAdapters} from './hearing.js';
import {renderInputs} from './render-inputs.js';
import {arrangementInputs} from './arrangement-inputs.js';
import {trimPreroll} from './outputs.js';
import {RETURNS_TRACK} from './returns-tap.js';
import {renderEnding} from './tail-release.js';
import {ScoreContext,createScoreAudio} from './score-engine.js';
import {RenderSpecError,FOLLOW_SOURCES,splitsKits} from './spec.js';
import {LOOKAHEAD,RenderTimeline,generateClipAudio,prerollFrames} from './timeline.js';
import {TimelineClock} from './timeline-clock.js';
import {OfflineTransport} from './transport.js';
import {beatLock} from '../shared/estimation/beat-sync.js';
import {CLOSING_ADDRESS} from '../bots/lib/modules/closure.js';
import {durationPolicy} from '../shared/composition-duration.js';
import {installVirtualTime} from './virtual-time.js';

const EPSILON=1e-9,RENDER_SINK=Symbol('musebots.render.sink'),TIMELINE='timeline',ROOM='main';

// One macrotask, so promise-scheduled bot work (sampleFile, corpus loads) lands on the tick that started it.
// setImmediate is taken at import, so a test that mocks timers afterwards cannot stall a render.
const nextMacrotask=(()=>{
  const immediate=globalThis.setImmediate;
  if(typeof immediate==='function')return ()=>new Promise(resolve=>immediate(resolve));
  if(typeof MessageChannel==='function'){
    const channel=new MessageChannel(),queue=[];
    channel.port1.onmessage=()=>queue.shift()?.();
    return ()=>new Promise(resolve=>{queue.push(resolve);channel.port2.postMessage(0)});
  }
  const timeout=globalThis.setTimeout;
  return ()=>new Promise(resolve=>timeout(resolve,0));
})();

// The sink an engine writes render-time blocks to: the caller's sink behind trimPreroll when preroll is "trim".
// Memoized per sink, so an engine created with renderSink(sink, spec) and a session given sink share one wrapper.
const renderSinks=new WeakMap;
export function renderSink(sink,spec){
  if(!sink||spec?.preroll==='keep')return sink||null;
  const frames=prerollFrames(spec.sampleRate);
  if(sink[RENDER_SINK]===frames)return sink;
  let wrappers=renderSinks.get(sink);
  if(!wrappers)renderSinks.set(sink,wrappers=new Map);
  if(!wrappers.has(frames)){
    const wrapper=Object.assign(trimPreroll(sink,frames),{abort:error=>sink.abort?.(error)});
    Object.defineProperty(wrapper,RENDER_SINK,{value:frames});
    wrappers.set(frames,wrapper);
  }
  return wrappers.get(frames);
}

const midiPitch=event=>{
  const frequency=Number(event.frequency);
  if(frequency>0)return Math.round((69+12*Math.log2(frequency/440))*1000)/1000;
  return Number.isFinite(event.pitch)?Math.round(event.pitch*1000)/1000:undefined;
};

// Runs a normalized render spec on one engine: prepare(), step() until done, finish(); run() does all three and always
// disposes (a caller stepping by hand calls dispose() itself, also after a failure, to restore time and the random seed).
// Every step follows docs/OFFLINE_RENDERING.md "Timing model" in order. Bots see virtual Date.now/performance.now
// and a seeded crypto.randomUUID for the whole render, and the global random source is seeded with spec.seed.
// How a logged note was made: from a recording (a sample, a sampled kit), by a plugin (VST3, WAM), by the singer's
// renderer, or by the engine's own voice.
const PLUGIN_SYNTHS=new Set(['vst3','wam','faust-flute']);
export function noteMechanism(event={}){
  if(event.kind==='sample'||event.synth==='drum-kit')return 'recorded';
  if(event.kind==='vocal')return 'sung';
  if(event.kind==='dsp')return PLUGIN_SYNTHS.has(event.synth)?'plugin':'synthesized';
  return typeof event.kind==='string'?event.kind:'unknown';
}
export class RenderSession {
  constructor({spec,agents,meterApi=globalThis.MusebotMeter,engine,sink=null,clips=new Map,logs={},wallClock,onProgress=null,onMessage=null,strict=false}={}){
    if(spec?.version!==1||!spec.length||!spec.transport||!Array.isArray(spec.bots)||!spec.outputs)throw new TypeError('RenderSession needs a spec from normalizeRenderSpec()');
    if(!agents||typeof agents!=='object')throw new TypeError('RenderSession needs the agent definitions');
    if(typeof meterApi?.normalizeMeter!=='function'||typeof meterApi.clockContext!=='function')throw new TypeError('RenderSession needs a meter API (MusebotMeter)');
    validateEngine(engine);
    const performance=globalThis.performance;
    Object.assign(this,{spec,agents,meterApi,engine,rawSink:sink,sink:renderSink(sink,spec),logs:{decisions:logs?.decisions||null,notes:logs?.notes||null},
      clipAudio:clips instanceof Map?clips:new Map(Object.entries(clips||{})),
      // Bound now, before virtual time replaces performance.now, so render statistics measure real time.
      wallClock:wallClock||(typeof performance?.now==='function'?performance.now.bind(performance):Date.now),
      onProgress,onMessage,strict,lookahead:LOOKAHEAD,state:'created',errors:[],warnings:[],result:null,
      // Per bot, every UMP packet it played, in render seconds. Null unless the
      // spec asks for MIDI, because holding a whole performance in memory is
      // only worth it when something is going to be written from it.
      umpTracks:spec?.outputs?.midi?new Map:null,
      transport:null,timeline:null,socket:null,silent:null,tracks:[],incarnations:new Map,tick:0,musicSeconds:0,renderSeconds:0,seq:0,lastPercent:-1,
      sending:null,sinkBegun:false,sinkEnded:false,restoreTime:null,previousSeed:undefined,failure:null});
  }
  // Creates the spec's engine on renderSink(sink, spec) and a session sharing that sink. An engine the session then
  // refuses is disposed here, since no session exists to dispose it.
  static async create({spec,sink=null,environment,...options}={}){
    if(spec?.version!==1||typeof spec.engine!=='string')throw new TypeError('RenderSession needs a spec from normalizeRenderSpec()');
    const output=renderSink(sink,spec),engine=await createRenderEngine(spec.engine,{spec,sink:output,environment});
    try{return new RenderSession({...options,spec,sink:output,engine})}
    catch(error){try{await engine.dispose()}catch{/* the refusal is the error worth reporting */}throw error}
  }

  async run(){
    let failure=null;
    try{
      await this.prepare();
      while(!this.done)await this.step();
      return await this.finish();
    }catch(error){failure=this.failure=error;throw error}
    finally{
      try{await this.dispose(failure)}catch(error){if(!failure)throw error}
    }
  }

  async prepare(){
    if(this.state!=='created')throw new Error(`prepare() needs a new session, not a ${this.state} one`);
    this.state='preparing';this.wallStart=this.wallClock();
    const {spec,engine}=this,problems=unsupportedFeatures(engine.capabilities,spec,spec.engine,{agents:this.agents}),unsupported=problems.filter(problem=>problem.level==='error');
    if(unsupported.length)throw new RenderSpecError(unsupported.map(({path,message})=>({path,message})));
    for(const {path,message} of problems)this.warn(`${path}: ${message}`);
    if(engine.capabilities.audio&&'sink' in engine&&engine.sink!==this.sink)throw new Error('The engine writes to another sink than this session; create it with renderSink(sink, spec) or use RenderSession.create()');
    const transport=this.transport=new OfflineTransport(this.meterApi,{...spec.transport,lookahead:this.lookahead});
    // Clips that name the 'input' hearing are armed here when their adapters are made, before any bot joins.
    transport.renderInputs=(spec.arrangement?arrangementInputs:renderInputs)({arrangement:spec.arrangement,sampleRate:spec.sampleRate,transport,lookahead:this.lookahead,listening:spec.follow?.listening??null,foresight:spec.foresight===true});
    // Who hears each pulse first (transport.js `broadcast`): the bots that only ever publish, then the harmony sources
    // that will lead whatever happens, then the ones that lead only if nobody else does -- so they have heard a leader
    // before deciding they must be one -- and then everybody who plays.
    const ranks=new Map;
    for(const bot of spec.bots){
      const definition=this.agents[bot.id];if(!definition)continue;
      const capability=capabilitiesOf(bot.id,definition),harmony=capability.provides.includes('harmony');
      ranks.set(definition.name,!definition.outputModes?.length?0:harmony?capability.defers.includes('harmony')?2:1:3);
    }
    transport.clockRank=client=>client.observer?-1:ranks.get(client.agent)??3;
    this.clockRanks=ranks;
    const timeline=this.timeline=new RenderTimeline({spec,transport,lookahead:this.lookahead});
    timeline.readyToEnter=(tick,join,entry)=>this.readyToEnter(tick,join,entry);
    for(const entry of timeline.clips)timeline.setDecoded(entry,this.clipAudioFor(entry));
    // Engine audio is created before virtual time and the seeded random source exist: plugin hosts (WAM) derive ids
    // from the real performance.now, and nothing an engine draws can shift the bots' random streams.
    for(const entry of timeline.bots)entry.host=this.createHost(entry);
    for(const entry of timeline.bots)entry.audio=await this.createBotAudio(entry);
    // Plugins the engine owns (a mixer effect) load now too, and every plugin settles, still on real time.
    await engine.preparePlugins?.(spec);
    // Virtual time first: it refuses a second render in this process or page before the seed of the running one moves.
    this.restoreTime=installVirtualTime({uuid:'seeded',seed:spec.seed,getRenderSeconds:()=>this.renderSeconds});
    this.previousSeed=randomSeed();configureRandomSeed(spec.seed);
    // The piece's stated character reaches the bots' shared configuration as it does on the page (app.js): PlexBOT's and
    // TuneBOT's tables (public/shared/aesthetic-apply.js), before any bot decides; the ports' own configuration stays as
    // authored. Put back when the render ends.
    if(spec.character)this.restoreCharacter=applyCharacter(spec.character,{config:STOCHASTIC_CONFIG}).restore;
    this.openTimeline();
    for(const entry of timeline.clips)timeline.setAdapters(entry,await createHearingAdapters({clip:entry.clip,decoded:entry.decoded,spec,transport}));
    this.tracks=this.outputTracks();
    // Marked before begin() resolves, so a sink that fails part way through opening its tracks is aborted too.
    if(this.sink){this.sinkBegun=true;await this.sink.begin({sampleRate:spec.sampleRate,tracks:this.tracks})}
    // Engines that tap tracks learn them here, before any bot or clip exists.
    if(this.tracks.length)await engine.attachOutputs?.(this.tracks);
    for(const entry of timeline.dueJoins(0))await this.join(entry);
    // **The opening.** Everybody who starts the piece is in the room and nothing has pulsed, so this is the one moment
    // a bot can say how the piece BEGINS and have it be true of bar 1: mh_PlexBOT states its form and asks for its first
    // section's meter and tempo, and the transport, not having pulsed, applies them at once. Without this every piece
    // it shaped spent its first phrase in the spec's 4/4 and only then became itself. Asked in the same order pulses
    // are delivered, publishers first, so it is the same every time.
    const opening={...this.meterApi.clockContext(transport),musicSeconds:0};
    const openers=timeline.bots.filter(entry=>entry.state==='joined'&&entry.host)
      .map((entry,index)=>({entry,index,rank:ranks.get(this.agents[entry.spec.id]?.name)??3}))
      .sort((left,right)=>left.rank-right.rank||left.index-right.index);
    for(const {entry} of openers)entry.host.prepareOpening(opening);
    // The mixing listeners (spec desk, autoMix) are hired once the opening bots are in, as the live page hires them after
    // the bots run: a desk needs tracks to tap. They run on render time until finish() stops them, after the tail.
    if(spec.desk||spec.autoMix)await engine.startListeners({desk:spec.desk??null,autoMix:spec.autoMix??null,onDecision:record=>this.decide(record)});
    this.state='ready';
    return this;
  }

  get done(){
    const {spec:{length},transport}=this;
    if(!transport)return false;
    // (With length.untilEnding, the ending the ensemble committed: the render stops at its bar, the tail after.)
    if(length.untilEnding&&this.endingBar!=null&&transport.barStarts[this.endingBar]!=null)return true;
    const reached=length.ticks!=null?transport.latestTick>=length.ticks:length.bars!=null?transport.barStarts[length.bars]!=null
      :transport.musicSeconds>=length.seconds-EPSILON;
    return reached&&!this.playsOnToEnding();
  }
  // An ending the ensemble committed that the length would cut: where it is reached (at the tempo heard over the last
  // bar) within what the duration contract allows past a length (composition-duration.js maxElapsedRatio and
  // maxElapsedAbsoluteSeconds: 12.5 %, at most 60 s, by default), the render plays on to it, and never past that
  // allowance. A breathing band's 140 s fell five bars before the ending its form had committed, and the render cut its
  // piano mid-phrase (the user, 28 September: "When possible - i.e., when it wouldn't add too much time to the end -
  // give enough time for bots to complete their endings, so I can hear how they proceed musically"). Decided once, where
  // the length is reached.
  playsOnToEnding(){
    const {transport}=this;
    if(this.playOn===undefined){
      const policy=durationPolicy(this.spec.length.policy??{}),at=transport.musicSeconds,bar=Number(this.endingBar);
      const allowance=Math.min(policy.maxElapsedRatio*at,policy.maxElapsedAbsoluteSeconds),perBar=transport.meter?.pulsesPerBar;
      let until=null;
      if(Number.isInteger(bar)&&transport.barStarts[bar]==null&&bar>transport.bar&&perBar>0){
        const latest=transport.latestTick,from=Math.max(0,latest-perBar),perTick=latest>from?(transport.tickSeconds[latest]-transport.tickSeconds[from])/(latest-from):transport.currentInterval;
        const ticksLeft=(bar-transport.bar)*perBar-transport.tickInBar;
        if(ticksLeft*perTick<=allowance)until=at+allowance;
      }
      this.playOn=until==null?null:{bar,until};
      if(this.playOn)this.decide({kind:'lengthPlaysOn',endingBar:bar,lengthSeconds:at,untilSeconds:until});
    }
    return Boolean(this.playOn)&&transport.barStarts[this.playOn.bar]==null&&transport.musicSeconds<this.playOn.until;
  }

  async step(){
    if(this.state!=='ready')throw new Error(`step() needs a prepared session, not a ${this.state} one`);
    if(this.done)throw new Error('The render has reached its length; call finish()');
    const {transport,timeline,engine}=this,tick=transport.latestTick,musicSeconds=transport.tickSeconds[tick];
    this.tick=tick;this.musicSeconds=musicSeconds;
    // 1. Render time equals music time at the decision point; sound lands one lookahead later.
    this.setRenderSeconds(musicSeconds);engine.setTime(musicSeconds);
    // 2. Timers (lifecycle fades), then scheduled leaves and joins, so a joining bot hears this tick's cues and pulse.
    transport.fireDue(musicSeconds);
    for(const entry of timeline.dueLeaves(tick))this.leaveBot(entry);
    for(const {entry,request} of (this.forkRequests??[]).splice(0))await this.addFork(entry,request,tick);
    for(const entry of timeline.dueJoins(tick))await this.join(entry);
    this.configureListeners();
    this.startFollowing();
    // 3. (Local tempo following is pumped first.)
    const begun=transport.beginStep(),interval=begun.provisionalInterval;
    // 4. Cues, then hearing, over the window [musicSeconds, musicSeconds + provisional interval).
    const clock={...this.meterApi.clockContext(transport),musicSeconds,provisionalInterval:interval};
    timeline.hear({tick,musicSeconds,interval,clock},(message,via)=>this.sendCue(message,via));
    this.reportSpectra(musicSeconds);
    // 5.-6.
    transport.pulse();
    const ended=transport.endStep();
    // 7.
    for(const {entry,resolved} of timeline.dueClips(tick))await this.placeClip(entry,resolved,tick);
    // 8.
    await nextMacrotask();
    // 8b. Audio a bot committed and is still waiting for (a vocal phrase from the vocal service, public/vocal/vocal-player.js)
    // is waited for before render time passes the moment it has to be scheduled by: offline, a phrase is never late.
    await this.awaitHolds(ended.nextMusicSeconds);
    // 9.
    await engine.renderUntil(ended.nextMusicSeconds);
    this.silent?.setTime(ended.nextMusicSeconds);
    this.progress();
    return ended;
  }

  // What the desk hears of each bot, said to the room as a cue (desk-spectra.js): once a round of its measurement, the
  // first a round after it starts, keyed by the instance each bot is known by (casting prefers it to its estimates).
  reportSpectra(musicSeconds){
    const desk=this.engine.listening?.desk;
    if(typeof desk?.spectra!=='function')return;
    this.spectraAt??=musicSeconds+DESK_SPECTRA.everySeconds;
    if(musicSeconds<this.spectraAt)return;
    this.spectraAt=musicSeconds+DESK_SPECTRA.everySeconds;
    const players=new Map(this.timeline.bots.filter(entry=>entry.host?.bot).map(entry=>[entry.host.trackId,entry.host.bot.instanceId]));
    const report=deskSpectraMessage(desk.spectra(),{instanceOf:channel=>players.get(channel)??null});
    if(report)this.sendCue({address:DESK_SPECTRA.address,args:[report]},'desk');
  }

  // A listening bot leads the harmony once it listens (the default live). In a render the spec decides: only the bot
  // followed leads it, as spec.follow.harmony says, and any other listening bot only observes.
  configureListeners(){
    const follow=this.spec.follow;this.configuredListeners??=new WeakSet;
    for(const entry of this.timeline.bots){
      const host=entry.host;
      if(entry.state!=='joined'||!host?.bot||!FOLLOW_SOURCES.includes(entry.spec.id)||this.configuredListeners.has(host))continue;
      this.configuredListeners.add(host);
      if(!(follow&&entry.spec.id===follow.bot&&entry.spec.key===follow.key))host.bot.leadHarmony?.(false);
    }
  }

  // spec.follow, once its bot has joined: the conductor follows that bot's tempo and the bot leads the harmony, as
  // when someone starts listening in a live room. At tick 0 no pulse has been emitted, so it starts a step later.
  startFollowing(){
    const follow=this.spec.follow,transport=this.transport;
    if(!follow||this.following)return;
    const entry=this.timeline.bots.find(value=>value.spec.id===follow.bot&&value.spec.key===follow.key),host=entry?.host;
    if(entry?.state!=='joined'||!host?.bot||!(transport.nextAt>0))return;
    // follow.also: the other listening bots whose reports are fused with this one's, once every one has joined.
    const others=(follow.also??[]).map(other=>this.timeline.bots.find(value=>value.spec.id===other.bot&&(value.spec.key??null)===other.key));
    if(others.some(other=>other?.state!=='joined'||!other.host?.bot))return;
    const sources=others.length?[host,...others.map(other=>other.host)].map(member=>({id:member.instanceId,incarnation:member.incarnation})):null;
    this.following={bot:host.trackId,atTick:transport.tick,musicSeconds:transport.musicSeconds,tempo:null,harmony:null};
    // Tried once: a refusal (say, a tempo outside the following bounds) is the render's error, not retried each step.
    try{
      this.following.harmony=Boolean(host.bot.leadHarmony?.(Boolean(follow.harmony)));
      if(follow.tempo)this.following.tempo=transport.tempoFollowingAction({action:'follow-tempo',source:{id:host.instanceId,incarnation:host.incarnation},
        ...(sources?{sources}:{}),options:follow.tempo});
    }catch(error){this.recordError(error,host,'follow')}
    this.decide({kind:'following',bot:host.trackId,tempo:this.following.tempo?.enabled??false,harmony:this.following.harmony??false,options:follow.tempo});
  }

  // A bot that listens first joins on a beat, once the conductor has held the followed performer's beat for
  // join.beats beats in a row: it has understood the time before it plays.
  readyToEnter(tick,join,entry){
    const following=this.transport.localTempoFollowing,cursor=following?.beatCursor?.();
    if(!this.following?.tempo?.enabled||!cursor?.isBeat||cursor.tick!==tick)return false;
    const lock=beatLock(following.controller.decisions,{beats:join.beats});
    if(lock.locked)this.decide({kind:'listen-first-entry',bot:entry.spec.id,tick,musicSeconds:this.transport.tickSeconds[tick]??null,bpm:lock.bpm,heldSince:lock.since});
    return lock.locked;
  }

  async finish(){
    if(this.state!=='ready')throw new Error(`finish() needs a prepared session, not a ${this.state} one`);
    this.state='finishing';
    const {spec,engine,transport,timeline}=this,end=transport.musicSeconds,tailEnd=end+spec.tailSeconds+this.lookahead;
    this.tick=transport.latestTick;this.musicSeconds=end;this.setRenderSeconds(end);
    transport.fireDue(end);
    // (The music's end is the conductor's cutoff: what any player holds there is let go, as at a committed stop
    // (framework/agent.js cutOffAt) -- the transport stops at the render's length, so no tick at the stop's bar reached
    // the players, and a final chord held open to its cutoff rang on through the tail: Op. 3.31's last eight seconds.)
    engine.setTime?.(end);
    for(const entry of timeline.bots)if(entry.state==='joined'&&typeof entry.host?.bot?.cutOffAt==='function')
      try{entry.host.bot.cutOffAt({...(transport.clock?.()??{}),tick:transport.latestTick,musicSeconds:end})}catch(error){this.recordError(error,entry.host,'cutoff')}
    await this.awaitHolds(Infinity);
    // renderTail() may render on (e.g. while the mix still rings) and returns the render seconds it reached.
    let renderSeconds=tailEnd;
    if(engine.renderTail){const reached=await engine.renderTail({end,tailSeconds:spec.tailSeconds,lookahead:this.lookahead,renderSeconds:tailEnd});if(Number.isFinite(reached)&&reached>tailEnd)renderSeconds=reached}
    else await engine.renderUntil(tailEnd);
    // The listeners stop after the tail and restore nothing: the faders and sends they set are what the files hold.
    if(spec.desk||spec.autoMix)await engine.stopListeners({restore:false});
    // Bots leave only now, without a fade: a fade or a disposal before the tail would change what the tail holds.
    for(const entry of timeline.bots)if(entry.state==='joined')this.leaveBot(entry);
    // Real time again before engines flush: a page or file writer may time out on Date.now.
    this.restoreTime?.();this.restoreTime=null;
    await engine.finish();
    const output=this.sink?await this.sink.end():null;
    this.sinkEnded=true;
    for(const warning of [...timeline.warnings(),...Array.isArray(engine.warnings)?engine.warnings:[]])this.warn(String(warning));
    this.warnIgnored();
    // fileSeconds is how long the written files are: the render less the trimmed preroll.
    const wallSeconds=(this.wallClock()-this.wallStart)/1000,fileSeconds=renderSeconds-(spec.preroll==='trim'?this.lookahead:0);
    // Where the music ends, where a tail still ringing was released (tail-release.js: E33), and where the output stops.
    const ending=renderEnding({musicSeconds:end,renderSeconds,lookahead:this.lookahead,trimmed:spec.preroll==='trim',release:engine.tailRelease??null,
      sampleRate:engine.context?.sampleRate??spec.sampleRate});
    this.result={ticks:transport.latestTick,bars:transport.bar,musicSeconds:end,renderSeconds,fileSeconds,ending,wallSeconds,
      realtimeFactor:wallSeconds>0?fileSeconds/wallSeconds:null,errors:this.errors.map(error=>({...error})),warnings:[...this.warnings],tracks:output?.tracks??[]};
    this.state='finished';
    this.progress(true);
    if(this.strict&&this.errors.length){
      const [first]=this.errors;
      throw Object.assign(new Error(`${this.errors.length} bot error(s) during the render; the first, ${first.bot??'the render'} at tick ${first.tick}: ${first.message}`,{cause:first.error}),{errors:this.errors,result:this.result});
    }
    return this.result;
  }

  // Safe to call at any point and twice. Bots still in the ensemble are removed while render time is still virtual.
  // Every step runs even when one fails (a sink that cannot abort must not keep the engine alive); the first failure
  // is rethrown at the end.
  async dispose(error=this.failure){
    if(this.state==='disposed'||this.disposing)return;
    this.disposing=true;
    let failure=null;
    const attempt=async action=>{try{await action()}catch(caught){failure??=caught}};
    try{
      for(const entry of this.timeline?.bots||[]){
        try{
          if(entry.host&&!['created','leaving','left'].includes(entry.host.state))entry.host.remove();
          // Audio made for a bot that never started has no host to dispose it.
          else if(entry.host?.state==='created')entry.audio?.dispose?.();
        }catch{/* the render is over */}
      }
      try{this.socket?.close()}catch{/* the ensemble is being discarded */}
      if(this.sinkBegun&&!this.sinkEnded)await attempt(()=>this.rawSink?.abort?.(error));
      await attempt(()=>this.engine.dispose());
    }finally{
      this.restoreTime?.();this.restoreTime=null;
      this.restoreCharacter?.();this.restoreCharacter=null;
      if(this.previousSeed!==undefined){configureRandomSeed(this.previousSeed);this.previousSeed=undefined}
      this.state='disposed';this.disposing=false;
    }
    if(failure)throw failure;
  }

  clipAudioFor({id,spec:clip}){
    const {spec,engine}=this;
    let decoded=this.clipAudio.get(id)??null;
    if(!decoded&&clip.file?.generate)decoded=generateClipAudio(clip.file.generate,spec.sampleRate,{seed:`${spec.seed}:${id}`});
    if(decoded&&decoded.sampleRate!==spec.sampleRate)throw new RangeError(`Clip "${id}" is decoded at ${decoded.sampleRate} Hz; the render runs at ${spec.sampleRate} Hz`);
    if(!decoded&&engine.capabilities.audio)throw new Error(`Clip "${id}" has no decoded audio; pass it in clips (a Map of clip id to {sampleRate, channels})`);
    return decoded;
  }
  // "engine": rendered by the engine. "silent": output "none" on a bot that plays, given score audio so its decisions are
  // the ones an audible render makes. "none": a message-only bot (HeadlessBot's stand-in audio).
  audioKind(botSpec){return botSpec.output!=='none'?'engine':availableModes(this.agents[botSpec.id]).length?'silent':'none'}
  // A batch's times are seconds from its own start; a file's are seconds from
  // the top of the render. fileSeconds subtracts the lookahead for exactly the
  // same reason notes.jsonl does: so the MIDI lines up with the WAV beside it.
  collectUmp(trackId,batch){
    if(!this.umpTracks||!batch?.events?.length)return;
    let events=this.umpTracks.get(trackId);
    if(!events)this.umpTracks.set(trackId,events=[]);
    const start=Number(batch.startSeconds)||0;
    for(const event of batch.events)events.push({seconds:start+event.time,packet:event.packet});
  }

  createHost(entry){
    const {spec:botSpec}=entry,kind=entry.kind=this.audioKind(botSpec);
    const host=new HeadlessBot({agents:this.agents,definitionId:botSpec.id,key:botSpec.key,randomKey:botSpec.randomKey??botSpec.key,room:ROOM,transport:this.transport,audio:()=>entry.audio,
      mixer:kind==='engine'?this.engine.mixer??null:null,seed:this.spec.seed,output:kind==='engine'?botSpec.output:undefined,loadOnly:botSpec.loadOnly,mix:botSpec.mix,
      settings:botSpec.settings??null,renderEnd:Object.freeze({...this.spec.length}),renderFeel:this.spec.transport.feel??null,renderExpression:this.spec.transport.expression??null,
      // A desk that places or groups the band hears each drum of a drum bot's kit on its own channel.
      kits:kind==='engine'&&splitsKits(this.spec.desk),
      hooks:{
        onAgentFork:request=>{(this.forkRequests??=[]).push({entry,request})},
        // A message the ensemble refused as malformed: logged at its tick, and said in the manifest's warnings.
        onProtocolError:(message,bot)=>{this.decide({kind:'protocol-error',bot:bot.trackId,address:message.address,errors:message.errors});
          this.warn(`${bot.trackId} sent ${message.address} malformed, and it was refused: ${message.errors?.[0]??'no reason given'}`)},
        onNote:kind==='engine'?event=>this.logNote(event):undefined,
        onUmp:kind==='engine'&&this.umpTracks?(batch,bot)=>this.collectUmp(bot.trackId,batch):undefined,
        onLifecycle:(state,bot)=>this.decide({kind:'lifecycle',bot:bot.trackId,state}),
        // Notes a chord change released (HarmonicRelease, as live): which, and the harmony they fell outside.
        onRelease:(release,bot)=>this.decide({kind:'release',bot:bot.trackId,at:+bot.soundingAt().toFixed(3),harmony:[...bot.harmonicRelease.classes].map(pc=>+pc.toFixed(2)).sort((a,b)=>a-b),
          notes:release.released.map(note=>({pitch:+note.note.toFixed(3),startedAt:+note.startedAt.toFixed(3)}))}),
        onError:(error,bot)=>this.recordError(error,bot),
        onWarning:(text,bot)=>this.warn(`${bot.trackId}: ${text}`),
        // A sung phrase the voice service refused, or placed too late to sound: logged at its tick, and a refusal said in
        // the manifest's warnings (Op. 3.4's rap lost half its lines to refusals nothing reported).
        onAudioEvent:kind==='engine'?(event,bot)=>{
          // (A bot that says it cannot play here, or only in part -- a singer whose voice cannot read a word of its text,
          // a service not answering -- said in the manifest's warnings: Op. 3.11's first render had two silent singers
          // and none.)
          if(event.kind==='bot_status'&&(event.state==='unavailable'||event.state==='limited')){
            this.decide({kind:'bot-status',bot:bot.trackId,state:event.state,message:String(event.message??'')});
            this.warn(`${bot.trackId} is ${event.state}: ${event.message??'no reason given'}`);return;
          }
          // (A player's personality as it starts, and the register and motif it takes from it: bots/lib/modules/personality.js.)
          if(event.kind==='personality'){const {kind,mode,...details}=event;this.decide({kind,bot:bot.trackId,...details});return}
          if(event.kind!=='vocal_failed'&&event.kind!=='vocal_late')return;
          this.decide({kind:event.kind,bot:bot.trackId,planId:event.planId,...(event.error?{error:event.error}:{}),...(event.lateBySec!=null?{lateBySec:event.lateBySec}:{})});
          if(event.kind==='vocal_failed')this.warn(`${bot.trackId}: a sung phrase was refused (${event.error??event.code})`);
        }:undefined,
        onMessage:this.onMessage?(direction,message,bot)=>this.onMessage(direction,message,bot):undefined,
      }});
    // The ensemble lists it without an output, as app.js lists a message-only bot.
    if(kind!=='engine')host.output=null;
    return host;
  }
  async createBotAudio(entry){
    const {kind,host,spec:botSpec}=entry,transport=this.transport;
    if(kind==='none')return null;
    const audio=kind==='silent'
      ?await createScoreAudio({context:this.silent??=new ScoreContext({sampleRate:this.spec.sampleRate}),soundSeed:host.soundSeed,transport,synthesizer:botSpec.synthesizer,synthOptions:botSpec.synthOptions})
      :await this.engine.createAudio({botSpec,soundSeed:host.soundSeed,transport,trackId:host.trackId,key:host.key,seed:host.seed,definition:host.definition,
        output:host.output,performing:host.performing,onNote:event=>this.logNote({...event,bot:host.trackId})});
    if(audio&&audio.clock?.transport!==transport)audio.clock=new TimelineClock({transport});
    // A bowed string on a physical model, where the render plays one (render/node/physical-strings.mjs sets
    // this.physical): its strokes logged for the model ('plan'), or the model's audio of its part played ('play').
    if(audio&&kind==='engine'&&this.physical&&botSpec.id==='bowedstring_clodbot'){
      // (Its strokes as MIDI 2.0 too, `ump`: what the model plays, read back -- audio.js bowedNote.)
      audio.physical={mode:this.physical.mode,log:[],ump:[],buffer:this.physical.buffers?.get(host.trackId)??null};
      this.physical.logs.set(host.trackId,{log:audio.physical.log,ump:audio.physical.ump,seat:botSpec.settings?.seat??null,label:botSpec.label??null});
    }
    // Audio a bot is still waiting for from elsewhere, due by render time `until` (docs/VOCALS.md): see awaitHolds(). `work` is
    // a promise, or a function called at that time which places the audio and returns a promise.
    if(audio&&kind==='engine')audio.holdRender=(work,until)=>{(this.holds??=[]).push({work,until:Number(until),order:this.holdOrder=(this.holdOrder??0)+1})};
    // (Where the render ends, audio.renderEnd, the bot's host sets on whatever audio the bot has: bot-host.js.)
    // Muting is the session's (join(), after start as app.js does), so every engine publishes the same setups.
    if(audio?.muted)audio.muted=false;
    return audio??null;
  }
  // A bot's fork (logic-conflicts.js /agent/fork): a sibling of it, the same bot on the same output, made with the
  // fork's settings, joining at the bar after the request and leaving where it leaves. A fork asks for no fork.
  async addFork(from,request,tick){
    const settings=forkSettings(request?.settings);
    if(from.spec.settings?.forkOf||!settings.forkOf){this.warn(`${from.host?.trackId}: a fork's request for another fork was not made`);return;}
    // The transport's bar counts from 0; a spec's from 1: the next bar is the transport's bar and two.
    const timeline=this.timeline,bar=(this.transport.bar??0)+2;
    let key=`${from.spec.key}-fork`;for(let n=2;timeline.bots.some(entry=>entry.spec.id===from.spec.id&&entry.spec.key===key);n++)key=`${from.spec.key}-fork${n}`;
    const spec={...from.spec,key,settings:{...(from.spec.settings??{}),...settings},join:{bar,beat:1}};
    const entry={index:timeline.bots.length,spec,state:'waiting',host:null,audio:null,forkOf:from.index};
    timeline.bots.push(entry);
    entry.host=this.createHost(entry);entry.audio=await this.createBotAudio(entry);
    this.decide({kind:'fork',from:from.host?.trackId,bot:entry.host.trackId,conflict:request?.conflict??null,settings:spec.settings,tick,joinBar:bar});
  }
  async join(entry){
    entry.state='joining';
    try{
      await entry.host.start();
      entry.state='joined';
      // As app.js applies a saved mute: after start, then published.
      if(entry.spec.muted&&entry.host.audio){entry.host.audio.muted=true;entry.host.publishSetup()}
    }catch(error){entry.state='failed';this.recordError(error,entry.host,'start')}
  }
  leaveBot(entry){
    entry.state='left';
    if(['created','leaving','left'].includes(entry.host.state))return;
    try{entry.host.leave({fadeSeconds:0})}catch(error){this.recordError(error,entry.host,'leave')}
  }
  async placeClip(entry,resolved,tick){
    const placement=this.timeline.place(entry,resolved,tick);
    await this.engine.placeClip(entry.clip,{renderSeconds:placement.renderSeconds,fileSeconds:placement.fileSeconds,frame:placement.frame,decoded:entry.decoded});
    this.decide({kind:'clip',id:entry.id,tick,fileSeconds:placement.fileSeconds});
  }
  outputTracks(){
    const {spec,engine}=this,tracks=[];
    if(!engine.capabilities.audio)return tracks;
    // An object stem is the source before it is placed, so it is mono (the engines tap it before
    // the panner and mix it down); the mix is the desk's own mix and stays stereo.
    const stemChannels=spec.outputs.stemTap==='object'?1:2;
    if(spec.outputs.mix)tracks.push({id:'mix',kind:'mix',channels:2});
    if(spec.outputs.stems.includes('bots'))for(const bot of spec.bots)if(bot.output!=='none')tracks.push({id:botTrackId(bot.id,bot.key),kind:'bot',channels:stemChannels});
    if(spec.outputs.stems.includes('clips'))for(const clip of spec.clips)tracks.push({id:`clip:${clip.id}`,kind:'clip',channels:stemChannels});
    // The mix less every stemmed channel: stereo whatever the stem tap, because it is the mix's own.
    if(spec.outputs.stems.includes('returns'))tracks.push({id:RETURNS_TRACK,kind:'return',channels:2});
    return tracks;
  }

  // The timeline is an observer client: it sends cues into the room and, being the first client, hears every broadcast
  // (its own cues included) before any bot does.
  openTimeline(){
    const socket=this.socket=this.transport.connect();
    socket.send(JSON.stringify({type:'join',room:ROOM,agent:TIMELINE,observer:true}));
    // (What the render hears -- each bar's attention, the ensemble's committed ending, its character -- whether or not it
    // logs: attached only with a decisions log, a render without one never heard its ending and played on past it (the
    // studio page's two passes, 25 October 2026, one logged and one not, ended a clarinet's last note apart).)
    socket.addEventListener('message',event=>this.observe(JSON.parse(event.data)));
    // The desk's feedback loops, moved by bots (/agent/feedback with a loop: public/shared/feedback-loops.js), whether or
    // not decisions are logged.
    socket.addEventListener('message',event=>this.feedback(JSON.parse(event.data)));
    // And the cuts bots ask the desk for (/agent/cut: public/shared/mix-cuts.js).
    socket.addEventListener('message',event=>this.cut(JSON.parse(event.data)));
    socket.addEventListener('message',event=>this.edit(JSON.parse(event.data)));
    socket.addEventListener('message',event=>this.formant(JSON.parse(event.data)));
    socket.addEventListener('message',event=>this.mixIntention(JSON.parse(event.data)));
    socket.addEventListener('message',event=>this.attention(JSON.parse(event.data)));
    socket.addEventListener('message',event=>this.effects(JSON.parse(event.data)));
  }
  // A scene's mix intention (/broadcast/mixIntention: public/shared/mix-intention.js), said by the form or a section's
  // plan, to the desk, as the live page gives it to its desks: a scene change made when the tick it was said on is heard
  // (a section's downbeat), as an edit is. A render without a desk has nobody to take it; one the desk cannot take is
  // logged as refused.
  mixIntention(message){
    if(message.type!=='protocol'||message.address!==MIX_INTENTION_ADDRESS)return;
    const desk=this.engine?.listening?.desk;if(!desk)return;
    const {intention=null,permissions=[],section=null}=message.args?.[0]??{};
    const heard=(this.transport?.tickSeconds?.[this.tick]??desk.context.currentTime)+this.lookahead;
    try{const reach=desk.setIntention(intention,{permissions,atSeconds:heard});this.decide({kind:'mixIntention',source:message.source??null,...(section?{section}:{}),intention:reach.intention,held:reach.held,unheld:reach.unheld,permissions:reach.permissions,...(reach.scene?{scene:reach.scene}:{})})}
    catch(error){this.decide({kind:'mixIntention',source:message.source??null,refused:error.message})}
  }
  // The band's attention (/broadcast/attention: shared/attention.js, ManageBOT's for each section, said a phrase ahead for
  // its first bar), to the desk, which moves each part's balance by its share against its typical share
  // (live-desk.js setAttention): kept until the clock reaches its bar (observe), then taken and logged.
  attention(message){
    if(message.type!=='protocol'||message.address!=='/broadcast/attention')return;
    const said=message.args?.[0];if(!said||!Number.isInteger(said.atBar))return;
    this.attentionPending=[...(this.attentionPending??[]).filter(entry=>entry.said.atBar!==said.atBar),{said,source:message.source??null}].sort((a,b)=>a.said.atBar-b.said.atBar);
  }
  takeAttention(bar){
    const desk=this.engine?.listening?.desk;if(!desk?.setAttention||!this.attentionPending?.length)return;
    const due=this.attentionPending.filter(entry=>entry.said.atBar<=bar);if(!due.length)return;
    this.attentionPending=this.attentionPending.filter(entry=>entry.said.atBar>bar);
    const {said,source}=due.at(-1);
    try{const held=desk.setAttention(said);this.decide({kind:'attention',source,atBar:said.atBar,soloist:held?.soloist??null,offsets:held?.offsets??{},...(held?.shifted?{shifted:held.shifted}:{})})}
    catch(error){this.decide({kind:'attention',source,atBar:said.atBar,refused:error.message})}
  }
  // An effects bot's request (/agent/effects: public/shared/effects-routing.js): the part it processes sent, after its
  // fader, into the effects bot's own channel, and the chain there moved, from when the tick it was sent on is heard.
  // The render waits for the chain to be built before it renders what the chain hears (a hold, as for a singer's audio).
  effects(message){
    const mixer=this.engine?.mixer;
    if(message.type!=='protocol'||message.address!==EFFECTS_ADDRESS||!mixer?.tracks)return;
    const effectsId=this.botFor(message.sourceIncarnation);if(!effectsId)return;
    const heard=(this.transport?.tickSeconds?.[this.tick]??mixer.context.currentTime)+this.lookahead;
    this.effectsState??=new Map;
    const work=applyEffects(mixer,{effectsId,request:message.args?.[0],atSeconds:heard,state:this.effectsState})
      .then(result=>this.decide({kind:'effects',source:message.source??null,...result}))
      .catch(error=>this.decide({kind:'effects',source:message.source??null,refused:error.message}));
    (this.holds??=[]).push({work,until:heard,order:this.holdOrder=(this.holdOrder??0)+1});
  }
  // A formant course (/agent/formant: public/shared/mix-formants.js), from when the tick it was sent on is heard, as an edit.
  formant(message){
    const mixer=this.engine?.mixer;
    if(message.type!=='protocol'||message.address!=='/agent/formant'||typeof mixer?.formant!=='function')return;
    this.formants??=new MixFormants(mixer,{log:record=>this.decide(record)});
    const heard=(this.transport?.tickSeconds?.[this.tick]??mixer.context.currentTime)+this.lookahead;
    this.formants.request(message.args?.[0],{start:heard,source:message.source??null});
  }
  // An edit (/agent/edit: public/shared/mix-edits.js), from when the tick it was sent on is heard, as a cut.
  edit(message){
    const mixer=this.engine?.mixer;
    if(message.type!=='protocol'||message.address!=='/agent/edit'||typeof mixer?.edit!=='function')return;
    this.edits??=new MixEdits(mixer,{log:record=>this.decide(record)});
    const heard=(this.transport?.tickSeconds?.[this.tick]??mixer.context.currentTime)+this.lookahead;
    this.edits.request(message.args?.[0],{start:heard,source:message.source??null});
  }
  // A cut, from when the tick it was sent on is heard: that tick's music time plus the lookahead, where its notes land.
  cut(message){
    const mixer=this.engine?.mixer;
    if(message.type!=='protocol'||message.address!=='/agent/cut'||typeof mixer?.cut!=='function')return;
    this.cuts??=new MixCuts(mixer,{log:record=>this.decide(record)});
    const heard=(this.transport?.tickSeconds?.[this.tick]??mixer.context.currentTime)+this.lookahead;
    this.cuts.request(message.args?.[0],{start:heard,source:message.source??null});
  }
  feedback(message){
    const mixer=this.engine?.mixer;if(!mixer)return;
    // An engine without render-time timers applies releases on the clock's ticks, so none after the music ends.
    if(message.type==='clock'){if(!this.loopsClock)this.loops?.tick(mixer.context.currentTime);return}
    const request=message.type==='protocol'&&message.address==='/agent/feedback'?message.args?.[0]:null;
    // A loop request names its loop or its amount; a request naming a patch is the page's routing, not the desk's.
    if(!request||typeof request!=='object'||request.loop===undefined&&request.amount===undefined)return;
    if(!this.loops){
      this.loops=new FeedbackLoops(mixer,{log:record=>this.decide(record)});
      // Releases are applied on render time, as a page applies them on its interval (app.js): the render's timers run on
      // through the tail, where the clock has stopped and a feedback let ring past the last bar is released.
      this.loopsClock=this.engine.timers?.every?.(FEEDBACK_REQUESTS.tickMs,()=>this.loops.tick(mixer.context.currentTime))??null;
    }
    this.loops.request(request,{now:mixer.context.currentTime,source:message.source??null});
  }
  // Bots' handler errors are theirs (onError); what escapes is the ensemble refusing the cue itself, e.g. a tempoCurve of null.
  sendCue({address,args=[]},via){
    this.sending=via;
    try{this.socket.send(JSON.stringify({type:'protocol',address,args}))}
    catch(error){throw new Error(`${via} ${address} at tick ${this.tick}: ${error?.message??error}`,{cause:error})}
    finally{this.sending=null}
  }
  observe(message){
    if(message.type==='clock')this.takeAttention(message.bar);
    else if(message.type==='protocol'){this.hearEnding(message);this.hearCharacter(message)}
    if(!this.logs.decisions)return;
    switch(message.type){
      case 'clock':return this.decide({kind:'tick',tick:message.tick,bar:message.bar,tickInBar:message.tickInBar,bpm:message.bpm});
      case 'protocol':{
        if(this.sending&&message.source===TIMELINE)return this.decide({kind:'cue',via:this.sending,source:message.source,address:message.address,args:message.args});
        // source is the agent name, shared by every instance of an agent; bot names the instance, as notes do.
        const bot=this.botFor(message.sourceIncarnation);
        return this.decide({kind:'message',source:message.source,...bot?{bot}:{},address:message.address,args:message.args});
      }
      case 'presence':return this.decide({kind:'presence',agent:message.agent,state:message.state,count:message.count});
      case 'ensemble_session':return this.decide({kind:'session',ensemble:message.ensemble});
      case 'tempo':return this.decide({kind:'tempo',bpm:message.bpm,curveActive:message.curveActive});
      case 'meter_queued':return this.decide({kind:'meterQueued',meter:message.meter,targetBar:message.targetBar});
      case 'meter_changed':return this.decide({kind:'meter',meter:message.meter,bar:message.bar});
      // Its own welcome and /system/instance arrive while it joins, before anything is logged.
      case 'welcome':return;
      default:return this.decide({kind:'broadcast',message});
    }
  }
  // A character said as the piece goes (stylespace_clodbot, a cue) reaches the bots' shared configuration as the page's
  // does (app.js applyCharacterMessage): the one in force put back, then the new one applied, so that PlexBOT and TuneBOT
  // decide by it from here. Put back when the render ends.
  hearCharacter({address,args}){
    if(address!=='/broadcast/character')return;
    const vector=args?.[0]?.vector??args?.[0];
    if(!vector||typeof vector!=='object')return;
    try{this.restoreCharacter?.();this.restoreCharacter=applyCharacter(vector,{config:STOCHASTIC_CONFIG}).restore}
    catch(error){this.restoreCharacter=null;this.decide({kind:'character-refused',reason:error?.message??String(error)})}
  }
  // An ending the ensemble commits, the latest said: form_clodbot's closing (/broadcast/form/closing, the bar the
  // ensemble stops before), or a committed stop (a lifecycle plan's commitment, as mh_FormBOT commits one). A render
  // whose length says untilEnding is done at that bar (done); the length is the most it plays.
  hearEnding({address,args}){
    const value=args?.[0];
    if(address===CLOSING_ADDRESS&&Number.isInteger(value?.endsAt?.bar))this.endingBar=value.endsAt.bar;
    else if(address==='/broadcast/plan'&&value?.kind==='lifecycle'&&value.payload?.action==='stop'&&value.payload?.phase==='commitment'&&Number.isInteger(value.appliesAt?.bar))
      this.endingBar=value.appliesAt.bar;
  }
  // The ensemble stamps each message with its client's incarnation, which a host learns in its welcome, before it sends.
  botFor(incarnation){
    if(!incarnation)return null;
    if(!this.incarnations.has(incarnation))this.incarnations.set(incarnation,this.timeline.bots.find(entry=>entry.host?.incarnation===incarnation)?.host.trackId??null);
    return this.incarnations.get(incarnation);
  }
  // The holds due by `untilSeconds`, settled one at a time in the order they fall due (then the order they were made): what
  // they place is placed at the same step and in the same order however long its audio took to prepare.
  async awaitHolds(untilSeconds){
    if(!this.holds?.length)return;
    const due=this.holds.filter(hold=>!(hold.until>untilSeconds)).sort((a,b)=>a.until-b.until||a.order-b.order);
    if(!due.length)return;
    this.holds=this.holds.filter(hold=>hold.until>untilSeconds);
    for(const hold of due)await Promise.resolve().then(()=>typeof hold.work==='function'?hold.work():hold.work).catch(()=>{});
    await nextMacrotask();
  }
  decide(record){
    const log=this.logs.decisions;
    if(log)log.write({seq:++this.seq,tick:this.tick,musicSeconds:this.musicSeconds,...record});
  }
  logNote(event){
    const log=this.logs.notes;if(!log)return;
    const renderSeconds=Number(event.renderSeconds),timed=Number.isFinite(renderSeconds);
    // A note planned ahead (a sung phrase) is logged at its own tick, not the one it was scheduled on, with its lyric.
    log.write({tick:Number.isFinite(event.tick)?event.tick:this.tick,bot:event.bot,kind:event.kind||'dsp',renderSeconds:timed?renderSeconds:undefined,fileSeconds:timed?renderSeconds-this.lookahead:undefined,
      pitch:midiPitch(event),velocity:event.velocity,duration:event.duration,identity:event.identity,
      ...(event.lyric&&typeof event.lyric==='object'?{lyric:event.lyric}:{}),
      // A note whose pitch moves (a sung transition or glide): [{seconds, cents}] from its start and its pitch.
      ...(Array.isArray(event.trajectory)&&event.trajectory.length?{trajectory:event.trajectory}:{}),
      // Where a sung note's vowel sounds, seconds from its start (vocal-player.js vowelSpans).
      ...(Number.isFinite(event.vowel?.from)&&Number.isFinite(event.vowel?.to)?{vowel:{from:event.vowel.from,to:event.vowel.to}}:{}),
      // Where its pitch came from, when a pitch language chose it: a row member's form and position, a motive note's node
      // (docs/PITCH_LANGUAGES.md).
      ...(event.pitchLanguage&&typeof event.pitchLanguage==='object'?{pitchLanguage:event.pitchLanguage}:{}),
      // The recording a grain note sounded from (docs/GRAINS.md): its unit's id in its corpus.
      ...(typeof event.unit==='string'?{unit:event.unit}:{}),
      // What a score's note is joined to (the implementation dossier's A001 and A007): the note's own identity (its bot's
      // track and its engine's number for it), how it was made, and, for a recording, which one and how far its rate
      // moved it.
      ...(Number.isInteger(event.noteId)?{note:`${event.bot}#${event.noteId}`}:{}),
      mechanism:noteMechanism(event),
      ...(event.kind==='sample'&&typeof event.bank==='string'&&typeof event.identity==='string'?{asset:`${event.bank}/${event.identity}`}:{}),
      ...(Number.isFinite(event.shift)?{shift:Math.round(event.shift*1e4)/1e4}:{})});
  }
  recordError(error,host,phase){
    const record={tick:this.tick,musicSeconds:this.musicSeconds,bot:host?.trackId??null,...(phase?{phase}:{}),message:String(error?.message??error)};
    this.errors.push(Object.defineProperty(record,'error',{value:error,enumerable:false}));
    this.decide({kind:'error',bot:record.bot,...(phase?{phase}:{}),message:record.message});
  }
  warn(text){if(!this.warnings.includes(text))this.warnings.push(text)}
  warnIgnored(){
    const counts=new Map;
    for(const {address,bar} of this.transport.ignored){const count=counts.get(address);counts.set(address,count?{...count,n:count.n+1}:{n:1,bar})}
    for(const [address,{n,bar}] of counts)this.warn(`transport: ${n} ${address} message(s) ignored (${address.endsWith('tempoCurve')?'lockTempo':'lockMeter'}), the first in bar ${bar+1}`);
  }
  setRenderSeconds(seconds){this.renderSeconds=seconds;this.silent?.setTime(seconds)}
  progress(final=false){
    if(!this.onProgress)return;
    const {spec:{length},transport}=this;
    const fraction=final?1:Math.min(1,length.ticks!=null?transport.latestTick/length.ticks:length.bars!=null?(transport.bar+transport.tickInBar/transport.meter.pulsesPerBar)/length.bars:transport.musicSeconds/length.seconds);
    const percent=Math.floor(fraction*100);
    if(!final&&percent<=this.lastPercent)return;
    this.lastPercent=percent;
    this.onProgress({tick:transport.latestTick,musicSeconds:transport.musicSeconds,fraction});
  }
}
