import {FORK_ADDRESS} from '../shared/logic-conflicts.js';
import {executionWatch} from '../shared/execution-watch.js';
import {specSettings} from '../shared/spec-settings.js';
import {resolveBotId} from '../framework/bot-registry.js';
import {HarmonicRelease} from '../../experiments/note-offs/harmonic-release.js';
import {capabilitiesOf} from '../../experiments/setup-phase/capabilities.js';
import {hashSeed,randomSeed} from '../random-source.js';
import {normalizeProtocolMessage} from '../shared/protocol-contract.js';
import {UmpMotifCapture} from '../shared/ump-events.js';
import {sendMemoryMessage} from '../shared/memory-transfer.js';
import {botMenuGroup} from '../shared/bot-menu.js';
import {mixSettings} from '../shared/sound-settings.js';
import {RECONNECT_CODES} from '../shared/room-socket.js';
import {breathSeconds} from '../shared/performance-timing.js';
import {installHoldTiming} from '../shared/hold-timing.js';
import {bandPhraseBars,bandTempo,bandMeter} from '../shared/opening-time.js';

// The DOM-free counterpart of app.js BotInstance. Everything that decides what
// the ensemble hears follows BotInstance line for line; UI, latency probes and
// MIDI routing are left out, and host timers run on the transport's render clock.
const OPEN=1,CLOSING=2;

export const availableModes=definition=>[...(definition?.previewOutputModes||definition?.outputModes||[])];
export const outputMode=(definition,requested)=>{const modes=availableModes(definition);return modes.includes(requested)?requested:modes[0]||null};
export const botSoundSeed=(seed,key,definitionId)=>hashSeed(`${seed}:${key}:${definitionId}:sound`);
export const botTrackId=(definitionId,key)=>`bot:${definitionId}:${key}`;
// ClientEnsemble names members `${agent}:${key}`; setting it before start() lets
// start-time messages carry the identity /system/instance confirms on join.
export const botInstanceId=(definition,key)=>`${definition.name}:${key}`;
// Render specs call the fader `gain`; the mixer track calls it `dry`.
export const botMix=(mix={})=>mixSettings(mix&&mix.dry===undefined&&mix.gain!==undefined?{...mix,dry:mix.gain}:mix);

export function botSetup({definition,key,output=outputMode(definition,'synth'),performing=true,audio=null,mix=botMix(),forkOf=null}){
  return {id:definition.id,key:String(key),output,loadOnly:!performing,muted:Boolean(audio?.muted),
    synthesizer:audio?.synthesizer,synthOptions:audio?.synthOptions,samplePreset:audio?.samplePreset,sampleSource:audio?.sampleSource,mix,
    midiProtocol:'midi1',midiGroup:1,channel:'default',
    mpeZone:definition.performanceType==='polyphonic'||definition.previewOutputModes?.includes('midi')?'lower':'single',bendRange:48,
    ...(forkOf?{forkOf}:{})};
}
export function joinMessage({definition,room='main',seed,setup}){
  return {type:'join',room,agent:definition.name,definitionId:definition.id,...(seed===undefined?{}:{seed:hashSeed(seed)}),...setup};
}
// output: the host's (null where the room lists it without one: a render's bot whose spec says none, heard only by its
// messages, as a harmony source played as a chart is). It is then message-only here whatever it could sound, so a manager
// does not cast it as a performer: ManageBOT built a trio's opening from a silent harmony source first, eight seconds of
// silence.
export function agentState({definition,bot=null,incarnation,state,output}){
  return {instanceId:bot?.instanceId||definition.id,incarnation,definitionId:definition.id,name:definition.name,state,
    functionGroup:botMenuGroup(definition),category:definition.category,outputModes:[...definition.outputModes],
    messageOnly:!definition.outputModes.length||output===null,protocolCapabilities:bot?.protocolCapabilities||{}};
}
// A fade of so many bars, in seconds. The clock's BPM counts the meter's own note (shared/tempo-display.js), so a bar is
// its numerator of them: 7/8 at 120 is 3.5 s. (It had been counted in quarters, and a fade in eighths lasted half its bars.)
export function lifecycleFadeSeconds(payload={},clock={}){
  const meter=clock?.meter||{},bars=Math.max(0,Number(payload?.fadeBars)||0);
  return (bars*(meter.numerator||bandMeter().numerator)*60)/(clock?.bpm||bandTempo());
}
// `harmony` is what the phrase was played against, in the motif's own ticks; a bot that followed none has none.
export function capturedMotifOptions(captured,clock,definition){
  return {timebase:captured.timebase,metadata:{defaultBpm:captured.defaultBpm,...(captured.harmony?.length?{harmony:{period:12,segments:captured.harmony}}:{}),...(captured.written?{written:captured.written}:{})},
    createdAt:{bar:Math.max(0,(clock.bar||0)-(clock.meter?.phraseBars||bandPhraseBars())),phrase:Math.max(0,(clock.phrase||0)-1),section:clock.section||0},
    tags:[definition.category,'captured-performance']};
}
// A shaped note's engine velocity is its level, which may pass unity (audio.js); the performed velocity is musicalVelocity.
// (`synth`: the engine's synthesizer, which says how the note was made: the built-in voice, a plugin, a sampled kit.)
export function dspNoteEvent(event,{trackId,definitionId,key,tick=null,synth}={}){
  const frequency=Number(event?.frequency),pitch=frequency>0?Math.round((69+12*Math.log2(frequency/440))*1e6)/1e6:undefined;
  return {tick,bot:trackId,definitionId,key,kind:'dsp',model:event?.model,renderSeconds:event?.atSeconds,pitch,frequency:event?.frequency,
    velocity:event?.musicalVelocity??event?.velocity,duration:event?.duration,identity:event?.identity,
    ...(Number.isInteger(event?.identity)?{noteId:event.identity}:{}),...(typeof synth==='string'?{synth}:{})};
}
// Message-only bots get no engine audio; Agent still routes lifecycle and status through it.
// Unmuted like BotInstance's started engine, so the ensemble session does not list them as muted.
const messageAudio=()=>({mode:null,muted:false,lifecycle(action,payload){this.onLifecycle?.(action,payload)},report(kind,details={}){this.onAudioEvent?.({kind,...details,mode:null})}});

export class HeadlessBot {
  constructor({agents,definitionId,key='1',randomKey=key,room='main',transport,audio=null,mixer=null,seed,output='synth',loadOnly=false,mix,identity,performanceGain,settings=null,kits=false,hooks={},renderEnd=null,renderFeel=null,renderExpression=null,reconnect=false}={}){
    definitionId=resolveBotId(definitionId,agents??{});
    const definition=agents?.[definitionId];
    if(!definition)throw new Error(`Unknown Musebot: ${definitionId}`);
    if(!transport)throw new TypeError('HeadlessBot requires a transport');
    this.agents=agents;this.definitionId=definitionId;this.definition=definition;this.key=String(key);this.room=room;
    this.transport=transport;this.audioSource=audio;this.mixer=mixer;this.hooks=hooks||{};
    // A live host's bot comes back as itself when its connection drops (docs/MUSEBOT_PROTOCOL.md, "Members"); a render's
    // in-page transport does not drop.
    this.reconnect=Boolean(reconnect);this.resumeToken=null;this.resumeMs=0;this.resumes=0;
    // BotInstance's ensembleSeed is the prepared session seed, always hashSeed()ed to uint32.
    this.seed=hashSeed(seed??randomSeed());this.output=outputMode(definition,output);this.performing=!loadOnly;this.mix=botMix(mix);
    // Its draws are made under randomKey (a spec's: its key, else its ordinal among the bots of its id), its sound's and
    // its behaviour's, so that other bots joining or leaving the spec move none of them; its key names it to the room.
    this.randomKey=String(randomKey);
    this.trackId=botTrackId(definitionId,this.key);this.soundSeed=botSoundSeed(this.seed,this.randomKey,definitionId);
    this.identity=identity??botInstanceId(definition,this.key);this.performanceGain=performanceGain;
    this.state='created';this.joined=false;this.pending=[];this.timers=new Set;this.motifCapture=new UmpMotifCapture();
    this.audio=null;this.bot=null;this.socket=null;this.lastClock=null;this.incarnation=undefined;this.error=null;this.renderEnd=renderEnd;this.renderFeel=renderFeel;this.renderExpression=renderExpression;
    // What the bot is made with beyond its defaults (a fork's settings: logic-conflicts.js), and what its definition lets
    // a render spec set (spec-settings.js: a singer's lyrics and language).
    this.settings=specSettings(settings,definition);
    // Whether a drum bot's kit is split into a channel per drum for a desk to place and process (audio.js splitKit).
    this.kits=Boolean(kits);
    // As BotInstance: a chord change releases this bot's notes that fall outside the new harmony, if it follows harmony
    // (experiments/note-offs/harmonic-release.js).
    this.harmonicRelease=new HarmonicRelease({follows:capabilitiesOf(definitionId,definition).requires.includes('harmony')});
  }
  send=(address,args=[])=>{
    if(address.startsWith('/agent/memory/')&&address!=='/agent/memory/transfer'&&JSON.stringify(args).length>=6000)return sendMemoryMessage(this.send,address,args);
    if(this.state==='left')return;
    // Its bot asking for a fork of itself (logic-conflicts.js): the host that can add a bot does; one that cannot says so.
    if(address===FORK_ADDRESS){
      if(this.hooks.onAgentFork)Promise.resolve(this.hooks.onAgentFork(args?.[0]??{},this)).catch(error=>this.fail(error));
      else this.hooks.onWarning?.(`${this.definition.name} asked for a fork (${args?.[0]?.conflict}); this host cannot add a bot, so it was not made`,this);
    }
    const message={type:'protocol',address,args};
    // What it says while it is away waits, the latest 256 of it.
    if(this.joined&&this.socket?.readyState===OPEN)this.transmit(message);else{this.pending.push(message);if(this.pending.length>256)this.pending.shift()}
  };
  transmit(message){this.hooks.onMessage?.('out',message,this);this.socket.send(JSON.stringify(message))}
  setup(){return botSetup({definition:this.definition,key:this.key,output:this.output,performing:this.performing,audio:this.audio,mix:this.mix,forkOf:this.settings.forkOf??null})}
  // Same order as BotInstance.start: audio, mixer, configure, bot, bot.start, then join,
  // so retained parameters replayed on join reach a bot that exists.
  async start(){
    if(this.state!=='created')throw new Error(`${this.definition.name} has already started`);
    this.setState('starting');
    try{
      const {definition}=this,audio=typeof this.audioSource==='function'
        ?await this.audioSource({definition,output:this.output,soundSeed:this.soundSeed,trackId:this.trackId,key:this.key,seed:this.seed,performing:this.performing})
        :this.audioSource;
      this.audio=audio||messageAudio();
      // Where a render ends ({bars} | {ticks} | {seconds}), for any bot that plans ahead: a singer's phrase, the form's and
      // the parts' groupings (meterform_clodbot, grouping-choice.js). Every bot is told, whether or not it sounds.
      if(this.renderEnd&&this.audio.renderEnd===undefined)this.audio.renderEnd=this.renderEnd;
      // The ensemble's timing feel (the performance layer: docs/PERFORMANCE_TIMING.md), for the bots that play with it.
      if(this.renderFeel&&this.audio.renderFeel===undefined)this.audio.renderFeel=this.renderFeel;
      // And the rubato report's baseline profiles beside it (transport.expression). A breath is the whole band's: every
      // bot's sound moved together, the performance layer's or not.
      if(this.renderExpression&&this.audio.renderExpression===undefined)this.audio.renderExpression=this.renderExpression;
      if(this.renderExpression?.breath&&typeof this.audio.eventStart==='function')this.breathe(this.audio,this.renderExpression.breath);
      // Time stopped at a held pulse, in every bot's sound as in the clocks (hold-timing.js): a note after its attack
      // after the hold, one held over it held the hold longer, the band silent where it rests.
      installHoldTiming(this.audio);
      // A load-only bot's engine may already be silent; zero is never the level to fade up to.
      this.performanceGain??=audio?.appliedPerformanceGain||audio?.pendingPerformanceGain||4;
      this.attachTelemetry();this.attachMixer();
      await this.audio.configure?.(definition,this.output);
      // A drum bot's kit a channel per drum, before it plays a hit, when a desk is to place and process each drum.
      if(this.kits&&this.audio.declaredRole==='drums')await this.audio.splitKit?.();
      if(!this.performing)this.audio.setPerformanceGain?.(0);
      // inputs: the render's clips that are armed as audio inputs, which a listening bot opens as it would a microphone.
      this.bot=definition.create(this.send,this.audio,{...this.settings,seed:this.seed,randomKey:this.randomKey,...(this.transport?.renderInputs?{inputs:this.transport.renderInputs}:{})});
      // (The identity its own draws are keyed by, beside the instance id the room gives it.)
      if(this.bot&&this.randomKey!==this.key)this.bot.randomIdentity=botInstanceId(definition,this.randomKey);
      this.bot.setIdentity?.(this.identity);
      this.watchDsp();
      await this.bot.start?.();
      await this.bot.loading;
      await this.connect();
      return this;
    }catch(error){
      this.error=error;
      try{this.remove()}catch{/* the start failure is the error worth reporting */}
      throw error;
    }
  }
  connect(resume=null){
    const socket=this.socket=this.transport.connect();
    return new Promise((resolve,reject)=>{
      this.welcomed={resolve,reject};
      socket.addEventListener('open',()=>{try{this.transmit(joinMessage({definition:this.definition,room:this.room,seed:this.seed,setup:{...this.setup(),...(resume?{resume}:{})}}))}catch(error){reject(error)}});
      socket.addEventListener('message',event=>{if(this.socket===socket)this.receive(JSON.parse(event.data))});
      socket.addEventListener('error',()=>reject(new Error('Could not connect to the Musebots ensemble')));
      socket.addEventListener('close',event=>{
        reject(new Error('The ensemble closed before welcoming this bot'));
        if(this.socket!==socket||!this.joined)return;
        // Dropped, not closed by the room on purpose: back as itself if it can be.
        if(this.reconnect&&this.resumeToken&&RECONNECT_CODES.has(event?.code)){this.rejoin();return}
        this.remove(false);
      });
    });
  }
  // Back as itself within the room's time for it (resumeMs), trying again at a doubling interval; past it, once more as
  // a new member; then gone.
  async rejoin(){
    this.joined=false;this.setState('reconnecting');this.hooks.onReconnecting?.(this);
    const until=Date.now()+Math.max(1000,this.resumeMs||10000);let wait=250;
    while(this.state==='reconnecting'){
      const late=Date.now()>until;
      try{await this.connect(late?null:this.resumeToken);return}
      catch{
        if(late||this.state!=='reconnecting'){if(this.state==='reconnecting')this.remove(false);return}
        await new Promise(resolve=>setTimeout(resolve,wait));wait=Math.min(2000,wait*2);
      }
    }
  }
  attachMixer(){if(this.mixer&&this.audio?.spatialGain&&!this.audio.mixerTrack)this.audio.setMixer(this.mixer,this.trackId,this.mix)}
  attachTelemetry(){
    const audio=this.audio,umpListener=audio.onUMP,audioListener=audio.onAudioEvent;
    audio.onUMP=batch=>{
      umpListener?.(batch);
      if(!this.performing||!this.lastClock)return;
      this.motifCapture.add(batch,this.bot?.notes,{meter:this.lastClock.meter});
      // The same batch, kept whole. motifCapture drains at every phrase and caps
      // itself, because a motif is a short quotation; a render's MIDI is the
      // whole performance, so it is collected separately and nothing is dropped.
      this.hooks.onUmp?.(batch,this);
      this.bot?.reportMemoryUse?.(batch,audio.clockTime());
    };
    audio.onLifecycle=(action,payload)=>this.applyLifecycle(action,payload);
    if(this.hooks.onAudioEvent)audio.onAudioEvent=event=>{audioListener?.(event);this.hooks.onAudioEvent(event,this)};
  }
  // Notes are observed where every synth voice leaves the audio layer: the dspNode.
  // Wrapping the node's own schedule/admit changes no engine code and sees UMP
  // replays too; sample and Web Audio voices are not reported here. One node per
  // bot is assumed: a node shared by several hosts would report to all of them.
  watchDsp(){
    // (Watched for the notes log, or for a bot that keeps what actually sounded: Agent.onExecuted.)
    if(!this.hooks.onNote&&typeof this.bot?.onExecuted!=='function')return;
    const node=this.audio?.dspNode;
    if(node&&node!==this.watchedDsp?.node){this.unwatchDsp();this.watchedDsp=this.wrapDsp(node)}
    // A split kit's renderers (audio.js splitKit), whose notes are the bot's as much as its own renderer's are.
    for(const part of this.audio?.kit?.values()??[])if(part.renderer&&!this.watchedKit?.has(part.renderer))
      (this.watchedKit??=new Map()).set(part.renderer,this.wrapDsp(part.renderer));
  }
  wrapDsp(node){
    const originals={};
    for(const method of ['schedule','admit']){
      const original=originals[method]=node[method];
      if(typeof original!=='function')continue;
      // Reported after the call, so an admission the node refuses outright is not logged as a note.
      // A wrapper left under another one after unwatchDsp() stays silent.
      node[method]=(events,...rest)=>{const result=original.call(node,events,...rest);if(this.watchedDsp?.node===node||this.watchedKit?.has(node))this.reportNotes(events);return result};
    }
    return {node,originals,wrappers:{schedule:node.schedule,admit:node.admit}};
  }
  unwatchDsp(){
    const unwrap=watched=>{for(const method of ['schedule','admit'])if(watched.node[method]===watched.wrappers[method]&&typeof watched.originals[method]==='function')watched.node[method]=watched.originals[method]};
    const watched=this.watchedDsp;this.watchedDsp=null;
    if(watched)unwrap(watched);
    const kit=this.watchedKit;this.watchedKit=null;
    for(const entry of kit?.values()??[])unwrap(entry);
  }
  reportNotes(events){
    const context={trackId:this.trackId,definitionId:this.definitionId,key:this.key,tick:this.lastClock?.tick??null,synth:this.audio?.synthesizer};
    // Events with an action are per-note controls and releases (UMP replay, cancelAt), not onsets. A bot that knows where
    // a note's pitch came from (a row position, a motive's derivation: docs/PITCH_LANGUAGES.md) says so, as the note is taken.
    for(const event of events||[])if(!event?.action){
      const note=dspNoteEvent(event,context),language=this.bot?.noteLanguage?.(note);
      this.hooks.onNote?.(language&&typeof language==='object'?{...note,pitchLanguage:language}:note,this);
    }
    // The notes of a motif's occurrences, kept until they begin, and a release before a start cancelling it
    // (shared/execution-watch.js, as the page's card keeps them).
    if(typeof this.bot?.onExecuted==='function')(this.execution??=executionWatch()).see(events,this.bot,context.tick);
  }
  // The notes of occurrences that have begun by now, told to the bot once each (the memorable-motifs report's ticket 5:
  // only what actually sounded is its history). A note the render ends before never begins.
  reportExecuted(){
    if(!this.execution?.size||typeof this.bot?.onExecuted!=='function')return;
    const begun=this.execution.begun(Number(this.audio?.clockTime?.()));
    if(begun.length)this.bot.onExecuted(begun);
  }
  receive(message){
    this.hooks.onMessage?.('in',message,this);
    try{
      if(message.type==='welcome')this.welcome(message);
      if(message.type==='error')this.welcomed?.reject(new Error(message.error||'The ensemble refused this bot'));
      if(message.type==='clock'&&this.joined&&this.bot)this.clock(message);
      if(message.type==='protocol')this.protocol(message);
      // The ensemble refused a message this bot sent as malformed (protocol-schemas.js): the session logs it.
      if(message.type==='protocol_error')this.hooks.onProtocolError?.(message,this);
    }catch(error){
      // A failure while flushing the welcome must not leave start() waiting forever.
      if(message.type==='welcome')this.welcomed?.reject(error);
      this.fail(error);
    }
  }
  welcome(message){
    this.resumeToken=message.resumeToken??null;this.resumeMs=message.resumeMs??0;
    if(message.resumed){this.resumes++;this.hooks.onResumed?.(message,this)}
    this.incarnation=message.instanceIncarnation;this.instanceId=message.instanceId;
    if(this.bot)this.bot.incarnation=this.incarnation;
    this.joined=true;
    this.setState(this.performing?'performing':'loaded');
    for(const pending of this.pending.splice(0))this.transmit(pending);
    this.announceState(this.performing?'performing':'loaded');
    this.publishSetup();
    this.welcomed?.resolve(this);
  }
  // Before the first pulse: whatever this bot has to say about how the piece begins (Agent.onPrepare). Asked of the
  // bots that would be ticked -- a loaded bot that is not performing has no say in the opening -- and a failure here is
  // a bot error like any other, not a reason to abandon the render.
  prepareOpening(clock){
    if(!this.joined||!this.bot||typeof this.bot.onPrepare!=='function')return;
    if(!this.performing&&this.definition.outputModes.length)return;
    try{this.bot.currentClock=clock;this.bot.onPrepare(clock)}catch(error){this.fail(error)}
  }
  // The phrase's breath (performance-timing.js breathSeconds): a sound scheduled `offset` seconds after the pulse the
  // bot is playing moves by the phrase's displacement from the grid where it falls, nothing at a phrase's ends. The
  // clock is not moved: a compensated breath ends each phrase where it would have. The beats are the meter's own.
  breathe(audio,breath){
    const original=audio.eventStart,host=this;
    audio.eventStart=function(offset=0){
      const clock=host.lastClock,at=Number(offset)||0,meter=clock?.meter;
      if(!meter||!(clock.bpm>0))return original.call(this,at);
      const bars=Math.max(1,Number(meter.phraseBars)||bandPhraseBars()),perTick=60/clock.bpm/meter.subdivision;
      const phrasePosition=((((Number(clock.bar)||0)%bars)+bars)%bars*meter.pulsesPerBar+clock.tickInBar+at/perTick)/(bars*meter.pulsesPerBar);
      return original.call(this,at+breathSeconds(breath,{phrasePosition,beatsPerPhrase:bars*meter.numerator,beatSeconds:60/clock.bpm}));
    };
  }
  clock(message){
    if(message.phraseStart)this.flushMotif(message);
    this.lastClock=message;
    this.watchDsp();
    this.audio.beginTick?.(message.tick,message.bpm,message.meter?.subdivision||bandMeter().subdivision,message);
    this.reportExecuted();
    this.mixer?.setTempo?.(message.bpm);
    if(this.performing||!this.definition.outputModes.length)this.bot.onTick?.(message.tick,message);
    else{
      this.bot.observeClock?.(message);
      // Started at this pulse (a start the observed clock brought due): it plays from the pulse it entered on. Given the
      // next pulse first, a line that plans its phrases on downbeats waited a bar, silent, at its entry, and a drummer
      // lost its entrance's downbeat.
      if(this.performing)this.bot.onTick?.(message.tick,message);
    }
  }
  protocol(message){
    const normalized=normalizeProtocolMessage(message);
    // A hold declared ahead reaches the notes that cross it (hold-timing.js).
    this.audio?.hearHold?.(normalized);
    this.bot?.onMessage?.(normalized);
    // Judged when the change sounds: the transport's pulse one lookahead on, as the notes decided with it are (live, the
    // engine's clock is the moment; here a pulse is decided a lookahead before it sounds).
    const release=this.harmonicRelease.observe(normalized,this.audio,this.soundingAt());
    if(release?.released.length)this.hooks.onRelease?.(release,this);
    const request=message.args?.[0];
    if(message.address==='/agent/load'&&this.agents[this.definitionId]?.id==='manage_clodbot'&&this.bot&&request?.target===this.bot.instanceId){
      const requested=this.agents[resolveBotId(request.definitionId,this.agents)];
      if(!requested)throw new Error(`Unknown requested bot: ${request.definitionId}`);
      // Hiring a performer mid-piece is something only a host with a bot
      // catalogue can do; a render's roster is fixed by its spec. Saying so is
      // the point: the manager believes it asked for a performer and will wait
      // for one that cannot arrive, so a silently dropped request reads later
      // as an ensemble that thinned itself for no reason.
      if(!this.hooks.onAgentLoad)this.hooks.onWarning?.(`ManageBOT asked to load "${request.definitionId}"; `
        +'this renderer cannot add a performer that is not in the spec, so the request was not honoured',this);
      Promise.resolve(this.hooks.onAgentLoad?.({...request,loadOnly:request.loadOnly!==false,output:outputMode(requested)},this)).catch(error=>this.fail(error));
    }
    if(message.address==='/system/instance'||message.address==='/system/announce')this.announceState(this.performing?'performing':'loaded');
  }
  // When what is decided now sounds, in the audio's seconds (TimelineClock): the transport's pulse, a lookahead on.
  soundingAt(){
    const transport=this.transport,seconds=transport?.musicSeconds;
    return Number.isFinite(seconds)?seconds+(transport.outputDelaySeconds??transport.lookahead??0):undefined;
  }
  flushMotif(clock){
    if(!this.bot?.publishMotif||this.definitionId==='memory')return;
    const captured=this.motifCapture.flush(this.lastClock||clock);
    if(!captured)return;
    if(captured.truncated){this.hooks.onWarning?.('Motif capture capacity reached; incomplete capture was not stored.',this);return}
    this.bot.publishMotif(captured.events,capturedMotifOptions(captured,clock,this.definition));
  }
  announceState(state){
    if(this.joined)this.send('/broadcast/agentState',[agentState({definition:this.definition,bot:this.bot,incarnation:this.incarnation,state,output:this.output})]);
  }
  publishSetup(){if(this.joined&&this.socket?.readyState===OPEN)this.transmit({type:'ensemble_bot',bot:this.setup()})}
  fadeSeconds(payload={}){return lifecycleFadeSeconds(payload,this.lastClock)}
  applyLifecycle(action,payload={}){
    if(action==='invited')return this.setState('invited');
    // Protocol lifecycles fade by fadeBars only, as BotInstance does; a payload fadeSeconds is not honoured.
    if(action==='start')return this.startPerformance({fadeSeconds:this.fadeSeconds(payload)});
    // BotInstance defers both with setTimeout even for a zero fade; a lifecycle
    // arriving inside a clock pulse must not tear the bot down mid-tick.
    if(action==='stop')return this.fade('stop',{fadeSeconds:this.fadeSeconds(payload)},true);
    // A COORDINATOR's leave parks the bot; only the bot's own leave (the spec's, or the end of the render) removes it.
    //
    // Live, a manager dismisses a performer and the host hires a fresh one from its catalogue when the ensemble should
    // grow again. A render has no catalogue -- its roster is its spec -- so a dismissal that destroyed the bot was a
    // one-way door: mh_ManageBOT under a form plan cut twelve performers to the arc's opening three and could never
    // climb to the six and eight the arc asks for next, because everyone it might have brought in no longer existed.
    // The pool a render can hire from IS its roster. So a dismissed performer goes back to it, loaded and silent,
    // which is exactly the state the manager's own entrance logic looks for, and nothing about the manager changes.
    if(action==='leave')return this.fade(payload?.coordinator?'park':'leave',{fadeSeconds:this.fadeSeconds(payload)},true);
  }
  startPerformance({fadeSeconds,fadeBars}={}){
    if(this.performing||this.state==='left')return;
    this.attachMixer();
    this.performing=true;
    this.setState('performing');
    this.audio?.setPerformanceGain?.(this.performanceGain,fadeSeconds??this.fadeSeconds({fadeBars}));
    this.announceState('performing');
    this.publishSetup();
  }
  stop(options={}){return this.fade('stop',options)}
  leave(options={}){return this.fade('leave',options)}
  fade(action,{fadeSeconds,fadeBars}={},deferred=false){
    if(this.state==='left')return Promise.resolve();
    const seconds=Math.max(0,Number(fadeSeconds??this.fadeSeconds({fadeBars}))||0),
      done=action==='stop'?()=>this.stopped():action==='park'?()=>this.parked():()=>this.remove();
    if(action==='stop'||action==='park')this.audio?.setPerformanceGain?.(0,seconds);
    if(!deferred&&seconds===0){done();return Promise.resolve()}
    return new Promise(resolve=>this.after(seconds,done,resolve));
  }
  // settle runs when the timer fires or when remove() cancels it, so no fade promise is left pending.
  // The timer is registered before at() in case a transport fires a due callback synchronously.
  after(seconds,callback,settle){
    const timer={cancel:null,settle};
    this.timers.add(timer);
    timer.cancel=this.transport.at(this.transport.now()+seconds,()=>{
      if(!this.timers.delete(timer))return;
      try{callback()}catch(error){this.fail(error)}finally{settle?.()}
    });
    return()=>{if(this.timers.delete(timer)){timer.cancel?.();settle?.()}};
  }
  stopped(){
    if(this.state==='left')return;
    this.performing=false;
    this.setState('stopped');
    this.announceState('stopped');
    this.publishSetup();
  }
  // Back in the pool: silent, still joined, its bot and audio intact, and announced as "loaded" so a coordinator's
  // entrance logic can invite and start it again. startPerformance() resumes from here as it does from "stopped".
  parked(){
    if(this.state==='left')return;
    this.performing=false;
    this.setState('loaded');
    this.announceState('loaded');
    this.publishSetup();
  }
  // The leaving agentState is delivered synchronously to every bot, this one included, so a
  // handler that throws must not abandon the teardown: every step runs, then the first error is rethrown.
  remove(closeSocket=true){
    if(this.state==='left'||this.state==='leaving')return;
    const timers=[...this.timers];this.timers.clear();
    for(const timer of timers){timer.cancel?.();timer.settle?.()}
    this.unwatchDsp();
    let failure=null;
    const attempt=action=>{try{action()}catch(error){failure??=error}};
    attempt(()=>this.announceState('leaving'));
    this.setState('leaving');
    this.joined=false;
    const bot=this.bot,audio=this.audio,socket=this.socket;
    this.bot=null;this.socket=null;
    attempt(()=>bot?.stop?.());
    attempt(()=>{audio?.panicMidi?.();audio?.releaseMidiRoute?.();audio?.dispose?.()});
    if(closeSocket&&socket?.readyState<CLOSING)attempt(()=>socket.close());
    this.setState('left');
    if(failure)throw failure;
  }
  setState(state){this.state=state;this.hooks.onLifecycle?.(state,this)}
  // Without an onError hook a bot failure propagates, which stops a render loudly.
  fail(error){
    this.error=error;
    if(!this.hooks.onError)throw error;
    this.hooks.onError(error,this);
  }
}
