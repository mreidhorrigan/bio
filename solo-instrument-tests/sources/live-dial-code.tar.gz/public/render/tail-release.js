// A tail still ringing where a render must stop is released, never cut (the extreme-aesthetics report's §6.6 and §6.7,
// E33). The music ends at its length (musicalEnd). Its tail follows, outside that length, ringing until it falls under
// the meter's floor, and at most max(tailSeconds, maxTailSeconds): the hard end (hardOutputEnd). A sound still decaying
// there does not extend the piece, and stopping it mid-waveform is a discontinuity, not an artistic cut. So when the mix
// still rings as the last stretch begins, every track fades over it together (tailReleaseStart to the hard end: the
// last `seconds`, or the whole tail where it is shorter, never the music itself), and the stems still sum to the mix. A release that is not needed is not applied; and one applied is said in the manifest.

// ---- Choices ---------------------------------------------------------------------------------------------------------
export const TAIL_RELEASE=Object.freeze({
  // How long the release lasts (ours: about a hand damping a cymbal, or a room's last second heard fading).
  seconds:1,
  // What the manifest says of the tail.
  policy:'the tail follows the music, outside its length: it rings until it falls under the meter\'s floor, at most max(tailSeconds, maxTailSeconds), and a tail still ringing at that hard end is released over its last second',
});

// The gain at frame `frame` of a release from `start` to `end`: 1 before it, a raised cosine down to 0 across it (no
// corner at either end), 0 after it.
export function releaseGain(frame,{start,end}){
  if(frame<start)return 1;
  if(frame>=end)return 0;
  return .5*(1+Math.cos(Math.PI*(frame-start)/(end-start)));
}

// `write(id, channels)` wrapped so each track's frames in a release are faded as they are written. Each track's frames
// are counted as they pass, so the release lands on the same frames of every track. Frames before it pass untouched
// (the arrays themselves: nothing is copied). writer.release(startFrame, endFrame) sets it before its frames are
// written; writer.released() says what was set (null: none).
export function releasingWriter(write){
  const written=new Map();let release=null;
  const writer=(id,channels)=>{
    const from=written.get(id)??0,count=channels[0]?.length??0;
    written.set(id,from+count);
    if(!release||from+count<=release.start)return write(id,channels);
    return write(id,channels.map(channel=>{
      const out=new Float32Array(count);
      for(let i=0;i<count;i++)out[i]=channel[i]*releaseGain(from+i,release);
      return out;
    }));
  };
  writer.release=(start,end)=>{
    if(!(Number.isInteger(start)&&Number.isInteger(end)&&end>start))throw new RangeError('a release from a frame to a later one');
    release=Object.freeze({start,end});
  };
  writer.released=()=>release;
  return writer;
}

// The render's ending, as the manifest says it, in the files' seconds (what is heard): where the music ends, where a
// release began (null: none was needed), where the output stops, and the policy. `musicSeconds` is the music's end on
// its own clock, `renderSeconds` the render's (the lookahead after it), `trimmed` whether the files leave out the
// preroll (the lookahead) at their start.
export function renderEnding({musicSeconds,renderSeconds,lookahead,trimmed,release,sampleRate}){
  const file=seconds=>Math.round((seconds-(trimmed?lookahead:0))*1e6)/1e6;
  return Object.freeze({basis:'file seconds',musicalEnd:file(musicSeconds+lookahead),tailReleaseStart:release?file(release.start/sampleRate):null,
    hardOutputEnd:file(renderSeconds),released:Boolean(release),tailInLength:false,policy:TAIL_RELEASE.policy});
}
