import {createRandomStream} from '../random-source.js';

const ACTIVE=Symbol.for('musebots.render.virtualTime');

// Salted so a render seeded like the global random source does not reuse its sequence for ids.
const seededUUID=seed=>{
  const stream=createRandomStream(`${seed}:uuid`);
  return()=>{
    const bytes=Array.from({length:16},()=>Math.floor(stream.next()*256));bytes[6]=bytes[6]&15|64;bytes[8]=bytes[8]&63|128;
    const hex=bytes.map(byte=>byte.toString(16).padStart(2,'0')).join('');
    return`${hex.slice(0,8)}-${hex.slice(8,12)}-${hex.slice(12,16)}-${hex.slice(16,20)}-${hex.slice(20)}`;
  };
};

// Dates it creates are real Dates (shared prototype, instanceof holds); only `constructor===Date` checks can tell.
function virtualDateConstructor(NativeDate,now){
  function VirtualDate(...args){return new.target?Reflect.construct(NativeDate,args.length?args:[now()],new.target):new NativeDate(now()).toString()}
  for(const [key,value] of [['prototype',NativeDate.prototype],['name','Date'],['length',NativeDate.length],['now',now],['parse',NativeDate.parse],['UTC',NativeDate.UTC]])
    Object.defineProperty(VirtualDate,key,{value,writable:!['prototype','name','length'].includes(key),configurable:key!=='prototype'});
  return VirtualDate;
}

// Date.now() = epochMs + render seconds and performance.now() = render seconds, read live from getRenderSeconds().
// Date.now() is rounded to whole milliseconds as it is live: session start times and ensemble links require integers.
// uuid:'seeded' makes crypto.randomUUID() a seeded v4 stream. date:'virtual' also swaps globalThis.Date so an
// argless new Date() follows render time; it is opt-in because it replaces a global constructor.
// One installation at a time: a nested install throws, since interleaved renders cannot share one clock.
// restore() puts back the exact original property descriptors and is safe to call twice; a patch that fails
// part way is rolled back before the error is rethrown.
export function installVirtualTime({epochMs=Date.UTC(2026,0,1),getRenderSeconds,uuid='native',date='native',seed=0}={}){
  if(typeof getRenderSeconds!=='function')throw new TypeError('installVirtualTime() needs getRenderSeconds()');
  if(!Number.isFinite(epochMs))throw new TypeError('installVirtualTime() needs a finite epochMs');
  if(!['native','seeded'].includes(uuid))throw new TypeError(`uuid must be 'native' or 'seeded', not ${uuid}`);
  if(!['native','virtual'].includes(date))throw new TypeError(`date must be 'native' or 'virtual', not ${date}`);
  if(uuid==='seeded'&&!globalThis.crypto)throw new Error('Seeded UUIDs need globalThis.crypto');
  if(globalThis[ACTIVE])throw new Error('Virtual time is already installed; restore it before installing again');
  const NativeDate=globalThis.Date,patches=[],now=()=>Math.round(epochMs+getRenderSeconds()*1000);
  const patch=(target,key,value)=>{const descriptor=Object.getOwnPropertyDescriptor(target,key);Object.defineProperty(target,key,{value,writable:true,configurable:true,enumerable:descriptor?.enumerable??false});patches.push([target,key,descriptor])};
  let restored=false;
  const restore=()=>{
    if(restored)return;restored=true;
    for(const [target,key,descriptor] of patches.reverse())if(descriptor)Object.defineProperty(target,key,descriptor);else delete target[key];
  };
  try{
    patch(globalThis,ACTIVE,true);
    patch(NativeDate,'now',now);
    if(globalThis.performance)patch(globalThis.performance,'now',()=>getRenderSeconds()*1000);
    if(uuid==='seeded')patch(globalThis.crypto,'randomUUID',seededUUID(seed));
    if(date==='virtual')patch(globalThis,'Date',virtualDateConstructor(NativeDate,now));
  }catch(error){restore();throw error}
  return restore;
}
