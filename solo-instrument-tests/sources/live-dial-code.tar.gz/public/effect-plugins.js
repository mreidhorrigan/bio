import {loadWamPlugin,wamParameterValues,wamTrimDb} from './synths/wam.js';
export const EFFECT_PLUGINS=[
  {id:'faust-ping-pong',name:'Faust ping-pong delay · WASM',url:'vendor/wam/faustPingPongDelayDefaultUI/index.js'},
  // A phaser, which is a cascade of allpass filters and so is not the modulated delay the
  // mixer's chorus is: the notches move but nothing is delayed, and they do not sound alike.
  {id:'stone-phaser',name:'Stone phaser (stereo) · WASM',url:'vendor/wam/StonePhaserStereo/index.js'},
];
export async function createEffectPlugin(context,options){
  // A VST3 effect, by its path: on the desktop, through the VST3 bridge (synths/vst3-bridge-effect.js).
  if(typeof options?.path==='string')return (await import('./synths/vst3-bridge-effect.js')).createVst3BridgeEffect(context,options);
  const plugin=await loadWamPlugin(context,options),node=plugin.audioNode;
  if(plugin.descriptor?.isInstrument===true){node.destroy();throw new Error('Choose an effect plugin for the shared effects bus')}
  // The return plays through the plugin's measured trim (data/wam-levels.js), or the one asked for.
  const trim=context.createGain();trim.gain.value=10**(wamTrimDb(plugin,options?.trimDb)/20);node.connect(trim);
  return {input:node,connect:destination=>trim.connect(destination),disconnect(){node.disconnect();trim.disconnect();node.destroy()},
    name:plugin.descriptor.name,parameterInfo:()=>node.getParameterInfo(),parameterValues:()=>wamParameterValues(node),getState:()=>node.getState(),setState:value=>node.setState(value),
    setParameters(values,atSeconds=context.currentTime){
      if(atSeconds<=context.currentTime)return node.setParameterValues(Object.fromEntries(Object.entries(values).map(([id,value])=>[id,{id,value,normalized:false}])));
      node.scheduleEvents(...Object.entries(values).map(([id,value])=>({type:'wam-automation',time:atSeconds,data:{id,value,normalized:false}})));
    },
  };
}
