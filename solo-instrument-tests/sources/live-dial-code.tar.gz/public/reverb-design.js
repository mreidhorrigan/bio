// Reverberation as rooms and devices have it, for the mixer's convolvers.
//
// The mixer had one reverb: seeded noise under a cubic fade, behind a lowpass. It is a pleasant
// wash and nothing else -- it has no early reflections, no pre-delay, and every frequency decays
// at the same rate, so a hall, a plate and a small room are the same sound at different lengths.
// A convolver will play any impulse it is given, so the difference between them is here: each
// type is an impulse built from the measured character of the space or device it names.
//
//   early reflections   discrete arrivals after a pre-delay, thinning to the tail
//   the late field      noise in bands, each decaying at its own rate: the bass ratio and the
//                       treble ratio are how much longer the lows ring, and how much sooner the
//                       highs die, than the middle; above them a room's air takes the top octaves
//                       sooner still, as it does in a real hall
//   the onset           how quickly the field becomes dense
//
// The numbers are measurements unless marked; research/expression-and-mixing-references.md
// gives each source. Deterministic: the same seed and settings give the same impulse, sample for
// sample, so a render repeats. The convolver normalises every impulse's power, so changing type
// changes character, not level.
import {createRandomStream} from './random-source.js';

export const REVERB_TYPES = Object.freeze(['legacy', 'booth', 'ambience', 'room', 'chamber', 'hall',
  'plate', 'cathedral', 'spring', 'gated']);

// seconds       mid-frequency reverberation time (T60)
// predelayMs    to the first arrival: the initial time delay gap
// bassRatio     low-frequency T60 over mid; trebleRatio: high over mid
// early         {count, windowMs, ratio}: how many discrete reflections, over how long, and their
//               energy against the first 80 ms of the tail
// buildMs       how long the late field takes to become dense
// topRatio      a device's (a plate's, a spring's) T60 above 5.7 kHz over mid. Rooms have no such
//               number: their air sets it (airAbsorption below)
export const REVERB_DESIGNS = Object.freeze({
  // A vocal booth: 0.08-0.11 s, the first reflection at 3-5 ms (Noxon 1987; practitioner).
  booth: Object.freeze({seconds: 0.1, predelayMs: 4, bassRatio: 1, trebleRatio: 0.8,
    early: {count: 6, windowMs: 12, ratio: 3}, buildMs: 1}),
  // A living room: 0.3-0.6 s (Hoshi et al. 2021, a review of measured rooms).
  ambience: Object.freeze({seconds: 0.4, predelayMs: 3, bassRatio: 1.2, trebleRatio: 0.8,
    early: {count: 16, windowMs: 30, ratio: 2}, buildMs: 4}),
  // A studio room: "dead" pop studios 0.35-0.9 s, music studios 0.9-1.4 s (BBC, Burd, Gilford &
  // Spring 1966), flat by design.
  room: Object.freeze({seconds: 0.7, predelayMs: 6, bassRatio: 1, trebleRatio: 0.9,
    early: {count: 18, windowMs: 45, ratio: 1.2}, buildMs: 8}),
  // A chamber-music hall: 1.5 +- 0.3 s, pre-delay 9-19 ms, bass ratio 1.1 +- 0.1 (Hidaka &
  // Nishihara 2004, via Buen; Kanev et al. 2016). Treble ratio not found; ours.
  chamber: Object.freeze({seconds: 1.5, predelayMs: 14, bassRatio: 1.1, trebleRatio: 0.85,
    early: {count: 22, windowMs: 70, ratio: 0.8}, buildMs: 18}),
  // A symphony hall, occupied: 1.8-2.2 s, Beranek's 85-hall mean 1.85 s (Barron 2005); pre-delay
  // at most 20 ms for intimacy, under 25 ms in the best halls (Hyde 2019); treble ratio 0.77-0.95
  // measured (Bradley 1991); bass ratio 1.1-1.25 as a design target (secondary sources only).
  hall: Object.freeze({seconds: 1.95, predelayMs: 20, bassRatio: 1.15, trebleRatio: 0.85,
    early: {count: 26, windowMs: 90, ratio: 0.6}, buildMs: 28}),
  // The EMT 140 plate: 1-5 s at 500 Hz, flat to about 3 kHz at short settings and about 0.6 of it
  // by 10 kHz; the lows ring longer at long settings; no discrete early reflections, the highs
  // arriving a millisecond or two before the lows; a return that peaks near 300 Hz and is about
  // 10 dB down at 50 Hz and at 4 kHz (BBC Technical Instruction S.9, c. 1959).
  plate: Object.freeze({seconds: 2, predelayMs: 0, bassRatio: 1.3, trebleRatio: 0.9, topRatio: 0.6,
    early: null, buildMs: 2, dispersionMs: 14, returnBand: [110, 4500]}),
  // A cathedral: 4.3-9.0 s, treble ratio 0.52-0.63 (Giron et al. 2020); bass ratio about 1-1.3.
  cathedral: Object.freeze({seconds: 6, predelayMs: 35, bassRatio: 1.15, trebleRatio: 0.55,
    early: {count: 30, windowMs: 140, ratio: 0.35}, buildMs: 60}),
  // A spring tank: 1.2-4.0 s by tank code; one measured spring's echo period 55.6 ms, losing
  // about 5.4 dB an echo (a short tank, near 0.6 s), dispersive below about 4.2 kHz, useful
  // between 200 Hz and 6 kHz (Gamper, Parker & Valimaki 2011); two or three springs of different
  // periods in parallel. Here each echo loses what the tank's T60 implies (1.5 dB at 2.2 s).
  spring: Object.freeze({seconds: 2.2, predelayMs: 0, bassRatio: 1, trebleRatio: 0.7, topRatio: 0.5,
    early: null, buildMs: 1, periodsMs: [43, 55.6, 67], chirpHz: [4200, 200], echoRatio: 3,
    returnBand: [200, 6000]}),
  // The 1980s gated drum room: a dense, compressed room cut by a gate. No hold or release time is
  // sourced anywhere (the gap is recorded in the references); ours: an eighth note at the tempo
  // when one is given, 250 ms otherwise, and a 60 ms close.
  gated: Object.freeze({seconds: 1.2, predelayMs: 4, bassRatio: 1, trebleRatio: 0.9,
    early: {count: 20, windowMs: 30, ratio: 1}, buildMs: 3, holdMs: 250, releaseMs: 60}),
});

const clamp = (value, low, high) => Math.max(low, Math.min(high, value));
const T60 = 6.907755;

// Sound's absorption by air, in dB per metre: ISO 9613-1, the model of Bass, Sutherland,
// Zuckerwar, Blackstock & Hester (1995). Oxygen and nitrogen relax, each with its own frequency,
// set by the humidity; above a few kHz this, not the walls, decides how long a large hall rings.
export function airAbsorption(hz, {celsius = 20, humidity = 50, kilopascals = 101.325} = {}) {
  const T = celsius + 273.15, T0 = 293.15, pressure = kilopascals / 101.325;
  const saturation = 10 ** (-6.8346 * (273.16 / T) ** 1.261 + 4.6151);
  const h = humidity * saturation / pressure;
  const oxygen = pressure * (24 + 4.04e4 * h * (0.02 + h) / (0.391 + h));
  const nitrogen = pressure * (T / T0) ** -0.5 * (9 + 280 * h * Math.exp(-4.170 * ((T / T0) ** (-1 / 3) - 1)));
  const f2 = hz * hz;
  return 8.686 * f2 * (1.84e-11 / pressure * (T / T0) ** 0.5 + (T / T0) ** -2.5
    * (0.01275 * Math.exp(-2239.1 / T) / (oxygen + f2 / oxygen) + 0.1068 * Math.exp(-3352 / T) / (nitrogen + f2 / nitrogen)));
}
// The seconds air alone would take to absorb 60 dB at this frequency, sound travelling 343 m/s.
const airSeconds = hz => 60 / (airAbsorption(hz) * 343.2);

// The design's T60 at any frequency: a curve through the octave bands the ratios are defined on
// (the bass ratio compares 125 and 250 Hz with 500 Hz and 1 kHz, the treble ratio 2 and 4 kHz
// with the same: Beranek), straight in log frequency between them. A room's surfaces and its air
// act together (1/T adds), so air takes the octaves above 4 kHz sooner still; a device has no
// air, and its topRatio says where its highs end up by 10 kHz.
//
// The ratios are what an octave-band measurement of a room reads, and an octave band of a sloping
// curve reads long: its slowest frequencies are what is left late in the decay. So the curve's
// plateaus are solved until a measurement of the curve itself (measuredBand) reads the settings.
export function decaySeconds(type, settings) {
  const design = REVERB_DESIGNS[type] || REVERB_DESIGNS.hall, s = settings;
  const through = points => hz => {
    const octave = Math.log2(Math.max(1, hz));
    if (octave <= points[0][0]) return points[0][1];
    for (let index = 1; index < points.length; index++) {
      const [x1, y1] = points[index], [x0, y0] = points[index - 1];
      if (octave <= x1) return y0 + (y1 - y0) * (octave - x0) / (x1 - x0);
    }
    return points.at(-1)[1];
  };
  const at = (hz, ratio) => [Math.log2(hz), ratio * s.seconds];
  // Air's share is what it absorbs beyond its share at 1 kHz, which the mid T60 already holds.
  const air = hz => Math.max(0, 1 / airSeconds(hz) - 1 / airSeconds(1000));
  const shape = design.topRatio !== undefined
    ? (low, mid, treble) => through([at(250, low), at(500, mid), at(1000, mid), at(2000, treble), at(4000, treble),
      at(10000, design.topRatio * mid)])
    : (low, mid, treble) => {
      const surfaces = through([at(250, low), at(500, mid), at(1000, mid), at(2000, treble)]);
      return hz => 1 / (1 / surfaces(hz) + air(hz));
    };
  let low = s.bassRatio, mid = 1, treble = s.trebleRatio;
  for (let round = 0; round < 8; round++) {
    const curve = shape(low, mid, treble), band = centre => measuredBand(curve, centre);
    const middle = (band(500) + band(1000)) / 2;
    mid *= s.seconds / middle;
    low *= s.bassRatio / ((band(125) + band(250)) / 2 / middle);
    // A room's air can make a bright treble unreachable; its surfaces then reflect everything.
    treble = Math.min(1000, treble * s.trebleRatio / ((band(2000) + band(4000)) / 2 / middle));
  }
  return shape(low, mid, treble);
}

// What an octave-band measurement of a T60 curve reads (ISO 3382-1's T30, from the -5 and -35 dB
// points). The band's noise is the sum of its frequencies' decays, so its Schroeder integral has
// a closed form: the sum of each frequency's energy times its T60 times its own decay.
export function measuredBand(curve, centre) {
  const parts = Array.from({length: 24}, (_, index) => {
    const low = centre / Math.SQRT2 * 2 ** (index / 24), high = centre / Math.SQRT2 * 2 ** ((index + 1) / 24);
    return [high - low, Math.max(0.005, curve(Math.sqrt(low * high)))];
  });
  const schroeder = t => parts.reduce((sum, [width, seconds]) => sum + width * seconds * Math.exp(-2 * T60 * t / seconds), 0);
  const total = schroeder(0), when = db => {
    const wanted = total * 10 ** (db / 10);
    let early = 0, late = 60;
    for (let step = 0; step < 48; step++) {const t = (early + late) / 2; if (schroeder(t) > wanted) early = t; else late = t}
    return (early + late) / 2;
  };
  return 2 * (when(-35) - when(-5));
}

// An in-place radix-2 inverse FFT, unscaled (the transform render/node/graph.mjs uses).
const transforms = new Map();
function inverseFFT(re, im) {
  const n = re.length;
  let table = transforms.get(n);
  if (!table) {
    const bits = Math.log2(n), reverse = new Uint32Array(n), cos = new Float64Array(n / 2), sin = new Float64Array(n / 2);
    for (let i = 1; i < n; i++) reverse[i] = (reverse[i >> 1] >> 1) | ((i & 1) << (bits - 1));
    for (let i = 0; i < n / 2; i++) {cos[i] = Math.cos(2 * Math.PI * i / n); sin[i] = Math.sin(2 * Math.PI * i / n)}
    transforms.set(n, table = {reverse, cos, sin});
  }
  const {reverse, cos, sin} = table;
  for (let i = 0; i < n; i++) {
    const j = reverse[i];
    if (j > i) {let x = re[i]; re[i] = re[j]; re[j] = x; x = im[i]; im[i] = im[j]; im[j] = x}
  }
  for (let size = 2; size <= n; size <<= 1) {
    const half = size >> 1, step = n / size;
    for (let start = 0; start < n; start += size) for (let k = 0, t = 0; k < half; k++, t += step) {
      const a = start + k, b = a + half, c = cos[t], s = sin[t], xr = re[b] * c - im[b] * s, xi = re[b] * s + im[b] * c;
      re[b] = re[a] - xr; im[b] = im[a] - xi; re[a] += xr; im[a] += xi;
    }
  }
}

// ---- the late field --------------------------------------------------------------------------
// Noise in which every frequency decays at its own rate, as in a real room, where T60 is a smooth
// curve and not a few bands' staircase (a staircase's long band rings on into its neighbour: a
// cathedral's treble ratio of 0.55 measured 0.7). Made a frame at a time: each frame's spectrum
// is random, its magnitude how much faster or slower than the middle each frequency has decayed
// by then, and the frames overlap-add at half a frame under sqrt-Hann windows, whose squares sum
// to one, so the noise's power stays steady. The middle's own decay is applied sample by sample
// afterwards, so even a booth's steep envelope is exact; the frames carry only differences,
// which change slowly. One complex transform gives both channels: the real and imaginary parts
// of a random spectrum with a symmetric magnitude are independent noises with that spectrum.
function lateField(type, s, design, sampleRate, length, seed, curve) {
  const N = 2048, hop = N / 2, random = createRandomStream(`${seed}:reverb:${type}:${s.seconds}:field`);
  const perHop = new Float64Array(N / 2), amplitude = new Float64Array(N / 2).fill(1);
  for (let bin = 1; bin < N / 2; bin++) {
    const seconds = Math.max(0.01, curve(bin * sampleRate / N));
    perHop[bin] = Math.exp(-T60 * hop / sampleRate * (1 / seconds - 1 / s.seconds));
  }
  const window = Float64Array.from({length: N}, (_, i) => Math.sin(Math.PI * i / N) / Math.sqrt(N));
  const left = new Float32Array(length), right = new Float32Array(length), re = new Float64Array(N), im = new Float64Array(N);
  // Frame k is centred on sample k * hop; the first starts half a frame early so the start is full.
  for (let frame = 0; (frame - 1) * hop < length; frame++) {
    re.fill(0); im.fill(0);
    for (let bin = 1; bin < N / 2; bin++) {
      const a = amplitude[bin];
      re[bin] = a * (random.next() * 2 - 1); im[bin] = a * (random.next() * 2 - 1);
      re[N - bin] = a * (random.next() * 2 - 1); im[N - bin] = a * (random.next() * 2 - 1);
      amplitude[bin] = a * perHop[bin];
    }
    inverseFFT(re, im);
    const start = (frame - 1) * hop;
    for (let i = Math.max(0, -start); i < N && start + i < length; i++) {
      left[start + i] += re[i] * window[i]; right[start + i] += im[i] * window[i];
    }
  }
  // The middle's decay, and the onset: how quickly the field becomes dense. A plate's lows arrive
  // after its highs, so below 354 Hz its field builds more slowly.
  const decay = Math.exp(-T60 / (s.seconds * sampleRate)), build = Math.max(1, design.buildMs / 1000 * sampleRate),
    lowBuild = Math.max(build, (design.dispersionMs || 0) / 1000 * sampleRate);
  for (let i = 0, envelope = 1; i < length; i++, envelope *= decay) {left[i] *= envelope; right[i] *= envelope}
  for (const data of [left, right]) {
    const span = Math.min(length, Math.ceil(12 * lowBuild) + 256), low = Float64Array.from(data.subarray(0, span));
    if (lowBuild > build) butterworth(low, 'lowpass', 250 * Math.SQRT2, sampleRate);
    for (let i = 0; i < span; i++) {
      const rise = 1 - Math.exp(-i / build), lowRise = 1 - Math.exp(-i / lowBuild);
      data[i] = data[i] * rise + (lowBuild > build ? low[i] * (lowRise - rise) : 0);
    }
  }
  return [left, right];
}

// The impulse the mixer always had, kept as type 0 so an ensemble link or a render that names no
// type sounds exactly as it did.
export function legacyImpulse(context, seed, seconds) {
  const frames = Math.ceil(context.sampleRate * seconds), buffer = context.createBuffer(2, frames, context.sampleRate),
    random = createRandomStream(`${seed}:reverb:${seconds}`);
  for (let channel = 0; channel < 2; channel++) {
    const data = buffer.getChannelData(channel); let filtered = 0;
    for (let i = 0; i < frames; i++) {filtered = filtered * 0.35 + (random.next() * 2 - 1) * 0.65; data[i] = filtered * (1 - i / frames) ** 3}
  }
  return buffer;
}

// What a design becomes with the caller's settings: -1 or undefined means "the type's own".
export function reverbSettings(type, {seconds, predelayMs, bassRatio, trebleRatio, bpm} = {}) {
  const design = REVERB_DESIGNS[type] || REVERB_DESIGNS.hall, own = (value, fallback) =>
    value === undefined || value === null || !Number.isFinite(Number(value)) || Number(value) < 0 ? fallback : Number(value);
  const hold = design.holdMs !== undefined
    ? (Number(bpm) > 0 ? clamp(60000 / Number(bpm) / 2, 60, 600) : design.holdMs) : undefined;
  return {type, seconds: clamp(own(seconds, design.seconds), 0.05, 12),
    predelayMs: clamp(own(predelayMs, design.predelayMs), 0, 150),
    bassRatio: clamp(own(bassRatio, design.bassRatio), 0.5, 2.5),
    trebleRatio: clamp(own(trebleRatio, design.trebleRatio), 0.3, 1.2),
    ...(hold !== undefined ? {holdMs: hold, releaseMs: design.releaseMs} : {})};
}

// A fourth-order Butterworth low- or highpass, in place: two biquad sections from the RBJ
// cookbook, their Qs the fourth-order Butterworth pair, in transposed direct form II.
function butterworth(data, kind, hz, sampleRate) {
  for (const q of [0.5411961, 1.3065630]) {
    const w = 2 * Math.PI * hz / sampleRate, cos = Math.cos(w), alpha = Math.sin(w) / (2 * q), a0 = 1 + alpha;
    const b0 = (kind === 'lowpass' ? (1 - cos) / 2 : (1 + cos) / 2) / a0, b1 = (kind === 'lowpass' ? 2 : -2) * b0,
      a1 = -2 * cos / a0, a2 = (1 - alpha) / a0;
    let z1 = 0, z2 = 0;
    for (let i = 0; i < data.length; i++) {
      const x = data[i], y = b0 * x + z1;
      z1 = b1 * x - a1 * y + z2; z2 = b0 * x - a2 * y; data[i] = y;
    }
  }
}

/**
 * An impulse response for a ConvolverNode.
 *
 * @param context  anything with createBuffer and sampleRate (an AudioContext, an offline one)
 * @param type     a REVERB_TYPES name
 * @param options  seconds, predelayMs, bassRatio, trebleRatio (each -1 or absent for the type's
 *                 own), seed, bpm (a gated room's hold follows it)
 */
export function designImpulse(context, type = 'hall', {seed = 1, ...options} = {}) {
  if (type === 'legacy' || !REVERB_DESIGNS[type]) return legacyImpulse(context, seed, options.seconds ?? 2.4);
  const design = REVERB_DESIGNS[type], s = reverbSettings(type, options), sr = context.sampleRate;
  const pre = Math.round(s.predelayMs / 1000 * sr);
  const longest = s.seconds * Math.max(1, s.bassRatio);
  const tailSeconds = type === 'gated' ? (s.holdMs + s.releaseMs * 3) / 1000 + 0.02 : Math.min(14, longest * 1.05);
  const frames = pre + Math.max(64, Math.ceil(tailSeconds * sr));
  const buffer = context.createBuffer(2, frames, sr);
  const one = hz => 1 - Math.exp(-2 * Math.PI * hz / sr);
  const mul = seconds => Math.exp(-T60 / (Math.max(0.01, seconds) * sr));
  const curve = decaySeconds(type, s), field = lateField(type, s, design, sr, frames - pre, seed, curve);
  for (let channel = 0; channel < 2; channel++) {
    const random = createRandomStream(`${seed}:reverb:${type}:${s.seconds}:${channel}`),
      data = buffer.getChannelData(channel);
    data.set(field[channel], pre);
    // ---- a gated room: held, lifting slightly as a compressed room does, then cut ------------
    if (type === 'gated') {
      const hold = Math.round(s.holdMs / 1000 * sr), close = mul(s.releaseMs / 1000);
      let gate = 1;
      for (let i = 0; i + pre < frames; i++) {
        if (i < hold) data[pre + i] *= 1 + 0.25 * i / hold;
        else {gate *= close; data[pre + i] *= 1.25 * gate}
      }
    }
    // ---- a spring: echoes a period apart, each a falling chirp, losing a little each time ----
    // The echo train is the sound of a spring -- its drip -- and the diffuse field only smears
    // it, so the echoes carry most of the energy of the first 300 ms (`echoRatio` of the field's).
    // Each echo loses what the tank's own T60 curve implies over one period at each frequency its
    // chirp passes through, so the train and the field decay together, the highs sooner, and the
    // reverb time and ratios still mean what they say.
    if (type === 'spring') {
      const [fromHz, toHz] = design.chirpHz, echoes = new Float32Array(frames);
      for (const [index, periodMs] of design.periodsMs.entries()) {
        const period = periodMs / 1000 * sr * (1 + (channel ? 0.013 : 0) * (index + 1));
        const chirp = Math.round(period * 0.55), seconds = period / sr, loss = Math.exp(-T60 * seconds / s.seconds);
        for (let echo = 1, level = 1; level > 1e-4 && pre + echo * period < frames; echo++, level *= loss) {
          // Each echo smears a little wider than the last; its amplitude falls to match, so the
          // energy an echo carries is what the loss leaves it.
          const start = pre + Math.round(echo * period), spread = 1 + echo * 0.08, width = Math.round(chirp * spread),
            amplitude = 1 / Math.sqrt(spread), elapsed = echo * seconds;
          let phase = random.next() * 2 * Math.PI;
          for (let j = 0; j < width && start + j < frames; j++) {
            const along = j / width, hz = fromHz * (toHz / fromHz) ** along;
            phase += 2 * Math.PI * hz / sr;
            echoes[start + j] += amplitude * Math.exp(-T60 * elapsed / curve(hz)) * Math.sin(Math.PI * along) * Math.sin(phase);
          }
        }
      }
      const window = Math.min(frames, pre + Math.round(0.3 * sr));
      let field = 0, train = 0;
      for (let i = pre; i < window; i++) {field += data[i] * data[i]; train += echoes[i] * echoes[i]}
      const scale = Math.sqrt(design.echoRatio * field / Math.max(1e-12, train));
      for (let i = 0; i < frames; i++) data[i] += echoes[i] * scale;
    }
    // ---- early reflections: discrete, thinning, their energy set against the tail's first 80 ms
    if (design.early) {
      const {count, windowMs, ratio} = design.early, window = windowMs / 1000 * sr;
      let late = 0;
      for (let i = pre; i < Math.min(frames, pre + 0.08 * sr); i++) late += data[i] * data[i];
      const times = Array.from({length: count}, (_, index) => {
        const along = (index + random.next() * 0.8 + 0.1) / count;
        return Math.max(1, Math.round(window * along ** 1.6));
      });
      const first = Math.min(...times);
      let energy = 0;
      const taps = times.map(offset => {
        const amplitude = (first / offset) * (random.next() < 0.5 ? -1 : 1) * (0.7 + 0.3 * random.next());
        energy += amplitude * amplitude;
        return {offset, amplitude};
      });
      const scale = Math.sqrt(Math.max(1e-12, ratio * late / Math.max(1e-12, energy)));
      for (const {offset, amplitude} of taps) {
        const at = pre + offset;
        // Three samples, not one: a reflection off a real surface is already a little dulled.
        if (at < frames) data[at] += 0.5 * amplitude * scale;
        if (at + 1 < frames) data[at + 1] += 0.3 * amplitude * scale;
        if (at + 2 < frames) data[at + 2] += 0.2 * amplitude * scale;
      }
    }
    // ---- a device's return band: the plate's mid peak, the spring's narrow usable range --------
    if (design.returnBand) {
      const [lowHz, highHz] = design.returnBand, hp = one(lowHz), lp = one(highHz);
      let hpState = 0, lpState = 0, second = 0;
      for (let i = 0; i < frames; i++) {
        hpState += hp * (data[i] - hpState);
        const highPassed = data[i] - hpState;
        lpState += lp * (highPassed - lpState);
        second += lp * (lpState - second);
        data[i] = second;
      }
    }
  }
  return buffer;
}

// T60 in one octave band: the impulse through an eighth-order Butterworth band-pass on the
// standard octave's edges, steep enough that a long neighbouring band does not ring into it.
export function measureBandT30(samples, sampleRate, centre) {
  const band = Float64Array.from(samples);
  butterworth(band, 'highpass', centre / Math.SQRT2, sampleRate);
  if (centre * Math.SQRT2 < 0.45 * sampleRate) butterworth(band, 'lowpass', centre * Math.SQRT2, sampleRate);
  return measureT30(band, sampleRate);
}

// T60 of an impulse measured by Schroeder backward integration over -5 to -35 dB (T30 doubled),
// as ISO 3382-1 measures a room. Used by the tests to check a design against its own numbers.
export function measureT30(samples, sampleRate) {
  const energy = new Float64Array(samples.length);
  let sum = 0;
  for (let i = samples.length - 1; i >= 0; i--) {sum += samples[i] * samples[i]; energy[i] = sum}
  const total = energy[0], db = i => 10 * Math.log10(Math.max(1e-30, energy[i] / total));
  let start = -1, end = -1;
  for (let i = 0; i < samples.length; i++) {
    if (start < 0 && db(i) <= -5) start = i;
    if (db(i) <= -35) {end = i; break}
  }
  if (start < 0 || end < 0) return null;
  // Least squares over the range, as the standard does, rather than two points.
  let n = 0, sx = 0, sy = 0, sxx = 0, sxy = 0;
  for (let i = start; i <= end; i += 16) {const x = i / sampleRate, y = db(i); n++; sx += x; sy += y; sxx += x * x; sxy += x * y}
  const slope = (n * sxy - sx * sy) / (n * sxx - sx * sx);
  return slope < 0 ? -60 / slope : null;
}
