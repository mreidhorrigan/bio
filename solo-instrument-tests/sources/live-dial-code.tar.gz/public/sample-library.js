// The original sample banks, decoded once a context and shared by every bot that plays them (each lease releases its
// files; the last release frees them).
//
// Within what the device can hold (RESEARCH_BACKLOG second queue, "Mobile loading"): a context's library has a budget of
// decoded audio, all its banks together (shared/device-profile.js: a phone's page 48 MiB), besides each bank's own
// 128 MiB. A bank is decoded in the order that plays most of it for what is decoded (decodeOrder: a pitched bank's
// range spread first, a kit's folders in turn), and what does not fit is left out rather than the bank refused; the
// lease says which files it holds, which it left out, and whether it is whole. The budget is shared: where a bank needs
// room, the banks holding more than their share of it (the budget over the banks held) give back their last files, the
// fill of their range, down to that share and never below the files that still play all of them (leastKept); each
// lease hears what it gave back (`onShed`), so its bot plays the recordings it has left. A file that fails to decode for
// want of memory stops the loading there, keeping what decoded. Only a bank of which nothing fits fails.
//
// Room again (regrow): when a bank is released, the banks that gave files back, or left them out, take them back in
// their decode order as far as the budget allows, the one holding least first, a file at a time; each lease hears what
// it regained (`onRegain`). Never while a bank is loading: that bank has the room first, and the regrowth it deferred
// runs when its loading ends, so no recording is decoded only to be given back.
import {decodeOrder,decodedEstimate,deviceProfile,leastKept} from './shared/device-profile.js';

const libraries=new WeakMap();
const MAX_FILE=16*1024*1024,MAX_BANK=128*1024*1024,MAX_SECONDS=30;
// A context's library, its budget the device's decoded audio (`profile`, else as the browser says it), set the first
// time it is asked for (a page's engines share its one profile).
export function sampleLibrary(context,{profile=null}={}){
  const device=profile??deviceProfile();
  if(!libraries.has(context))libraries.set(context,new SampleLibrary(context,{budgetBytes:device.decodedBytes,bankBytes:device.bankBytes??MAX_BANK}));
  return libraries.get(context);
}
// Whether an error is the device's memory running out (an allocation refused), not the file's own fault.
const outOfMemory=error=>error instanceof RangeError||/out of memory|allocation failed/i.test(String(error?.message??error));
const decodedBytesOf=buffer=>buffer.length*buffer.numberOfChannels*4;
export class SampleLibrary {
  // bankBytes: one bank's own cap (the device's, shared/device-profile.js: 128 MiB on a page, none in an offline render).
  constructor(context,{budgetBytes=Infinity,bankBytes=MAX_BANK}={}){this.context=context;this.bankBytes=bankBytes;this.entries=new Map();this.manifestPromise=null;this.budgetBytes=budgetBytes;this.decodedBytes=0;this.reservedBytes=0;this.holds=new Set;this.loading=0;this.regrowth=null;this.regrowPending=false}
  // Room for `bytes` more within the budget, from the banks holding more than their share (the budget over the banks
  // held, one more for the bank asking), the largest first, each giving back its last files down to its share and its
  // least kept. Whether the room is there.
  makeRoom(bytes,{asking=null}={}){
    const fits=()=>this.decodedBytes+this.reservedBytes+bytes<=this.budgetBytes;
    const share=this.budgetBytes/(this.holds.size+(asking&&this.holds.has(asking)?0:1));
    for(const hold of [...this.holds].sort((a,b)=>b.bytes-a.bytes)){
      if(fits())return true;
      if(hold===asking)continue;
      while(!fits()&&hold.bytes>share&&hold.order.length>hold.least)hold.giveBack();
    }
    return fits();
  }
  // Room given back: the banks missing files take them back, as far as the budget allows (see above). A pass is under
  // way until no bank can take more; one asked for while a bank loads, or while a pass runs, follows it.
  regrow(){
    this.regrowPending=true;
    if(!this.loading&&!this.regrowth)this.regrowth=this.regrowPass().catch(()=>{}).finally(()=>{this.regrowth=null;if(this.regrowPending&&!this.loading)this.regrow()});
  }
  async regrowPass(){
    this.regrowPending=false;const done=new Set;
    while(!this.loading){
      const hold=[...this.holds].filter(hold=>!done.has(hold)&&hold.missing()).sort((a,b)=>a.bytes-b.bytes)[0];
      if(!hold)return;
      const outcome=await hold.regain();
      if(outcome==='pressure')return;
      if(outcome==='none')done.add(hold);
    }
    this.regrowPending=true;
  }
  // Once no regrowth is under way.
  async settled(){while(this.regrowth)await this.regrowth}
  async catalog(){
    this.manifestPromise||=fetch('sample-banks.json').then(response=>{if(!response.ok)throw new Error('Original samples need the Musebots server; you can also choose local audio files');return response.json()}).catch(error=>{this.manifestPromise=null;throw error});
    return this.manifestPromise;
  }
  // A bank's preset, as much of it as fits: {bank, preset, files (those it holds, in the bank's order), left (those left
  // out), complete, pressure (whether memory ran out), buffers, design, metadata, bytes, release}. `onProgress` hears
  // each file as it decodes: {loaded, total, bytes, file, budgetBytes}. While any bank loads, regrowth waits (regrow).
  async acquire(bank,options={}){
    this.loading++;
    try{return await this.loadBank(bank,options)}
    finally{if(!--this.loading&&this.regrowPending)this.regrow()}
  }
  // `seconds`: how much of each file is served, the bank's own where its design says (a piano's bass rings longer than
  // a drum), else 8; and no more of a file than its entry says it sounds (its `seconds`).
  async loadBank(bank,{preset='',seconds,onProgress=()=>{}}={}){
    const catalog=await this.catalog(),manifest=catalog[bank];if(!manifest)throw new Error(`Unknown sample bank: ${bank}`);
    const selected=manifest.presets?.find(item=>item.id===preset)||manifest.presets?.[0],files=selected?.files||manifest.files;
    if(!files?.length)throw new Error('This sample preset is empty');
    const served=Math.max(.1,Math.min(MAX_SECONDS,seconds??manifest.design?.seconds??8)),order=decodeOrder(files,manifest.entries),bankCap=this.bankBytes;
    const servedOf=file=>{const own=Number(manifest.entries?.[file]?.seconds);return Number.isFinite(own)&&own>0?Math.max(.1,Math.min(served,own)):served};
    const urlOf=file=>`/samples/${encodeURIComponent(bank)}/${file.split('/').map(encodeURIComponent).join('/')}?seconds=${servedOf(file)}`;
    const estimateOf=(file,shared)=>shared?0:decodedEstimate(manifest.entries?.[file]?.bytes,{seconds:servedOf(file),sampleRate:this.context?.sampleRate})??0;
    const leases=[],buffers=new Map(),sizes=new Map(),byFile=new Map(),refused=new Set,listeners={shed:null,regain:null};
    let next=0,bytes=0,failure,pressure=false,overBank=false,result=null,released=false;
    const keep=(file,lease,size)=>{leases.push(lease);bytes+=size;buffers.set(file,lease.buffer);sizes.set(file,size);byFile.set(file,lease);hold.order.push(file)};
    // The lease's account of its files, in the bank's order, as it gives them back and takes them back.
    const settle=()=>{if(!result)return;result.files=files.filter(file=>buffers.has(file));result.left=files.filter(file=>!buffers.has(file));result.complete=!result.left.length};
    // What this bank holds of the budget, as another bank may ask it to give back (makeRoom): its files in the order
    // they were decoded, the last given back first. Once loaded, it may take back what it misses (regrow).
    const hold={bank,order:[],least:leastKept(files,manifest.entries),get bytes(){return bytes},
      giveBack:()=>{const file=hold.order.pop(),lease=byFile.get(file);byFile.delete(file);leases.splice(leases.indexOf(lease),1);
        bytes-=sizes.get(file);buffers.delete(file);lease.release();settle();listeners.shed?.(file)},
      missing:()=>Boolean(result)&&!released&&order.some(file=>!byFile.has(file)&&!refused.has(file)),
      // The first file of its decode order it misses that fits the room left and its own cap, decoded: 'gained';
      // 'failed' where it would not decode, or is over the cap once decoded (it is not asked for again, and the next may
      // be); 'none' where nothing fits; 'pressure' where memory ran out (the pass ends; it is asked for at the next).
      regain:async()=>{
        for(const file of order){
          if(byFile.has(file)||refused.has(file))continue;
          const url=urlOf(file),shared=this.entries.has(url),estimate=estimateOf(file,shared);
          if(bytes+estimate>bankCap||this.decodedBytes+this.reservedBytes+estimate>this.budgetBytes)continue;
          let lease;
          try{lease=await this.retain(url,{reserve:estimate})}
          catch(error){if(outOfMemory(error))return 'pressure';refused.add(file);return 'failed'}
          const size=decodedBytesOf(lease.buffer);
          if(bytes+size>bankCap){refused.add(file);lease.release();return 'failed'}
          if(released||(!shared&&this.decodedBytes>this.budgetBytes)){lease.release();return 'none'}
          keep(file,lease,size);settle();listeners.regain?.(file,lease.buffer);return 'gained';
        }
        return 'none';
      }};
    this.holds.add(hold);
    try{
      await Promise.all(Array.from({length:Math.min(4,order.length)},async()=>{
        while(next<order.length&&!failure&&!pressure){
          const file=order[next++],url=urlOf(file),shared=this.entries.has(url),estimate=estimateOf(file,shared);
          // Within the device's budget (what the context holds, and what is decoding) and the bank's own.
          if(bytes+estimate>bankCap){overBank=true;continue}
          if(!this.makeRoom(estimate,{asking:hold}))continue;
          try{
            const lease=await this.retain(url,{reserve:estimate}),size=decodedBytesOf(lease.buffer);
            if(bytes+size>bankCap||(!shared&&this.decodedBytes>this.budgetBytes)){overBank||=bytes+size>bankCap;lease.release();continue}
            keep(file,lease,size);
            onProgress({loaded:buffers.size,total:files.length,bytes,file,budgetBytes:this.budgetBytes});
          }catch(error){if(outOfMemory(error))pressure=true;else failure=error}
        }
      }));
      if(failure)throw failure;
      if(!buffers.size)throw new Error(overBank?`This sample selection exceeds ${Math.round(bankCap/1048576)} MiB of decoded audio`:pressure?`This device ran out of memory decoding ${bank}`:
        `This device holds ${Math.round(this.budgetBytes/1048576)} MiB of decoded audio, and none of ${bank} fits in what is left`);
      result={bank,preset:selected?.id||'',files:[],left:[],complete:false,pressure,buffers,design:selected?.design||manifest.design||{},metadata:manifest.entries||{},
        get bytes(){return bytes},
        // A file given back for another bank, or taken back when there is room again: gone from the lease's files or
        // back in them, and its holder told (a file taken back with its buffer).
        set onShed(listener){listeners.shed=listener},
        set onRegain(listener){listeners.regain=listener},
        release:()=>{if(released)return;released=true;this.holds.delete(hold);for(const lease of leases)lease.release();leases.length=0;this.regrow()}};
      settle();
      return result;
    }catch(error){this.holds.delete(hold);for(const lease of leases)lease.release();this.regrow();throw error}
  }
  // A file decoded (once, shared): its buffer, and a release. What it holds decoded counts against the budget until its
  // last release. The room its decoder reserved for it (`reserve`, its estimate) counts until it is decoded, and then
  // its size does in the same step, so no file is counted twice while others decode (the budget's room is not lost).
  async retain(url,{reserve=0}={}){
    let entry=this.entries.get(url);
    if(!entry){
      entry={refs:0,bytes:0,promise:fetch(url).then(async response=>{
        if(!response.ok)throw new Error(`Sample unavailable (${response.status}): ${decodeURIComponent(url.split('/').at(-1).split('?')[0])}`);
        if(Number(response.headers.get('content-length'))>MAX_FILE)throw new Error('Sample exceeds 16 MiB');
        const data=await response.arrayBuffer();if(data.byteLength>MAX_FILE)throw new Error('Sample exceeds 16 MiB');
        return this.context.decodeAudioData(data);
      }).then(buffer=>{this.reservedBytes-=reserve;if(this.entries.get(url)===entry){entry.bytes=decodedBytesOf(buffer);this.decodedBytes+=entry.bytes}return buffer},
        error=>{this.reservedBytes-=reserve;throw error})};
      this.entries.set(url,entry);this.reservedBytes+=reserve;
    }
    entry.refs++;let released=false;
    const release=()=>{if(released)return;released=true;if(--entry.refs===0&&this.entries.get(url)===entry){this.entries.delete(url);this.decodedBytes-=entry.bytes}};
    try{const buffer=await entry.promise;if(buffer.duration>MAX_SECONDS+.05)throw new Error('Choose a sample no longer than 30 seconds');return {buffer,release}}
    catch(error){release();throw error}
  }
  async importFiles(files,{onProgress=()=>{}}={}){
    const buffers=new Map(),metadata={};let bytes=0;
    for(const file of files){
      if(file.size>MAX_FILE)throw new Error(`${file.name} exceeds 16 MiB`);
      if(buffers.has(file.name))throw new Error(`Duplicate sample filename: ${file.name}`);
      const buffer=await this.context.decodeAudioData(await file.arrayBuffer());
      if(buffer.duration>MAX_SECONDS)throw new Error(`${file.name} is longer than 30 seconds`);
      bytes+=buffer.length*buffer.numberOfChannels*4;if(bytes>MAX_BANK)throw new Error('These samples exceed 128 MiB of decoded audio');
      buffers.set(file.name,buffer);onProgress({loaded:buffers.size,total:files.length,bytes});
    }
    if(!buffers.size)throw new Error('Choose one or more short audio files');
    return {bank:'local',preset:'',files:[...buffers.keys()],buffers,metadata,design:{},bytes,release(){buffers.clear()}};
  }
}
