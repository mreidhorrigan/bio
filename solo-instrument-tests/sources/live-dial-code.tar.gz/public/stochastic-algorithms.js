// Direct equivalents of the reusable Max abstractions used by the source bots.
import { random } from './random-source.js';
// The Max idiom the source bots used, [random 32768] over 32767: 32768 values from 0 to 1, both ends included. Kept as
// it is, because the ports are faithful to it and every seeded piece depends on it (the mathematical audit, S01).
export const unitRandom = (rng=random) => Math.floor(rng()*32768)/32767;
export const decide = (rng=random) => unitRandom(rng) >= .5;
// Within one of uniform on unitRandom's 32768 points, which is as even as any mapping of them can be (the audit's S01:
// its counts for 3 are 10923, 10922, 10923). Finer would take a finer source, and change every seeded piece.
export function randomInt(max,rng=random){return Math.min(max-1,Math.floor(unitRandom(rng)*max))}
// A value drawn with probability in proportion to its weight. A weight that is zero, negative or not a number is never
// drawn: the audit's S01 found the first zero-weight value returned whenever the draw was exactly 0, one draw in 32768.
// Ties at a boundary still go to the earlier value, as they always did, so a seeded piece changes only where a
// zero-weight value would have been chosen. With no positive weight (or mismatched lengths) it keeps the first value,
// as the Max abstraction did.
export function weightedChoice(values,weights,rng=random){
  const weightOf=index=>{const weight=Number(weights[index]);return Number.isFinite(weight)&&weight>0?weight:0};
  if(!values.length||values.length!==weights.length)return values[0];
  let sum=0;for(let i=0;i<values.length;i++)sum+=weightOf(i);
  if(!(sum>0))return values[0];
  let chosen=unitRandom(rng)*sum,last=0;
  for(let i=0;i<values.length;i++){const weight=weightOf(i);if(!weight)continue;last=i;chosen-=weight;if(chosen<=0)return values[i]}
  return values[last];
}
export function boundedDrunk(value,range,step,rng=random){const movement=randomInt(Math.abs(step)*2+1,rng)-Math.abs(step);return Math.max(0,Math.min(range-1,value+movement))}
export function occurrenceMode(values){const counts=new Map();for(const value of values)counts.set(value,(counts.get(value)||0)+1);return [...counts].reduce((best,item)=>item[1]>best[1]?item:best,[undefined,-1])[0]}
export const contains=(values,value)=>values.includes(value);
export function weightedObject(record,rng=random){const entries=Object.entries(record);return weightedChoice(entries.map(([key])=>key),entries.map(([,weight])=>weight),rng)}
export function scramble(values,rng=random){const result=[...values];for(let i=result.length-1;i>0;i--){const j=randomInt(i+1,rng);[result[i],result[j]]=[result[j],result[i]]}return result}

export function additiveGroupStarts(groups,total){const starts=[],limit=Math.max(1,Math.trunc(Number(total)||1));let position=0;for(const group of groups.map(Number).filter(value=>Number.isInteger(value)&&value>0)){if(position>=limit)break;starts.push(position);position+=group}return position===limit?starts:[]}
export function euclideanDistance(a,b){const length=Math.min(a.length,b.length);if(!length)return Infinity;let sum=0;for(let index=0;index<length;index++){const difference=Number(a[index])-Number(b[index]);if(!Number.isFinite(difference))return Infinity;sum+=difference*difference}return Math.sqrt(sum)}
export function nearestRecords(records,target,limit=10,distance=euclideanDistance){
  const count=Math.max(0,Math.trunc(limit));
  // Keep arbitrary metrics and large requests on their existing path.
  if(distance!==euclideanDistance||!Array.isArray(records)||!Number.isFinite(count)||count>128)
    return records.map((record,index)=>({index,record,distance:distance(record,target)})).filter(item=>Number.isFinite(item.distance)).sort((a,b)=>a.distance-b.distance||a.index-b.index).slice(0,count);
  const out=[];
  for(let index=0;index<records.length;index++){
    if(!(index in records))continue;
    const record=records[index],value=euclideanDistance(record,target);
    if(!Number.isFinite(value)||!count)continue;
    const item={index,record,distance:value};let at=out.length;
    while(at>0&&(value<out[at-1].distance||value===out[at-1].distance&&index<out[at-1].index))at--;
    if(at<count){out.splice(at,0,item);if(out.length>count)out.pop();}
  }
  return out;
}
// A rank biased toward the top by (base^u - 1)/(base - 1), which is u itself at base 1: the audit's S02 found NaN there.
// Near 1 (within 1e-9) the limit is used; a base that is not a positive number means no bias. Elsewhere the formula is
// the one it always was, so no other draw changes.
export function exponentialRankIndex(length,base=20,rng=random){const count=Math.max(1,Math.trunc(length)),unit=unitRandom(rng),b=Number(base),curved=!(Number.isFinite(b)&&b>0)||Math.abs(b-1)<1e-9?unit:(Math.exp(unit*Math.log(b))-1)/(b-1);return Math.min(count-1,Math.floor(curved*count))}
export function randomDupleOnsets(steps,rng=random){const limit=Math.max(1,Math.trunc(Number(steps)||1)),onsets=[];let position=0;while(position<limit){position+=decide(rng)?2:1;if(position<limit)onsets.push(position)}return scramble(onsets,rng)}
export function interpolateControlPoints(points,position,eased=true){if(!points.length)return 0;if(points.length===1)return Number(points[0])||0;const normalized=Math.max(0,Math.min(1,Number(position)||0)),scaled=normalized*(points.length-1),index=Math.min(points.length-2,Math.floor(scaled)),fraction=scaled-index,mix=eased?fraction*fraction*(3-2*fraction):fraction,a=Number(points[index])||0,b=Number(points[index+1])||0;return a+(b-a)*mix}
export function interpolateCurvePoints(points,position){if(!points.length)return 0;const x=Math.max(0,Math.min(1,Number(position)||0)),ordered=[...points].sort((a,b)=>a.x-b.x);if(x<=ordered[0].x)return ordered[0].y;if(x>=ordered.at(-1).x)return ordered.at(-1).y;const right=ordered.findIndex(point=>point.x>=x),a=ordered[right-1],b=ordered[right],fraction=(x-a.x)/Math.max(Number.EPSILON,b.x-a.x),mix=fraction*fraction*(3-2*fraction);return a.y+(b.y-a.y)*mix}
export function randomFivePointCurve({xRanges=[[.05,.333],[.35,.666],[.7,.95]],terminalWeights=[.8,.1,.1]}={},rng=random){const terminal=weightedChoice(['random','zero','one'],terminalWeights,rng),xs=[0,...xRanges.map(([low,high])=>low+rng()*(high-low)),1],ys=Array.from({length:5},()=>unitRandom(rng));if(terminal==='zero')ys[4]=0;else if(terminal==='one')ys[4]=1;return xs.map((x,index)=>({x,y:ys[index]}))}
export function randomProductGate(value,leftRange=[500,1000],rightRange=[0,500],rng=random){const [a,b]=leftRange,[c,d]=rightRange,left=Math.floor(a+rng()*(b-a)),right=Math.floor(c+rng()*(d-c));return left*Number(value)>right}
export function gaussianRandom(rng=random){let u=0,v=0;while(u<=Number.EPSILON)u=rng();while(v<=Number.EPSILON)v=rng();return Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v)}

// General rhythm algorithms. Musical densities, rotations, and other choices live
// in stochastic-config.js; these functions are deterministic and meter-agnostic.
export function defaultGrouping(numerator){
  const n=Math.max(1,Math.trunc(Number(numerator)||1));
  if(n===1)return[1];
  const groups=[],threes=Math.floor(n/3),remainder=n%3;
  if(remainder===1){for(let i=0;i<threes-1;i++)groups.push(3);groups.push(2,2)}
  else{for(let i=0;i<threes;i++)groups.push(3);if(remainder===2)groups.push(2)}
  return groups;
}
export function rotateCycle(values,rotation=0){const n=values.length;if(!n)return[];const shift=((Math.trunc(rotation)%n)+n)%n;return values.map((_,index)=>values[(index-shift+n)%n])}
export function neighborEvolvedCycle(values,iterations=1,rng=random){const cycle=values.map(value=>value?1:0);if(!cycle.length)return cycle;for(let pass=0;pass<Math.max(0,Math.trunc(iterations));pass++){const next=[...cycle];for(let index=0;index<cycle.length;index++){if(!cycle[index])continue;const previous=(index-1+cycle.length)%cycle.length,following=(index+1)%cycle.length,count=cycle[previous]+cycle[following];if(count===2)next[index]=0;else if(count===0)next[rng()<.5?previous:following]=1;else if(rng()<.5)next[cycle[previous]?following:previous]=1}cycle.splice(0,cycle.length,...next)}return cycle}
export function euclideanRhythm(hits,steps,rotation=0){
  const n=Math.max(1,Math.trunc(Number(steps)||1)),k=Math.max(0,Math.min(n,Math.trunc(Number(hits)||0)));
  // Modular bucket form of Euclid's algorithm: exactly k maximally-even onsets.
  const cycle=Array.from({length:n},(_,index)=>Math.floor((index+1)*k/n)!==Math.floor(index*k/n)?1:0);
  const first=cycle.indexOf(1),aligned=first>0?rotateCycle(cycle,-first):cycle;
  return rotateCycle(aligned,rotation);
}
export function normalizeClave(value,steps){
  const n=Math.max(1,Math.trunc(Number(steps)||1));if(!Array.isArray(value)||!value.length)return[];
  if(value.length===n&&value.every(item=>Number(item)===0||Number(item)===1))return value.map(Number);
  const cycle=Array(n).fill(0);for(const item of value){const onset=Number(item);if(Number.isInteger(onset))cycle[((onset%n)+n)%n]=1}return cycle;
}
export function cyclicPattern({steps,hits=0,rotation=0,clave=[]}={}){const explicit=normalizeClave(clave,steps);return explicit.length?rotateCycle(explicit,rotation):euclideanRhythm(hits,steps,rotation)}
export function metricWeights(groups=[4],subdivision=4){
  const valid=groups.map(Number).filter(item=>Number.isInteger(item)&&item>0),sub=Math.max(1,Math.trunc(Number(subdivision)||1)),steps=valid.reduce((a,b)=>a+b,0)*sub,weights=Array(steps).fill(1);
  let beat=0;for(const size of valid){for(let local=0;local<size;local++){const pulse=(beat+local)*sub;weights[pulse]+=2;if(local===0)weights[pulse]+=2}beat+=size}
  if(weights.length)weights[0]+=2;return weights;
}
export function clumpedRhythm(hits,groups=[4],subdivision=4,rotation=0){
  const valid=groups.map(Number).filter(value=>Number.isInteger(value)&&value>0),sub=Math.max(1,Math.trunc(Number(subdivision)||1)),steps=valid.reduce((sum,value)=>sum+value,0)*sub,count=Math.max(0,Math.min(steps,Math.trunc(Number(hits)||0))),starts=[];let beat=0;for(const size of valid){starts.push(beat*sub);beat+=size}const circularDistance=(a,b)=>Math.min((a-b+steps)%steps,(b-a+steps)%steps),ranked=Array.from({length:steps},(_,index)=>({index,distance:Math.min(...starts.map(start=>circularDistance(index,start))),subdivision:index%sub})).sort((a,b)=>a.distance-b.distance||a.subdivision-b.subdivision||a.index-b.index),cycle=Array(steps).fill(0);for(const {index}of ranked.slice(0,count))cycle[index]=1;return rotateCycle(cycle,rotation)
}
export function randomAdditiveGrouping(total,allowed=[2,3],rng=random){const target=Math.max(1,Math.trunc(Number(total)||1)),parts=[...new Set(allowed.map(Number).filter(value=>Number.isInteger(value)&&value>0))].sort((a,b)=>a-b),possible=Array(target+1).fill(false);possible[0]=true;for(let remainder=1;remainder<=target;remainder++)possible[remainder]=parts.some(part=>remainder>=part&&possible[remainder-part]);if(!possible[target])return defaultGrouping(target);const groups=[];let remaining=target;while(remaining){const choices=parts.filter(part=>remaining>=part&&possible[remaining-part]);const choice=choices[Math.min(choices.length-1,Math.floor(unitRandom(rng)*choices.length))];groups.push(choice);remaining-=choice}return groups}
