import {parseGranularCorpus,indexGranularCorpus,createGrainSelector} from './shared/granular-corpus.js';
import {parseGranularProfile,grainPools} from './shared/granular-profile.js';
import {createRandomStream} from './random-source.js';

// Loads a grain corpus and schedules grains on the ensemble clock.
//
// This deliberately does NOT go through public/sample-library.js. That library guards
// the shared sample banks with limits meant for one-file-per-note instruments — 16 MiB a
// file, 30 seconds a file, 128 MiB a bank — and a grain corpus is the opposite shape: a
// handful of long packs, each holding hundreds of slices that are only ever read a
// fraction of a second at a time. A 388-second pack set is not an oversized instrument;
// it is the instrument. The budget below replaces those limits with one that matches
// what actually costs memory here (decoded audio), and refuses the rest of the corpus
// rather than the whole load, so an under-budget device still plays a smaller corpus.
// See docs/GRANUBOT.md for the measured run context.
export const DESKTOP_BUDGET_BYTES=192*1024*1024;
export const MODEST_BUDGET_BYTES=48*1024*1024;
// Concurrency, not memory, is what a grain cloud runs out of first: every grain is a
// BufferSource with its own envelope, and the render thread pays for all of them at once.
export const MAX_CONCURRENT_GRAINS=48;

const bytesOf=buffer=>buffer.length*buffer.numberOfChannels*4;

// A phone is not the target for this bot, but it should degrade rather than fail: the
// corpus loads until the budget runs out and the pools only offer what actually decoded.
export function deviceBudgetBytes(scope=globalThis){
  const memory=Number(scope.navigator?.deviceMemory);
  const coarse=scope.matchMedia?.('(pointer: coarse)')?.matches;
  return (Number.isFinite(memory)&&memory<8)||coarse?MODEST_BUDGET_BYTES:DESKTOP_BUDGET_BYTES;
}

// What this device can do with a grain corpus, decided before anything is fetched, so a
// listener is told what will happen instead of watching a bot appear to play in silence.
// `typicalBytes` is what a bot-sized corpus costs decoded (the shipped one is 71 MiB);
// the real figure replaces this guess once the manifest has actually loaded.
export function corpusAvailability(scope=globalThis,{budgetBytes=null,typicalBytes=71*1024*1024,canDecode=null}={}){
  // `canDecode` is what a running engine knows; the global sniff answers for the menu,
  // where no engine exists yet.
  const audible=canDecode??(typeof scope.AudioContext==='function'||typeof scope.webkitAudioContext==='function');
  if(!audible)
    return {state:'unavailable',message:'This page has no browser audio, so a grain corpus cannot be decoded here.'};
  if(scope.location?.protocol==='file:')
    return {state:'unavailable',message:'A grain corpus is served by the Musebots server; this page is opened from a file, so there is nothing to load.'};
  const budget=budgetBytes??deviceBudgetBytes(scope);
  if(budget<typicalBytes)
    return {state:'limited',
      message:`This device is held to ${Math.round(budget/1048576)} MiB of decoded audio, so only part of the corpus will load and the bot will draw on fewer sounds.`};
  return {state:'ready',message:''};
}

export class GrainCorpusPlayer {
  constructor(audio,{name='granubot',base='./data/granubot',budgetBytes=null,seed=1,fetchImpl=null}={}){
    this.audio=audio;this.name=name;this.base=String(base).replace(/\/+$/,'');
    this.budgetBytes=budgetBytes??deviceBudgetBytes();
    this.fetch=fetchImpl||((...args)=>globalThis.fetch(...args));
    this.random=createRandomStream(`${seed}:granubot:grains`);
    this.buffers=new Map();this.voices=new Set();
    this.decodedBytes=0;this.skippedSources=[];this.ready=false;
  }
  get context(){return this.audio?.ctx||null}
  async load({onProgress}={}){
    if(this.ready)return this;
    const read=async file=>{
      const response=await this.fetch(`${this.base}/${file}`);
      if(!response.ok)throw new Error(`Could not load ${file} (${response.status})`);
      return response;
    };
    const corpus=parseGranularCorpus(await (await read(`${this.name}-corpus.json`)).json());
    this.index=indexGranularCorpus(corpus);
    this.profile=parseGranularProfile(await (await read(`${this.name}-profile.json`)).json(),this.index);
    // Packs decode in manifest order and stop at the budget; the corpus is sorted so
    // that order is stable, which keeps a truncated load deterministic too.
    let loaded=0;
    for(const source of corpus.sources){
      // `source.audio` is already a browser-relative URL: the manifest owns where its
      // audio lives, so a corpus can be served from anywhere the page can reach.
      const response=await this.fetch(source.audio);
      if(!response.ok){this.skippedSources.push(source.id);continue}
      const buffer=await this.context.decodeAudioData(await response.arrayBuffer());
      if(this.decodedBytes+bytesOf(buffer)>this.budgetBytes){this.skippedSources.push(source.id);continue}
      this.buffers.set(source.id,buffer);this.decodedBytes+=bytesOf(buffer);
      onProgress?.({loaded:++loaded,total:corpus.sources.length,bytes:this.decodedBytes});
    }
    if(!this.buffers.size)throw new Error('No grain packs fitted in the audio budget');
    this.pools=grainPools(this.profile,{decoded:this.buffers});
    this.roleSelectors=new WeakMap();
    this.selector=createGrainSelector(this.index,{random:()=>this.random.next(),pool:this.pools.transitions});
    this.ready=true;
    return this;
  }
  // Pools are precomputed lists; a gesture asks for one by name and never filters.
  poolFor(role){return this.pools?.[role]?.length?this.pools[role]:this.pools?.transitions||[]}
  select(role,{pitches=[]}={}){
    const pool=this.poolFor(role);
    if(!pool.length)return null;
    this.roleSelectors??=new WeakMap();
    let selector=this.roleSelectors.get(pool);
    if(!selector){selector=createGrainSelector(this.index,{random:()=>this.random.next(),pool});this.roleSelectors.set(pool,selector)}
    // Preserve the CURRENT stateless-per-selection repetition/order policy.
    // Retaining these maps across calls would be a musical-policy change.
    return selector.reset().select({pitches});
  }
  // `events` are {grain, at, shift, gain}: `at` in seconds from now on the ensemble
  // clock, which AudioEngine.eventStart turns into a sample-accurate start time.
  schedule(events,{gain=.5,maxVoices=MAX_CONCURRENT_GRAINS}={}){
    const context=this.context;
    if(!context||!this.audio?.master||this.audio.muted)return 0;
    let started=0;
    for(const event of events){
      if(this.voices.size>=maxVoices)break;
      const buffer=this.buffers.get(event.grain.source);
      if(!buffer)continue;
      const rate=2**((event.shift||0)/12),
        start=this.audio.eventStart(event.at||0),
        sounding=event.grain.durationSeconds/rate,
        level=Math.max(0,gain*(event.gain??this.profile.detail(event.grain)?.gain??1)),
        // Grains are cut on zero crossings, but varispeed moves them, so a short fade
        // is what actually guarantees no click. It scales with the grain so a 50 ms
        // grain is not mostly envelope.
        fade=Math.min(.004,sounding/4);
      const source=context.createBufferSource(),amp=context.createGain();
      source.buffer=buffer;source.playbackRate.value=rate;
      amp.gain.setValueAtTime(0,start);
      amp.gain.linearRampToValueAtTime(level,start+fade);
      amp.gain.setValueAtTime(level,start+sounding-fade);
      amp.gain.linearRampToValueAtTime(0,start+sounding);
      source.connect(amp).connect(this.audio.master);
      const graph=this.audio.retainGraph(source,[source,amp]);
      graph.sampleGain=amp;                       // AudioEngine.stopSampleVoices honours this
      this.voices.add(graph);
      source.addEventListener('ended',()=>this.voices.delete(graph),{once:true});
      source.start(start,event.grain.offsetSeconds,event.grain.durationSeconds);
      source.stop(start+sounding+.005);
      started++;
    }
    return started;
  }
  stop(){
    for(const graph of this.voices){try{graph.source.stop()}catch{/* already finished */}}
    this.voices.clear();
  }
  dispose(){this.stop();this.buffers.clear();this.ready=false}
  report(){
    return {
      grains:this.index?.grains.length||0,packs:this.buffers.size,
      decodedMiB:Number((this.decodedBytes/1048576).toFixed(1)),
      budgetMiB:Number((this.budgetBytes/1048576).toFixed(1)),
      skipped:this.skippedSources.length,voices:this.voices.size,
      roles:this.profile?Object.fromEntries(Object.entries(this.profile.counts)):{},
    };
  }
}
