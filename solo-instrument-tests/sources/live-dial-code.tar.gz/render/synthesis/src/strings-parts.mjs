// A bowed string player's part on the strings' model (Artifastring, Musebots' driver), the planning a page shares with the
// Mac (render/node/physical-strings.mjs renderParts; the studio page, public/studio/engines/strings-worker.js): its strokes
// compiled into the model's actions (public/shared/performers/physical-strings.js compileActions), the part rendered by
// the `drive` it is given -- the driver's process in Node, the driver in WebAssembly in a page -- each stroke heard when it
// arrives and the part rendered again, each stroke heard late begun earlier, up to STRINGS_ANTICIPATION.tries times; the
// try heard most nearly on time kept. Its level its instrument's one scale (gainOf).
import {compileActions,glidesInto,CALIBRATION} from '../../../public/shared/performers/physical-strings.js';
import {MEASURED_AT,stemLevelDb} from '../../../public/shared/performers/sound-power.js';
import {ANTICIPATION,ARRIVAL,nextLead} from './breath.mjs';
import {arrivalOf} from './ness.mjs';
import {floatWav} from '../../../public/shared/float-wav.js';

export {floatWav};

// An instrument's gain (dB): its typical note at ff (its calibration's levels.ff) brought to the instrument's measured
// ff (sound-power.js stemLevelDb at the velocity ff is written at), or null where either is not measured. Its
// recordings' levels are their sessions' own (the Iowa cello's mf 10 dB under its violin's): matched to them, Op. 3.32's
// cellos sounded 21 dB and its violas 8 dB under its violins (the owner, 8 October 2026: "scored instruments simply don't
// sound ... the final pages' violin and viola parts").
export function soundPowerGainDb(instrument){
  const own=CALIBRATION.instruments?.[instrument]?.levels?.ff,heard=stemLevelDb(instrument,MEASURED_AT.ff);
  return Number.isFinite(own)&&heard!==null?heard-own:null;
}
// (Its balance against the other instruments, where measured as the band plays them (scripts/strings-balance.mjs --write:
// balanceDb), added to its sound-power gain: one scale still, every note alike.)
export const gainOf=instrument=>{const entry=CALIBRATION.instruments?.[instrument],sound=soundPowerGainDb(instrument);
  return 10**(((sound!=null?sound+(Number(entry?.balanceDb)||0):entry?.stemGainDb??entry?.gainDb)??0)/20)};
// A 24-bit file's smallest step (render/synthesis/tools/audit_renders.py SILENT): a part's sound under it is silence, and
// one that ends over it in its last 10 ms (CUT_SECONDS there) is cut off.
export const SMALLEST_STEP=2**-23,END_SECONDS=.01;
// The level of the driver's own output under which a part's stem is under SMALLEST_STEP, for the driver to ring the part
// down to (musebots-strings.cpp SILENT): the stem is the driver's output -- its body already in it -- at its
// instrument's one scale.
export const silentFor=({outputScale})=>SMALLEST_STEP/outputScale;
// When a bowed note arrives, as a listener hears it on an instrument whose notes ring on into the next (a string slurred
// from, or let go, rings on at its level for a third of a second, and a pitch heard alone never settles there): its own
// partials -- each of its first eight `clear` of its window's bandwidths from every one of the note before's -- back within
// `db` of their held level for ARRIVAL.frames windows running, after a moment they were not; the first one's middle (within
// ARRIVAL.db, the note before's sound still on them had them there a third of a second early). Each window `periods` of
// its periods, `seconds` at least: over three, 30 ms, the note before's fundamental had leaked into its own partials within
// 6 dB, there before it was bowed. A repeated pitch, with no partials of its own, as arrivalOf hears it (its dip).
// Its `db` where a listener hears a tone begin: "the times at which the envelopes pass a relative threshold of 15 dB
// below the maximum level of the tones" (Vos & Rasch 1981, "The perceptual onset of musical tones", Perception &
// Psychophysics 29(4), 323-335, doi:10.3758/BF03207341). Heard within 6 dB, near the top of its attack, a loud stroke had
// been begun early enough for that to fall on its beat, the rest of its attack before it (the owner, 10 October 2026, of
// Op. 3.36: "it sounds like loud notes are attacked early to 'build up to them', which isn't always how a human player
// would play"; "An attack can be both fast and loud, if given with enough force").
// -> s after its onset (late, else early), null where it is not heard to arrive.
export const VOICED=Object.freeze({db:15,periods:6,seconds:.06,clear:2.5});
export function voicedArrival(samples,rate,{hz,prevHz=null,on,prevOn=null,held:[ha,hb]}){
  if(prevHz&&Math.abs(1200*Math.log2(hz/prevHz))<ARRIVAL.repeat)return arrivalOf(samples,rate,{hz,prevHz,on,prevOn,held:[ha,hb]});
  const width=Math.max(VOICED.seconds,VOICED.periods/hz),n=Math.round(width*rate),hann=Float64Array.from({length:n},(_,i)=>.5-.5*Math.cos(2*Math.PI*i/(n-1)));
  const clear=VOICED.clear/width,own=Array.from({length:8},(_,p)=>hz*(p+1)).filter(f=>f<rate/2&&!(prevHz&&Array.from({length:8},(_,q)=>prevHz*(q+1)).some(g=>Math.abs(f-g)<clear)));
  if(!own.length)return null;
  const level=t=>{const a=Math.max(0,Math.round(t*rate));if(a+n>samples.length)return -Infinity;let e=0;
    for(const f of own){const c=2*Math.cos(2*Math.PI*f/rate);let s1=0,s2=0;for(let i=0;i<n;i++){const s0=samples[a+i]*hann[i]+c*s1-s2;s2=s1;s1=s0}e+=s1*s1+s2*s2-c*s1*s2}
    return 10*Math.log10(e+1e-30)};
  let sum=0,count=0;for(let t=ha;t+width<=hb;t+=.01){sum+=10**(level(t)/10);count++}
  if(!count)return null;const target=10*Math.log10(sum/count)-VOICED.db;
  let absent=false,run=0;
  for(let t=Math.max(prevOn!=null?prevOn+.03:0,on-ARRIVAL.before);t<on+ARRIVAL.after;t+=ARRIVAL.step){
    if(!(level(t)>=target)){absent=true;run=0;continue}
    if(absent&&++run===ARRIVAL.frames)return t-(ARRIVAL.frames-1)*ARRIVAL.step+width/2-on;
  }
  return null;
}
// When a bowed note arrives, by how its stroke took it (the compiler's kinds): slurred, re-bowed or pulsed on the string
// it was on, as a wind's or a brass's is heard (ness.mjs arrivalOf: its pitch its own, at its level) -- one string's one
// length sounds the new pitch at once, and a low string slurred up a tone had its own partials so near the note before's
// that the sound leaked into them, heard a third of a second early; begun from silence, or taken on another string, by
// its own partials (voicedArrival), the string it left ringing on. Where its pitch is never heard -- a cello stopped high
// on its A string, its tone clean, read at another octave by the pitch it was listened for -- by its own partials too.
export function bowedArrival(samples,rate,{kind,...note}){
  const onString=kind==='slur'||kind==='change'||kind==='loure';
  return onString?arrivalOf(samples,rate,note)??voicedArrival(samples,rate,note):voicedArrival(samples,rate,note);
}
// A note's held part, where its level is heard: from a share of it in (0.15 s at most) to a little before its end.
export const heldOf=(start,end)=>{const length=end-start;return [start+Math.min(.15,.4*length),end-Math.min(.05,.1*length)]};

// The strings' anticipation, by ear, as the winds' is (breath.mjs ANTICIPATION): a player's part rendered and each of its
// strokes heard -- when its note arrives -- and rendered again with each stroke heard late begun earlier, its lead the
// next of its tries' (nextLead), within ANTICIPATION's bounds; up to `tries` renders, the one heard most nearly on time
// kept. A stroke is heard where it holds a pitch of its own for `shortest` s at least (no glissando, harmonic,
// multiphonic, tremolo or pluck); one too short to hear is begun as early as the median of those heard of its kind
// (begun from silence, a change of bow, a slur, one to another string, a louré). On the model a stroke from silence
// spoke 50 to 145 ms after its time, a slur to another string 50 to 130 ms -- its attack, and its new string's Helmholtz
// motion, take that long to build -- and a player begins them early, as a wind player does.
export const STRINGS_ANTICIPATION=Object.freeze({tries:4,shortest:.2});
// Each stroke of a part heard in its audio: s after its time that it arrived, else null. (`log` the player's strokes,
// `kinds` the compiler's for them, `leads` how early each was begun: a note's held part ends before the next is begun.)
export function strokeArrivals(samples,rate,log,kinds,leads=[]){
  const order=log.map((g,index)=>({g,index})).filter(({index})=>kinds[index]&&kinds[index]!=='pizzicato').sort((a,b)=>a.g.at-b.g.at);
  const heard=log.map(()=>null);
  order.forEach(({g,index},k)=>{
    const end=Math.min(g.at+g.seconds,Number.isFinite(g.released)?g.released:Infinity);
    if(end-g.at<STRINGS_ANTICIPATION.shortest||glidesInto(g)||g.harmonic||g.multiphonic||g.stroke?.tremolo)return;
    const prev=order[k-1]?.g,next=order[k+1],hz=440*2**((g.note-69)/12),[ha,hb]=heldOf(g.at,end);
    const held=[ha,next?Math.max(ha,Math.min(hb,next.g.at-(leads[next.index]??0)-.02)):hb];
    heard[index]=bowedArrival(samples,rate,{kind:kinds[index],hz,prevHz:prev?440*2**((prev.note-69)/12):null,on:g.at,prevOn:prev?.at??null,held});
  });
  return heard;
}
// Each stroke's next lead (s), from its tries ([{leads, heard}]): a heard stroke's by nextLead, within what its place
// allows -- at most ANTICIPATION.most and its share of the time since the stroke before, never before the piece's start;
// one unheard, its kind's median among those heard.
export function nextStrokeLeads(log,kinds,tries){
  const order=log.map((g,index)=>({g,index})).sort((a,b)=>a.g.at-b.g.at),leads=log.map(()=>0),byKind={};
  order.forEach(({g,index},k)=>{
    const seen=tries.map(t=>[t.leads[index],t.heard[index]]).filter(([,e])=>e!=null);if(!seen.length)return;
    const since=k?g.at-order[k-1].g.at:g.at,room=Math.max(0,Math.min(ANTICIPATION.most,ANTICIPATION.share*since,g.at));
    leads[index]=Math.max(0,Math.min(room,nextLead(seen)));(byKind[kinds[index]]??=[]).push(leads[index]);
  });
  const median=list=>{const sorted=[...list].sort((a,b)=>a-b);return sorted[sorted.length>>1]};
  order.forEach(({g,index},k)=>{
    if(tries.some(t=>t.heard[index]!=null)||!byKind[kinds[index]])return;
    const since=k?g.at-order[k-1].g.at:g.at;leads[index]=Math.max(0,Math.min(median(byKind[kinds[index]]),ANTICIPATION.share*since,g.at));
  });
  return leads;
}
// How far a try is from its time: each heard stroke's lateness beyond ANTICIPATION.tolerance, summed (s).
export const offTime=heard=>heard.reduce((sum,e)=>e==null?sum:sum+Math.max(0,Math.abs(e)-ANTICIPATION.tolerance),0);
// A player's seed from the piece's and its seat (FNV-1a, 32 bits).
export const hash32=text=>{let h=2166136261;for(const c of text){h^=c.charCodeAt(0);h=Math.imul(h,16777619)>>>0}return h};

// One player's part: `entry` its plan's {log (its strokes), seat}, `chair` its variant, `seed` its own; `capabilities` its
// driver's (--capabilities); `drive(actions (text), {type, variant, seed, silent})` -> {samples (the driver's own output,
// its body in it), rate, broken, brokenAt, said (what it said), recovered ([s], where it started again), extra (the
// caller's own: hashes, paths)}. -> {kept, tries: [{leads, compiled, samples (at its one scale), rate, outputScale, heard,
// extra}]}, the kept try's compiled warnings what each try said.
export async function stringsPart(entry,{chair=0,seed,capabilities={},drive}){
  const render=async leads=>{
    // (A driver that rings a part down, given the level its stem is silent under, ends the part there, from its last action;
    // one that cannot, 3 s after it, its strings turned off where they fell quiet -- said.)
    const ringsDown=Boolean(capabilities.ringsDown);
    const compiled=compileActions(entry.log.map((g,k)=>leads[k]>0?{...g,lead:leads[k]}:g),{seat:entry.seat,variant:chair,ringsDown});
    const outputScale=gainOf(compiled.instrument),silent=silentFor({outputScale});
    const driven=await drive(compiled.lines.join('\n')+'\n',{type:compiled.type,variant:compiled.variant,seed,silent:ringsDown?silent:null});
    if(!ringsDown)compiled.warnings.push(`${entry.seat}: the strings' driver cannot ring a part down (no ringsDown in its capabilities): its strings turned off where they fell quiet, its part cut 3 s after its last action`);
    if(!capabilities.body)compiled.warnings.push(`${entry.seat}: the strings' driver has no body of its own (none in its capabilities: an older build than the engine's): heard as Artifastring's bodies, uncorrected, with their offset`);
    if(!capabilities.ramps)compiled.warnings.push(`${entry.seat}: the strings' driver has no ramps (none in its capabilities): each change its actions ask to move over a span (transitions.js) made at once, a step`);
    for(const line of String(driven.said??'').split('\n'))if(/rung down/.test(line))compiled.warnings.push(`${entry.seat}: ${line.trim()}`);
    // (What the model said it left out: NESS's, physical-strings.mjs renderParts.)
    for(const said of driven.warnings??[])compiled.warnings.push(`${entry.seat}: ${said}`);
    // (Its sound at its instrument's one scale (gainOf), every stroke alike.)
    const {rate,broken,brokenAt}=driven,samples=Float32Array.from(driven.samples,x=>x*outputScale);
    const tail=samples.subarray(Math.max(0,samples.length-Math.round(END_SECONDS*rate))).reduce((most,v)=>Math.max(most,Math.abs(v)),0);
    if(tail>=SMALLEST_STEP)compiled.warnings.push(`${entry.seat}: its part ends at ${(20*Math.log10(tail)).toFixed(1)} dBFS, over a 24-bit file's smallest step (cut off)`);
    if(broken)compiled.warnings.push(`${entry.seat}: the model could not compute ${broken} samples from ${brokenAt.toFixed(3)} s, silenced`);
    // (Where the driver caught the model running away and went on from a fresh instrument: a time a restart.)
    if(driven.recovered?.length)compiled.warnings.push(`${entry.seat}: the model ran away and was started again at ${driven.recovered.map(at=>`${at.toFixed(3)} s`).join(', ')} (a moment silent)`);
    return {leads,compiled,samples,rate,outputScale,extra:driven.extra??{},heard:strokeArrivals(samples,rate,entry.log,compiled.kinds,leads)};
  };
  // (Its tries, each from the leads its last ones heard; the one most nearly on time kept.)
  const tries=[await render(entry.log.map(()=>0))];
  while(tries.length<STRINGS_ANTICIPATION.tries&&offTime(tries.at(-1).heard)>0)tries.push(await render(nextStrokeLeads(entry.log,tries[0].compiled.kinds,tries)));
  return {kept:tries.reduce((best,t)=>offTime(t.heard)<offTime(best.heard)?t:best),tries};
}
