// A woodwind part's breath groups for OpenWInD (openwind_worker.py), each simulated whole on its keyed body, its fingers
// changing under the breath (the owner, 9 October 2026: "continuous breath while fingering changes, with the possibility
// of breath continuous adjustment to facilitate the changes of pitch"): the groups and their breath's shape from the
// shared breath module (breath.mjs), the same as the brass's (ness.mjs), told to the worker, which tunes each note on the
// body and fills each shape with each note's own pressure, embouchure and fingering.
//   - share: the breath as shares of each note's tuned pressure, [[s, share]] from the group's origin -- its attack, its
//     swells, a tongued note's air stopped and let go (a reed's held behind the tongue on its reed: `tongues`, where the
//     worker shuts its reed), its release (passageBreath with every pressure 1); the worker multiplies it by each note's
//     own, moved across each change (across).
//   - levels: each note's level as its dynamic is measured on its instrument (sound-power.js stemLevelDb, its stem's
//     RMS, dBFS), for a player holding each note at it by ear (openwind_compiled.py Ear, where its reed's law hears);
//     null where its instrument is not measured. And `edges`: its level at its scored range's edge where it lies beyond
//     it (ppp's under, fff's over), its own within -- the step its mark lies beyond, for its player to play by
//     (openwind_passages.py ear_of).
//   - its vibrato in the breath: a woodwind's vibrato is its breath's (its diaphragm's and throat's), so a note's vibrato
//     curve (its seat's, vibrato.js: the cents it would bend, its arc through the phrase) moves its breath by
//     VIBRATO_SHARE a cent -- the pitch and level it then sways by its instrument's own answer to its breath.
import {ANTICIPATION,ARRIVAL,breathGroups,passageBreath} from './breath.mjs';
import {noteHzAt} from './pitch.mjs';
import {WOODWIND_TONGUES} from './physical.mjs';
import {stemLevelDb} from '../../../public/shared/performers/sound-power.js';
import {DYNAMIC_VELOCITY} from '../../../public/shared/dynamics.js';

// (A breath vibrato's depth, a share of the breath a cent of the curve: a flute's 15 cents, 6 % of its breath -- the
// middle of the 3 to 10 % players' breath vibrato moves the jet by (ours, after Fletcher's and Cottier's flutes); the
// curve's samples a second.)
export const VIBRATO_SHARE=.004,VIBRATO_RATE=200;

// A part's passages: [{notes (indices into part.notes), origin (s), share: [[s, share]], changes: [{to, at, seconds}],
// entries, end, onsets, firstRisen, anticipation, arrival}], each from its first note's onset (the worker begins its
// breath earlier where its tone takes longer to speak, and each change earlier where its note is heard late: breath.mjs
// anticipation, ANTICIPATION and ARRIVAL told it).
export function woodwindPassages(part){
  const all=part.notes;
  return breathGroups(all).map(group=>{
    const notes=group.notes.map(k=>all[k]),origin=notes[0].startSeconds;
    const breath=passageBreath(notes,{origin,pressures:notes.map(()=>1),hz:notes.map(n=>noteHzAt(n,n.startSeconds)),tongue:WOODWIND_TONGUES[part.physical?.model]??'air'});
    const share=withVibrato(breath.pressure,notes,origin);
    const levels=notes.map(n=>stemLevelDb(part.physical?.model,n.velocity,69+12*Math.log2(n.baseHz/440)));
    const edges=notes.map(n=>stemLevelDb(part.physical?.model,Math.max(DYNAMIC_VELOCITY.ppp,Math.min(DYNAMIC_VELOCITY.fff,n.velocity)),69+12*Math.log2(n.baseHz/440)));
    return {notes:group.notes,origin,share,changes:breath.changes,entries:breath.entries,end:breath.end,onsets:breath.onsets,firstRisen:breath.firstRisen,levels,edges,
      ...(breath.tongues?{tongues:breath.tongues}:{}),anticipation:ANTICIPATION,arrival:ARRIVAL};
  });
}

// The breath with each note's vibrato in it: within each note's span its share times 1 + VIBRATO_SHARE times its curve's
// cents, sampled VIBRATO_RATE times a second, never rounded (a rounded sample a step: breath.mjs passageBreath).
function withVibrato(points,notes,origin){
  const curved=notes.filter(n=>n.breathVibrato?.length);
  if(!curved.length)return points;
  const at=t=>{if(t<=points[0][0])return points[0][1];for(let i=1;i<points.length;i++)if(t<=points[i][0]){const [a,x]=points[i-1],[b,y]=points[i];return x+(y-x)*(t-a)/((b-a)||1)}return points.at(-1)[1]};
  const centsAt=(curve,t)=>{if(t<=curve[0].seconds)return curve[0].cents;for(let i=1;i<curve.length;i++)if(t<=curve[i].seconds){const a=curve[i-1],b=curve[i];return a.cents+(b.cents-a.cents)*(t-a.seconds)/((b.seconds-a.seconds)||1)}return curve.at(-1).cents};
  const times=new Set(points.map(([t])=>t));
  for(const n of curved)for(let t=n.startSeconds;t<=n.endSeconds;t+=1/VIBRATO_RATE)times.add(+(t-origin).toFixed(6));
  return [...times].sort((a,b)=>a-b).map(t=>{
    const n=curved.find(each=>t+origin>=each.startSeconds&&t+origin<=each.endSeconds);
    const v=at(t)*(n?1+VIBRATO_SHARE*centsAt(n.breathVibrato,t+origin):1);
    return [t,Math.max(0,v)];
  });
}
