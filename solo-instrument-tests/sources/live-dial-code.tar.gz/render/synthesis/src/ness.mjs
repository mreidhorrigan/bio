// NESS's brass as a physical model, offline (the Edinburgh Acoustics and Audio Group's NESS framework, MIT: its brass a
// lip reed on a bore of its own profile, with valves: doc/BrassInfo.md). Each note a simulation of its own, its bore
// scaled to tune it (as a valve or a slide lengthens one: the player's fixed-length tube a constraint broken, every pitch
// reachable, as the strings' tension is retuned) and its lips' frequency set to lock the partial it plays, both measured
// (calibration below); then the player's technique in its breath -- a hum or a growl as NESS's mouth-pressure tremolo at
// the voice's pitch (with breath noise for a growl), a flutter as the tremolo at the tongue's roll -- and a mute in its
// bore: the bell's end narrowed to the gap a straight or cup mute's corks leave. NESS normalizes each output to its peak,
// so its mouth pressure shapes its timbre and the note's velocity its level, after. A 1D bore cannot hold a mute's own
// cavity: its resonance is not in this model, and said so.
// (Its planning alone, here, which a page shares: its simulations run by the `simulate` it is given -- NESS's binary in
// Node, ness-process.mjs; NESS in WebAssembly in the studio page, public/studio/engines/brass-worker.js.)
import KAUSEL_BORES from '../geometry/brass-bores-kausel-2021.json' with {type:'json'};
import GRID_MOUTHPIECES from '../ness-grid-mouthpieces.json' with {type:'json'};
import TUBA_BORE from '../ness-tuba-bore.json' with {type:'json'};
import HORN_BORE from '../ness-horn-bore.json' with {type:'json'};
import FITTED_BRASS from '../fitted-brass-players.json' with {type:'json'};
import CHARTS from '../../../public/shared/performers/brass-standard-fingerings.json' with {type:'json'};
import {noteHzAt} from './pitch.mjs';
import {A4,SEMITONES_PER_OCTAVE} from '../../../public/shared/pitch-course.js';
import {playersBreath} from './brass-breath.mjs';
import {BREATH,ANTICIPATION,ARRIVAL,probeBreath,speakingDb,breathGroups,passageBreath,boundLeads,anticipation,nextLead} from './breath.mjs';
import {transitionSeconds,eased,bump,ramp,rampBreakpoints,RAMP_POINTS} from '../../../public/shared/performers/transitions.js';

// A bore measured point by point ([[x, diameter]] mm from the mouthpiece's plane), as NESS takes it: from its first
// measured place, and a step (two diameters measured at one place, a joint) a hundredth of a millimetre long, each place
// past the one before. -> [[x, diameter]].
function measuredBore(points){
  const [x0]=points[0],out=[];
  for(const [x,d] of points){const at=Math.max(x-x0,out.length?out.at(-1)[0]+.01:0);out.push([+at.toFixed(2),d])}
  return out;
}
const KAUSEL_2021=KAUSEL_BORES.instruments;
// A bore with a tuning slide drawn: `ratio` times as long, the tube added just before `at` (mm), of the bore's diameter
// there, and all from `at` on moved along by it. -> [[x, diameter]].
function drawnOut(bore,ratio,at){
  const add=(ratio-1)*bore.at(-1)[0];if(!(add>0))return bore;
  const k=bore.findIndex(([x])=>x>at),[x0,d0]=bore[k-1],[x1,d1]=bore[k],d=d0+(d1-d0)*(at-x0)/((x1-x0)||1);
  return [...bore.slice(0,k).filter(([x])=>x<at),[at,+d.toFixed(4)],[+(at+add).toFixed(2),+d.toFixed(4)],...bore.slice(k).map(([x,dd])=>[+(x+add).toFixed(2),dd])];
}
// (The trumpet's valves' places on its bore as measured, and its tuning slide's draw: NESS_BRASS.trumpet.)
const TRUMPET_VALVES=[600,630,660],TRUMPET_DRAWN=1.03404,TRUMPET_ADDED=(TRUMPET_DRAWN-1)*KAUSEL_2021.trumpet.length;
// Each brass instrument: its bore (mm), its valves' tubes (default and bypass lengths, mm, at their positions), its lips
// (NESS's lip parameters: area Sr m^2, mass mu kg, damping sigma, rest opening H m, width w m; or, as a player's
// embouchure changes with register, a list of [lip frequency Hz, lips] interpolated by lipsAt), its mouth pressure from
// softest to loudest (Pa), and its mutes. The trumpet's bore is a B-flat trumpet's measured whole with its mouthpiece, its
// lips the documented template's; the trombone's a pBone's measured whole with its mouthpiece, its lips fitted to
// trombonists' (both Kausel, Mayer & Beauchamp 2021, geometry/brass-bores-kausel-2021.json); the tuba's an Alexander CC's
// as measured, its bell another Alexander's, its mouthpiece a maker's rim and throat (ness-tuba-bore.json); the horn's a
// measured horn's, its crook drawn in to sound F, its bell to another horn's measured rim, its mouthpiece a maker's rim,
// throat and cup (ness-horn-bore.json). The horn's and tuba's lips the template's scaled to each one's mouthpiece, to be
// fitted (tools/fit_lips.py fit).
// A mute: `annulus` (a straight or cup mute's corks, or a stopping hand, leaving a ring `gap` wide round `cork`'s
// diameter), or `harmon` (its cork sealing the bell at `cork`; its chamber [diameter, length]; its exit -- the open
// hole, stem out, or the stem's tube and its little bell, stem in -- [diameter, length] each). Dimensions ours, from
// common mutes', to be replaced by measured ones.
// Which lips a model with measured ones plays (MUSEBOTS_NESS_LIPS; in a browser, its deployed), where its part does not
// say (its physical `lips`: lipsChoiceOf): its deployed `lips`, or `measured`, its `measuredLips` and their own
// calibration (NESS_CALIBRATION_FILES) -- so that lips measured but not yet ready to play are kept and worked on, never
// played unasked.
export const NESS_LIPS=globalThis.process?.env?.MUSEBOTS_NESS_LIPS||'deployed';
if(!['deployed','measured'].includes(NESS_LIPS))throw new Error(`MUSEBOTS_NESS_LIPS: ${NESS_LIPS} (deployed or measured)`);
// Which of a trombone's slurs across its slide are legato-tongued (MUSEBOTS_SLIDE_SLURS; in a browser, its deployed):
// 'tongued', every one, the renderer's rule as deployed; or 'played', those its player tongues (its note's portato:
// wind-seat.js, the score's tenuto under the slur), the others slurred under the breath, the slide's glide heard -- a
// slur need not be tongued (the owner, 25 October 2026). Deployed once the trombone's slurs hold on it.
export const SLIDE_SLURS=globalThis.process?.env?.MUSEBOTS_SLIDE_SLURS||'tongued';
if(!['tongued','played'].includes(SLIDE_SLURS))throw new Error(`MUSEBOTS_SLIDE_SLURS: ${SLIDE_SLURS} (tongued or played)`);
// How a brass player's breath is blown by its law (MUSEBOTS_BRASS_BREATH; in a browser, its deployed): 'range', its
// instrument's mouth pressure from softest to loudest by its velocity alone, at every pitch, as deployed; or 'players',
// as brass players were measured to blow each note at each dynamic, rising with its pitch (brass-breath.mjs) -- kept
// apart until the scoreboard hears it play no worse (research/MODEL_REFACTOR_PLAN.md).
export const BRASS_BREATH=globalThis.process?.env?.MUSEBOTS_BRASS_BREATH||'range';
if(!['range','players'].includes(BRASS_BREATH))throw new Error(`MUSEBOTS_BRASS_BREATH: ${BRASS_BREATH} (range or players)`);
// A note's mouth pressure (Pa) by its player's law, at `hz` and `velocity`, on `model`'s `instrument` (BRASS's entry):
// its adopted player's where it has one (fittedBreath), else as BRASS_BREATH says.
export function breathOf(model,instrument,hz,velocity){
  const v=Math.max(0,Math.min(1,velocity??.6)),fitted=FITTED_BRASS[model];
  if(fitted)return fittedBreath(fitted,hz,v);
  if(BRASS_BREATH==='players')return playersBreath(hz,v);
  const [softest,loudest]=instrument.pressure;return softest+(loudest-softest)*v;
}
// A note's breath by an adopted player's law (render/synthesis/fitted-brass-players.json: tools/brass_player.py's,
// adopted by tools/brass_adopt.py where the scoreboard hears it no worse): its register's place at its velocity -- read
// between the law's dynamics by velocity, held beyond them -- in its note's window of breath, log-spaced from its
// threshold (0) to where it leaves its partial or its players' most (1); a pitch between two notes mapped, their windows
// read between in its pitch's logarithm and its register the nearer's; past the notes mapped, the nearest's. Never under
// a note's threshold nor past its partial: feasible by construction.
export function fittedBreath(law,hz,velocity){
  const midi=A4.note+SEMITONES_PER_OCTAVE*Math.log2(hz/A4.hz),rows=law.windows,above=rows.findIndex(r=>r.midi>=midi);
  const [a,b]=above<0?[rows.at(-1),rows.at(-1)]:above===0?[rows[0],rows[0]]:[rows[above-1],rows[above]];
  const t=b.midi>a.midi?(midi-a.midi)/(b.midi-a.midi):0,read=key=>Math.exp(Math.log(a[key])+t*Math.log(b[key]/a[key]));
  const register=law.registers[String(t<1-t?a.midi:b.midi)],marks=law.dynamics.map(d=>law.velocities[d]);
  // (Between the two marks about its velocity -- the first two below them, the last two above.)
  const pairs=marks.slice(1).map((m,j)=>[j,m]),[k]=pairs.find(([,m])=>velocity<=m)??pairs.at(-1)??[0];
  const place=!pairs.length?law.values[`place.${law.dynamics[0]}.${register}`]:(()=>{
    const s=Math.max(0,Math.min(1,(velocity-marks[k])/(marks[k+1]-marks[k])));
    return (1-s)*law.values[`place.${law.dynamics[k]}.${register}`]+s*law.values[`place.${law.dynamics[k+1]}.${register}`]})();
  const least=read('least'),most=read('most');
  return Math.exp(Math.log(least)+place*Math.log(most/least));
}
const BRASS=Object.freeze({
  trumpet:Object.freeze({
    source:'measured: a B-flat trumpet whole, valves open, with its mouthpiece, 338 points (W. Kausel, A. Mayer & J. W. Beauchamp 2021, JASA 149(4) 2698, doi:10.1121/10.0004303, supplement, CC BY 4.0), its main tuning slide drawn',
    // (measuredGeometry: kausel-2021-trumpet -- geometry/measured.json's id, test/measured-bodies.test.mjs reading it.
    // NESS's documented measured bore before it put its third and fourth resonances 62 and 88 cents over B-flat 2's
    // partials, its sixth 26 under -- an instrument no tuning slide puts in tune, which its lips' locks played 63 to 134
    // cents sharp (G4 on its 1st valve, its charted fingerings locking nowhere near); this one's lie 7 to 36 over
    // (research/BRASS_LIPS_FIT_PLAN.md, 25 October).)
    // (Its main tuning slide drawn as its player draws it: `drawn` times its length as measured, the tube added before its
    // valves, of the bore's diameter there, its valves moved along by it -- found from
    // its bore alone, its players over each resonance as measured -- trombonists' 1.1%, none of trumpeters' -- its open
    // B-flat 3, F4, B-flat 4, F5 and B-flat 5 (a trumpeter's measured, brass-lips-targets.json) in tune on average at
    // 1.03404, -21 to +17 cents (tools/fit_lips.py tuning, 31 October 2026). A setting of the instrument, so part of its
    // bore: every note of it then on its bore as drawn, its valves' and its calibration's.)
    drawn:TRUMPET_DRAWN,
    bore:Object.freeze(drawnOut(measuredBore(KAUSEL_2021.trumpet.bore),TRUMPET_DRAWN,TRUMPET_VALVES[0]).map(Object.freeze)),
    reach:2**(6/12),
    // (Its valves' tubes lowering its partials a tone, a semitone and three semitones as NESS sounds this bore: 130.2,
    // 43.9 and 221.4 mm added, within a cent of each (scripts/size-ness-valves.mjs --open, its open sweep's 11 strong
    // locks, 31 October 2026; on NESS's documented bore they had been 149, 53 and 245 mm). Sized as
    // a trumpet's slides are from its length as its open partials space it (1.45 m: 177, 86 and 274 mm), they had lowered
    // them 238, 140 and 336 cents; NESS's documented example's (111, 38 and 180 mm) had left a C-sharp 4 near no fingering
    // at all, its lips and half-valves bending every fingering the rest: Op. 3.35's render stopped there.)
    // (Its valves' places NESS's documented example's, within this trumpet's measured cylinder (some 280 to 800 mm from
    // its rim): its valve slides unmeasured, its list its open path.)
    valves:Object.freeze({position:Object.freeze(TRUMPET_VALVES.map(x=>+(x+TRUMPET_ADDED).toFixed(2))),short:Object.freeze([20,20,20]),bypass:Object.freeze([150.2,63.9,241.4])}),
    lips:Object.freeze({Sr:1.46e-5,mu:5.37e-5,sigma:10,H:.00029,w:.01}),
    // (Its mouth pressure from the softest note to the loudest, Pa: the documented examples' 1.8 to 4 kPa, a little wider.)
    pressure:Object.freeze([1500,6000]),
    mutes:Object.freeze({straight:Object.freeze({kind:'annulus',cork:45,gap:3}),cup:Object.freeze({kind:'annulus',cork:50,gap:6}),
      'harmon-stem-out':Object.freeze({kind:'harmon',cork:52,chamber:[95,85],exit:[22,12]}),
      'harmon-stem-in':Object.freeze({kind:'harmon',cork:52,chamber:[95,85],exit:[12,60],bell:[34,14]})}),
  }),
  trombone:Object.freeze({
    source:'measured: a pBone tenor trombone whole, slide in, with its mouthpiece, 479 points (W. Kausel, A. Mayer & J. W. Beauchamp 2021, JASA 149(4) 2698, doi:10.1121/10.0004303, supplement, CC BY 4.0)',
    // (measuredGeometry: kausel-2021-pbone -- its mouthpiece, mouthpipe, slide and bell, geometry/measured.json's id.)
    bore:Object.freeze(measuredBore(KAUSEL_2021.trombone.bore).map(Object.freeze)),
    reach:2**(6/12),
    // (Its main tuning slide drawn as its player draws it, its seven positions counted from there as a trombone's are: a
    // player's setting, found from its bore alone (tools/fit_lips.py tuning) -- measured trombonists play 1.1% over each
    // resonance of their bore (H. Boutin, N. Fletcher, J. Smith & J. Wolfe 2015, JASA 137(3) 1195, doi:10.1121/1.4908236;
    // render/synthesis/brass-lips-targets.json), and so played, its first position's B-flat 2 to F4 are in tune on
    // average with its bore 1.01889 times as long as measured (OpenWInD's resonances; its partials then -39 to +25 cents).)
    tuningSlide:1.01889,
    // (Its slide: the second leg of its inner slides, 968.5 to 1655.8 mm along its bore at first position, a cylinder of
    // 13.99 mm as measured, stretched as the slide moves out -- the length the slide adds, a cylinder of the slide's own
    // bore -- NESS built with the slide patch (scripts/build-ness.mjs). The owner, 10 October 2026: "A trombone has a
    // slide. It is absolutely imperative that the slide is therefore correctly simulated"; "The trombone must be able to
    // perform continuous glissando using the slide". On the designed bore before it, held out 170, 400 and 700 mm, its
    // partial fell 96, 218 and 368 cents, its added length alone 95, 217 and 363.)
    slide:Object.freeze([968.51,1655.84]),
    valves:Object.freeze({position:Object.freeze([1800]),short:Object.freeze([20]),bypass:Object.freeze([850])}),
    // (Its lips by register, fitted through their physics to what was measured of trombonists in their mouths and
    // mouthpieces (tools/fit_lips.py fit, render/synthesis/lips-fits/trombone.json; its targets brass-lips-targets.json:
    // Boutin et al. 2015's B-flat 2 and F4, Campbell et al. 2021's F4) -- each set at the lips its note is played at
    // normally, interpolated between. Its harmonic and flows met within their spreads; B-flat 2 plays 2.7% over its
    // resonance and F4 on it, where players play 1.1% over, and B-flat 2's steady flow lies 23% outside its measured range:
    // NESS's one-mass lips, at Q 81 where players' are damped to 1.2-1.8. From the template's
    // {Sr:2.9e-5,mu:1.1e-4,sigma:8,H:.00042,w:.015}.)
    lips:Object.freeze([Object.freeze([89.415,Object.freeze({Sr:3.139e-5,mu:1.174e-4,sigma:6.901,H:.0004074,w:.01278})]),
      Object.freeze([305.164,Object.freeze({Sr:2.719e-5,mu:1.684e-4,sigma:8.611,H:.0002574,w:.01183})])]),
    // (Its lips as measured, two modes -- played where MUSEBOTS_NESS_LIPS=measured (NESS_LIPS), with their own calibration
    // (NESS_CALIBRATION_FILES.measured); not yet by default: its legato phrase's first slur breaks where the slide begins
    // to move, 13 dB for some 15 ms (research/MODELING_GAPS.md, "A slurred trombone's tone breaks on its measured lips"),
    // and its notes 73-77 are unheld (its lips above F4 unmeasured). Fitted (tools/fit_lips.py fit --second,
    // lips-fits/trombone.json) to the same targets and to Newton, Campbell & Gilbert 2008's measured lips: the outward
    // resonance under the note at Q 1.2-1.8, an inward one above it -- its inward mode played by NESS's inward-lips patch
    // (inwardOf). Reached by continuation from the one-mass fit, which went no nearer the measured damping than 0.86 of
    // the way: the outward lips at Q 1.46 and 1.53 and B-flat 2's at 75.99 Hz (measured 76.5), the inward at 148.2 Hz
    // (Newton's ratio: 148.7); B-flat 2 1.4% over its resonance (players 1.1%), its harmonic within 0.6 dB and F4's 0.8,
    // F4's threshold 4% over its measured one; NESS holds B-flat 2 and F4 at the players' pressures within 1.8 and 3.6
    // cents of the balance (research/BRASS_LIPS_FIT_PLAN.md Status).)
    measuredLips:Object.freeze([Object.freeze([75.986,Object.freeze({Sr:3.522e-5,mu:8.95e-5,sigma:326.2,H:.0004878,w:.013,inwardRatio:1.951,inwardQ:1.613,inwardCoupling:1.314})]),
      Object.freeze([302.242,Object.freeze({Sr:3.806e-5,mu:9.776e-5,sigma:1238,H:.000172,w:.01198,inwardRatio:1.482,inwardQ:1.798,inwardCoupling:1.27})])]),
    pressure:Object.freeze([1000,5000]),
    mutes:Object.freeze({straight:Object.freeze({kind:'annulus',cork:78,gap:4}),cup:Object.freeze({kind:'annulus',cork:84,gap:8}),
      'harmon-stem-out':Object.freeze({kind:'harmon',cork:86,chamber:[150,130],exit:[30,15]}),
      'harmon-stem-in':Object.freeze({kind:'harmon',cork:86,chamber:[150,130],exit:[16,85],bell:[48,20]})}),
  }),
  horn:Object.freeze({
    source:'measured: a French horn by pulse reflectometry to 53.7 mm across (Kemp 2002, Fig. 7.9), a crooked horn sounding in D, its cylinder drawn in along its axis to sound F (0.764 of its length); its bell from there to Koehler\'s measured rim (MIMEd 14586) as a Bessel horn; its mouthpiece GW\'s FH-2\'s rim, throat and cup, its throat\'s and whole length designed (ness-horn-bore.json, tools/horn_measured_bore.py)',
    // (measuredGeometry: kemp-2002-horn, measuredGeometry: koehler-1856-horn-bell and
    // measuredGeometry: gw-horn-mouthpieces -- geometry/measured.json's ids. Its designed bore, an F horn of 11.9 mm bore
    // and a 305 mm bell from published typical dimensions, played till 31 October 2026.)
    bore:Object.freeze(HORN_BORE.bore.map(Object.freeze)),
    reach:2**(6/12),
    // (Its valves in its measured cylinder (720 to 2859 mm from its rim, ness-horn-bore.json parts), where they stood on
    // the designed horn; sized there to lower its partials a tone, a semitone and three semitones as NESS sounds them
    // (142, 351 and 605 mm added) -- sized by their lengths alone (430, 200 and 680 mm), they had lowered them 245, 141 and
    // 337 cents -- and to be sized again on this bore (scripts/size-ness-valves.mjs).)
    valves:Object.freeze({position:Object.freeze([1500,1530,1560]),short:Object.freeze([20,20,20]),bypass:Object.freeze([371,162,625])}),
    lips:Object.freeze({Sr:1.2e-5,mu:4.6e-5,sigma:10,H:.00026,w:.009}),
    pressure:Object.freeze([1200,5500]),
    mutes:Object.freeze({straight:Object.freeze({kind:'annulus',cork:92,gap:5}),
      // (Stopped: the right hand closing the bell where it is some 95 mm wide, a gap of 2.5 mm left: + on the page.)
      stopped:Object.freeze({kind:'annulus',cork:95,gap:2.5})}),
  }),
  tuba:Object.freeze({
    source:'measured: an Alexander tuba in 16-ft C from its mouthpipe to 95 mm across (Campbell, Gilbert & Myers 2021, Fig. 7.46), another Alexander tuba\'s bell from there to 270 mm (Fig. 6.9), its flare\'s length fitted to sound C; its mouthpiece a maker\'s rim and throat (Werden: Bach 18), its cup\'s depth and backbore designed (ness-tuba-bore.json, tools/tuba_measured_bore.py)',
    // (measuredGeometry: campbell-2021-alexander-cc, measuredGeometry: campbell-2021-alexander-tuba-bell and
    // measuredGeometry: werden-tuba -- geometry/measured.json's ids. Its designed bore, a CC of 19 mm bore and a 430 mm
    // bell from published typical dimensions, played till 31 October 2026, its measured one waiting on its lips: on the
    // template's lips scaled to the designed mouthpiece its fingerings' sweeps at middle breath had held 9 % of its compass
    // where they held 78 % on the designed, its legato test's slurred notes held by none of its fingerings (24 October
    // 2026, claude-scratch/ness-tuba-measured/). A measured body is never put back for that (CLAUDE.md, "A conflict with
    // a measurement is the model's problem"): its lips are fitted to it (tools/fit_lips.py fit tuba).)
    bore:Object.freeze(TUBA_BORE.bore.map(Object.freeze)),
    reach:2**(10/12),
    // (Its valves in its measured cylinder (some 820 to 1230 mm from its rim, 20.2 mm), a tone, a semitone, three
    // semitones and a fourth as NESS sounds them on this bore, its mouthpiece fitted to NESS's grid
    // (ness-grid-mouthpieces.json): the first three sized on its open sweep of 31 October 2026 (scripts/size-ness-valves.mjs
    // --open: 554.7, 236.3 and 895.3 mm added, each within 1.1 cents of its interval; its second had been 249.4, sized
    // before its mouthpiece was fitted, 24 October); its fourth as sized then, 1583.1 mm added; each combination's locks
    // measured as NESS sounds it in its calibration (scripts/calibrate-ness-brass.mjs), which its fingerings are found from.)
    valves:Object.freeze({position:Object.freeze([840,880,920,960]),short:Object.freeze([25,25,25,25]),bypass:Object.freeze([579.7,261.3,920.3,1608.1])}),
    // (Its lips by register, as a player's embouchure changes: the template's scaled to its mouthpiece up to lips of 145 Hz,
    // the template's own from 160 -- the scaled lips drift and lock weakly in its upper middle register (F3 wandering over
    // a note, a muted A-flat 3 falling silent), the template's lock it in steady plateaus but do not speak below 150, and
    // a set halfway between speaks in neither; both speak at 150, where it changes.)
    lips:Object.freeze([Object.freeze([145,Object.freeze({Sr:5.6e-5,mu:2.6e-4,sigma:6,H:.00055,w:.026})]),
      Object.freeze([160,Object.freeze({Sr:1.46e-5,mu:5.37e-5,sigma:5,H:.00029,w:.01})])]),
    pressure:Object.freeze([600,3500]),
    mutes:Object.freeze({straight:Object.freeze({kind:'annulus',cork:150,gap:6})}),
  }),
});
// (Each model as it is played: with MUSEBOTS_NESS_LIPS=measured, its measured lips where it has them.)
export const NESS_BRASS=Object.freeze(Object.fromEntries(Object.entries(BRASS).map(([model,spec])=>
  [model,NESS_LIPS==='measured'&&spec.measuredLips?Object.freeze({...spec,lips:spec.measuredLips}):spec])));
// Each model's calibration's file in render/synthesis/: its deployed lips' (ness-brass-calibration.json), or with
// MUSEBOTS_NESS_LIPS=measured, a model with measured lips its measured lips' (ness-brass-calibration.measured-lips.json,
// its entry read over the deployed file's, its calibrators writing it there).
export const NESS_CALIBRATION_FILES=Object.freeze({deployed:'ness-brass-calibration.json',measured:'ness-brass-calibration.measured-lips.json'});
export const calibrationNameOf=model=>NESS_LIPS==='measured'&&BRASS[model]?.measuredLips?NESS_CALIBRATION_FILES.measured:NESS_CALIBRATION_FILES.deployed;
// The lips a part plays: those it asks for (its physical `lips`, 'deployed' or 'measured': a studio's choice of model,
// public/studio/band.js), else MUSEBOTS_NESS_LIPS's -- measured lips asked for by name refused where a model has none.
// -> 'deployed' or 'measured', the key of its calibration (NESS_CALIBRATION_FILES) as of its lips (brassOf).
export function lipsChoiceOf(model,asked){
  if(asked!==undefined&&!['deployed','measured'].includes(asked))throw new Error(`NESS ${model}: lips ${asked} (deployed or measured)`);
  if(asked==='measured'&&!BRASS[model]?.measuredLips)throw new Error(`NESS ${model}: its lips are not measured (ness.mjs measuredLips)`);
  return (asked??NESS_LIPS)==='measured'&&BRASS[model]?.measuredLips?'measured':'deployed';
}
export const brassOf=(model,choice)=>choice==='measured'?Object.freeze({...BRASS[model],lips:BRASS[model].measuredLips}):BRASS[model];
// What a brass calibration measured: the instrument as NESS is given it -- its bore at the renders' rate (its mouthpiece
// at NESS's grid's points), under `mute`, its lips, its valves -- as a 64-bit FNV-1a hash, written beside each sweep
// (scripts/calibrate-ness-brass.mjs) and checked as a part is rendered: a calibration measured on an instrument since
// changed plays with a warning, never refused (the trumpet's, horn's and tuba's had stood two weeks on bores NESS no
// longer sampled so: MODELING_GAPS.md).
// (FNV-1a's 64-bit offset basis and prime, and the rate its bore is sampled at, the renders'.)
const STAMP=Object.freeze({offset:0xcbf29ce484222325n,prime:0x100000001b3n,bits:64n,digits:16,rate:48000});
export function instrumentStamp(model,instrument=BRASS[model],{mute=null}={}){
  const text=JSON.stringify({bore:nessBore(model,{sampleRate:STAMP.rate,mute}),lips:instrument.lips,valves:instrument.valves??null}),mask=(1n<<STAMP.bits)-1n;
  let h=STAMP.offset;for(let i=0;i<text.length;i++){h^=BigInt(text.charCodeAt(i));h=(h*STAMP.prime)&mask}
  return h.toString(16).padStart(STAMP.digits,'0');
}
// How far a note's bore may be scaled from the instrument's: as its valves or slide lengthen it, as far as they reach
// (its own `reach`: six semitones for three valves or a slide's seventh position, ten for a tuba's four valves, from
// where its tuning slide is drawn: `tuningSlide`, the ratio its player lengthens its bore by to put it in tune); and,
// above the highest partial its lips lock to, shortened as far as a piccolo trumpet is, by half -- the player's one
// instrument a constraint broken, every pitch reachable (CLAUDE.md, microtones first-class). The scale aimed for: the
// valves' middle, the geometric middle of its reach.
export const SCALE=Object.freeze({least:.5,most:1.34,aim:1.16});
export const reachOf=model=>{const most=(NESS_BRASS[model]?.reach??SCALE.most)*(NESS_BRASS[model]?.tuningSlide??1);return {least:SCALE.least,most,aim:Math.sqrt(most)}};
// An instrument's slide where NESS is built to move one (its backend's build: scripts/build-ness.mjs), else null: [from,
// to] mm along its bore. A note's slide out by its scale: (scale - 1) of its bore's length, mm (never in past first position).
export const slideOf=(model,backend)=>NESS_BRASS[model]?.slide&&backend?.build?.capabilities?.includes('slide')?NESS_BRASS[model].slide:null;
export const slideOut=(model,scale)=>Math.max(0,(scale-1)*NESS_BRASS[model].bore.at(-1)[0]);

// The bore a note plays on: the instrument's scaled by `scale`, and, muted, its bell's end narrowed from where its
// diameter reaches the mute's corks to the gap's equivalent opening (an annulus `gap` wide round the cork's diameter:
// its area as a circle's). -> [[x, diameter]] mm.
// Where a place on an instrument's bore lies once its whole is `scale` times as long: lengthened as its valves or slide
// lengthen it, by tubing of the bore's own diameter where they are (its first valve's place), its mouthpiece, leadpipe
// and bell as they were; shortened, above the partials its lips lock to, its length past its mouthpiece's throat (the
// bore's first narrowest place, where it begins to widen again) shortened alike. (Its whole had been scaled, its mouthpiece's cup and its bell with it: a horn lengthened a quarter for
// its low D-sharp, its cup a quarter deeper, held no tone.) -> {at: x -> x', inserted: [from, length] | null}.
export function lengthened(model,scale=1){
  const {bore,valves}=NESS_BRASS[model],total=bore.at(-1)[0];
  if(scale>=1){const at=valves.position[0],add=(scale-1)*total;return {at:x=>x<=at?x:x+add,inserted:add>0?[at,add]:null}}
  const throat=bore[bore.findIndex(([,d],i)=>i+1<bore.length&&bore[i+1][1]>d)][0],k=(scale*total-throat)/(total-throat);
  return {at:x=>x<=throat?x:throat+(x-throat)*k,inserted:null};
}
// Where its valves sit on a note's bore: lengthened, each where `lengthened` moves it; shortened, its valve block as it
// is, its first valve where `lengthened` moves it and the rest their own distances after it, as a piccolo trumpet's block
// is a B-flat's. (Drawn in alike, the sections between its valves fell under one of NESS's steps, which NESS cannot
// build: the trumpet's and horn's 10 mm under a scale of 0.905 at 48 kHz, the tuba's 15 under 0.804.) -> [x] mm.
export function valvesAt(model,scale=1){
  const {position}=NESS_BRASS[model].valves,{at}=lengthened(model,scale);
  return scale>=1?position.map(at):position.map(x=>at(position[0])+x-position[0]);
}
const diameterAt=(bore,x)=>{const k=bore.findIndex(([at])=>at>=x);if(k<=0)return bore[Math.max(0,k)][1];const [x0,d0]=bore[k-1],[x1,d1]=bore[k];return d0+(d1-d0)*(x-x0)/((x1-x0)||1)};
export function boreOf(model,{scale=1,mute=null}={}){
  const instrument=NESS_BRASS[model],{at:moved,inserted}=lengthened(model,scale);
  let bore=instrument.bore.map(([x,d])=>[moved(x),d]);
  if(inserted){const [from,length]=inserted,d=diameterAt(instrument.bore,from),k=bore.findIndex(([x])=>x>from);
    bore=[...bore.slice(0,k),[from,d],[from+length,d],...bore.slice(k)].filter((p,i,all)=>!i||p[0]>all[i-1][0])}
  if(!mute)return bore;
  const fitted=instrument.mutes[mute]??(()=>{throw new RangeError(`${model} has no ${mute} mute (${Object.keys(instrument.mutes).join(', ')})`)})();
  const at=bore.findIndex(([,d])=>d>=fitted.cork);if(at<1)return bore;
  const [x0,d0]=bore[at-1],[x1,d1]=bore[at],x=x0+(x1-x0)*(fitted.cork-d0)/(d1-d0),inside=[...bore.slice(0,at),[x,fitted.cork]];
  if(fitted.kind==='annulus'){const opening=2*Math.sqrt(fitted.cork*fitted.gap);return [...inside,[x+.5,opening],[bore.at(-1)[0],opening]]}
  // (A harmon: sealed at its cork, the sound through its chamber and out of its exit -- the open hole, or the stem and
  // its little bell: its own resonances, the 1D bore holding them.)
  const [chamber,deep]=fitted.chamber,[exit,neck]=fitted.exit,steps=[[8,chamber],[deep,chamber],[8,exit],[neck,exit],...(fitted.bell?[[fitted.bell[1],fitted.bell[0]]]:[])];
  let along=x;return [...inside,...steps.map(([length,diameter])=>[along+=length,diameter])];
}
// NESS's grid samples a bore every c/FS (BrassInstrument.cpp init: its step the sound's travel in one sample, 7.15 mm at
// 48 kHz), coarser than a mouthpiece's cup and throat: at 48 kHz its grid played the trumpet's resonances 7 to 44 cents
// flat, the trombone's, horn's and tuba's up to 7, its time stepping adding at most 1.4 -- why its locks rose with its
// rate (tools/ness_grid_impedance.py; research/BRASS_LIPS_FIT_PLAN.md). Each instrument's mouthpiece as NESS is given it
// at a rate: radii at its grid's own points through its throat and a cell more, fitted so that the grid plays the
// measured bore's resonances and troughs within a cent (ness-grid-mouthpieces.json); the bore after as measured. For
// NESS alone: the balance, OpenWInD and the scores take the bore itself (boreOf). Its valves and slide lengthen the bore
// past the mouthpiece and its mutes narrow the bell, so one fit serves every note; shortened (scale under 1) the bore
// past its throat is drawn in, which the fit, made on it unshortened, leaves out. Its end at its grid's last point too
// (nessEnded). -> [[x, diameter]] mm.
export function nessBore(model,{sampleRate,...options}={}){
  const bore=boreOf(model,options);
  if(!sampleRate)return bore;
  const fitted=GRID_MOUTHPIECES[model]?.[String(sampleRate)],through=fitted?fitted.points.at(-1)[0]:-Infinity;
  return [...(fitted?.points??[]),...nessEnded(bore.filter(([x])=>x>through+NESS_WRITTEN),sampleRate)];
}
// NESS's air at the temperature its instrument files give it, its sound's speed so in mm/s, as its bores are given, and
// so its grid's step, its radii sampled at so many points a step (BrassInstrument.cpp init: every h/2); and the finest
// place a bore is written to, mm (matrix: toFixed(6)).
const NESS_TEMPERATURE=20,NESS_C=347.23e3*(1+.00166*(NESS_TEMPERATURE-26.85)),NESS_STEP_POINTS=2,NESS_WRITTEN=1e-6;
// A bore as NESS is given it at a rate, its end's diameter at its grid's last point too, its length kept: NESS samples a
// bore's radii every h/2 from the rim, and its bell radiates, and its last node holds, the radius at the last of them --
// up to h/2 short of the end, where a bell flares most. On Kausel's trumpet at 48 kHz, 3.3 mm short, the rim's radius
// taken there 4% under the rim's, its grid had played its troughs up to 4.8 cents flat however its mouthpiece was
// fitted; given its rim there, 0.9 (tools/ness_grid_impedance.py ended, which the fits take). Floored to the place
// matrix writes, so that NESS's last point lies on the end's diameter. A mute's end alike. -> [[x, diameter]] mm.
export function nessEnded(bore,sampleRate){
  const half=NESS_C/sampleRate/NESS_STEP_POINTS,[end,d]=bore.at(-1),last=Math.floor(Math.floor(end/half)*half/NESS_WRITTEN)*NESS_WRITTEN;
  if(end-last<NESS_WRITTEN)return bore;
  return [...bore.filter(([x])=>x<last-NESS_WRITTEN),[last,d],[end,d]];
}
// (Each matrix on one line: NESS 0.1.1's instrument parser reads nothing of a matrix written over several lines, though
// BrassInfo.md shows one so -- found when its own measured-bore example rendered nothing.)
const matrix=rows=>`[${rows.map(row=>row.map(v=>+Number(v).toFixed(6)).join(',')).join(';')}]`;
// (A lips value over time, [[s, value], ...], each value to nine significant figures: a note's score writes its lips in
// full, and six decimal places had moved a trumpet's area Sr, 1.46e-5, to 1.5e-5 in every passage (2.7 %; its mass
// 0.56 %, the trombone's fitted lips up to 1.2 %) -- the passages playing lips their calibration never measured.)
const lipsMatrix=rows=>`[${rows.map(([t,...values])=>[+Number(t).toFixed(6),...values.map(v=>+Number(v).toPrecision(9))].join(',')).join(';')}]`;
// A tuning's next scale from its tries so far ([{scale, error (cents)}]): where two lie either side of the pitch, by the
// line through the nearest of each (false position, the pitch bracketed); else by the secant through the last two -- where
// the lips, not the bore, hold the pitch (a tuba's high notes: lengthened 1.5 %, its pitch rose 15 cents), the bore's rule
// would walk away from it -- and at first as a bore's frequency goes, as one over its length. Its step at most half an octave's.
const BORE_SLOPE=-1200/Math.LN2,MOST_STEP=600*Math.LN2/1200;
// (Above its partials the lips lead: a brass model's measured runs past its highest lock sound within some 2 % of their
// lips -- a tuba's lips at 343 Hz sound 350, a trumpet's at 1306 sound 1303 -- the pitch rising with the lips.)
const LIP_SLOPE=1200/Math.LN2;
// (The locks a note tries, nearest the valves' middle first.)
const LOCKS_TRIED=3,QUARTER_TONE=50;
// (How far a note may lie from the nearest measured note it starts from, cents.)
const FROM_NOTES_CENTS=150;
// (By when a tone speaks in time, s: a player's note within its first tenths -- the model's lips, at their documented
// pressures, take three of them on a trombone's open middle register. A later one is begun early, by at most MOST_AHEAD.)
const SPEAKS_BY=.35,MOST_AHEAD=1;
// (A pitch between two measured notes where neither's breath holds it: their breath and lips a little either side, as
// [breath, lips] shares, as a player finds a note's slot. A tuba's E3 and F3 hold only at 4.5 kPa exactly; the F3 a fifth
// of a semitone flat held at neither's, and at 0.9 of their breath, and at 1.25 of it with lips 3 % slower.)
const NEAR_HOLDING=Object.freeze([[.9,1],[1.1,1],[.8,1],[1.25,1],[1,.97],[1,1.03],[1.25,.97],[.9,.97]]);
// (The valved brass, tuned on their own valves by their players' actions (tuneFingered); the trombone by its slide, its
// bore's length (tune), as a player's slide does.)
export const FINGERED=new Set(['trumpet','horn','tuba']);
// (Its lips' reach as shares of the frequency its fingering's partial locks at, and how far a share moves its pitch at
// first, cents: a trumpet's Bb4 on 1-3 moved 17 cents from 0.97 to 1.06, leaving its partial below 0.94; a secant's tries.)
const LIPS_REACH=Object.freeze([.88,1.12]),LIP_CENTS=200,LIP_TRIES=6,LIP_STEP=.04;
// (A step's change of pitch past this, cents, a change of regime; a fingering's first tone this far off, another partial.)
const LEAP_CENTS=60,WRONG_PARTIAL=150;
// (Fingerings tried a note, nearest first.)
const FINGERINGS_TRIED=6;
// (The breaths a fingered note is tried at, as multiples of its dynamic's, where none speaks at it: a player's support --
// after, where its dynamic's is a tenth or more away from it, the middle of its instrument's breath, where its locks were
// measured (scripts/calibrate-ness-brass.mjs: a ff horn note's lock at G3 held no tone at 5.1 kPa on any fingering, its
// breath only ever raised from there, and the note was left out of Op. 3.35, 10 October 2026).)
const SUPPORTED=Object.freeze([1,1.5,2]);
const breathsOf=(instrument,pressure)=>{
  const middle=(instrument.pressure[0]+instrument.pressure[1])/2;
  return [pressure,...(Math.abs(middle/pressure-1)>=.1?[middle]:[]),...SUPPORTED.slice(1).map(k=>pressure*k)];
};
// A fingering's valves' added length, mm: each pressed valve its bypass less its own short tube, a half-pressed one its share.
const addedBy=(model,fingering)=>NESS_BRASS[model].valves.bypass.reduce((sum,bypass,k)=>sum+(+(fingering[k]??0))*(bypass-NESS_BRASS[model].valves.short[k]),0);
// The cents valve `v` pressed all the way (or let up) moves a fingering's pitch: as the length it adds (a tube's
// frequency as one over its length).
export function fingeringCents(model,fingering,v){
  const total=NESS_BRASS[model].bore.at(-1)[0],other=fingering.map((on,k)=>k===v?!on:on);
  return Math.abs(1200*Math.log2((total+addedBy(model,other))/(total+addedBy(model,fingering))));
}
// Each brass instrument's standard fingerings as its players' charts give them (brass-standard-fingerings.json): for
// each written note, [standard, ...alternates]. Hard empirical data (the owner, 23 October 2026: "Standard fingerings,
// where standard, are hard empirical data").
const STEPS={C:0,D:2,E:4,F:5,G:7,A:9,B:11};
export const midiOfName=name=>{const [,letter,sharp,octave]=/^([A-G])(#?)(-?\d+)$/.exec(name);return 12*(+octave+1)+STEPS[letter]+(sharp?1:0)};
// A pitch's fingerings as its instrument's chart gives them, for the written note nearest it: [standard, ...alternates],
// valve keys from the first ('110'), a slide's positions (1 in, 7 out) -- none where its chart gives none.
export function chartedFingerings(model,target){
  const chart=CHARTS[model],table=chart?.notes??chart?.positions;if(!table)return [];
  const written=Math.round(69+12*Math.log2(target/440))-chart.sounds;
  return Object.entries(table).find(([name])=>midiOfName(name)===written)?.[1]??[];
}
// The position a slide is at, its bore `scale` times first position's: a semitone a position.
export const positionOf=scale=>1+Math.round(12*Math.log2(scale));
// A slide's choices of partial for a pitch ([{lock, scale}]) its chart gives, in its chart's order: for each position,
// the partial it lowers to the pitch -- the lock nearest the pitch that many semitones up, within a semitone -- its slide
// then placed where that partial plays the pitch in tune, as a player's is ("for an advanced player, the slide placement
// is adjusted for each of the natural notes", Campbell, Gilbert & Myers 2021, 1.2.5): the pBone's 6th partial 36 cents
// sharp, a mute's partials moved off the open bell's.
export function chartedChoices(model,target,choices){
  const out=[];
  for(const position of chartedFingerings(model,target)){
    const hz=target*2**((position-1)/12),c=choices.reduce((a,b)=>!a||Math.abs(Math.log(b.lock.played/hz))<Math.abs(Math.log(a.lock.played/hz))?b:a,null);
    if(c&&Math.abs(1200*Math.log2(c.lock.played/hz))<100&&!out.includes(c))out.push(c);
  }
  return out;
}
// Those choices with its chart's first, in its chart's order, the rest as they were: the pBone's G4 and F#4 had been held
// in 4th and 5th position on its 8th partial, nearer its slide's middle, where its players' chart gives 2nd and 3rd on its
// 7th, which NESS holds as firmly.
export function chartedFirst(model,target,choices){
  const charted=chartedChoices(model,target,choices);
  return [...charted,...choices.filter(c=>!charted.includes(c))];
}
// A pitch's fingerings on a valved instrument: its chart's first, in its chart's order, each on the partial of it nearest
// the pitch -- never another put before them for sounding nearer (a trumpet's concert G4 and D4 had been played on its
// third valve alone, 8 cents a valve preferring it to the 1-2 its players' chart gives: the third valve "tuned ... slightly
// more than three semitones" and avoided on its own, Campbell, Gilbert & Myers 2021, 1.2.5) -- then the rest, nearest
// first: each partial its lips lock to on each combination of its valves -- as that combination was measured to sound
// (`fingered`: the calibration's, scripts/calibrate-ness-brass.mjs --fingering), else the open instrument's locks
// (`locks`) lowered as the length its valves add would lower them (an estimate: a muted instrument's) -- `cents` it lies
// from `target` (sharp positive), `lip` its lips' frequency there; within the nearer reach, each valve more a little
// further.
export function fingeringCandidates(model,locks,target,fingered=null){
  const {valves}=NESS_BRASS[model],total=NESS_BRASS[model].bore.at(-1)[0],n=valves.position.length;
  const combos=Array.from({length:2**n},(_,m)=>valves.position.map((x,k)=>Boolean(m>>k&1)));
  const all=combos.flatMap(fingering=>{
    const key=fingering.map(Number).join(''),measured=fingering.some(Boolean)?fingered?.[key]?.locks:null;
    if(measured)return measured.map(lock=>({lock,fingering,lip:lock.lip,cents:1200*Math.log2(lock.played/target),measured:true}));
    const ratio=total/(total+addedBy(model,fingering));
    return locks.map(lock=>({lock,fingering,lip:lock.lip*ratio,cents:1200*Math.log2(lock.played*ratio/target)}));
  })
    .filter(c=>Math.abs(c.cents)<CANDIDATE_CENTS[1]).sort((a,b)=>Math.abs(a.cents)+8*a.fingering.filter(Boolean).length-Math.abs(b.cents)-8*b.fingering.filter(Boolean).length);
  const charted=chartedFingerings(model,target).map(key=>all.find(c=>c.fingering.map(Number).join('')===key)).filter(Boolean);
  // (Those within the nearer reach, else as many as FINGERINGS_TRIED from the wider: a player reaches further with its
  // lips before giving a pitch up.)
  const rest=all.filter(c=>!charted.includes(c));
  return [...charted.map(c=>({...c,charted:true})),
    ...rest.filter((c,k)=>Math.abs(c.cents)<CANDIDATE_CENTS[0]||rest.filter(d=>Math.abs(d.cents)<CANDIDATE_CENTS[0]).length+k<FINGERINGS_TRIED*2)];
}
// Where a lock's lips play `target` (Hz), by its sweep as calibrated (`runs`: [{lip, played, periodicity}], each lip setting
// the pitch it played at the instrument's middle breath; scaled by `ratio`, a fingering's own estimated from the open
// bore's): its held runs within its lips -- its first and last left out, each a regime's edge, and those as periodic as
// scripts/brass-model-pitches.mjs holds them -- read as a curve, the lip where it plays the pitch; beyond them, its
// nearest end's. A valved player's lips placed by the map its playing has made, no probe (the law: renderNessBrass).
// -> a lip frequency (Hz).
export function sweptLip(runs,lock,target,ratio=1){
  const held=(runs??[]).filter(r=>r.played&&r.lip>=lock.lips[0]&&r.lip<=lock.lips[1]).slice(1,-1).filter(r=>r.periodicity>=SWEEP_PERIODIC)
    .map(r=>[r.lip*ratio,r.played*ratio]).sort((a,b)=>a[0]-b[0]);
  // (A curve of two runs at least: its lock's own lip where it has fewer.)
  if(!held[1])return lock.lip*ratio;
  const at=Math.log(target),points=held.map(([lip,played])=>[lip,Math.log(played)]);
  const k=points.findIndex(([,p],i)=>i>0&&(points[i-1][1]-at)*(p-at)<=0);
  if(k>0){const [l0,p0]=points[k-1],[l1,p1]=points[k];return p1===p0?l0:l0+(l1-l0)*(at-p0)/(p1-p0)}
  return Math.abs(points[0][1]-at)<Math.abs(points.at(-1)[1]-at)?points[0][0]:points.at(-1)[0];
}
const SWEEP_PERIODIC=.95;
// (A fingering's estimated pitch within the first of these of a note, cents, a candidate; within the second, where too few are.)
const CANDIDATE_CENTS=[70,160];
// (A player's lips learned over a note: the times, s from its onset, their tension is set at; how many tries; from when it
// is heard and from when all of it must be within the tolerance; how much of each error a try corrects. A soft note's
// attack takes a quarter of a second to centre on the model as a player's may -- a trumpet's quiet F#5 was 73 cents off
// from 0.15 to 0.3 s, held within a cent after -- where a note begun on its neighbouring plateau is still there past it.)
const LEARN_TRIES=5,LEARN_FROM=.1,LEARN_SETTLED=.25,LEARN_HELD=.35,LEARN_GAIN=.8,ATTACK_CENTS=15;
export const learnKnots=seconds=>[0,.1,.2,.3,.45,.6,.8,1,1.25,1.5,1.8,2.2,2.7].filter(t=>t<seconds).concat([seconds]);
// A tone's pitch over time, cents from `target`: [[t (s, the window's middle), cents | null]], a window of `window` s
// every `step` from `from` to `to`.
export function pitchTrack(audio,sampleRate,{from,to,target,step=.1,window=.12}){
  const out=[];
  for(let t=from;t+window<=to+1e-9;t+=step){const found=fundamentalOf(audio,sampleRate,{from:Math.round(t*sampleRate),to:Math.round((t+window)*sampleRate),low:target/1.6,high:target*1.6});
    out.push([+(t+window/2).toFixed(4),found?1200*Math.log2(found.hz/target):null])}
  return out;
}
// How far its lips move a fingering's pitch, cents per unit of their ratio, from its tries ([{lipRatio, errorCents}]): the
// steepest pair's slope a held tone gave, else LIP_CENTS; never under a tenth of it.
export function sensitivityOf(tries){
  let slope=null;
  for(let i=0;i<tries.length;i++)for(let j=i+1;j<tries.length;j++){const a=tries[i],b=tries[j],d=b.lipRatio-a.lipRatio;
    if(Math.abs(d)>1e-4&&Math.abs(b.errorCents-a.errorCents)<LEAP_CENTS){const s=(b.errorCents-a.errorCents)/d;if(s>0&&(slope===null||s<slope))slope=s}}
  return Math.max(LIP_CENTS/10,slope??LIP_CENTS);
}
// A lip curve's factors corrected by a pitch track: each knot from LEARN_FROM its own root found over the tries -- its
// history ([[factor, cents heard there]], `histories`, kept by the caller) bracketed once its errors cross, else a secant
// on its last two where their slope is a lip's (positive, under LEAP_CENTS a hundredth), else a step at `slope` -- each
// step at most LIP_STEP, all within LIPS_REACH; a reading further than QUARTER_TONE*2 off (another partial, a misread
// octave) not heard; the knots before LEARN_FROM as the first. (A fixed gain oscillated: a trumpet's F#4 moved 330 to 580
// cents a unit of its lips once speaking, its plateau's tries 110.)
export function learnedFactors(knots,factors,track,{slope,histories=knots.map(()=>[]),from=LEARN_FROM}){
  const heard=track.filter(([,e])=>e!=null&&Math.abs(e)<=QUARTER_TONE*2);if(!heard.length)return factors;
  const at=t=>{if(t<=heard[0][0])return heard[0][1];for(let i=1;i<heard.length;i++)if(t<=heard[i][0]){const [a,x]=heard[i-1],[b,y]=heard[i];return x+(y-x)*(t-a)/(b-a)}return heard.at(-1)[1]};
  const next=knots.map((t,i)=>{
    if(t<from)return null;
    const f=factors[i],e=at(t),h=histories[i];h.push([f,e]);
    const above=h.filter(([,x])=>x>0).sort((a,b)=>a[1]-b[1])[0],below=h.filter(([,x])=>x<0).sort((a,b)=>b[1]-a[1])[0];
    let to;
    if(above&&below&&above[0]!==below[0])to=below[0]-below[1]*(above[0]-below[0])/(above[1]-below[1]);
    else if(h.length>1){const [[f0,e0],[f1,e1]]=h.slice(-2),k=f1!==f0?(e1-e0)/(f1-f0):0;to=k>0&&k<LEAP_CENTS*100?f1-e1/k:f*(1-LEARN_GAIN*e/slope)}
    else to=f*(1-LEARN_GAIN*e/slope);
    return Math.max(LIPS_REACH[0],Math.min(LIPS_REACH[1],f*Math.max(1-LIP_STEP,Math.min(1+LIP_STEP,to/f))));
  });
  const first=next.find(f=>f!==null)??factors[0];
  return next.map(f=>f??first);
}
// (A run its lips may start from: a steady tone.)
const LIPS_PERIODIC=.9;
// A probe's held tone: its pitch in a window from 0.6 s and in its last 0.4 s, the same within STEADY_CENTS (a muted tuba drifting 5 cents over a note is not held), and its
// level there within FADING_DB of the first's -- a tone dying away keeps its pitch, a horn's low A-flat, steady, fell
// 14 dB in half a second; its pitch their geometric middle -- and speaking, its tone BREATH.speaksDb over its breath's
// thump (breath.mjs speakingDb: the tuba's B2, its lips 6 % off their lock, held its pitch hardly moving, and boomed).
// And pure: its pitch in windows of five of its periods (40 ms at least) through the held part within WAVERS of each
// other -- two pitches beating in it, a trumpet's note bent 7 % off its lock warbled 30 cents either side sixteen times
// a second, its long windows' pitches the same (the owner, of Op. 3.35: "steady notes frequently have the warbling
// quality of multiphonics"). -> {hz, periodicity, drift (cents), fall (dB), speaking (dB), spread (cents)}, or null where
// it is not held so (it dies, fades, wanders, warbles or barely speaks).
export const PROBE_SECONDS=1.4;const STEADY_CENTS=2,FADING_DB=6;
// (The breaths a lock is tried at where its tone does not hold, as multiples of the note's own, softer and harder in
// turn -- a tuba's low register holds only at a soft breath; never past twice the instrument's loudest.)
const HARDER=Object.freeze([1,.6,1.5,.4,2.2]);
const rmsDb=(x,from,to)=>{let sum=0;for(let i=from;i<to;i++)sum+=x[i]*x[i];return 10*Math.log10(sum/Math.max(1,to-from)+1e-20)};
export function heldTone(audio,sampleRate,seconds){
  const a=[Math.round(.6*sampleRate),Math.round(1*sampleRate)],b=[Math.round((seconds-.4)*sampleRate),Math.round(seconds*sampleRate)];
  const early=fundamentalOf(audio,sampleRate,{from:a[0],to:a[1]}),late=fundamentalOf(audio,sampleRate,{from:b[0],to:b[1]});
  if(!early||!late)return null;
  const drift=1200*Math.log2(late.hz/early.hz),fall=rmsDb(audio,...a)-rmsDb(audio,...b),hz=Math.sqrt(early.hz*late.hz),speaking=speakingDb(audio,sampleRate,seconds,{hz});
  if(!(Math.abs(drift)<=STEADY_CENTS&&fall<=FADING_DB&&speaking>=BREATH.speaksDb))return null;
  // (Pure: its short windows' pitches near its own, half of them heard at least, within WAVERS of each other.)
  const width=Math.max(.04,5/hz),seen=[];let windows=0;
  for(let t=.6;t+width<=seconds;t+=width/2){windows++;const f=fundamentalOf(audio,sampleRate,{from:Math.round(t*sampleRate),to:Math.round((t+width)*sampleRate),low:hz/1.3,high:hz*1.3});if(f)seen.push(1200*Math.log2(f.hz/hz))}
  const spread=seen.length?Math.max(...seen)-Math.min(...seen):Infinity;
  return seen.length>=windows/2&&spread<=WAVERS?{hz,periodicity:Math.min(early.periodicity,late.periodicity),drift,fall,speaking,spread:+spread.toFixed(1)}:null;
}
// When a probe's tone speaks (s): the start of the first tenth of a second, in twentieths, that sounds a periodic tone
// within a quarter tone of its settled pitch `hz`; null where none does.
export function speaksAt(audio,sampleRate,hz,seconds){
  for(let t=0;t+.1<=seconds;t+=.05){
    const found=fundamentalOf(audio,sampleRate,{from:Math.round(t*sampleRate),to:Math.round((t+.1)*sampleRate)});
    if(found&&Math.abs(1200*Math.log2(found.hz/hz))<=QUARTER_TONE)return +t.toFixed(2);
  }
  return null;
}
export function nextScale(tries,{slope:first=BORE_SLOPE}={}){
  const last=tries.at(-1),above=tries.filter(t=>t.error>0),below=tries.filter(t=>t.error<0),bracketed=above.length&&below.length;
  const [a,b]=bracketed?[above.reduce((x,y)=>y.error<x.error?y:x),below.reduce((x,y)=>y.error>x.error?y:x)]:tries.length>1?tries.slice(-2):[null,null];
  const moved=a?Math.log(b.scale/a.scale):0,secant=a&&Math.abs(moved)>1e-9&&Math.abs(b.error-a.error)>.01?(b.error-a.error)/moved:null;
  const slope=secant!==null&&Math.abs(secant)>1?secant:first,from=bracketed?b:last;
  return from.scale*Math.exp(Math.max(-MOST_STEP,Math.min(MOST_STEP,-from.error/slope)));
}
// Its sound brought to the render's scale by one number an instrument, measured once (scripts/calibrate-ness-output.mjs:
// its held notes' bell pressure at ff against its measured sound power there, sound-power.js), the same for every note --
// never a note's own gain, its loudness its player's breath and its instrument's answer to it (the owner, 10 October
// 2026: "Gain is never per-note"; "You cannot use gain in ANY circumstances to compensate for behaviour of the
// instrument"). A model not yet measured is refused, never sounded at a guess. -> its gain (linear).
export function outputGainOf(model,calibration){
  const db=calibration?.[model]?.outputGainDb;
  if(!Number.isFinite(db))throw new Error(`NESS's ${model}: its output's scale is not measured (node scripts/calibrate-ness-output.mjs --model ${model})`);
  return 10**(db/20);
}
// An instrument's lips at a lip frequency: its one set, or, given by register, interpolated geometrically in log
// frequency between the two sets round it (each parameter alike; the nearer end's past either).
export function lipsAt(lips,hz){
  if(!Array.isArray(lips))return lips;
  const sorted=[...lips].sort((a,b)=>a[0]-b[0]);
  if(!(hz>sorted[0][0]))return sorted[0][1];
  if(hz>=sorted.at(-1)[0])return sorted.at(-1)[1];
  const k=sorted.findIndex(([f])=>f>hz),[f0,a]=sorted[k-1],[f1,b]=sorted[k],t=Math.log(hz/f0)/Math.log(f1/f0);
  return Object.fromEntries(Object.keys(a).map(key=>[key,+(a[key]*(b[key]/a[key])**t).toPrecision(6)]));
}
// The lips' inward mode in NESS's terms (scripts/build-ness.mjs, its inward-lips patch), where a lips set carries one
// (tools/fit_lips.py --second: Newton, Campbell & Gilbert 2008's inward-striking resonance above the note): its resonance
// inwardRatio times the lip frequency `lipHz`, its damping by its Q, its area the outward mass's, its mass the outward's
// over its coupling. -> {inward_frequency, inward_sigma, inward_Sr, inward_mu} or null
export function inwardOf(set,lipHz){
  if(!(set?.inwardRatio>0))return null;
  const hz=set.inwardRatio*lipHz;
  return {inward_frequency:hz,inward_sigma:2*Math.PI*hz/set.inwardQ,inward_Sr:set.Sr,inward_mu:set.mu/set.inwardCoupling};
}
const INWARD=['inward_frequency','inward_sigma','inward_Sr','inward_mu'];
// Refused where a model's lips have an inward mode and `backend` is a NESS not built to play one (its build's
// capabilities: scripts/build-ness.mjs): such a NESS reads no inward arrays and would play the outward mass alone, unsaid.
export function playableLips(model,backend,lips=NESS_BRASS[model]?.lips){
  const sets=Array.isArray(lips)?lips.map(([,set])=>set):[lips];
  if(sets.some(set=>set?.inwardRatio)&&!backend?.build?.capabilities?.includes('inward-lips'))
    throw new Error(`NESS ${model}: its lips have an inward mode, which this NESS is not built to play (scripts/build-ness.mjs, its inward-lips patch)`);
}
// NESS's instrument and score files (BrassInfo.md's formats) for one note. `lip` (Hz) constant, or following its pitch
// curve (`curve`: [[seconds, ratio]]); its mouth `pressure` (Pa) shaped by its `breath` ([[seconds, share]]: breath.mjs,
// a player's; else the probe's, risen over BREATH.probeRise -- never the step of a millisecond NESS's examples use, its
// thump the tuba's booms); its technique's tremolo and noise. Fingered (`fingering`: each valve pressed, true, or not),
// a valve given as a share (0 to 1) pressed that far -- a half-valve, the air shared between its tubes, as a player bends
// a pitch between two fingerings with its lips --, its valves' slides drawn out by `slides` (mm each: a trumpet's
// triggers); its embouchure (`embouchure`: shares of its
// lips' own aperture H, area Sr, mass mu, as its player sets them to a note) -- the player's actions a note is tuned by.
// `lipsBy`: lips by register ([[lip Hz, {Sr, mu, sigma, H, w}], ...]) in place of the instrument's own -- a fit's, heard
// before it is adopted (tools/brass_engines.py --fit).
export function nessFiles(model,{sampleRate,scale,mute=null,lip,curve=null,pressure,seconds,tail,breath=null,technique={},fingering=null,slides=null,embouchure=null,slide=null,buzz=null,lipsBy=null}){
  const instrument=NESS_BRASS[model],{valves}=instrument,set=lipsAt(lipsBy??instrument.lips,lip),lips={...set,...Object.fromEntries(Object.entries(embouchure??{}).filter(([key])=>key in set).map(([key,share])=>[key,set[key]*share]))};
  // (Its slide out, where it has one and NESS moves it: its bore as given, its slide region stretched by its scale.)
  const slid=slide&&scale>=1,bore=slid?1:scale;
  // (Each file begun with a comment: NESS 0.1.1 renders nothing, silently, from a file whose first line is not one.)
  const instrumentFile=[`% Musebots: ${model}, NESS brass instrument`,`custominstrument=0;`,`FS=${sampleRate};`,`temperature=${NESS_TEMPERATURE};`,
    `vpos=[${valvesAt(model,bore).map(x=>+x.toFixed(3)).join(',')}];`,`vdl=[${valves.short.map(x=>+x.toFixed(3)).join(',')}];`,
    `vbl=[${valves.bypass.map((x,k)=>+(x+(slides?.[k]??0)).toFixed(3)).join(',')}];`,`bore=${matrix(nessBore(model,{scale:bore,mute,sampleRate}))};`,
    ...(slid?[`slide=[${slide.join(',')}];`]:[])].join('\n')+'\n';
  const blown=(breath??probeBreath(seconds)).map(([t,share])=>[t,share*pressure]),T=Math.max(seconds+tail,blown.at(-1)[0]+.02);
  const voiced=technique.growl??technique.hum,flutter=technique.flutter;
  const tremolo=voiced?[voiced.level,voiced.hz]:flutter?[flutter.depth,flutter.hz]:[0,0];
  // (Its attack buzzed at `buzz` (Hz, its pitch), as a passage's attacks are (BUZZ): its tone tuned as it will begin --
  // driven from its start, under its breath's rise, let go as a technique is (tremoloRows).)
  const trem=tremoloRows(buzz?[{at:0,depth:BUZZ.depth,hz:buzz},{at:BUZZ.hold,align:'start',seconds:BUZZ.seconds-BUZZ.hold,depth:tremolo[0],hz:tremolo[1]}]:[{at:0,depth:tremolo[0],hz:tremolo[1]}]);
  const lipRows=curve?.length?curve.map(([t,ratio])=>[t,lip*ratio]):[[0,lip]];
  const scoreFile=[`% Musebots: ${model}, NESS brass score`,`maxout=0.95;`,`T=${+T.toFixed(6)};`,`Sr=[0,${lips.Sr}];`,`mu=[0,${lips.mu}];`,`sigma=[0,${lips.sigma}];`,`H=[0,${lips.H}];`,`w=[0,${lips.w}];`,
    `lip_frequency=${matrix(lipRows)};`,`pressure=${matrix(blown)};`,
    ...(inwardOf(lips,lip)?INWARD.map(key=>`${key}=${lipsMatrix(lipRows.map(([t,hz])=>[t,inwardOf(lips,hz)[key]]))};`):[]),
    `vibamp=[0,0];`,`vibfreq=[0,5];`,`tremamp=${matrix(trem.depth)};`,`tremfreq=${matrix(trem.hz)};`,`noiseamp=[0,${technique.growl?+(.3*technique.growl.rough).toFixed(4):0}];`,
    `valveopening=[0,${valves.position.map((x,k)=>{const pressed=fingering?.[k];return typeof pressed==='number'?+(1-Math.max(0,Math.min(1,pressed))).toFixed(4):pressed?0:1}).join(',')}];`,`valvevibfreq=[0,${valves.position.map(()=>0).join(',')}];`,`valvevibamp=[0,${valves.position.map(()=>0).join(',')}];`,...(slid?[`slide=[0,${+slideOut(model,scale).toFixed(3)};${+T.toFixed(6)},${+slideOut(model,scale).toFixed(3)}];`]:[])].join('\n')+'\n';
  return {instrumentFile,scoreFile};
}

// A tone's fundamental (Hz) over its steady part: its normalized difference function's first dip under a threshold
// (YIN's), independent of the pitch asked; null where nothing periodic is found. `periodicity` 1 less that dip.
const DIP=Object.freeze({weak:.05,deeper:4});
export function fundamentalOf(samples,rate,{from=0,to=samples.length,low=40,high=2000}={}){
  const x=samples.subarray(Math.max(0,from),Math.min(samples.length,to)),most=Math.floor(rate/low),least=Math.max(2,Math.floor(rate/high));
  if(x.length<most*3)return null;
  const n=x.length-most,d=new Float64Array(most+1);
  for(let tau=1;tau<=most;tau++){let sum=0;for(let i=0;i<n;i++){const v=x[i]-x[i+tau];sum+=v*v}d[tau]=sum}
  let running=0;const cmnd=new Float64Array(most+1);cmnd[0]=1;
  for(let tau=1;tau<=most;tau++){running+=d[tau];cmnd[tau]=running>0?d[tau]*tau/running:1}
  let tau=-1;for(let t=least;t<most;t++)if(cmnd[t]<.15){while(t+1<most&&cmnd[t+1]<cmnd[t])t++;tau=t;break}
  if(tau<0)return null;
  // (A weak first dip given up for the first one DEEPER times deeper after it: a note whose fifth harmonic stands over
  // its fundamental -- a violin's B4, its body raising its fifth 9 dB over its first -- dips first at four fifths of its
  // period, its correlation 0.88 there against 0.997 at its period, and was heard a major third high, its held note
  // "warbling" 388 cents, 11 October 2026. A clean period's first dip is near nothing, under WEAK, and kept -- never its
  // octave below.)
  if(cmnd[tau]>DIP.weak)for(let t=tau+1;t<most;t++)if(cmnd[t]<cmnd[tau]/DIP.deeper){while(t+1<most&&cmnd[t+1]<cmnd[t])t++;tau=t;break}
  const a=cmnd[tau-1],b=cmnd[tau],c=cmnd[tau+1],bend=a-2*b+c,exact=tau+(bend?.5*(a-c)/bend:0);
  return {hz:rate/exact,periodicity:1-b};
}

// When a note is heard to arrive in a breath group's audio (`audio` from `from` s, in the group's time; `on` its onset,
// `held` its held part, `prevHz` and `prevOn` the note's before), as breath.mjs ARRIVAL says. -> s after its onset (late,
// else early), null where it is not heard to arrive. (openwind_passages.py arrival_of, the same.)
export function arrivalOf(audio,rate,{from=0,hz,prevHz=null,on,prevOn=null,held:[ha,hb]}){
  const S=t=>Math.max(0,Math.min(audio.length,Math.round((t-from)*rate)));
  const db=(a,b)=>{let e=0;for(let i=a;i<b;i++)e+=audio[i]*audio[i];return b>a?10*Math.log10(e/(b-a)+1e-24):-Infinity};
  const level=db(S(ha),S(hb));if(!(hb-ha>=.02)||!Number.isFinite(level))return null;
  const cents=(a,b)=>1200*Math.log2(a/b),apart=prevHz?Math.abs(cents(hz,prevHz)):Infinity;
  const start=Math.max(from,prevOn!=null?prevOn+.03:-Infinity,on-ARRIVAL.before),stop=on+ARRIVAL.after;
  if(apart<ARRIVAL.repeat){
    let low=Infinity,lowAt=null;for(let t=on-.08;t<on+.08;t+=ARRIVAL.step){const v=db(S(t),S(t+.01));if(v<low){low=v;lowAt=t}}
    if(lowAt==null||level-low<ARRIVAL.dip)return null;
    for(let t=lowAt;t<stop;t+=ARRIVAL.step)if(db(S(t),S(t+.01))>level-ARRIVAL.back)return t+.005-on;
    return null;
  }
  const low=hz/1.3,width=Math.max(.03,3.05/low),near=Math.min(ARRIVAL.cents,apart/2);
  let absent=false,run=0;
  for(let t=start;t<stop;t+=ARRIVAL.step){
    const f=fundamentalOf(audio,rate,{from:S(t),to:S(t+width),low,high:hz*1.3});
    if(!(f&&Math.abs(cents(f.hz,hz))<near&&db(S(t),S(t+width))>level-ARRIVAL.db)){absent=true;run=0;continue}
    if(absent&&++run===ARRIVAL.frames)return t-(ARRIVAL.frames-1)*ARRIVAL.step+width/2-on;
  }
  return null;
}

// When a part's player is free to begin a note's breath (s): the latest end of its notes begun before it, 0 for its
// first.
export const freedAt=(notes,note)=>notes.reduce((latest,other)=>other!==note&&other.startSeconds<note.startSeconds?Math.max(latest,other.endSeconds):latest,0);

// Whether a part is played with searches for its notes' tunings -- each note probed until its pitch is within the
// tolerance, each breath group played again until its notes are, re-fingered, re-tongued -- as a development measure of
// how far its player's law is from them: never in playback or the tests (the owner, 26 October 2026: the renders' per-note
// tuning search "shouldn't be happening at actual playback or testing"), MUSEBOTS_TUNING_SEARCH=1 alone asking. Without
// it, every note by its player's law and each breath group played once, its gaps heard and registered
// (research/MODELING_GAPS.md: Tuning; Silent and unsteady notes).
export const tuningSearch=()=>globalThis.process?.env?.MUSEBOTS_TUNING_SEARCH==='1';

// A part on NESS's brass. Its notes by its player's law (tuningSearch none): each on its chart's fingering (or a slide's
// charted position) on the measured partial nearest the pitch, its lips at that partial's lock, blown as its dynamic asks,
// each breath group played once. A development measure asking: each tuned to within `pitchToleranceCents` (strict) by a
// measured lock (the calibration's: a lip frequency and the partial it sounds on the unscaled bore), its bore scaled and
// measured again until it sounds there; a pitch near one tuned, blown as hard, reuses its scale. -> a stem {samples, sampleRate, channels, originSeconds, diagnostics}.
// `simulate(files, {signal, name})` -> its raw output (a Float32Array of the bell's pressure): one NESS run of a note's or a
// passage's files, `name` its job's (ness-process.mjs nessProcess, or a page's engine); `keepRaw`, its sound before its one
// scale kept beside it. `calibrations`: each lips' calibration, {deployed, measured} (the files NESS_CALIBRATION_FILES
// names), the part's lips' read (lipsChoiceOf).
export async function renderNessBrass(part,sampleRate,backend,{signal,calibrations,simulate,keepRaw=false}={}){
  if(typeof simulate!=='function')throw new TypeError('renderNessBrass needs the simulate its runs are made by (ness-process.mjs nessProcess)');
  const searching=tuningSearch();
  const model=part.physical?.model??'trumpet';
  if(!BRASS[model])throw new Error(`NESS brass has no model ${model} (${Object.keys(BRASS).join(', ')})`);
  const lipsChoice=lipsChoiceOf(model,part.physical?.lips),instrument=brassOf(model,lipsChoice),calibration=calibrations?.[lipsChoice];
  // (Its one scale, refused before any note is played where it is not measured: outputGainOf.)
  const outputScale=outputGainOf(model,calibration);
  // (Its calibration's instrument against its own as now built: a warning where they differ, or where it was measured
  // before calibrations were stamped.)
  const stale=(entry,mute)=>entry?.locks&&entry.instrument!==instrumentStamp(model,instrument,{mute})?`its ${mute?`${mute} mute's `:''}calibration (${entry.measured}) was measured on ${entry.instrument?'another':'an unstamped'} instrument -- its bore, lips or valves as NESS is given them since changed: measured again by scripts/chain.mjs (sweep to output)`:null;
  playableLips(model,backend,instrument.lips);
  // (Its slide, where it has one and NESS is built to move it: a note tuned by how far it is out.)
  const slide=slideOf(model,backend);
  const locksOf=mute=>mute?calibration?.[model]?.muted?.[mute]?.locks:calibration?.[model]?.locks;
  if(!locksOf(null)?.length)throw new Error(`NESS ${model}: its lips' locks are not measured (scripts/calibrate-ness-brass.mjs)`);
  // (Within a cent: the owner, 8 October 2026.)
  const tolerance=Number(part.physical.pitchToleranceCents??1),tail=Number(backend.tailSeconds??.15),tries=Math.max(1,Number(backend.maxCalibrationIterations??8));
  const end=Math.max(...part.notes.map(note=>note.endSeconds))+tail,scales=new Map,diagnostics=[],warnings=[];let out=new Float32Array(Math.ceil(end*sampleRate)+1);
  // (Its sound before its one scale, kept where a test asks (MUSEBOTS_KEEP_RAW=1): the instrument's contract, its part its
  // raw sound times outputScale throughout -- test/audio/instrument-contract.test.mjs.)
  for(const said of [stale(calibration?.[model],null),...[...new Set(part.notes.map(n=>n.technique?.mute?.kind).filter(Boolean))].map(m=>stale(calibration?.[model]?.muted?.[m],m))])if(said)warnings.push(said);
  let raw=keepRaw?new Float32Array(out.length):null,written=out.length;
  // (A run's sound placed whole, the part's buffer grown where its tail rings past it: never cut at its end -- a click.)
  const place=(audio,offset)=>{
    const needed=offset+audio.length;
    if(needed>out.length){const grown=new Float32Array(Math.max(needed,Math.ceil(out.length*1.5)));grown.set(out);out=grown;if(raw){const r=new Float32Array(grown.length);r.set(raw);raw=r}}
    for(let i=Math.max(0,-offset);i<audio.length;i++){out[offset+i]+=audio[i]*outputScale;if(raw)raw[offset+i]+=audio[i]}
    written=Math.max(written,needed);
  };
  // (Each note tuned first, alone, as below; then each breath group played whole, passage below.)
  const tunings=[];
  let job=0;
  for(const [index,note] of part.notes.entries()){
    const seconds=note.endSeconds-note.startSeconds,target=noteHzAt(note,note.startSeconds);
    const curve=note.pitchCurve?.length?note.pitchCurve.map(k=>[Math.max(0,k.seconds-note.startSeconds),noteHzAt(note,k.seconds)/target]):null;
    const pressure=breathOf(model,instrument,target,note.velocity);
    const technique=note.technique??{},asked=technique.mute?.kind??null;
    if(asked&&!locksOf(asked)?.length)throw new Error(`NESS ${model}: its locks with a ${asked} mute are not measured (scripts/calibrate-ness-brass.mjs --mute ${asked})`);
    // (Its lock: of the measured partials whose scale to this pitch lies within the valves' reach, the one nearest their
    // middle that speaks there -- one that sounds no periodic tone at this pitch, or another partial, giving way to the
    // next, as a player takes a note on another partial. Measured once a pitch, mute and breath.)
    // (Muted, its mute's own locks first, then the open bell's, from which a mute moves a partial a little: a partial the
    // sweep found no plateau of with the mute in, the tuning brings there.)
    // (A slide's reach from first position out, never in past it: its partials taken there, as a trombonist takes them --
    // the measured notes' shortened bores, a constraint broken for pitches its slide reaches, left aside.)
    // (And on a slide, only its strong locks, as a trombonist takes its partials: a weak one between them -- the designed
    // trombone's 197 Hz, three runs of its sweep -- let a slurred repeat fall to the partial beside it, 115 cents flat.)
    const strong=list=>slide?list.filter(strongLock):list;
    // (A slide's chart's positions first (chartedFirst): standard fingerings are data.)
    const reach=slide?{...reachOf(model),least:1}:reachOf(model),near=list=>{
      const choices=strong(list).map(lock=>({lock,scale:lock.played/target})).filter(c=>c.scale>=reach.least&&c.scale<=reach.most)
        .sort((a,b)=>Math.abs(Math.log(a.scale/reach.aim))-Math.abs(Math.log(b.scale/reach.aim)));
      return slide?chartedFirst(model,target,choices):choices};
    // (A mute is part of the instrument a note is tuned on -- it moves the bore's resonances; the breath's techniques are
    // not, the note tuned without them and played with them. Nor is its pitch curve, its scoop and vibrato: tuned on lips
    // held at its pitch. Following it, a probe past the curve's end held its vibrato's last swing, six cents off, and a
    // trumpet's held tones were heard as wandering: Op. 3.34's brass searched dozens of probes a note, three of its F#5s
    // played on a tone that rang and faded.)
    // (Its mouth pressure part of it too: the lips' lock moves with how hard they are blown.)
    const attempts=[];let lock,scale,mute=asked,blown=pressure,lipRatio=1;
    const play=(withTechnique,length,ahead=0,breath=null)=>simulate(nessFiles(model,{sampleRate,scale,mute,slide,lip:lock.lip/scale*lipRatio,
      curve:!withTechnique||!curve?null:ahead?[[0,curve[0][1]],...curve.map(([t,ratio])=>[t+ahead,ratio])]:curve,pressure:blown,seconds:length,tail,breath,technique:withTechnique?(mute?technique:Object.fromEntries(Object.entries(technique).filter(([name])=>name!=='mute'))):{},buzz:target,lipsBy:instrument.lips}),{signal,name:`n${job++}`});
    // (Tuned on a probe long enough to measure, without its technique: as the clarinet's bore is, openwind_worker.py.)
    // (Two seconds long, its pitch heard early and late -- heldTone: the lips take a few tenths to settle, a muted bore
    // longer, the trombone's harmon gliding from 25 cents sharp over its first half second; and a tone may speak and die,
    // the horn's low notes a transient 60 to 90 dB down gone by two seconds, which a shorter probe had taken for tuned.)
    // -> {lock, scale, late} (late: its tone speaks only after SPEAKS_BY), or null where no lock sounds the pitch.
    // (`prefer`: a lock tried alone first -- a slurred note's note before's, its slide moving on its partial.)
    const tune=async({ringing=false,prefer=null}={})=>{
      const key=`${ringing?'ringing:':''}${mute??''}:${Math.round(1200*Math.log2(target))}:${Math.round(pressure/50)}${prefer?`:on ${prefer.played}`:''}`;
      if(scales.has(key))return scales.get(key);
      const choices=prefer?near([prefer]):[...near(locksOf(mute)),...(mute?near(locksOf(null)):[])],probe=Math.max(PROBE_SECONDS,48/target);
      // (Each lock in turn until one sounds the pitch within the tolerance, speaking early -- on one, the pitch may leap
      // across it, the lips leaving the partial between two lengths -- else the closest any came, an early tone before
      // a late one, said in its attempts.)
      let best=null;
      // (Its pitch first: within the tolerance before without; then the earlier to speak; then the nearer.)
      const within=t=>Math.abs(t.error)<=tolerance;
      const better=(a,b)=>!b||(within(a)!==within(b)?within(a):within(a)&&Math.abs(a.at-b.at)>.05?a.at<b.at:Math.abs(a.error)<Math.abs(b.error));
      // (At each lock, blown as the note asks; where its tone fades or dies there, softer and harder in turn, as a player
      // finds the breath a note holds at -- its level is its measured sound power's anyway, its breath its timbre.)
      lock:for(const choice of choices.slice(0,LOCKS_TRIED))for(const more of HARDER){
        ({lock,scale}=choice);lipRatio=1;blown=Math.min(pressure*more,instrument.pressure[1]*2);const tried=[];let held=false;
        for(let k=0;k<tries;k++){
          // (Ringing: where nothing holds, a tone heard at its pitch from 0.6 s to 1, held or not -- the last resort.)
          // (Speaking, even so: a tone under its breath's thump is no tone.)
          const audio=await play(false,probe),rung=ringing&&speakingDb(audio,sampleRate,1,{window:.4,hz:target})>=BREATH.speaksDb?fundamentalOf(audio,sampleRate,{from:Math.round(.6*sampleRate),to:Math.round(sampleRate)}):null;
          const found=ringing?rung:heldTone(audio,sampleRate,probe);
          // (When it speaks: a bore that starts its tone only after half a second sounds nothing in a short note -- the
          // trombone's harmon, stem in, on the open bell's lock.)
          const at=found?speaksAt(audio,sampleRate,found.hz,probe):null,late=at!==null&&at>SPEAKS_BY;
          const error=found?1200*Math.log2(found.hz/target):null;attempts.push({lock:lock.played,...(mute?{mute}:{}),scale:+scale.toFixed(6),pressure:Math.round(blown),measuredHz:found?.hz??null,errorCents:error,periodicity:found?.periodicity??null,...(found?{speaksAt:at}:{})});
          if(!found||Math.abs(error)>300)break;
          held=true;const tuned={lock,scale,lipRatio,pressure:blown,error,at,late};if(better(tuned,best))best=tuned;
          if(Math.abs(error)<=tolerance&&!late)break;
          // (A step too small to move it: this lock's tuning as near as it comes.)
          tried.push({scale,error});const next=nextScale(tried);
          if(Math.abs(Math.log(next/scale))<1e-7||next<reach.least||next>reach.most)break;scale=next;
        }
        if(best&&!best.late&&Math.abs(best.error)<=tolerance)break lock;
        if(held)break;
      }
      // (Its closest further than a quarter tone from the pitch: not this pitch on the model.)
      const found=best&&Math.abs(best.error)<=QUARTER_TONE?{lock:best.lock,scale:best.scale,lipRatio:best.lipRatio??1,pressure:best.pressure,error:best.error,at:best.at,late:best.late}:null;
      scales.set(key,found);return found;
    };
    // -> as tune, a note led by its lips: the bore unscaled, its lips first where its measured runs (the calibration's
    // sweep) sound nearest the pitch, then tuned themselves -- above a model's partials, where its lips lead the pitch,
    // and wherever its partials tune no nearer.
    const runsOf=m=>(m?calibration?.[model]?.muted?.[m]?.runs:calibration?.[model]?.runs)??[];
    const tuneLips=async()=>{
      const key=`lips:${mute??''}:${Math.round(1200*Math.log2(target))}:${Math.round(pressure/50)}`;
      if(scales.has(key))return scales.get(key);
      const runs=runsOf(mute).filter(r=>r.played&&(r.periodicity??0)>=LIPS_PERIODIC);
      if(!runs.length){scales.set(key,null);return null}
      const nearest=runs.reduce((a,b)=>Math.abs(Math.log(b.played/target))<Math.abs(Math.log(a.played/target))?b:a);
      const probe=Math.max(PROBE_SECONDS,48/target),tried=[];let lip=nearest.lip*target/nearest.played,best=null;scale=1;blown=pressure;lipRatio=1;
      for(let k=0;k<tries;k++){
        lock={lip,played:target,lipLed:true};
        const audio=await play(false,probe),found=heldTone(audio,sampleRate,probe);
        const at=found?speaksAt(audio,sampleRate,found.hz,probe):null,error=found?1200*Math.log2(found.hz/target):null;
        attempts.push({lips:+lip.toFixed(3),...(mute?{mute}:{}),scale:1,measuredHz:found?.hz??null,errorCents:error,periodicity:found?.periodicity??null,...(found?{speaksAt:at}:{})});
        if(!found||Math.abs(error)>300)break;
        if(!best||Math.abs(error)<Math.abs(best.error))best={lock:{...lock},scale:1,pressure:blown,error,at,late:at!==null&&at>SPEAKS_BY};
        if(Math.abs(error)<=tolerance)break;
        tried.push({scale:lip,error});const next=nextScale(tried,{slope:LIP_SLOPE});
        if(Math.abs(Math.log(next/lip))<1e-7)break;lip=next;
      }
      const found=best&&Math.abs(best.error)<=QUARTER_TONE?best:null;
      scales.set(key,found);return found;
    };
    // -> as tune, from its nearest note measured note by note (scripts/calibrate-ness-notes.mjs: its lock, length, lips
    // and band of breath where its tone holds) -- its mute's own, else the open bell's -- its breath placed in that band
    // by its velocity, its bore (or, its lips leading, its lips) tuned on a held tone. Null where none is measured near.
    const notesOf=m=>(m?calibration?.[model]?.muted?.[m]?.notes:null)??calibration?.[model]?.notes??[];
    const tuneFromNotes=async()=>{
      const swept=lock=>(locksOf(mute)??[]).find(l=>l.played===lock.played&&l.lip===lock.lip);
      const measured=notesOf(mute).filter(n=>n.held!==false&&n.lock&&(!slide||n.lock.lipLed||n.scale>=1&&strongLock(swept(n.lock))));
      if(!measured.length)return null;
      const v=Math.max(0,Math.min(1,note.velocity??.6)),key=`notes:${mute??''}:${Math.round(1200*Math.log2(target))}:${Math.round(20*v)}`;
      if(scales.has(key))return scales.get(key);
      // (Its two measured neighbours, the nearer first, each within FROM_NOTES_CENTS; each at the breath its velocity
      // asks within its band, then at the one it was measured at -- a breath moves the pitch the lips lock to -- then,
      // where neither holds, its breath and lips a little either side of it (NEAR_HOLDING).)
      const below=measured.filter(n=>n.hz<=target).at(-1),above=measured.find(n=>n.hz>target);
      const froms=[below,above].filter(n=>n&&Math.abs(1200*Math.log2(n.hz/target))<=FROM_NOTES_CENTS)
        .sort((a,b)=>Math.abs(Math.log(a.hz/target))-Math.abs(Math.log(b.hz/target)));
      const probe=Math.max(PROBE_SECONDS,48/target);let best=null;
      search:for(const from of froms){
        const [soft,hard]=from.band??[from.pressure,from.pressure],asked=Math.round(soft*(hard/soft)**v);
        const settings=[[asked,1],...(asked!==from.pressure?[[from.pressure,1]]:[]),...NEAR_HOLDING.map(([b,l])=>[Math.round(from.pressure*b),l])];
        for(const [breath,lips] of settings){
          const led=Boolean(from.lock.lipLed),tuning=[];
          lock=from.lock;blown=breath;scale=led?1:from.scale*from.hz/target;lipRatio=(led?from.lipRatio*target/from.hz:from.lipRatio)*lips;
          // (A slide never in past first position.)
          if(slide&&!led&&scale<1)continue;
          let last=null;
          for(let k=0,back=0;k<tries;k++){
            const audio=await play(false,probe),found=heldTone(audio,sampleRate,probe);
            const at=found?speaksAt(audio,sampleRate,found.hz,probe):null,error=found?1200*Math.log2(found.hz/target):null;
            attempts.push({fromNote:from.midi,...(mute?{mute}:{}),scale:+scale.toFixed(6),lipRatio:+lipRatio.toFixed(5),pressure:Math.round(blown),measuredHz:found?.hz??null,errorCents:error,...(found?{speaksAt:at}:{})});
            // (A step off its island of holding: halfway back toward its last held setting, twice at most.)
            if(!found||Math.abs(error)>300){if(!last||back>=2)break;back++;if(led)lipRatio=(lipRatio+last.lipRatio)/2;else scale=(scale+last.scale)/2;continue}
            last={scale,lipRatio};
            if(!best||Math.abs(error)<Math.abs(best.error))best={lock,scale,lipRatio,pressure:blown,error,at,late:at!==null&&at>SPEAKS_BY};
            if(Math.abs(error)<=tolerance)break search;
            const value=led?lipRatio:scale;tuning.push({scale:value,error});const next=nextScale(tuning,led?{slope:LIP_SLOPE}:{});
            if(Math.abs(Math.log(next/value))<1e-7||slide&&!led&&next<1)break;if(led)lipRatio=next;else scale=next;
          }
        }
      }
      const found=best&&Math.abs(best.error)<=tolerance?best:null;
      scales.set(key,found);return found;
    };
    // (Its measured notes' tuning first; then its partials', then its lips', where that comes no nearer than its
    // tolerance: the nearer kept.)
    // -> as tune, fingered (the valved brass: FINGERED): on the instrument's own valves, at its own length, each fingering
    // and partial its valves and lips sound nearest the pitch in turn (fingeringCandidates), the player's actions tuning
    // it there -- its lips' tension (a secant on their frequency, within LIPS_REACH, bracketed where it crosses), then its
    // ear's lip curve. The owner, 9 October 2026: "strictly realistic while calibrating the player's actions ... to
    // accurately hit each microtone within the cent". Never a half-valve: its air shared between two tubes, it had
    // warbled as a multiphonic does in Op. 3.35 (the owner, 10 October 2026: "steady notes frequently have the warbling
    // quality of multiphonics - there are no horn 'pure tones' here"; "brass multiphonics ... require an altered breath
    // stream that likely limits dynamics") -- a technique, not a way of tuning; a player keeps to the pitches its lips
    // hold (scripts/brass-model-pitches.mjs).
    // (`exclude`: fingerings its breath group heard it fall off its partial on, slurred into -- each another to find, at
    // its own breath, its lips alone: a slurred note's attack is never played, so never learned -- REFINGER_CANDIDATES
    // of them at most, its passage's ear tuning it the rest of the way.)
    const tuneFingered=async(exclude=null)=>{
      const again=Boolean(exclude?.size);
      const key=`fingered:${mute??''}:${Math.round(12000*Math.log2(target))}:${Math.round(pressure/50)}${exclude?.size?`:not ${[...exclude].sort().join(',')}`:''}`;
      if(scales.has(key))return scales.get(key);
      const probe=Math.max(PROBE_SECONDS,48/target);let best=null,rung=null,blowing=pressure;
      const sound=async(candidate,fingering,ratio)=>{
        const audio=await simulate(nessFiles(model,{sampleRate,scale:1,mute,lip:candidate.lip*ratio,pressure:blowing,seconds:probe,tail,fingering,buzz:target,lipsBy:instrument.lips}),{signal,name:`n${job++}`});
        const found=heldTone(audio,sampleRate,probe),error=found?1200*Math.log2(found.hz/target):null;
        // (Where nothing holds, the nearest tone that rings at its pitch and speaks kept, its last resort: a real fingering.)
        if(!found){const ringing=fundamentalOf(audio,sampleRate,{from:Math.round(.6*sampleRate),to:Math.round(Math.min(probe,1)*sampleRate),low:target/1.6,high:target*1.6}),off=ringing?1200*Math.log2(ringing.hz/target):null;
          if(off!==null&&Math.abs(off)<=QUARTER_TONE&&speakingDb(audio,sampleRate,Math.min(probe,1),{window:.4,hz:ringing.hz})>=BREATH.speaksDb&&(!rung||Math.abs(off)<Math.abs(rung.error)))
            rung={lock:candidate.lock,fingering:[...fingering],lip:candidate.lip,lipRatio:ratio,scale:1,pressure:blowing,error:off,at:speaksAt(audio,sampleRate,ringing.hz,probe),rings:true}}
        attempts.push({fingering:fingering.map(v=>+(+v).toFixed(3)),partial:candidate.lock.played,lipRatio:+ratio.toFixed(5),pressure:Math.round(blowing),measuredHz:found?.hz??null,errorCents:error});
        if(found&&Math.abs(error)<=300&&(!best||Math.abs(error)<Math.abs(best.error)))
          best={lock:candidate.lock,fingering:[...fingering],lip:candidate.lip,lipRatio:ratio,scale:1,pressure:blowing,error,at:speaksAt(audio,sampleRate,found.hz,probe)};
        return found&&Math.abs(error)<=300?error:null;
      };
      // (Its lips: from their lock (`from`), a secant on their frequency, each step at most LIP_STEP, bracketed once it
      // crosses; a step that leaps (a change of regime: the lips leaving their partial) halved back toward the last held.)
      const lipsTo=async(candidate,fingering,from)=>{
        // (Where the lips at their lock hold nothing, a little looser and tighter first, as a player feels for the slot: the
        // horn's G3 on its first valve held nothing at its lock and held at 0.97 of it.)
        const tried=[],first=[from,from*(1-LIP_STEP*.75),from*(1+LIP_STEP*.75)];let ratio=from,last=null,feeling=0;
        for(let k=0;k<LIP_TRIES+first.length-1;k++){
          const error=await sound(candidate,fingering,ratio);
          if(error===null&&!last&&feeling<first.length-1){ratio=first[++feeling];continue}
          if(error===null||last&&Math.abs(error-last[1])>LEAP_CENTS){if(!last)break;ratio=(ratio+last[0])/2;continue}
          if(!tried.length&&Math.abs(error)>WRONG_PARTIAL)break;
          tried.push([ratio,error]);last=[ratio,error];if(Math.abs(error)<=tolerance)break;
          const above=tried.filter(([,e])=>e>0).sort((a,b)=>a[1]-b[1])[0],below=tried.filter(([,e])=>e<0).sort((a,b)=>b[1]-a[1])[0];
          const [[r0,e0],[r1,e1]]=above&&below?[below,above]:tried.length>1?tried.slice(-2):[[ratio,error],[ratio,error]];
          const secant=Math.abs(e1-e0)>.05&&r1!==r0?r1-e1*(r1-r0)/(e1-e0):ratio*(1-error/LIP_CENTS);
          const next=above&&below?secant:ratio*Math.max(1-LIP_STEP,Math.min(1+LIP_STEP,secant/ratio));
          if(!(next>=LIPS_REACH[0]*from&&next<=LIPS_REACH[1]*from)||Math.abs(next/ratio-1)<1e-6)break;ratio=next;
        }
        return tried.length?tried.reduce((a,b)=>Math.abs(b[1])<Math.abs(a[1])?b:a):null;
      };
      // (The player's ear: its lips' tension learned over the note, tenth by tenth, against what it hears -- a start on
      // another regime, a drift -- as a player holds a bent note, from the setting its fingering came nearest at (a
      // trumpet's F#4 on its open partial began half a second on its neighbouring plateau, 89 cents sharp, then sank to 9
      // flat), until the note speaks near its pitch from LEARN_SETTLED (within ATTACK_CENTS) and is within the tolerance
      // from LEARN_HELD. -> {ok, result: its setting, lipCurve, error (cents, held), worst (cents)}.)
      const learn=async from=>{
        const knots=learnKnots(probe),histories=knots.map(()=>[]);let factors=knots.map(()=>1),previous=null,nearest=null;
        const slope=sensitivityOf(attempts.filter(a=>a.partial===from.lock.played&&a.errorCents!=null&&a.learned==null&&JSON.stringify(a.fingering)===JSON.stringify(from.fingering.map(v=>+(+v).toFixed(3)))));
        for(let k=0;k<LEARN_TRIES;k++){
          const curve=knots.map((t,i)=>[t,+factors[i].toFixed(6)]);
          const audio=await simulate(nessFiles(model,{sampleRate,scale:1,mute,lip:from.lip*from.lipRatio,curve,pressure:from.pressure??blowing,seconds:probe,tail,fingering:from.fingering,buzz:target,lipsBy:instrument.lips}),{signal,name:`n${job++}`});
          const track=pitchTrack(audio,sampleRate,{from:LEARN_FROM,to:probe,target}),heard=track.filter(([t])=>t>=LEARN_SETTLED);
          const lost=!heard.length||heard.some(([,e])=>e==null);
          const held=heard.filter(([t])=>t>=LEARN_HELD),attack=heard.filter(([t])=>t<LEARN_HELD);
          const worst=lost?null:Math.max(...held.map(([,e])=>Math.abs(e))),early=lost?null:Math.max(0,...attack.map(([,e])=>Math.abs(e))),mean=lost?null:held.reduce((a,[,e])=>a+e,0)/held.length;
          attempts.push({fingering:from.fingering.map(v=>+(+v).toFixed(3)),partial:from.lock.played,lipRatio:+from.lipRatio.toFixed(5),learned:k,worstCents:worst,attackCents:early,errorCents:mean});
          const speaks=!lost&&speakingDb(audio,sampleRate,probe,{hz:target})>=BREATH.speaksDb,result={...from,lipCurve:curve,error:mean,held:worst,worst:Math.max(worst??Infinity,(early??Infinity)/ATTACK_CENTS*tolerance)};
          if(speaks&&(!nearest||result.worst<nearest.worst))nearest=result;
          // (Its lips as they were, its held tone in tune and its attack near: kept, never learned past -- each lip curve
          // learned for a quiet F#5 whose attack was 16 cents off had lost its held tone, and every other fingering had
          // then been tried, 89 simulations for one note.)
          if(speaks&&worst<=tolerance&&early<=ATTACK_CENTS*(k===0?2:1))return {ok:true,result};
          if(lost){if(!previous)break;factors=factors.map((f,i)=>(f+previous[i])/2);continue}
          previous=[...factors];factors=learnedFactors(knots,factors,track,{slope,histories});
        }
        // (None learned within the attack's bound: the nearest whose held tone is in tune, its attack its own.)
        return {ok:Boolean(nearest&&nearest.held<=tolerance),result:nearest};
      };
      let chosen=null,nearest=null;
      // (Where no fingering's tone speaks at its dynamic's breath, its player blows it at its instrument's middle, then
      // supports it with more air (breathsOf): the trumpet's F-sharp 3 on all three valves held its pitch to a hundredth of
      // a cent there, its tone still growing at 1.4 s, 9 dB over its breath's thump, under BREATH.speaksDb; blown harder,
      // it spoke.)
      supported:for(const breath of again?breathsOf(instrument,pressure).slice(0,1):breathsOf(instrument,pressure)){
      blowing=Math.min(instrument.pressure[1]*1.5,breath);
      const others=fingeringCandidates(model,locksOf(mute)??[],target,mute?null:calibration?.[model]?.fingered).slice(0,FINGERINGS_TRIED).filter(c=>!exclude?.has(c.fingering.map(Number).join('')));
      for(const candidate of again?others.slice(0,REFINGER_CANDIDATES):others){
        best=null;
        const lipped=await lipsTo(candidate,candidate.fingering,1);
        if(!lipped||!best)continue;
        if(again){if(Math.abs(best.error)<=QUARTER_TONE&&(!nearest||Math.abs(best.error)<Math.abs(nearest.error)))nearest={...best};if(Math.abs(best.error)<=tolerance)break supported;continue}
        const learned=await learn({...best});
        if(learned.ok){chosen=learned.result;break supported}
        if(learned.result&&(!nearest||learned.result.worst<nearest.worst))nearest=learned.result;
      }
      }
      best=chosen??nearest??best??rung;
      if(best?.rings)warnings.push(`${note.id}: ${target.toFixed(2)} Hz held by no fingering of the model; played on its nearest ringing tone, ${best.error.toFixed(1)} cents`);
      // (Its nearest, however near, said where it is not within the tolerance: the instrument's own fingerings only.)
      const found=best?{...best,late:best.at!==null&&best.at>SPEAKS_BY}:null;
      scales.set(key,found);return found;
    };
    const tuneEither=async()=>{
      if(FINGERED.has(model)){
        const valved=await tuneFingered();
        if(valved&&Math.abs(valved.error)<=tolerance)return valved;
        // (Its valves holding no tone near it: played on the bore its measured note holds it on (its notes table), the
        // instrument's valves set aside, said -- a note is never left out where its model holds it at all (the owner, 10
        // October 2026: "make sure you track down and fix that problem where some instruments' notes just weren't
        // sounding": Op. 3.35's tuba left seven notes silent, its 139 Hz at ff held by none of its fingerings and held
        // by its measured note at 2050 Pa). Its bore its own run, two simulations meeting (passage).)
        const measured=await tuneFromNotes();
        if(measured&&(!valved||Math.abs(measured.error)<Math.abs(valved.error))){
          warnings.push(`${note.id}: ${target.toFixed(2)} Hz held by none of the ${model}'s fingerings on the model; played on the bore its measured note holds it on (its valves set aside), ${measured.error.toFixed(1)} cents`);
          return {...measured,unvalved:true};
        }
        return valved;
      }
      // (Slurred on a slide: on its note before's partial first, where its slide reaches the pitch there -- as a trombonist
      // slurs a step on one partial, the slide moving under it as through a glissando, never a partial left as the slide
      // moves: tuned each alone, a trombone's 56.23 and 58.40 had stood on two partials 344 mm of slide apart, its slur
      // between them lost for a tenth of a second, a semitone over.)
      const before=index>0&&note.slurred&&slide?tunings[index-1]:null;
      if(before?.lock&&!mute){const kept=await tune({prefer:before.lock});if(kept&&Math.abs(kept.error)<=tolerance)return kept}
      const measured=await tuneFromNotes();if(measured)return measured;
      let tuned=near(locksOf(mute)??[]).length||mute&&near(locksOf(null)).length?await tune():null;
      if(!tuned||Math.abs(tuned.error)>tolerance){const led=await tuneLips();if(led&&(!tuned||Math.abs(led.error)<Math.abs(tuned.error)))tuned=led}
      return tuned;
    };
    // (A mute the model cannot sound this pitch with at all, the note played open, said: the render goes on.)
    // (A tone that speaks late is begun early, below: only a mute that does not sound the pitch at all is left off.)
    // (By its player's law: its chart's fingering, or its slide's charted position, on the measured partial nearest the
    // pitch, its lips at that partial's lock as its valves or slide move it -- a valved note's lips where its fingering's
    // sweep played the pitch (sweptLip; a fingering not swept, the open bore's sweep as its valves move it) -- blown as its
    // dynamic asks: no probe; its pitch as the model sounds it, heard in its breath group. Lipped by a slope instead
    // (LIP_CENTS), a horn's notes 43 to 99 c sharp at its locks' lips had sounded 128 to 177 c flat, its lips off the
    // lock.)
    const byLaw=()=>{
      if(FINGERED.has(model)){const c=fingeringCandidates(model,locksOf(mute)??[],target,mute?null:calibration?.[model]?.fingered)[0];if(!c)return null;
        const key=c.fingering.map(Number).join(''),swept=c.measured?calibration?.[model]?.fingered?.[key]?.runs:(mute?calibration?.[model]?.muted?.[mute]?.runs:calibration?.[model]?.runs);
        return {lock:c.lock,fingering:[...c.fingering],lip:sweptLip(swept,c.lock,target,c.measured?1:c.lip/c.lock.lip),lipRatio:1,scale:1,pressure,error:null,at:0}}
      // (A slur on a slide on its note before's partial where the slide reaches the pitch there, as a trombonist slurs.)
      const before=index>0&&note.slurred&&slide&&!mute?tunings[index-1]:null;
      const choice=(before?.lock?near([before.lock])[0]:null)??near(locksOf(mute)??[])[0]??(mute?near(locksOf(null))[0]:null);
      return choice?{lock:choice.lock,scale:choice.scale,lipRatio:1,pressure,error:null,at:0}:null;
    };
    let tuned=searching?await tuneEither():byLaw(),open=false;
    if(mute&&!tuned){
      mute=null;tuned=searching?await tuneEither():byLaw();
      if(tuned){warnings.push(`${note.id}: its ${asked} mute does not speak at ${target.toFixed(2)} Hz on the model; played open`);open=true}
    }
    // (A pitch no setting of the model holds -- the horn's B1 and C2, under its second partial's reach on the model --
    // played on its nearest ringing tone, said: the render goes on.)
    if(searching&&!tuned&&!FINGERED.has(model)){tuned=await tune({ringing:true});if(tuned)warnings.push(`${note.id}: ${target.toFixed(2)} Hz is held by no setting of the model; played on a tone that rings and fades`)}
    // (A pitch nothing of the model holds or rings at: left out, said loudly -- never the whole render stopped for one note,
    // as Op. 3.35's was after 85 minutes.)
    if(!tuned){
      warnings.push(`${note.id}: LEFT OUT -- none of the ${model}'s fingerings or locks speaks at ${target.toFixed(2)} Hz${asked?`, open or with a ${asked} mute`:''} (tried: ${JSON.stringify(attempts.map(a=>[a.lock??a.lips??a.partial,a.fingering??a.scale,a.lipRatio??null,a.errorCents==null?null:+a.errorCents.toFixed(1),a.speaksAt??null]))})`);
      tunings.push(null);diagnostics.push({noteId:note.id,targetHz:target,leftOut:true,attempts});continue;
    }
    ({lock,scale}=tuned);blown=tuned.pressure??pressure;lipRatio=tuned.lipRatio??1;
    // (A development measure's own setting of this note -- a map's or a player fit's probe (tools/brass_regions.py,
    // scripts/brass-probe.mjs): its lips a share of its law's, its breath its own; never a bot's, whose notes carry none.)
    if(note.probe){if(note.probe.lipRatio!=null)lipRatio*=note.probe.lipRatio;if(note.probe.breath!=null)blown=note.probe.breath}
    // (A pitch its measured locks reach no nearer than this -- the tuba's F3, at its highest lock -- played as near as they
    // came, said.)
    if(tuned.error!=null&&Math.abs(tuned.error)>tolerance)warnings.push(`${note.id}: ${target.toFixed(2)} Hz tuned within ${Math.abs(tuned.error).toFixed(1)} cents at best on the model${mute?` with a ${mute} mute`:''}`);
    tunings.push({note,target,curve,technique,mute,asked,open,lock,scale,lipRatio,blown,pressure,at:tuned.at??0,error:tuned.error,attempts,
      fingering:tuned.fingering??null,lip:tuned.lip??lock.lip/scale,lipCurve:tuned.lipCurve??null,...(tuned.unvalved?{unvalved:true}:{}),
      // (Its tuning again on another of its fingerings, none of `exclude` (each its valves as '010'): a valved player's
      // other way to a note its slur fell off -- its passage's. -> the same fields, or null where none tunes near it.)
      ...(FINGERED.has(model)?{retune:async exclude=>{const again=await tuneFingered(new Set(exclude));
        return again&&!again.rings&&Math.abs(again.error)<=QUARTER_TONE?{lock:again.lock,scale:again.scale??1,lipRatio:again.lipRatio??1,blown:again.pressure??pressure,at:again.at??0,
          error:again.error,fingering:again.fingering??null,lip:again.lip??again.lock.lip,lipCurve:again.lipCurve??null}:null}}:{})});
  }
  // (Each breath group played as one simulation, its breath going on through it: breath.mjs.)
  // (The notes it plays -- any it could not, left out -- each breath group of them one simulation.)
  const playing=part.notes.map((n,k)=>tunings[k]?k:null).filter(k=>k!==null);
  for(const group of breathGroups(playing.map(k=>part.notes[k])))await passage({...group,notes:group.notes.map(i=>playing[i])});
  return {samples:out.length===written?out:out.slice(0,written),sampleRate,channels:1,originSeconds:0,...(raw?{raw:raw.length===written?raw:raw.slice(0,written)}:{}),diagnostics:{backend:'ness',model,lips:lipsChoice,source:instrument.source,notes:diagnostics,warnings,outputScale,
    fidelity:'NESS lip reed on a measured bore, each breath group one simulation (breath.mjs): its player\'s breath going on through it -- its attack, swell and release, a tongued note\'s air stopped and let go, a slurred note reached under it, the breath moving to its tuned pressure -- on the instrument as it is -- a valved instrument\'s own valves fingered for each note (a half-valve held part way), a trombone\'s slide moved -- its lips tuned to each note; output normalized by NESS, each note\'s held level its own (its levelDb), else its velocity',
    muteModel:'the bell narrowed to the mute gap\'s opening; the mute\'s cavity is not modelled',license:'MIT (NESS)'}};

  // A breath group, its notes' tunings above, played on the instrument itself, its breath going on through it: a valved
  // instrument's (FINGERED) as one simulation, its valves moving under the breath to each note's fingering, its lips each
  // note's own; a trombone's as one simulation where NESS moves its slide, its slurs across a change of position
  // legato-tongued where its player tongues them (SLIDE_SLURS), a lip slur within one. Each note's
  // pitch then measured in its run and its player's lips (a trombone's slide, its run's) tuned again, until each is
  // within the tolerance or PASSAGE_TRIES have passed; each note at its own level after (its levelDb: its held level in
  // its run), across each change.
  async function passage(group){
    const items=group.notes.map(k=>tunings[k]),notes=items.map(t=>t.note),fingered=FINGERED.has(model);
    // (Its player's anticipation, learned by ear (breath.mjs anticipation): its first note's breath begun `ahead` early --
    // at first as early as its tone took to speak when it was tuned, never before its player is free -- and each change
    // after it `leads` earlier, each by as much as its note was heard late in the try before (arrivalOf).)
    const first=notes[0],free=Math.max(0,Math.min(MOST_AHEAD,first.startSeconds-freedAt(part.notes,first)));
    let ahead=Math.min(free,items[0].at),origin=first.startSeconds-ahead,leads=items.map(()=>0),lates=items.map(()=>null);
    const timings=items.map(()=>[]),refingerings=items.map(()=>null),aids=items.map(()=>0),softTongues=items.map(()=>BREATH.softSeconds);
    // (A trombone's slide moving under one breath, where NESS moves it (slideOf): the group one simulation, each note's
    // slide out by its own scale, moved between notes as quickly as a player moves it -- under a legato tongue as long as
    // the move where its player tongues the slur, else under the breath (SLIDE_SLURS); within a note, its pitch curve the
    // slide's (a glissando). A note above first position's reach (its bore shortened: the constraint broken) has no slide to take:
    // its group in runs, as without one. Without a slide, its runs: a new one wherever its slide moves, two simulations
    // meeting -- no legato.)
    const moves=items.map((t,k)=>k>0&&(!fingered||t.unvalved||items[k-1].unvalved)&&Math.abs(1200*Math.log2(t.scale/items[k-1].scale))>.01);
    const slid=Boolean(slide)&&items.every(t=>t.scale>=1);
    const moveSeconds=k=>Math.max(BREATH.softSeconds,Math.min(SLIDE.most,Math.abs(12*Math.log2(items[k].scale/items[k-1].scale))*SLIDE.semitone));
    // (Its slide's moves under a slur, each as long as it takes (`moves`); tongued where its player tongues them, or every
    // one where SLIDE_SLURS says so. Without a slide, two simulations meet at each move, under a tongue: `soft`.)
    const slurKeys=items.map((t,k)=>k).filter(k=>moves[k]&&notes[k].slurred);
    const slideMoves=new Map(slid?slurKeys.map(k=>[k,moveSeconds(k)]):[]);
    const soft=new Set(slid?(SLIDE_SLURS==='tongued'?slurKeys:[]):slurKeys);
    const starts=slid?[0]:[0,...items.map((t,k)=>k).filter(k=>moves[k])],runs=starts.map((from,r)=>({from,to:(starts[r+1]??items.length)-1}));
    const runOf=k=>runs.findIndex(run=>k>=run.from&&k<=run.to);
    // (Its plan for a try: its breath from its origin, its changes led where it is one simulation -- a trombone's runs,
    // its slide not moving under the breath, each begin where they were.)
    const timed=runs.length===1;let breath=null,played=null;
    const plan=()=>{origin=first.startSeconds-ahead;breath=passageBreath(notes,{origin,pressures:items.map(t=>t.blown),hz:items.map(t=>t.target),ahead,soft,moves:slideMoves,softTongues});
      if(timed){leads=boundLeads(breath,leads);played=anticipation(breath,leads)}};
    const ratios=items.map(t=>t.lipRatio),scales=runs.map(run=>items[run.from].scale),history=items.map(()=>[]),attempts=[];
    // (With a slide, each note's own scale, its ear correcting it in the group as a trombonist's corrects the slide.)
    const noteScales=items.map(t=>t.scale);
    // (Each note's lips over it, learned: its tuning's curve, s from its onset, else none yet; and the one before each try.)
    // (Each note's lips over it as its tuning learned them, s from its onset -- an attack from silence's start among them;
    // a note slurred to, its held tension throughout: no attack is begun there (a trumpet's 520 Hz, slurred to with its
    // attack's low start, fell a partial, 440 Hz, for a third of a second).)
    const curves=items.map((t,k)=>!t.lipCurve?null:notes[k].slurred&&k>0?t.lipCurve.map(([x])=>[x,heldFactor(t.lipCurve)]):t.lipCurve.map(([x,f])=>[x,f]));
    let sounds=[],errors=[],kept=null;
    // (How far a try is from its passage as asked: each note's error (cents, a note not heard where it holds as far as
    // OFF_TRY), its warble past WAVERS twice over, its lateness past its tolerance (ms) a half -- and a note heard on its
    // pitch but never heard to arrive as far as one not heard: a repeated pitch its legato tongue went unheard in is one
    // note where two were asked. Counted nothing, a trombone's tries had kept the one whose repeat merged into the note
    // before it (its tongue 48 ms, a 1.5 dB dip) over those its ear had lengthened its tongue in to be heard (24 October
    // 2026). Its tries' least kept: a try that fell -- a slurred note re-fingered onto worse, dying -- never the last
    // word, its best before it played.)
    const offTry=()=>items.reduce((sum,t,k)=>{const e=errors[k],[a,b]=heardSpan(k),{audio,window}=sounds[runOf(k)];
      const late=lates[k]==null?(e!=null&&Math.abs(e)<=WRONG_PARTIAL?OFF_TRY:0):Math.max(0,Math.abs(lates[k])-ANTICIPATION.tolerance)*500;
      return sum+(e==null?(b-a>=MEASURABLE?OFF_TRY:0):Math.min(OFF_TRY,Math.abs(e)))+2*Math.max(0,waverOf(audio,k,window[0])-WAVERS)+late},0);
    // (Played once by its player's law; again and again only where a development measure searches: tuningSearch.)
    const tries=searching?PASSAGE_TRIES:1;
    for(let attempt=0;attempt<tries;attempt++){
      plan();sounds=[];errors=[];
      for(const [r,run] of runs.entries()){
        const window=runWindow(run),files=runFiles(run,scales[r],window);
        const audio=await simulate(files,{signal,name:`p${job++}`});
        sounds.push({audio,window});
        for(let k=run.from;k<=run.to;k++)errors[k]=measured(audio,k,window[0]);
      }
      attempts.push(errors.map(e=>e==null?null:+e.toFixed(2)));
      // (When each note was heard to arrive; each lead taken on by its lateness where it is out of time, its first note's
      // breath begun earlier or later by its own; in time where none moves. Never where its held part was heard on another
      // partial: a note that cracked never arrived, and what its ear took for its arrival led it on by as much --
      // openwind_passages.py's oboe, 24 October 2026.)
      lates=items.map((t,k)=>{if(errors[k]!=null&&Math.abs(errors[k])>WRONG_PARTIAL)return null;const {audio,window}=sounds[runOf(k)];
        return arrivalOf(audio,sampleRate,{from:window[0],hz:t.target,prevHz:k?items[k-1].target:null,on:notes[k].startSeconds-origin,prevOn:k?notes[k-1].startSeconds-origin:null,held:heardSpan(k)})});
      const off=offTry();
      if(!kept||off<kept.off)kept={off,sounds,errors:[...errors],lates:[...lates],leads:[...leads],ahead,origin,breath,played,items:[...items],ratios:[...ratios],curves:[...curves],noteScales:[...noteScales],scales:[...scales],aids:[...aids]};
      const out=k=>lates[k]!=null&&Math.abs(lates[k])>ANTICIPATION.tolerance;
      lates.forEach((l,k)=>{if(l!=null)timings[k].push([k?leads[k]:ahead,l])});
      const nextAhead=out(0)?Math.max(0,Math.min(free,nextLead(timings[0]))):ahead,nextLeads=timed?boundLeads(breath,leads.map((l,k)=>k&&out(k)?nextLead(timings[k]):l)):leads;
      const settled=Math.abs(nextAhead-ahead)<1e-3&&nextLeads.every((l,k)=>Math.abs(l-leads[k])<1e-3);
      // (A slurred note its slur fell off -- no tone heard where it holds, or another partial's -- tuned again on another
      // of its fingerings, as a player takes another way to it (at most REFINGERINGS a note): a trumpet's F4 slurred up to
      // a sharp G4 on its second and third valves jumped a partial over it and fell to another, its two notes tuned alone
      // within two cents.)
      // (Or one that wavers there, two pitches beating in it -- the same G4 on its third valve slurred into wavered 25 cents
      // either side of its pitch, a multiphonic's warble where a pure tone was asked for.)
      let refingered=false;
      if(fingered&&attempt<tries-1)for(const [k,t] of items.entries()){
        const e=errors[k],[a,b]=heardSpan(k),{audio,window}=sounds[runOf(k)],fell=e==null?b-a>=MEASURABLE:Math.abs(e)>WRONG_PARTIAL||waverOf(audio,k,window[0])>WAVERS;
        // (Never a repeated pitch: it keeps its note's fingering, as a player half-attacks it -- re-fingered when it fell,
        // a trumpet's repeat went from its note's valves to two others and sounded 70 cents flat; its half attack is its
        // own ear's to deepen, below.)
        if(!(k>0&&notes[k].slurred&&t.retune&&t.fingering&&fell)||Math.abs(1200*Math.log2(t.target/items[k-1].target))<BREATH.samePitch)continue;
        // (First its breath's help at the change, as a player gives it: eased for a slur down to a lower partial, pushed for
        // one up (SLUR_AIDS), more each try; then another fingering, its help begun again.)
        if(aids[k]<SLUR_AIDS.down.length){aids[k]++;refingered=true;continue}
        const tried=(refingerings[k]??=[t.fingering.map(Number).join('')]);if(tried.length>REFINGERINGS)continue;
        const again=await t.retune(tried);tried.push(again?.fingering?.map(Number).join('')??'none');if(!again)continue;
        items[k]={...t,...again};ratios[k]=again.lipRatio;history[k]=[];timings[k]=[];nextLeads[k]=0;aids[k]=0;
        curves[k]=again.lipCurve?again.lipCurve.map(([x])=>[x,heldFactor(again.lipCurve)]):null;refingered=true;
      }
      // (Each repeated pitch's legato tongue heard: where its dip is under HALF_HEARD dB -- a trombone's rang through the
      // air's fall to 0.55 of itself for 30 ms, 2.7 dB, its repeated note not heard again -- its tongue held longer the next
      // try, the air falling as far: let fall further, to a fifth, its lips had stopped and begun again, its pitch
      // wandering 133 cents. A slur's legato tongue across a slide's move, only to soften its glide, left as it is.)
      let deepened=false;
      breath.entries.forEach((entry,k)=>{if(entry!=='soft'||attempt>=tries-1||Math.abs(1200*Math.log2(items[k].target/items[k-1].target))>=BREATH.samePitch)return;const dip=softDipOf(k);
        if(dip!=null&&dip<HALF_HEARD&&softTongues[k]<SOFT_MOST-1e-9){softTongues[k]=Math.min(SOFT_MOST,softTongues[k]*SOFT_STEP);deepened=true}});
      if(errors.every(e=>e==null||Math.abs(e)<=tolerance)&&settled&&!refingered&&!deepened||attempt===tries-1)break;
      ahead=nextAhead;leads=nextLeads;
      // (Its player's lips each a secant on the note's error; a trombone's slide its run's, by its notes' median error.)
      // (Its player's ear, in its passage: each note's lips one ratio (the shape its tuning learned kept), a secant on the
      // pitch of its held part, each step at most LIP_STEP, bracketed once it crosses, a leap halved back toward the last
      // held. Learning its whole curve in the passage was tried: the regimes its slurs and tongue begin on, chased, moved
      // the pitch heard -- five notes of a trumpet stalled at 5 to 16 cents, against 0.4 to 2.7 so.)
      items.forEach((t,k)=>{const e=errors[k];if(e==null||Math.abs(e)<=tolerance)return;
        const h=history[k],last=h.at(-1);
        if(last&&Math.abs(e-last[1])>LEAP_CENTS||Math.abs(e)>QUARTER_TONE*2){if(last)ratios[k]=(ratios[k]+last[0])/2;return}
        h.push([ratios[k],e]);
        const above=h.filter(([,x])=>x>0).sort((a,b)=>a[1]-b[1])[0],below=h.filter(([,x])=>x<0).sort((a,b)=>b[1]-a[1])[0];
        const [[r0,e0],[r1,e1]]=above&&below?[below,above]:h.length>1?h.slice(-2):[[ratios[k],e],[ratios[k],e]];
        const secant=Math.abs(e1-e0)>.05&&r1!==r0?r1-e1*(r1-r0)/(e1-e0):ratios[k]*(1-e/LIP_CENTS);
        const next=above&&below?secant:ratios[k]*Math.max(1-LIP_STEP,Math.min(1+LIP_STEP,secant/ratios[k]));
        ratios[k]=Math.max(t.lipRatio*LIPS_REACH[0],Math.min(t.lipRatio*LIPS_REACH[1],next))});
      if(slid)items.forEach((t,k)=>{const e=errors[k];if(e!=null&&Math.abs(e)<=QUARTER_TONE*2&&Math.abs(e)>tolerance)noteScales[k]*=2**(e/1200)});
      else if(!fingered)runs.forEach((run,r)=>{const v=errors.slice(run.from,run.to+1).filter(e=>e!=null&&Math.abs(e)<=QUARTER_TONE*2).sort((a,b)=>a-b);
        if(v.length&&Math.abs(v[v.length>>1])>tolerance)scales[r]*=2**(v[v.length>>1]/1200)});
    }
    // (Its best try's sound and settings, where a later one was worse.)
    if(kept&&offTry()>kept.off){({sounds,errors,lates,leads,ahead,origin,breath,played}=kept);kept.items.forEach((t,k)=>{items[k]=t});
      kept.ratios.forEach((r,k)=>{ratios[k]=r});kept.curves.forEach((c,k)=>{curves[k]=c});kept.noteScales.forEach((v,k)=>{noteScales[k]=v});kept.scales.forEach((v,k)=>{scales[k]=v});
      kept.aids.forEach((v,k)=>{aids[k]=v})}
    // (Each run simulated until its sound has died away -- its last 10 ms, at the part's one scale, under SILENT -- never
    // for a fixed tail: its breath let go, a bore rings on for its lowest resonance's decay (the owner, 16 October 2026:
    // "make sure that renders never end with audio above zero"). Its tail from FIRST_TAIL, at least doubled each time, at
    // least as long as its decay heard in the last says it needs; LONGEST_TAIL at most, said where it has not died away.)
    for(const [r,run] of runs.entries()){
      let {audio,window}=sounds[r],t=tail;
      for(;;){
        const last=peakOf(audio,audio.length-Math.round(.01*sampleRate),audio.length)*outputScale;
        if(last<=SILENT)break;
        if(t>=LONGEST_TAIL){warnings.push(`${notes[run.to].id}: its run's sound still ${(20*Math.log10(last)).toFixed(1)} dBFS after a ${t} s tail (undecayed)`);break}
        t=Math.min(LONGEST_TAIL,Math.max(FIRST_TAIL,2*t,decayedBy(audio,sampleRate,t,outputScale)));
        audio=await simulate(runFiles(run,scales[r],window,t),{signal,name:`p${job++}`});
      }
      sounds[r]={audio,window,tailSeconds:t};
    }
    // (Its sound at its instrument's one scale, every note alike: outputGainOf.)
    for(const {audio,window} of sounds)place(audio,Math.round((origin+window[0])*sampleRate));
    items.forEach((t,k)=>{
      const error=errors[k],note=t.note;
      diagnostics.push({noteId:note.id,targetHz:t.target,lock:{lip:t.lock.lip,played:t.lock.played,...(t.lock.lipLed?{lipLed:true}:{})},scale:fingered?1:slid?+noteScales[k].toFixed(6):scales[runOf(k)],...(slid?{slideMm:+slideOut(model,noteScales[k]).toFixed(1)}:{}),
        ...(t.fingering?{fingering:t.fingering.map(v=>+(+v).toFixed(3))}:{}),lipRatio:+ratios[k].toFixed(5),...(curves[k]?{lipCurve:curves[k].map(([x,f])=>[x,+f.toFixed(5)])}:{}),pressure:Math.round(t.blown),...(t.blown>t.pressure?{askedPressure:Math.round(t.pressure)}:{}),attempts:t.attempts,...(t.open?{playedOpen:t.asked}:{}),
        passage:{group:group.notes[0],entry:breath.entries[k],run:runOf(k),measuredCents:error==null?null:+error.toFixed(2),...(k===0&&ahead?{aheadSeconds:+ahead.toFixed(3)}:{}),
          ...(k&&leads[k]?{leadSeconds:+leads[k].toFixed(3)}:{}),arrivedMs:lates[k]==null?null:Math.round(lates[k]*1000),...(refingerings[k]?{refingered:refingerings[k]}:{}),...(aids[k]?{slurAid:aids[k]}:{}),...(k===0?{tuning:attempts}:{})},
        ...(Object.keys(t.technique).length?{technique:t.technique}:{})});
      // (A glissando's pitch moves: no one pitch to hear it at -- its slide's own, the slide moving it.)
      const glides=t.curve?.length&&Math.abs(1200*Math.log2(Math.max(...t.curve.map(([,r])=>r))/Math.min(...t.curve.map(([,r])=>r))))>QUARTER_TONE;
      if(error==null&&!glides&&heardSpan(k)[1]-heardSpan(k)[0]>=MEASURABLE)warnings.push(`${note.id}: no tone at ${t.target.toFixed(2)} Hz heard in its breath group`);
      else if(error!=null&&Math.abs(error)>tolerance)warnings.push(`${note.id}: ${t.target.toFixed(2)} Hz within ${Math.abs(error).toFixed(1)} cents in its breath group${t.mute?` with a ${t.mute} mute`:''}`);
    });
    // A note's span in the passage, s from its start: from its change in (its attack's end) to its change out -- as led,
    // where its player begins it (its sound leaves the note there, to arrive at the next on its beat).
    function span(k){
      const into=breath.changes.find(c=>c.to===k),next=breath.changes.find(c=>c.to===k+1);
      const a=(into?into.at+into.seconds/2:notes[k].startSeconds-origin+.03),b=next?next.at-next.seconds/2-(leads[k+1]??0):notes[k].endSeconds-origin;
      return [Math.max(0,a),Math.max(a,b)];
    }
    // A run's window in the passage, s: from where the run before hands its breath to it (the group's start) to where it
    // hands its own to the next (the breath's end), its tail after -- each hand-over a breath's rise either side of where
    // its breath is least across their change (leastBreathAt, runPressure).
    function runWindow(run){
      const into=breath.changes.find(c=>c.to===run.from),next=breath.changes.find(c=>c.to===run.to+1),S=transitionSeconds('breathRise');
      return [into?leastBreathAt(breath.pressure,into)-S:0,next?leastBreathAt(breath.pressure,next)+S:breath.end];
    }
    // A note's pitch in its run (whose audio begins at `from` s), cents from its target, over its span less its first
    // tenth (the lips settling): null where its span is too short to measure or no tone is heard.
    // The part of a note's span its pitch is heard over: its first tenth (or third) and its attack's settling left out.
    // (A note too short for it is not heard at all, never said to be silent: Op. 3.35's eighth-second runs were.)
    function heardSpan(k){
      let [a,b]=span(k);if(b-a<MEASURABLE)return [a,a];
      a=Math.max(a+Math.min(.1,(b-a)/3),notes[k].startSeconds-origin+Math.min(LEARN_HELD,(notes[k].endSeconds-notes[k].startSeconds)/2));return [a,Math.max(a,b)];
    }
    // How far the sound dips round a legato-tongued note's onset, dB: its lowest 5 ms against the lower of the two notes'
    // heard spans; null where either is too short to hear.
    function softDipOf(k){
      const {audio,window}=sounds[runOf(k)],[a0,b0]=heardSpan(k-1),[a1,b1]=heardSpan(k),on=notes[k].startSeconds-origin;
      if(b0-a0<.02||b1-a1<.02)return null;
      const db=(a,b)=>{const i=Math.max(0,Math.round((a-window[0])*sampleRate)),j=Math.min(audio.length,Math.round((b-window[0])*sampleRate));let e=0;for(let x=i;x<j;x++)e+=audio[x]*audio[x];return j>i?10*Math.log10(e/(j-i)+1e-24):-Infinity};
      let low=Infinity;for(let t=on-(leads[k]??0)-.06;t<on+.1;t+=.005)low=Math.min(low,db(t,t+.005));
      return Math.min(db(a0,b0),db(a1,b1))-low;
    }
    // How far a note's pitch wanders over its heard span, cents (its windows' highest and lowest: 40 ms, or five of its
    // periods where those are longer), else 0.
    function waverOf(sound,k,from){
      const [a,b]=heardSpan(k),t=items[k],seen=[],width=Math.max(.04,5/t.target);
      for(let x=a;x+width<=b;x+=width/2){const f=fundamentalOf(sound,sampleRate,{from:Math.round((x-from)*sampleRate),to:Math.round((x+width-from)*sampleRate),low:t.target/1.6,high:t.target*1.6});if(f)seen.push(1200*Math.log2(f.hz/t.target))}
      return seen.length>=3?Math.max(...seen)-Math.min(...seen):0;
    }
    function measured(sound,k,from){
      const [a,b]=heardSpan(k);if(b-a<MEASURABLE)return null;
      const t=items[k],found=fundamentalOf(sound,sampleRate,{from:Math.round((a-from)*sampleRate),to:Math.round((b-from)*sampleRate),low:t.target/1.6,high:t.target*1.6});
      return found?1200*Math.log2(found.hz/t.target):null;
    }
    // A run's instrument and score files: the instrument's own (its valves where they are), its bore at `scale` (a
    // trombone's slide; a valved instrument's own length); each note's fingering held from its change in to its change
    // out, moving over each change; its lips (frequency and set) each note's own, following its
    // pitch curve, moving across each change; its breath (passageBreath) within its window; each note's technique.
    function runFiles(run,scale,[w0,w1],tailSeconds=tail){
      const {valves}=instrument,T=w1-w0+tailSeconds,mute=items[run.from].mute,ks=[];for(let k=run.from;k<=run.to;k++)ks.push(k);
      const bore=slid?1:scale;
      const instrumentFile=[`% Musebots: ${model}, NESS brass instrument, a run of a breath group`,`custominstrument=0;`,`FS=${sampleRate};`,`temperature=${NESS_TEMPERATURE};`,
        `vpos=[${valvesAt(model,bore).map(x=>+x.toFixed(3)).join(',')}];`,`vdl=[${valves.short.map(x=>+x.toFixed(3)).join(',')}];`,
        `vbl=[${valves.bypass.map(x=>+x.toFixed(3)).join(',')}];`,`bore=${matrix(nessBore(model,{scale:bore,mute,sampleRate}))};`,...(slid?[`slide=[${slide.join(',')}];`]:[])].join('\n')+'\n';
      const changes=breath.changes.filter(c=>c.to>run.from&&c.to<=run.to).map(c=>({...c,at:c.at-w0,...(c.released!=null?{released:c.released-w0}:{})}));
      // (Its rows written at each change's breakpoints for each kind it moves -- its lips, its valves, its technique's,
      // a trombone's slide -- and at each note's pitch and lip curves' points.)
      const times=[...new Set([0,T,...changeTimes(changes,['lips','valve','technique',...(slid?['slide']:[])]),
        ...ks.flatMap(k=>[...(items[k].curve??[]).map(([x])=>x),...(curves[k]??[]).map(([x])=>x-(k===0?ahead:0))].map(x=>notes[k].startSeconds-origin-w0+x))].filter(t=>t>=0&&t<=T).map(t=>+t.toFixed(6)))].sort((a,b)=>a-b);
      // (A value of each note's, moved across each change as its kind moves (transitions.js): geometric, for a frequency.)
      const between=(value,kind,t,log=false)=>acrossChanges(value,t,changes,{from:run.from,kind,log});
      const curveAt=(k,t)=>{const c=items[k].curve;if(!c?.length)return 1;const x=t+w0-(notes[k].startSeconds-origin);if(x<=c[0][0])return c[0][1];
        for(let i=1;i<c.length;i++)if(x<=c[i][0]){const [a,p]=c[i-1],[b,q]=c[i];return p+(q-p)*(x-a)/((b-a)||1)}return c.at(-1)[1]};
      // (A note's learned lips from its attack: its first note's from its breath's beginning, `ahead` before its onset --
      // its attack begun there, the curve begun at its onset had held its lips at their attack's setting while it sounded,
      // a trombone's first note hunting a semitone either side.)
      const learnedAt=(k,t)=>{const c=curves[k];if(!c)return 1;const x=t+w0-(notes[k].startSeconds-origin)+(k===0?ahead:0);if(x<=c[0][0])return c[0][1];
        for(let i=1;i<c.length;i++)if(x<=c[i][0]){const [a,p]=c[i-1],[b,q]=c[i];return p+(q-p)*(x-a)/((b-a)||1)}return c.at(-1)[1]};
      const lipOf=(k,t)=>(fingered?items[k].lip:items[k].lock.lip/(slid?noteScales[k]:scale))*ratios[k]*curveAt(k,t)*learnedAt(k,t);
      // (Its slide out at each moment: each note's own, its pitch curve moving it -- a glissando -- moved across each change.)
      const slideAt=(k,t)=>slideOut(model,noteScales[k]/curveAt(k,t));
      const lipsRows=key=>times.map(t=>[t,between((k,x)=>lipsAt(instrument.lips,lipOf(k,x))[key],'lips',t,true)]);
      const openRows=times.map(t=>[t,...valves.position.map((x,v)=>between(k=>1-(+(items[k].fingering?.[v]??0)),'valve',t))]);
      const tremoloOf=k=>{const tech=items[k].technique,voiced=tech.growl??tech.hum,flutter=tech.flutter;return voiced?[voiced.level,voiced.hz]:flutter?[flutter.depth,flutter.hz]:[0,0]};
      // (Its breath within its window, handed over from the run before and to the run after where it is least.)
      const into=breath.changes.find(c=>c.to===run.from),next=breath.changes.find(c=>c.to===run.to+1);
      let pressure=runPressure(breath.pressure,[w0,w1],{into:into?leastBreathAt(breath.pressure,into):null,out:next?leastBreathAt(breath.pressure,next):null});
      // (A slur its ear heard fall: its breath eased or pushed over its change and back (transitions.js bump), from the
      // change's start, each way no quicker than a breath rises.)
      const aided=changes.filter(c=>aids[c.to]>0).map(c=>{const down=items[c.to].target<items[c.to-1].target,[factor,seconds]=SLUR_AIDS[down?'down':'up'][aids[c.to]-1];
        return {from:c.at-c.seconds/2,seconds:2*transitionSeconds('breathRise',seconds/2),factor}});
      if(aided.length){
        const helped=t=>aided.reduce((f,a)=>{const x=(t-a.from)/a.seconds;return x>0&&x<1?f*(1+(a.factor-1)*bump(x)):f},1);
        const extra=aided.flatMap(a=>Array.from({length:2*RAMP_POINTS+1},(_,i)=>a.from+a.seconds*i/(2*RAMP_POINTS)));
        pressure=[...new Map([...pressure,...extra.map(t=>[t,breathAt(pressure,t)])].map(([t,v])=>[+t.toFixed(6),v])).entries()].sort((a,b)=>a[0]-b[0])
          .filter(([t])=>t>=0&&t<=T).map(([t,v])=>[t,v*helped(t)]);
      }
      // (Each attack from silence buzzed -- its run's first note's from its start, or from its tongue's release where it
      // is tongued, a tongued note's at its release -- its breath driven at its own pitch over its attack (BUZZ), as a
      // tongue's release sets a player's lips buzzing at once: from rest NESS's lips grew from almost nothing, a
      // trombone's 210 Hz 0.2 s before it was within 6 dB of its level; driven so, 50 ms, on its own partial, as loud.
      // Its drive full by its release, let go after its hold; its rate moved only where it drives nothing (tremoloRows).)
      // (A slurred change not driven: driven at its new note's pitch through its change, 0.4 deep, a trombone's slurs
      // were heard nowhere near their notes and its tongued note 155 ms late.)
      const letGo=(at,k)=>{const [depth,hz]=tremoloOf(k);return {at:at+BUZZ.hold,align:'start',seconds:BUZZ.seconds-BUZZ.hold,depth,hz}};
      const targets=[{at:0,depth:BUZZ.depth,hz:items[run.from].target},letGo(into?.released!=null?into.released-w0:0,run.from)];
      for(const c of changes){const [depth,hz]=tremoloOf(c.to);
        if(breath.entries[c.to]==='tongued')targets.push({at:c.released,align:'end',depth:BUZZ.depth,hz:items[c.to].target},letGo(c.released,c.to));
        else targets.push({at:c.at,seconds:c.seconds,depth,hz})}
      const tremolo=tremoloRows(targets);
      // (Everything its player does, at the time it is done: each change as led (anticipation), else as planned.)
      const done=rows=>matrix(playedRows(rows,played,w0)),doneLips=rows=>lipsMatrix(playedRows(rows,played,w0));
      const scoreFile=[`% Musebots: ${model}, NESS brass score, a run of a breath group`,`maxout=0.95;`,`T=${+T.toFixed(6)};`,
        ...['Sr','mu','sigma','H','w'].map(key=>`${key}=${doneLips(lipsRows(key))};`),
        `lip_frequency=${done(times.map(t=>[t,between(lipOf,'lips',t,true)]))};`,`pressure=${done(pressure)};`,
        ...(inwardOf(lipsAt(instrument.lips,lipOf(run.from,0)),1)?INWARD.map(key=>`${key}=${doneLips(times.map(t=>[t,between((k,x)=>inwardOf(lipsAt(instrument.lips,lipOf(k,x)),lipOf(k,x))[key],'lips',t,true)]))};`):[]),
        `vibamp=[0,0];`,`vibfreq=[0,5];`,
        `tremamp=${done(tremolo.depth)};`,`tremfreq=${done(tremolo.hz)};`,
        `noiseamp=${done(times.map(t=>[t,between(k=>items[k].technique.growl?.3*items[k].technique.growl.rough:0,'technique',t)]))};`,
        `valveopening=${done(openRows)};`,`valvevibfreq=${matrix([[0,...valves.position.map(()=>0)]])};`,`valvevibamp=${matrix([[0,...valves.position.map(()=>0)]])};`,
        ...(slid?[`slide=${done(times.map(t=>[t,between(slideAt,'slide',t)]))};`]:[])].join('\n')+'\n';
      return {instrumentFile,scoreFile};
    }
  }
}
// A learned lip curve's held tension: its factor from LEARN_HELD on (the last knot's where it ends before).
const heldFactor=curve=>(curve.find(([x])=>x>=LEARN_HELD)??curve.at(-1))[1];
// A breath's pressure at `t` (s), between its points.
const breathAt=(points,t)=>{if(t<=points[0][0])return points[0][1];for(let i=1;i<points.length;i++)if(t<=points[i][0]){const [a,x]=points[i-1],[b,y]=points[i];return x+(y-x)*(t-a)/((b-a)||1)}return points.at(-1)[1]};

// Every control a run writes moves as transitions.js has it (the owner, 16 October 2026: "making sure nothing changes
// instantaneously"): never a ramp of NESS's own here (test/transitions.test.mjs).
// A value of each note's (`value(k, t)`) at `t`: its run's first note's (`from`), moved across each change in turn
// ([{to, at, seconds}], s) along `kind`'s raised cosine round its middle, never quicker than the kind's least --
// geometric, for a frequency.
export function acrossChanges(value,t,changes,{from,kind,log=false}){
  let v=value(from,t);
  for(const c of changes){const s=transitionSeconds(kind,c.seconds),to=value(c.to,t);
    v=log?Math.exp(ramp(t,c.at-s/2,s,Math.log(v),Math.log(to))):ramp(t,c.at-s/2,s,v,to)}
  return v;
}
// The times a run's rows are written at across its changes, each change's breakpoints (transitions.js RAMP_POINTS) for
// each kind it moves -- NESS joining its rows with straight lines, the raised cosine followed between them.
export const changeTimes=(changes,kinds)=>changes.flatMap(c=>kinds.flatMap(kind=>{const s=transitionSeconds(kind,c.seconds);return rampBreakpoints(c.at-s/2,s,0,1).map(([t])=>t)}));
// A tremolo's rows (NESS's tremamp and tremfreq: its breath driven `depth` deep at `hz`) from its targets [{at, depth,
// hz, seconds?, align?}] in time order, the first its state from the start: each depth moved over a technique's least
// or `seconds` where longer. Its rate moved only where it drives nothing: NESS's tremolo is a sine of its rate times the
// time (1 + tremamp sin(2π tremfreq n k)), its phase never carried, so a rate moved under a depth leaps its phase -- its
// depth taken down to nothing first, its rate moved there (`any`), its depth up again after. Each target's whole change
// round its `at` (`align` 'centre'), begun there ('start') or done by it ('end'); one too near the change before begun
// where that one ends. -> {depth: [[s, v]], hz: [[s, v]]}.
export function tremoloRows(targets){
  const z=transitionSeconds('any');let {depth:d,hz:f}=targets[0],free=0;const depth=[[0,d]],hz=[[0,f]];
  for(const {at,depth:d1,hz:f1,seconds,align='centre'} of targets.slice(1)){
    const s=transitionSeconds('technique',seconds),moves=f1!==f&&d1>0;if(!moves&&d1===d)continue;
    const length=moves?(d>0?s:0)+z+s:s,start=Math.max(free,align==='start'?at:align==='end'?at-length:at-length/2);
    if(!moves){depth.push(...rampBreakpoints(start,s,d,d1));d=d1;free=start+s;continue}
    const silent=start+(d>0?s:0);if(d>0)depth.push(...rampBreakpoints(start,s,d,0));
    hz.push(...rampBreakpoints(silent,z,f,f1));depth.push(...rampBreakpoints(silent+z,s,0,d1));d=d1;f=f1;free=silent+z+s;
  }
  return {depth,hz};
}
// Where a run hands its breath to the next, s: the middle of where its plan's breath (breath.mjs's [[s, pressure]]) is
// least across their change ({at, seconds}) -- a tongued note's stopped air, a legato tongue's dip.
export function leastBreathAt(plan,{at,seconds}){
  const a=at-seconds/2,b=at+seconds/2,ts=[a,...plan.map(([t])=>t).filter(t=>t>a&&t<b),b],vs=ts.map(t=>breathAt(plan,t)),least=Math.min(...vs);
  const low=ts.filter((t,i)=>vs[i]<=least+1e-9);return (low[0]+low.at(-1))/2;
}
// A run's breath within its window [w0, w1] (`plan` breath.mjs's, s in its passage's time), as rows from w0: let in from
// the run before at `into` and let go to the run after at `out` (s: leastBreathAt) -- two simulations meeting, never
// begun or ended at once. Each side of its hand-over its plan's own; beyond it, its breath held at its least there and
// eased from or to nothing over a breath's rise: one move after the plan's own into its least (a tongued note's stopped
// air: nothing, the plan's to its stop and from its release, cut there).
// (Faded over a breath's rise centred on its least, the breath beyond moved under the fade: a run's last note, its air
// stopped, blown again by the next's rise: 10.8 Pa 3.5 ms after its stop, gone 3.5 ms later -- moving 13.6x as quick as
// a tongue stops the air.)
export function runPressure(plan,[w0,w1],{into=null,out=null}={}){
  const S=transitionSeconds('breathRise'),inAt=into==null?null:breathAt(plan,into),outAt=out==null?null:breathAt(plan,out);
  const valueAt=t=>into!=null&&t<into?inAt*eased((t-into+S)/S):out!=null&&t>out?outAt*(1-eased((t-out)/S)):breathAt(plan,t);
  const ts=[w0,w1,...[into,out].filter(x=>x!=null),...plan.map(([t])=>t).filter(t=>(into==null||t>into)&&(out==null||t<out)),
    ...(into==null?[]:rampBreakpoints(into-S,S,0,1).map(([t])=>t)),...(out==null?[]:rampBreakpoints(out,S,0,1).map(([t])=>t))].filter(t=>t>=w0&&t<=w1);
  // (Each read at its own time, its row's time rounded after: read at its rounded time, a run's first row, half a
  // microsecond into its breath's rise, had been let in from 4e-7 of its pressure, not from nothing.)
  const byTime=new Map;for(const t of ts){const key=+t.toFixed(6);if(!byTime.has(key))byTime.set(key,t)}
  return [...byTime].sort((a,b)=>a[0]-b[0]).map(([,t])=>[+(t-w0).toFixed(6),valueAt(t)]);
}
// A run's rows ([[s, ...values]] from its window's start `w0`) at the times its player makes them: each change as led
// (breath.mjs anticipation's `played`), else as planned.
export const playedRows=(rows,played,w0)=>played?rows.map(([t,...v])=>[+(played.played(t+w0)-w0).toFixed(6),...v]):rows;
// (A run's sound died away: its last 10 ms under the smallest step of a 24-bit file at the part's scale, so that it is
// written as zeros, never trimmed or faded to get there; its tail at first and at most, s -- openwind_passages.py's, and
// render/synthesis/tools/audit_renders.py's floor.)
const SILENT=2**-23,FIRST_TAIL=.3,LONGEST_TAIL=8;
const peakOf=(x,a,b)=>{let p=0;for(let i=Math.max(0,a);i<Math.min(x.length,b);i++)p=Math.max(p,Math.abs(x[i]));return p};
// The tail a run's sound needs to die away under SILENT, s: from how fast it decayed over the last half of its tail
// `tail` (its 10 ms peaks, a straight line through their levels in dB); LONGEST_TAIL where it was not decaying.
function decayedBy(audio,rate,tail,scale){
  const w=Math.round(.01*rate),xs=[],ys=[];
  for(let i=Math.max(0,audio.length-Math.round(tail/2*rate));i+w<=audio.length;i+=w){const p=peakOf(audio,i,i+w)*scale;if(p>0){xs.push(i/rate);ys.push(20*Math.log10(p))}}
  if(xs.length<3)return LONGEST_TAIL;
  const mx=xs.reduce((a,b)=>a+b)/xs.length,my=ys.reduce((a,b)=>a+b)/ys.length,slope=xs.reduce((s,x,i)=>s+(x-mx)*(ys[i]-my),0)/xs.reduce((s,x)=>s+(x-mx)**2,0);
  return slope<0?tail+(my+slope*(xs.at(-1)-mx)-20*Math.log10(SILENT))/-slope:LONGEST_TAIL;
}
// (A breath group's tuning: how many simulations of it at most; how long a note's span must be to measure its pitch, s.)
const PASSAGE_TRIES=7,MEASURABLE=.08;
// (How many other fingerings a slurred note its slur fell off may be tuned on in its passage.)
const REFINGERINGS=2,REFINGER_CANDIDATES=3;
// (A legato tongue heard: its dip at least this, dB; held this many times longer each try it is not, never past
// SOFT_MOST s.)
const HALF_HEARD=4,SOFT_STEP=1.6,SOFT_MOST=.1;
// (An attack's buzz: its breath driven at its pitch this deep (a share of its pressure, NESS's tremolo), held this long,
// gone by this, s -- 0.6 for 30 ms brought a trombone's 210 Hz within 6 dB in 50 ms where from rest it took 205; 1 for
// 15 ms, 25 ms. Ours.)
const BUZZ=Object.freeze({depth:.6,hold:.018,seconds:.03});
// (A slur its ear heard fall helped by its breath before another fingering is tried, level by level: [share of its breath
// at the help's height, s] -- eased for a slur down, as a player relaxes into a lower partial, pushed for one up. None
// for now: tried at 0.75 and 0.55 down, 1.2 and 1.4 up, a trumpet's slur down dipped 7 dB, heard tongued, and its push
// up threw a held note 384 cents about; another fingering served better (the legato test, 10 October 2026).)
const SLUR_AIDS=Object.freeze({down:Object.freeze([]),up:Object.freeze([])});
// (A held pitch wandering more than this over its heard span, cents, wavers: its slur fallen into a beating regime.)
const WAVERS=30;
// (A note not heard where it holds, counted in a try's distance from its passage as this many cents off.)
const OFF_TRY=300;
// (A slide's move between two notes, s a semitone, at most `most`: a player's quick move, under a legato tongue as long --
// first to seventh position, six semitones, a tenth of a second; ours, to be replaced by players' measured slide moves.)
const SLIDE=Object.freeze({semitone:.017,most:.12});
// (A lock a slide plays on, its partial's own: held over at least this span of its lips' frequency, its sweep's first run
// on it to its last (scripts/calibrate-ness-brass.mjs `lips`) -- six runs of a x1.015 sweep, as it was set, the designed
// trombone's weak 197 Hz lock three. Counted in runs, it held only at that step: the kept 27 October sweep, at x1.03,
// halved every lock's runs, and the trombone's F4 was left out. Its lips as written, rounded, a ten-thousandth under.)
// strongLock(lock) -> whether it is one.
export const STRONG_LOCK=1.015**5*(1-1e-4);
export const strongLock=lock=>Array.isArray(lock?.lips)&&lock.lips[1]/lock.lips[0]>=STRONG_LOCK;
