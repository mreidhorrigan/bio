/** Exact rational arithmetic. Serialize as decimal integers or "numerator/denominator". */
export function gcd(a, b) {
  a = a < 0n ? -a : a; b = b < 0n ? -b : b;
  while (b) [a, b] = [b, a % b];
  return a;
}
export class Q {
  constructor(n, d = 1n) {
    n = BigInt(n); d = BigInt(d);
    if (!d) throw new RangeError('Zero denominator');
    if (d < 0n) { n = -n; d = -d; }
    const g = gcd(n, d); this.n = n / g; this.d = d / g;
    Object.freeze(this);
  }
  static of(x) {
    if (x instanceof Q) return x;
    if (typeof x === 'bigint') return new Q(x);
    if (Array.isArray(x) && x.length === 2) return new Q(x[0], x[1]);
    if (typeof x === 'number' && (!Number.isFinite(x) || Math.abs(x) > Number.MAX_SAFE_INTEGER))
      throw new RangeError('Nonfinite/unsafe number; use a rational string');
    if (typeof x !== 'string' && typeof x !== 'number') throw new TypeError('Expected rational');
    const s = String(x).trim();
    if (/^[+-]?\d+\/[+-]?\d+$/.test(s)) { const [n, d] = s.split('/'); return new Q(n, d); }
    const m = /^([+-]?)(\d+)(?:\.(\d*))?(?:e([+-]?\d+))?$/i.exec(s);
    if (!m) throw new TypeError(`Invalid rational: ${s}`);
    const power = Number(m[4] ?? 0) - (m[3]?.length ?? 0);
    if (Math.abs(power) > 1000 || s.length > 2000) throw new RangeError('Rational exceeds input limits');
    const n = BigInt((m[1] === '-' ? '-' : '') + m[2] + (m[3] ?? ''));
    return power >= 0 ? new Q(n * 10n ** BigInt(power)) : new Q(n, 10n ** BigInt(-power));
  }
  add(x) { x = Q.of(x); return new Q(this.n * x.d + x.n * this.d, this.d * x.d); }
  sub(x) { x = Q.of(x); return new Q(this.n * x.d - x.n * this.d, this.d * x.d); }
  mul(x) { x = Q.of(x); return new Q(this.n * x.n, this.d * x.d); }
  div(x) { x = Q.of(x); return new Q(this.n * x.d, this.d * x.n); }
  cmp(x) { x = Q.of(x); const v = this.n * x.d - x.n * this.d; return v < 0n ? -1 : v > 0n ? 1 : 0; }
  number() { const v = Number(this.n) / Number(this.d); if (!Number.isFinite(v)) throw new RangeError('Float overflow'); return v; }
  /** Nearest integer; exact halves away from zero. */
  round() {
    const sign = this.n < 0n ? -1n : 1n, n = this.n < 0n ? -this.n : this.n;
    return sign * ((2n * n + this.d) / (2n * this.d));
  }
  toString() { return this.d === 1n ? String(this.n) : `${this.n}/${this.d}`; }
  toJSON() { return this.toString(); }
}
/** Piecewise-constant BPM; beats are quarter-note units, not metrical denominators. */
export class TempoMap {
  constructor(events = [{beat: '0', bpm: '120'}]) {
    if (!Array.isArray(events) || !events.length) throw new TypeError('Empty tempo map');
    this.events = events.map(e => ({beat: Q.of(e.beat), bpm: Q.of(e.bpm)}));
    if (this.events[0].beat.cmp(0)) throw new RangeError('Tempo map must start at beat 0');
    for (let i = 0; i < this.events.length; i++) {
      const e = this.events[i];
      if (e.bpm.cmp(0) <= 0 || (i && e.beat.cmp(this.events[i-1].beat) <= 0))
        throw new RangeError('BPM must be positive; tempo events must increase strictly');
      e.seconds = i ? this.events[i-1].seconds.add(e.beat.sub(this.events[i-1].beat).mul(60).div(this.events[i-1].bpm)) : Q.of(0);
    }
  }
  seconds(beat) {
    beat = Q.of(beat); let i = this.events.length - 1;
    while (i > 0 && this.events[i].beat.cmp(beat) > 0) i--;
    const e = this.events[i]; return e.seconds.add(beat.sub(e.beat).mul(60).div(e.bpm));
  }
  sample(beat, sampleRate) {
    const value = this.seconds(beat).mul(sampleRate).round();
    if (value > BigInt(Number.MAX_SAFE_INTEGER) || value < -BigInt(Number.MAX_SAFE_INTEGER))
      throw new RangeError('Sample index exceeds JavaScript integer range');
    return Number(value);
  }
}
