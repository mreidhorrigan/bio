import {finite,noteHzAt} from './pitch.mjs';
const num=n=>{finite(n,'DSP numeric literal');return Number(n).toPrecision(16);};
const str=s=>JSON.stringify(String(s));
// Models that sound one pitch a note -- a piano's strings tuned as they are struck, a membrane, a bore of fixed length
// -- and so follow no pitch curve within it (physical-events.mjs holds such a note at its held pitch, reported).
// Each wind and brass instrument's physical model, offline by default (the owner, 8 October 2026: "switch winds and
// brass to the physical model offline default"): the woodwinds on OpenWInD, the brass on NESS.
export const WIND_MODELS=Object.freeze({flute:Object.freeze({backend:'openwind',model:'flute'}),oboe:Object.freeze({backend:'openwind',model:'oboe'}),
  clarinet:Object.freeze({backend:'openwind',model:'clarinet'}),bassoon:Object.freeze({backend:'openwind',model:'bassoon'}),
  alto:Object.freeze({backend:'openwind',model:'alto-flute'}),
  ...Object.fromEntries(['alto-flute','piccolo','e-flat-clarinet','bass-clarinet','english-horn','contrabassoon','soprano-saxophone','alto-saxophone','tenor-saxophone','baritone-saxophone'].map(model=>[model,Object.freeze({backend:'openwind',model})])),
  horn:Object.freeze({backend:'ness',model:'horn'}),trumpet:Object.freeze({backend:'ness',model:'trumpet'}),
  trombone:Object.freeze({backend:'ness',model:'trombone'}),tuba:Object.freeze({backend:'ness',model:'tuba'})});
// The instruments whose model plays offline unless a spec says otherwise: every one. (The flute's had been left out
// while OpenWInD's flute, on a generic flanged opening, could not sound a quarter of its compass; on the recorder's
// window and its measured jet it speaks all 40 of its notes: openwind_worker.py WOODWINDS.)
export const WIND_MODELS_BY_DEFAULT=Object.freeze(Object.keys(WIND_MODELS));
// (OpenWInD's woodwinds: openwind_worker.py WOODWINDS.)
export const OPENWIND_WOODWINDS=Object.freeze(['clarinet','oboe','bassoon','flute','alto-flute','piccolo','e-flat-clarinet','bass-clarinet','english-horn','contrabassoon','soprano-saxophone','alto-saxophone','tenor-saxophone','baritone-saxophone']);
// (Where each woodwind's player's tongue touches: a reed player's its reed, holding it shut; a flutist's stops its air --
// breath.mjs passageBreath `tongue`.)
export const WOODWIND_TONGUES=Object.freeze({clarinet:'reed',oboe:'reed',bassoon:'reed',flute:'air','alto-flute':'air',piccolo:'air',...Object.fromEntries(['e-flat-clarinet','bass-clarinet','english-horn','contrabassoon','soprano-saxophone','alto-saxophone','tenor-saxophone','baritone-saxophone'].map(model=>[model,'reed']))});
// (OpenWInD's reeds, which NESS plays too, as OpenWInD's player plays them (workers/ness_woodwind.py): their reed NESS's
// lips' inward mode, a double reed's scaled one by OpenWInD's own conversion with its slit as measured. Its flutes' jet
// NESS has not.)
export const NESS_WOODWINDS=Object.freeze(['clarinet','e-flat-clarinet','bass-clarinet','soprano-saxophone','alto-saxophone','tenor-saxophone','baritone-saxophone',
  'oboe','english-horn','bassoon','contrabassoon']);
export const FIXED_PITCH=Object.freeze({supercollider:Object.freeze(['piano','membrane']),openwind:OPENWIND_WOODWINDS,ness:NESS_WOODWINDS});
export const followsPitch=(backend,model)=>!(FIXED_PITCH[backend]??[]).includes(model);
// The models of one pitch a note whose player's vibrato is in its breath (a woodwind's: its diaphragm's and throat's): its
// curve kept as the breath's sway (openwind-passages.mjs), never dropped.
export const BREATHES_VIBRATO=Object.freeze({openwind:OPENWIND_WOODWINDS,ness:NESS_WOODWINDS});
export const breathesVibrato=(backend,model)=>(BREATHES_VIBRATO[backend]??[]).includes(model);
// The extended techniques each model realizes as forcings of its own (public/shared/performers/techniques.js): OpenWInD's
// reed takes a hummed or growled voice and a fluttering tongue in its mouth pressure, and a measured cross-fingering on its
// body with tone holes (openwind_worker.py). Elsewhere a note's technique is reported, not followed.
export const TECHNIQUES_REALIZED=Object.freeze({openwind:Object.freeze(Object.fromEntries(OPENWIND_WOODWINDS.map(model=>[model,Object.freeze(['hum','growl','flutter','multiphonic'])]))),
  // (And NESS's brass: the same three in its mouth-pressure tremolo and noise, and a mute in its bore: ness.mjs.)
  ness:Object.freeze(Object.fromEntries(['trumpet','trombone','horn','tuba'].map(model=>[model,Object.freeze(['hum','growl','flutter','mute'])])))});
export const realizes=(backend,model,technique)=>(TECHNIQUES_REALIZED[backend]?.[model]??[]).includes(technique);
// The backends that sound each note at its own level (a note's levelDb: its held part's RMS, dBFS -- its instrument's
// measured sound power at its velocity and pitch, public/shared/performers/sound-power.js), a part's level then its
// notes' own and no calibration's: OpenWInD's woodwinds and NESS's brass (openwind_worker.py, ness.mjs).
export const LEVELLED=Object.freeze(['openwind','ness']);
export function validatePhysicalControls(part,backend) {
  const model=part.physical?.model??(backend==='supercollider'?'plucked':'clarinet');
  const controls=backend==='supercollider'?{bowed:['release','bowForce','bowPosition'],piano:['release','unisonDetune'],plucked:['release','decay'],membrane:['release','tension','calibratedHz','calibrationSampleRate']}:
    backend==='csound'?{clarinet:[],flute:[],brass:[],bowed:[]}:backend==='openwind'?Object.fromEntries(OPENWIND_WOODWINDS.map(model=>[model,['pitchPolicy','pitchToleranceCents','boreRadius','mouthPressure','jetVelocity','temperature','reedOpening','reedMass','reedPulsation','reedDissipation','attack','release','outputScale','excitationAudio','body','playing']])):null;
  if(!controls||!Object.hasOwn(controls,model))throw new Error(`Unsupported ${backend} model ${model}`);
  for(const key of Object.keys(part.physical??{}))if(key!=='model'&&!controls[model].includes(key))
    throw new Error(`${part.id}: ${backend} does not implement physical control ${key}`);
  if(part.articulations?.length||Object.keys(part.expression??{}).length)throw new Error(`${part.id}: ${backend} does not implement part articulations or expression`);
  for(const note of part.notes){
    if(note.articulations?.length||Object.keys(note.expression??{}).length||Object.keys(note.physical??{}).length)
      throw new Error(`${note.id}: ${backend} does not implement note articulations, expression or physical controls`);
  }
  return model;
}
function validateRate(sampleRate) {
  if(!Number.isSafeInteger(sampleRate)||sampleRate<8000||sampleRate>192000)throw new RangeError('sampleRate 8000..192000');
}
export function frequencySegments(n) {
  const times=[n.startSeconds,...n.pitchCurve.map(k=>k.seconds).filter(t=>t>n.startSeconds&&t<n.endSeconds),n.endSeconds];
  return {hz:times.map(t=>noteHzAt(n,t)),durations:times.slice(1).map((t,i)=>t-times[i])};
}
/** Source generator. The resulting program needs sclang/scsynth and the declared plugins. */
export function superColliderProgram(part,sampleRate,{outputPath,oscPath,blockSize=64,tailSeconds=2,pluginPaths}={}) {
  if(part.kind==='choir')throw new Error('Physical instrument worker cannot pronounce lyrics');
  const model=validatePhysicalControls(part,'supercollider');
  validateRate(sampleRate);
  if(!outputPath||!oscPath)throw new Error('SC outputPath and oscPath required');
  if(pluginPaths!==undefined&&(!Array.isArray(pluginPaths)||!pluginPaths.length||pluginPaths.some(path=>typeof path!=='string'||!path)))
    throw new Error('SC pluginPaths must list the core and additional UGen directories');
  if(!Number.isInteger(blockSize)||blockSize<1||blockSize>1024||(blockSize&(blockSize-1)))throw new Error('SC blockSize must be a power of two');
  finite(tailSeconds,'tail',0,30);
  const release=finite(part.physical?.release??0.2,'release',0.001,30),renderTail=Math.max(tailSeconds,release);
  const lead=0.1,lines=[],events=[],defs=[];
  const required=model==='bowed'?['DWGBowed','DWGSoundBoard']:model==='piano'?['OteyPianoStrings','OteySoundBoard']:model==='membrane'?['MembraneCircle']:[];
  for(const c of required)lines.push(`if(${str(c)}.asSymbol.asClass.isNil) { ${str('Missing required UGen class '+c)}.postln; 1.exit; };`);
  if(model==='piano'){
    defs.push(`SynthDef(\\mb_body, { var sig; sig = "OteySoundBoard".asSymbol.asClass.perform(\\ar, In.ar(16, 1)); Out.ar(0, Mix(sig) * 0.2); })`);
    events.push('[0.05, [\\s_new, \\mb_body, 900, 1, 1]]');
  }
  part.notes.forEach((n,i)=>{
    const {hz,durations}=frequencySegments(n),name=`mb_${i}`,dur=n.endSeconds-n.startSeconds;
    if(dur<0.001)throw new Error('SC fixture requires notes of at least 1 ms');
    const gate=`EnvGen.ar(Env([1, 1, 0], [${num(dur)}, 0.0001]))`;
    const freq=`EnvGen.ar(Env([${hz.map(num)}], [${durations.map(num)}], \\exp))`;
    let signal;
    if(model==='bowed')signal=`"DWGBowed".asSymbol.asClass.perform(\\ar, freq, ${num(n.velocity)}, ${num(finite(part.physical?.bowForce??1,'bowForce',0.01,10))}, gate, ${num(finite(part.physical?.bowPosition??0.14,'bowPosition',0.001,0.999))}, ${num(release)}); sig = "DWGSoundBoard".asSymbol.asClass.perform(\\ar, sig) * 0.1`;
    if(model==='piano') {
      if(hz.some(f=>Math.abs(f-hz[0])>1e-8))throw new Error('OteyPianoStrings tunes only at initialization; continuous pitch bends are unsupported');
      const detune=finite(part.physical?.unisonDetune??0,'unisonDetune',0,0.02);
      signal=`"OteyPianoStrings".asSymbol.asClass.performList(\\ar, [${[hz[0],n.velocity,0,0.35,2,4,8,1,0.07,1.4,-4,4,1,1,1,0,1,0.2,1,1,0.142,1,detune,1].map(num)}])`;
    }
    if(model==='plucked')signal=`Pluck.ar(WhiteNoise.ar(${num(n.velocity)}), Impulse.ar(0), ${num(1/Math.min(...hz)*1.1)}, freq.reciprocal, ${num(finite(part.physical?.decay??3,'decay',0.01,60))}, 0.3)`;
    if(model==='membrane') {
      if(hz.some(f=>Math.abs(f-hz[0])>1e-8))throw new Error('MembraneCircle tension is not an F0 controller: bends require calibration');
      if(part.physical?.tension===undefined)throw new Error('MembraneCircle requires calibrated tension; refusing to call nominal Hz a realized pitch');
      if(part.physical.calibrationSampleRate!==sampleRate || !(part.physical.calibratedHz>0) || Math.abs(1200*Math.log2(hz[0]/part.physical.calibratedHz))>0.01)
        throw new Error('Membrane pitch needs a matching measured calibratedHz and calibrationSampleRate; no guessed tension-to-Hz mapping');
      signal=`"MembraneCircle".asSymbol.asClass.perform(\\ar, Impulse.ar(0) * ${num(n.velocity)}, ${num(finite(part.physical.tension,'tension',0.001,0.5))}, 0.999)`;
    }
    const attack=Math.min(0.003,dur/4);
    defs.push(`SynthDef(\\${name}, { var freq, gate, sig, env; RandSeed.ir(1, ${12345+i}); freq = ${freq}; gate = ${gate}; sig = ${signal}; env = EnvGen.ar(Env([0, 1, 1, 0], [${num(attack)}, ${num(dur-attack)}, ${num(release)}]), doneAction: 2); OffsetOut.ar(${model==='piano'?16:0}, Mix(sig) * env * 0.5); })`);
    events.push(`[${num(n.startSeconds+lead)}, [\\s_new, \\${name}, ${1000+i}, 0, 1]]`);
  });
  // All definitions arrive before nodes; the initial 100 ms is retained as signed stem pre-roll.
  const end=Math.max(...part.notes.map(n=>n.endSeconds))+lead+renderTail;
  return {originSeconds:-lead,source:`(\nvar defs, events, opts, score;\ntry {\n${lines.join('\n')}\nTempoClock.default.tempo = 1;\ndefs = [${defs.join(',\n')}];\nevents = List.new;\ndefs.do { |d| events.add([0.0, [\\d_recv, d.asBytes]]); };\n[${events.join(',\n')}].do { |e| events.add(e); };\nevents.add([${num(end)}, [\\c_set, 0, 0]]);\nopts = ServerOptions.new.numOutputBusChannels_(1).numInputBusChannels_(0).blockSize_(${blockSize}).memSize_(262144).maxNodes_(${Math.max(2048,part.notes.length+128)}).maxSynthDefs_(${2**Math.ceil(Math.log2(Math.max(2048,part.notes.length+128)))});\n${pluginPaths?`opts.ugenPluginsPath_([${pluginPaths.map(str).join(',')}]);\n`:''}score = Score(events.asArray.sort { |a, b| a[0] < b[0] });\nscore.recordNRT(oscFilePath: ${str(oscPath)}, outputFilePath: ${str(outputPath)}, sampleRate: ${sampleRate}, headerFormat: "WAV", sampleFormat: "float", options: opts, duration: ${num(end)}, action: { |exitCode| if(exitCode == 0) { "MUSEBOTS_RENDER_COMPLETE".postln; 0.exit; } { exitCode.exit; }; });\n} { |error| error.reportError; 1.exit; };\n)\n`,
    diagnostics:{backend:'supercollider',model,fidelity:'uncalibrated-prototype',blockSize,tailSeconds:renderTail,notePlacement:'OffsetOut',pitchEnvelope:model==='piano'?'constant at initialization':model==='membrane'?'fixed calibrated tension':'audio-rate graph; UGen control-read rate requires measurement',requirements:required,
      warning:model==='membrane'?'Pitch follows explicit tension calibration, not note frequency':null}};
}
export function csoundProgram(part,sampleRate,{ksmps=1,tailSeconds=0.25}={}) {
  if(part.kind==='choir')throw new Error('Csound physical instrument presets do not pronounce lyrics');
  const model=validatePhysicalControls(part,'csound');
  validateRate(sampleRate);finite(tailSeconds,'tail',0,30);
  if(!Number.isInteger(ksmps)||ksmps<1||ksmps>1024)throw new Error('Invalid ksmps');
  const release=0.03,renderTail=Math.max(tailSeconds,release);
  const instruments=[],score=['f 1 0 16384 10 1'];
  part.notes.forEach((n,i)=>{
    const {hz,durations}=frequencySegments(n),dur=n.endSeconds-n.startSeconds,attack=Math.min(0.02,dur/4);
    const curve=[num(hz[0])];durations.forEach((d,k)=>curve.push(num(d),num(hz[k+1])));
    curve.push(num(release),num(hz.at(-1)));const min=num(Math.max(0.1,Math.min(...hz)*0.98)),amp=num(n.velocity*0.25);
    let op;
    if(model==='clarinet')op=`wgclar ${amp}, kfreq, -0.3, ${num(attack)}, ${num(release)}, 0.1, 0, 0, 1, ${min}`;
    if(model==='flute')op=`wgflute ${amp}, kfreq, 0.32, ${num(attack)}, ${num(release)}, 0.1, 0, 0, 1, ${min}`;
    if(model==='brass')op=`wgbrass ${amp}, kfreq, 0.4, ${num(attack)}, 0, 0, 1, ${min}`;
    if(model==='bowed')op=`wgbow ${amp}, kfreq, 3, 0.127236, 0, 0, 1, ${min}`;
    instruments.push(`instr ${i+1}\nkfreq expseg ${curve.join(', ')}\naenv linseg 0, ${num(attack)}, 1, ${num(dur-attack)}, 1, ${num(release)}, 0\nasig ${op}\nout asig * aenv\nendin`);
    score.push(`i ${i+1} ${num(n.startSeconds)} ${num(dur+release)}`);
  });
  const end=Math.max(...part.notes.map(n=>n.endSeconds))+renderTail;
  return {originSeconds:0,source:`<CsoundSynthesizer>\n<CsOptions>\n</CsOptions>\n<CsInstruments>\nsr=${sampleRate}\nksmps=${ksmps}\nnchnls=1\n0dbfs=1\nseed 12345\n${instruments.join('\n')}\n</CsInstruments>\n<CsScore>\n${score.join('\n')}\nf 0 ${num(end)}\ne\n</CsScore>\n</CsoundSynthesizer>\n`,
    diagnostics:{backend:'csound',model,controlGridSamples:ksmps,tailSeconds:renderTail,fidelity:'uncalibrated-waveguide-prototype',warning:model==='brass'?'Upstream wgbrass documentation reports quality/control limitations':null}};
}
