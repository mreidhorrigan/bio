// A brass player's breath as players were measured to blow (render/synthesis/brass-lips-targets.json): the mouth's
// pressure at pp and at ff as lines in the note's frequency, both logarithmic, through every brass player measured at both
// -- Fletcher & Tarnopolsky's professional trumpeter (1999, doi:10.1121/1.426276: each note's least pressure and its
// fortissimo limit, F3 to C6) and Bouhuys's tuba and C trumpet players (1965, doi:10.1121/1.1909350: each note blown pp
// and ff) -- the dynamics between them along the same line in velocity as their measured loudness is (sound-power.js
// soundPowerDb, between the velocities pp and ff are written at). One line for every brass instrument: the trumpeter's
// and the tuba player's pressures lie on it within a factor of 1.2 at pp and 1.3 at ff (a threshold "very nearly
// proportional to the frequency of the note being played", Fletcher & Tarnopolsky, its players within a factor of 2), so
// that an instrument nobody measured -- the trombone, the horn -- is blown as the brass players measured blow at its
// pitch: borrowed, and said so. Never past the most pressure measured in a brass player's mouth (MOST).
import TARGETS from '../brass-lips-targets.json' with {type:'json'};
import {MEASURED_AT} from '../../../public/shared/performers/sound-power.js';

// (Each player's notes at pp and ff: [Hz, Pa].)
function measured(){
  const pp=[],ff=[],{trumpet,tuba}=TARGETS;
  for(const n of trumpet.notes){pp.push([n.hz,n.least.mouthPressure]);ff.push([n.hz,n.forte.mouthPressure])}
  for(const n of tuba.measured.notes){pp.push([n.hz,n.pp.mouthPressure]);ff.push([n.hz,n.ff.mouthPressure])}
  const c=trumpet.cTrumpet;pp.push([c.hz,c.pp.mouthPressure]);ff.push([c.hz,c.ff.mouthPressure]);
  return {pp,ff};
}
// (A least-squares line through [log Hz, log Pa] -> {at, slope}: log Pa = at + slope log Hz; and its scatter, the
// factor its points lie within of it in rms.)
function line(points){
  const x=points.map(([hz])=>Math.log(hz)),y=points.map(([,pa])=>Math.log(pa)),n=x.length;
  const mx=x.reduce((s,v)=>s+v,0)/n,my=y.reduce((s,v)=>s+v,0)/n;
  let sxy=0,sxx=0;for(let k=0;k<n;k++){sxy+=(x[k]-mx)*(y[k]-my);sxx+=(x[k]-mx)**2}
  const slope=sxy/sxx,at=my-slope*mx;
  const rms=Math.sqrt(x.reduce((s,v,k)=>s+(y[k]-at-slope*v)**2,0)/n);
  return Object.freeze({at,slope,scatter:Math.exp(rms),points:points.length});
}
const {pp,ff}=measured();
export const PLAYERS_BREATH=Object.freeze({pp:line(pp),ff:line(ff)});
// How hard a player blows pp and ff against the note's own threshold, as the players measured at both blow: the
// trumpeter's least and forte pressures against his thresholds (Fletcher & Tarnopolsky), the tuba and C trumpet
// players' ff against their pp (Bouhuys, whose pp are their thresholds, as Campbell, Gilbert & Myers 2021 read them) --
// {pp, ff}: each {ratio, logSd, points}, their ratios' geometric mean and spread -- so that a model whose thresholds are
// not its players' is blown as they blow theirs -- its pp at its own threshold (tools/brass_player.py's prior; its ff
// the pressure players blow at ff, which drives the bore whatever its threshold: PLAYERS_BREATH).
function span(ratios){
  const l=ratios.map(Math.log),m=l.reduce((s,v)=>s+v,0)/l.length;
  return Object.freeze({ratio:Math.exp(m),logSd:Math.sqrt(l.reduce((s,v)=>s+(v-m)**2,0)/(l.length-1)),points:l.length});
}
export const PLAYERS_SPAN=Object.freeze({
  pp:span(TARGETS.trumpet.notes.map(n=>n.least.mouthPressure/n.threshold)),
  ff:span([...TARGETS.trumpet.notes.map(n=>n.forte.mouthPressure/n.threshold),...TARGETS.tuba.measured.notes.map(n=>n.ff.mouthPressure/n.pp.mouthPressure),
    TARGETS.trumpet.cTrumpet.ff.mouthPressure/TARGETS.trumpet.cTrumpet.pp.mouthPressure]),
});
// (The most: "Mean pressures greater than 20 kPa have been measured in the mouths of trumpet players" (Schwab &
// Schultze-Florey 2004); Fletcher & Tarnopolsky's trumpeter "about 25 kPa".)
export const MOST=TARGETS.trumpet.most.mouthPressure;

// The mouth's pressure (Pa) a brass player blows a note of `hz` at `velocity` with.
export function playersBreath(hz,velocity){
  const at=d=>PLAYERS_BREATH[d].at+PLAYERS_BREATH[d].slope*Math.log(hz);
  const t=(velocity-MEASURED_AT.pp)/(MEASURED_AT.ff-MEASURED_AT.pp);
  return Math.min(MOST,Math.exp(at('pp')+(at('ff')-at('pp'))*t));
}
