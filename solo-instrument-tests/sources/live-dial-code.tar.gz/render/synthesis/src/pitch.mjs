import {Q} from './rational.mjs';
export function finite(x, name, lo = -Infinity, hi = Infinity) {
  if (typeof x !== 'number' || !Number.isFinite(x) || x < lo || x > hi)
    throw new RangeError(`${name}: expected a finite number in [${lo}, ${hi}]`);
  return x;
}
export function hzToMidi(hz) { return 69 + 12 * Math.log2(finite(hz, 'Hz', Number.MIN_VALUE) / 440); }
export function midiToHz(note) { return 440 * 2 ** ((finite(note, 'MIDI pitch') - 69) / 12); }
export function centsBetween(actual, intended) { return 1200 * Math.log2(finite(actual, 'actual Hz', Number.MIN_VALUE) / finite(intended, 'target Hz', Number.MIN_VALUE)); }
/** Tuning identity stays in the score; only the DSP boundary evaluates it numerically. */
export function pitchHz(pitch) {
  if (!pitch || typeof pitch !== 'object') throw new TypeError('Missing pitch definition');
  let hz;
  if (Object.hasOwn(pitch, 'hz')) hz = pitch.hz;
  else {
    const ref = finite(pitch.referenceHz, 'referenceHz', Number.MIN_VALUE);
    if (pitch.ratio !== undefined) hz = ref * Q.of(pitch.ratio).number();
    else if (pitch.edo !== undefined) {
      if (!Number.isSafeInteger(pitch.edo) || pitch.edo < 1) throw new RangeError('edo must be a positive integer');
      const period = pitch.period === undefined ? 2 : Q.of(pitch.period).number();
      finite(period, 'period', Number.MIN_VALUE);
      hz = ref * period ** (Q.of(pitch.step).number() / pitch.edo);
    } else throw new TypeError('Pitch needs hz, ratio, or edo/step');
  }
  return finite(hz, 'result Hz', Number.MIN_VALUE, 1e7);
}
export function curveAt(knots, seconds) {
  if (!knots?.length) return 0;
  if (seconds <= knots[0].seconds) return knots[0].cents;
  for (let i = 1; i < knots.length; i++) {
    if (seconds < knots[i].seconds) {
      const a = knots[i-1], b = knots[i], w = (seconds - a.seconds) / (b.seconds-a.seconds);
      return a.cents + w * (b.cents-a.cents);
    }
  }
  return knots.at(-1).cents;
}
export function noteHzAt(note, absoluteSeconds) {
  return note.baseHz * 2 ** (curveAt(note.pitchCurve, absoluteSeconds) / 1200);
}
/** Complete, non-overlapping notes; hold nearest edge through silence by default.
 * DiffSinger banks generally expect continuous F0. Voicing is a separate control.
 */
export function f0At(notes, seconds, gapPolicy = 'hold') {
  if (!notes.length) throw new RangeError('No notes for F0');
  let previous = null;
  for (const n of notes) {
    if (seconds < n.startSeconds) {
      if (gapPolicy === 'zero') return 0;
      return previous ? noteHzAt(previous, previous.endSeconds) : noteHzAt(n, n.startSeconds);
    }
    if (seconds < n.endSeconds) return noteHzAt(n, seconds);
    previous = n;
  }
  return gapPolicy === 'zero' ? 0 : noteHzAt(previous, previous.endSeconds);
}
export function sampleF0(notes, originSeconds, frames, frameSeconds, gapPolicy = 'hold') {
  if (!Number.isSafeInteger(frames) || frames < 1 || frames > 1e7) throw new RangeError('Invalid frame count');
  finite(frameSeconds, 'frameSeconds', Number.MIN_VALUE);
  return Float32Array.from({length: frames}, (_, i) => f0At(notes, originSeconds + i * frameSeconds, gapPolicy));
}
