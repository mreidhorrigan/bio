// An aerophone player's breath, for the physical models (NESS's brass, OpenWInD's woodwinds): a way of phrasing, as a
// string player's bow is (the owner, 9 October 2026: "this needs to operate at the multi-note level, because breath is a
// way of phrasing"; "it is closely related to bowing, for strings"; "The situation this needs to be able to model is
// continuous breath while fingering changes, with the possibility of breath continuous adjustment to facilitate the
// changes of pitch"). And on Op. 3.34: "Trumpet tremoloes sound like each note in the tremolo is reattacked"; its tuba's
// "explosive low booms ... louder than a bass drum".
//
// A breath group is what one breath carries, as a bow stroke is what one bow carries: the notes from a breath to the
// next (the player's breaths are its seat's, bots/lib/modules/wind-seat.js: a rest of at least BREATH.breathGap between
// two notes is one). Each is simulated whole, as one run of its model (ness.mjs, openwind_worker.py), never note by
// note: its breath goes on through it, its fingers (valves, lips) changing under it.
//   - Its first note's breath rises over its attack (its player's: articulation.js, the seat's tongue at its dynamic, a
//     raised cosine), begun as early as its tone takes to speak (`ahead`), and held there until its onset -- the rise
//     its tone was heard to speak after, never stretched over the time it takes (a breath risen over a whole second had
//     spoken later than the second it was begun early by).
//   - A slurred note is reached under the breath: the fingering changes over joinSeconds (a few of the lower note's
//     periods) round its onset, and the breath moves there from the pressure the last note was tuned at to its own --
//     the breath adjusting to help the change of pitch, as a player supports a slur.
//   - A tongued note stops the air at the end of the one before (TONGUE stop, its tongue touching), the fingering
//     changing while it is stopped, and lets it go at its onset, over its attack: the breath held behind the tongue, its
//     pressure where it was. A reed player's tongue (`tongue: 'reed'`) touches its reed instead, holding it shut: its
//     breath held behind it, moved to the next note's while it is shut, and its reed let go at the onset (`tongues`,
//     each one's span, for its model to shut its reed over) -- as clarinettists tongue: "After tongue release ... the
//     changing aperture past the reed rapidly changes the airflow", and "tongue action can initiate sustained notes at
//     low pressure" (Li, Almeida, Smith & Wolfe 2016, "The effect of blowing pressure, lip force and tonguing on
//     transients: A study using a clarinet-playing machine", JASA 140(2), 1089-1100, doi:10.1121/1.4960594). Its first
//     note's breath rises behind its tongue too, let go as it has risen.
//   - A note slurred across a change its instrument cannot make under the breath (a trombone's slide moving: its
//     simulation begun again, ness.mjs) is legato-tongued, as trombonists play it: the air dipping, never stopping.
//   - So is a note slurred to the pitch it follows (within BREATH.samePitch): a repeated pitch has no change of fingering
//     or lips to be heard by, so its player half-attacks it with the tongue (the owner, 10 October 2026: "For brass to
//     slur repeated notes is a bit of a weird technique, almost like half-attacking the notes"); slurred as any other, it
//     had run into the note before, the two heard as one (Op. 3.35).
//   - Each note swells and ebbs with its pressure curve (its player's), at most BREATH.swell either side of its tuned
//     pressure: a breath much harder or softer moves the pitch the lips or reed lock to, or stops them (the tuba's B2 at
//     1.3 times its breath fell silent).
//   - Its last note's breath falls over its release.
//   - Each change begun as much earlier as its instrument takes to answer it (`anticipation`, learned by ear in each
//     group: ness.mjs, openwind_passages.py), as a player begins a slow instrument's change early so that its note is
//     heard on its beat -- each change's own window (its slur's fingers and breath, its tongue's stop and release, its
//     legato tongue's dip) moved whole, the time between two changes taking up the difference. The owner, 10 October
//     2026, of Op. 3.35: "the timing ... seemed too ragged"; "a difference that wide requires a rubato problem" -- its
//     parts written together had been heard 160 ms apart at the median and 620 at most, though they asked for 15: each
//     change had been made on its beat, and each note arrived as late as its model took to answer, a tuba's slur 0.2 s,
//     a trombone's slide moved under a legato tongue 0.25 s, a trumpet's tongued note 0.05 to 0.1.
// A tone the tuning accepts speaks (speakingDb): its tone at least BREATH.speaksDb over the thump of the probe's breath
// -- the flow a breath sets going through the instrument, heard from its bell, the quicker the louder. The trumpet's and
// trombone's documented lips are 40 to 59 dB over it, the horn's 19 to 25; Op. 3.34's tuba B2, its lips moved 6 % off
// their lock to tune it, -24 dB, its held level lifted 22 times to its sound power, its thumps with it: its booms.
import {WIND_LINE} from '../../../public/shared/performers/wind-line.js';
import {transition,transitionSeconds,ramp,rampBreakpoints} from '../../../public/shared/performers/transitions.js';

export const BREATH=Object.freeze({
  // (The tuning probe's breath rise, s: the standard a tone's speaking is measured against.)
  probeRise:.05,
  // (The quickest a breath rises or falls, s: transitions.js's, one definition for every engine.)
  leastRise:transition('breathRise').least,leastFall:transition('breathFall').least,
  // (A tongue's stop, s: the air cut before a tongued note, from the note before's end or this long before its onset,
  // whichever is earlier -- cut only at the note's end, the stop had been as short as the gap, two milliseconds where
  // none was, and Op. 3.35's tongued notes had dipped 1 to 3 dB, attacks the owner could not tell from notes going on --
  // its air falling over tongueFall (transitions.js tongueStop); a legato tongue's ("da", a trombone's slur across a change
  // of position): how long its dip and how far the air falls in it, as a share.)
  tongueStop:.035,tongueFall:transition('tongueStop').least,softSeconds:.03,softDip:.55,
  // (A slurred note this near the pitch it follows, cents: the same pitch, legato-tongued.)
  samePitch:10,
  swell:.08,
  // (The least a tone speaks over its probe's thump, dB: Op. 3.34's booming tuba B2 was 24 under; a horn's G3 on its
  // own valves, a tone players hold, 19 over.)
  speaksDb:14,
  // (A slur's change of fingering: eight periods of the lower note, within these bounds, s; and the breath's move between
  // its two notes' pressures, slower than the fingers, s. NESS's trumpet slurred from open to its first and second valves
  // burst 7 dB over its held tone in the high band at 12 ms, as a tongued attack, and 2.5 dB at 25 ms, dipping 4 dB
  // there; a breath held steady across it took 2.6 dB more off -- Op. 3.35's slurs had all sounded reattacked, the owner,
  // 10 October 2026: "I'm not hearing any slurred notes - all seem reattacked".)
  joinPeriods:8,join:Object.freeze([.02,.06]),slurBreath:.08,
  // (A rest at least this long, s, is a breath: the seat's catch breath (wind-seat.js BREATH.catch) less the release of the
  // note it is taken from (at most 80 ms) and a margin -- at the catch breath's whole length, a released note's rest fell
  // short of it and breath groups ran on through their breaths.)
  breathGap:WIND_LINE.breathRest-.05-.1,
});
// (A change of fingering: its keys or valves and its lips moving together, no quicker than the slowest of them.)
const fingering=asked=>Math.max(...['key','valve','lips'].map(kind=>transitionSeconds(kind,asked)));
// (Every kind a change moves across its middle in any engine -- its keys or valves, its lips, a trombone's slide, a
// technique begun or ended with its note, a pitch's own modulation (ness.mjs acrossChanges, the workers') -- each over
// the change's length or its own least, whichever is longer.)
const CHANGING=Object.freeze(['key','valve','lips','slide','technique','modulation']);

// The probe's breath, as [[s, share]]: risen over probeRise, held to `seconds`, let go over leastFall -- each along
// transitions.js's raised cosine, as breakpoints NESS joins with straight lines.
export function probeBreath(seconds){
  const points=[...rampBreakpoints(0,transitionSeconds('breathRise',BREATH.probeRise),0,1),[seconds,1],...rampBreakpoints(seconds,transitionSeconds('breathFall'),1,0).slice(1)];
  return points.map(([t,v])=>[+t.toFixed(6),+v.toFixed(5)]);
}
// A slur's change of fingering, s: joinPeriods of the lower of its two notes, within BREATH.join.
export const joinSeconds=(hzA,hzB)=>Math.max(BREATH.join[0],Math.min(BREATH.join[1],BREATH.joinPeriods/Math.min(hzA,hzB)));

// A part's breath groups (its notes sorted by onset, each {startSeconds, endSeconds, slurred?, technique?}): its notes
// from one breath to the next -- a rest of at least `gap` between two, or a mute put in or taken out (a breath's work) --
// as [{notes: [indices], start, end}].
export function breathGroups(notes,{gap=BREATH.breathGap}={}){
  const groups=[];let last=null;
  notes.forEach((note,index)=>{
    const mute=note.technique?.mute?.kind??null,previous=last?notes[last.notes.at(-1)]:null;
    if(!last||note.startSeconds-previous.endSeconds>=gap||mute!==(previous.technique?.mute?.kind??null)){last={notes:[index],start:note.startSeconds,end:note.endSeconds};groups.push(last)}
    else{last.notes.push(index);last.end=Math.max(last.end,note.endSeconds)}
  });
  return groups;
}

// A breath group's breath and changes, from `origin` (s: its simulation's start). `notes` its notes in order (each with
// startSeconds, endSeconds, slurred?, source.performance: attackSeconds, releaseSeconds, pressureCurve), `pressures` the
// pressure each was tuned at, `hz` each one's pitch, `softTongues` how long each legato tongue lasts (its ear's, where
// its instrument rings through BREATH.softSeconds' dip), `ahead` how early its first note's breath begins (s before its
// onset), `soft` the notes its model legato-tongues whatever their player says (a Set: two of NESS's simulations meeting,
// ness.mjs), `moves` how long each change's own mechanism takes where longer than a key's (a Map, s: a trombone's slide
// moving, under a legato tongue where its player tongues it, else under the breath), `tongue` where its
// player's tongue touches ('air', its air stopped; 'reed', its reed held shut). -> {pressure: [[s, pressure]], changes:
// [{to (index), at, seconds, released?, span}] (each fingering change: its middle and length; a tongued note's, when its
// tongue lets its air go; `span` [from, to], what its player moves for it -- its anticipation's to move whole), entries: ['first' | 'slurred' | 'soft' |
// 'tongued'], end (s: its breath let go), onsets (s: each note's), firstRisen (s: its first note's onset and rise -- its
// attack, never moved by `anticipation`), tongues (a reed's: [{to, shut, open, soft?}], s, where its tongue holds its
// reed -- `soft` a legato tongue's touch)}.
export function passageBreath(notes,{origin,pressures,hz,ahead=0,soft=new Set,moves=new Map,softTongues=[],tongue='air'}){
  const changes=[],entries=[],tongues=[],reed=tongue==='reed';
  const on=k=>notes[k].startSeconds-origin,off=k=>Math.max(on(k),notes[k].endSeconds-origin);
  const swells=notes.map((note,k)=>noteSwell(note,{from:on(k),until:off(k)}));
  const level=(k,t)=>pressures[k]*swellAt(swells[k],t);
  const rise=k=>{const a=Number(notes[k].source?.performance?.attackSeconds);return transitionSeconds('breathRise',Math.min(Number.isFinite(a)?a:BREATH.probeRise,(off(k)-on(k))/2))};
  // (The breath laid move by move, each whole and after the last, from where the breath is: `now` where it has been laid
  // to, `value` its value there. A move asked to begin before the last has ended begins as it ends -- a move begun from a
  // note's level while the breath was still rising to it, or cut off partway, had jumped: a tongue's stop begun 2 ms into
  // a 25 ms note's rise, from the level the rise was going to, 30 times its least's rate.)
  const points=[[0,0]];let now=0,value=0,moved=null;
  const hold=until=>{if(until>now){points.push([until,value]);now=until}};
  // (A move from where the breath is to `to`, begun at `start` or as the last ends, over `length` -- its caller's
  // transitionSeconds, never under its kind's least: transitions.js's raised cosine, as breakpoints. -> where it began.
  // `moved` the moves laid for the change being laid, [from, to].)
  const move=(start,length,to)=>{const begun=Math.max(start,now);hold(begun);points.push(...rampBreakpoints(begun,length,value,to).slice(1));now=begun+length;value=to;moved=[moved?moved[0]:begun,now];return begun};
  // (A change's span, s: what anticipation moves whole -- its breath's moves, a reed's tongue touching and leaving it,
  // and its fingering's, as long as the slowest kind a change moves in any engine.)
  const spanOf=(c,tongued)=>{const s=Math.max(...CHANGING.map(kind=>transitionSeconds(kind,c.seconds)));
    const times=[c.at-s/2,c.at+s/2,...(moved??[]),...(tongued?[tongued.shut,tongued.open+transition('tongueRelease').least]:[])];
    c.span=[Math.min(...times),Math.max(...times)]};
  // (A note held to `until`, where its arrival left it until its onset, then as its pressure curve swells and ebbs: its
  // curve's own points, none closer to the last than a breath moves (transitions.js breathRise), the last at `until`
  // itself, where the next move begins; too short for one, held.)
  const least=transition('breathRise').least;
  const sustain=(k,until)=>{
    hold(Math.min(until,on(k)));
    if(!swells[k]||until-now<least){hold(until);return}
    let last=now;for(const [t] of swells[k])if(t>=last+least&&t<=until-least){points.push([t,level(k,t)]);last=t}
    points.push([until,level(k,until)]);now=until;value=level(k,until);
  };
  const repeated=k=>k>0&&hz[k]>0&&hz[k-1]>0&&Math.abs(1200*Math.log2(hz[k]/hz[k-1]))<BREATH.samePitch;
  // (Where a reed's tongue is free to touch it again: its last touch let go, over tongueRelease. Touched sooner, its
  // release had been cut and turned back -- two tongued notes 30 ms apart, the second's touch begun where the first's
  // let go, a saxophone's tongue rose halfway off its reed and back in 5 ms: test/transitions.test.mjs's woodwind guard.)
  const free=()=>tongues.length?tongues.at(-1).open+transition('tongueRelease').least:0;
  // (A change's own length where its mechanism takes longer than a key's: `moves`, a trombone's slide moving, ness.mjs.)
  const moveOf=k=>moves.get(k)??0;
  for(let k=0;k<notes.length;k++){
    // (Legato-tongued where its player says (portato: wind-seat.js, a trombonist across its slide), a repeated pitch (the
    // owner, 10 October 2026), or where its model must (`soft`) -- never by a rule of the renderer's for its player.)
    const slurred=k>0&&notes[k].slurred===true&&on(k)-off(k-1)<BREATH.breathGap,tongue=notes[k].portato===true||soft.has(k)||repeated(k);
    entries.push(k===0?'first':tongue&&slurred?'soft':slurred?'slurred':'tongued');moved=null;
    if(k===0){const begin=Math.max(0,on(0)-ahead);move(begin,rise(0),level(0,begin+rise(0)));if(reed)tongues.push({to:0,shut:begin,open:begin+rise(0)})}
    else if(tongue&&slurred){
      // (Legato-tongued: the air dipping round its onset, never stopped. Its change -- a trombone's slide moving, as long
      // as its move -- ends with the tongue's dip, the breath held through the rest of it, as a trombonist's slide moves
      // under a held tone and its tongue's "d" lands with it: dipped through the whole of a tenth of a second's move, the
      // trombone's lips had stopped, its slurs heard 19 to 35 dB down and a semitone over, reattacked.)
      // (Its tongue's touch and its leaving each a stop's least at the shortest; a breath moved under a reed's touch, a
      // breath's.)
      const tongue=Math.max(softTongues[k]??BREATH.softSeconds,2*transitionSeconds('tongueStop'),reed?transitionSeconds('breathRise'):0),seconds=fingering(Math.max(BREATH.softSeconds,moveOf(k),tongue));
      const a=Math.max(on(k)-tongue/2,now,reed?free():0);sustain(k-1,a);
      changes.push({to:k,at:a+tongue/2-(seconds-tongue)/2,seconds,...(repeated(k)?{repeat:true}:{})});
      // (A reed's legato tongue touches its reed, its breath held and moved to the next note's under the touch: dipped
      // instead, a bassoon's low A repeated had dipped 1 to 2 dB in its group, never heard again -- its bore ringing through
      // the dip -- and dipped deep enough to be heard, its reed had stopped and spoken again only 0.26 s later; touched for
      // 30 ms it dipped 5 to 10 dB and was back at once (claude-scratch/register-probe/repeat-probe.py, 11 October 2026).
      // How lightly: openwind_worker.py TONGUE_SOFT.)
      if(reed){move(a,tongue,level(k,a+tongue));tongues.push({to:k,shut:a,open:a+tongue,soft:true})}
      else{move(a,tongue/2,value*BREATH.softDip);move(a+tongue/2,tongue/2,level(k,a+tongue))}
    }
    else if(slurred){
      // (Under the breath: the fingering changing round its onset, the breath moving from the last note's pressure to its,
      // no quicker than a breath rises.)
      // (A slide's move under the breath as long as it takes: its glide heard, as its player chose.)
      const seconds=fingering(Math.max(joinSeconds(hz[k-1],hz[k]),moveOf(k))),breathing=transitionSeconds('breathRise',Math.max(seconds,BREATH.slurBreath)),a=Math.max(on(k)-breathing/2,now);
      sustain(k-1,a);changes.push({to:k,at:on(k),seconds});move(a,breathing,level(k,a+breathing));
    }else{
      // (Tongued: the air stopped at the last note's end, or tongueStop before its onset where that is earlier, the
      // fingering changed behind the tongue, let go at its onset. Its stop never quicker than a tongue stops the air
      // (transitions.js tongueStop), nor begun before the last note's breath has arrived (a reed's: before its tongue's
      // last touch has let go, `free`): notes closer than that are let go after it -- a stop 2 ms long had been a step.)
      const cut=Math.max(on(k-1),Math.min(off(k-1),on(k)-BREATH.tongueStop),reed?free():now),stop=transitionSeconds('tongueStop',BREATH.tongueFall),release=Math.max(cut+stop,on(k));
      changes.push({to:k,at:(cut+stop+release)/2,seconds:fingering(Math.min(joinSeconds(hz[k-1],hz[k]),release-cut)),released:release});
      // (A reed's: its breath held behind the tongue on its reed, moved to the next note's while the reed is shut, no
      // quicker than a breath moves -- begun as much before the reed is let go as that takes.)
      if(reed){const moving=transitionSeconds('breathRise',release-cut),a=Math.max(release-moving,now);sustain(k-1,a);move(a,moving,level(k,a+moving));tongues.push({to:k,shut:cut,open:release})}
      else{sustain(k-1,cut);move(cut,stop,0);move(release,rise(k),level(k,release+rise(k)))}
    }
    if(k>0)spanOf(changes.at(-1),tongues.at(-1)?.to===k?tongues.at(-1):null);
  }
  // (Its last note's breath falling over its release, once its breath has arrived.)
  const last=notes.length-1,fall=transitionSeconds('breathFall',Number(notes[last].source?.performance?.releaseSeconds)),letGo=Math.max(off(last),now);
  sustain(last,letGo);move(letGo,fall,0);
  // (Each time once, the later point kept; its times and values as moved, never rounded -- rounded to a thousandth, a
  // woodwind's shares (pressures of 1, openwind-passages.mjs) had swelled as a staircase, each 0.001 step taken over one
  // 2.2 ms segment, faster than a tongue stops; its times rounded to a microsecond, its first rise had ended after
  // `firstRisen`, where the worker holds it, the rest of its rise taken in one sample after its hold: test/
  // transitions.test.mjs's woodwind guard.)
  const byTime=new Map;for(const [t,v] of points)byTime.set(t,v);
  return {pressure:[...byTime].sort((a,b)=>a[0]-b[0]),changes,entries,end:now,onsets:notes.map((_,k)=>on(k)),firstRisen:on(0)+rise(0),...(reed?{tongues}:{})};
}
// A pressure curve as shares of its mean, within BREATH.swell: [[s, share]] over the note (from `from`), or null -- its
// points at their `times` (s from `from`) where given, else evenly over `seconds`, and cut at `until` (its note let go
// before its curve ends: its player's swell cut short, as the engine's own curve is, its events at their times --
// expression.js expressionCurveEvents; squeezed whole into the note instead, a crescendo let go halfway had reached its
// peak). Its mean its average over the note's time, between its points as the breath lays them (along the line), so that
// a curve says one swell however many points carry it: an engine's three points, or the sixteen its MIDI 2.0 sends along
// them (expression.js performanceTimeline; wind-midi2.js). (Their plain mean had made the two 4 % apart at a note's
// start.)
export function swellOf(curve,{from,seconds,until=from+seconds,times=null}){
  let points=swellPoints(curve,{from,seconds,times});
  if(points.length<2||!(until>from))return null;
  const after=points.findIndex(([t])=>t>until);
  if(after>0){const [a,x]=points[after-1],[b,y]=points[after];points=[...points.slice(0,after),...(a<until?[[until,x+(y-x)*(until-a)/(b-a)]]:[])]}
  const span=points.at(-1)[0]-points[0][0];
  if(!(span>0))return null;
  let area=0;for(let k=1;k<points.length;k++)area+=(points[k][0]-points[k-1][0])*(points[k][1]+points[k-1][1])/2;
  const mean=area/span,most=Math.max(...points.map(([,v])=>Math.abs(v/mean-1)));
  const scale=most>BREATH.swell?BREATH.swell/most:1;
  return points.map(([t,v])=>[t,1+(v/mean-1)*scale]);
}
// A pressure curve's points as its player plays them, [[s, value]]: at their `times` (s from `from`) where given, else
// evenly over `seconds`.
export function swellPoints(curve,{from,seconds,times=null}){
  const values=(Array.isArray(curve)?curve:[]).map(Number);
  return Array.isArray(times)?values.map((v,k)=>[from+Number(times[k]),v]).filter(([t,v])=>Number.isFinite(t)&&Number.isFinite(v)&&v>0)
    :values.filter(v=>Number.isFinite(v)&&v>0).map((v,k,kept)=>[from+seconds*k/Math.max(1,kept.length-1),v]);
}
// A compiled note's swell (physical-events.mjs: its source's performance, and its length as its player meant it), from
// its onset `from` to its end `until` (s).
export const noteSwell=(note,{from,until})=>{const performance=note.source?.performance;
  const meant=Number(note.source?.duration);
  return swellOf(performance?.pressureCurve,{from,seconds:Number.isFinite(meant)&&meant>0?meant:until-from,until,times:performance?.pressureTimes})};
export const swellAt=(swell,t)=>{if(!swell)return 1;if(t<=swell[0][0])return swell[0][1];for(let k=1;k<swell.length;k++)if(t<=swell[k][0]){const [a,x]=swell[k-1],[b,y]=swell[k];return x+(y-x)*(t-a)/(b-a)}return swell.at(-1)[1]};

// How fully a probe's tone speaks, dB: its tone's RMS (the output less its slow part: a running mean over whole periods
// of `hz`, the tone's, at least 20 ms -- over 20 ms alone a 220 Hz tone leaked 7 % of itself into it, a tuba's 40 Hz
// most of itself) over its last `window` seconds before `seconds`, against the peak of that slow part over the breath's
// first 0.3 s -- the flow its breath sets going, heard as a thump. A tone barely speaking, its lips or reed hardly
// moving, is far under it.
export function speakingDb(audio,sampleRate,seconds,{window=.6,hz=null}={}){
  const n=Math.max(1,hz>0?Math.round(Math.ceil(.02*hz)*sampleRate/hz):Math.round(.02*sampleRate)),slow=new Float64Array(audio.length);let sum=0;
  for(let i=0;i<audio.length;i++){sum+=audio[i];if(i>=n)sum-=audio[i-n];slow[i]=sum/Math.min(i+1,n)}
  // (Its slow part read only once its window is full: the mean of a tone's first few samples is no flow.)
  let surge=0;for(let i=n-1;i<Math.min(audio.length,Math.round(.3*sampleRate));i++)surge=Math.max(surge,Math.abs(slow[i]));
  const a=Math.max(0,Math.round((seconds-window)*sampleRate)),b=Math.min(audio.length,Math.round(seconds*sampleRate));
  let e=0;for(let i=a;i<b;i++){const v=audio[i]-slow[i];e+=v*v}
  const tone=b>a?Math.sqrt(e/(b-a)):0;
  return tone>0?20*Math.log10(tone*Math.SQRT2/Math.max(surge,1e-12)):-Infinity;
}
// A value between two notes' across their change: transitions.js's raised cosine from `from` to `to` over the change round
// `at` (its `seconds` a change's, never under its least).
export const across=(from,to,t,{at,seconds})=>ramp(t,at-seconds/2,seconds,from,to);

// A player's anticipation, learned by ear in a breath group: how much earlier a change may be begun, at most, s, and at
// most this share of the time since the change before (the note before keeps the rest); a note heard within `tolerance`
// of its onset is in time; each change's window moved whole -- `window` either side of its middle at least, its own half
// length where longer, never more than `reach` of the way to the change either side -- and at least `margin` between
// two windows as played. Begun no later than planned: a change heard early is begun as planned.
export const ANTICIPATION=Object.freeze({most:.3,share:.5,tolerance:.02,window:.045,reach:.3,margin:.01,step:.8,slope:.2});
// A lead's next (s; bounded by boundLeads after), from what its note was heard to do with each lead tried, [[lead,
// lateness]]: where it is known to cross -- once heard late and once early, the two nearest in time -- or else through its
// last two, a secant, as its player's ear finds a pitch; on by `step` of its lateness where they say nothing (one tried,
// or a change no earlier for being begun earlier: under `slope`). A slide's move under a legato tongue arrived 0.26 s late
// begun on its beat and 0.08 early begun 0.3 earlier: its lateness never a lead's own measure.
export function nextLead(heard){
  const [l1,e1]=heard.at(-1),late=heard.filter(([,e])=>e>0).sort((a,b)=>a[1]-b[1])[0],early=heard.filter(([,e])=>e<0).sort((a,b)=>b[1]-a[1])[0];
  const [[la,ea],[lb,eb]]=late&&early?[late,early]:heard.length>1?heard.slice(-2):[[l1,e1],[l1,e1]];
  if(Math.abs(lb-la)>1e-4&&(ea-eb)/(lb-la)>ANTICIPATION.slope)return lb+eb*(lb-la)/(ea-eb);
  return l1+ANTICIPATION.step*e1;
}
// When a note is heard to arrive (ness.mjs arrivalOf, openwind_passages.py arrival_of): its pitch nearer its own than the
// note before's and within `cents` of it, at a level within `db` of its held part's, for `frames` windows running (every
// `step` s, searched from `before` s ahead of its onset, never before the note before's onset, to `after` s past it)
// after one where it was not -- the first one's middle, each window long enough for three of the lowest period it hears;
// a pitch repeated (within `repeat` cents), where its level is back within `back` dB of its held part's after its dip
// (at least `dip` dB). As a listener times it: on sawtooth tones at known times each was heard within 20 ms of its
// onset, and notes written together within 26 ms of each other. Its `db` where a listener hears a tone begin, 15 dB under
// its level (Vos & Rasch 1981, "The perceptual onset of musical tones", Perception & Psychophysics 29(4), 323-335,
// doi:10.3758/BF03207341; render/node/physical-strings.mjs VOICED).
export const ARRIVAL=Object.freeze({cents:50,db:15,repeat:20,back:6,dip:3,step:.005,frames:3,before:.5,after:.6});
// The windows its changes are moved whole in, s, in order: [{lo, hi, changes (indices), fixed?}] -- each change's span
// (passageBreath's), widened to `window` either side of its middle where narrower, never more than `reach` of the way to
// the span either side; changes whose windows meet one window, moved by one lead; its first note's attack a window never
// moved (`fixed`), with any change that meets it. A window as wide as its change's middle and length alone had left a
// tongued note's stop outside it, 0.15 s before, and the time between two windows shrunk under it: the stop 1.4 times
// as quick as a tongue stops the air.
function windowsOf(breath){
  const cs=breath.changes,{window,reach}=ANTICIPATION,spans=cs.map(c=>c.span??[c.at-c.seconds/2,c.at+c.seconds/2]);
  const windows=[{lo:0,hi:breath.firstRisen,changes:[],fixed:true}];
  spans.forEach(([s0,s1],i)=>{
    const before=Math.max(breath.firstRisen,...spans.slice(0,i).map(s=>s[1])),after=Math.min(breath.end,...spans.slice(i+1).map(s=>s[0]));
    let lo=Math.min(s0,Math.max(cs[i].at-window,s0-reach*Math.max(0,s0-before))),hi=Math.max(s1,Math.min(cs[i].at+window,s1+reach*Math.max(0,after-s1))),changes=[i],fixed=false;
    while(windows.length&&lo<=windows.at(-1).hi){const w=windows.pop();lo=Math.min(lo,w.lo);hi=Math.max(hi,w.hi);changes=[...w.changes,...changes];fixed||=w.fixed}
    windows.push({lo,hi,changes,fixed});
  });
  return windows;
}
// Each note's lead (s, how much earlier its change is begun; the first note's its group's `ahead`, untouched) within what
// its plan allows: at least 0, at most ANTICIPATION.most and its share of the time since the change before, its window
// played after the one before and after its first note's attack, the time between the two shrunk by at most its share
// (what moved in it -- a note's swell, its breath's points no closer than a breath moves -- no quicker than twice its
// pace); one lead for the changes of one window, the least they allow; a repeated pitch's no more than its half attack
// lasts (its change's own length): led further, its dip fell before where its ear listens for it (arrivalOf looks within
// 80 ms of its onset), was never heard, and its lead ran on to the most -- a trumpet's repeat begun 0.3 s early, its tone
// over the note before's held part.
export function boundLeads(breath,leads){
  const {most,share,margin}=ANTICIPATION,cs=breath.changes,bounded=leads.slice();
  let last=breath.onsets[0],played=0,before={hi:0,lead:0};
  for(const w of windowsOf(breath)){
    let lead=w.fixed?0:Math.min(w.lo-played-margin,before.lead+share*(w.lo-before.hi));
    for(const i of w.changes){const c=cs[i];lead=Math.min(lead,most,share*(c.at-last),c.repeat?c.seconds:Infinity,Number(bounded[c.to])||0);last=c.at}
    lead=Math.max(0,lead);for(const i of w.changes)bounded[cs[i].to]=lead;
    played=w.hi-lead;before={hi:w.hi,lead};
  }
  return bounded;
}
// Its plan's time as played with these leads (boundLeads'), and back: {played: t => s, planned: t => s} -- each window
// moved whole by its changes' lead, its first note's attack and its end where they were, the time between them stretched
// or shrunk to fit (piecewise linear; past its end, as it was).
export function anticipation(breath,leads){
  const cs=breath.changes,anchors=[];
  for(const w of windowsOf(breath)){const lead=w.fixed?0:Number(leads[cs[w.changes[0]].to])||0;anchors.push([w.lo,w.lo-lead],[w.hi,w.hi-lead])}
  anchors.push([breath.end,breath.end]);
  // (Each anchor after the last, both ways: a note too short for its windows leaves its change where it was.)
  const kept=anchors.filter((p,i)=>i===0||anchors.slice(0,i).every(q=>p[0]>q[0]&&p[1]>q[1]));
  const map=(points,t)=>{if(t<=points[0][0])return t-points[0][0]+points[0][1];
    for(let i=1;i<points.length;i++)if(t<=points[i][0]){const [a,x]=points[i-1],[b,y]=points[i];return b>a?x+(y-x)*(t-a)/(b-a):y}
    return t-points.at(-1)[0]+points.at(-1)[1]};
  return {played:t=>map(kept,t),planned:t=>map(kept.map(([a,b])=>[b,a]),t)};
}
