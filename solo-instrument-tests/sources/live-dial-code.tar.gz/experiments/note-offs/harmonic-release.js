// No note should outlive the harmony that sanctioned it.
//
// **This exists because of two measurements.** The first found the mechanism missing: both
// renderers implement an early release — the Rust engine as `4 => voice.duration =
// voice.elapsed`, the Web Audio voice as a ramp to zero — and a search of the whole app found
// exactly one occurrence of action 4, the implementation. Nothing ever sent it. A note ran to
// the length it was born with and could not be stopped.
//
// The second found what that costs. Five bots, 45 seconds, hooked at the one place every note
// passes through:
//
//     bot              notes   dur med/max   rel med/max   own polyphony med/max   duty
//     mh_BleepBOT        528    0.11/0.11     0.03/0.03                    0/10     23%
//     PAP_MelodyBot      199    0.22/0.40     0.03/0.03                     1/9     58%
//     ae_PadBOT           96    4.44/4.44     1.07/1.07                   10/20     90%
//     mh_DroneBOT         24    0.40/0.40     0.05/0.05                    0/24      1%
//     (unattributed)      97    0.11/17.78    0.03/1.07                    0/45     42%
//
//     ensemble notes sounding at once: median 15, p90 24, max 45
//
// ae_PadBOT holds a 4.44-second note with a 1.07-second tail — 5.5 seconds of ringing — and
// starts them often enough that ten to twenty of its own notes overlap, ninety per cent of the
// time. A chord in these line-ups lasts two to four beats: at 108 bpm, 1.11 to 2.22 seconds.
// So every pad note outlived between two and five chords, and the harmony the ensemble had
// just negotiated was being played over by the harmony from four chords ago. That is what
// "blurred" means here, and it is not a mixing problem: no fader fixes a wrong note.
//
// The rule below is deliberately narrow. It does not shorten notes, cap polyphony or refuse
// anything — a bot that wants a long note gets one. It releases a note only when all three
// things are true at once:
//
//   1. the harmony has actually changed (a different set of pitch classes, not a republication
//      of the same one — the measured line-ups republish the same progression every few
//      seconds and reacting to that would cut every note constantly);
//   2. the note started before the change, and would still be sounding a grace period after
//      it — so a note that was going to end anyway is left alone;
//   3. the note's pitch class is not in the new harmony — a note that is still consonant keeps
//      ringing, which is how a suspension works and how a drone survives a chord change it
//      happens to fit.
//
// Microtuning is respected throughout: a pitch is a floating-point semitone and the pitch
// class is compared within a tolerance in cents rather than rounded to a key.

export const RELEASE=Object.freeze({
  // How long a note may outlive its harmony before it counts as blur. A little overlap is
  // legato; half a second of the old chord under the new one is mud.
  graceSeconds:0.25,
  // How close a sounding pitch has to be to a sanctioned one to count as still in the
  // harmony. 50 cents is a quarter tone: anything nearer to a chord tone than to the next
  // note over is treated as that chord tone, so microtonal inflections are not cut.
  toleranceCents:50,
  // Addresses that carry harmony. Both are measured to appear: the progression and the pool.
  addresses:Object.freeze(['/plan/chords','/notepool']),
});

// The pitch classes a harmony message sanctions, as floating-point semitones in [0,12).
// Chord plans arrive as arrays of space-separated note strings; note pools as arrays of
// numbers. Both may be nested, so this flattens rather than assuming a depth.
export function sanctionedClasses(args){
  const out=new Set();
  const visit=value=>{
    if(Array.isArray(value)){for(const item of value)visit(item);return}
    if(typeof value==='number'){if(Number.isFinite(value))out.add(((value%12)+12)%12);return}
    if(typeof value!=='string')return;
    for(const token of value.trim().split(/\s+/)){
      if(token==='')continue;
      const number=Number(token);
      if(Number.isFinite(number))out.add(((number%12)+12)%12);
    }
  };
  visit(args);
  return out;
}

// Is this pitch in that harmony? Distance is measured around the octave, so B and C are a
// semitone apart rather than eleven.
export function withinHarmony(pitch,classes,toleranceCents=RELEASE.toleranceCents){
  if(!classes?.size)return true; // No harmony published means nothing to be out of.
  const pitchClass=((pitch%12)+12)%12;
  for(const sanctioned of classes){
    const raw=Math.abs(pitchClass-sanctioned),distance=Math.min(raw,12-raw);
    if(distance*100<=toleranceCents)return true;
  }
  return false;
}

// Watches one engine's harmony and releases the notes that fall out of it.
export class HarmonicRelease {
  // **`follows` is the whole difference between a fix and a fault, and it was measured too.**
  // The first version judged every bot's notes against the published harmony. On the seven-bot
  // line-up that silenced mh_DroneBOT completely — its own polyphony went from a 24-note
  // cluster to zero, its duty cycle from 1% to 0% — because a self-contained drone's material
  // is not in anybody's chord and never was meant to be. PAP_MelodyBot was being judged the
  // same way.
  //
  // `capabilities.js` already knows which bots follow harmony and which do not: ae_PadBOT
  // requires it, mh_DroneBOT requires nothing, PAP_MelodyBot requires pulse. A bot that does
  // not declare that it follows harmony has not agreed to be held to it, and cutting its notes
  // is not unmasking a mix — it is deleting a part.
  constructor({graceSeconds=RELEASE.graceSeconds,toleranceCents=RELEASE.toleranceCents,
    addresses=RELEASE.addresses,follows=false}={}){
    this.graceSeconds=graceSeconds;this.toleranceCents=toleranceCents;this.addresses=addresses;
    this.follows=Boolean(follows);
    this.classes=new Set();
    this.established=false;
    this.changes=0;this.releasedCount=0;
  }
  // A protocol message. Returns what it did and why, so a caller can log a sentence rather
  // than a boolean — and so a test can check the reason rather than only the effect.
  observe(message,audio,atSeconds){
    const address=message?.address||'';
    if(!this.addresses.some(suffix=>address.endsWith(suffix)))return null;
    const classes=sanctionedClasses(message.args);
    if(!classes.size)return null;
    const same=classes.size===this.classes.size&&[...classes].every(item=>this.classes.has(item));
    const first=!this.established;
    this.classes=classes;
    this.established=true;
    // **The first harmony is not a change.** Rule 1 above says the harmony has to have
    // *changed*, and going from nothing known to something known is establishing it — there
    // was no previous harmony for a note to have outlived. Releasing here would cut every note
    // struck in the moments before the harmony source got its first word in, which is the
    // opening of every performance.
    if(first)return {changed:false,established:[...classes].sort((a,b)=>a-b),released:[],
      because:'the first harmony establishes the room rather than changing it'};
    // A republication of the same harmony is not a change either. The measured line-ups
    // republish their progression every few seconds; treating that as a change would cut every
    // note in the room on a timer.
    if(same)return null;
    this.changes++;
    // A bot that does not follow harmony still tracks it — the state is worth reading, and a
    // second desk or a display may want it — but nothing of its own is ever cut for it.
    if(!this.follows)
      return {changed:true,released:[],
        because:'this bot does not follow harmony, so its notes are not judged by it'};
    if(!audio?.soundingNotes)return {changed:true,released:[],because:'no engine to release on'};
    const now=atSeconds??audio.clockTime?.()??0,cutoff=now+this.graceSeconds;
    const released=audio.releaseNotes((note)=>
      note.startedAt<now&&note.endsAt>cutoff&&!withinHarmony(note.note,classes,this.toleranceCents),
      {atSeconds:now});
    this.releasedCount+=released.length;
    return {changed:true,released,
      because:released.length
        ?`${released.length} note${released.length===1?'':'s'} left sounding outside the new `
          +`harmony (${[...classes].map(value=>value.toFixed(2)).join(' ')})`
        :'every sounding note is still in the new harmony'};
  }
  state(){return {follows:this.follows,established:this.established,
    changes:this.changes,released:this.releasedCount,
    harmony:[...this.classes].sort((a,b)=>a-b)}}
}
