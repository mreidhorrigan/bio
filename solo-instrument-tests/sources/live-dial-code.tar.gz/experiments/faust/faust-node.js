// A Faust program as a node in the graph, so a bot can be routed through one.
//
// `host.js` runs these offline and `build-faust.mjs` measures them there; this is the part
// that puts the same module in a live audio graph. It fetches the wasm and its JSON, makes
// sure the worklet is registered once per context, and hands the bytes across.
//
// **Why the bundle and not the source.** `faust-processor.js` imports `FaustDsp` from
// `host.js`, which is right — the DSP the ensemble hears should be the DSP the tests measure,
// not a second copy. But an `AudioWorkletProcessor` is loaded into a scope where `import`
// support has differed by browser and by version, and a worklet that fails to load fails into
// silence with nothing in the console. So the build inlines it, and this loads the bundle.
//
// **What a caller gets** is a node with an input and an output, a list of the program's
// parameters with their ranges and units, and a `set` that takes the parameter's *address* —
// the readable path like `/moogladder/cutoff`, not the byte offset the wasm actually wants.
// The offset is the trap the build script documents; nothing above this line should meet it.

// The programs `scripts/build-faust.mjs` compiles, named for people rather than files.
export const FAUST_EFFECTS=Object.freeze([
  Object.freeze({id:'moogladder',name:'Moog filter',
    describe:'Julius Smith’s ve.moog_vcf — a resonant ladder filter',
    defaults:{'/moogladder/cutoff':1200,'/moogladder/resonance':.3,'/moogladder/drive':1}}),
  Object.freeze({id:'compressor',name:'Compressor',
    describe:'co.compressor_mono — level control that acts inside a note',
    defaults:{'/compressor/ratio':4,'/compressor/threshold':-24}}),
  Object.freeze({id:'fdnreverb',name:'FDN reverb',
    describe:'re.fdnrev0 — eight mutually prime lines, a Hadamard matrix, three decay bands',
    defaults:{'/fdnreverb/wet':.4,'/fdnreverb/midT60':2.4}}),
  // The four the audit found missing. Each is here because Web Audio has no node for it and
  // no good WAM of it exists: neither wam-examples nor the sequencer.party collection has a
  // gate, a crusher, a transient shaper or a multiband compressor. Built with the same
  // compiler as the three above, so the offline renderer meets one shape rather than five.
  Object.freeze({id:'gate',name:'Noise gate',
    describe:'ef.gate_mono — turns the quiet off, which no compressor setting does',
    defaults:{'/gate/threshold':-40,'/gate/hold':.05,'/gate/release':.12}}),
  Object.freeze({id:'bitcrusher',name:'Bitcrusher',
    describe:'depth and rate reduction — quantisation noise and aliasing, separately',
    defaults:{'/bitcrusher/bits':8,'/bitcrusher/downsample':.5,'/bitcrusher/drywet':1}}),
  Object.freeze({id:'transient',name:'Transient shaper',
    describe:'fast against slow envelope — attack and sustain without a threshold',
    defaults:{'/transient/attack':3,'/transient/sustain':0}}),
  Object.freeze({id:'multiband',name:'Multiband compressor',
    describe:'fi.crossover3LR4 into three compressors — a bass note stops ducking the mix',
    defaults:{'/multiband/lowCross':220,'/multiband/highCross':3200}}),
]);
export const faustEffect=id=>FAUST_EFFECTS.find(effect=>effect.id===id)||null;

const WORKLET='/experiments/faust/built/faust-processor.bundle.js';
const registered=new WeakSet();

// One `addModule` per context, awaited by everyone who needs it. Calling it twice is harmless
// but racing it is not: two callers can both find it missing and both add it, and the second
// rejects with "already registered" in some browsers.
const pending=new WeakMap();
async function ensureWorklet(context){
  if(registered.has(context))return;
  if(!pending.has(context))pending.set(context,context.audioWorklet.addModule(WORKLET)
    .then(()=>{registered.add(context);pending.delete(context)}));
  await pending.get(context);
}

export async function loadFaustEffect(context,id,{base=''}={}){
  const effect=faustEffect(id);
  if(!effect)throw new Error(`No Faust effect called ${id}`);
  await ensureWorklet(context);
  const [wasm,description]=await Promise.all([
    fetch(`${base}/experiments/faust/built/${id}.wasm`).then(response=>{
      if(!response.ok)throw new Error(`${id}.wasm is not on the server`);
      return response.arrayBuffer();
    }),
    fetch(`${base}/experiments/faust/built/${id}.json`).then(response=>{
      if(!response.ok)throw new Error(`${id}.json is not on the server`);
      return response.json();
    }),
  ]);
  const node=new AudioWorkletNode(context,'faust-dsp',{
    numberOfInputs:1,numberOfOutputs:1,
    outputChannelCount:[Math.max(1,Number(description.outputs)||1)],
    processorOptions:{wasm,description},
  });
  // The processor says when it is ready and what it found, so a caller can show the real
  // parameters rather than the ones this file guessed at.
  const ready=new Promise(resolve=>{
    const listen=event=>{
      if(event.data?.ready){node.port.removeEventListener('message',listen);resolve(event.data.parameters||[])}
      if(event.data?.error){node.port.removeEventListener('message',listen);resolve([])}
    };
    node.port.addEventListener('message',listen);
    node.port.start();
  });
  // A processor that throws goes silent for the rest of its life and says nothing. This is the
  // only place that failure is visible, so it is not left unhandled.
  node.onprocessorerror=event=>{
    node.__failed=`the ${id} worklet stopped: ${event?.message||'processor error'}`;
    console.error(node.__failed,event);
  };
  const set=parameters=>node.port.postMessage({parameters});
  set(effect.defaults);
  return {node,effect,set,parameters:await ready,
    // A Faust program has no meaningful "stop": disconnecting it is enough, and the worklet
    // is collected with the context.
    dispose(){try{node.disconnect()}catch{}}};
}
