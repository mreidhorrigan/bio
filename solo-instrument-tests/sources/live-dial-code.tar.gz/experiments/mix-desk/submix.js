// The band in groups: each player's channel routed into its group's bus by the role its bot plays, and each group
// balanced as one part. The Mixbot's submix duty (mh_DeskBOT: live-desk.js); the groups, the arithmetic and the routing
// are here.
//
// The user, 26 September 2026, among the next steps for professionalizing mix quality: "5. Submixes", then "6. Submix
// and whole-mix cuts -- for example, heavy rock mixes (think Linkin Park) sometimes cut whole sections of a mix, reverb
// and all, at drastic section transitions."
//
// **Why a group is the unit of balance.** The loudness an approach sets a part at was measured on groups: in the
// measured mixes the lead vocal sits 2.7 LU under the mix, the *total* drums 6.5 to 8.5 LU and the bass 8 to 9 (De Man
// et al. 2014; De Man 2017 Table 6.1), while a kit's own close tracks sit far lower (kick -13.2, snare -16.8, the other
// drums -12.7 LU: De Man 2017 Table 4.2; research/audio-mixing-literature.md E.2). Given to each channel, as the level
// duty gave it, three drum bots each sat at the drums' loudness and so together 4.8 dB over it (10 log10 3). So a
// group's channels are balanced among themselves first, toward their own average as every channel was before, and the
// group then, as the power sum of its channels, toward the ensemble's average at its role's loudness. A group of one
// is a channel balanced as it always was.
//
// **Why each group has a bus.** A bus is where a group is treated as one thing: compressed as one (the drums' punch),
// cut as one at a form's join (item 6), heard as one stem. The approaches already had one, the studio mix's bus:drums
// (public/shared/mix-approaches.js), and name theirs as these are named, so an approach's bus strip lands on the group's
// bus (public/mix-approach.js, with its own routing off while this duty routes).
//
// **What a group is not.** A bus here is never balanced, placed, sent to a reverb or unmasked as a channel: it holds its
// channels, and each of those already is. Its fader stays at unity; what a bus adds is its own processing.
//
// **Whose routing.** A channel is routed only from the master or from a bus this made: one somebody else routed (a person,
// a routing graph, another desk) is theirs, as a pan somebody else set is (live-desk.js).
//
// **A kit split into a channel per drum** (audio.js splitKit) is routed as its bot's channel is: that channel is the
// kit's bus, and this routes it into its group's bus like any other channel, while its drums stay routed into it. A
// drum is in the group its kit is in: the group's channels are its drums, balanced within the group each at its own
// loudness, and the kit is one unit only for the group's loudness and the bus.

// ---- Definitions -------------------------------------------------------------------------------------------------------
const POWER_DB=10;          // decibels of power: 10 log10

// ---- Choices -----------------------------------------------------------------------------------------------------------
export const SUBMIX=Object.freeze({
  // The groups, each the roles it takes (articulation.js ROLES). The drums, the bass and the lead are the groups the
  // measured balances were read on (above); keys and pads are one group, as a band's keyboards are, and textures one of
  // their own, so an ambience can be cut or kept apart from the band (ours). A role in no group, or not known yet
  // ('other'), stays on the master.
  groups:Object.freeze({
    drums:Object.freeze(['drums']),
    bass:Object.freeze(['bass']),
    keys:Object.freeze(['keys','pad']),
    lead:Object.freeze(['lead']),
    texture:Object.freeze(['texture']),
    // A singing voice on a bus of its own, as a mix's lead vocal is, apart from the instrumental lead (ours).
    vocal:Object.freeze(['vocal']),
  }),
  prefix:'bus:',            // a group's bus is named as an approach names its buses (the studio approach's bus:drums)
  routeSeconds:.05,         // a channel moves into its group's bus by a crossfade this long (audio-mixer.js routeTo's own)
  levelEpsilonDb:.01,       // a member's fader is moved when its group's move and its own add up to more than this
  errorsKept:4,             // the routing errors a state reports, the latest
  mostHops:8,               // the longest chain of routes followed to a group's bus (a drum, its kit, its group: 2)
  // A kit's drums within their group, each at its own loudness, in LU against the others' (a channel that is not a drum,
  // a whole kit among them, at 0). The kick and the snare lead the kit, as "many mixing styles aim for particularly
  // punchy snare and kick" (the user); in measured mixes the kick's close track is the kit's loudest, 13.2 LU under the
  // mix against the total drums' 6.5 to 8.5 (De Man 2017 Tables 4.2 and 6.1), where the snare's reads lower for the
  // share of it the overheads carry. The rest sit under them: the hats and percussion furthest, the cymbals and the toms
  // between (ours).
  kitLu:Object.freeze({kick:-4,snare:-4,hats:-14,toms:-8,ride:-12,crash:-12,hands:-8,perc:-14}),
});

// ---- Arithmetic --------------------------------------------------------------------------------------------------------
// The group a role belongs to, or null.
export function submixGroup(role,choices=SUBMIX){
  if(!role)return null;
  for(const [group,roles] of Object.entries(choices.groups))if(roles.includes(role))return group;
  return null;
}
export const submixBus=(group,choices=SUBMIX)=>`${choices.prefix}${group}`;

// The loudness of parts sounding together, in dB: their powers summed (exact for parts that do not correlate, which
// separate players' parts mostly do not). Null for none.
export function powerSumDb(levels){
  let sum=0;
  for(const level of levels)if(Number.isFinite(level))sum+=10**(level/POWER_DB);
  return sum>0?POWER_DB*Math.log10(sum):null;
}

// A group's loudness for the balance: its sounding members' loudness (as the balance within the group now sets them)
// summed, and the role loudness of the loudest of them, which is the part the group is heard as. `members`:
// [{lufs, gainDb, balanceLu}]; `silenceLufs`: under it a member is resting and adds nothing. Null when none is sounding.
export function groupLoudness(members,{silenceLufs=-Infinity}={}){
  const sounding=members.filter(member=>Number.isFinite(member.lufs)&&member.lufs>silenceLufs);
  if(!sounding.length)return null;
  const levels=sounding.map(member=>member.lufs+(member.gainDb??0));
  const loudest=sounding[levels.indexOf(Math.max(...levels))];
  return {lufs:powerSumDb(levels),balanceLu:loudest.balanceLu??0,loudest:loudest.id??null,sounding:sounding.length};
}

// ---- The buses on a mixer ----------------------------------------------------------------------------------------------
// Keeps each channel in its group's bus as roles become known and players come and go (audio-mixer.js buses), and puts
// everything back on restore().
export class Submixes {
  constructor(mixer,{choices=SUBMIX}={}){
    this.mixer=mixer;
    this.choices=choices;
    this.made=new Set();       // the buses this made
    this.routed=new Map();     // channel -> the bus this routed it into
    this.errors=[];
  }
  // The group's bus a channel is in by this duty, through whatever it is routed into first (a drum through its kit's
  // bus), or null.
  busOf(id){
    let hop=id;
    for(let hops=0;hop!==null&&hop!==undefined&&hops<=this.choices.mostHops;hops++){
      const bus=this.routed.get(hop);
      if(bus)return bus;
      hop=this.mixer.tracks.get(hop)?.route??null;
    }
    return null;
  }
  // The channels in a group's bus: every channel that reaches it, a kit's drums rather than the kit's bus.
  membersOf(bus){return [...this.mixer.tracks].filter(([id,track])=>!track.bus&&this.busOf(id)===bus).map(([id])=>id)}
  // Each group's bus and its channels.
  groups(){
    const groups={};
    for(const [id,track] of this.mixer.tracks){
      if(track.bus)continue;
      const bus=this.busOf(id);
      if(bus)(groups[bus]??=[]).push(id);
    }
    return groups;
  }
  // Every channel into its group's bus (made when first needed), out of one it no longer belongs to, and each bus this
  // made that nobody is in taken away. `owns(id)`: whether a channel is this desk's to route (one it routed and no longer
  // owns goes back to the master). Cheap when nothing has changed; a desk calls it at every decision.
  update({owns=()=>true}={}){
    const {mixer,choices}=this,wanted=new Map();
    for(const [id,track] of mixer.tracks){
      // A group's bus is routed by nobody here; a kit's bus is its bot's channel, and is.
      if(track.bus&&!track.kit)continue;
      const route=track.route??null;
      if(route!==null&&this.routed.get(id)!==route){this.routed.delete(id);continue}   // somebody else's routing
      if(!owns(id)){if(this.routed.has(id))wanted.set(id,null);continue}
      const group=submixGroup(track.role,choices);
      wanted.set(id,group===null?null:submixBus(group,choices));
    }
    for(const bus of new Set(wanted.values()))if(bus!==null&&!mixer.tracks.has(bus)){mixer.bus(bus);this.made.add(bus)}
    const moved={};
    for(const [id,bus] of wanted){
      const track=mixer.tracks.get(id);
      // A name taken by a channel that is not a bus cannot be routed into; the channel stays where it is.
      if(bus!==null&&!mixer.tracks.get(bus)?.bus){this.routed.delete(id);continue}
      if((track.route??null)!==bus){
        try{track.routeTo(bus,{seconds:choices.routeSeconds});moved[id]=bus}
        catch(error){this.errors.push(`${id} into ${bus}: ${error.message}`);continue}
      }
      if(bus===null)this.routed.delete(id);else this.routed.set(id,bus);
    }
    for(const id of [...this.routed.keys()])if(!mixer.tracks.has(id))this.routed.delete(id);
    const occupied=new Set(this.routed.values());
    for(const bus of [...this.made])if(!occupied.has(bus)){mixer.tracks.get(bus)?.disconnect();this.made.delete(bus)}
    return moved;
  }
  // Every channel this routed back to the master, and the buses this made gone.
  restore(){
    for(const [id,bus] of this.routed){
      const track=this.mixer.tracks.get(id);
      if(track&&track.route===bus)try{track.routeTo(null,{seconds:this.choices.routeSeconds})}catch{/* its bus has gone */}
    }
    this.routed.clear();
    for(const bus of this.made)this.mixer.tracks.get(bus)?.disconnect();
    this.made.clear();
    return this;
  }
  state(){return {groups:this.groups(),made:[...this.made],...(this.errors.length?{errors:this.errors.slice(-this.choices.errorsKept)}:{})}}
}
