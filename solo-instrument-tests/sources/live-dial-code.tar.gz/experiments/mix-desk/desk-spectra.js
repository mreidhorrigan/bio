// What the desk hears of each bot, said to the room: every channel's energy in the desk's bands, as the Mixbot measures
// it (live-desk.js LiveDesk.spectra()), published on `/broadcast/analysis` as
//   {source: 'mix-desk', kind: 'spectra', bands, spectra: {<instanceId>: [share per band]}, levels: {<instanceId>: dB}}
// so casting (manage_clodbot; public/shared/casting/evidence.js) can judge who masks whom from the parts' measured
// sound rather than from spectra estimated from their notes, which assume every part a sawtooth.
//
// **Shares and levels, apart.** A spectrum is published as each band's share of the bot's energy (summing to one), the
// unit casting's estimates from notes and profiles come in: a group is judged with measured and estimated members side
// by side (a resting or newly joined bot has no measurement), and at a share each part stands at the same loudness, as
// the Mixbot's balance brings parts toward. How loud each bot is, as measured, is `levels`: its total energy in dB under
// the loudest bot's, so energies are shares × 10^(level / 10) for a reader that wants them.
//
// **A bot, not a channel.** A drummer whose kit the desk has split into a channel per drum (kit-channels.js) is one
// performer: its channels are summed back into it. Channels no bot owns (a clip, a bus) are left out, and so is a
// bot heard nowhere yet. The host says which instance plays on which channel (`instanceOf`): a page's channel is its
// bot's random key, a render's `bot:<id>:<key>`, and neither is the instance id the room knows the bot by.
import {AUTO_MIX} from './auto-mix.js';
import {kitTrackOf} from '../../public/shared/kit-channels.js';

// ---- Choices ---------------------------------------------------------------------------------------------------------
export const DESK_SPECTRA=Object.freeze({
  // A report each round of the desk's spectrum measurement (live-desk.js LIVE_DESK.spectrumEveryMs: every channel
  // measured afresh once a round), so no two reports say the same thing.
  everySeconds:6,
  // Six significant figures: the measurement varies by far more from one round to the next.
  digits:6,
  address:'/broadcast/analysis',
});
const DECIBELS_PER_BEL=10;
const figures=value=>Number(value.toPrecision(DESK_SPECTRA.digits));

// The report for the room from the desk's measurement (`channels`: [channelId, energy per band] pairs, or an object of
// them), or null when no bot has been heard.
export function deskSpectraMessage(channels,{instanceOf,bands=AUTO_MIX.bands}={}){
  if(typeof instanceOf!=='function')throw new TypeError('deskSpectraMessage needs instanceOf(channelId) → the instance playing on it');
  const totals=new Map;
  for(const [channel,energies] of channels instanceof Map?channels:Object.entries(channels??{})){
    if(!Array.isArray(energies)||energies.length!==bands.length-1)continue;
    const instance=instanceOf(kitTrackOf(channel)?.track??channel);
    if(instance===null||instance===undefined)continue;
    const sum=totals.get(String(instance))??energies.map(()=>0);
    energies.forEach((value,band)=>{sum[band]+=Number.isFinite(value)&&value>0?value:0});
    totals.set(String(instance),sum);
  }
  const heard=[...totals].map(([id,energies])=>({id,energies,total:energies.reduce((a,b)=>a+b,0)})).filter(entry=>entry.total>0);
  if(!heard.length)return null;
  const loudest=Math.max(...heard.map(entry=>entry.total));
  return {source:'mix-desk',kind:'spectra',bands:[...bands],
    spectra:Object.fromEntries(heard.map(({id,energies,total})=>[id,energies.map(value=>figures(value/total))])),
    levels:Object.fromEntries(heard.map(({id,total})=>[id,figures(DECIBELS_PER_BEL*Math.log10(total/loudest))]))};
}
