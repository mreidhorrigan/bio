// Drums with punch: the kick and the snare each compressed on their own, the drums' bus glued and a hard-compressed copy
// of it blended under it, and the bass and the chords stepping back a little as the kick and the snare strike. The
// Mixbot's punch duty (mh_DeskBOT: live-desk.js managePunch); its choices and arithmetic are here.
//
// The user, 26 September 2026: "4. Mixbot: Ducking and compression to give drums 'punch'", and "Many mixing styles aim
// for particularly punchy snare and kick; so, in advanced mixing, the whole drum kit should not necessarily be treated
// as a unit."
//
// **What punch is, here**: a drum's attack standing out from its own body and from the mix around it. Three moves make
// it, each an engineer's usual one:
//   - each drum's attack raised and its ring shortened by a transient designer (dynamics-worklet.js 'transient'), which
//     answers to the shape of each hit rather than to its level. A compressor with a slow attack is the older way, and
//     was tried first: on the Virtuosity kit's kick, whose energy peaks 15-30 ms after the stick, a 25 ms attack
//     clamped that peak and an 80 ms release let the tail back up, so the kick's attack stood 1.9 dB less far out of its
//     body than without it (a 40 ms attack and a 200 ms release, 2 dB less: the next hit's attack caught in the last
//     one's release). The shaper raised a probe's attack by 6 dB for its first 10 ms and left its body as it was (5.1 dB
//     further out). Its attack setting is how long a hit's rise counts as its attack (the kick's slower, ours); what
//     it adds and takes the balance evens out, measuring each channel after its inserts (live-desk.js). On a kit split into a channel
//     per drum (audio.js splitKit) the kick and the snare each have one; a kit that is one channel has one, gentler.
//     Each raises a drum's attack only as far as it takes to stand where the boost puts the kit it was tuned on: its aim,
//     that kit's height (how far a hit's attack stands over its body, as the shaper hears it) and the boost. A drum
//     whose attack already stands out, as a drum machine's sharp samples do, is left as it is. Found 29 September 2026:
//     raised by the whole boost, the xDrum samples' 808 kick, whose attack stands 14.6 dB over its body (the Virtuosity
//     kick's, 2.9), stood 23 dB over it, and a render's mix peaked 9 dB over full scale;
//   - on the drums' group bus (submix.js), a glue compressor with the same slow attack, and a copy compressed hard
//     blended under it: parallel ("New York") compression, which brings the hits' bodies and the room up under the
//     transients rather than bringing the transients down. The bus's fader is its make-up: what the two take away,
//     measured (a bus is otherwise never moved: live-desk.js);
//   - the parts that share the drums' frequencies stepping back as a drum strikes: the bass under the kick, the chords
//     under the snare, a few dB and back within a tenth of a second (ours: far less than a pumping duck's 9 dB, which is
//     a sound of its own: mix-approaches.js MEASURED.pump). Keyed by the kick's and the snare's own channels, so only
//     where a kit is split; and not where the approach has a sidechain of its own (the electronic approach's pump).
// And none of it pushes the mix's peaks past what can be delivered: where the mix's peaks stand further over its
// loudness than a master's limiter can bring them to the delivery's loudness under its ceiling (live-desk.js
// deliverableCrestDb, 21 dB), each drum's boost is backed off by the excess, as an engineer backs off a transient
// designer when the master's peaks run out of room, and let back as the room returns (nextBackoff). Where the mix's
// peaks stand that far out already, its attacks are heard: a sparse part's, or a drum machine's sharp samples (the xDrum
// snares stood 24 dB over a mix's loudness with no punch at all). Backing off takes the same off every hit, so a ghost,
// a stroke and an accent keep their distances; a limiter on the drums' bus, tried first (29 September 2026), held a
// stroke and an accent at one peak (test/audio/dynamic-hierarchy.test.mjs).
// Each compressor is steered as an engineer sets one, by the reduction it makes on the hits (its meter's swing), toward
// its target (ours, after the kit drums' 2.2-2.6:1 fitted by Ma, De Man, Pestana, Black & Reiss 2015, the mix bus's
// measured 3 dB of reduction: Pestana & Reiss 2014, and the steeper settings punch asks for).
//
// **Whose it is.** An approach says how much punch it wants (mix-approaches.js `punch`): none for a concert, an intimate
// room or an ambient wash, whose drums are the players' own; this, otherwise. Without an approach, this.

// ---- Choices -----------------------------------------------------------------------------------------------------------
export const PUNCH=Object.freeze({
  // Each drum's own compressor, by what it is (kit-channels.js: a split kit's kick and snare; 'kit', a whole kit on one
  // channel): its ratio, attack and release, knee, and the reduction it is steered to on the hits, dB.
  // Each drum's transient designer: its attack raised by up to `boost` dB, its ring moved by `sustain` dB (shorter), a
  // hit's rise counting as its attack for about `attack` seconds, its ring measured against `release` (ours). `height`:
  // how far the attack of the kit the boost was tuned on stands over its body, as the shaper hears it (dB, the median
  // over its hits: dynamics-worklet.js), the Virtuosity kit's premixed samples (public/vendor/drum-kits): its kick's
  // four dynamics layers 2.4 to 4.4 dB, median 2.9; its snare's 36, 7.2 to 12.1, median 9.6; the three in a groove on
  // one channel (hats on the eighths, kick on 1 and 3, snare on 2 and 4), 2.7 and 8.0 at two dynamics, mean 5.4. The
  // aim is the height and the boost (punchAim), measured again by test/audio/punch.test.mjs.
  drums:Object.freeze({
    kick:Object.freeze({mode:'transient',boost:6,sustain:-6,attack:.012,release:.12,height:2.9}),
    snare:Object.freeze({mode:'transient',boost:5,sustain:-2,attack:.012,release:.1,height:9.6}),
    kit:Object.freeze({mode:'transient',boost:4,sustain:-2,attack:.015,release:.12,height:5.4}),
  }),
  // The drums' bus: its glue, and the hard copy blended under it (`mix`, the copy's share: 0.3 is about 10 dB under).
  glue:Object.freeze({ratio:2,attack:.03,release:.2,knee:6,targetDb:2}),
  parallel:Object.freeze({ratio:10,attack:.001,release:.1,knee:0,targetDb:12,mix:.3}),
  // The parts that step back as a drum strikes: from which drum (a kit channel), which roles, how far, how fast.
  ducks:Object.freeze([
    Object.freeze({from:'kick',to:Object.freeze(['bass']),rangeDb:3,attack:.001,release:.07,threshold:-40,ratio:8}),
    Object.freeze({from:'snare',to:Object.freeze(['keys','pad']),rangeDb:2,attack:.001,release:.09,threshold:-40,ratio:8}),
  ]),
  // Steering, as an engineer turns a compressor's threshold while watching its meter: by what the reduction on the hits
  // is short of or over the target, through the ratio's slope (a threshold lowered 1 dB takes 1 - 1/ratio dB more off a
  // hit over it), at most maxStepDb a decision, outside a dead band about the target, and only while the drum sounds
  // near its threshold (ours); the threshold's range; where it starts.
  maxStepDb:3,deadBandDb:1,activeMarginDb:18,thresholdRange:Object.freeze([-50,-3]),startThreshold:-20,
  // The reduction read at a decision: the deepest since the last (the meter's swing on the hardest hit), followed this
  // fraction of the way (ours: one loud accent moves it half as far).
  meterApproach:.5,
  // Make-up: what the compressors take away, measured before and after them over the level window, followed this
  // fraction of the way at each decision (ours: settles in a few decisions, never jumps), within this range, dB.
  makeupApproach:.5,makeupRange:Object.freeze([0,12]),
  // The prefix of a group's bus (submix.js) and the drums' group.
  drumsBus:'bus:drums',
  // Backing off for the mix's headroom: by the excess, at most backoffStepDb a decision; let back recoverStepDb a
  // decision once the mix's crest is recoverMarginDb inside what can be delivered (ours: backs off within a bar or two,
  // returns over half a minute, since the crest's peak is the loudest of the last minute).
  backoffStepDb:3,recoverStepDb:.5,recoverMarginDb:2,
});

// ---- Arithmetic --------------------------------------------------------------------------------------------------------
// What an approach asks of punch: its own (an object laid over these), none (false), or these (absent).
export function punchPlan(approachPunch,choices=PUNCH){
  if(approachPunch===false||approachPunch===null)return null;
  if(!approachPunch||approachPunch===true)return choices;
  return Object.freeze({...choices,...approachPunch});
}
// A punch plan scaled for a scene's attack legibility (shared/mix-intention.js punchScale): each drum's transient boost
// and ring cut times `scale`, and so its aim (punchAim) as far over the kit it was tuned on; none at 0 (no punch), the
// plan's own at 1 or unsaid (null).
export function scaledPunch(plan,scale){
  if(!plan||scale===null||scale===undefined||scale===1)return plan;
  if(!(scale>0))return null;
  return Object.freeze({...plan,drums:Object.freeze(Object.fromEntries(Object.entries(plan.drums).map(([piece,drum])=>
    [piece,Object.freeze({...drum,boost:drum.boost*scale,sustain:drum.sustain*scale})])))});
}
// The next backoff for the mix's headroom (dB, from 0 to the plan's largest boost): up by the excess of the mix's crest
// (its peaks over its integrated loudness, dB) over what can be delivered, at most backoffStepDb; down recoverStepDb
// once it is recoverMarginDb inside; left where it is between, and while the crest is unmeasured.
export function nextBackoff(backoff,crestDb,deliverableDb,largestBoost,{backoffStepDb,recoverStepDb,recoverMarginDb}=PUNCH){
  if(!Number.isFinite(crestDb)||!Number.isFinite(deliverableDb))return backoff;
  const excess=crestDb-deliverableDb;
  const next=excess>0?backoff+Math.min(backoffStepDb,excess):excess<-recoverMarginDb?backoff-recoverStepDb:backoff;
  return Math.max(0,Math.min(Math.max(0,largestBoost),next));
}
// A plan with each drum's boost backed off (and so its aim), none below 0.
export function backedOff(plan,backoff){
  if(!plan||!(backoff>0))return plan;
  return Object.freeze({...plan,drums:Object.freeze(Object.fromEntries(Object.entries(plan.drums).map(([piece,drum])=>
    [piece,Object.freeze({...drum,boost:Math.max(0,drum.boost-backoff)})])))});
}
// How far a drum's shaper raises its attacks' height over their bodies: to where its boost puts the kit it was tuned on
// (dB), scaled with the boost (scaledPunch); none (0: every attack raised by the whole boost) for a drum with no height.
export const punchAim=drum=>Number.isFinite(drum?.height)&&drum.boost>0?drum.height+drum.boost:0;
// What a channel is to punch: a split kit's kick or snare, a whole kit (a drums channel that is neither a kit's drum
// nor a bus), the drums' bus, or nothing.
export function punchRole(track,id,choices=PUNCH){
  if(!track)return null;
  if(id===choices.drumsBus&&track.bus)return 'bus';
  if(track.bus)return null;
  if(track.piece)return choices.drums[track.piece]?track.piece:null;
  return track.role==='drums'?'kit':null;
}
// The next threshold toward a target reduction on the hits: moved by what the reduction is short of (down) or over (up),
// through the ratio's slope, at most maxStepDb, or left where it is inside the dead band.
export function steerThreshold(threshold,reductionDb,targetDb,{maxStepDb,deadBandDb,thresholdRange:[low,high]}=PUNCH,ratio=PUNCH.glue.ratio){
  const short=targetDb-reductionDb;
  if(Math.abs(short)<=deadBandDb)return threshold;
  const slope=1-1/Math.max(1+Number.EPSILON,ratio),move=Math.max(-maxStepDb,Math.min(maxStepDb,short/slope));
  return Math.max(low,Math.min(high,Math.round(threshold-move)));
}
// The make-up gain after one more look: toward what the compressors took away (the loudness before them less after).
export function nextMakeup(makeup,lostDb,{makeupApproach,makeupRange:[low,high]}=PUNCH){
  if(!Number.isFinite(lostDb))return makeup;
  const target=Math.max(low,Math.min(high,lostDb));
  return makeup+(target-makeup)*makeupApproach;
}
