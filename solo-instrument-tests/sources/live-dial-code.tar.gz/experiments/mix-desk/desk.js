// The mixing a workstation has and this ensemble did not.
//
// `public/audio-mixer.js` gives every track a pan, a dry gain and four sends into shared
// reverb, delay, compression and plugin buses, and `mh_CoordBOT` owns foreground/background
// placement. Against a mainstream desk — Ableton's mixer and Utility device, or any of
// Pro Tools, Logic and Reaper — the gaps are these, and this file is all of them, as pure
// arithmetic so each can be tested rather than eyeballed:
//
//   * **pan law**, because summing two panned sources depends on which law is in force;
//   * **width and mid-side**, and mono folding, which is Ableton's Utility;
//   * **polarity inversion**, the other half of Utility;
//   * **mute, solo and solo-safe**, resolved the way a desk resolves them rather than as
//     independent gains;
//   * **VCA-style fader groups**, where a group fader scales its members without moving
//     their own faders, and **mute groups**;
//   * **track delay** in milliseconds or samples, Ableton's ± per-track delay;
//   * **pre- and post-fader sends**, which is the difference between a reverb that follows
//     a fade and one that does not;
//   * **loudness metering to ITU-R BS.1770**, K-weighted, because "it sounds about right"
//     is not a measurement;
//   * **stereo correlation**, the meter that catches a width setting that has gone phasey;
//   * **gain sharing**, Dan Dugan's automatic mixer, which is the one item on this list
//     that is about *relationships between players* and therefore the most musebot-shaped
//     thing here;
//   * **sidechain ducking**, with a real envelope follower.
//
// Deliberately absent: anything about recording, arrangement, clips, automation lanes or
// export. This is the mixing half only.

export const DESK=Object.freeze({
  // The three laws that exist, plus the name the -6 dB one usually goes by. Writing them
  // out as four independent laws was a mistake the tests caught: "linear" *is* the -6 dB
  // law — it keeps the sum constant and therefore loses 6 dB of level in the middle — and a
  // first attempt at -6 dB produced -3 dB because its scaling cancelled itself out.
  laws:Object.freeze(['-3dB','-4.5dB','-6dB','linear']),
  defaultLaw:'-3dB',
  maxWidth:2,
  maxDelayMs:200,          // Ableton's track delay range, near enough
  duganHeadroomDb:3,       // 3 dB per doubling of open channels, as Dugan's own
  meterBlock:4800,         // 100 ms at 48 kHz: the BS.1770 gating block
});

const clamp=(value,low,high)=>Math.min(high,Math.max(low,value));
const number=(value,fallback=0)=>{
  if(value===null||value===undefined||value==='')return fallback;
  const parsed=Number(value);
  return Number.isFinite(parsed)?parsed:fallback;
};
export const dbToGain=db=>10**(number(db,0)/20);
export const gainToDb=gain=>20*Math.log10(Math.max(1e-12,number(gain,0)));

// ---- pan ---------------------------------------------------------------------

// `position` runs -1 (hard left) to +1 (hard right). The law decides what happens in the
// middle: linear keeps the *sum* constant and dips 3 dB in power, the others keep power
// constant and dip the sum instead. A desk that gets this wrong makes every centre-panned
// source quietly louder than the ones beside it.
export function panGains(position,{law=DESK.defaultLaw}={}){
  const pan=clamp(number(position,0),-1,1);
  const fraction=(pan+1)/2;                      // 0 … 1, left to right
  const angle=fraction*Math.PI/2;
  // Equal power: unity at the extremes, −3 dB in the middle, constant power everywhere.
  const power={left:Math.cos(angle),right:Math.sin(angle)};
  // Sum-preserving: unity at the extremes, −6 dB in the middle. This is what "linear" means.
  const linear={left:1-fraction,right:fraction};
  if(law==='-3dB')return power;
  if(law==='-6dB'||law==='linear')return linear;
  // The compromise: the geometric mean of the two, which lands at −4.5 dB in the middle.
  return {left:Math.sqrt(power.left*linear.left),right:Math.sqrt(power.right*linear.right)};
}

// ---- width, mid-side, polarity ----------------------------------------------

export const midSide=Object.freeze({
  encode(left,right){return {mid:(left+right)/2,side:(left-right)/2}},
  decode(mid,side){return {left:mid+side,right:mid-side}},
});

// 0 is mono, 1 is unchanged, 2 is twice as wide. Ableton's Utility width, and the same
// arithmetic: scale the side signal.
export function applyWidth(left,right,width=1){
  const amount=clamp(number(width,1),0,DESK.maxWidth);
  const {mid,side}=midSide.encode(left,right);
  return midSide.decode(mid,side*amount);
}
export const polarityGain=invert=>invert?-1:1;

// ---- mute, solo, groups ------------------------------------------------------

// A desk does not add mute and solo together; it resolves them. Solo mutes everything not
// soloed *unless* a channel is solo-safe, which is how a reverb return stays audible while
// a source is soloed.
export class SoloBus {
  constructor(){this.muted=new Set();this.soloed=new Set();this.safe=new Set()}
  mute(id,value=true){value?this.muted.add(id):this.muted.delete(id);return this}
  solo(id,value=true){value?this.soloed.add(id):this.soloed.delete(id);return this}
  soloSafe(id,value=true){value?this.safe.add(id):this.safe.delete(id);return this}
  get soloing(){return this.soloed.size>0}
  // 1 or 0 for a given channel, with solo taking precedence over mute the way a desk does:
  // a soloed channel is heard even if its own mute is down, which is what performers expect.
  gain(id){
    if(this.soloing)return this.soloed.has(id)||this.safe.has(id)?1:0;
    return this.muted.has(id)?0:1;
  }
}

// A VCA: a group fader that scales its members without touching their own faders, so
// releasing the group leaves every relative balance exactly as it was.
export class FaderGroups {
  constructor(){this.groups=new Map();this.membership=new Map()}
  assign(id,group){
    this.membership.set(id,group);
    if(!this.groups.has(group))this.groups.set(group,{gain:1,muted:false});
    return this;
  }
  set(group,{gain,muted}={}){
    const entry=this.groups.get(group)||{gain:1,muted:false};
    if(gain!==undefined)entry.gain=clamp(number(gain,1),0,4);
    if(muted!==undefined)entry.muted=Boolean(muted);
    this.groups.set(group,entry);
    return this;
  }
  gain(id){
    const group=this.membership.get(id);
    if(group===undefined)return 1;
    const entry=this.groups.get(group);
    return entry?(entry.muted?0:entry.gain):1;
  }
}

// ---- delay and sends ---------------------------------------------------------

// Ableton's track delay, in either unit. Negative is early, which only works because the
// scheduler already runs a lookahead — without one, a negative delay is a lie.
export function trackDelay({milliseconds,samples,sampleRate=48000,lookaheadSeconds=.25}={}){
  const ms=samples!==undefined?number(samples,0)/sampleRate*1000:number(milliseconds,0);
  const bounded=clamp(ms,-DESK.maxDelayMs,DESK.maxDelayMs);
  const early=bounded<0;
  const possible=!early||Math.abs(bounded)/1000<=lookaheadSeconds;
  return {milliseconds:bounded,samples:Math.round(bounded/1000*sampleRate),
    early,possible,
    // What a graph can actually do: a delay line cannot be negative, so an early track is
    // everything *else* delayed by the same amount.
    compensation:early?Math.abs(bounded):0};
}

// A send is pre- or post-fader. Post follows the fader, which is what a reverb usually
// wants; pre does not, which is what a monitor mix or a deliberate wash wants.
export function sendGain({amount=0,fader=1,tap='post'}={}){
  const send=clamp(number(amount,0),0,1);
  return tap==='pre'?send:send*clamp(number(fader,1),0,4);
}

// ---- metering ----------------------------------------------------------------

// K-weighting from ITU-R BS.1770: a high-shelf, then a high-pass. These are the published
// 48 kHz coefficients, used as they are at 48 kHz.
const K_STAGE1=Object.freeze({b:[1.53512485958697,-2.69169618940638,1.19839281085285],
  a:[-1.69065929318241,.73248077421585]});
const K_STAGE2=Object.freeze({b:[1,-2,1],a:[-1.99004745483398,.99007225036621]});
// At another rate they are re-derived rather than reused: the analog filters the published
// coefficients were made from, brought to that rate by the bilinear transform. These are
// libebur128's parameters (ffmpeg's ebur128 resamples to 48 kHz instead); at 48 kHz they give the
// published coefficients back to within 1e-8, which a test checks.
const K_PROTOTYPE=Object.freeze({shelfHz:1681.974450955533,shelfDb:3.999843853973347,shelfQ:.7071752369554196,
  shelfSlope:.4996667741545416,highpassHz:38.13547087602444,highpassQ:.5003270373238773});
// The lowest rate the derivation is trusted at: the shelf sits at 1.7 kHz, and below this the
// warping of its upper octaves toward Nyquist is no longer small.
export const K_WEIGHTING_MIN_RATE=16000;
export function deriveKWeighting(sampleRate){
  const p=K_PROTOTYPE,k1=Math.tan(Math.PI*p.shelfHz/sampleRate),vh=10**(p.shelfDb/20),vb=vh**p.shelfSlope;
  const a0=1+k1/p.shelfQ+k1*k1;
  const stage1={b:[(vh+vb*k1/p.shelfQ+k1*k1)/a0,2*(k1*k1-vh)/a0,(vh-vb*k1/p.shelfQ+k1*k1)/a0],
    a:[2*(k1*k1-1)/a0,(1-k1/p.shelfQ+k1*k1)/a0]};
  const k2=Math.tan(Math.PI*p.highpassHz/sampleRate),d=1+k2/p.highpassQ+k2*k2;
  const stage2={b:[1,-2,1],a:[2*(k2*k2-1)/d,(1-k2/p.highpassQ+k2*k2)/d]};
  return {stage1,stage2,coefficients:'derived'};
}
export function kWeighting(sampleRate=48000){
  return sampleRate===48000?{stage1:K_STAGE1,stage2:K_STAGE2,coefficients:'published'}:deriveKWeighting(sampleRate);
}

class Biquad {
  constructor({b,a}){this.b=b;this.a=a;this.x1=0;this.x2=0;this.y1=0;this.y2=0}
  process(x){
    const y=this.b[0]*x+this.b[1]*this.x1+this.b[2]*this.x2-this.a[0]*this.y1-this.a[1]*this.y2;
    this.x2=this.x1;this.x1=x;this.y2=this.y1;this.y1=y;
    return y;
  }
}

// ---- equalisation ----------------------------------------------------------
//
// A desk without an EQ is not a desk. Every mixer in every workstation has one, and this one
// had a `Biquad` for its loudness meter and nothing to shape a sound with — which showed up
// as a measurement: across eight aesthetic characters, the *brightness* of the result barely
// moved, because nothing any of them could ask for changed a spectrum.
//
// Three bands, which is what a channel strip on a console has: a low shelf, a swept peak, and
// a high shelf. The coefficients are Robert Bristow-Johnson's audio EQ cookbook formulas,
// which are the ones every implementation uses; the band layout and its defaults are ours.
export const EQ=Object.freeze({
  bands:Object.freeze(['low','mid','high']),
  defaults:Object.freeze({low:{hz:120,gainDb:0,q:.7},mid:{hz:1000,gainDb:0,q:.9},
    high:{hz:6000,gainDb:0,q:.7}}),
  maxGainDb:18,
  minHz:20,
  maxHz:20000,
  // A shelf's `q` is the cookbook's shelf slope S, not a Q. Its square root's radicand,
  // (A + 1/A)(1/S - 1) + 2, is negative past S = (A + 1/A) / (A + 1/A - 2), and the filter then
  // gives NaN (the mathematical audit's I18: 18 dB at q 4 did). S = 1 is the steepest shelf that
  // stays monotonic, and within (0, 1] the radicand is never under 2: a shelf's slope is held there.
  shelfSlope:Object.freeze([.1,1]),
});

// A peaking filter, from the cookbook. `A` is the amplitude the gain asks for, and the
// asymmetry between b and a is what makes a boost and a cut mirror each other exactly.
function peakingCoefficients({hz,gainDb,q,sampleRate}){
  const A=10**(number(gainDb,0)/40);
  const w=2*Math.PI*clamp(number(hz,1000),EQ.minHz,Math.min(EQ.maxHz,sampleRate/2-1))/sampleRate;
  const alpha=Math.sin(w)/(2*Math.max(.05,number(q,.9)));
  const a0=1+alpha/A;
  return {
    b:[(1+alpha*A)/a0,(-2*Math.cos(w))/a0,(1-alpha*A)/a0],
    a:[(-2*Math.cos(w))/a0,(1-alpha/A)/a0],
  };
}
// A shelf, also from the cookbook. `kind` is 'low' or 'high'.
function shelfCoefficients({hz,gainDb,q,sampleRate,kind}){
  const A=10**(number(gainDb,0)/40);
  const w=2*Math.PI*clamp(number(hz,1000),EQ.minHz,Math.min(EQ.maxHz,sampleRate/2-1))/sampleRate;
  const cos=Math.cos(w),sin=Math.sin(w);
  const slope=clamp(number(q,.7),EQ.shelfSlope[0],EQ.shelfSlope[1]);
  const alpha=sin/2*Math.sqrt((A+1/A)*(1/slope-1)+2);
  const twoRootAlpha=2*Math.sqrt(A)*alpha;
  if(kind==='low'){
    const a0=(A+1)+(A-1)*cos+twoRootAlpha;
    return {
      b:[A*((A+1)-(A-1)*cos+twoRootAlpha)/a0,
        2*A*((A-1)-(A+1)*cos)/a0,
        A*((A+1)-(A-1)*cos-twoRootAlpha)/a0],
      a:[-2*((A-1)+(A+1)*cos)/a0,((A+1)+(A-1)*cos-twoRootAlpha)/a0],
    };
  }
  const a0=(A+1)-(A-1)*cos+twoRootAlpha;
  return {
    b:[A*((A+1)+(A-1)*cos+twoRootAlpha)/a0,
      -2*A*((A-1)+(A+1)*cos)/a0,
      A*((A+1)+(A-1)*cos-twoRootAlpha)/a0],
    a:[2*((A-1)-(A+1)*cos)/a0,((A+1)-(A-1)*cos-twoRootAlpha)/a0],
  };
}

// A channel's equaliser: three bands, each bypassed while its gain is zero so that a flat EQ
// costs nothing and — more importantly — changes nothing. A filter at unity gain is not quite
// an identity in floating point, and a desk that quietly filtered every channel it had never
// been asked to touch would be a desk nobody could reason about.
export class ChannelEq {
  constructor({sampleRate=48000,bands={}}={}){
    this.sampleRate=sampleRate;
    this.bands={};
    for(const band of EQ.bands)
      this.bands[band]={...EQ.defaults[band],...(bands[band]||{})};
    this.build();
  }
  set(band,settings={}){
    if(!EQ.bands.includes(band))return null;
    const current=this.bands[band];
    if(settings.hz!==undefined)current.hz=clamp(number(settings.hz,current.hz),EQ.minHz,EQ.maxHz);
    if(settings.gainDb!==undefined)
      current.gainDb=clamp(number(settings.gainDb,0),-EQ.maxGainDb,EQ.maxGainDb);
    if(settings.q!==undefined)current.q=band==='mid'?clamp(number(settings.q,current.q),.1,18):clamp(number(settings.q,current.q),...EQ.shelfSlope);
    this.build();
    return {...current};
  }
  build(){
    this.filters=[];
    for(const band of EQ.bands){
      const settings=this.bands[band];
      if(Math.abs(settings.gainDb)<1e-9)continue;        // bypassed, and therefore exact
      const coefficients=band==='mid'
        ?peakingCoefficients({...settings,sampleRate:this.sampleRate})
        :shelfCoefficients({...settings,sampleRate:this.sampleRate,kind:band});
      this.filters.push(new Biquad(coefficients));
    }
    return this.filters.length;
  }
  get flat(){return this.filters.length===0}
  process(sample){
    let value=sample;
    for(const filter of this.filters)value=filter.process(value);
    return value;
  }
  run(frame){
    if(this.flat)return frame;
    const out=new Float32Array(frame.length);
    for(let index=0;index<frame.length;index++)out[index]=this.process(frame[index]);
    return out;
  }
  // The magnitude response at a frequency, in dB, computed from the coefficients rather than
  // measured — so a test can check that a 6 dB boost at 6 kHz is 6 dB at 6 kHz.
  responseDb(hz){
    let total=1;
    for(const filter of this.filters){
      const w=2*Math.PI*hz/this.sampleRate;
      const cos1=Math.cos(w),cos2=Math.cos(2*w),sin1=Math.sin(w),sin2=Math.sin(2*w);
      const numeratorReal=filter.b[0]+filter.b[1]*cos1+filter.b[2]*cos2;
      const numeratorImag=-(filter.b[1]*sin1+filter.b[2]*sin2);
      const denominatorReal=1+filter.a[0]*cos1+filter.a[1]*cos2;
      const denominatorImag=-(filter.a[0]*sin1+filter.a[1]*sin2);
      total*=Math.hypot(numeratorReal,numeratorImag)
        /Math.max(1e-12,Math.hypot(denominatorReal,denominatorImag));
    }
    // An invalid filter says so: NaN, not the floor a gain of NaN would be turned into.
    return Number.isFinite(total)?gainToDb(total):NaN;
  }
  settings(){return Object.fromEntries(EQ.bands.map(band=>[band,{...this.bands[band]}]))}
}

// Momentary (400 ms) and short-term (3 s) loudness, in LUFS, per BS.1770's own formula:
// −0.691 + 10·log₁₀ of the channel-weighted mean square of the K-weighted signal.
export class LoudnessMeter {
  constructor({sampleRate=48000,channels=2}={}){
    this.sampleRate=sampleRate;
    // Published at 48 kHz, derived for any other rate (kWeighting); `exact` says whether the
    // K-weighting is BS.1770's at this rate, which below K_WEIGHTING_MIN_RATE it is not.
    const weighting=kWeighting(sampleRate);
    this.coefficients=weighting.coefficients;
    this.exact=sampleRate===48000||Number.isFinite(sampleRate)&&sampleRate>=K_WEIGHTING_MIN_RATE;
    this.filters=Array.from({length:channels},()=>[new Biquad(weighting.stage1),new Biquad(weighting.stage2)]);
    this.blockSamples=Math.round(sampleRate*.1);
    this.blocks=[];                     // mean square per 100 ms block, summed across channels
    this.allBlocks=[];                  // every block, for an integrated measurement
    this.keepAllBlocks=false;
    this.accumulator=0;this.count=0;
    this.peak=0;
  }
  // `frames` is an array of channel Float arrays, all the same length.
  //
  // Each sample through each channel's two K-weighting stages as Biquad.process computes them, the same arithmetic in
  // the same order, but with the coefficients (every channel's are the same) and each filter's state held in locals
  // for the length of the call and written back after it: every figure is the same to the bit. As method calls this
  // loop was 28% of a four-bot render's time with the desk.
  push(frames){
    const length=frames[0]?.length||0,channels=frames.length;
    if(!length||!channels)return this;
    const filters=this.filters,[stage1,stage2]=filters[0];
    const [p0,p1,p2]=stage1.b,[p3,p4]=stage1.a,[q0,q1,q2]=stage2.b,[q3,q4]=stage2.a;
    const state=new Float64Array(channels*8);
    for(let channel=0;channel<channels;channel++){
      const [shelf,highpass]=filters[channel],at=channel*8;
      state[at]=shelf.x1;state[at+1]=shelf.x2;state[at+2]=shelf.y1;state[at+3]=shelf.y2;
      state[at+4]=highpass.x1;state[at+5]=highpass.x2;state[at+6]=highpass.y1;state[at+7]=highpass.y2;
    }
    let peak=this.peak,accumulator=this.accumulator,count=this.count;
    for(let index=0;index<length;index++){
      let sum=0;
      for(let channel=0;channel<channels;channel++){
        const sample=frames[channel][index]||0,at=channel*8,magnitude=Math.abs(sample);
        if(magnitude>peak)peak=magnitude;
        const shelved=p0*sample+p1*state[at]+p2*state[at+1]-p3*state[at+2]-p4*state[at+3];
        state[at+1]=state[at];state[at]=sample;state[at+3]=state[at+2];state[at+2]=shelved;
        const weighted=q0*shelved+q1*state[at+4]+q2*state[at+5]-q3*state[at+6]-q4*state[at+7];
        state[at+5]=state[at+4];state[at+4]=shelved;state[at+7]=state[at+6];state[at+6]=weighted;
        sum+=weighted*weighted;         // every channel weighted 1.0: stereo, no surround
      }
      accumulator+=sum;count++;
      if(count>=this.blockSamples){
        const block=accumulator/count;
        this.blocks.push(block);
        if(this.keepAllBlocks)this.allBlocks.push(block);
        accumulator=0;count=0;
        while(this.blocks.length>30)this.blocks.shift();   // three seconds
      }
    }
    for(let channel=0;channel<channels;channel++){
      const [shelf,highpass]=filters[channel],at=channel*8;
      shelf.x1=state[at];shelf.x2=state[at+1];shelf.y1=state[at+2];shelf.y2=state[at+3];
      highpass.x1=state[at+4];highpass.x2=state[at+5];highpass.y1=state[at+6];highpass.y2=state[at+7];
    }
    this.peak=peak;this.accumulator=accumulator;this.count=count;
    return this;
  }
  loudness(blocks){
    const window=this.blocks.slice(-blocks);
    if(!window.length)return null;
    const mean=window.reduce((total,value)=>total+value,0)/window.length;
    return mean<=0?null:-.691+10*Math.log10(mean);
  }
  momentary(){return this.loudness(4)}      // 400 ms
  shortTerm(){return this.loudness(30)}     // 3 s
  // The gated integrated measurement and the loudness range, over everything pushed so far.
  // Requires `keepAllBlocks`, because an integrated figure is not a rolling one.
  summary(){return loudnessSummary(this.allBlocks,{sampleRate:this.sampleRate})}
  peakDb(){return gainToDb(this.peak)}
}


// ---- integrated loudness, loudness range, true peak -------------------------

// Momentary and short-term are what a meter shows a performer. *Integrated* loudness is
// what a target is set against, and it is not simply the mean of the others: BS.1770 gates
// it twice — once absolutely at −70 LUFS to drop silence, then again at 10 LU below the
// ungated mean to drop the quiet parts that would otherwise drag a dynamic piece down.
// Without the second gate a piece with long quiet passages measures far lower than it
// sounds, and normalising it to a target would make it far too loud.
export const LOUDNESS=Object.freeze({
  blockSeconds:.4,          // BS.1770's gating block
  blockStride:.1,           // at 75% overlap
  shortTermSeconds:3,       // EBU R128 short-term, for the loudness range
  absoluteGateLufs:-70,
  relativeGateLu:-10,       // BS.1770 integrated
  rangeGateLu:-20,          // EBU Tech 3342 loudness range
  truePeakOversample:4,
  defaultCeilingDbtp:-1,    // the usual delivery ceiling
});

const lufsFromMeanSquare=mean=>mean<=0?null:-.691+10*Math.log10(mean);

// A 4× oversampling true-peak estimate. BS.1770-4 specifies a 48-tap polyphase filter; this
// is a windowed-sinc of the same shape and order, which is an approximation and is labelled
// as one — it reads within a few tenths of a decibel of the specified filter on material
// like ours, and it is the difference between "no clipping" and "no inter-sample clipping".
const SINC_TAPS=24;
function polyphase(oversample=LOUDNESS.truePeakOversample,taps=SINC_TAPS){
  const phases=[];
  for(let phase=0;phase<oversample;phase++){
    const coefficients=new Float64Array(taps);
    let sum=0;
    for(let tap=0;tap<taps;tap++){
      const position=tap-taps/2+phase/oversample;
      const sinc=position===0?1:Math.sin(Math.PI*position)/(Math.PI*position);
      const window=.54-.46*Math.cos(2*Math.PI*tap/(taps-1));   // Hamming
      coefficients[tap]=sinc*window;sum+=coefficients[tap];
    }
    for(let tap=0;tap<taps;tap++)coefficients[tap]/=sum||1;
    phases.push(coefficients);
  }
  return phases;
}
const PHASES=polyphase();

// A window's interpolated samples are at most its largest absolute sample times the largest of the phases' summed
// absolute taps (at least 1, since each phase sums to 1). So a block of windows whose bound, with a margin far wider
// than any rounding, is no more than the peak found so far holds nothing larger, and is skipped (as render/limiter.mjs
// skips spans that cannot reach its ceiling). Every window computed is summed in the same order as before, so the peak
// is the same value, bit for bit, as computing them all (test/desk-true-peak.test.mjs). A NaN in a block keeps it from
// being skipped, and nothing is skipped once the peak is infinite, so those come out as they always did.
const PHASE_L1=Math.max(...PHASES.map(coefficients=>coefficients.reduce((sum,value)=>sum+Math.abs(value),0)));
const SKIP_BLOCK=64,SKIP_MARGIN=1+1e-9;
export function truePeak(frames){
  let peak=0;
  for(const channel of frames){
    const length=channel.length;
    for(let start=0;start<length;start+=SKIP_BLOCK){
      const end=Math.min(length,start+SKIP_BLOCK);
      if(peak<Infinity){
        // (The samples the block's windows reach: SINC_TAPS/2 before its first, SINC_TAPS/2 - 1 after its last.)
        let largest=0;
        for(let at=Math.max(0,start-SINC_TAPS/2),to=Math.min(length,end+SINC_TAPS/2-1);at<to;at++)largest=Math.max(largest,Math.abs(channel[at]));
        if(largest*PHASE_L1*SKIP_MARGIN<=peak)continue;
      }
      for(let index=start;index<end;index++){
        peak=Math.max(peak,Math.abs(channel[index]));
        const first=index-SINC_TAPS/2,inside=first>=0&&first+SINC_TAPS<=length;
        for(const coefficients of PHASES){
          let sum=0;
          if(inside)for(let tap=0;tap<SINC_TAPS;tap++)sum+=coefficients[tap]*channel[first+tap];
          else for(let tap=0;tap<coefficients.length;tap++){
            const at=index-coefficients.length/2+tap;
            sum+=coefficients[tap]*(at>=0&&at<channel.length?channel[at]:0);
          }
          peak=Math.max(peak,Math.abs(sum));
        }
      }
    }
  }
  return {gain:peak,dbtp:gainToDb(peak)};
}

// Everything a delivery decision needs, from the 100 ms mean-square blocks a LoudnessMeter
// has already accumulated.
export function loudnessSummary(blocks,{sampleRate=48000}={}){
  const perBlock=Math.round(LOUDNESS.blockSeconds/LOUDNESS.blockStride);   // 4
  const gating=[];
  for(let index=0;index+perBlock<=blocks.length;index++){
    let sum=0;
    for(let offset=0;offset<perBlock;offset++)sum+=blocks[index+offset];
    gating.push(sum/perBlock);
  }
  const loud=gating.map(lufsFromMeanSquare).map((value,index)=>({lufs:value,mean:gating[index]}))
    .filter(entry=>entry.lufs!==null);
  const aboveAbsolute=loud.filter(entry=>entry.lufs>LOUDNESS.absoluteGateLufs);
  // The loudest 400 ms anywhere in the take, ungated. R128 calls it the maximum momentary
  // loudness and BWF has a field for it, so it is measured here rather than guessed there.
  const maxMomentary=loud.length?Math.max(...loud.map(entry=>entry.lufs)):null;
  if(!aboveAbsolute.length)
    return {integrated:null,range:null,blocks:gating.length,maxMomentary,maxShortTerm:null,
      shortTerm:0};
  const ungated=aboveAbsolute.reduce((total,entry)=>total+entry.mean,0)/aboveAbsolute.length;
  const relativeGate=lufsFromMeanSquare(ungated)+LOUDNESS.relativeGateLu;
  const kept=aboveAbsolute.filter(entry=>entry.lufs>relativeGate);
  const integrated=kept.length
    ?lufsFromMeanSquare(kept.reduce((total,entry)=>total+entry.mean,0)/kept.length)
    :lufsFromMeanSquare(ungated);

  // Loudness range, EBU Tech 3342: the spread of the *short-term* values, gated 20 LU below
  // their own mean, as the 10th to 95th percentile. It is what makes "quite dynamic" and
  // "quite consistent" measurable rather than adjectives.
  const shortPer=Math.round(LOUDNESS.shortTermSeconds/LOUDNESS.blockStride);   // 30
  const shortTerm=[];
  for(let index=0;index+shortPer<=blocks.length;index++){
    let sum=0;
    for(let offset=0;offset<shortPer;offset++)sum+=blocks[index+offset];
    const value=lufsFromMeanSquare(sum/shortPer);
    if(value!==null&&value>LOUDNESS.absoluteGateLufs)shortTerm.push({lufs:value,mean:sum/shortPer});
  }
  let range=null;
  if(shortTerm.length>=2){
    const mean=shortTerm.reduce((total,entry)=>total+entry.mean,0)/shortTerm.length;
    const gate=lufsFromMeanSquare(mean)+LOUDNESS.rangeGateLu;
    const values=shortTerm.filter(entry=>entry.lufs>gate).map(entry=>entry.lufs)
      .sort((left,right)=>left-right);
    if(values.length>=2){
      const at=fraction=>values[Math.min(values.length-1,Math.max(0,Math.round(fraction*(values.length-1))))];
      range=at(.95)-at(.1);
    }
  }
  return {integrated,range,blocks:gating.length,shortTerm:shortTerm.length,maxMomentary,
    // And the loudest 3 s, which is the other field BWF keeps.
    maxShortTerm:shortTerm.length?Math.max(...shortTerm.map(entry=>entry.lufs)):null};
}

// What gain would put this material at a target loudness, and whether that gain is
// deliverable without inter-sample clipping.
//
// This is the honest part. On dynamic material a loud target is simply not reachable at a
// −1 dBTP ceiling: the peaks arrive before the loudness does. The answer is to report both
// numbers — the gain the target asks for and the gain the ceiling allows — and let the
// caller decide, rather than clipping quietly or compressing without being asked.
export function loudnessTarget(frames,{targetLufs=-16,ceilingDbtp=LOUDNESS.defaultCeilingDbtp,
  sampleRate=48000}={}){
  const meter=new LoudnessMeter({sampleRate,channels:frames.length});
  meter.keepAllBlocks=true;
  meter.push(frames);
  const summary=loudnessSummary(meter.allBlocks,{sampleRate});
  if(summary.integrated===null)
    // The same fields as the measured branch, so a caller reading `allowedDb` does not get
    // `undefined` from silence and quietly compute NaN from it.
    return {integrated:null,range:null,truePeakDbtp:null,
      requestedDb:0,allowedDb:0,gain:1,achievedLufs:null,
      limited:false,shortfallDb:0,reason:'nothing audible to measure'};
  const requestedDb=targetLufs-summary.integrated;
  const peak=truePeak(frames);
  const headroomDb=ceilingDbtp-peak.dbtp;
  const allowedDb=Math.min(requestedDb,headroomDb);
  return {
    integrated:summary.integrated,range:summary.range,
    truePeakDbtp:peak.dbtp,
    requestedDb,allowedDb,
    gain:dbToGain(allowedDb),
    achievedLufs:summary.integrated+allowedDb,
    limited:allowedDb<requestedDb-1e-9,
    shortfallDb:Math.max(0,requestedDb-allowedDb),
    reason:allowedDb<requestedDb-1e-9
      ?`the ${ceilingDbtp} dBTP ceiling allows ${allowedDb.toFixed(2)} dB of the ${requestedDb.toFixed(2)} dB asked for`
      :'the target is reachable without touching the peaks',
  };
}

// The meter that catches a width setting gone wrong: +1 is mono, 0 is uncorrelated, −1 is
// out of phase and will disappear when the mix is folded down.
export function correlation(left,right){
  let sumLeft=0,sumRight=0,sumBoth=0;
  const length=Math.min(left.length,right.length);
  for(let index=0;index<length;index++){
    sumLeft+=left[index]*left[index];
    sumRight+=right[index]*right[index];
    sumBoth+=left[index]*right[index];
  }
  const denominator=Math.sqrt(sumLeft*sumRight);
  return denominator<1e-12?0:clamp(sumBoth/denominator,-1,1);
}

// ---- gain sharing and ducking ------------------------------------------------

// Dan Dugan's automatic mixer, which is the one thing on a desk that is really about an
// ensemble: gain is *shared* between whoever is sounding, so the sum stays where it was as
// players come and go. Each doubling of open channels costs about 3 dB, and a settable
// number may stay at full gain before the sharing bites.
export function duganGains(levels,{fullGainChannels=1,headroomDb=DESK.duganHeadroomDb,threshold=1e-4}={}){
  const entries=Object.entries(levels||{}).map(([id,level])=>[id,Math.max(0,number(level,0))]);
  const open=entries.filter(([,level])=>level>threshold);
  const total=open.reduce((sum,[,level])=>sum+level,0);
  const allowance=Math.max(1,number(fullGainChannels,1));
  // Dugan's own share: a channel's gain is its level as a fraction of the whole, which
  // automatically gives the loudest source the most and mutes the silent ones.
  const gains={};
  for(const [id,level] of entries){
    if(level<=threshold){gains[id]=0;continue}
    const share=total>0?level/total:0;
    // With `allowance` channels open nothing is attenuated; beyond that the sharing applies,
    // scaled so each doubling costs `headroomDb`.
    const excess=Math.max(0,Math.log2(Math.max(1,open.length)/allowance));
    gains[id]=share*open.length*dbToGain(-headroomDb*excess)/Math.max(1,open.length);
  }
  // `+0` rather than `-0`, which is the same number and a different JSON value.
  const attenuationDb=-headroomDb*Math.max(0,Math.log2(Math.max(1,open.length)/allowance))||0;
  return {gains,open:open.map(([id])=>id),attenuationDb};
}

// An envelope follower and a ratio: the honest way to duck one source under another when
// the platform's compressor has no key input. The envelope is the *ducking* bot's own, so
// the reason a channel dipped is legible rather than hidden in a detector.
export class Ducker {
  constructor({attackSeconds=.01,releaseSeconds=.25,sampleRate=48000,depthDb=6,threshold=.05}={}){
    this.attack=Math.exp(-1/Math.max(1,attackSeconds*sampleRate));
    this.release=Math.exp(-1/Math.max(1,releaseSeconds*sampleRate));
    this.depthDb=number(depthDb,6);this.threshold=number(threshold,.05);
    this.envelope=0;
  }
  // One key sample in, the gain to apply to the ducked channel out.
  push(key){
    const level=Math.abs(number(key,0));
    const coefficient=level>this.envelope?this.attack:this.release;
    this.envelope=level+coefficient*(this.envelope-level);
    const over=Math.max(0,this.envelope-this.threshold)/Math.max(1e-6,1-this.threshold);
    return dbToGain(-this.depthDb*Math.min(1,over));
  }
}

// Everything a channel's gain is made of, in one place, so a bot can ask what a change
// would do before scheduling it.
export function channelGain({fader=1,pan=0,law=DESK.defaultLaw,width=1,invert=false,
  solo=1,group=1,duck=1}={}){
  const pans=panGains(pan,{law});
  const level=clamp(number(fader,1),0,4)*clamp(number(solo,1),0,1)
    *clamp(number(group,1),0,4)*clamp(number(duck,1),0,1)*polarityGain(invert);
  return {left:level*pans.left,right:level*pans.right,
    level,width:clamp(number(width,1),0,DESK.maxWidth),invert:Boolean(invert)};
}
