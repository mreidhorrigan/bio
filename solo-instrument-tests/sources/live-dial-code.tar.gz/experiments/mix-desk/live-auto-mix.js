// The automatic mix, attached to a room that is actually playing.
//
// `auto-mix.js` is the two published methods and knows nothing about Web Audio: it takes
// loudnesses and returns fader moves. This is the part that makes it audible — it taps every
// track of a live `EnsembleMixer`, measures each one, asks the balancer what the faders should
// be, and moves them.
//
// **Where the tap goes is a decision, not a detail.** It taps each track's `input`, which is
// *before* the fader this then moves. Measuring after the fader would make the loop chase its
// own tail — the measurement would improve because the gain went up, which is the shape of
// every runaway automatic mixer. `FaderBalance` is stable either way, because it approaches a
// target rather than integrating a step (see the note in `auto-mix.js`, which is there because
// an earlier version ran a 6 dB deficit to 44 dB), but pre-fader is still the honest place:
// the question is "how loud is this bot playing", not "how loud did I make it".
//
// **What it moves.** Only `dry`, each track's own fader, as an offset in decibels on top of
// whatever the mix was when it attached. It never touches pan, the sends or the shared
// effects: a balancer that redecorated the mix would be impossible to tell apart from a bug.
//
// **What it measures.** On the analyser path (metering.js) loudness is sampled rather than
// continuous: an `AnalyserNode` holds the most recent 2048 frames, so reading it every 50 ms
// catches most of the audio and not all of it — about 85% at 48 kHz. That is fine for
// balancing and would not be fine for metering. On the worklet path, the default wherever the
// context has one, the handle has heard every sample. Either way `channelLoudness` here is an
// estimate of the integrated loudness over the window and is named as one. Nothing in the
// project's own compliance testing goes through this path.
import {FaderBalance,channelLoudness} from './auto-mix.js';
import {wallClock} from '../../public/shared/listener-clock.js';
import {createMetering,meteringMode,workletClock} from './metering.js';

const MS_PER_SECOND=1000;

export const LIVE_AUTO_MIX=Object.freeze({
  sampleMs:50,        // how often the analyser is read
  windowMs:2000,      // how much playing each decision rests on
  // How long a fader takes to arrive. Most of the window rather than a fraction of it: at
  // 0.4 s of a 2 s window the gain lunged and then sat still for a second and a half, which
  // reads as a series of jerks whether you are watching the fader or listening to it. Gliding
  // for most of the window makes each move a mix decision rather than an event, and it is
  // still short enough to have settled before the next one is taken.
  rampSeconds:1.6,
  minDry:.02,         // never quite off: a balancer that mutes a bot has stopped balancing
  maxDry:1.5,         // the mixer's own ceiling for `dry`
});

export class LiveAutoMix {
  // `apply` is how a fader actually moves, and it is injectable because *where* the gain
  // belongs is the host's business, not the balancer's. The default writes straight to the
  // mixer track, which is right for a headless graph and wrong for an application with faders
  // on screen: moving the track behind its own controls changes what you hear while every
  // slider sits still, which is indistinguishable from nothing happening. An app passes an
  // applier that goes through its own mix state so the control moves with the sound.
  // `clock` is when it listens (`{every(ms, fn) → cancel, now() → seconds}`): the wall clock and
  // the context's time by default, render time in an offline render.
  // `metering` is how it listens (metering.js: 'analyser' or 'worklet', or a strategy); with the
  // worklet, and no clock given, it schedules on the audio's own clock.
  constructor(mixer,{options={},rules={},onUpdate=null,apply=null,clock=null,metering=null}={}){
    this.mixer=mixer;
    this.metering=metering&&typeof metering==='object'?metering:createMetering(this.context,{mode:meteringMode({option:metering,context:this.context})});
    this.clock=clock??(this.metering.mode==='worklet'?workletClock(this.context):wallClock(this));
    this.rules={...LIVE_AUTO_MIX,...rules};
    this.balance=new FaderBalance({options});
    this.onUpdate=onUpdate;
    this.apply=apply;
    this.taps=new Map();          // id → {handle, track, base}
    this.last=null;               // the most recent decision, for a display
    this.running=false;
    this.timers=[];
  }

  get context(){return this.mixer.context}

  // Every track that exists now, and any that appear later — bots join mid-performance and a
  // balancer that only saw the opening line-up would ignore them.
  tapTracks(){
    for(const [id,track] of this.mixer.tracks){
      if(this.taps.has(id))continue;
      // Pre-fader, for the reason at the top of this file.
      const handle=this.metering.tap(track.input,{channels:1,keepBlocks:Math.ceil(this.rules.windowMs/100),
        chunkWindowMs:this.rules.windowMs,peakWindowMs:this.rules.windowMs,sampleMs:this.rules.sampleMs});
      this.taps.set(id,{handle,track,get analyser(){return handle.analysers?.[0]},base:track.settings.dry});
    }
    // And forget tracks that have gone, so a bot that left does not hold the average down.
    for(const id of [...this.taps.keys()])if(!this.mixer.tracks.has(id)){
      this.taps.get(id).handle.close();
      this.taps.delete(id);
    }
  }

  sample(){
    this.tapTracks();
    for(const tap of this.taps.values())tap.handle.sample();
  }

  // One decision: measure everything, ask the balancer, move the faders.
  decide(){
    if(!this.taps.size)return null;
    const loudnesses={},measured={};
    for(const [id,tap] of this.taps){
      const joined=tap.handle.window(this.rules.windowMs);
      if(!joined)continue;
      const lufs=channelLoudness(joined,{sampleRate:this.context.sampleRate});
      if(lufs===null||!Number.isFinite(lufs))continue;
      loudnesses[id]=lufs;measured[id]=Math.round(lufs*10)/10;
    }
    const decision=this.balance.update(loudnesses,{seconds:this.rules.windowMs/MS_PER_SECOND});
    const applied={};
    for(const [id,db] of Object.entries(decision.moves)){
      const tap=this.taps.get(id);
      if(!tap)continue;
      const dry=Math.max(this.rules.minDry,
        Math.min(this.rules.maxDry,tap.base*10**(db/20)));
      if(this.apply)this.apply({id,dry,db,track:tap.track,seconds:this.rules.rampSeconds});
      else tap.track.set({dry},{seconds:this.rules.rampSeconds});
      applied[id]={db:Math.round(db*100)/100,dry:Math.round(dry*1000)/1000};
    }
    // Stamped with the audio clock, which is the one the decision was taken on.
    this.last={at:this.clock.now(),target:decision.target,measured,applied,
      detail:decision.detail??{},active:decision.active??[],
      reason:decision.reason??null};
    // The *whole* state, not just the decision. An earlier version passed `this.last`, which
    // carries no `running` flag, so a display that checks whether the mix is on read every
    // update as "off" and put itself back to sleep two seconds after being switched on.
    this.onUpdate?.(this.state());
    return this.last;
  }

  // Resolves once the metering can hear: at once with analysers, after the module loads with the worklet.
  ready(){return this.metering.ready()}

  start(){
    if(this.running)return this;
    this.running=true;
    this.timers.push(this.clock.every(this.rules.sampleMs,()=>this.sample()));
    this.timers.push(this.clock.every(this.rules.windowMs,()=>this.decide()));
    this.tapTracks();
    return this;
  }

  // Stopping puts every fader back where it was found. An automatic mix you cannot switch off
  // is one nobody will switch on.
  stop({restore=true}={}){
    this.running=false;
    for(const cancel of this.timers)cancel();
    this.timers=[];
    for(const [id,tap] of this.taps){
      tap.handle.close();
      if(restore){
        if(this.apply)this.apply({id,dry:tap.base,db:0,track:tap.track,
          seconds:this.rules.rampSeconds,restoring:true});
        else tap.track.set({dry:tap.base},{seconds:this.rules.rampSeconds});
      }
      this.taps.delete(id);
    }
    this.balance.reset();
    this.last=null;
    return this;
  }

  // What a display needs: who is playing, how loud, and what was done about it.
  state(){
    return {running:this.running,tracks:this.taps.size,...(this.last||{})};
  }
}
