// Where each player stands, left to right and front to back: the arithmetic of the Mixbot's placement (mh_DeskBOT's
// `placement` duty; live-desk.js measures the ensemble and applies it), with no audio in it, so each rule is tested on
// its own. The user, 26 September 2026: "Mixbot should be able to place the bots in left-right space, and in one or
// more front-back spaces using one or more reverbs."
//
// Left to right, as measured mixes are made (research/audio-mixing-literature.md §E.1):
//   - the low end in the middle. The parts that carry it, whose sound is mostly under the 400 Hz the panning spectrum
//     opens by, stand in the middle: the bass and the kick (Pestana & Reiss 2014), the bass the most centred track of
//     all, side/mid 0.009 (De Man et al. 2014). And the rest are held to that spectrum: mixes put no side energy below
//     50 Hz and their full share by 400 Hz, straight between in log frequency (De Man 2017 §4.1.2), so a band may be
//     panned as far as that line opens it and a part as far as the lowest band holding a real share of its sound
//     allows (a band holding less limits it in proportion): a hi-hat is free, a piano's low notes hold it in a little;
//   - the featured part centred: the lead vocal's imbalance, 0.045, was the smallest of any source (De Man et al.
//     2014). What is held in the middle is the featured parts' image, so two leads may stand either side of it;
//   - parts that share a spectrum set apart, each freed from the other's masking (Perez Gonzalez & Reiss 2010 placed
//     tracks by their spectral content);
//   - left and right in balance: number-one hits lie within 0.8 dB (Pestana & Reiss 2014);
//   - the mix about as wide as measured mixes are: side/mid power 0.10, 0.05-0.15 in 64 mixes (De Man et al. 2014);
//     wider mixes were liked less, and overly mono ones too (De Man et al. 2015). The width is measured on the master,
//     so a patch's own width and the reverbs' count toward it, and the pans fill what is left;
//   - a part already wide in itself (a stereo patch) placed by its own width rather than by a pan, which would
//     collapse its image toward one speaker;
//   - a kit's drums, each on a channel of its own (audio.js splitKit), placed as parts: the kick and the snare held as
//     near the middle as measured mixes hold them, the kick within 0.075 of left/right imbalance and the snare within
//     0.144 (De Man et al. 2014), the rest within the kit's overheads' image, 70% wide, where practitioners put a kit's
//     hats (0.5-0.7), ride (0.6), crashes (0.4-0.6) and toms (within 0.4: De Man 2017 Table 2.4, on a pot's travel from
//     7:00 to 17:00); and each drum starting where its kit put it (an audience's view of the
//     kit: shared/kit-channels.js), from which it moves only for what the move gains, so a kit keeps its image unless
//     the band needs it otherwise.
// A plan is the positions that cost least against all of these at once, each penalty in units of its own tolerance
// (ours), searched a part and a mirrored pair at a time from where the parts stand, so the ensemble moves no more
// than it must as players come and go.
//
// Front to back, with the reverbs:
//   - distance is heard mostly in the direct sound's level against the reverberant sound's, which falls 6 dB for
//     each doubling of distance in a room (Zahorik, Brungart & Bronkhorst 2005); a change of it is heard at 5-6 dB
//     (Zahorik 2002). The long reverb's send here spans 12 dB front to back: two such steps, front, middle, back.
//     It is shared out about the ensemble's middle depth, so the reverb is redistributed rather than added to or
//     taken from: a band standing all at one depth keeps the sends it had;
//   - a near source's reflections arrive well after its direct sound, a far one's close behind it (a room's
//     geometry: the farther the source, the less longer the reflected paths are than the direct one). So the short
//     room, with little pre-delay, is the space a part is sent back into, and the long reverb, pre-delayed, is the
//     tail a near part keeps without being moved back;
//   - who stands where follows the balance: the featured part in front, the others behind it as far as the
//     approach's quietest role, the low end dry and in front (no kick or bass in the reverb: Pestana & Reiss 2014).
//
// A stereo part is placed by its width as well as its pan ("narrow and offset"): a patch wider than the mix has room
// for is narrowed, where the mix is wider than measured mixes or where narrowing lets it stand apart from a part like
// it, at a cost, since its width is part of what it is (ours).
//
// And neither changes a part's loudness. Web Audio's StereoPannerNode keeps a mono signal's power, but it pans a stereo
// one by folding the far channel into the near one: a correlated signal (L = R) comes out up to 3 dB louder at the side
// (`panRatio`); and narrowing a wide patch cancels what was out of phase in it. `partImage` is both, exactly, from the
// channel's own measured powers, and the desk trims the fader by what they add or take away.
import {AUTO_MIX} from './auto-mix.js';

// ---- Definitions -----------------------------------------------------------------------------------------------
// The desk's octave bands (auto-mix.js): every spectrum here is a list of energies in them.
const BANDS=AUTO_MIX.bands;
// Two numbers this close are one; a channel's right side this far under its left is no right side at all (a mono
// signal, or one panned hard left inside the patch).
const EPSILON=1e-9,SILENT_SIDE=1e-6;
// Blocks quieter than this (mean square, full scale 1) are silence, not sound to learn a channel's stereo from.
const SILENT_POWER=1e-10;

// ---- Choices ---------------------------------------------------------------------------------------------------
export const PLACEMENT=Object.freeze({
  // The panning spectrum: no side energy below centreHz, all of a band free above openHz, straight in log frequency
  // between (De Man 2017 §4.1.2).
  centreHz:50,openHz:400,
  // The mix's width, as side/mid power: 0.10, within 0.05-0.15, in measured mixes (De Man et al. 2014); the pull
  // toward the middle of that band against the hinge at its edges (ours).
  sideMid:.1,leastSideMid:.05,mostSideMid:.15,widthPull:.25,
  // Left against right, as (R-L)/(R+L) of their power: 0.8 dB is 0.09 (Pestana & Reiss 2014).
  imbalance:.09,
  // The featured parts' image, within this of the middle: the lead vocal's measured imbalance, 0.045, is a pan of
  // about 0.03 (De Man et al. 2014); ours a little wider.
  featuredPan:.05,
  // A band holding this share of a part's sound limits how far the part may be panned; one holding less limits it in
  // proportion (ours). A part with this share of its sound under openHz carries the low end, and stands in the middle
  // (ours: most of it).
  heldShare:.1,lowEndShare:.5,
  // A part whose own side/mid reaches this is placed by its width alone, never panned (ours: side as strong as mid); the
  // widths the desk may narrow a stereo part to, as it came (1) down to a third of it (ours: a patch keeps some of the
  // width it was made with), for a part whose own side/mid is narrowFrom or more (ours: under a tenth of its mid, a
  // part is as good as mono, and narrowing it would change nothing heard); and what narrowing a part as wide as its mid
  // costs, at a width of 0 (ours: halving it costs as much as the lead standing 0.025 off the middle).
  wideSideMid:1,widths:Object.freeze([1,.8,.6,.45,.33]),narrowFrom:.1,narrowCost:1,
  // A patch is never narrowed past where it would lose this much of its power (ours: half; a patch mostly out of
  // phase with itself, narrowed further, would be mostly gone, what it was lying in its width).
  mostNarrowLossDb:3,
  // What moving a part costs, weighed against what the move gains (ours): one playing (a move of 0.25 costs as much as
  // parting two alike parts from 0 to 0.7 gains), one resting; a part never placed moves freely. And when the band has
  // just changed (a part joined or left, a role became known), a playing part costs little more to move than a resting
  // one: an engineer places the band again as a player enters, and a band placed part by part as its players arrive
  // would keep the first one's place for good.
  stayPlaying:6,stayResting:.2,stayChanged:.5,
  // The drums measured mixes keep near the middle, by their measured left/right imbalance, (R-L)/(R+L) of their RMS
  // (De Man et al. 2014): a drum held so is panned no further than the pan that makes it (heldPan). And what moving a
  // kit's drum from where its kit put it costs, before the desk has placed it (ours: as a resting part's move).
  heldDrums:Object.freeze({kick:.075,snare:.144}),stayHome:.2,
  // A kit's drums stand within its overheads' image: 70% wide (practitioners, compiled in De Man 2017 Table 2.4), close.
  // Stood back, a kit is narrower, as anything further away takes a smaller angle: its width in proportion to how near it
  // is, the back of the room kitDepthSpan times as far as the front (ours). The user, 26 September 2026, of a kit heard
  // from the audience, set back, and spread at the close width: "mixbot should have a concept of each multi-mic bot's
  // (e.g., drumkit's) width in space. This recording used quite a wide width, giving a sense of being surrounded by the
  // drum kit, which is a good sound for some purposes but something we should be aware of." An approach may ask for its
  // own width (kit.width), an immersive kit among them.
  kitWidth:.7,kitDepthSpan:3,
  // A desk's own kit width, its furthest drum from the middle, in place of the one its distance gives (null: by distance).
  kitSpan:null,
  // The side a kit is heard from, when nothing else decides it (an approach's kit.perspective does): 1 the drummer's
  // seat, -1 the audience's (kit-channels.js KIT_PERSPECTIVES). The user, 26 September 2026: "If all other things are
  // equal, the mixbot should favour placing individual drums from the drummer's perspective". And how far back a kit's
  // drums stand at the least, 0 to 1 (an approach's kit.distance; ours).
  perspective:1,kitDistance:0,
  // The search (ours): positions on this grid, sweeps at most.
  step:.05,sweeps:16,
  // A pan or a width move smaller than this is not made (ours); a fader trim is renewed when what the pan and the width
  // add has changed by this many dB (ours: a quarter of the 1 dB a listener can just hear).
  panDeadBand:.1,widthDeadBand:.1,trimStepDb:.25,
  // Front to back: the long reverb's send from front to back, in dB (two steps of Zahorik's 5-6 dB).
  depthDb:12,
  // The short room's send at the back (ours).
  roomBack:.3,
  // A part's sound below this is its low end, kept dry and in front: the desk's band edge nearest the reverb sends'
  // measured 200 Hz low cut (Pestana & Reiss 2014).
  lowHz:160,
  // A depth change smaller than this is not made (ours).
  depthDeadBand:.1,
  // The featured parts: those within this many LU of the most prominent present part's place in the balance (ours).
  featuredLu:1,
  // How long a pan move takes on a part playing and on one resting, and how often a plan is looked at again when
  // nothing has changed (ours).
  moveSeconds:8,restSeconds:1,planEveryMs:30000,
  // A part keeps its place this long after it was last heard, as a player resting for a few bars keeps theirs (ours);
  // its spectrum, for placing, is carried from one measurement to the next by this much (ours: about 20 s at the desk's
  // six-second round).
  holdSeconds:20,spectrumMemory:.7,
  // A channel's stereo (its width and correlation) weighed over imageSeconds, its power in the mix and the master's image
  // over energySeconds, long enough to hold a part's phrases and its rests; known after knownSeconds of sound (ours).
  imageSeconds:10,energySeconds:60,knownSeconds:1,
});

const clamp=(value,low,high)=>Math.max(low,Math.min(high,value));
const round=(value,places=2)=>Math.round(value*10**places)/10**places;

// ---- Spectra -----------------------------------------------------------------------------------------------------
// Each band's centre, geometric.
export const bandCentres=(bands=BANDS)=>bands.slice(0,-1).map((low,index)=>Math.sqrt(low*bands[index+1]));
// How far a band may be panned, 0 (the middle only) to 1 (anywhere): the measured panning spectrum.
export function openness(hz,choices=PLACEMENT){
  return clamp(Math.log(hz/choices.centreHz)/Math.log(choices.openHz/choices.centreHz),0,1);
}
// A spectrum's shares of its own energy, band by band (all zero when it has none).
export function shares(energies){
  const total=energies.reduce((sum,value)=>sum+Math.max(0,value),0);
  return energies.map(value=>total>0?Math.max(0,value)/total:0);
}
// How alike two spectra are, 0 (no band in common) to 1 (the same shape): the Bhattacharyya coefficient of their shares.
export function similarity(one,other){
  const a=shares(one),b=shares(other);
  return clamp(a.reduce((sum,share,index)=>sum+Math.sqrt(share*b[index]),0),0,1);
}
// How far a part may be panned for its low end, 0 to 1: each band caps it at the band's openness when it holds
// heldShare of the part's sound or more, and nearer 1 in proportion when it holds less; the lowest cap is the part's.
export function lowAllowance(energies,{bands=BANDS,choices=PLACEMENT}={}){
  if(lowShare(energies,{hz:choices.openHz,bands})>=choices.lowEndShare-EPSILON)return 0;
  const share=shares(energies),centres=bandCentres(bands);
  return share.reduce((least,value,index)=>Math.min(least,
    1-(1-openness(centres[index],choices))*Math.min(1,value/choices.heldShare)),1);
}
// The share of a spectrum below `hz` (whole bands whose top edge is at or under it).
export function lowShare(energies,{hz=PLACEMENT.lowHz,bands=BANDS}={}){
  const share=shares(energies);
  return share.reduce((sum,value,index)=>bands[index+1]<=hz+EPSILON?sum+value:sum,0);
}

// ---- A pan's effect on loudness ------------------------------------------------------------------------------------
// The power a StereoPannerNode puts out at `pan`, against its power at the centre. Mono in: always 1 (equal power).
// Stereo in: the far channel is folded into the near one, sin(pi|pan|/2) of it, so the power grows by that much of the
// channels' normalized cross-power, kappa = 2 E[LR] / (E[L^2] + E[R^2]): 1 + kappa sin(pi|pan|/2). Correlated (kappa 1)
// is +3 dB hard to one side; uncorrelated keeps its power; anti-correlated loses it.
export const panRatio=(pan,kappa=0)=>Math.max(EPSILON,1+kappa*Math.sin(Math.PI*Math.min(1,Math.abs(pan))/2));
// The fader trim that keeps the loudness where it was, in dB.
export const panTrimDb=(pan,kappa=0)=>-10*Math.log10(panRatio(pan,kappa));
// The pan that gives a mono part a left/right imbalance, (R-L)/(R+L) of its RMS, under the -3 dB law (gL = cos, gR = sin
// of pi (p + 1) / 4): the imbalance is tan(pi p / 4), so the pan is (4 / pi) atan of it.
export const imbalancePan=imbalance=>4/Math.PI*Math.atan(clamp(imbalance,-1,1));
// How wide a kit stands, as its furthest drum from the middle: the overheads' width close, narrower in proportion to how
// much further away it is at `depth` (0 front to 1 back), or `width` where an approach asks for its own.
export const kitSpan=(depth=0,{width=null,choices=PLACEMENT}={})=>Number.isFinite(width)?clamp(width,0,1)
  :(choices.kitWidth??1)/(1+clamp(depth,0,1)*((choices.kitDepthSpan??1)-1));
// How far a kit's drum may stand from the middle: as far as measured mixes hold it (heldDrums), and within the kit's
// span (kitSpan: the overheads' image close, narrower further back).
export const heldPan=(piece,choices=PLACEMENT,span=choices.kitWidth??1)=>Math.min(Number.isFinite(choices.heldDrums?.[piece])?imbalancePan(choices.heldDrums[piece]):1,span);

// ---- A channel's stereo, measured ------------------------------------------------------------------------------------
// Running sums of a stereo signal's powers and cross-power, forgetting over `seconds` (what the signal is: mono, or
// stereo and how wide) and over `longSeconds` (how much of it there is, rests and all, and which way it leans).
export class StereoStats {
  constructor({seconds=PLACEMENT.imageSeconds,longSeconds=PLACEMENT.energySeconds,knownSeconds=PLACEMENT.knownSeconds,sampleRate=48000}={}){
    this.seconds=seconds;this.longSeconds=longSeconds;this.sampleRate=sampleRate;this.knownFrames=knownSeconds*sampleRate;
    this.left=0;this.right=0;this.both=0;this.heard=0;this.channels=null;
    this.long={left:0,right:0,both:0,frames:0};
  }
  // One block. `channels`, when the meter knows it, is how many channels the signal arrived with. Each sample weighed by
  // its age at the block's end, as a per-sample exponential average weighs it, so a signal gives the same statistics in
  // one block or many (the mathematical audit's I18: a second's left-then-right signal read 0 dB in one block and
  // +2.17 dB in two, when each block's samples were added at full weight).
  add(left,right,{channels=null}={}){
    const frames=Math.min(left?.length??0,right?.length??0);
    if(!frames)return this;
    const step=Math.exp(-1/(this.seconds*this.sampleRate)),stepLong=Math.exp(-1/(this.longSeconds*this.sampleRate));
    let ll=0,rr=0,lr=0,wll=0,wrr=0,wlr=0,wLongLl=0,wLongRr=0,wLongLr=0,weight=1,weightLong=1,weights=0;
    for(let index=frames-1;index>=0;index--){
      const l=left[index],r=right[index],pl=l*l,pr=r*r,plr=l*r;
      ll+=pl;rr+=pr;lr+=plr;
      wll+=weight*pl;wrr+=weight*pr;wlr+=weight*plr;wLongLl+=weightLong*pl;wLongRr+=weightLong*pr;wLongLr+=weightLong*plr;weights+=weightLong;
      weight*=step;weightLong*=stepLong;
    }
    const keep=weight,keepLong=weightLong,long=this.long;
    this.left=this.left*keep+wll;this.right=this.right*keep+wrr;this.both=this.both*keep+wlr;
    long.left=long.left*keepLong+wLongLl;long.right=long.right*keepLong+wLongRr;long.both=long.both*keepLong+wLongLr;long.frames=long.frames*keepLong+weights;
    if((ll+rr)/frames>SILENT_POWER)this.heard+=frames;
    if(channels!==null)this.channels=channels;
    return this;
  }
  get known(){return this.heard>=this.knownFrames&&this.left+this.right>0}
  // One channel's worth: a mono signal, or a stereo one with nothing on its right (the StereoPannerNode then keeps its
  // power, as it keeps a mono signal's).
  get mono(){return this.channels===1||this.right<=SILENT_SIDE*this.left}
  get kappa(){return this.mono?0:clamp(2*this.both/Math.max(EPSILON,this.left+this.right),-1,1)}
  // Side over mid, in power: 0 for mono, 1 as much side as mid; `longSideMid` over the long window.
  get sideMid(){return this.mono?0:sideOverMid(this)}
  get longSideMid(){return this.mono?0:sideOverMid(this.long)}
  // Right against left over the long window, in dB, and as (R-L)/(R+L) of their power.
  get balanceDb(){return 10*Math.log10(Math.max(EPSILON,this.long.right)/Math.max(EPSILON,this.long.left))}
  get imbalance(){return (this.long.right-this.long.left)/Math.max(EPSILON,this.long.left+this.long.right)}
  // Its power in a mix at the centre, per sample, over the long window, rests and all: both sides of a stereo signal; a
  // mono one's own (its silent right side adds nothing).
  get power(){return (this.long.left+this.long.right)/Math.max(EPSILON,this.long.frames)}
  // Its left and right powers and their cross-power as shares of its whole, over the long window (the planner's part
  // `source`); null for a mono signal.
  // Its powers and cross-power per sample over the long window: {left, right, both}.
  get powers(){const {left,right,both,frames}=this.long,per=Math.max(EPSILON,frames);return {left:left/per,right:right/per,both:both/per}}
  get shares(){
    if(this.mono)return null;
    const {left,right,both}=this.long,whole=Math.max(EPSILON,left+right);
    return {pl:left/whole,pr:right/whole,c:both/whole};
  }
  // What this channel puts into the mix at the centre, against what a meter of its mono fold-down, (L+R)/2, reads, in
  // dB: 0 for a mono signal, +3 for a correlated stereo one, more for a wide one. The desk's level duty meters the fold-
  // down, and a wide patch reads quieter there than it sounds in the mix.
  get centreDb(){
    if(this.mono)return 0;
    const mid=(this.left+this.right+2*this.both)/4;
    return 10*Math.log10(Math.max(EPSILON,this.left+this.right)/Math.max(EPSILON,mid));
  }
}

const sideOverMid=({left,right,both})=>(left+right-2*both)/Math.max(EPSILON,left+right+2*both);

// ---- Left to right -----------------------------------------------------------------------------------------------
// A part as its panner hears it: its left and right powers and their cross-power as shares of its whole power (pl + pr =
// 1), from StereoStats.shares; null for a mono part, which the panner places by the equal-power law.
//
// Its image in the mix at `width` (the desk's mid/side width, mixer-parts.js widthMatrix: 1 as it is, 0 folded to mono)
// and `pan` (the StereoPannerNode: a stereo signal's far side folded into its near one), with its fader trimmed so its
// power is what it was: {pl, pr, c}, summing to 1 on pl + pr. And `power`, what the width and the pan alone would have
// made of it, which the trim takes back.
export function partImage(source,pan=0,width=1){
  const p=clamp(pan,-1,1);
  if(!source){const angle=(p+1)*Math.PI/4;return {pl:Math.cos(angle)**2,pr:Math.sin(angle)**2,c:Math.cos(angle)*Math.sin(angle),power:1}}
  const a=(1+width)/2,b=(1-width)/2,whole=Math.max(EPSILON,source.pl+source.pr);
  const pl=a*a*source.pl+b*b*source.pr+2*a*b*source.c,pr=b*b*source.pl+a*a*source.pr+2*a*b*source.c,c=a*b*(source.pl+source.pr)+(a*a+b*b)*source.c;
  const g=Math.sin(Math.abs(p)*Math.PI/2),h=Math.cos(Math.abs(p)*Math.PI/2);
  const out=p<=0?{pl:pl+g*g*pr+2*g*c,pr:h*h*pr,c:h*c+g*h*pr}:{pl:h*h*pl,pr:pr+g*g*pl+2*g*c,c:h*c+g*h*pl};
  const power=Math.max(EPSILON,out.pl+out.pr)/whole;
  return {pl:out.pl/(power*whole),pr:out.pr/(power*whole),c:out.c/(power*whole),power};
}
// The fader trim, in dB, that keeps a part's loudness where it was at `pan` and `width`.
export const placeTrimDb=(source,pan=0,width=1)=>-10*Math.log10(partImage(source,pan,width).power);
// A part's own side/mid at `width`, before any pan: 0 for mono.
export function ownSideMid(source,width=1){
  if(!source)return 0;
  const {pl,pr,c}=partImage(source,0,width);
  return (pl+pr-2*c)/Math.max(EPSILON,pl+pr+2*c);
}

// The mix's image from its parts, each at its pan and width and trimmed to its own power: its side/mid and its
// imbalance, (R-L)/(R+L). A part's `source` is null for mono; `energy` its power in the mix.
export function modelImage(parts,pans,widths=parts.map(()=>1)){
  let left=0,right=0,both=0;
  parts.forEach((part,index)=>{
    const e=Math.max(0,part.energy),image=partImage(part.source??null,pans[index],widths[index]);
    left+=e*image.pl;right+=e*image.pr;both+=e*image.c;
  });
  const total=left+right;
  return {sideMid:total>0?(total-2*both)/Math.max(EPSILON,total+2*both):0,imbalance:total>0?(right-left)/total:0};
}

// How far across the field a part's own image spreads, 0 (a point) to 1 (the whole width), from its side/mid (ours: the
// square root, so a part with as much side as mid fills the field).
const extentOf=sideMid=>Math.min(1,Math.sqrt(Math.max(0,sideMid)));

// The search's state: every sum the cost is made of, kept so one part's move is costed in time proportional to the
// number of parts rather than its square.
class PanCost {
  constructor(parts,{other,lean,returns,choices}){
    this.parts=parts;this.choices=choices;this.other=other;this.otherLean=lean;
    const n=parts.length;
    const total=parts.reduce((sum,part)=>sum+Math.max(0,part.energy),0)||1;
    this.energy=parts.map(part=>Math.max(0,part.energy)/total);
    // The returns (the reverbs, the echoes), as measured, in the parts' units: they are in the mix as they are.
    this.extra={left:Math.max(0,returns?.left??0)/total,right:Math.max(0,returns?.right??0)/total,both:(returns?.both??0)/total};
    this.similar=parts.map((part,i)=>parts.map((other,j)=>i===j?0:similarity(part.bands,other.bands)));
    this.featured=parts.map(part=>Boolean(part.featured));
    this.featuredEnergy=this.energy.reduce((sum,value,i)=>sum+(this.featured[i]?value:0),0);
    // What each part is wide in itself, as it came: narrowing a part barely wide gains and costs little.
    this.ownWidth=parts.map(part=>ownSideMid(part.source??null,1));
    this.pans=parts.map(part=>clamp(part.pan??0,-1,1));
    this.widths=parts.map(part=>part.source?clamp(part.narrow??1,0,1):1);
    this.n=n;
    this.recount();
  }
  extent(i,width){return extentOf(ownSideMid(this.parts[i].source??null,width))}
  recount(){
    this.left=this.extra.left;this.right=this.extra.right;this.both=this.extra.both;this.centroid=0;this.stay=0;this.narrowing=0;this.masking=0;
    this.extents=this.parts.map((part,i)=>this.extent(i,this.widths[i]));
    for(let i=0;i<this.n;i++)this.addPart(i,this.pans[i],this.widths[i],1);
    for(let i=0;i<this.n;i++)for(let j=i+1;j<this.n;j++)this.masking+=this.maskingPair(i,this.pans[i],this.extents[i],j);
  }
  // How much two parts mask each other where they stand: as alike as their spectra, less as their images part.
  maskingPair(i,pan,extent,j){
    const apart=Math.max(0,Math.abs(pan-this.pans[j])-(extent+this.extents[j])/2);
    return this.similar[i][j]*Math.cos(Math.PI*apart/4)**2;
  }
  // Part i's contributions at `pan` and `width`, added (sign 1) or taken away (-1).
  addPart(i,pan,width,sign){
    const e=this.energy[i],part=this.parts[i],image=partImage(part.source??null,pan,width);
    this.left+=sign*e*image.pl;this.right+=sign*e*image.pr;this.both+=sign*e*image.c;
    if(this.featured[i])this.centroid+=sign*e*pan;
    this.stay+=sign*(part.stay??0)*((pan-(part.pan??0))**2+(width-(part.narrow??1))**2);
    this.narrowing+=sign*this.choices.narrowCost*Math.min(1,this.ownWidth[i])*(1-width)**2;
  }
  maskingWith(i,pan,extent){
    let sum=0;
    for(let j=0;j<this.n;j++)if(j!==i)sum+=this.maskingPair(i,pan,extent,j);
    return sum;
  }
  // The cost as the sums stand, and its terms.
  terms(){
    const c=this.choices,half=(c.mostSideMid-c.leastSideMid)/2,total=this.left+this.right;
    const sideMid=(total>0?(total-2*this.both)/Math.max(EPSILON,total+2*this.both):0)+this.other;
    const imbalance=(total>0?(this.right-this.left)/total:0)+this.otherLean;
    const outside=Math.max(0,sideMid-c.mostSideMid,c.leastSideMid-sideMid);
    const centroid=this.featuredEnergy>0?this.centroid/this.featuredEnergy:0;
    return {masking:this.masking,balance:(imbalance/c.imbalance)**2,
      width:(outside/half)**2+c.widthPull*((sideMid-c.sideMid)/half)**2,
      featured:(centroid/c.featuredPan)**2,stay:this.stay,narrowing:this.narrowing,
      sideMid,imbalance,centroid};
  }
  total(terms=this.terms()){return terms.masking+terms.balance+terms.width+terms.featured+terms.stay+terms.narrowing}
  // Move part i to `pan` and `width` (keeping every sum).
  move(i,pan,width=this.widths[i]){
    const extent=this.extent(i,width);
    this.masking+=this.maskingWith(i,pan,extent)-this.maskingWith(i,this.pans[i],this.extents[i]);
    this.addPart(i,this.pans[i],this.widths[i],-1);this.addPart(i,pan,width,1);
    this.pans[i]=pan;this.widths[i]=width;this.extents[i]=extent;
  }
  // What the cost would be with these moves ([i, pan, width?]), the state left as it was.
  costWith(moves){
    const was=moves.map(([i])=>[i,this.pans[i],this.widths[i]]);
    for(const [i,pan,width] of moves)this.move(i,pan,width??this.widths[i]);
    const cost=this.total();
    for(const [i,pan,width] of was.reverse())this.move(i,pan,width);
    return cost;
  }
}

// The grid of positions a part may take: within its allowance, on the choices' step.
function positions(allow,step){
  const out=[],count=Math.floor(allow/step+EPSILON);
  for(let k=-count;k<=count;k++)out.push(round(k*step));
  return out;
}

// Descent from where the state stands: each free part to its best width and position (and off a position its width no
// longer allows), then each free pair moved apart or together about their middle, until nothing moves. Ties go to the smaller move, then to the wider part, then to the
// left, so a plan is the same every time.
function descend(state,free,allowFor,widthsFor,choices){
  const better=(cost,best)=>cost<best-EPSILON;
  for(let sweep=0;sweep<choices.sweeps;sweep++){
    let moved=false;
    for(const i of free){
      // A part standing where its width no longer allows it (its stereo became known, or it grew wider) has to move.
      const fromPan=state.pans[i],fromWidth=state.widths[i],allowed=Math.abs(fromPan)<=allowFor(i,fromWidth)+EPSILON;
      let best=allowed?state.total():Infinity,to=[fromPan,fromWidth];
      const distance=([pan,width])=>Math.abs(pan-fromPan)+Math.abs(width-fromWidth);
      for(const width of widthsFor(i))for(const pan of positions(allowFor(i,width),choices.step)){
        if(pan===fromPan&&width===fromWidth)continue;
        const cost=state.costWith([[i,pan,width]]),here=[pan,width];
        if(better(cost,best)||Math.abs(cost-best)<=EPSILON&&(distance(here)<distance(to)-EPSILON
          ||Math.abs(distance(here)-distance(to))<=EPSILON&&(width>to[1]+EPSILON||Math.abs(width-to[1])<=EPSILON&&pan<to[0]))){best=cost;to=here}
      }
      if(to[0]!==fromPan||to[1]!==fromWidth){state.move(i,to[0],to[1]);moved=true}
    }
    for(let a=0;a<free.length;a++)for(let b=a+1;b<free.length;b++){
      const i=free[a],j=free[b],pi=state.pans[i],pj=state.pans[j];
      let best=state.total(),shift=0;
      const most=Math.ceil(2/choices.step);
      for(let k=-most;k<=most;k++){
        if(!k)continue;
        const x=k*choices.step,to=[round(pi-x),round(pj+x)];
        if(Math.abs(to[0])>allowFor(i,state.widths[i])+EPSILON||Math.abs(to[1])>allowFor(j,state.widths[j])+EPSILON)continue;
        const cost=state.costWith([[i,to[0]],[j,to[1]]]);
        if(better(cost,best)){best=cost;shift=x}
      }
      if(shift){state.move(i,round(pi-shift));state.move(j,round(pj+shift));moved=true}
    }
    if(!moved)break;
  }
  return state;
}

// Where each part should stand, left to right, and how wide.
//   parts   [{id, energy (its power in the mix, any scale), bands (its octave-band energies), source (its stereo as its
//            panner hears it, StereoStats.shares; null or absent for mono), pan and narrow (where it stands, and the
//            width the desk gives it now, 1 as it came), featured, pinned (placed by someone else: kept), playing, placed
//            (false: never placed by this plan, so free to go anywhere), home (true: never placed, and standing where its
//            kit put it, which it leaves at stayHome), most (the furthest from the middle it may stand: heldPan), piece
//            (a kit's drum: its channel's name)}]
//   changed the band has just changed, so a playing part moves at stayChanged rather than stayPlaying
//   returns the rest of the mix, the shared effects' returns, as measured: {left, right, both}, its powers and cross-power
//           in the parts' units; in the mix as it is
//   other   side/mid the mix has from anywhere else, added as it is; lean likewise its imbalance, (R-L)/(R+L)
// Returns {pans: {id: pan}, widths: {id: width}, why: {id: reason}, sideMid, imbalance, cost}.
export function planPans(parts,{returns=null,other=0,lean=0,changed=false,choices=PLACEMENT}={}){
  if(!parts.length)return {pans:{},widths:{},why:{},sideMid:0,imbalance:0,cost:0};
  const low=parts.map(part=>lowAllowance(part.bands,{choices}));
  // How far a part may be panned at a width: as far as its low end allows, and no further than its own width leaves
  // room for (a pan collapses a stereo image toward one speaker).
  const allowFor=(i,width)=>parts[i].pinned?0:round(Math.min(low[i],parts[i].most??1,clamp(1-ownSideMid(parts[i].source??null,width)/choices.wideSideMid,0,1)));
  // The widths a part may be narrowed to: none for a part barely wide, and none past half its power.
  const leastPower=10**(-choices.mostNarrowLossDb/10);
  const widthsFor=i=>parts[i].source&&!parts[i].pinned&&ownSideMid(parts[i].source,1)>=choices.narrowFrom
    ?choices.widths.filter(width=>partImage(parts[i].source,0,width).power>=leastPower-EPSILON):[1];
  const staying=parts.map(part=>({...part,pan:clamp(part.pan??0,-1,1),narrow:part.source?clamp(part.narrow??1,0,1):1,
    stay:part.pinned?0:part.placed===false?(part.home?choices.stayHome:0):part.playing?(changed?choices.stayChanged:choices.stayPlaying):choices.stayResting}));
  // The parts free to move, heaviest first: they settle and the lighter ones find room around them.
  const free=parts.map((part,index)=>index).filter(index=>!parts[index].pinned)
    .sort((a,b)=>parts[b].energy-parts[a].energy||String(parts[a].id).localeCompare(String(parts[b].id)));
  // Two starts: where the parts stand, and a spread one (the free parts alternately left and right, half their
  // allowance, heaviest first), because a descent from everyone in the middle cannot always part two alike parts.
  // The cheaper wins, and where they cost the same, where the parts stood.
  const here=descend(new PanCost(staying,{other,lean,returns,choices}),free,allowFor,widthsFor,choices);
  const spread=new PanCost(staying,{other,lean,returns,choices});
  free.forEach((index,order)=>spread.move(index,round((order%2?1:-1)*allowFor(index,spread.widths[index])/2/choices.step)*choices.step));
  descend(spread,free,allowFor,widthsFor,choices);
  const chosen=spread.total()<here.total()-EPSILON?spread:here;
  const terms=chosen.terms(),pans={},widths={},why={};
  parts.forEach((part,index)=>{
    const pan=round(chosen.pans[index])+0,width=round(chosen.widths[index]);pans[part.id]=pan;widths[part.id]=width;
    why[part.id]=reason(part,index,pan,width,chosen,{low:low[index],allow:allowFor(index,width)},choices);
  });
  return {pans,widths,why,sideMid:round(terms.sideMid,3),imbalance:round(terms.imbalance,3),cost:round(chosen.total(terms),4)};
}

// What holds a centred part there, when no rule of its own does: the term that grows most if it is moved half way out.
const HOLDS=Object.freeze({masking:'it would move nearer a part it shares a spectrum with',balance:'it would tip the balance between left and right',
  width:'the mix would be wider than measured mixes are',stay:'it is playing, and the move would be heard for too little'});
// Why a part stands where it does and is as wide as it is, in words.
function reason(part,index,pan,width,state,{low,allow},choices){
  if(part.pinned)return 'kept where it was put';
  const side=pan<0?'left':'right',own=ownSideMid(part.source??null,1);
  const narrowed=width<1-EPSILON?`, narrowed to ${width} of its width (its own side/mid ${round(own)})`:'';
  if(Math.abs(pan)<choices.panDeadBand){
    if(low<choices.panDeadBand)return `in the middle: ${Math.round(lowShare(part.bands,{hz:choices.openHz})*100)}% of its sound is under ${choices.openHz} Hz, where mixes keep the middle${narrowed}`;
    if(allow<choices.panDeadBand)return `in the middle: wide in itself (side/mid ${round(ownSideMid(part.source??null,width))} as it stands), so placed by its own width${narrowed}`;
    if(part.featured)return `in the middle: the featured part${narrowed}`;
    if((part.most??1)<choices.panDeadBand)return `in the middle: a ${part.piece??'part'} measured mixes keep there${narrowed}`;
    const before=state.terms(),out=Math.min(allow,1/2),to=[-out,out].map(at=>[at,state.costWith([[index,round(at)]])]).sort((a,b)=>a[1]-b[1])[0][0];
    state.move(index,round(to));const after=state.terms();state.move(index,pan);
    const grew=Object.keys(HOLDS).map(term=>[term,after[term]-before[term]]).sort((a,b)=>b[1]-a[1])[0][0];
    return `in the middle: moved out, ${HOLDS[grew]}${narrowed}`;
  }
  let nearest=null,alike=0;
  state.parts.forEach((other,j)=>{if(j!==index&&state.similar[index][j]>alike){alike=state.similar[index][j];nearest=other}});
  return (nearest?`${side} (${pan}), away from ${nearest.id} (their spectra ${Math.round(alike*100)}% alike, at ${round(state.pans[state.parts.indexOf(nearest)])})`
    :`${side} (${pan}), for the balance and the width`)+narrowed;
}

// ---- Front to back -----------------------------------------------------------------------------------------------
// How far back each part stands, 0 (front) to 1 (back): by its place in the balance below the most prominent part
// present, over the approach's own span of prominence, and in front for as much of it as is low end.
//   parts   [{id, prominence (the part's loudness against the mix, LU: the approach's balance for its role), low (its
//            share under choices.lowHz)}]
//   span    the LU from the approach's most prominent role to its least
// Returns {depth: {id: 0..1}, featured: [ids], why: {id: reason}}.
export function planDepths(parts,{span,choices=PLACEMENT}={}){
  const out={depth:{},featured:[],why:{}};
  if(!parts.length)return out;
  const top=Math.max(...parts.map(part=>part.prominence)),reach=Math.max(EPSILON,span);
  for(const part of parts){
    const behind=top-part.prominence,depth=round(clamp(behind/reach,0,1)*(1-clamp(part.low??0,0,1)));
    out.depth[part.id]=depth;
    if(behind<=choices.featuredLu+EPSILON)out.featured.push(part.id);
    out.why[part.id]=behind<=choices.featuredLu+EPSILON?'in front: the featured part'
      :(part.low??0)>=1/2?`in front: ${Math.round(part.low*100)}% of its sound is low end, kept dry`
      :`${depth<1/3?'near the front':depth<2/3?'in the middle':'at the back'}: ${round(behind,1)} LU under the featured part in the balance`;
  }
  return out;
}
// The long reverb's send at a depth, against its send at the ensemble's middle depth: depthDb from front to back.
export const reverbFactor=(depth,middle=1/2,choices=PLACEMENT)=>10**((clamp(depth,0,1)-clamp(middle,0,1))*choices.depthDb/20);
// The short room's send at a depth: the approach's own for the part's role where it has one, else nothing at the front
// rising to roomBack at the back.
export const roomSend=(depth,base=0,choices=PLACEMENT)=>round(Math.max(base,choices.roomBack*clamp(depth,0,1)),3);
