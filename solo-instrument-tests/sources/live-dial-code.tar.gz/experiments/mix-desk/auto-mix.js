// Intelligent music production: balancing by loudness, and getting out of each other's way.
//
// Two published methods from the Queen Mary group, both cross-adaptive — each channel's
// treatment depends on what the *others* are doing, which is exactly the shape of a musebot
// ensemble and the reason these belong here rather than a per-channel effect.
//
// **Fader balance** — Mansbridge, Finn & Reiss, "Implementation and Evaluation of Autonomous
// Multi-track Fader Control" (AES 132, 2012). Their abstract states four design elements and
// this implements those four:
//
//   1. levels are decided by the **EBU R-128 loudness measure** — which this project already
//      has, gated and to the standard, in `desk.js`;
//   2. a **cross-adaptive process brings each track to a time-varying average** — so a quiet
//      track comes up and a loud one comes down, toward the ensemble's own moving mean rather
//      than toward a fixed target;
//   3. a **hysteresis loudness gate**, and
//   4. **selective smoothing**, which together "prevent the adjustment of intentional
//      dynamics in the music" — the failure this guards against is an automatic fader that
//      hears a deliberate diminuendo and helpfully undoes it.
//
// **Masking** — Hafezi & Reiss, "Autonomous Multitrack Equalization Based on Masking
// Reduction" (JAES 63(5), 2015). Their metric is stated as the level by which a given signal
// is masked *by the sum of all the others*, computed per band, with signals then processed to
// reduce it. That is what `maskingOf` computes and what `unmaskingMoves` acts on.
//
// **What is theirs and what is ours.** The measures and the cross-adaptive shape are theirs
// and are used as stated. Every *constant* here is ours, because the papers' own thresholds
// and time constants were not reachable — the AES PDFs are behind a certificate this machine
// will not verify and academia.edu returns 403. They are named as ours in `AUTO_MIX` rather
// than left looking like citations, and each is a number that can be argued with.
import {ChannelEq,EQ,LoudnessMeter,dbToGain,gainToDb,loudnessSummary} from './desk.js';
import {fusedCutDb,maskingPermitted} from '../../public/shared/mix-intention.js';

export const AUTO_MIX=Object.freeze({
  // --- fader balance -------------------------------------------------------
  // How far a single move may go. A fader that can leap 20 dB is a fader that will, on one
  // bad measurement, and the ensemble would hear it.
  maxMoveDb:6,
  // How fast a fader approaches its share of the average: a time constant, so a caller that
  // decides more or less often moves at the same rate (each update takes -expm1(-dt/tau) of
  // the distance: the mathematical audit's A07). Cross-adaptive, not instantaneous: the
  // paper's "time-varying average" is a thing to approach. This one takes .35 of it in the
  // two seconds between the live desks' decisions, as the per-update fraction did.
  approachSeconds:-2/Math.log1p(-.35),
  updateSeconds:2,           // a caller's interval between updates, where it does not say
  // The hysteresis gate, ours: a track within this much of the average is already balanced
  // and is left alone. Without a dead band the faders never settle, because every measurement
  // moves the average that every fader is chasing.
  deadBandDb:1.5,
  // And the inner edge of the hysteresis: once moving, a track keeps moving until its fader is
  // this close to where the balance wants it, rather than stopping the moment it crosses the
  // outer threshold. Close enough to call converged (28 September 2026): the gate once read a
  // track's own distance from the average, which a pre-fader measure holds still while the fader
  // moves, so a moving track went on to the balance exactly; read on the fader's own error, as
  // it now is, .75 left a lead 1.7 LU short of its margin over the bass.
  releaseDb:.25,
  // Set once and held (settleOnce, off by default): a channel's first measurement is taken whole, as a soundcheck sets
  // it, and after that it moves only when its fader stands more than heldDeadBandDb from where the balance wants it: a
  // large change in how it is played, not the drift of its neighbours joining and leaving. For a kit's drums, whose
  // balance within the kit an engineer sets once and rarely rides (étude 45: the within-kit balance rode the kick down
  // some 5 dB over the bars after the drums entered, as the hats and the snare joined). Ours.
  settleOnce:false,
  heldDeadBandDb:6,
  // Below this a channel is silence, not a quiet channel, and balancing silence upward would
  // bring up whatever noise is in it. R-128's own absolute gate is −70 LUFS; this is higher
  // because a musebot channel that quiet is not playing.
  silenceLufs:-55,
  // "Selective smoothing": a channel whose own loudness is *moving* is playing dynamics, and
  // its fader is smoothed harder so the automatic mix does not flatten them. Measured as the
  // spread of its recent loudness, in LU.
  dynamicSpreadLu:4,
  dynamicApproachSeconds:-2/Math.log1p(-.08),   // .08 of the distance in two seconds
  history:16,                // how many measurements the average and the spread are over

  // --- masking -------------------------------------------------------------
  // Band edges in hertz. Not critical bands: a mix engineer works in about this many regions
  // and the decisions below are made in the same terms, so a report reads like a mix note.
  bands:Object.freeze([20,80,160,320,640,1280,2560,5120,10240,20000]),
  // A channel masked by more than this in a band is worth acting on. Below it, the masking is
  // a normal consequence of instruments sharing a spectrum.
  maskedDb:6,
  // A band must hold at least this share of the maskee's *own* energy before masking there
  // counts. Without it a channel is "maximally masked" wherever it has no content at all —
  // a bass is buried in the treble by definition — and the deepest masking found is always
  // in a band the maskee was never in. Measured doing exactly that: the first unmasking move
  // for a lead buried by a pad came back centred at 14 kHz.
  presentShare:.05,
  // The largest cut a single unmasking move may ask for, and the smallest worth making.
  maxCutDb:6,
  minCutDb:1,
  // A masker is only asked to move if it holds at least this share of the band's energy;
  // otherwise the masking is everybody's fault and nobody's to fix.
  dominantShare:.4,
});

const clamp=(value,low,high)=>Math.min(high,Math.max(low,value));
const finite=(value,fallback=null)=>{
  const number=Number(value);
  return Number.isFinite(number)?number:fallback;
};
const mean=values=>values.length
  ?values.reduce((total,value)=>total+value,0)/values.length:null;
const spread=values=>{
  if(values.length<2)return 0;
  const centre=mean(values);
  return Math.sqrt(values.reduce((total,value)=>total+(value-centre)**2,0)/(values.length-1));
};

// ---- fader balance ---------------------------------------------------------

// The integrated loudness of one channel's frames, to the standard already in the desk.
export function channelLoudness(frames,{sampleRate=48000}={}){
  const channels=Array.isArray(frames[0])||ArrayBuffer.isView(frames[0])?frames:[frames];
  const meter=new LoudnessMeter({sampleRate,channels:channels.length});
  meter.keepAllBlocks=true;
  const step=1<<14;
  const length=Math.min(...channels.map(channel=>channel.length));
  if(!length)return null;
  for(let at=0;at+step<=length;at+=step)
    meter.push(channels.map(channel=>channel.subarray(at,at+step)));
  if(length<step)meter.push(channels.map(channel=>channel.subarray(0,length)));
  return loudnessSummary(meter.allBlocks,{sampleRate}).integrated;
}

// The balancer. Holds the recent loudness of every channel, because the average it works
// toward is time-varying and the smoothing is selective — both need a history, and a
// function that took only the present moment could implement neither.
export class FaderBalance {
  constructor({options={}}={}){
    this.options={...AUTO_MIX,...options};
    this.history=new Map();      // id → recent LUFS
    this.gains=new Map();        // id → the gain it was last given, in dB
    this.moving=new Set();       // ids currently inside a hysteresis excursion
    this.updates=0;
  }

  observe(id,lufs){
    const key=String(id);
    const value=finite(lufs,null);
    if(value===null)return null;
    const list=this.history.get(key)||[];
    list.push(value);
    while(list.length>this.options.history)list.shift();
    this.history.set(key,list);
    return list;
  }

  // What each channel's fader should be, in dB, given what everything is doing now.
  //
  // `loudnesses` is id → integrated LUFS for the stretch just measured. Channels below the
  // silence floor take no part: balancing silence upward brings up whatever noise is in it,
  // and a channel that is not playing has no business setting the average either. `seconds`
  // is how long since the last update (the smoothing is a time constant).
  //
  // **The measurement's domain is part of the contract.** The gain returned is absolute (the
  // whole deficit, approached), which is right for a loudness measured *before* the fader, as
  // both live desks measure it. A loudness measured after it already holds the gain, and an
  // absolute gain set from it counts the gain twice and settles short of the balance (the
  // audit's A07); a caller measuring there says `measured: 'post-fader'`, and each channel's
  // own gain is taken out of what it measured first.
  // `reach`: how far each channel's fader can raise it (dB, by id), where the caller knows. An aim beyond a channel's
  // reach it cannot be given, and the others would stand over it by what it lacks; so the target comes down until every
  // aim is within reach, the channel short of it at its reach and every other as far below as the balance puts it, as an
  // engineer brings the band down when the lead's fader is at the top (étude 45: a melody's solo wanted 8 dB more than
  // its fader's 3.5, and the drums sat level with it).
  update(loudnesses={},{seconds=this.options.updateSeconds,measured='pre-fader',reach=null}={}){
    const options=this.options;
    const active=[];
    for(const [id,lufs] of Object.entries(loudnesses)){
      const heard=measured==='post-fader'?finite(lufs,null)-this.gainOf(id):lufs;
      this.observe(id,heard);
      if(finite(heard,-Infinity)>options.silenceLufs)active.push(id);
    }
    this.updates++;
    this.lastActive=active;
    if(!active.length)return {moves:{},target:null,active:[],reason:'nothing playing'};

    // The time-varying average: the mean of each active channel's own recent mean, so one
    // loud measurement does not drag the target the whole ensemble is chasing.
    const perChannel=active.map(id=>mean(this.history.get(id)||[]));
    let target=mean(perChannel.filter(Number.isFinite));
    if(reach){
      const reachOf=id=>Number.isFinite(reach[id])?reach[id]:Infinity;
      const beyond=Math.max(0,...active.map((id,index)=>Number.isFinite(perChannel[index])?clamp(target-perChannel[index],-options.maxMoveDb*4,options.maxMoveDb*4)-reachOf(id):0));
      target-=beyond;
    }
    const moves={},detail={};
    for(const [index,id] of active.entries()){
      const own=perChannel[index];
      if(!Number.isFinite(own))continue;
      const distance=target-own;                   // positive: this channel is too quiet
      // The gain *wanted* is the whole deficit, and the fader approaches it. An earlier
      // version added a step to the previous gain each time, which integrates: fed the same
      // measurement repeatedly — which is what happens when the loudness passed in is the
      // channel's own, before the fader — it ran a 6 dB deficit up to 44 dB. Approaching a
      // target is stable whether the measurement is taken before or after the gain.
      const wanted=clamp(distance,-options.maxMoveDb*4,options.maxMoveDb*4);
      const previous=this.gains.get(id)??0;
      // The hysteresis gate, on how far the fader stands from where the balance wants it: inside
      // the dead band a channel is balanced and is left alone; once it has started moving it keeps
      // moving until it is well inside, rather than stopping the moment it crosses back. Without
      // this the faders never settle, because every move changes the average every other fader is
      // chasing. (On the channel's own distance from the average, as it was until 28 September
      // 2026, a fader turned down for a loud passage stayed down when the part came back to the
      // average: its distance was inside the gate, its fader not where the balance wanted it.)
      const absolute=Math.abs(wanted-previous);
      const wasMoving=this.moving.has(id);
      // Set once: the first measurement whole; held after, but for a large change.
      const first=options.settleOnce&&!this.settled?.has(id),held=options.settleOnce&&!first&&!wasMoving;
      const threshold=wasMoving?options.releaseDb:held?options.heldDeadBandDb:options.deadBandDb;
      if(absolute<=threshold){
        this.moving.delete(id);
        if(options.settleOnce)(this.settled??=new Set()).add(id);
        detail[id]={own,distance,moved:0,reason:held?'held: set once':'within the gate'};
        continue;
      }
      this.moving.add(id);
      // Selective smoothing: a channel whose own loudness is moving is playing dynamics, and
      // its fader approaches far more slowly so the automatic mix does not flatten a
      // deliberate crescendo into a straight line.
      const dynamics=spread(this.history.get(id)||[]);
      const dynamic=dynamics>=options.dynamicSpreadLu;
      const approach=-Math.expm1(-Math.max(0,finite(seconds,options.updateSeconds))/(dynamic?options.dynamicApproachSeconds:options.approachSeconds));
      const step=first?wanted-previous:clamp((wanted-previous)*approach,-options.maxMoveDb,options.maxMoveDb);
      // Set whole, it is where the balance wants it: set, not moving.
      if(options.settleOnce){(this.settled??=new Set()).add(id);if(first)this.moving.delete(id)}
      const gain=previous+step;
      this.gains.set(id,gain);
      moves[id]=Math.round(gain*100)/100;
      detail[id]={own,distance:Math.round(distance*100)/100,
        moved:Math.round(step*100)/100,dynamic,
        reason:dynamic?'smoothed: this channel is playing dynamics':'toward the average'};
    }
    return {moves,target:Math.round(target*100)/100,active,detail};
  }

  gainOf(id){return this.gains.get(String(id))??0}
  // Where the fader of a channel not yet heard stands when it begins (a soundcheck's, live-desk.js), which the balance
  // then approaches from as from any gain it gave: within the same reach as any it gives. A channel heard already is
  // the balance's, and is left.
  preset(id,db){
    const key=String(id),reach=this.options.maxMoveDb*4;
    if(!this.history.has(key)&&Number.isFinite(db))this.gains.set(key,clamp(db,-reach,reach));
    return this.gainOf(key);
  }
  heard(id){return this.history.has(String(id))}
  // A gain moved by `db` at once, where the balance's own aim has moved by as much (the band's attention changing a part's
  // balance at a section's downbeat: live-desk.js setAttention), so the balance finds it where it wants it rather than
  // riding it there. Within the same reach as any gain it gives.
  // A channel's measurements reweighed by `lu` (what it is balanced at has changed, not how it plays: the band's attention
  // moving its part), so its average is what it would have been, and the balance does not take its history's length to
  // hear the change.
  reframe(id,lu){
    const key=String(id),list=this.history.get(key);
    if(list&&Number.isFinite(lu))this.history.set(key,list.map(value=>value+lu));
  }
  shift(id,db){
    const key=String(id),reach=this.options.maxMoveDb*4;
    if((this.gains.has(key)||this.history.has(key))&&Number.isFinite(db))this.gains.set(key,clamp(this.gainOf(key)+db,-reach,reach));
    return this.gainOf(key);
  }
  reset(){this.history.clear();this.gains.clear();this.moving.clear()}
}

// ---- masking ---------------------------------------------------------------

// Per-band energy of one channel, in dB. The band layout is ours; the use is the paper's.
export function bandEnergies(frames,{sampleRate=48000,bands=AUTO_MIX.bands,
  window=4096}={}){
  if(!Number.isSafeInteger(window)||window<2||window>65536||(window&(window-1)))throw new RangeError('Band analysis window must be a bounded power of two');
  const signal=Array.isArray(frames[0])||ArrayBuffer.isView(frames[0])?frames[0]:frames;
  if(!signal||signal.length<window)return bands.slice(0,-1).map(()=>0);
  const totals=new Array(bands.length-1).fill(0);
  const binBands=new Int32Array(window/2).fill(-1);
  for(let bin=1;bin<binBands.length;bin++){const hertz=bin*sampleRate/window;for(let band=0;band<totals.length;band++)if(hertz>=bands[band]&&hertz<bands[band+1]){binBands[bin]=band;break;}}
  let frameCount=0;
  for(let start=0;start+window<=signal.length;start+=window){
    frameCount++;
    // A real FFT is in the listening code; here the band energies are wanted rather than a
    // spectrum, so a bank of one-pole-pair filters would do as well. The transform is reused
    // for exactness and because a corpus of eight channels is not a hot loop.
    const spectrum=magnitudesOf(signal.subarray(start,start+window));
    for(let bin=1;bin<spectrum.length;bin++){const band=binBands[bin];if(band>=0)totals[band]+=spectrum[bin]*spectrum[bin];}
  }
  return totals.map(value=>value/Math.max(1,frameCount));
}

// A real-input magnitude spectrum, by the same radix-2 transform the listening code uses.
const mixTransformPlans=new Map;
function mixTransformPlan(size){
  if(mixTransformPlans.has(size))return mixTransformPlans.get(size);
  const window=Float64Array.from({length:size},(_,index)=>.5-.5*Math.cos(2*Math.PI*index/(size-1))),stages=new Map;
  for(let length=2;length<=size;length<<=1){const angle=-2*Math.PI/length,cos=new Float64Array(length/2),sin=new Float64Array(length/2);
    for(let offset=0;offset<length/2;offset++){cos[offset]=Math.cos(angle*offset);sin[offset]=Math.sin(angle*offset);}stages.set(length,{cos,sin});}
  const plan={window,stages};if(mixTransformPlans.size>=8)mixTransformPlans.delete(mixTransformPlans.keys().next().value);mixTransformPlans.set(size,plan);return plan;
}
function magnitudesOf(frame){
  const size=frame.length,plan=mixTransformPlan(size);
  const real=new Float64Array(size),imaginary=new Float64Array(size);
  for(let index=0;index<size;index++){
    // Hann, so a partial between bins does not smear across the band edges.
    real[index]=frame[index]*plan.window[index];
  }
  for(let step=1,bits=0;step<size;step<<=1)bits++;
  for(let index=1,reversed=0;index<size;index++){
    let bit=size>>1;
    for(;reversed&bit;bit>>=1)reversed^=bit;
    reversed^=bit;
    if(index<reversed){
      [real[index],real[reversed]]=[real[reversed],real[index]];
      [imaginary[index],imaginary[reversed]]=[imaginary[reversed],imaginary[index]];
    }
  }
  for(let length=2;length<=size;length<<=1){
    const stage=plan.stages.get(length);
    for(let start=0;start<size;start+=length)
      for(let offset=0;offset<length/2;offset++){
        const cos=stage.cos[offset],sin=stage.sin[offset];
        const a=start+offset,b=a+length/2;
        const realPart=real[b]*cos-imaginary[b]*sin;
        const imaginaryPart=real[b]*sin+imaginary[b]*cos;
        real[b]=real[a]-realPart;imaginary[b]=imaginary[a]-imaginaryPart;
        real[a]+=realPart;imaginary[a]+=imaginaryPart;
      }
  }
  const half=size/2;
  const out=new Float64Array(half);
  for(let index=0;index<half;index++)
    out[index]=Math.hypot(real[index],imaginary[index])/half;
  return out;
}

// The metric, as Hafezi & Reiss state it: for each channel, in each band, the level by which
// it is masked **by the sum of all the other channels**.
//
// Positive decibels mean the others are louder there than this channel is — the amount by
// which it is buried. That is the quantity to minimise.
// `energies` lets a caller supply band energies it has already computed. The transform is the
// expensive part and a live desk can afford it only if it is spread — one channel per sample
// tick rather than every channel at once — so the metric has to be separable from the
// measurement. Given nothing, it measures, exactly as before.
export function maskingOf(channels,{sampleRate=48000,bands=AUTO_MIX.bands,energies=null,includeShares=true}={}){
  const ids=Object.keys(channels);
  const measured=energies||Object.fromEntries(ids.map(id=>
    [id,bandEnergies(channels[id],{sampleRate,bands})]));
  const bandCount=bands.length-1;
  // Prefix/suffix sums avoid total-minus-dominant cancellation. Full pairwise
  // shares below still have O(N^2 B) output cost; only sum preparation is O(NB).
  const prefixes=Array.from({length:ids.length+1},()=>new Float64Array(bandCount)),suffixes=Array.from({length:ids.length+1},()=>new Float64Array(bandCount));
  for(let i=0;i<ids.length;i++)for(let b=0;b<bandCount;b++)prefixes[i+1][b]=prefixes[i][b]+measured[ids[i]][b];
  for(let i=ids.length-1;i>=0;i--)for(let b=0;b<bandCount;b++)suffixes[i][b]=measured[ids[i]][b]+suffixes[i+1][b];
  const result={};let channelIndex=0;
  for(const id of ids){
    const own=measured[id],ownTotal=own.reduce((total,value)=>total+value,0),at=channelIndex++;
    const masked=[];
    for(let band=0;band<bandCount;band++){
      // The sum of all the others, which is the paper's own formulation and is not the same
      // as the loudest other: three quiet channels can bury one on their own.
      const others=prefixes[at][band]+suffixes[at+1][band];
      const mine=own[band];
      const presence=ownTotal>0?mine/ownTotal:0;
      masked.push({
        band,
        from:bands[band],to:bands[band+1],
        // How much of this channel's own sound is in this band. Masking of nothing is not
        // masking, and this is what says so.
        presence:Math.round(presence*1000)/1000,
        // Masking weighted by how much of the channel is actually there to be masked. This is
        // the figure to rank on: measured on a lead buried by a pad, the raw masking was flat
        // at 14–17 dB across every band including ones the lead barely occupied, and the
        // deepest reading was in the top band at 11% presence. Weighted, the answer is
        // 1280–2560 Hz, which is where the lead lives.
        weighted:0,
        ownDb:gainToDb(Math.sqrt(Math.max(1e-24,mine))),
        othersDb:gainToDb(Math.sqrt(Math.max(1e-24,others))),
        // How far this channel is below the sum of the rest, in this band.
        maskedDb:Math.round((gainToDb(Math.sqrt(Math.max(1e-24,others)))
          -gainToDb(Math.sqrt(Math.max(1e-24,mine))))*100)/100,
        // Who is doing it, and by how much of the band.
        share:includeShares?Object.fromEntries(ids.filter(other=>other!==id).map(other=>
          [other,others>0?Math.round(measured[other][band]/others*1000)/1000:0])):{},
      });
      const entry=masked.at(-1);
      entry.weighted=Math.round(entry.presence*Math.max(0,entry.maskedDb)*100)/100;
    }
    result[id]={bands:masked,
      // The worst masking *of something that is there*, which is the only kind worth calling
      // masking.
      worst:masked.filter(entry=>entry.presence>=AUTO_MIX.presentShare)
        .reduce((worst,entry)=>
          entry.weighted>(worst?.weighted??-Infinity)?entry:worst,null)};
  }
  return {masking:result,energies,bands};
}

// What to do about it: the moves that would reduce the masking, as desk requests.
//
// The decision rule is ours, and it is the conservative one. A channel buried past the
// threshold has *one* masker asked to step back in *that band alone*, and only where that
// masker holds a dominant share of the band — because if the burial is the sum of four
// channels equally, it is everybody's fault and cutting one of them is arbitrary. Nothing is
// boosted: a mix that solves masking by adding gain gets louder until it clips.
//
// What the music allows is not undone (the extreme-aesthetics report's §6.2, M3: shared/mix-intention.js): a masker
// the permissions let cover its channel there is left alone, and an intentional fusion makes every cut shallower, none
// at all when the scene asks its sources to fuse entirely. Without either, the moves are as they were.
export function unmaskingMoves(channels,{sampleRate=48000,protect=[],
  options={},energies=null,permissions=[],fusion=null}={}){
  const settings={...AUTO_MIX,...options};
  const {masking}=maskingOf(channels,{sampleRate,bands:settings.bands,energies});
  const moves=[];
  const protectSet=new Set(protect.map(String));
  for(const [id,report] of Object.entries(masking)){
    // Only the channels somebody has said matter, when anybody has said so. A mix has a
    // subject, and unmasking everything against everything says nothing.
    if(protectSet.size&&!protectSet.has(id))continue;
    for(const band of report.bands){
      if(band.presence<settings.presentShare)continue;   // it is not there to be buried
      if(band.maskedDb<settings.maskedDb)continue;
      const [masker,share]=Object.entries(band.share)
        .sort((left,right)=>right[1]-left[1])[0]||[];
      if(!masker||share<settings.dominantShare)continue;
      if(protectSet.has(masker))continue;         // it is not asked to bury itself for itself
      // Centre the cut in the band, geometrically, which is where a band's middle actually is
      // to a listener.
      const centre=Math.round(Math.sqrt(band.from*band.to)),where=centre<250?'low':centre>4000?'high':'mid';
      if(maskingPermitted(permissions,masker,id,where))continue;   // it may cover it there
      const deepest=clamp(Math.round((band.maskedDb-settings.maskedDb)*10)/10,
        settings.minCutDb,settings.maxCutDb),cutDb=Math.round(fusedCutDb(deepest,fusion)*10)/10;
      if(cutDb<settings.minCutDb)continue;
      moves.push({
        parameter:'eq',id:masker,
        band:where,
        hz:centre,gainDb:-cutDb,q:1.1,
        because:`${id} is ${band.maskedDb.toFixed(1)} dB under the rest around `
          +`${centre} Hz, and ${masker} holds ${Math.round(share*100)}% of that band`
          +(cutDb<deepest?` (a shallower cut: the scene lets its sources fuse ${Math.round(fusion*100)}%)`:''),
        masked:id,maskedDb:band.maskedDb,weighted:band.weighted,presence:band.presence,share,
      });
    }
  }
  // One move per masker per band, deepest first, so a single pass does not ask one channel to
  // step back four times in the same place.
  const seen=new Set();
  return moves
    // Deepest *weighted* masking first, so the move that matters most is the one made.
    .sort((left,right)=>right.weighted-left.weighted)
    .filter(move=>{
      const key=`${move.id}:${move.band}`;
      if(seen.has(key))return false;
      seen.add(key);
      return true;
    });
}

// Both together, as a mix note a person could read and a bot could act on.
export function autoMixReport(channels,{sampleRate=48000,protect=[],balance=null}={}){
  const loudnesses=Object.fromEntries(Object.entries(channels)
    .map(([id,frames])=>[id,channelLoudness(frames,{sampleRate})]));
  const balancer=balance||new FaderBalance();
  const faders=balancer.update(loudnesses);
  const unmask=unmaskingMoves(channels,{sampleRate,protect});
  return {
    loudness:loudnesses,
    faders,
    unmask,
    summary:`${faders.active.length} channels playing, average `
      +`${faders.target===null?'—':`${faders.target} LUFS`}; `
      +`${Object.keys(faders.moves).length} fader moves, ${unmask.length} unmasking cuts`,
  };
}
