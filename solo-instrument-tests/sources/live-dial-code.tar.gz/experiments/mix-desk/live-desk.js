// mh_DeskBOT's ear, in a room that is playing: balance, unmasking, and space, as one thing.
//
// `desk-bot.js` is the desk as a musebot — gain sharing, ducking, groups, law — operating on
// abstract channel state and explaining itself in plans. `auto-mix.js` is the two published
// cross-adaptive methods. Neither has ever heard anything: one moves numbers, the other takes
// loudnesses it is handed. This is the ear. It measures what the ensemble is actually playing
// and acts on what it hears, under the boundaries `desk-bot.js` already set for itself.
//
// **The currencies, and why they belong together.** The first three are all answers to the
// same question — what does this bot need to give up so the others can be heard:
//
//   * **level**, by the cross-adaptive fader balance after Mansbridge, Finn & Reiss (AES 132,
//     2012): every channel toward the ensemble's own moving average, gated and smoothed so a
//     deliberate diminuendo is not undone.
//   * **frequency**, by the masking metric of Hafezi & Reiss (JAES 63(5), 2015): a channel
//     masked by the *sum* of the others gets room made for it, and the cut goes to whichever
//     channel holds the dominant share of that band. Three bands per channel, because that is
//     what `desk.js`'s `ChannelEq` specifies and what the moves are expressed in.
//   * **space**, which is ours and has no paper: reverb send falls as the room fills. It is
//     the acoustic twin of Dugan gain sharing, which `desk-bot.js` already runs on level — the
//     more players are sounding, the less reverb each one gets, so the *sum* of the
//     reflections stays where it was rather than growing with the band. Five players each at
//     the reverb send of a soloist is a wash, and it is the commonest way an automatic mix
//     turns an ensemble to mud.
//
// And one about where each player stands:
//
//   * **placement**, left to right and front to back (`placement.js`, where the rules and their
//     sources are): the low end and the featured part in the middle, parts that share a spectrum
//     set apart, left and right in balance, the mix as wide as measured mixes are -- each part
//     measured where its panner hears it and the returns as they are, so a patch's own width and
//     the reverbs count, and a patch too wide narrowed before it is panned -- and each part as far
//     back as its place in the balance puts it, through the
//     two reverbs: the short room it is sent back into, the long reverb's send 12 dB from front to
//     back. Planned when the band changes, and moved slowly while a part plays, quickly while it
//     rests. Neither a pan nor a width here changes a part's loudness: the fader is trimmed by
//     what they add or take away.
//
// And one about how the band is grouped:
//
//   * **submix** (`submix.js`): each part's channel routed into its group's bus by the role its bot plays -- the drums,
//     the bass, the keys and pads, the lead, the textures -- and each group balanced as one part, because the
//     loudnesses an approach sets parts at were measured on groups: three drum bots each given the drums' loudness were
//     4.8 dB over it together. A bus is never balanced, placed, sent or unmasked itself -- it holds its channels, and
//     each of those already is -- and it carries what is done to a group as one: an approach's bus strip, a cut.
//
// The last two are about the mix rather than about any one channel, and both act through the
// fader balance rather than beside it:
//
//   * **dynamics**, a loudness range to ITU-R BS.1770 and EBU Tech 3342. Balancing every
//     channel toward the ensemble average *is* compression, across channels instead of across
//     time, so when the mix goes flat the desk balances less hard rather than more. See
//     `DYNAMICS` for the published targets and which one this holds.
//   * **spectral balance**, against pink noise — equal energy in every octave. A channel
//     crowding an octave that is already full is reported to the balance as louder than it
//     measured, so the existing cross-adaptive rule cuts it with its own dead band and its own
//     smoothing intact. See `PINK`, including why real music is not pink and this does not try
//     to make it so.
//
// **The boundaries are `desk-bot.js`'s and are kept.** It never mutes or solos. It never sets
// a value — every change is a ramp with a stated duration. It explains every move it makes, in
// words, because a mix decision nobody can read is one nobody can overrule. And it moves only
// what it has been given: `dry`, an EQ band, a reverb send, and, placing, a pan, the short
// room's send and a width stage of its own, and, grouping, a channel's route into a bus it made.
// A pan or a route somebody else set is theirs, and it plans around it.
//
// **What it will not do**: boost. Every unmasking move is a cut. A mix that solves masking by
// adding gain gets louder until it clips, which is the failure mode `auto-mix.js` names and
// this inherits.
import {AUTO_MIX,FaderBalance,bandEnergies,unmaskingMoves} from './auto-mix.js';
import {EQ,LoudnessMeter,loudnessSummary,truePeak} from './desk.js';
import {mixAesthetic} from '../../public/shared/aesthetic.js';
import {wallClock} from '../../public/shared/listener-clock.js';
import {createMetering,meteringMode,workletClock} from './metering.js';
import {planApproach,roleBalanceLu,voiceFeatureLu} from '../../public/shared/mix-approaches.js';
import {ApproachApplier} from '../../public/mix-approach.js';
import {PLACEMENT,StereoStats,heldPan,kitSpan,lowShare,placeTrimDb,planDepths,planPans,reverbFactor,roomSend} from './placement.js';
import {widthMatrix} from '../../public/mixer-parts.js';
import {SUBMIX,Submixes,groupLoudness,powerSumDb,submixBus,submixGroup} from './submix.js';
import {botLoudness} from '../../public/shared/bot-loudness.js';
import {kitLoudnessOf} from '../../public/shared/kit-loudness.js';
import {KIT_HOMES,perspectiveSign} from '../../public/shared/kit-channels.js';
import {PUNCH,backedOff,nextBackoff,nextMakeup,punchAim,punchPlan,punchRole,scaledPunch,steerThreshold} from './punch.js';
import {MIX_INTENTION,contrastRangeLu,depthWetLu,intentionReach,maskingPermission,mixIntention,punchScale,saysAnything,widthAim} from '../../public/shared/mix-intention.js';

const MS_PER_SECOND=1000;
// How far the band's attention may move a part's balance either way, LU (ours: a little more than the 4.8 LU a lead sits
// over the drums in the measured mixes, De Man et al. 2014).
const ATTENTION_REACH_LU=6;

export const LIVE_DESK=Object.freeze({
  sampleMs:50,          // how often each channel is sampled
  windowMs:2000,        // how much playing a level decision rests on
  maskWindowMs:4000,    // masking needs longer: a spectrum over two seconds is a guess
  maskEveryMs:6000,     // and it is expensive, so it is asked less often than the faders
  // **Everything that transforms audio runs on this clock, not on the fader clock.**
  // Measured, after the spectral balance was added and before this existed: `bandEnergies`
  // over a four-second window is 46 transforms of 4096 points, about 3.1 M operations per
  // signal, and it was being run on every channel *and* the master at every two-second
  // decision — 25 M operations on the main thread, every two seconds, in the thread that also
  // has to hand the audio graph its next block. It dropped out, and the report was "occasional
  // audio interruptions ... possibly with deskbot". It was.
  spectrumEveryMs:6000,
  // And however long the window is, this many transforms are taken from it, from the newest
  // audio. **One.** A 4096-point transform at 48 kHz is 85 ms of audio resolved to 11.7 Hz
  // bins, and what is wanted from it is nine octave-band sums read against a ±3 dB tolerance.
  // Averaging forty-six of them changed the answer by less than the tolerance and cost
  // forty-six times as much. Eight signals, one transform each, every six seconds is about
  // 0.5 M operations — a twentieth of a per cent of what it was doing.
  spectrumWindows:1,
  // Masking gets more than the profile does, because it drives an EQ cut on a named channel
  // rather than a ±3 dB nudge, and a channel caught between notes in a single window would be
  // reported as absent from a band it lives in. Four spread windows, not four adjacent ones.
  maskWindows:4,
  rampSeconds:1.6,      // most of the level window, so a move glides rather than lunges
  // Parts set before they are heard, from their bots' measured loudness (soundcheck), the band's attention landed on its
  // downbeat rather than ridden in (setAttention), and the balance's aims kept within its faders' reach (boundedAims).
  // Off until heard: on étude 45 (the user: "legitimately good music") the first two entered the drums 3 LU lower, but
  // left them 4 LU over their role in its climax, peaking 3 dB higher, where the lead's aim was beyond its fader's reach.
  soundcheck:false,
  soundcheckSeconds:.05, // a soundcheck's move, made before the part is heard (soundcheck)
  attentionAtOnce:false,
  boundedAims:false,     // the balance's aims kept within its faders' reach, the others brought down (auto-mix.js update)
  kitSetOnce:false,      // a kit's drums set once within their kit, from their first hits, and held (groupBalance)
  attentionSeconds:.25,  // the band's attention moving the parts at a section's downbeat, together (setAttention)
  eqRampSeconds:2.4,    // slower still: a filter that moves fast is heard as a filter
  spaceRampSeconds:3,   // slowest: space is the thing you least want to hear being adjusted
  minDry:.02,
  maxDry:1.5,
  // Space. `soloSend` is what one player alone would get; the share falls as the square root
  // of the count, which is the same shape Dugan's 3 dB per doubling has and keeps the summed
  // reflected energy roughly constant rather than the summed amplitude.
  soloSend:.5,
  minSend:.05,
  maxSend:1,
  // **Space needs the same hysteresis level has, and for a worse reason.** The share depends on
  // how many are playing, and these bots have activity-dependent play and break durations, so
  // the instantaneous count changes at almost every decision: one player wants 0.50, two want
  // 0.354, three 0.289, four 0.25. Following that count directly makes the send audibly pump —
  // reported as "reverb send amount is cycling", and it was. So:
  //   * a channel stays counted as present for `holdMs` after it stops, because a bot resting
  //     for a bar has not left the room;
  //   * the count itself is averaged over `countWindow` decisions, so one bot entering does not
  //     move everybody at once;
  //   * and the send only moves when it would move by more than `sendDeadBand`, which is the
  //     same gate Mansbridge, Finn & Reiss put on the faders and for the same reason.
  holdMs:6000,
  countWindow:5,
  sendDeadBand:.04,
  // A channel quieter than this is not playing, and neither balancing nor unmasking it means
  // anything. Matches `auto-mix.js`'s own floor.
  silenceLufs:-48,
  // A channel this far under the loudest of its group is resting there, as one under the silence floor is: a sparse part,
  // a tom between fills, strokes a drummer is fading in. The balance within the group neither raises it nor counts it in
  // the group's average (ours: a part 20 LU under its group's loudest adds a hundredth of the group's power). Found on a
  // drummer alone (FILL_FIGURES.md, "One continuum"): its toms, fading in at -54 LUFS, raised to the end of their fader,
  // so the fills that followed came in hot.
  restingLu:20,
  // A channel dying away: its loudness and its window's peak both fallen by this much or more since the last decision,
  // with no new attack in the window (a gong's ring, a cymbal's, a chord let go). The balance hears it at what it last
  // sounded at, until it falls under the silence floor, so a part is balanced by its loudness when it sounds: a ring is
  // never ridden up, nor the band brought down to it. Found on a gong (29 September 2026), struck every 17 s and
  // ringing for 30: its falling figure lowered the band's average, and the desk rode the gong's ring up 5 dB and the
  // piano down 8 dB over a minute. Left out of the balance instead, the gong took the band's average with it at each
  // stroke and the keys pumped 2 dB. (Ours: the least fall read as one.)
  dyingLu:1,
  // The reverb's loudness against the mix, which an approach names (mix-approaches.js wetLu):
  // held within the dead band by moving the reverb returns half the error at a time, at most
  // this much per decision, so the room settles rather than breathes.
  wetDeadBandLu:1.5,
  wetStepDb:1.5,
});

// `bandEnergies`' own transform length. Named here because the desk bounds how many of them
// it asks for, and a number that has to agree with another file's default should say so.
const SPECTRUM_WINDOW=4096;

// `LoudnessMeter.push` takes an array of channels. Wrapping one frame in a fresh array twenty
// times a second per channel is a small allocation, but it is one that need not happen at all.
const SINGLE_HOLDER=[null];
const SINGLE=frame=>{SINGLE_HOLDER[0]=frame;return SINGLE_HOLDER};

const clamp=(value,low,high)=>Math.min(high,Math.max(low,value));
const round=value=>Number.isFinite(value)?Math.round(value*10)/10:null;
// Full scale is 0 dB; silence is reported as -Infinity rather than as a number, so a caller
// can tell "nothing played" from "played quietly".
const AMPLITUDE_DB=20;       // decibels of amplitude: 20 log10
const gainDb=gain=>gain>0?AMPLITUDE_DB*Math.log10(gain):-Infinity;
// Below this a frame is a rest, not a signal to take an oversampled peak from.
const SILENT_SNAPSHOT_DB=-60;
const fmt=(value,unit)=>Number.isFinite(value)?`${(Math.round(value*10)/10).toFixed(1)} ${unit}`:`no ${unit}`;
// Where each role stands in the balance when no approach says (mix-approaches.js: the loudnesses measured in studio mixes,
// De Man et al. 2014), which placement reads a part's depth from.
const STUDIO_ROLES=planApproach('studio').roles;
// Two pans this close are one; a pan somebody else set differs from the desk's own by more.
const SAME_PAN=1e-3;
// A spectral round this far under a channel's own carried spectrum caught it resting, not playing.
const SOUNDING_SHARE=.01;

// What a desk is responsible for. One desk with the default remit runs the whole mix, which is
// where this starts; the point of naming a remit at all is that the second desk does not have
// to be a rewrite.
//
// **Listening and acting are separate, and that is the whole design.** A desk listens to every
// channel always — masking is *defined* as being buried by the sum of the others, and the
// ensemble's moving average is the average of everyone playing, so a desk that only heard its
// own channels would compute a different target from its neighbour and the two would pull
// against each other forever. It acts only on the channels and the currencies it owns.
export const DUTIES=Object.freeze(['level','frequency','space','dynamics','placement','submix','punch']);

// **Dynamic range: the published targets, and which one this holds.**
//
// The measurements are all standard and none of them needed research; what needed deciding was
// which figures a live machine ensemble should be held to, and that is an argument, so it is
// written down here rather than buried in a constant.
//
// *Long term.* Integrated loudness is gated twice per ITU-R BS.1770 — absolutely at −70 LUFS,
// then 10 LU below the ungated mean — and `desk.js` already implements it. The delivery
// targets: EBU R 128 asks −23 LUFS and ATSC A/85 −24 LKFS, both broadcast; streaming
// normalises to about −14 LUFS (Spotify, YouTube, Tidal, Amazon) or −16 (Apple Music), and
// AES TD1004.1.15-10 (2015) recommends −16 LUFS ±2 for streaming and network playback. A room
// full of musebots is closer to streaming than to broadcast, so −16 is the figure. True peak
// −1 dBTP, which is both R 128's and TD1004's ceiling.
//
// *The range itself.* EBU Tech 3342 defines loudness range as the 10th-to-95th percentile
// spread of the short-term (3 s) loudness distribution, gated 20 LU below its own mean. Tech
// 3343's practical guidance is the useful part: a programme below about 3 LU has been
// compressed flat, and one above about 20 LU cannot be followed in a room with any noise in
// it. Produced pop sits at 5 to 9 LU; acoustic, jazz and folk at 9 to 15; orchestral higher
// still. Nobody is riding a fader here and the material is not pop, so this aims at the
// acoustic end: 9 LU, and it only acts outside 6 to 14.
//
// *Short term.* LRA is a long-window statistic and cannot see a single flattened bar, so it is
// not enough on its own. The short-term figure is PSR — peak to short-term loudness ratio,
// true peak minus the 3 s loudness — which is how far a transient stands above the texture it
// is in. Dense modern masters read 5 to 8 dB, well-made music 8 to 14, acoustic material 14
// and up. PLR, the same thing against the integrated figure, is reported beside it because the
// two disagreeing is itself informative: a good PLR with a poor PSR is a mix that has loud
// moments and flat bars.
//
// **What it can actually do about it.** The desk owns faders and EQ, not a compressor, so the
// lever is its own cross-adaptive balance. Pulling every channel toward the ensemble average
// is, by construction, a range-reducing operation — it is the mix equivalent of compression
// across channels rather than across time, and the reported symptom was exactly that: one
// channel pushed +4.95 dB into the fader ceiling. So when the range is short the desk balances
// *less*: a wider dead band, so more channels are left where they are, and a smaller maximum
// move, so the ones it does touch travel less far. When the range is long it goes back toward
// the published defaults and no further. It never compresses to *reduce* range — a live
// ensemble that is too dynamic is a musical situation, not a fault.
export const DYNAMICS=Object.freeze({
  targetLufs:-16,          // AES TD1004.1.15-10, streaming
  ceilingDbtp:-1,          // EBU R 128 / AES TD1004
  // What a master's limiter may take off the loudest peak to reach the target under the ceiling (render/master.mjs,
  // the streaming profile's limiterMaxDb): with the two above, the most a mix's peaks may stand over its loudness and
  // still be delivered (deliverableCrestDb), which the desk's own punch never pushes it past (punch.js).
  limiterBudgetDb:6,
  rangeLu:9,               // EBU Tech 3342 loudness range, aimed at the acoustic end
  minRangeLu:6,
  maxRangeLu:14,
  psrDb:12,                // peak to short-term loudness, the 3 s crest
  minPsrDb:8,
  // **PLR: peak to *integrated* loudness, the crest over the whole window.** The long-term
  // companion to PSR, and the two disagreeing is the informative case — a healthy PLR with a
  // poor PSR is a mix with loud moments and flat bars, which is exactly what a range statistic
  // hides. Because the integrated figure is gated, a piece with genuine quiet passages reads a
  // higher PLR than PSR, so this is the more forgiving of the two: if PLR is under its floor
  // the mix is dense against its own peaks by any reading, which is why it is worth acting on
  // rather than only reporting. 12 dB wanted, acting below 9.
  plrDb:12,
  minPlrDb:9,
  // How much history the range rests on. LRA over less than half a minute is noise: the
  // statistic is percentiles of 3-second blocks, and ten blocks have no percentiles worth
  // the name.
  rangeWindowMs:60000,
  minBlocks:120,           // 12 s of 100 ms blocks before it will say anything at all
  // How far the balance may be loosened, and in what steps. Slow on purpose: this changes how
  // the whole mix behaves, and a mix that renegotiates its own character every two seconds is
  // worse than one that is slightly flat.
  deadBandCeilingDb:4.5,
  maxMoveFloorDb:2,
  deadBandStepDb:.25,
  maxMoveStepDb:.5,
});
// How far a mix's peaks may stand over its integrated loudness and still be delivered at the target under the ceiling,
// its master's limiter taking no more than its budget: 21 dB at the defaults.
export const deliverableCrestDb=(rules=DYNAMICS)=>rules.ceilingDbtp-rules.targetLufs+rules.limiterBudgetDb;

// **Pink noise as the balance's target profile.**
//
// The cross-adaptive balance asks one question — is this channel near the ensemble's average
// loudness — and a channel's answer is the same whether its energy is all in one octave or
// spread over six. That is how an ensemble ends up correctly balanced and still wrong: five
// bots agreeing about level while four of them sit in the same octave.
//
// Pink noise is the reference because it holds **equal energy in every octave**, which is the
// nearest thing there is to a neutral spectrum: it is what a mix engineer plays through the
// monitors to check a room, and what the pink-noise mixing method sets each instrument
// against. A mix whose long-term average spectrum is pink has no octave doing more work than
// any other.
//
// **What this is not.** Real music is not pink and should not be made pink. Measured long-term
// average spectra of commercial masters fall off above about a kilohertz, faster than pink,
// and are shelved below about a hundred hertz; a strict pink target would ask for a
// bass-heavy, bright mix that nobody wants. So three things keep it honest:
//
//   * `perOctaveDb` tilts the reference. Zero is pink exactly; a negative value asks for the
//     downward tilt real mixes have. It is the one number to change to argue with this.
//   * only the bands between `lowestHz` and `highestHz` are acted on. Below and above that the
//     reference is least trustworthy and the measurement is worst — the lowest band of
//     `AUTO_MIX.bands` is two octaves wide, and an FFT at this window barely resolves it.
//   * `toleranceDb` is wide and `maxTrimDb` is small. This is a nudge to what the balance is
//     already doing, not a graphic equaliser.
//
// **How it acts, and why that way.** Not by moving a fader itself: it biases the loudness the
// balance is *told*. A channel over-represented in a band that is already full is reported as
// louder than it measured, and the existing cross-adaptive rule cuts it — with its own dead
// band, its own selective smoothing, its own maximum move, all unchanged. So pink mixing is a
// weighting on the balance's input rather than a second thing pulling on the same fader, and
// two mechanisms cannot fight over one control. The measured figure is still what the desk
// displays; the weighted one is only what the decision is made on.
// A character's spectral aim, from its projection's shelves (aesthetic.js mixAesthetic): the high shelf's gain
// less the low shelf's, over the octaves between their corners, in dB per octave (0 where it has no shelves).
export function characterTilt(actions){
  const shelf=band=>actions?.find(([kind,value])=>kind==='eq'&&value?.band===band)?.[1];
  const high=shelf('high'),low=shelf('low');
  if(!high||!low||!(high.hz>low.hz))return 0;
  return (high.gainDb-low.gainDb)/Math.log2(high.hz/low.hz);
}
// A character's tone, from its projection's shelves: {low: {hz, gainDb}, high: {hz, gainDb}}, or null without them.
export function characterTone(actions){
  const shelf=band=>{const value=actions?.find(([kind,v])=>kind==='eq'&&v?.band===band)?.[1];return value?{hz:value.hz,gainDb:value.gainDb}:null};
  const low=shelf('low'),high=shelf('high');
  return low&&high?{low,high}:null;
}
// The tone stage's shelves in each channel, flat until a character states its tone.
const TONE_SHELVES=Object.freeze({low:Object.freeze({type:'lowshelf',hz:150}),high:Object.freeze({type:'highshelf',hz:5000})});
export const PINK=Object.freeze({
  // Decibels per octave the reference is tilted from flat-per-octave. 0 is pink.
  perOctaveDb:0,
  // The range the reference is trusted over. `AUTO_MIX.bands` runs 20 Hz to 20 kHz; the ends
  // are where both the reference and the measurement are weakest.
  lowestHz:80,
  highestHz:10240,
  // How far a band may sit from the reference before it is worth doing anything about.
  toleranceDb:3,
  // The most this may add to or subtract from a channel's reported loudness.
  maxTrimDb:3,
  // How much of the way to the wanted trim is taken each decision. Slow, because the profile
  // is measured over seconds and a trim that chased it would be an effect.
  approach:.25,
  // A channel below this share of its own energy in a band is not in that band, so its
  // opinion about that band does not count. Same idea and same figure as the masking metric's
  // `presentShare`, which exists because a bass is "maximally masked" in the treble by
  // definition.
  presentShare:.05,
  // And a band the *mix* is barely in is not acted on either. An empty band reads 40 dB below
  // the reference, which would ask for the largest boost available for whoever happens to be
  // the only thing playing there — chasing a target the ensemble is not playing. The
  // reference says how to divide the energy there is; it does not say to invent any.
  bandFloorShare:.01,
  // How much of the previous profile each round keeps. Pink is a target for the long-term
  // average spectrum, so the profile is an average over rounds rather than one snapshot: at
  // 0.8 and a six-second round, roughly the last half-minute carries most of the weight.
  profileMemory:.8,
});

// Deal the channels out, deterministically, so two desks given the same room and the same list
// of desks divide it the same way without talking to each other. Sorted first, because a Map's
// insertion order is not something two machines agree about.
export function divideChannels(channelIds,deskIds){
  const channels=[...channelIds].map(String).sort();
  const desks=[...deskIds].map(String).sort();
  const shares=new Map(desks.map(id=>[id,[]]));
  if(!desks.length)return shares;
  channels.forEach((channel,index)=>shares.get(desks[index%desks.length]).push(channel));
  return shares;
}

export class LiveDesk {
  // `apply` is how a change reaches a channel, and it is injectable for the same reason the
  // balancer's was: *where* the value belongs is the host's business. The default writes the
  // mixer track, which is right for a headless graph and wrong for an application that has the
  // fader on screen — writing the track behind its own controls changes what you hear while
  // the panel's own state says otherwise. An app passes an applier that goes through the bot's
  // state, so the control, the sound and the shared ensemble link all agree.
  // `clock` is when it listens: `{every(ms, fn) → cancel, now() → seconds}`. The default is the
  // wall clock and the context's time, as it always was; an offline render passes render time,
  // because a setInterval cannot sample audio that is rendered faster than it plays.
  constructor(mixer,{id='desk',rules={},options={},onUpdate=null,protect=[],reverbSend=null,
    apply=null,channels='all',duties=DUTIES,clock=null,metering=null,production=true}={}){
    this.applyChange=apply;
    this.id=String(id);
    this.mixer=mixer;
    // `metering` is how it listens (metering.js: 'analyser' or 'worklet', or a strategy); with the
    // worklet, and no clock given, it also schedules on the audio's own clock.
    this.metering=metering&&typeof metering==='object'?metering:createMetering(this.context,{mode:meteringMode({option:metering,context:this.context})});
    this.clock=clock??(this.metering.mode==='worklet'?workletClock(this.context):wallClock(this));
    // `'all'` rather than a list, so one desk needs no configuration and a second desk is the
    // only thing that ever has to say what it is for.
    this.channels=channels;
    this.duties=new Set(duties);
    this.rules={...LIVE_DESK,...rules};
    this.balance=new FaderBalance({options});
    this.onUpdate=onUpdate;
    // Whose subject the mix is. Unmasking everything against everything says nothing, so the
    // moves are only made on behalf of the channels somebody has named — and with nobody
    // named, every channel is its own subject in turn.
    this.protect=new Set(protect.map(String));
    // What the scene's mix is for, and who may cover whom (setIntention): said by the form or a section's plan.
    this.intention=null;this.permissions=[];this.keptAttacks=new Map();
    // A scene change's moves (sceneChange): what it last made, the moves' timing while it makes them, and until when
    // each duty leaves what it moved (context seconds).
    this.lastScene=null;this.sceneTiming=null;this.settling={};
    // How a reverb send is delivered. Null means the mixer's own `reverb` send; a routing
    // graph can supply its own, which is how the Faust FDN reverb becomes the room.
    this.reverbSend=reverbSend;
    this.taps=new Map();
    this.last=null;
    this.running=false;
    this.timers=[];
    this.lastMaskAt=-Infinity;
    this.elapsedMs=0;
    this.presentUntil=new Map();   // channel → the time it stops counting as present
    this.counts=[];                // recent room sizes, for the average
    this.sentShare=null;           // what the send was last actually moved to
    // Dynamics. The master tap is built on the first sample rather than here, because a desk
    // can be constructed before the mixer has an output worth listening to.
    this.dynamics={...DYNAMICS,...(rules.dynamics||{})};
    this.pink={...PINK,...(rules.pink||{})};
    this.trims=new Map();           // channel → the loudness bias it is currently given, in dB
    this.lastProfile=null;
    this.lastTrims=null;
    this.spectrumSlot=-1;this.spectrumTick=0;
    this.lastSpectrumAt=-Infinity;
    this.lastPeak=null;
    this.lastPeakAt=-Infinity;
    this.master=null;
    this.lastDynamics=null;
    // What the balance was set to before this desk started loosening it, so stopping puts it
    // back rather than leaving the room permanently unbalanced.
    this.balanceDefaults={deadBandDb:this.balance.options.deadBandDb,
      maxMoveDb:this.balance.options.maxMoveDb};
    // Production: when a character or an approach is set, the desk also makes the mix the way the
    // approach does -- its reverbs and echoes, each channel's strip by role, its buses and its
    // sidechain (public/mix-approach.js) -- and its own duties aim where the approach says: the
    // reverb shared by role, the parts balanced at the approach's loudnesses, the reverb held at its
    // wet level. False keeps the desk to the moves it always made.
    this.production=production!==false;
    this.approachPlan=null;
    this.applier=null;
    this.wet=null;this.lastWet=null;
    // Placement (placement.js): its rules, what it gave each channel -- {pan, width, depth, room, trimDb} -- the pans
    // somebody else set, the master's stereo image as measured (the check), and when and on what it last planned.
    this.place={...PLACEMENT,...(rules.placement||{})};
    // What the desk's own rules said of placement, which an approach's defaults do not override (the kit's perspective).
    this.placeGiven={...(rules.placement||{})};
    this.placed=new Map();
    this.pinned=new Set();
    this.placeUntil=new Map();      // channel → the time it stops counting as in the room, for placing
    this.image=null;
    this.lastPlacement=null;this.placeKey=null;this.lastPlanAt=-Infinity;this.middleDepth=null;
    // Submixes (submix.js): the buses, made at the first decision that groups, and each group's balance of its own
    // channels among themselves (bus -> FaderBalance), under the ensemble's balance of the groups.
    this.submix={...SUBMIX,...(rules.submix||{})};
    this.submixes=null;
    this.groupBalances=new Map();
    this.soundchecked=new Map();  // part -> what the soundcheck set it at, before it was heard (soundcheck)
    this.kitSends=new Map();        // a split kit's own channel -> the reverb send it had before its drums were sent
    // Punch (punch.js): its choices; what it built on each channel -- {role, inserts, processors, thresholds, reductions,
    // makeup, post (a meter after its compressors), pre (one before them, on a bus)}; and each duck it keyed, by the
    // channel ducked and the drum it steps back under.
    this.punchChoices={...PUNCH,...(rules.punch||{})};
    this.punched=new Map();
    // How far each drum's boost is backed off for the mix's headroom (punch.js nextBackoff), dB.
    this.punchBackoff=0;
    this.ducked=new Map();
  }

  // ---- spectral balance ------------------------------------------------------
  //
  // The octave width of each band, and from it the share of the total energy a pink reference
  // would put there. Pink is equal energy per octave, so the share is simply the band's width
  // in octaves over the total — which handles `AUTO_MIX.bands`' uneven ends correctly rather
  // than pretending nine bands are nine octaves.
  pinkReference(){
    const bands=AUTO_MIX.bands,tilt=this.pink.perOctaveDb;
    const lowestOctave=Math.log2(bands[0]);
    const weights=[];
    for(let index=0;index<bands.length-1;index++){
      const low=bands[index],high=bands[index+1];
      const octaves=Math.log2(high/low);
      const centre=(Math.log2(low)+Math.log2(high))/2-lowestOctave;
      weights.push(octaves*10**(tilt*centre/10));
    }
    const total=weights.reduce((sum,value)=>sum+value,0);
    return weights.map(value=>value/total);
  }

  // Where the mix's energy actually is, against where pink would put it. Measured on the
  // master, which is after the faders and the EQ — the profile of what is heard, not of what
  // was played.
  pinkProfile(){
    if(!this.master?.handle.recent())return null;
    const energies=this.master.bands;
    if(!energies)return null;
    const total=energies.reduce((sum,value)=>sum+value,0);
    if(!(total>0))return null;
    const reference=this.pinkReference();
    const bands=AUTO_MIX.bands;
    return energies.map((energy,index)=>{
      const share=energy/total;
      const acted=bands[index]>=this.pink.lowestHz&&bands[index+1]<=this.pink.highestHz;
      // Zero energy in a band is −Infinity decibels, which is true and useless. Floor it at
      // the point where the band is empty enough that the number stops meaning anything.
      const deviationDb=share>0?10*Math.log10(share/reference[index]):-40;
      return {hz:[bands[index],bands[index+1]],share,reference:reference[index],
        deviationDb:Math.round(deviationDb*10)/10,acted};
    });
  }

  // What each channel should be told about its own loudness, so that the balance moves the
  // mix toward the reference without being told about spectra at all.
  pinkTrims(){
    // Still on the slower clock, though the reason has changed: the transforms now happen one
    // per sample tick in `rollSpectrum`, so what this paces is how fast the trims move. A
    // quarter of the way every six seconds is a balance settling; every two seconds is an
    // effect.
    if(this.elapsedMs-this.lastSpectrumAt<this.rules.spectrumEveryMs&&this.lastTrims)
      return this.lastTrims;
    this.lastSpectrumAt=this.elapsedMs;
    const profile=this.pinkProfile();
    this.lastProfile=profile;
    if(!profile||!this.does('level'))return this.lastTrims={};
    const wanted={};
    for(const [id,tap] of this.taps){
      const energies=tap.bands;
      if(!energies)continue;
      const total=energies.reduce((sum,value)=>sum+value,0);
      if(!(total>0))continue;
      let weighted=0,weight=0;
      for(const [index,band] of profile.entries()){
        if(!band.acted||band.share<this.pink.bandFloorShare)continue;
        const share=energies[index]/total;
        if(share<this.pink.presentShare)continue;      // this channel is not in this band
        // Inside the tolerance the band is where it should be and has no opinion.
        const excess=band.deviationDb>this.pink.toleranceDb?band.deviationDb-this.pink.toleranceDb
          :band.deviationDb<-this.pink.toleranceDb?band.deviationDb+this.pink.toleranceDb:0;
        weighted+=share*excess;weight+=share;
      }
      // A channel in a band that is over-represented should come down, so the trim is the
      // negative of the excess it is sitting in.
      wanted[id]=weight>0?clamp(-weighted/weight,-this.pink.maxTrimDb,this.pink.maxTrimDb):0;
    }
    // Approach, never jump: the profile is measured over seconds and a trim that followed it
    // exactly would be heard as an effect rather than as a balance.
    const trims={};
    for(const id of this.taps.keys()){
      const target=wanted[id]??0;
      const now=this.trims.get(id)??0;
      const next=now+(target-now)*this.pink.approach;
      this.trims.set(id,next);
      trims[id]=Math.round(next*100)/100;
    }
    for(const id of [...this.trims.keys()])if(!this.taps.has(id))this.trims.delete(id);
    return this.lastTrims=trims;
  }

  // ---- dynamics --------------------------------------------------------------
  //
  // The master bus, split rather than downmixed. An AnalyserNode gives one channel of data
  // whatever you feed it, and BS.1770 sums the channels: measuring the downmix of correlated
  // stereo reads 3 dB low, which would make a stated −16 LUFS target wrong by 3 dB. A splitter
  // and two analysers is the difference between a figure and a number.
  tapMaster(){
    if(this.master)return this.master;
    // A context that cannot split or analyse is a real situation — an offline render, a
    // partial stub — and it should say so rather than throw halfway through a decision or
    // report a mix it never heard.
    if(!this.mixer.output||this.metering.mode==='analyser'&&(typeof this.context.createChannelSplitter!=='function'
      ||typeof this.context.createAnalyser!=='function')){
      this.masterUnavailable='this context has no master bus to listen to';
      return null;
    }
    // The master in stereo: its meter over the whole range window, the newest frames for the
    // true peak, a window of audio for its spectrum, and **the peak per measurement, kept as a
    // ring** — a crest ratio is a peak *over the same stretch* as the loudness it is divided
    // against, and an oversampled `truePeak` is too expensive to run continuously, so the
    // cheap sample peak is kept and `manageDynamics` takes its maximum over whichever window
    // it needs: the whole range window for PLR, the last three seconds for PSR.
    const handle=this.metering.tap(this.mixer.output,{channels:2,keepBlocks:Math.ceil(this.dynamics.rangeWindowMs/100),
      chunkWindowMs:this.rules.maskWindowMs,peakWindowMs:this.dynamics.rangeWindowMs,sampleMs:this.rules.sampleMs});
    this.master={handle,
      get meter(){return handle.meter},get chunks(){return handle.chunks},get recent(){return handle.recent()},
      // What the last oversampled reading added over that frame's plain sample peak. Applied
      // to the ring maxima so both crests are true-peak *estimates* rather than sample peaks,
      // with the overshoot measured on this material rather than assumed.
      overshootDb:0};
    return this.master;
  }

  // On the analyser path this is sampled, not continuous: the analysers hold 2048 frames and
  // are read every 50 ms, so it sees about 85% of the audio at 48 kHz -- enough for a loudness
  // range to be worth quoting, not enough to be called metering. On the worklet path (the
  // default, metering.js) the handle has already heard every sample and this reads nothing.
  // The per-channel taps carry the same honesty: a figure is as complete as the path behind it.
  sampleMaster(){
    const master=this.tapMaster();
    if(!master)return;
    master.handle.sample();
  }

  // What the mix is doing, and what to do about it.
  manageDynamics(){
    const master=this.master,recent=master?.handle.recent();
    if(!recent)return {because:this.masterUnavailable||'nothing measured yet'};
    const blocks=master.meter.allBlocks;
    const summary=loudnessSummary(blocks,{sampleRate:this.context.sampleRate});
    // A 4x-oversampled true peak is 24 taps in 4 phases over every sample — 0.39 M
    // multiply-adds for one frame pair — so it runs on the slow clock. What it is *for* is the
    // delivery ceiling, which is about inter-sample overs; and measuring it beside that frame's
    // plain sample peak gives the overshoot to apply to the ring below.
    if(this.elapsedMs-this.lastPeakAt>=this.rules.spectrumEveryMs||!this.lastPeak){
      let framePeak=0;
      for(const channel of recent)
        for(const value of channel){const size=Math.abs(value);if(size>framePeak)framePeak=size}
      const sampleDb=gainDb(framePeak);
      // A snapshot that lands in a rest measures nothing: the true peak of digital silence read
      // as -240 dBTP and lifted every crest figure by two hundred decibels for the next six
      // seconds. An offline render found it, its first decision falling exactly in the gap
      // between two phrases; live it happens whenever this clock and a rest coincide. Keep the
      // last estimate and try again at the next decision.
      if(sampleDb>=SILENT_SNAPSHOT_DB){
        this.lastPeakAt=this.elapsedMs;
        this.lastPeak=truePeak(recent);
        if(Number.isFinite(this.lastPeak?.dbtp))master.overshootDb=Math.max(0,this.lastPeak.dbtp-sampleDb);
      }
    }
    const peak=this.lastPeak;
    const shortTerm=master.meter.shortTerm();
    const rules=this.dynamicsAims();

    // **Each crest over the window it belongs to.** This was wrong: both ratios divided one
    // 43 ms frame's peak — refreshed every six seconds — against loudnesses measured over
    // three and sixty seconds. A peak-to-loudness ratio is a peak over the *same* stretch as
    // the loudness, so PLR takes the ring's maximum across the whole range window and PSR
    // across the last three seconds, each lifted by the measured oversampling overshoot.
    const windowPeakDb=gainDb(master.handle.peakOver(this.dynamics.rangeWindowMs/1000))+master.overshootDb;
    const shortPeakDb=gainDb(master.handle.peakOver(3))+master.overshootDb;
    const psr=Number.isFinite(windowPeakDb)&&Number.isFinite(shortTerm)
      ?shortPeakDb-shortTerm:null;
    const plr=Number.isFinite(windowPeakDb)&&Number.isFinite(summary.integrated)
      ?windowPeakDb-summary.integrated:null;
    const reading={integrated:round(summary.integrated),range:round(summary.range),
      shortTerm:round(shortTerm),maxShortTerm:round(summary.maxShortTerm),
      truePeakDbtp:round(peak?.dbtp),
      // The peak PLR is measured against, over the same window as the integrated loudness.
      windowPeakDbtp:round(windowPeakDb),
      psrDb:round(psr),plrDb:round(plr),
      blocks:blocks.length,seconds:Math.round(blocks.length/10)};
    // A range measured over twelve seconds is a rumour. Say so rather than acting on it.
    if(blocks.length<rules.minBlocks)
      return {...reading,moved:false,
        because:`${reading.seconds}s measured; a loudness range needs `
          +`${Math.round(rules.minBlocks/10)}s before it means anything`};
    if(!this.does('dynamics'))
      return {...reading,moved:false,because:'dynamics is another desk\u2019s'};

    const before={deadBandDb:this.balance.options.deadBandDb,
      maxMoveDb:this.balance.options.maxMoveDb};
    // Two ways to be flat, and either one is enough: a short loudness range over the minute, or
    // a crest that has collapsed over the last three seconds. Flat wins when both fire, because
    // the balance is the only lever there is and loosening it is the only direction that helps
    // a collapsed crest — a mix with a wide range and no transients is still a flat mix in the
    // bar you are listening to.
    const flat=(Number.isFinite(summary.range)&&summary.range<rules.minRangeLu)
      ||(Number.isFinite(psr)&&psr<rules.minPsrDb)
      ||(Number.isFinite(plr)&&plr<rules.minPlrDb);
    const wide=Number.isFinite(summary.range)&&summary.range>rules.maxRangeLu;
    let deadBandDb=before.deadBandDb,maxMoveDb=before.maxMoveDb;
    if(flat){
      deadBandDb=Math.min(rules.deadBandCeilingDb,deadBandDb+rules.deadBandStepDb);
      maxMoveDb=Math.max(rules.maxMoveFloorDb,maxMoveDb-rules.maxMoveStepDb);
    }else if(wide){
      // Back toward the published defaults and no further. The desk does not compress a
      // live ensemble for being too dynamic.
      deadBandDb=Math.max(this.balanceDefaults.deadBandDb,deadBandDb-rules.deadBandStepDb);
      maxMoveDb=Math.min(this.balanceDefaults.maxMoveDb,maxMoveDb+rules.maxMoveStepDb);
    }
    const moved=deadBandDb!==before.deadBandDb||maxMoveDb!==before.maxMoveDb;
    if(moved)this.balance.options={...this.balance.options,deadBandDb,maxMoveDb};
    const balance={deadBandDb:round(deadBandDb),maxMoveDb:round(maxMoveDb)};
    return {...reading,moved,balance,flat,wide,
      target:{lufs:rules.targetLufs,rangeLu:rules.rangeLu,psrDb:rules.psrDb,
        plrDb:rules.plrDb,ceilingDbtp:rules.ceilingDbtp},
      because:flat
        ?`${fmt(summary.range,'LU')} range, ${fmt(psr,'dB')} short crest and `
          +`${fmt(plr,'dB')} whole-window crest against ${rules.minRangeLu} LU, `
          +`${rules.minPsrDb} dB and ${rules.minPlrDb} dB — `
          // Saying "balancing less hard" while sitting at the limit reads as a move that just
          // happened. At the limit the honest sentence is that there is nothing left to give.
          +(moved
            ?`balancing less hard (dead band ${balance.deadBandDb} dB, max move `
              +`${balance.maxMoveDb} dB) so the quiet channels are left quiet`
            :`already balancing as gently as it will (dead band ${balance.deadBandDb} dB, `
              +`max move ${balance.maxMoveDb} dB); the rest of the range would have to come `
              +`from what the bots play`)
        :wide
          ?`${fmt(summary.range,'LU')} range, above ${rules.maxRangeLu} LU — back toward the `
            +`default balance, which is as far as it goes; a live ensemble that is too `
            +`dynamic is a musical situation, not a fault`
          :`${fmt(summary.range,'LU')} range, ${fmt(psr,'dB')} short crest and `
            +`${fmt(plr,'dB')} whole-window crest, all inside their targets — nothing to do`,
    };
  }

  get context(){return this.mixer.context}

  // Does this desk act on this channel? It still *hears* it either way.
  owns(id){return this.channels==='all'||[...this.channels].map(String).includes(String(id))}
  does(duty){return this.duties.has(duty)}
  // Change the division of labour while running. The channels it gives up are handed back the
  // way `stop` would hand them back, or they keep whatever this desk last did to them forever.
  // The desk's half of the aesthetic bridge.
  //
  // A character does not reach in and move faders. It moves the *targets the desk is aiming
  // at* -- how loud the mix should sit, how much crest to protect, how much range to allow,
  // and how willing the desk is to act at all -- and the desk then does its ordinary work
  // against them. That distinction is the whole design: "dark and spacious" is a statement
  // about where the mix should end up, not a set of gain moves, and a desk that treated it
  // as gain moves would fight its own loudness measurements a second later.
  //
  // The sends in the projection are for whoever is sending per-channel messages; the desk itself
  // only takes the targets. Darkness is one: the projection's two shelves (take the top, add weight
  // underneath) become the aim of the pink reference's tilt, their difference over the octaves
  // between them, and the balance weighs its channels against it as it always does (a bright
  // channel crowding a top the character wants quieter is reported louder, and cut). 0f found in
  // a render that a character's darkness never reached the sound (SESSIONS.md, 28 September).
  // Reversible by `clearAesthetic`, because a character is a state the room can leave.
  setAesthetic(vector){
    const projection=mixAesthetic(vector),rules=projection?.rules;
    if(!rules)return this;
    if(!this.dynamicsBeforeCharacter)this.dynamicsBeforeCharacter={...this.dynamics};
    if(!this.pinkBeforeCharacter)this.pinkBeforeCharacter={...this.pink};
    const tilt=characterTilt(projection.actions);
    this.pink={...this.pinkBeforeCharacter,perOctaveDb:this.pinkBeforeCharacter.perOctaveDb+tilt};
    // And the tone itself: the projection's shelves in every channel the desk owns, made at once, as a scene is,
    // since a stated character is a stated move and a small gradual one would sound accidental.
    this.setTone(characterTone(projection.actions));
    this.character=vector;
    // Only the aims move. Floors that exist to stop the desk hurting the mix -- minRangeLu,
    // minPsrDb, minPlrDb, the ceiling -- are not a matter of taste and stay where they are.
    this.dynamics={...this.dynamics,
      targetLufs:rules.targetLufs,psrDb:rules.psrDb,plrDb:rules.plrDb,
      rangeLu:Math.max(this.dynamics.minRangeLu,Math.min(this.dynamics.maxRangeLu,rules.rangeLu)),
      deadBandCeilingDb:rules.deadBandCeilingDb};
    // The second compression stage. The mixer builds it as a pass-through and it stays one
    // until a character asks for the headroom. With production on, the approach stages it.
    if(this.production&&this.mixer?.setEffects)return this.setApproach(vector);
    const staging=mixAesthetic(vector)?.busCompression;
    if(staging&&this.mixer?.setBusCompression)this.busCompression=this.mixer.setBusCompression(staging);
    this.onUpdate?.(this.state());
    return this;
  }
  // The character's tone (characterTone) in every channel the desk owns, or flat again (null), over a scene's time.
  setTone(tone){
    this.tone=tone;
    const at=this.context?.currentTime??0,seconds=MIX_INTENTION.sceneSeconds;
    for(const [id,tap] of this.taps){
      if(!this.owns(id)||!tap.eq?.tone)continue;
      for(const [band,filter] of Object.entries(tap.eq.tone)){
        filter.frequency.setValueAtTime(tone?.[band]?.hz??TONE_SHELVES[band].hz,at);
        filter.gain.linearRampToValueAtTime(tone?.[band]?.gainDb??0,at+seconds);
      }
    }
  }
  // A scene's mix intention and its masking permissions (shared/mix-intention.js; the extreme-aesthetics report's M3),
  // said by the form or a section's plan and never chosen here. Like a character, it moves only the aims of the duties
  // that hold its axes: the unmasking's cuts (fusion, and the permissions), the punch's transient shaping (attack
  // legibility), the range the dynamics duty lets the mix keep (contrast) and the reverb's level (depth). An axis no
  // duty holds yet is reported so. setIntention(null) returns the desk to its own way.
  // Said for a moment (`atSeconds`, context seconds: when the tick it was said on is heard, a section's downbeat), it is
  // a scene change, made there all at once (sceneChange); said with no moment, the duties move toward it at their pace.
  setIntention(intention,{permissions=[],atSeconds=null}={}){
    const before=this.intention;
    this.intention=intention&&saysAnything(intention)?mixIntention(intention):null;
    this.permissions=(permissions??[]).map(maskingPermission);
    const scene=Number.isFinite(atSeconds)&&this.running?this.sceneChange(before,this.intention,atSeconds):null;
    this.onUpdate?.(this.state());
    return {...this.intentionReach(),...(scene?{scene}:{})};
  }
  // A scene change (the user, 27 September 2026, on the form's section mixes, each reached at the duties' own pace: "The
  // minor changes in this are not intense or synchronous enough to be interpreted as deliberate, to my ear"). As an
  // engineer recalls a scene on a section's downbeat, every move the new intention makes is made at `at`, together,
  // each over MIX_INTENTION.sceneSeconds:
  //   - depth: the reverb's returns by the difference the two depths make to the space duty's aim;
  //   - attack legibility: the drums' transient shaping set to its new scale;
  //   - width: the band placed again for the new width, its pans and widths moved there.
  // Each duty then leaves what it moved for MIX_INTENTION.settleSeconds, while its meters hear the new scene, and holds
  // it from there. Fusion and dynamic contrast are left to their duties: an unmasking cut needs the new scene's
  // spectra, and contrast is a range kept over minutes. Returns {at, seconds, moved: {axis: what}}.
  sceneChange(before,after,at){
    const seconds=MIX_INTENTION.sceneSeconds,moved={},settle=at+MIX_INTENTION.settleSeconds;
    const differs=axis=>(before?.[axis]??null)!==(after?.[axis]??null);
    const plan=this.approachPlan,mixer=this.mixer;
    if(differs('depth')&&this.does('space')&&Number.isFinite(plan?.wetLu)&&mixer?.reverbReturn&&typeof mixer.setEffects==='function'){
      const stepDb=depthWetLu(plan.wetLu,after?.depth)-depthWetLu(plan.wetLu,before?.depth),gain=10**(stepDb/20);
      const values={reverbReturn:clamp(mixer.settings.reverbReturn*gain,.02,1.5)};
      if(mixer.room)values.roomReturn=clamp(mixer.settings.roomReturn*gain,.02,1.5);
      mixer.setEffects(values,{atSeconds:at,seconds});
      this.settling.space=settle;moved.depth={stepDb:round(stepDb),reverbReturn:Math.round(values.reverbReturn*1000)/1000};
    }
    if(differs('attackLegibility')&&this.does('punch')){
      const legibility=after?.attackLegibility??null,shaped={};
      const punch=backedOff(scaledPunch(punchPlan(plan?.punch,this.punchChoices),legibility===null?null:punchScale(legibility)),this.punchBackoff);
      if(punch)for(const [id,record] of this.punched){
        if(!record.ready)continue;
        const settings=record.role==='bus'?[punch.glue,punch.parallel]:[punch.drums[record.role]];
        record.processors.forEach((processor,index)=>{
          if(settings[index]?.mode!=='transient'||typeof processor?.set!=='function')return;
          const {boost,sustain}=settings[index],aim=punchAim(settings[index]);
          processor.set({boost,sustain,aim},{atSeconds:at,seconds});record.shapes[index]={boost,sustain,aim};shaped[id]={boost,sustain,aim};
        });
      }
      if(Object.keys(shaped).length)moved.attackLegibility=shaped;
    }
    if(differs('width')&&this.does('placement')){
      this.placeKey=null;this.sceneTiming={at,seconds};
      try{const placed=this.managePlacement(this.last?.level?.active??[]);if(Object.keys(placed?.moved??{}).length)moved.width=placed.moved}
      finally{this.sceneTiming=null}
      this.settling.placement=settle;
    }
    return this.lastScene={at,seconds,moved};
  }
  intentionReach(){return {intention:this.intention,permissions:this.permissions,...intentionReach(this.intention)}}
  // The channels a permission's name means: that channel, or every channel of that role (a track's role: 'pad', 'bass'),
  // or every channel of that bot (its tracks, bot:<id>:<key>). What a bot says in its own terms reaches the desk's.
  channelsNamed(name){
    if(this.taps.has(name))return [name];
    return [...this.taps].filter(([id,tap])=>tap.track?.role===name||String(id).startsWith(`bot:${name}:`)).map(([id])=>id);
  }
  permittedPairs(){
    return this.permissions.flatMap(permission=>permission.fuse?[{fuse:permission.fuse.flatMap(name=>this.channelsNamed(name))}]
      :this.channelsNamed(permission.masker).flatMap(masker=>this.channelsNamed(permission.masked).map(masked=>({masker,masked,bands:permission.bands}))));
  }
  // The dynamics duty's aims under the scene's dynamic contrast: the range below which it calls the mix flat and lets
  // the balance go, from the desk's floor (no contrast asked) toward its ceiling (the most).
  dynamicsAims(){
    const contrast=this.intention?.dynamicContrast;
    if(contrast===null||contrast===undefined)return this.dynamics;
    const rangeLu=contrastRangeLu(contrast,this.dynamics);
    return {...this.dynamics,rangeLu,minRangeLu:Math.max(this.dynamics.minRangeLu,rangeLu)};
  }
  // The reverb's level against the mix the space duty holds: the approach's, moved by the scene's depth.
  wetAim(plan){return depthWetLu(plan.wetLu,this.intention?.depth)}
  // An approach by name, or the one nearest a character: planned for the mixer's tempo and put
  // onto the mixer. Everything it changes, clearAesthetic takes back.
  setApproach(which){
    const plan=planApproach(which,{bpm:this.mixer?.bpm??108,vector:typeof which==='string'?this.character:null});
    this.approachPlan=plan;
    this.applier??=new ApproachApplier(this.mixer,{reverbSends:!this.does('space'),roomSends:!this.does('placement'),routing:!this.does('submix')});
    this.applier.apply(plan);
    this.busCompression=this.mixer.busCompression??null;
    this.onUpdate?.(this.state());
    return this;
  }
  clearAesthetic(){
    if(this.applier){this.applier.restore();this.applier=null}
    this.approachPlan=null;this.closeWet();
    this.mixer?.setBusCompression?.({ratio:1,thresholdDb:0,makeupDb:0});
    this.busCompression=null;
    if(this.dynamicsBeforeCharacter)this.dynamics={...this.dynamicsBeforeCharacter};
    if(this.pinkBeforeCharacter)this.pink={...this.pinkBeforeCharacter};
    this.setTone(null);
    this.dynamicsBeforeCharacter=null;this.pinkBeforeCharacter=null;this.character=null;
    this.onUpdate?.(this.state());
    return this;
  }
  setRemit({channels,duties}={}){
    if(channels!==undefined){
      const before=[...this.taps.keys()].filter(id=>this.owns(id));
      this.channels=channels;
      for(const id of before)if(!this.owns(id))this.release(id);
    }
    if(duties!==undefined){
      const grouped=this.does('submix');
      this.duties=new Set(duties);
      // Grouping handed over: the channels back to the master, and an approach's own buses back to it; taken up: the
      // approach's buses given up to the groups'.
      if(grouped&&!this.does('submix')){this.submixes?.restore();this.submixes=null;this.groupBalances.clear()}
      if(grouped!==this.does('submix'))this.applier?.setRouting(!this.does('submix'));
      if(!this.does('punch'))this.unpunch();
    }
    return this;
  }
  // One change to one channel, through the host's applier when there is one.
  change(id,values,seconds){
    const tap=this.taps.get(id);
    if(!tap)return;
    this.changeTrack(id,tap.track,values,seconds);
  }
  // A scene change's moves are made at its moment, over its time (sceneTiming); every other move now, over `seconds`.
  changeTrack(id,track,values,seconds){
    const scene=this.sceneTiming,timing=scene?{seconds:scene.seconds,atSeconds:scene.at}:{seconds};
    if(this.applyChange)this.applyChange({id,values,track,...timing});
    else track.set(values,timing);
  }

  // Put one channel back as it was found, without stopping.
  release(id){
    const tap=this.taps.get(id);
    if(!tap)return;
    this.change(id,{dry:tap.base,reverb:tap.baseSend,...this.unplaced(id)},this.rules.rampSeconds);
    this.placed.delete(id);
    for(const filter of [...Object.values(tap.eq?.bands||{}),...Object.values(tap.eq?.tone||{})])
      filter.gain.linearRampToValueAtTime(0,this.context.currentTime+this.rules.eqRampSeconds);
  }

  // Each channel gets three peaking filters between its input and its pan, which is the one
  // place a cut is *this channel's* rather than the room's. `desk.js` decides what the bands
  // are; this only builds them.
  insertEq(track){
    const bands={};
    let previous=null;
    for(const band of EQ.bands){
      const filter=this.context.createBiquadFilter();
      filter.type='peaking';
      filter.frequency.value=EQ.defaults[band].hz;
      filter.Q.value=EQ.defaults[band].q;
      filter.gain.value=0;
      bands[band]=filter;
      if(previous)previous.connect(filter);
      previous=filter;
    }
    // Then the character's tone: a low and a high shelf, flat unless a character has stated one (setTone).
    const tone={};
    for(const [band,shelf] of Object.entries(TONE_SHELVES)){
      const filter=this.context.createBiquadFilter();
      filter.type=shelf.type;
      filter.frequency.value=this.tone?.[band]?.hz??shelf.hz;
      filter.gain.value=this.tone?.[band]?.gainDb??0;
      tone[band]=filter;previous.connect(filter);previous=filter;
    }
    // Splice the chain in before the pan: feed → low → mid → high → pan, in place of feed → pan,
    // where the feed is the track's own insert chain when it has one (the mixer routes input →
    // inserts → pan) and the input otherwise. Splicing at the input regardless left the insert
    // path in place beside the EQ: measured on the offline graph, a channel came out at twice
    // its level with the desk running, and stayed doubled after `stop` put input → pan back.
    const feed=track.inserts?.exit??track.input;
    try{feed.disconnect(track.pan)}catch{}
    feed.connect(bands[EQ.bands[0]]);
    previous.connect(track.pan);
    return {bands,tone,first:bands[EQ.bands[0]],last:previous,feed};
  }

  removeEq(track,eq){
    if(!eq)return;
    const feed=eq.feed??track.input;
    try{feed.disconnect(eq.first)}catch{}
    try{eq.last.disconnect(track.pan)}catch{}
    eq.widthStage?.dispose();
    for(const filter of [...Object.values(eq.bands),...Object.values(eq.tone??{})]){try{filter.disconnect()}catch{}}
    feed.connect(track.pan);
  }

  tapTracks(){
    for(const [id,track] of this.mixer.tracks){
      // A bus is heard through its channels (submix.js), so it is not tapped as one.
      if(this.taps.has(id)||track.bus)continue;
      // Pre-fader and before this desk's EQ, so what is measured is not what this desk has already
      // done to it: a loop that measured its own output would chase its tail. But after the
      // channel's inserts -- an approach's compressor, punch's (punch.js), a duck -- so what is
      // measured is what the channel puts into the mix, and whatever a compressor takes away is
      // made up by the balance, whoever's compressor it is. Measured before them, as it was until
      // 26 September, the studio approach's drum compressors (4 dB on the hits, no make-up) left
      // the drums 2-4 dB under the loudness the balance had set them at.
      // (A channel without an insert chain -- a stub -- is measured at its input.)
      // **A meter per channel, fed once as the audio arrives.** `channelLoudness` builds a
      // fresh meter and K-weights the whole window on every call, which put two seconds of
      // audio for every channel through two biquads at every decision: measured at 267 ms
      // of the 373 ms `decide()` spent, in bursts of up to 21 ms every two seconds. Exactly
      // the same statistic — the gated integrated loudness of the window — computed from
      // blocks filtered once as they arrive, is the same work spread over forty samples
      // instead of arriving in one lump in the thread that owes the audio graph its next
      // block (and, with the worklet, off that thread altogether).
      const handle=this.metering.tap(track.inserts?.exit??track.input,{channels:1,keepBlocks:Math.ceil(this.rules.windowMs/100),
        chunkWindowMs:this.rules.maskWindowMs,peakWindowMs:this.rules.windowMs,sampleMs:this.rules.sampleMs});
      this.taps.set(id,{handle,track,get meter(){return handle.meter},get chunks(){return handle.chunks},get analyser(){return handle.analysers?.[0]},
        base:track.settings.dry,baseSend:track.settings.reverb,basePan:track.settings.pan??0,baseRoom:track.settings.room??0,
        eq:this.insertEq(track),eqDb:{low:0,mid:0,high:0}});
    }
    for(const id of [...this.taps.keys()])if(!this.mixer.tracks.has(id)||this.mixer.tracks.get(id).bus){
      const tap=this.taps.get(id);
      tap.handle.close();tap.stereo?.handle.close();
      this.placed.delete(id);this.pinned.delete(id);
      const less=this.returns?.less.get(id);
      if(less){try{less.dry.disconnect(less.gain)}catch{}try{less.gain.disconnect()}catch{}this.returns.less.delete(id)}
      this.removeEq(tap.track,tap.eq);
      this.taps.delete(id);
    }
  }

  // Each channel heard in stereo too, where its panner hears it (after its inserts and this desk's EQ), once the master is
  // tapped (so a stub mixer's meters are handed out in the order they always were): whether it is mono or stereo and how
  // wide, and how much of it there is (placement.js StereoStats), which the level duty reads its loudness in the mix from
  // and placement its width, its weight and its pan's effect. Discrete, so a mono channel's right side is silent rather
  // than a copy of its left; every block counted as it arrives, as the meters count theirs.
  tapStereo(){
    if(!this.does('level')&&!this.does('placement'))return;
    const options={seconds:this.place.imageSeconds,longSeconds:this.place.energySeconds,knownSeconds:this.place.knownSeconds,sampleRate:this.context.sampleRate};
    for(const tap of this.taps.values()){
      if(tap.stereo)continue;
      const stats=new StereoStats(options);
      const handle=this.metering.tap(tap.eq?.last??tap.track.input,{channels:2,interpretation:'discrete',keepBlocks:1,
        chunkWindowMs:this.rules.sampleMs,peakWindowMs:this.rules.sampleMs,sampleMs:this.rules.sampleMs});
      handle.onBlock=audio=>stats.add(audio[0],audio[1]);
      tap.stereo={handle,stats};
    }
    if(this.master&&!this.image&&this.does('placement')){
      const image=this.image=new StereoStats({...options,seconds:this.place.energySeconds});
      this.master.handle.onBlock=audio=>image.add(audio[0],audio[1]);
      // And the rest of the mix, as the render's returns stem is built (public/render/returns-tap.js): the mix bus less
      // every player's own output, which leaves the shared effects' returns, whatever they are.
      if(this.mixer.output&&typeof this.context.createGain==='function'){
        const sum=this.context.createGain(),stats=new StereoStats({...options,seconds:this.place.energySeconds});
        this.mixer.output.connect(sum);
        const handle=this.metering.tap(sum,{channels:2,keepBlocks:1,chunkWindowMs:this.rules.sampleMs,peakWindowMs:this.rules.sampleMs,sampleMs:this.rules.sampleMs});
        handle.onBlock=audio=>stats.add(audio[0],audio[1]);
        this.returns={sum,handle,stats,less:new Map()};
      }
    }
    // What every channel and every bus puts into the mix bus taken out of the returns once, as it arrives: its output to
    // the master (audio-mixer.js toMaster, after its fader), so a channel routed into a bus is taken out once, through
    // its bus and with whatever the bus did to it, and what is left is the shared effects' returns alone.
    if(this.returns){
      for(const [id,track] of this.mixer.tracks){
        const out=track.toMaster??track.dry;
        if(!out||this.returns.less.get(id)?.dry===out)continue;
        const gain=this.context.createGain();gain.gain.value=-1;out.connect(gain);gain.connect(this.returns.sum);
        this.returns.less.set(id,{dry:out,gain});
      }
      for(const [id,less] of [...this.returns.less])if(!this.mixer.tracks.has(id)){
        try{less.dry.disconnect(less.gain)}catch{}try{less.gain.disconnect()}catch{}this.returns.less.delete(id);
      }
    }
  }

  sample(){
    this.tapTracks();
    this.sampleMaster();
    this.tapStereo();
    this.elapsedMs+=this.rules.sampleMs;
    // What each handle keeps — the level window in its meter, the spectral window in its
    // chunks — it keeps in recycled buffers: nothing here is allocated per tick.
    for(const tap of this.taps.values()){tap.handle.sample();tap.stereo?.handle.sample()}
    for(const record of this.punched.values()){
      record.post?.sample();record.pre?.sample();
      // Each compressor's meter, watched as an engineer watches it: its deepest reduction and loudest level since the
      // last decision (the worklet reports its deepest about twenty times a second).
      record.processors.forEach((processor,index)=>{
        if(!processor?.reduction)return;
        record.swings[index]=Math.max(record.swings[index]??0,-processor.reduction());
        if(processor.boost){record.boosts??=[];record.boosts[index]=Math.max(record.boosts[index]??0,processor.boost())}
        record.levels[index]=Math.max(record.levels[index]??-Infinity,processor.level?.()??-Infinity);
      });
    }
    this.wet?.handle.sample();
    this.rollSpectrum();
  }

  // The strip an approach gives a channel, by the role its bot plays (null with no approach).
  roleStrip(track){
    const plan=this.approachPlan;
    return plan?(plan.roles[track?.role||'other']||plan.roles.other):null;
  }

  // ---- the room's loudness ---------------------------------------------------
  // What listeners judge is how loud the reverb is against the mix: skilled listeners preferred it
  // 14 LU under, and at 9 LU under or wetter it was always judged too wet (De Man, McNally &
  // Reiss 2017; Pestana & Reiss 2014). The sends decide who is in the room; the returns decide
  // how loud the room is, and this holds them at the approach's wetLu -- measured, both short-term,
  // against the master.
  manageWet(){
    const plan=this.approachPlan,mixer=this.mixer;
    if(!plan||!Number.isFinite(plan.wetLu)||!mixer?.reverbReturn)return null;
    if(!this.wet){
      const sum=this.context.createGain();
      mixer.reverbReturn.connect(sum);
      this.wet={sum,room:null,handle:this.metering.tap(sum,{channels:2,keepBlocks:40,sampleMs:this.rules.sampleMs})};
    }
    if(mixer.room&&this.wet.room!==mixer.room){mixer.room.returnNode.connect(this.wet.sum);this.wet.room=mixer.room}
    const wetLufs=this.wet.handle.meter?.shortTerm?.(),mixLufs=this.master?.meter?.shortTerm?.(),aim=this.wetAim(plan);
    const whose=aim===plan.wetLu?plan.approach:`${plan.approach} at the scene's depth`;
    if(this.settling.space>this.context.currentTime)
      return {target:aim,relative:null,moved:false,because:'a scene change moved the returns; its meters are still hearing it'};
    if(!Number.isFinite(wetLufs)||!Number.isFinite(mixLufs)||mixLufs<this.rules.silenceLufs)
      return {target:aim,relative:null,moved:false,because:'the room is not measured yet'};
    const relative=Math.round((wetLufs-mixLufs)*10)/10,error=relative-aim;
    if(Math.abs(error)<this.rules.wetDeadBandLu)
      return {target:aim,relative,moved:false,because:`the reverb sits ${-relative} LU under the mix, where ${whose} wants it`};
    const stepDb=clamp(-error/2,-this.rules.wetStepDb,this.rules.wetStepDb),gain=10**(stepDb/20);
    const values={reverbReturn:clamp(mixer.settings.reverbReturn*gain,.02,1.5)};
    if(mixer.room)values.roomReturn=clamp(mixer.settings.roomReturn*gain,.02,1.5);
    mixer.setEffects(values,{seconds:this.rules.spaceRampSeconds});
    return {target:aim,relative,moved:true,stepDb:Math.round(stepDb*10)/10,
      because:`the reverb was ${-relative} LU under the mix and ${whose} wants ${-Math.round(aim*10)/10}, so its returns move ${stepDb>0?'up':'down'} ${Math.abs(stepDb).toFixed(1)} dB`};
  }
  closeWet(){
    if(!this.wet)return;
    this.wet.handle.close();
    try{this.mixer.reverbReturn.disconnect(this.wet.sum)}catch{}
    try{this.wet.room?.returnNode.disconnect(this.wet.sum)}catch{}
    this.wet=null;this.lastWet=null;
  }

  // The most recent `ms` of a channel, joined. Complete on the worklet path; on the analyser
  // path sampled rather than continuous — an analyser holds 2048 frames and is read every
  // 50 ms, so about 85% of the audio at 48 kHz is seen, which is enough to balance and to find
  // masking.
  frames(tap,ms){return tap.handle.window(ms)}

  // **One transform per sample tick, round-robin.** Masking and the pink profile both want a
  // spectrum per channel, and both used to take theirs in one burst on a six-second clock:
  // measured at 18 ms for the masking pass and 13 ms for the profile, landing on the same
  // decision, inside a `decide()` whose worst case was 33 ms — on the thread that owes the
  // audio graph its next block. A stutter.
  //
  // The transform is the expensive part and nothing needs it to be simultaneous, so it is
  // spread: each tick refreshes one channel's band energies, and with eight slots every
  // channel is 400 ms fresh. The decision passes then do arithmetic on cached numbers. Same
  // work, no burst — the same trade the channel meters make, for the same reason.
  rollSpectrum(){
    const slots=[...this.taps.values()];
    if(this.master)slots.push(this.master);
    if(!slots.length)return;
    // **And the round is paced to what consumes it, not to the sample tick.** One transform
    // every 50 ms is twenty a second, which is far more freshness than anything here reads:
    // both the masking pass and the pink trims run on `spectrumEveryMs`, so a spectrum needs
    // to be refreshed once per that period and no more. Pacing the round to finish in exactly
    // one period gives every signal a fresh spectrum before the decision that uses it, at a
    // fifteenth of the transforms — one every 750 ms with eight signals on a six-second clock.
    const ticksPerSlot=Math.max(1,
      Math.round(this.rules.spectrumEveryMs/this.rules.sampleMs/slots.length));
    this.spectrumTick=(this.spectrumTick??0)+1;
    if(this.spectrumTick<ticksPerSlot&&this.spectrumSlot>=0)return;
    this.spectrumTick=0;
    this.spectrumSlot=(this.spectrumSlot??-1)+1;
    const slot=slots[this.spectrumSlot%slots.length];
    const frames=this.spectralFrames(slot,this.rules.maskWindows);
    if(!frames)return;
    const bands=bandEnergies(frames,{sampleRate:this.context.sampleRate});
    // **The master's profile is averaged across rounds; a channel's is not.** Pink is a target
    // for the *long-term* average spectrum, and one turn of the round is four windows spread
    // over four seconds — a fair snapshot, but a snapshot. Carrying it forward with a slow
    // coefficient makes the profile describe the last half-minute or so, which is the span the
    // target is about. Masking is the opposite case: it is asked about the passage being played
    // now, so a channel's bands are replaced rather than averaged.
    if(slot!==this.master){
      slot.bands=bands;
      // Placement's own, carried across rounds (a snapshot places a part by one moment's notes), and only from rounds in
      // which the channel was sounding: the first of them taken whole, not blended into the silence of a round before
      // it (a part entering after the desk's first look at it read 5 dB quiet a round later, 3 dB two rounds later).
      const total=bands.reduce((sum,value)=>sum+value,0),held=slot.placeBands?.reduce((sum,value)=>sum+value,0)??0;
      if(!held)slot.placeBands=bands.slice();
      else if(total>held*SOUNDING_SHARE){const keep=this.place.spectrumMemory;slot.placeBands=slot.placeBands.map((value,index)=>value*keep+bands[index]*(1-keep))}
      return;
    }
    if(!slot.bands){slot.bands=bands;return}
    const keep=this.pink.profileMemory;
    for(let index=0;index<bands.length;index++)
      slot.bands[index]=slot.bands[index]*keep+bands[index]*(1-keep);
  }

  // `windows` transforms' worth of a tap, taken **evenly across** the retained window rather
  // than from the end of it. That matters: `bandEnergies` runs one transform per 4096 samples
  // of whatever it is handed, so handing it four spread windows averages over the whole four
  // seconds at a twelfth of the cost, while handing it the newest four would average over the
  // last third of a second and quietly stop being the measurement it claims to be.
  //
  // **Measured.** With the desk running: 8 main-thread tasks over 20 ms in 55 s, worst 106 ms,
  // median 88 ms. With the desk stopped: none. The bots schedule their notes from the main
  // thread, so an 88 ms stall delivers a bar's worth of notes late and in a heap — which is
  // what "occasional audio interruptions" was.
  spectralFrames(tap,windows=this.rules.spectrumWindows){
    const chunks=tap?.chunks;
    if(!chunks?.length)return null;
    const total=chunks.reduce((sum,chunk)=>sum+chunk.length,0);
    if(total<=windows*SPECTRUM_WINDOW)return this.frames(tap,this.rules.maskWindowMs);
    const joined=new Float32Array(windows*SPECTRUM_WINDOW);
    // Where each window starts, spread over the retained audio and ending at the newest.
    const span=total-SPECTRUM_WINDOW;
    for(let index=0;index<windows;index++){
      const from=windows===1?span:Math.round(span*index/(windows-1));
      this.copyFrom(chunks,from,joined,index*SPECTRUM_WINDOW,SPECTRUM_WINDOW);
    }
    return joined;
  }
  // Read `length` samples starting `from` samples into a list of chunks, without joining the
  // whole list first — joining four seconds to read a third of a second is the allocation the
  // cost fix was about.
  copyFrom(chunks,from,into,at,length){
    let seen=0,written=0;
    for(const chunk of chunks){
      if(written>=length)break;
      const start=Math.max(0,from-seen);
      if(start<chunk.length){
        const take=Math.min(chunk.length-start,length-written);
        into.set(chunk.subarray(start,start+take),at+written);
        written+=take;
      }
      seen+=chunk.length;
    }
    return written;
  }

  // One channel's loudness, from the blocks its own meter has already filtered. The same
  // gated integrated figure `channelLoudness` returns, over the same window, without putting
  // the window through the K-weighting again.
  //
  // The blocks are built from sampled audio — an analyser holds 2048 frames and is read every
  // 50 ms, so about 85% of the audio at 48 kHz is seen and a 100 ms block spans about 117 ms
  // of wall time. That approximation is the same one joining the chunks made, and it is why
  // none of this is called metering.
  tapLoudness(tap){
    if(!tap.meter.allBlocks.length)return null;
    const lufs=loudnessSummary(tap.meter.allBlocks,{sampleRate:this.context.sampleRate}).integrated;
    return Number.isFinite(lufs)?lufs:null;
  }

  // Every channel's loudness, whoever owns it — the shared measurement the duties draw on.
  measureAll(){
    const measured={};
    for(const [id,tap] of this.taps){
      const lufs=this.tapLoudness(tap);
      if(lufs!==null)measured[id]=Math.round(lufs*10)/10;
    }
    return measured;
  }
  playing(){
    return Object.entries(this.measureAll())
      .filter(([,lufs])=>lufs>this.rules.silenceLufs).map(([id])=>id);
  }

  // ---- soundcheck ------------------------------------------------------------
  //
  // Before a part is heard its fader is set from the loudness its bot plays at (public/shared/bot-loudness.js, measured
  // once: every source now sounds at its bot's built-in voice), as a sound engineer sets the channels at a soundcheck.
  // The parts expected are balanced as the level duty balances the parts it hears: each toward their average, at its
  // role's balance and the band's attention, a group (a kit's drums, the keys) as one part, the power sum of its bots;
  // toward the average the balance last found where something is playing. The balance then rides only the difference.
  // Found in étude 45 (28 September 2026): the drums entered 6 LU over the band, and the desk, which had never heard
  // them, rode them down over two bars, a move heard as a mistake. A part already heard is the balance's and is left, as
  // is a bot not measured.
  soundcheck(){
    if(!this.does('level')||!this.rules.soundcheck)return null;
    // A part is heard once the balance has heard it, or any of its channels' own meters has (a part sounding before the
    // desk's first decision); heard, it is the balance's from then on.
    const heard=new Set();
    for(const [id,tap] of this.taps){
      const part=this.soundcheckPart(id,tap.track);
      if(!this.soundchecked.has(part)&&(this.balance.heard(part)||this.tapLoudness(tap)!==null))heard.add(part);
    }
    for(const part of heard)this.soundchecked.set(part,null);
    const parts=new Map();
    const add=(id,track,channel)=>{
      const part=this.soundcheckPart(id,track),lufs=botLoudness(id);
      if(lufs===null||this.soundchecked.has(part))return;
      if(!parts.has(part))parts.set(part,{bots:new Map(),channels:[],balanceLu:this.partBalanceLu(track)+this.attentionLu(id)});
      const entry=parts.get(part);
      // A kit's drums are one bot's: its figure is the kit's, counted once.
      entry.bots.set(String(id).split('/')[0],lufs);if(channel)entry.channels.push(id);
    };
    for(const [id,tap] of this.taps)if(this.owns(id))add(id,tap.track,true);
    // A kit's bus, before any of its drums has a channel of its own (each is given one at its first hit: audio.js
    // kitTrack): its bot's figure is its part's, which each drum then joins at (trackMade).
    for(const [id,track] of this.mixer?.tracks??[])if(track.kit&&this.owns(id))add(id,track,false);
    if(!parts.size)return null;
    const expected=[...parts].map(([part,entry])=>[part,powerSumDb([...entry.bots.values()])-entry.balanceLu]);
    let target=Number.isFinite(this.last?.level?.target)?this.last.level.target:expected.reduce((sum,[,lufs])=>sum+lufs,0)/expected.length;
    target-=this.withinReach(Object.fromEntries(expected.map(([part,lufs])=>[part,target-lufs])));
    const set={};
    for(const [part,lufs] of expected){
      const db=this.balance.preset(part,target-lufs);
      this.soundchecked.set(part,{expectedLufs:round(lufs),db:round(db)});
      for(const id of parts.get(part).channels){this.setPartLevel(id,part);set[id]=round(db)}
    }
    return {target:round(target),parts:Object.fromEntries(expected.map(([part])=>[part,this.soundchecked.get(part)])),set};
  }
  // The part a channel is balanced as: its group's bus by its role, where the submix duty groups it (before the
  // duty has routed it: submix.js), else itself.
  soundcheckPart(id,track){
    // Without the duty, or on a mixer that makes no buses, every channel is a part of its own (manageSubmixes).
    if(!this.does('submix')||typeof this.mixer?.bus!=='function')return id;
    const bus=this.groupOf(id);if(bus!==null)return bus;
    // A kit is drums before it has played anything that says so.
    const role=track?.role??this.mixer.tracks.get(track?.route)?.role??(track?.kit?'drums':null),group=submixGroup(role,this.submix);
    return group===null?id:submixBus(group,this.submix);
  }
  // How far a part's fader can raise it (dB): a channel's by its travel and its place's trim, a group's by the member with
  // the least left, net of its place in the group; Infinity where no channel of it is tapped yet (a kit before its drums).
  partReach(part){
    const own=id=>{const tap=this.taps.get(id);return tap&&tap.base>0?gainDb(this.rules.maxDry/tap.base)-(this.placed.get(id)?.trimDb??0):Infinity};
    if(this.taps.has(part))return own(part);
    const members=[...this.taps].filter(([id,tap])=>this.soundcheckPart(id,tap.track)===part).map(([id])=>id);
    return members.length?Math.min(...members.map(id=>own(id)-(this.groupBalances.get(part)?.gainOf(id)??0))):Infinity;
  }
  // Where the balance keeps its aims within reach (boundedAims), the dB every part in `levels` (part -> dB) comes down so
  // that none is beyond its reach: the soundcheck and the attention's moves set as the balance will then hold them.
  withinReach(levels){
    if(!this.rules.boundedAims)return 0;
    return Math.max(0,...Object.entries(levels).map(([part,db])=>db-this.partReach(part)));
  }
  // A channel set at once to the level its part stands at: the part's own balance, and the channel's within its group.
  setPartLevel(id,part,seconds=this.rules.soundcheckSeconds){
    const tap=this.taps.get(id);if(!tap)return null;
    const db=part===id?this.balance.gainOf(id):this.balance.gainOf(part)+(this.groupBalances.get(part)?.gainOf(id)??0);
    this.change(id,{dry:this.dryFor(tap,id,db)},seconds);
    tap.levelDb=db;return db;
  }
  // A kit's drum set within its kit before it is heard, as an engineer sets a kit's channels at the soundcheck: at the
  // gain the kit's balance would find for it (groupBalance: each drum toward the kit's average, at its place in the kit,
  // SUBMIX.kitLu, the kick and the snare leading), from how loud each of the kit's drums plays (public/shared/
  // kit-loudness.js, measured once, by the channel's source where it names one, else its drummer's). The balance then
  // rides only what differs. Found in étude 45 (28 September 2026): each drum joined its kit at the kit's level, the
  // kit's balance first heard it two seconds later, and the drums dropped 7 dB into the next bar. The gain, or null.
  kitPreset(id,track,part){
    if(!track?.piece||part===id)return null;
    const kit=kitLoudnessOf(id,track.source??null);
    if(!kit||!Number.isFinite(kit[track.piece]))return null;
    const own=drum=>kit[drum]-(this.submix.kitLu[drum]??0),drums=Object.keys(kit);
    return this.groupBalance(part).preset(id,drums.reduce((sum,drum)=>sum+own(drum),0)/drums.length-own(track.piece));
  }
  // A channel the mixer has just made (its onTrack): tapped, and set before it sounds, at the level its part stands at
  // where the part has one (a kit's drum given its channel at its first hit joins its kit's), else by the soundcheck.
  // Taken at the end of the turn that made it, once its maker has given it its role and its route (audio.js kitTrack),
  // and before any of its audio is rendered.
  trackMade(id){
    queueMicrotask(()=>{
      const track=this.mixer?.tracks.get(id);
      if(!this.running||!track||track.bus)return;
      this.tapTracks();
      if(!this.does('level')||!this.rules.soundcheck||!this.owns(id)||!this.taps.has(id))return;
      const part=this.soundcheckPart(id,track),within=this.kitPreset(id,track,part);
      // Said with the next decision, as every move this desk makes is.
      if(this.balance.gains.has(part)){const db=this.setPartLevel(id,part);(this.pending??={}).joined={...this.pending.joined,[id]:{part,db:round(db),...(within===null?{}:{within:round(within)})}}}
      else{const check=this.soundcheck();if(check)(this.pending??={}).soundcheck=check}
    });
  }

  // ---- level -----------------------------------------------------------------
  balanceFaders(){
    const loudnesses={},measured={},groups=new Map(),dying=[];
    // The spectral weighting, if there is a master to measure it on. A channel crowding an
    // octave that is already full is reported to the balance as louder than it measured, and
    // the balance's own rules do the rest — see PINK.
    const trims=this.pinkTrims();
    for(const [id,tap] of this.taps){
      const lufs=this.tapLoudness(tap);
      if(lufs===null)continue;
      // Measured is what the desk shows; weighted is what it decides on. Displaying the
      // weighted figure would be showing a loudness nothing is actually at.
      // An approach balances parts at their own loudness against the mix rather than all alike: a
      // channel it wants 5 LU above another is reported 5 LU quieter than it is, and the balance does
      // the rest (lead -2.7, drums -7.5, bass -8.5 LU in the studio approach: De Man et al. 2014).
      // And what the channel puts into the mix rather than what its fold-down reads: metered as (L+R)/2, a correlated
      // stereo channel reads 3 dB under what it sends to the mix and a wide one more, where a mono one reads what it
      // sends (placement.js StereoStats.centreDb).
      // (And forward or back by the band's attention: setAttention.)
      // Dying away since the last decision (dyingLu): heard at what it last sounded at, above the silence floor.
      const peakDb=gainDb(tap.handle.peakOver(this.rules.windowMs/MS_PER_SECOND)),last=tap.sounding;tap.sounding={lufs,peakDb};
      const dies=Boolean(last)&&lufs>this.rules.silenceLufs&&Number.isFinite(tap.soundedLufs)
        &&lufs<=last.lufs-this.rules.dyingLu&&peakDb<=last.peakDb-this.rules.dyingLu;
      if(dies)dying.push(id);else tap.soundedLufs=lufs;
      const heard=dies?tap.soundedLufs:lufs;
      const inMix=heard+this.stereoDb(tap),weighted=inMix-(trims[id]||0),balanceLu=this.partBalanceLu(tap.track)+this.attentionLu(id);
      measured[id]=Math.round((lufs+this.stereoDb(tap))*10)/10;
      // A channel in a group is balanced within it, and the group as one part (submix.js).
      const bus=this.groupOf(id);
      if(bus===null){loudnesses[id]=weighted-balanceLu;continue}
      if(!groups.has(bus))groups.set(bus,[]);
      groups.get(bus).push({id,lufs:weighted,balanceLu,withinLu:this.withinLu(tap.track)});
    }
    // Each group: its channels toward their own average, as every channel was before, and then the group, as the power
    // sum of its channels where that puts them, reported at its loudest channel's role loudness.
    const within={};
    for(const [bus,members] of groups){
      // (A member resting in its group, restingLu under its loudest, is left out of it, as silence is: not given as a
      // number, since the balance would read null as 0 LUFS.)
      const ownLu=member=>member.lufs-member.withinLu,loudest=Math.max(...members.map(ownLu));
      const sounding=members.filter(member=>ownLu(member)>=loudest-this.rules.restingLu);
      const inner=this.groupBalance(bus),decision=inner.update(Object.fromEntries(sounding.map(member=>[member.id,ownLu(member)])),{seconds:this.rules.windowMs/MS_PER_SECOND});
      // Each channel as loud as its fader can make it: one at the end of its travel gives no more, whatever the balance
      // asks, and counted at what it asks it would have its group heard louder than it is.
      const outer=this.balance.gainOf(bus),heard=member=>this.heardDb(member.id,outer+inner.gainOf(member.id))-outer;
      const group=groupLoudness(members.map(member=>({...member,gainDb:heard(member)})),{silenceLufs:this.balance.options.silenceLufs});
      within[bus]={members:members.map(member=>member.id),target:decision.target,detail:decision.detail??{},
        ...(group?{lufs:round(group.lufs),balanceLu:group.balanceLu,loudest:group.loudest}:{})};
      if(group)loudnesses[bus]=group.lufs-group.balanceLu;
    }
    // The average is computed over everyone playing, including channels this desk does not
    // own — see the note on the remit above.
    // How far each part's fader can raise it, where the balance is to keep its aims within reach (boundedAims): a
    // channel's by its travel and its place's trim, a group's by the member with the least left, net of its place in the
    // group.
    const reach=this.rules.boundedAims?Object.fromEntries(Object.keys(loudnesses).map(id=>[id,this.partReach(id)])):null;
    const decision=this.balance.update(loudnesses,{seconds:this.rules.windowMs/MS_PER_SECOND,...(reach?{reach}:{})});
    const applied={};
    const move=(id,db,extra={})=>{
      const tap=this.taps.get(id);
      if(!tap||!this.owns(id))return;
      const dry=this.dryFor(tap,id,db);
      this.change(id,{dry},this.rules.rampSeconds);
      tap.levelDb=db;
      applied[id]={db:Math.round(db*100)/100,dry:Math.round(dry*1000)/1000,...extra};
    };
    // (A voice's feature a floor: a voice already that far above everything else sounding together is never brought
    // down to it -- Op. 3.24's voice, 4.5 LU over its band, had been lowered to the lead vocal's 0.6.)
    const featured=this.voiceAboveFeature(measured);
    for(const [id,db] of Object.entries(decision.moves))if(!groups.has(id)&&!(featured.has(id)&&db<(this.taps.get(id)?.levelDb??0)))move(id,db);
    // A group's channels at its move and their own within it, resting ones too, so the group moves as one.
    for(const bus of groups.keys())for(const id of this.submixes.membersOf(bus)){
      const db=this.levelDb(id);
      if(Math.abs(db-(this.taps.get(id)?.levelDb??0))>=this.submix.levelEpsilonDb)move(id,db,{group:bus});
    }
    // Who is playing, by the balance's own floor: a group's channels each by their own loudness.
    const silence=this.balance.options.silenceLufs;
    const active=[...(decision.active??[]).filter(id=>!groups.has(id)),
      ...[...groups.values()].flat().filter(member=>member.lufs>silence).map(member=>member.id)];
    return {measured,applied,trims,profile:this.lastProfile,
      target:decision.target,detail:decision.detail??{},
      active,...(dying.length?{dying}:{}),...(groups.size?{groups:within}:{}),reason:decision.reason??null};
  }
  // The loudness a channel's part is balanced at against the others, in LU (mix-approaches.js balanceLu): its role's in
  // the approach, if one is set; grouped, without one, the measured balance (the studio approach's roles: the lead 2.7 LU
  // under the mix, the total drums 7.5, the bass 8.5, the rest 10), since groups are what it was measured on; a channel
  // alone, without one, 0: every part alike, as the desk always balanced.
  // (While a singing voice is in the band, an instrumental lead balances where the band's keys do: roleBalanceLu.)
  // (A voice's own: featured against everything else sounding, vocalBalanceLu.)
  partBalanceLu(track){
    if(track?.role==='vocal')return this.vocalBalanceLu();
    return this.ownBalanceLu(track);
  }
  ownBalanceLu(track){
    const roles=this.approachPlan?.roles??(this.does('submix')&&this.submixes?STUDIO_ROLES:null);
    return roles?(roleBalanceLu(roles,track?.role,this.voiced())??0):0;
  }
  // The voices' channels already at least their feature above everything else sounding together, as measured (in the
  // mix: `measured`, channel -> LUFS): their faders held where the balance would bring them down. -> Set of channels.
  voiceAboveFeature(measured){
    const silence=this.balance?.options?.silenceLufs??-Infinity,voices=[],others=[];
    for(const [id,tap] of this.taps){const lufs=measured[id];if(!Number.isFinite(lufs)||lufs<=silence)continue;(tap.track?.role==='vocal'?voices:others).push([id,lufs])}
    if(!voices.length||!others.length)return new Set;
    const sum=list=>10*Math.log10(list.reduce((total,[,lufs])=>total+10**(lufs/10),0)),feature=voiceFeatureLu(voices.length);
    return sum(voices)-sum(others)>=feature?new Set(voices.map(([id])=>id)):new Set;
  }
  // A voice's parts' place in the balance (mix-approaches.js VOICE_FEATURE): together, its feature above (a solo voice)
  // or under (a choir) every other part sounding together, each of its parts an equal share -- whatever the approach
  // balances the rest at, so that a voice among an orchestra's thirty channels is not balanced as one of them, a
  // thirtieth of the mix. Its singers counted by channel, its parts by the part each is balanced as (a group's bus).
  vocalBalanceLu(){
    const silence=this.balance?.options?.silenceLufs??-Infinity,others=new Map,voices=new Set;let singers=0;
    for(const [id,tap] of this.taps){
      const lufs=this.tapLoudness(tap);if(lufs===null||lufs<=silence)continue;
      const part=this.soundcheckPart(id,tap.track);
      if(tap.track?.role==='vocal'){voices.add(part);singers++}else if(!others.has(part))others.set(part,this.ownBalanceLu(tap.track));
    }
    if(!others.size)return 0;
    const rest=10*Math.log10([...others.values()].reduce((sum,lu)=>sum+10**(lu/10),0));
    return rest+voiceFeatureLu(Math.max(1,singers))-10*Math.log10(Math.max(1,voices.size));
  }
  // The band's attention (0f's model: public/shared/attention.js, /broadcast/attention): each part's share against its
  // typical share moves its balance, the soloist forward and the rest back, by 10 log10(share / typical) LU, within
  // ATTENTION_REACH_LU either way (ours). `shares` and `typical` (typical claims, dB) are by bot instance; a channel is
  // its instance's ('bot:<instance>' or 'bot:<instance>/<piece>', a split kit's pieces all the drummer's). Null clears.
  setAttention(attention){
    const before=this.attention?.offsets??{};
    if(!attention){this.attention=null;this.shiftByAttention(before,{});return null}
    const typical=Object.entries(attention.typical??{}).filter(([,db])=>Number.isFinite(db)),total=typical.reduce((sum,[,db])=>sum+10**(db/10),0);
    const expected=Object.fromEntries(typical.map(([instance,db])=>[instance,total>0?10**(db/10)/total:0])),offsets={};
    for(const [instance,share] of Object.entries(attention.shares??{}))
      if(share>0&&expected[instance]>0)offsets[instance]=Math.max(-ATTENTION_REACH_LU,Math.min(ATTENTION_REACH_LU,10*Math.log10(share/expected[instance])));
    const shifted=this.shiftByAttention(before,offsets);
    this.attention=Object.freeze({soloist:attention.soloist??null,offsets:Object.freeze(offsets),...(Object.keys(shifted).length?{shifted:Object.freeze(shifted)}:{})});
    return this.attention;
  }
  // The band's attention moves the parts at the section's downbeat, together and at once, as a band's balance changes
  // when a soloist steps forward: announced a phrase ahead and landed on its bar (the render hands it to the desk there),
  // a move several LU large. The level duty's approach would ride it in over several decisions, heard as a mistake
  // (étude 45: the drums, entering under a melody's solo 6 LU under their role, ridden down over two bars). Each part the
  // balance has a gain for moves by the change in its offset; one not yet set takes its offset from the soundcheck.
  shiftByAttention(before,after){
    if(!this.does('level')||!this.rules.attentionAtOnce)return {};
    const deltas=new Map(),instance=id=>String(id).replace(/^bot:/,'').split('/')[0];
    const consider=(id,track)=>{
      const part=this.soundcheckPart(id,track);
      if(deltas.has(part)||!(this.balance.gains.has(part)||this.balance.heard(part)))return;
      deltas.set(part,(after[instance(id)]??0)-(before[instance(id)]??0));
    };
    for(const [id,tap] of this.taps)if(this.owns(id))consider(id,tap.track);
    for(const [id,track] of this.mixer?.tracks??[])if(track.kit&&this.owns(id))consider(id,track);
    // The balance aims each part at the average of the parts playing, which the offsets move too: each part moves by its
    // own change less the average change of those playing, so the parts move against one another and the band's level
    // stays where it was (moved by the offsets alone, every fader would sit off its aim by that average, and be ridden).
    const playing=(this.balance.lastActive??[]).filter(part=>deltas.has(part));
    let mean=playing.length?playing.reduce((sum,part)=>sum+deltas.get(part),0)/playing.length:0;
    // And within reach, where the balance keeps its aims there: every part down by what the one furthest beyond lacks.
    mean+=this.withinReach(Object.fromEntries([...deltas].map(([part,delta])=>[part,this.balance.gainOf(part)+delta-mean])));
    const shifted={};
    for(const [part,delta] of deltas){
      // Its measurements as the balance would now weigh them (a part moved forward reads that much quieter against its
      // balance), then its gain where the balance now aims it.
      this.balance.reframe(part,-delta);
      const move=delta-mean;if(Math.abs(move)<1e-9)continue;
      this.balance.shift(part,move);shifted[part]=round(move);
      for(const [id,tap] of this.taps)if(this.owns(id)&&this.soundcheckPart(id,tap.track)===part)this.setPartLevel(id,part,this.rules.attentionSeconds);
    }
    return shifted;
  }
  attentionLu(id){return this.attention?.offsets?.[String(id).replace(/^bot:/,'').split('/')[0]]??0}
  // Whether a singing voice (a channel whose role is vocal) is in the band.
  voiced(){for(const tap of this.taps.values())if(tap.track?.role==='vocal')return true;return false}
  // The side a kit's drums are heard from (kit-channels.js KIT_PERSPECTIVES: 1 the drummer's seat, -1 the audience's)
  // and how far back they stand at the least: what this desk's rules say, else the approach's kit, else the defaults
  // (placement.js PLACEMENT: the drummer's seat, close).
  kitPerspective(){return perspectiveSign(this.placeGiven.perspective??this.approachPlan?.kit?.perspective??this.place.perspective)}
  kitDistance(){return clamp(Number(this.placeGiven.kitDistance??this.approachPlan?.kit?.distance??this.place.kitDistance)||0,0,1)}
  // A channel's loudness within its group, in LU, as the group's balance of its own channels reads it: a kit's drum at
  // its own (submix.js SUBMIX.kitLu: the kick and the snare leading the kit), any other channel alike.
  withinLu(track){return track?.piece?this.submix.kitLu[track.piece]??0:0}
  // What a balance of `db` gives a channel once its fader's travel is counted (dryFor's limits), in dB.
  heardDb(id,db){
    const tap=this.taps.get(id);
    if(!tap||!(tap.base>0))return db;
    return gainDb(this.dryFor(tap,id,db)/tap.base)-(this.placed.get(id)?.trimDb??0);
  }
  // The bus a channel is balanced in, or null where it is a part of its own.
  groupOf(id){return this.does('submix')?this.submixes?.busOf(id)??null:null}
  // A group's balance of its own channels, which loosens and tightens with the ensemble's (the dynamics duty's).
  groupBalance(bus){
    if(!this.groupBalances.has(bus))this.groupBalances.set(bus,new FaderBalance({options:this.balance.options}));
    const balance=this.groupBalances.get(bus);
    // A kit's drums set once within their kit and held (kitSetOnce), as an engineer sets a kit's balance at the soundcheck.
    const kit=this.rules.kitSetOnce&&this.submixes?.membersOf(bus).some(id=>this.mixer.tracks.get(id)?.piece);
    balance.options=kit?{...this.balance.options,settleOnce:true}:this.balance.options;
    return balance;
  }
  // A channel's balance, in dB: its own, or its group's and its own within the group.
  levelDb(id){
    const bus=this.groupOf(id);
    return bus===null?this.balance.gainOf(id):this.balance.gainOf(bus)+(this.groupBalances.get(bus)?.gainOf(id)??0);
  }

  // ---- punch -----------------------------------------------------------------
  //
  // The drums with punch (punch.js): the kick's and the snare's own compressors (a whole kit's, gentler), the drums'
  // bus's glue and parallel compression, and the bass and the chords stepping back under the kick and the snare. Each
  // built once and then steered: its threshold toward the reduction it should make on the hits, its make-up toward what
  // it takes away, measured before and after it; each drum's boost backed off while the mix's peaks stand further over
  // its loudness than can be delivered (dynamics, read just before).
  managePunch(active){
    // The scene's attack legibility scales each drum's shaping: none asked, no punch (shared/mix-intention.js).
    const legibility=this.intention?.attackLegibility??null;
    const scaled=scaledPunch(punchPlan(this.approachPlan?.punch,this.punchChoices),legibility===null?null:punchScale(legibility));
    // The mix's headroom: each drum's boost backed off by how far the mix's peaks stand past what can be delivered.
    const crestDb=this.lastDynamics?.plrDb,deliverableDb=deliverableCrestDb(this.dynamics);
    if(scaled)this.punchBackoff=nextBackoff(this.punchBackoff??0,crestDb,deliverableDb,Math.max(0,...Object.values(scaled.drums).map(drum=>drum.boost)),scaled);
    const plan=backedOff(scaled,this.punchBackoff);
    if(!plan){
      const undone=this.unpunch();
      return {built:[],steered:{},ducks:{},undone,because:legibility===0?'no punch: the scene asks for no attack legibility'
        :'no punch: the approach leaves the drums as the players play them'};
    }
    if(typeof this.mixer?.tracks?.get!=='function')return {built:[],steered:{},ducks:{},because:'no mixer to punch'};
    const built=[],steered={};
    for(const [id,track] of this.mixer.tracks){
      const role=punchRole(track,id,plan);
      if(!role||typeof track.addInsert!=='function'||(role!=='bus'&&!this.owns(id)))continue;
      const record=this.punched.get(id);
      if(!record){this.buildPunch(id,track,role,plan);built.push(id)}
      else if(record.ready)steered[id]=this.steerPunch(id,track,record,plan,active);
    }
    for(const [id,record] of [...this.punched])if(!this.mixer.tracks.has(id)){record.post?.close();record.pre?.close();this.punched.delete(id)}
    const ducks=this.manageDucks(plan);
    this.applier?.setPunched?.([...this.punched.keys()]);
    const drums=[...this.punched].filter(([,record])=>record.role!=='bus').map(([id,record])=>record.role==='kit'?id:record.role);
    const backoff=this.punchBackoff>0?{backoffDb:round(this.punchBackoff)}:{};
    return {built,steered,ducks,...backoff,because:!this.punched.size?'no drums to punch yet'
      :`punch: ${drums.length?`${[...new Set(drums)].join(', ')} shaped on their own, the attack raised and the ring shortened`:'the drums whole'}`
        +`${this.punched.has(plan.drumsBus)?', the drums\u2019 bus glued with a hard-compressed copy under it':''}`
        +`${Object.keys(ducks).length?`, ${Object.values(ducks).map(duck=>`${duck.role} under the ${duck.from}`).join(', ')}`:''}`
        +(this.punchBackoff>0?`; each drum's boost backed off ${round(this.punchBackoff)} dB for the mix's headroom (its peaks `
          +`${fmt(crestDb,'dB')} over its loudness, ${deliverableDb} dB deliverable)`:'')};
  }
  buildPunch(id,track,role,plan){
    const settings=role==='bus'?[plan.glue,plan.parallel]:[plan.drums[role]];
    const record={role,inserts:[],processors:[],thresholds:settings.map(()=>plan.startThreshold),reductions:settings.map(()=>0),
      shapes:settings.map(setting=>({boost:setting.boost,sustain:setting.sustain,aim:punchAim(setting)})),
      swings:settings.map(()=>0),levels:settings.map(()=>-Infinity),makeup:0,ready:false,post:null,pre:null,error:null};
    this.punched.set(id,record);
    const meter=node=>this.metering.tap(node,{channels:1,keepBlocks:Math.ceil(this.rules.windowMs/100),
      chunkWindowMs:this.rules.maskWindowMs,peakWindowMs:this.rules.windowMs,sampleMs:this.rules.sampleMs});
    record.queue=(async()=>{
      for(const [at,setting] of settings.entries()){
        const insertId=await track.addInsert('dynamics',setting.mode==='transient'
          ?{mode:'transient',boost:setting.boost,sustain:setting.sustain,aim:punchAim(setting),attack:setting.attack,release:setting.release,at}
          :{mode:'compress',ratio:setting.ratio,attack:setting.attack,release:setting.release,knee:setting.knee,threshold:plan.startThreshold,mix:setting.mix??1,makeup:0,at});
        record.inserts.push(insertId);record.processors.push(track.inserts.get(insertId)?.processor);
      }
      // A drum's loss is made up by the balance, which measures its channel after its inserts; a bus, whose own
      // processing the balance does not hear (it measures the bus's channels), is metered before and after it.
      if(role==='bus'){record.post=meter(record.processors.at(-1).output);record.pre=meter(track.input)}
      record.ready=true;
    })().catch(error=>{record.error=error.message});
    return record;
  }
  steerPunch(id,track,record,plan,active){
    const settings=record.role==='bus'?[plan.glue,plan.parallel]:[plan.drums[record.role]];
    record.processors.forEach((processor,index)=>{
      if(!processor?.reduction)return;
      const swing=record.swings[index],loudest=record.levels[index];
      record.swings[index]=0;record.levels[index]=-Infinity;
      // A transient designer is not steered: it answers to each hit's shape, whatever its level, and to how far the
      // hits' attacks already stand over their bodies (its aim: dynamics-worklet.js). Its shaping follows the plan when
      // the scene's attack legibility moves it.
      if(settings[index].mode==='transient'){
        record.reductions[index]=swing;
        const height=processor.height?.();if(Number.isFinite(height)){record.heights??=[];record.heights[index]=height}
        const {boost,sustain}=settings[index],aim=punchAim(settings[index]),applied=record.shapes?.[index];
        if(applied&&(applied.boost!==boost||applied.sustain!==sustain||applied.aim!==aim)){processor.set({boost,sustain,aim},{seconds:this.rules.rampSeconds});record.shapes[index]={boost,sustain,aim}}
        return;
      }
      // Only when the drum sounded near its threshold, so a bar's rest is not read as too little reduction.
      if(!(loudest>=record.thresholds[index]-plan.activeMarginDb))return;
      record.reductions[index]+=(swing-record.reductions[index])*plan.meterApproach;
      const next=steerThreshold(record.thresholds[index],record.reductions[index],settings[index].targetDb,plan,settings[index].ratio);
      if(next!==record.thresholds[index]){record.thresholds[index]=next;processor.set({threshold:next},{seconds:this.rules.rampSeconds})}
    });
    // A bus's make-up, its fader: what its compressors take away, the loudness before them less after.
    const pre=record.pre?this.tapLoudness(record.pre):null,post=record.post?this.tapLoudness(record.post):null;
    if(pre!==null&&post!==null&&pre>this.rules.silenceLufs){
      const makeup=nextMakeup(record.makeup,pre-post,plan);
      if(Math.abs(makeup-record.makeup)>=this.submix.levelEpsilonDb){
        record.makeup=makeup;
        this.changeTrack(id,track,{dry:10**(makeup/AMPLITUDE_DB)},this.rules.rampSeconds);
      }
    }
    const report={thresholds:[...record.thresholds],reductionsDb:record.reductions.map(value=>round(value)),makeupDb:round(record.makeup),
      ...(record.boosts?{boostsDb:record.boosts.map(value=>round(value))}:{}),
      // A shaper's: how far its hits' attacks stand over their bodies, its aim, and the most it may add now.
      ...(record.heights?{heightsDb:record.heights.map(value=>round(value)),aimsDb:record.shapes.map(shape=>round(shape.aim)),
        mostDb:record.shapes.map(shape=>round(shape.boost))}:{})};
    // A shaper's boost is the most it added since the last decision.
    if(record.boosts)record.boosts=record.boosts.map(()=>0);
    return report;
  }
  // The parts that step back under a drum: each duck keyed by the drum's own channel (a split kit's), on each channel of
  // the roles it names, unless the approach has a sidechain of its own.
  manageDucks(plan){
    const wanted=new Map();
    if(!this.approachPlan?.sidechain)for(const spec of plan.ducks){
      const from=[...this.mixer.tracks].find(([,track])=>track.piece===spec.from)?.[0];
      if(!from)continue;
      for(const [id,track] of this.mixer.tracks)
        if(!track.bus&&!track.piece&&spec.to.includes(track.role)&&this.owns(id)&&typeof track.addInsert==='function')wanted.set(`${id}<${spec.from}`,{id,track,spec,from});
    }
    for(const [key,duck] of [...this.ducked])if(!wanted.has(key)){this.removeDuck(duck);this.ducked.delete(key)}
    const out={};
    for(const [key,{id,track,spec,from}] of wanted){
      let duck=this.ducked.get(key);
      if(!duck){
        duck={id,track,from,insertId:null};this.ducked.set(key,duck);
        track.addInsert('dynamics',{mode:'duck',range:spec.rangeDb,attack:spec.attack,release:spec.release,threshold:spec.threshold,ratio:spec.ratio,keyFrom:from})
          .then(insertId=>{duck.insertId=insertId}).catch(error=>{duck.error=error.message});
      }else if(duck.insertId&&duck.from!==from){this.mixer.keyInsert(id,duck.insertId,from);duck.from=from}
      out[key]={role:track.role,from:spec.from,rangeDb:spec.rangeDb};
    }
    return out;
  }
  removeDuck(duck){
    if(duck.insertId)try{duck.track.inserts.remove(duck.insertId)}catch{/* its channel has gone */}
    for(const link of [...(this.mixer.keys??[])])if(link.trackId===duck.id&&link.insertId===duck.insertId){link.filter?.disconnect();this.mixer.keys.delete(link)}
  }
  // What a masking permission keeps (shared/mix-intention.js keep: ['attacks']): the masker may cover the masked part, but
  // steps back a few dB as that part strikes, keyed from its own channel, so its attacks stay exposed. The punch duty's
  // ducks, from any part to any other the permissions name.
  manageKeptAttacks(){
    const wanted=new Map(),choices=MIX_INTENTION.keptAttack;
    for(const permission of this.permissions)if(!permission.fuse&&permission.keep?.includes('attacks'))
      for(const masker of this.channelsNamed(permission.masker))for(const masked of this.channelsNamed(permission.masked)){
        const track=this.mixer?.tracks?.get(masker);
        if(masker!==masked&&track&&!track.bus&&this.owns(masker)&&typeof track.addInsert==='function')wanted.set(`${masker}<${masked}`,{id:masker,track,from:masked});
      }
    for(const [key,duck] of [...this.keptAttacks])if(!wanted.has(key)){this.removeDuck(duck);this.keptAttacks.delete(key)}
    const out={};
    for(const [key,{id,track,from}] of wanted){
      if(!this.keptAttacks.has(key)){
        const duck={id,track,from,insertId:null};this.keptAttacks.set(key,duck);
        track.addInsert('dynamics',{mode:'duck',range:choices.rangeDb,attack:choices.attack,release:choices.release,threshold:choices.threshold,ratio:choices.ratio,keyFrom:from})
          .then(insertId=>{duck.insertId=insertId}).catch(error=>{duck.error=error.message});
      }
      out[key]={masker:id,keeps:from,rangeDb:choices.rangeDb};
    }
    return out;
  }
  // Everything punch built taken out: its inserts, its meters, a bus's make-up, its ducks. Returns the channels undone.
  unpunch(){
    const undone=[...this.punched.keys()];
    for(const [id,record] of this.punched){
      record.post?.close();record.pre?.close();
      const track=this.mixer?.tracks?.get(id);
      if(track)for(const insertId of record.inserts)try{track.inserts.remove(insertId)}catch{/* already out */}
      if(track&&record.role==='bus'&&record.makeup)this.changeTrack(id,track,{dry:1},this.rules.rampSeconds);
    }
    this.punched.clear();
    for(const duck of this.ducked.values())this.removeDuck(duck);
    this.ducked.clear();
    this.applier?.setPunched?.([]);
    return undone;
  }

  // ---- submix ----------------------------------------------------------------
  //
  // Each channel this desk owns into its group's bus as its role becomes known (submix.js); an approach's bus strip, if
  // one is set, lands on its bus by name (public/mix-approach.js).
  manageSubmixes(){
    if(typeof this.mixer?.bus!=='function')return {groups:{},moved:{},because:'this mixer has no buses, so every channel is a part of its own'};
    this.submixes??=new Submixes(this.mixer,{choices:this.submix});
    const moved=this.submixes.update({owns:id=>this.owns(id)}),groups=this.submixes.groups();
    for(const bus of [...this.groupBalances.keys()])if(!groups[bus])this.groupBalances.delete(bus);
    const named=Object.entries(groups).map(([bus,ids])=>`${bus.slice(this.submix.prefix.length)} ${ids.length}`);
    return {groups,moved,because:named.length
      ?`the band in ${named.length} group${named.length===1?'':'s'} (${named.join(', ')}), each balanced as one part and`
        +` each on a bus of its own`
      :'no channel has a group yet: its role is not known'};
  }

  // ---- frequency -------------------------------------------------------------
  unmask(active){
    // The spectra are already there: `rollSpectrum` refreshed one per sample tick. A channel
    // that has not had its turn yet simply does not take part in this pass.
    const channels={},energies={};
    for(const id of active){
      const tap=this.taps.get(id);
      if(!tap?.bands)continue;
      channels[id]=true;energies[id]=tap.bands;
    }
    if(Object.keys(channels).length<2)return {moves:[],why:'masking needs two channels'};
    const moves=unmaskingMoves(channels,{sampleRate:this.context.sampleRate,
      protect:[...this.protect],energies,permissions:this.permittedPairs(),fusion:this.intention?.intentionalFusion??null});
    const applied=[];
    for(const move of moves){
      const tap=this.taps.get(move.id);
      // The cut lands on the *masker*, which may be a channel another desk owns. It is theirs
      // to make, not this one's.
      if(!tap?.eq||!this.owns(move.id))continue;
      const filter=tap.eq.bands[move.band];
      if(!filter)continue;
      const at=this.context.currentTime;
      // A ramp, never a set: this bot does not set values, and a filter that jumps is heard
      // as a click before it is heard as an EQ.
      filter.frequency.linearRampToValueAtTime(move.hz,at+this.rules.eqRampSeconds);
      filter.Q.linearRampToValueAtTime(move.q,at+this.rules.eqRampSeconds);
      filter.gain.linearRampToValueAtTime(move.gainDb,at+this.rules.eqRampSeconds);
      tap.eqDb[move.band]=move.gainDb;
      applied.push({id:move.id,band:move.band,hz:move.hz,
        gainDb:move.gainDb,because:move.because,masked:move.masked});
    }
    return {moves:applied,why:null};
  }

  // ---- space -----------------------------------------------------------------
  //
  // Reverb send by how full the room is. Ours, and the shape is the one Dugan's sharing has:
  // the send falls as the square root of the number of players, so the summed reflected energy
  // stays about where a soloist's was instead of growing with the band.
  // How full the room is, held and averaged rather than counted. A bot resting for a bar has
  // not left, and the number that sets the send should change at the speed a room fills, not at
  // the speed a bot phrases.
  holdPresence(active){
    for(const id of active)this.presentUntil.set(id,this.elapsedMs+this.rules.holdMs);
    for(const [id,until] of [...this.presentUntil])
      if(until<this.elapsedMs||!this.taps.has(id))this.presentUntil.delete(id);
  }
  roomSize(active){
    this.holdPresence(active);
    const present=this.presentUntil.size;
    this.counts.push(present);
    while(this.counts.length>this.rules.countWindow)this.counts.shift();
    const mean=this.counts.reduce((total,value)=>total+value,0)/this.counts.length;
    return {present,mean:Math.max(1,mean),
      held:[...this.presentUntil.keys()].filter(id=>!active.includes(id))};
  }

  manageSpace(active){
    const room=this.roomSize(active);
    const share=clamp(this.rules.soloSend/Math.sqrt(room.mean),
      this.rules.minSend,this.rules.maxSend);
    const wanted=Math.round(share*1000)/1000;
    // **The gate is on the target, not on the writing.** A send that follows every change in
    // the room is heard as an effect being adjusted rather than as a room, so the target only
    // moves when it has somewhere to go. But every channel is then brought *to* that target,
    // including one that joined after it was set — gating the writing instead left four of
    // five channels on a send of zero forever, because they were not in the room on the one
    // decision that happened to move.
    const moved=this.sentShare===null
      ||Math.abs(wanted-this.sentShare)>=this.rules.sendDeadBand;
    if(moved)this.sentShare=wanted;
    const target=this.sentShare;
    const applied={};
    for(const id of this.taps.keys()){
      if(!this.owns(id))continue;
      const tap=this.taps.get(id);
      const now=this.reverbSend?null:tap.track.settings.reverb;
      // An approach weights the share by what the channel is: no reverb on the bass, less on the
      // kit than on the pads (Pestana & Reiss 2014: no kick or bass sent). And placement by how far
      // back the channel stands: 12 dB of send from the front to the back.
      const weight=(this.roleStrip(tap.track)?.reverbWeight??1)*this.depthFactor(id);
      const wanted=weight===0?0:clamp(Math.round(target*weight*1000)/1000,this.rules.minSend,this.rules.maxSend);
      // A channel already at the target is left alone; one that is not is brought to it.
      if(now!==null&&Math.abs(now-wanted)<this.rules.sendDeadBand/2)continue;
      if(this.reverbSend)this.reverbSend(id,wanted,this.rules.spaceRampSeconds);
      else this.change(id,{reverb:wanted},this.rules.spaceRampSeconds);
      applied[id]=wanted;
    }
    // A kit split into a channel per drum (audio.js splitKit) is sent drum by drum, so the kit's own channel, its bus,
    // sends nothing more: its send is kept, and given back when the desk stops.
    if(!this.reverbSend)for(const [id,track] of this.mixer.tracks){
      if(!track.kit||!this.owns(id)||!((track.settings?.reverb??0)>0))continue;
      if(!this.kitSends.has(id))this.kitSends.set(id,track.settings.reverb);
      this.changeTrack(id,track,{reverb:0},this.rules.spaceRampSeconds);
      applied[id]=0;
    }
    return {playing:room.present,mean:Math.round(room.mean*100)/100,
      share:target,moved,applied,held:room.held,
      because:moved
        ?`${room.present} in the room (${room.mean.toFixed(1)} on average), so each gets `
          +`${Math.round(target*100)}% of a soloist's send — the reflections sum to about what `
          +`one player alone would have made`+(this.does('placement')?', more for those further back':'')
        :`${room.present} in the room, so the send stays at ${Math.round(target*100)}% — `
          +`inside the gate, and a send that chased every bot's phrasing would pump`};
  }

  // ---- placement ---------------------------------------------------------------
  //
  // Where each player stands (placement.js). Planned when the band changes -- a part joins or
  // leaves the room, a role becomes known, the featured part changes -- and looked at again every
  // `planEveryMs`, with what moving a playing part costs weighed in, so a plan moves nobody for
  // little. A pan or a width moves slowly while its part plays and quickly while it rests; the
  // fader is trimmed by what they add or take away, so the part is no louder or softer for them;
  // the short room's send and the long reverb's weight follow how far back it stands.
  // The placement duty's aims under the scene's width: the mix's side/mid aim moved (shared/mix-intention.js widthAim),
  // nothing else.
  placementAims(){return {...this.place,...(widthAim(this.intention?.width,MIX_INTENTION,this.place.sideMid)??{})}}
  managePlacement(active){
    if(!this.sceneTiming&&this.settling.placement>this.context.currentTime)
      return {...this.lastPlacement,planned:false,moved:{},because:'a scene change placed the band; it stands there while the scene settles'};
    const rules=this.placementAims();
    // Who is in the room to be placed: heard within holdSeconds, as a player resting for a few bars keeps a place.
    for(const id of active)this.placeUntil.set(id,this.elapsedMs+rules.holdSeconds*1000);
    for(const [id,until] of [...this.placeUntil])if(until<this.elapsedMs||!this.taps.has(id))this.placeUntil.delete(id);
    // A bus is not a player: its channels are placed, and it stays where it is.
    const present=[...this.placeUntil.keys()].filter(id=>!this.taps.get(id)?.track.bus&&this.taps.get(id)?.placeBands?.some(value=>value>0));
    if(!present.length)return {planned:false,moved:{},because:'nobody has been heard long enough to place'};
    // Front to back first, because it says who is featured.
    const roles=this.balancedRoles(),balances=Object.values(roles).map(role=>role.balanceLu).filter(Number.isFinite),voiced=this.voiced();
    const depths=planDepths(present.map(id=>{
      const tap=this.taps.get(id);
      return {id,prominence:roleBalanceLu(roles,tap.track.role,voiced)??roles.other.balanceLu,low:lowShare(tap.placeBands,{hz:rules.lowHz})};
    }),{span:Math.max(...balances)-Math.min(...balances),choices:rules});
    // A kit heard from a distance (an approach's kit.distance) stands at least that far back, all its drums together.
    const distance=this.kitDistance();
    if(distance>0)for(const id of present)if(this.taps.get(id).track.piece&&!(depths.depth[id]>=distance)){
      depths.depth[id]=distance;depths.why[id]=`${Math.round(distance*100)}% of the way back: the kit heard from a distance`;
    }
    // The channels somebody named as the mix's subject are its featured parts when they are here.
    const named=present.filter(id=>this.protect.has(id)),featured=new Set(named.length?named:depths.featured);
    const key=JSON.stringify([this.kitPerspective(),this.kitDistance(),present.map(id=>[id,this.taps.get(id).track.role??null,featured.has(id)])]);
    if(key===this.placeKey&&this.elapsedMs-this.lastPlanAt<rules.planEveryMs)
      return {...this.lastPlacement,planned:false,moved:{}};
    const changed=key!==this.placeKey;
    this.placeKey=key;this.lastPlanAt=this.elapsedMs;
    // How wide the kit stands: the overheads' width close, narrower as it stands back, or the approach's own.
    const sign=this.kitPerspective(),span=kitSpan(this.kitDistance(),{width:this.placeGiven.kitSpan??this.approachPlan?.kit?.width??null,choices:rules});
    const parts=present.map(id=>{
      const tap=this.taps.get(id),track=tap.track,stats=tap.stereo?.stats,pan=track.settings.pan??0,placed=this.placed.get(id);
      // A pan this desk did not give -- set by the spec or a person, or moved since -- is theirs to keep. A kit's drum
      // stands where its kit put it (audio.js splitKit), and that is the desk's to move.
      const home=track.piece?tap.basePan:0;
      if(placed?Math.abs(pan-placed.pan)>SAME_PAN:Math.abs(pan-home)>SAME_PAN)this.pinned.add(id);
      // Its energy in the mix: its power where its panner hears it over the last energySeconds, rests and all, through
      // its fader (its meter's loudness until its stereo is known).
      const dry=track.settings.dry??1,lufs=this.heardLufs(tap);
      const power=stats?.known?stats.power:lufs===null?0:10**(lufs/10);
      // Its stereo as its panner hears it (after its inserts, the approach's width among them), mirrored if this desk
      // mirrors it (a kit's drum heard from the audience), and the width this desk gives it now.
      const flip=track.piece&&sign<0?-1:1,shares=stats?.known?stats.shares:null;
      const source=shares&&flip<0?{pl:shares.pr,pr:shares.pl,c:shares.c}:shares;
      return {id,bands:tap.placeBands,energy:power*dry*dry,pan,at:pan,flip,source,narrow:placed?.width??1,
        featured:featured.has(id),pinned:this.pinned.has(id)||!this.owns(id),playing:active.includes(id),placed:Boolean(placed),
        // A kit's drum: held near the middle if measured mixes hold it there, and, until this desk has placed it,
        // standing where the kit's perspective puts it (kit-channels.js KIT_HOMES; the audience's view mirrored).
        ...(track.piece?{piece:track.piece,most:heldPan(track.piece,rules,span),home:!placed,...(placed?{}:{pan:(KIT_HOMES[track.piece]??0)*sign*span/(rules.kitWidth||1)})}:{})};
    });
    // The returns as measured, in the parts' units (a sample's power in the mix): they stay in the mix as they are.
    const returns=this.returns?.stats.known?this.returns.stats.powers:null;
    const plan=planPans(parts,{returns,changed,choices:rules});
    const moved={};
    for(const part of parts){
      if(part.pinned)continue;
      const id=part.id,tap=this.taps.get(id),before=this.placed.get(id)??{pan:part.at,width:1,flip:1,depth:null,room:null,trimDb:0};
      const values={},pan=plan.pans[id],width=plan.widths[id];
      if(Math.abs(pan-part.at)>=rules.panDeadBand)values.pan=pan;
      const narrowed=Math.abs(width-before.width)>=rules.widthDeadBand?width:before.width,flipped=part.flip!==(before.flip??1);
      // The trim takes back what the pan and the width add or take away (placement.js partImage), the mirror counted.
      const trimDb=Math.round(placeTrimDb(part.source,values.pan??part.at,narrowed)*100)/100;
      if(values.pan!==undefined||narrowed!==before.width||Math.abs(trimDb-before.trimDb)>=rules.trimStepDb)
        values.dry=this.dryFor(tap,id,this.levelDb(id),trimDb);
      const depth=before.depth===null||Math.abs(depths.depth[id]-before.depth)>=rules.depthDeadBand?depths.depth[id]:before.depth;
      const room=roomSend(depth,this.roleStrip(tap.track)?.sends?.room??0,rules);
      if(before.room===null||Math.abs(room-(tap.track.settings.room??0))>=this.rules.sendDeadBand/2)values.room=room;
      this.placed.set(id,{pan:values.pan??part.at,width:narrowed,flip:part.flip,depth,room:values.room??before.room,trimDb:values.dry!==undefined?trimDb:before.trimDb});
      if(!Object.keys(values).length&&narrowed===before.width&&!flipped)continue;
      // One gesture: the pan, the width (a mirror with it), the trim and the room move together, slowly while the part plays.
      const seconds=values.pan===undefined&&narrowed===before.width&&!flipped?this.rules.spaceRampSeconds:part.playing?rules.moveSeconds:rules.restSeconds;
      if(narrowed!==before.width||flipped)this.narrow(tap,narrowed*part.flip,seconds);
      if(Object.keys(values).length)this.change(id,values,seconds);
      moved[id]={...values,...(narrowed!==before.width?{width:narrowed}:{}),...(flipped?{mirrored:part.flip<0}:{}),seconds};
    }
    const image=this.image?.known?{sideMid:Math.round(this.image.sideMid*1000)/1000,balanceDb:Math.round(this.image.balanceDb*10)/10}:null;
    const said=Object.keys(moved).filter(id=>moved[id].pan!==undefined||moved[id].width!==undefined).map(id=>`${id} ${plan.why[id]}`);
    // The middle depth the long reverb is shared out about: the mean of those placed here.
    const placedHere=present.filter(id=>this.placed.get(id)?.depth!==undefined);
    this.middleDepth=placedHere.length?placedHere.reduce((sum,id)=>sum+this.placed.get(id).depth,0)/placedHere.length:null;
    const kit=parts.some(part=>part.piece)?{kitSpan:Math.round(span*100)/100}:{};
    return this.lastPlacement={planned:true,pans:plan.pans,widths:plan.widths,depth:depths.depth,featured:[...featured],moved,...kit,
      why:Object.fromEntries(parts.map(part=>[part.id,{role:this.taps.get(part.id).track.role??null,
        share:Math.round(part.energy/Math.max(Number.EPSILON,parts.reduce((sum,other)=>sum+other.energy,0))*1000)/1000,
        pan:plan.why[part.id],depth:depths.why[part.id]}])),
      image:{measured:image,planned:{sideMid:plan.sideMid,imbalance:plan.imbalance},
        returns:returns?{sideMid:Math.round(this.returns.stats.longSideMid*1000)/1000,balanceDb:Math.round(this.returns.stats.balanceDb*10)/10}:null},
      because:(said.length?`${changed?'the band changed, so ':''}${said.join('; ')}`:'everyone stays where they stand: no move worth making')
        +(kit.kitSpan!==undefined?`; the kit ${Math.round(kit.kitSpan*100)}% wide either side${this.kitDistance()>0?', narrower for standing back':''}`:'')
        +(image?` — the mix measures side/mid ${image.sideMid} and ${Math.abs(image.balanceDb)} dB ${image.balanceDb<0?'left':'right'} of centre`:'')};
  }
  // The roles' places in the balance: the approach's when it balances by role, a studio mix's otherwise.
  balancedRoles(){
    const roles=this.approachPlan?.roles;
    return roles&&Object.values(roles).some(role=>Number.isFinite(role.balanceLu))?roles:STUDIO_ROLES;
  }
  // A channel's loudness when it was last heard playing: a part resting for a bar still has a place.
  heardLufs(tap){
    const lufs=this.tapLoudness(tap);
    if(lufs!==null&&lufs>this.rules.silenceLufs)tap.heardLufs=lufs;
    return tap.heardLufs??null;
  }
  // What a channel puts into the mix at the centre against what its fold-down meter reads, in dB (0 until known).
  stereoDb(tap){return tap.stereo?.stats.known?tap.stereo.stats.centreDb:0}
  // A channel's fader: its balance and its pan's trim, in dB, over where it was found.
  dryFor(tap,id,db,trimDb=this.placed.get(id)?.trimDb??0){
    return clamp(tap.base*10**((db+trimDb)/20),this.rules.minDry,this.rules.maxDry);
  }
  // The long reverb's weight for how far back a channel stands, about the ensemble's middle depth (1 where placement has
  // not placed it).
  depthFactor(id){
    const depth=this.does('placement')?this.placed.get(id)?.depth:null;
    return depth===null||depth===undefined||this.middleDepth===null||this.middleDepth===undefined?1:reverbFactor(depth,this.middleDepth,this.place);
  }
  // A channel's width, this desk's own mid/side stage just before its panner (mixer-parts.js widthMatrix), spliced in
  // the first time the channel is narrowed: at a width of 1 it passes the channel exactly, so the splice is not heard.
  narrow(tap,width,seconds){
    const eq=tap.eq,pan=tap.track.pan;
    if(!eq)return;
    if(!eq.widthStage){
      const stage=widthMatrix(this.context,1);
      try{eq.last.disconnect(pan)}catch{}
      eq.last.connect(stage.input);stage.output.connect(pan);
      eq.widthStage=stage;
    }
    eq.widthStage.set(width,this.sceneTiming?.at??this.context.currentTime,this.sceneTiming?.seconds??seconds);
  }
  // Where placement found a channel, to put it back.
  unplaced(id){
    const tap=this.taps.get(id);
    if(!tap||!this.placed.has(id))return {};
    tap.eq?.widthStage?.set(1,this.context.currentTime,this.rules.rampSeconds);
    return {pan:tap.basePan,room:tap.baseRoom};
  }

  // ---- one pass --------------------------------------------------------------
  decide(){
    if(!this.taps.size)return null;
    // The groups first, so the balance hears the band in them (submix.js).
    const submix=this.does('submix')?this.manageSubmixes():null;
    // Parts set before they were heard: now, and since the last decision as channels were made (trackMade).
    const now=this.soundcheck(),since=this.pending??{};this.pending=null;
    const soundcheck=now||since.soundcheck||since.joined?{...(since.soundcheck??{}),...(now??{}),...(since.joined?{joined:since.joined}:{})}:null;
    const level=this.does('level')?this.balanceFaders()
      :{measured:this.measureAll(),applied:{},target:null,detail:{},active:this.playing(),reason:'level is another desk\u2019s'};
    // Placement before space, whose sends it weights by depth.
    const placement=this.does('placement')?this.managePlacement(level.active)
      :{planned:false,moved:{},because:'placement is another desk\u2019s'};
    const space=this.does('space')?this.manageSpace(level.active)
      :{playing:level.active.length,share:null,applied:{},because:'space is another desk\u2019s'};
    // Masking is asked less often than level: a spectrum needs a longer window and costs more
    // to compute, and a filter that moves every two seconds is an effect rather than a mix.
    let frequency=this.last?.frequency??{moves:[],why:null};
    if(!this.does('frequency'))frequency={moves:[],why:'frequency is another desk\u2019s'};
    else if(this.elapsedMs-this.lastMaskAt>=this.rules.maskEveryMs){
      this.lastMaskAt=this.elapsedMs;
      frequency=this.unmask(level.active);
    }
    // A kept attack follows the permissions at every decision, not the unmasking's slower round.
    if(this.does('frequency'))frequency={...frequency,kept:this.manageKeptAttacks()};
    // Dynamics last, because it changes how the *next* balance behaves rather than this one —
    // reading the range and then moving the faders under it in the same pass would mean the
    // figure never described the mix it was measured on.
    const dynamics=this.manageDynamics();
    this.lastDynamics=dynamics;
    // Punch before the approach's refresh, which leaves the dynamics punch has taken over to it.
    const punch=this.does('punch')?this.managePunch(level.active):null;
    // The approach, if one is set: new channels fitted, roles refitted, compressors steered to
    // their reductions, and the reverb held at its wet level.
    let production=null;
    if(this.applier&&this.approachPlan){
      const masterLufs=this.master?.meter?.shortTerm?.();
      this.applier.refresh({active:level.active,masterLufs:Number.isFinite(masterLufs)?masterLufs:null});
      production={...this.applier.state(),wet:this.lastWet=this.manageWet()};
    }
    // What a character moves, said with every decision (a parameter reported as one: the user, 28 September, on mood):
    // its tone in the channels the desk owns, and the tilt the balance aims at.
    const character=this.character?{tone:this.tone??null,tiltAimDbPerOctave:this.pink.perOctaveDb}:null;
    this.last={at:this.elapsedMs,level,frequency,space,placement,dynamics,production,submix,punch,...(soundcheck?{soundcheck}:{}),...(character?{character}:{}),
      ...(this.attention?{attention:this.attention}:{})};
    this.onUpdate?.(this.state());
    return this.last;
  }

  // Resolves once the metering can hear: at once with analysers, after the module loads with the worklet.
  ready(){return this.metering.ready()}

  start(){
    if(this.running)return this;
    this.running=true;
    // The delivery protected: a mix that measures under its ceiling can still overshoot it between
    // measurements, and past full scale a page's output clips. The mixer's limiter holds the ceiling the
    // dynamics duty aims under (EBU R 128's -1 dBTP), unless something has already set one.
    if(this.mixer?.setEffects&&this.mixer.settings?.limiterCeiling===0){
      this.engagedLimiter=true;
      this.mixer.setEffects({limiterCeiling:Math.max(-12,Math.min(-0.1,this.dynamics.ceilingDbtp??-1))});
    }
    // Sampling first, so that where both fall on one instant the decision reads the newest audio.
    this.timers.push(this.clock.every(this.rules.sampleMs,()=>this.sample()));
    this.timers.push(this.clock.every(this.rules.windowMs,()=>this.decide()));
    this.tapTracks();
    // The groups before the soundcheck, so it balances the parts as the level duty will (their roles' loudness counted).
    if(this.does('submix'))this.manageSubmixes();
    this.firstSoundcheck=this.soundcheck();
    // And every channel made from now on, before it sounds (trackMade).
    if(this.rules.soundcheck&&this.mixer&&'onTrack' in this.mixer){
      const before=this.mixer.onTrack;this.restoreOnTrack=()=>{this.mixer.onTrack=before};
      this.mixer.onTrack=(id,track)=>{before?.(id,track);this.trackMade(id)};
    }
    return this;
  }

  // Everything back where it was found: faders, EQ, and sends. An automatic mix you cannot
  // switch off is one nobody will switch on.
  stop({restore=true}={}){
    this.running=false;
    this.restoreOnTrack?.();this.restoreOnTrack=null;
    for(const cancel of this.timers)cancel();
    this.timers=[];
    for(const [id,tap] of this.taps){
      tap.handle.close();tap.stereo?.handle.close();
      if(restore){
        this.change(id,{dry:tap.base,reverb:tap.baseSend,...this.unplaced(id)},this.rules.rampSeconds);
        for(const filter of Object.values(tap.eq?.bands||{}))
          filter.gain.linearRampToValueAtTime(0,this.context.currentTime+this.rules.eqRampSeconds);
      }
      this.removeEq(tap.track,tap.eq);
      this.taps.delete(id);
    }
    this.balance.reset();this.groupBalances.clear();
    if(restore)this.balance.options={...this.balance.options,...this.balanceDefaults};
    // The buses stay where a render leaves the mix (what its files then hold); restored, every channel goes back to the
    // master and the buses this made go.
    if(restore&&this.submixes){this.submixes.restore();this.submixes=null}
    if(restore)for(const [id,send] of this.kitSends){const track=this.mixer.tracks?.get(id);if(track)this.changeTrack(id,track,{reverb:send},this.rules.rampSeconds)}
    this.kitSends.clear();
    // Punch's meters close either way; restored, its inserts come out and a bus's fader goes back to unity.
    if(restore)this.unpunch();
    else for(const record of this.punched.values()){record.post?.close();record.pre?.close()}
    // A kept attack's duck comes out with the desk, restored; left, the render's files keep it.
    if(restore){for(const duck of this.keptAttacks.values())this.removeDuck(duck);this.keptAttacks.clear()}
    if(restore&&this.applier){this.applier.restore();this.applier=null;this.approachPlan=null}
    if(restore&&this.engagedLimiter){this.mixer.setEffects?.({limiterCeiling:0});this.engagedLimiter=false}
    this.trims.clear();this.lastProfile=null;this.lastTrims=null;this.spectrumSlot=-1;this.spectrumTick=0;
    this.lastSpectrumAt=-Infinity;this.lastPeak=null;this.lastPeakAt=-Infinity;
    if(this.master){this.master.handle.close();this.master=null}
    this.closeWet();
    if(this.returns){
      this.returns.handle.close();
      try{this.mixer.output?.disconnect(this.returns.sum)}catch{}
      for(const {dry,gain} of this.returns.less.values()){try{dry.disconnect(gain)}catch{}try{gain.disconnect()}catch{}}
      this.returns=null;
    }
    this.placed.clear();this.pinned.clear();this.placeUntil.clear();this.image=null;this.lastPlacement=null;this.placeKey=null;this.lastPlanAt=-Infinity;this.middleDepth=null;
    this.last=null;this.lastDynamics=null;
    return this;
  }

  // The desk as it stands, channel by channel: not what changed at the last decision but what
  // every control is *now*. A mixing desk you can only see the last move of is not a desk you
  // can read, and "show me the state of the desk" is the question this answers.
  //
  // Called `strip` and not `channels` because `this.channels` is the remit — the constructor
  // assigns it — and a method of the same name is silently shadowed by the field, so every
  // call to it read a string as a function.
  strip(){
    const last=this.last;
    return [...this.taps.keys()].map(id=>{
      const tap=this.taps.get(id);
      const bands={};
      for(const band of EQ.bands){
        const filter=tap.eq?.bands[band];
        bands[band]=filter?{
          hz:Math.round(filter.frequency.value),
          gainDb:Math.round(filter.gain.value*10)/10,
          q:Math.round(filter.Q.value*100)/100,
        }:{hz:EQ.defaults[band].hz,gainDb:0,q:EQ.defaults[band].q};
      }
      return {
        id,
        mine:this.owns(id),
        lufs:last?.level?.measured?.[id]??null,
        // The live values, not the requested ones — a desk that showed what it asked for
        // rather than what is there would be a wish list.
        fader:Math.round((tap.track.dry?.gain?.value??tap.track.settings.dry)*1000)/1000,
        faderDb:last?.level?.applied?.[id]?.db??0,
        pan:tap.track.settings.pan,
        send:Math.round((tap.track.settings.reverb??0)*1000)/1000,
        // Where placement stands it: how far back (0 front, 1 back), the short room's send, and the fader trim its pan
        // takes (null where it has not placed it).
        depth:this.placed.get(id)?.depth??null,
        width:this.placed.get(id)?.width??null,
        room:Math.round((tap.track.settings.room??0)*1000)/1000,
        panTrimDb:this.placed.get(id)?.trimDb??null,
        // The bus its group is on (submix.js), or null on the master.
        bus:this.groupOf(id),
        eq:bands,
        // What the spectral target is adding to this channel's reported loudness, so a fader
        // that moved for a reason the level column cannot explain is still explicable.
        trimDb:last?.level?.trims?.[id]??0,
        // Whether this channel is doing anything at all, which is what the gate decided.
        playing:(last?.level?.active??[]).includes(id),
        why:last?.level?.detail?.[id]?.reason??null,
      };
    });
  }

  // Each channel's energy in the desk's bands (AUTO_MIX.bands), as the desk measures it for placement: carried over the
  // rounds the channel was sounding in, so a part resting now is still described by how it sounded (desk-spectra.js
  // publishes these to the room). Channels not yet heard are left out.
  spectra(){
    const measured={};
    for(const [id,tap] of this.taps){
      const bands=tap.placeBands??tap.bands;
      if(!tap.track.bus&&bands?.some(value=>value>0))measured[id]=[...bands];
    }
    return measured;
  }

  // What it is doing and why, in the shape a display or a plan can carry.
  state(){
    const last=this.last;
    return {
      id:this.id,running:this.running,channels:this.taps.size,
      remit:{channels:this.channels==='all'?'all':[...this.channels],duties:[...this.duties]},
      intention:this.intention||this.permissions.length?{...this.intentionReach(),...(this.lastScene?{scene:this.lastScene}:{})}:null,
      owned:[...this.taps.keys()].filter(id=>this.owns(id)),
      target:last?.level?.target??null,
      measured:last?.level?.measured??{},
      faders:last?.level?.applied??{},
      detail:last?.level?.detail??{},
      eq:last?.frequency?.moves??[],
      // The character's tone in the channels it owns (setTone), or null.
      tone:this.tone??null,
      space:last?.space??null,
      placement:last?.placement??null,
      submix:last?.submix?{groups:last.submix.groups,balance:last.level?.groups??{},because:last.submix.because}:null,
      punch:last?.punch??null,
      dynamics:last?.dynamics??null,
      spectrum:last?.level?.profile
        ?{perOctaveDb:this.pink.perOctaveDb,toleranceDb:this.pink.toleranceDb,
          bands:last.level.profile,trims:last.level.trims??{}}
        :null,
      strip:this.strip(),
      rules:{targetLufs:last?.level?.target??null,
        deadBandDb:this.balance.options.deadBandDb,
        maxMoveDb:this.balance.options.maxMoveDb,
        soloSend:this.rules.soloSend,
        maskEveryMs:this.rules.maskEveryMs,
        // What it is holding the mix to, so a display can say the target beside the reading.
        dynamics:{targetLufs:this.dynamics.targetLufs,rangeLu:this.dynamics.rangeLu,
          rangeBandLu:[this.dynamics.minRangeLu,this.dynamics.maxRangeLu],
          psrDb:this.dynamics.psrDb,plrDb:this.dynamics.plrDb,
          psrFloorDb:this.dynamics.minPsrDb,plrFloorDb:this.dynamics.minPlrDb,
          ceilingDbtp:this.dynamics.ceilingDbtp}},
      reason:last?.level?.reason??null,
      // The approach it is making the mix by, if any: its name and description, each channel's
      // role and what it was given, and the reverb against its wet level.
      production:last?.production??(this.applier?this.applier.state():null),
    };
  }

  // The same thing in words, which is what gets said to the room.
  // `state` is a parameter because a caller that has just built one should not make the desk
  // build another: `state()` walks every channel and `drawMix` was asking for it three times
  // per decision — the display, the explanation, and the broadcast.
  explain(state=this.state()){
    const lines=[];
    if(state.target!==null)
      lines.push(`levels toward ${state.target.toFixed(1)} LUFS, the ensemble's own average`);
    for(const move of state.eq)
      lines.push(`${move.id} ${move.gainDb.toFixed(1)} dB at ${move.hz} Hz — ${move.because}`);
    if(state.production?.approach)lines.push(`mixing as ${state.production.approach}: ${state.production.describe}`);
    if(state.production?.wet?.because)lines.push(state.production.wet.because);
    if(state.space)lines.push(state.space.because);
    if(state.placement?.because)lines.push(state.placement.because);
    if(state.submix?.because)lines.push(state.submix.because);
    if(state.punch?.because)lines.push(state.punch.because);
    if(state.dynamics?.because)lines.push(state.dynamics.because);
    const crowded=(state.spectrum?.bands||[])
      .filter(band=>band.acted&&Math.abs(band.deviationDb)>state.spectrum.toleranceDb)
      .sort((left,right)=>Math.abs(right.deviationDb)-Math.abs(left.deviationDb));
    if(crowded.length){
      const band=crowded[0];
      lines.push(`${band.hz[0]}\u2013${band.hz[1]} Hz is `
        +`${band.deviationDb>0?'+':''}${band.deviationDb.toFixed(1)} dB against pink, so the `
        +`channels living there are balanced as if they were that much louder`);
    }
    return lines;
  }
}
