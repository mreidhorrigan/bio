// How the desk and the automatic mix listen: two ways, one interface, one switch.
//
// **analyser** is the original path. Every channel gets an AnalyserNode whose last 2048 frames
// are read on the sample clock (every 50 ms), so about 85% of the audio at 48 kHz is seen; the
// main thread K-weights each snapshot into the loudness meter and keeps the snapshots for the
// spectral passes. **worklet** puts a small processor on the audio thread instead
// (`meter-worklet.js`): it runs the same `LoudnessMeter` over every sample, gapless, keeps the
// sample peak, and hands each finished 100 ms block to the main thread with its audio, so the
// meters see everything and the sampling clock can be the audio's own rather than a timer a
// background tab throttles. Nothing else moves to the audio thread: spectra and the true peak
// stay here, on the same cadence as before.
//
// **To go back to the analyser path** — if audio interruptions appear with the worklet live —
// any one of these, in order of precedence:
//   * pass `metering: 'analyser'` to LiveDesk / LiveAutoMix (a render spec's `desk.metering`);
//   * set `globalThis.MUSEBOTS_METERING = 'analyser'` before the desk starts;
//   * open the page with `?metering=analyser`;
//   * change DEFAULT_METERING below.
// Both paths stay complete and tested; the classes consume only the handle interface below.
//
// A handle measures one signal (a channel, or the master in stereo):
//   sample()            read what has arrived (the analyser path reads its analysers here)
//   meter               allBlocks (kept to keepBlocks), blocks, shortTerm(), momentary(), loudness(n): the LoudnessMeter API
//   chunks              the retained audio, newest last, for the spread spectral windows: a stereo signal's mid,
//                       (L+R)/2, so a part panned to one side is heard in the spectrum as much as one in the middle
//   window(ms)          the newest `ms` of audio joined, or null
//   recent()            the newest frames per channel (the true peak is taken from them), or null
//   peakOver(seconds)   the highest sample peak measured over the last `seconds`
//   frame               how many frames the signal had produced when the newest block arrived (worklet), else null
//   onBlock             settable: called with each block's audio, one array per channel, as it arrives (worklet) or is
//                       sampled (analyser), before the buffers go back -- how a caller keeps its own statistics of every
//                       block, as the meter does, rather than of whichever block is newest when it happens to look
//   close()
// A stereo tap (channels: 2) takes `interpretation`: 'speakers' (the default) spreads a mono signal to both sides, as
// a stereo bus would hear it; 'discrete' leaves its right side silent, which is how a listener tells a mono signal from
// a correlated stereo one (the analyser path's splitter is always discrete).
import {LoudnessMeter} from './desk.js';

export const DEFAULT_METERING='worklet';
export const METERING_MODES=Object.freeze(['analyser','worklet']);
// The worklet's address, resolved when asked for rather than at load. In the offline demo
// package every module is bundled into one classic script, where `import.meta.url` is empty:
// a `new URL` at load time threw there before the page had drawn anything. In that bundle
// the worklet file is not shipped either, so the worklet path is simply unavailable (null)
// and the desk meters with analysers.
export function meterWorkletURL(base=import.meta.url){
  try{return base?new URL('./meter-worklet.js',base):null}catch{return null}
}
const FFT_SIZE=2048,CLOCK_TICK_FRAMES=512,MS_PER_SECOND=1000;
let warnedFallback=false,warnedUnknown=false;

function urlOverride(){
  try{const search=globalThis.location?.search;return search?new URLSearchParams(search).get('metering'):null}catch{return null}
}
// The mode to use: the option, then the global, then the URL, then the default; 'worklet' becomes
// 'analyser', once with a warning, on a context that has no AudioWorklet or in a bundle that
// cannot reach the worklet file.
export function meteringMode({option=null,context=null,workletURL=meterWorkletURL()}={}){
  const explicit=option??globalThis.MUSEBOTS_METERING??urlOverride()??null;
  let mode=explicit??DEFAULT_METERING;
  if(!METERING_MODES.includes(mode)){
    if(!warnedUnknown){warnedUnknown=true;console.warn(`Unknown metering "${mode}"; using ${DEFAULT_METERING}`)}
    mode=DEFAULT_METERING;
  }
  if(mode==='worklet'&&(!workletURL||context&&!context.audioWorklet)){
    // Asked for by name and unavailable is worth a word; the default quietly takes what the context has.
    if(explicit==='worklet'&&!warnedFallback){warnedFallback=true;console.warn(workletURL
      ?'This audio context has no AudioWorklet; the desk meters with analysers'
      :'The meter worklet is not shipped in this bundle; the desk meters with analysers')}
    mode='analyser';
  }
  return mode;
}

// A LoudnessMeter fed finished blocks rather than samples: the same window and formula, so a
// figure read from it is the figure the analyser path would give from the same blocks.
export class BlockMeter extends LoudnessMeter {
  pushBlock(block){
    this.blocks.push(block);
    if(this.keepAllBlocks)this.allBlocks.push(block);
    while(this.blocks.length>30)this.blocks.shift();
    return this;
  }
}

const trim=(list,keep)=>{if(list.length>keep)list.splice(0,list.length-keep)};
const ringPeak=(peaks,count)=>{let best=0;for(let index=Math.max(0,peaks.length-count);index<peaks.length;index++)if(peaks[index]>best)best=peaks[index];return best};

// ---- analyser -------------------------------------------------------------------
function analyserTap(context,node,{channels,keepBlocks,chunkWindowMs,peakWindowMs,sampleMs}){
  const sampleRate=context.sampleRate;
  let splitter=null,analysers;
  if(channels===2&&typeof context.createChannelSplitter==='function'){
    splitter=context.createChannelSplitter(2);node.connect(splitter);
    analysers=[0,1].map(channel=>{const analyser=context.createAnalyser();analyser.fftSize=FFT_SIZE;splitter.connect(analyser,channel);return analyser});
  }else{
    const analyser=context.createAnalyser();analyser.fftSize=FFT_SIZE;node.connect(analyser);analysers=[analyser];
  }
  const meter=new LoudnessMeter({sampleRate,channels:analysers.length});meter.keepAllBlocks=true;
  const frames=analysers.map(analyser=>new Float32Array(analyser.fftSize));
  const chunkWindow=Math.ceil(chunkWindowMs/sampleMs),peakWindow=Math.ceil(peakWindowMs/sampleMs);
  const handle={meter,analysers,chunks:[],peaks:[],frame:null,joined:null,
    sample(){
      if(analysers.length===1){
        // The chunk is the read buffer, recycled from the oldest: no copy and no garbage.
        const frame=handle.chunks.length>=chunkWindow?handle.chunks.shift():new Float32Array(FFT_SIZE);
        analysers[0].getFloatTimeDomainData(frame);frames[0]=frame;
        handle.chunks.push(frame);
      }else{
        for(const [index,analyser] of analysers.entries())analyser.getFloatTimeDomainData(frames[index]);
        const spare=handle.chunks.length>=chunkWindow?handle.chunks.shift():new Float32Array(FFT_SIZE);
        const [left,right]=frames;for(let index=0;index<spare.length;index++)spare[index]=(left[index]+right[index])/2;
        handle.chunks.push(spare);
      }
      handle.onBlock?.(frames);
      meter.push(frames);
      trim(meter.allBlocks,keepBlocks);
      let peak=0;
      for(const channel of frames)for(const value of channel){const size=Math.abs(value);if(size>peak)peak=size}
      handle.peaks.push(peak);trim(handle.peaks,peakWindow);
      return 1;
    },
    // The newest `ms`, sampled: ms/sampleMs snapshots joined into one reused buffer.
    window(ms){return joinNewest(handle,Math.ceil(ms/sampleMs))},
    recent(){return handle.chunks.length?frames:null},
    peakOver(seconds){return ringPeak(handle.peaks,Math.ceil(seconds*1000/sampleMs))},
    close(){
      for(const analyser of analysers){try{(splitter||node).disconnect(analyser)}catch{}}
      if(splitter){try{node.disconnect(splitter)}catch{}try{splitter.disconnect()}catch{}}
    },
  };
  return handle;
}

function joinNewest(handle,count){
  const chunks=handle.chunks,from=Math.max(0,chunks.length-count);
  if(chunks.length<=from)return null;
  let total=0;
  for(let index=from;index<chunks.length;index++)total+=chunks[index].length;
  if(!total)return null;
  if(!handle.joined||handle.joined.length<total)handle.joined=new Float32Array(total);
  let at=0;
  for(let index=from;index<chunks.length;index++){handle.joined.set(chunks[index],at);at+=chunks[index].length}
  return at===handle.joined.length?handle.joined:handle.joined.subarray(0,at);
}

// How faithfully a strategy hears the audio, for a caller that must know (the mathematical audit's I18): the worklet
// hears every frame, in order; the analyser path reads its newest frames at each poll, so at a poll slower than its
// buffer lasts it misses the frames between (2,048 frames, 42.7 ms at 48 kHz, read every 50 ms: 85% heard), and at a
// faster one it reads some twice. `coverage(pollMs)` is the share of the audio a poll that often reads once.
export function analyserQuality(context,frames=FFT_SIZE){
  return {contiguous:false,frames,coverage:pollMs=>Math.min(1,frames/Math.max(1,pollMs*context.sampleRate/MS_PER_SECOND))};
}
export function analyserMetering(context){
  return {mode:'analyser',ready:()=>Promise.resolve(),quality:analyserQuality(context),
    tap:(node,options)=>analyserTap(context,node,options),dispose(){}};
}

// ---- worklet --------------------------------------------------------------------
const modules=new WeakMap;
// One module load per context, shared by every meter and the clock on it.
export function loadMeterWorklet(context,url=meterWorkletURL()){
  if(!modules.has(context)){
    const load=url?context.audioWorklet.addModule(url.href):Promise.reject(new Error('The meter worklet is not available from this bundle'));
    modules.set(context,load.catch(error=>{modules.delete(context);throw error}));
  }
  return modules.get(context);
}
// The page's AudioWorkletNode, or the one the context's own worklet runtime provides (a Node render).
const nodeClass=context=>{
  const Node=globalThis.AudioWorkletNode??context.audioWorklet?.AudioWorkletNode;
  if(typeof Node!=='function')throw new Error('This context has an AudioWorklet but no AudioWorkletNode class to make meters with');
  return Node;
};

function workletTap(context,node,{channels,keepBlocks,chunkWindowMs,peakWindowMs,interpretation='speakers'},ready){
  const sampleRate=context.sampleRate,blockFrames=Math.round(sampleRate*.1),blockMs=100;
  const meter=new BlockMeter({sampleRate,channels});meter.keepAllBlocks=true;
  const chunkWindow=Math.ceil(chunkWindowMs/blockMs),peakWindow=Math.ceil(peakWindowMs/blockMs);
  let worklet=null,closed=false,latest=null;
  // A stereo signal's retained audio is its mid, made here into buffers kept for the purpose.
  const mids=[];
  const recycle=buffers=>{if(worklet&&!closed)worklet.port.postMessage({type:'recycle',buffers},buffers.map(buffer=>buffer.buffer))};
  const handle={meter,chunks:[],peaks:[],frame:null,joined:null,arrived:0,attached:null,
    // Blocks arrive on their own; there is nothing to read here.
    sample(){return 0},
    window(ms){return joinNewest(handle,Math.ceil(ms/blockMs))},
    recent(){return latest},
    peakOver(seconds){return ringPeak(handle.peaks,Math.ceil(seconds*1000/blockMs))},
    close(){
      closed=true;
      if(worklet){try{node.disconnect(worklet)}catch{}try{worklet.port.close()}catch{}}
    },
  };
  // Attached once the module has loaded; a failure surfaces through the strategy's ready(), not in silence.
  handle.attached=ready.then(()=>{
    if(closed)return;
    const Node=nodeClass(context);
    worklet=new Node(context,'musebots-meter',{numberOfInputs:1,numberOfOutputs:0,channelCount:channels,
      channelCountMode:'explicit',channelInterpretation:interpretation,processorOptions:{channels,blockFrames}});
    worklet.port.onmessage=({data})=>{
      if(closed||data?.type!=='block')return;
      handle.arrived++;handle.frame=data.frame;
      meter.pushBlock(data.loudness);trim(meter.allBlocks,keepBlocks);
      handle.peaks.push(data.peak);trim(handle.peaks,peakWindow);
      handle.onBlock?.(data.audio);
      // A mono signal's block joins the retained audio as it is, and goes back when it leaves it; a stereo one's mid
      // joins it, and the previous block's channels go back when this one arrives.
      const stereo=data.audio.length>1;
      if(latest&&latest.length>1)recycle(latest);
      latest=data.audio;
      if(stereo){
        const [left,right]=data.audio,mid=mids.pop()||new Float32Array(left.length);
        for(let index=0;index<mid.length;index++)mid[index]=(left[index]+right[index])/2;
        handle.chunks.push(mid);
        if(handle.chunks.length>chunkWindow)mids.push(handle.chunks.shift());
      }else{
        handle.chunks.push(data.audio[0]);
        if(handle.chunks.length>chunkWindow)recycle([handle.chunks.shift()]);
      }
    };
    worklet.port.start?.();
    node.connect(worklet);
  });
  handle.attached.catch(()=>{});
  return handle;
}

export function workletMetering(context){
  const ready=loadMeterWorklet(context),taps=new Set;
  return {mode:'worklet',quality:{contiguous:true,frames:null,coverage:()=>1},
    // The module loaded and every meter asked for so far attached (or the first failure).
    ready:()=>Promise.all([ready,...[...taps].map(tap=>tap.attached)]).then(()=>undefined),
    tap(node,options){const handle=workletTap(context,node,options,ready);taps.add(handle);return handle},
    dispose(){}};
}

export function createMetering(context,{mode=meteringMode({context})}={}){
  return mode==='worklet'?workletMetering(context):analyserMetering(context);
}

// ---- the audio-clocked clock ------------------------------------------------------
const clocks=new WeakMap;
// `{every(ms, fn) → cancel, now()}` on the audio's own frame counter: one 'musebots-clock'
// processor per context posts its frame every ~10 ms, and a timer runs when the posted frame
// reaches its due frame. Its next deadline is counted from its own phase, not from the frame it
// happened to run at (the mathematical audit's I18: re-armed from the frame it ran at, a
// 2,400-frame period checked every 512 frames took 2,560 each time); deadlines missed while it
// waited are run once, not queued. Until the module has loaded nothing fires; a timer set then is
// due from frame 0.
export function workletClock(context){
  if(clocks.has(context))return clocks.get(context);
  const timers=new Map;let ids=0,frame=0,node=null;
  const sampleRate=context.sampleRate;
  const attached=loadMeterWorklet(context).then(()=>{
    const Node=nodeClass(context);
    // One silent output, connected to the destination. The spec refuses a node with neither
    // inputs nor outputs, and a source nobody pulls is never rendered -- so the clock has to
    // be in the graph to tick. Its processor writes nothing, and adding exact zeros to the
    // master changes no sample; a byte-identical render stays byte-identical.
    node=new Node(context,'musebots-clock',{numberOfInputs:0,numberOfOutputs:1,outputChannelCount:[1],
      processorOptions:{tickFrames:CLOCK_TICK_FRAMES}});
    node.connect(context.destination);
    node.port.onmessage=({data})=>{
      if(typeof data?.frame!=='number')return;
      frame=data.frame;
      const due=[...timers.values()].filter(timer=>timer.at<=frame).sort((a,b)=>a.at-b.at||a.id-b.id);
      for(const timer of due){if(!timers.has(timer.id))continue;timer.at+=timer.every*(1+Math.floor((frame-timer.at)/timer.every));timer.fn()}
    };
    node.port.start?.();
  });
  attached.catch(()=>{});
  const clock={ready:()=>attached,
    every(ms,fn){
      const every=Math.max(1,Math.round(ms*sampleRate/1000)),id=++ids;
      timers.set(id,{id,every,at:frame+every,fn});
      return ()=>timers.delete(id);
    },
    now(){return context.currentTime},
    get frame(){return frame},
  };
  clocks.set(context,clock);
  return clock;
}
