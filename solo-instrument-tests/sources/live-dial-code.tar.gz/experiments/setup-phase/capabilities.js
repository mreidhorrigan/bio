// What each bot provides and what it needs, so an ensemble can be asked whether it could
// possibly play together before it tries.
//
// **This exists because of a measurement.** A five-bot line-up sounded like harmonically
// disorganised chaos. Watching what it actually said to itself: 166 protocol messages in 25
// seconds, and *none* of them harmonic. Density, arousal and meter were agreed within 0.15 s;
// harmony was never mentioned, because four of the five bots *follow* chord plans and note
// pools and not one of them *publishes* any. Add `ae_ModalChordBOT` to the same line-up and a
// harmony plan appears at +0.14 s, with note pool and chords, and two bots answer it at
// +0.16 s. The protocol was never the problem and neither was timing; the room had no harmony
// source in it, and nothing anywhere checked.
//
// So: a declaration per bot of what it publishes and what it consumes, and a census that says
// what an ensemble is missing. A line-up whose consumers have no provider is not a taste
// question, it is a fault, and it should be visible before the downbeat rather than audible
// after it.
//
// **How the declarations are arrived at, and why that is provisional.** The registry describes
// each bot in prose — "sustained chord-plan pad", "walks an octave-expanded note pool",
// "broadcasts note pools and plans" — and that prose is the only structured-ish thing there is
// for 97 bots. So this reads it, with an explicit override table for the ones where the prose
// misleads. It is a *heuristic over documentation*, which is worth saying plainly: it can be
// wrong, it is checkable against what a bot actually broadcasts at runtime (`observed`), and
// the real fix is the backlog item asking every bot to declare its own range of situations.
// Until then, an inference that can be corrected beats a blank where the knowledge should be.

// The things an ensemble has to agree about before it can play together. Ordered by how badly
// their absence shows: two bots in different keys is chaos, two bots at different densities is
// a texture.
export const FACULTIES=Object.freeze(['harmony','tuning','pulse','form']);

// Where the prose is misleading, or where a bot's name says more than its description. Every
// entry here is a correction to the inference below, and says why.
export const OVERRIDES=Object.freeze({
  // Self-contained: it makes its own material and neither needs nor offers harmony. Its
  // description mentions no harmony at all, which the inference gets right, but it is the bot
  // the failing line-up was built around so it is worth being explicit.
  mhDrone:{provides:[],requires:[]},
  // "Silent ... harmony agent publishing current chords, pitch-class probabilities" — these
  // publish and never sound, which is exactly what a setup phase wants to know about.
  swingChord:{provides:['harmony'],requires:[]},
  methenyChord:{provides:['harmony'],requires:[]},
  mozartChord:{provides:['harmony'],requires:[]},
  xChord:{provides:['harmony'],requires:[]},
  // The tuning authority. Its plans are optional by design, so it provides rather than requires.
  tune:{provides:['tuning'],requires:[]},
  mhTune:{provides:['tuning'],requires:[]},
  // Form and coordination.
  form:{provides:['form'],requires:[]},
  coord:{provides:[],requires:[]},
  // An observed external clock is evidence, not authority over the transport.
  midiInput:{provides:[],requires:[]},
  listener:{provides:[],requires:[]},
  response:{provides:[],requires:[]}, // Its selected input governs only its own prepared output.
  conductor:{provides:['pulse','form'],requires:[]},
  // A curated harmony agent: it leads the harmony when nobody else does and accompanies when somebody does. `defers`
  // is what lets a room order its sources -- the one that will yield is asked after the one that will not, so it
  // hears a leader before deciding it has to be one.
  harmonyPulse:{provides:['harmony'],requires:[],defers:['harmony']},
  // It sets the METER and the TEMPO, section by section, and its description says "form", so the inference missed
  // the pulse entirely. `opens` says it has an opening to state before anybody plays: the first section's meter and
  // tempo, so a piece does not spend its first phrase in a default 4/4 it was never going to keep.
  plex:{provides:['form','pulse'],requires:[],opens:['pulse']},
  // The voice-leading clodbots tune their own chords (just or harmonic-series intonation, native-tuning.js), which the
  // prose says and the inference reads as offering tuning to others. They offer none, and defer to a tuning plan where
  // the room has one; they follow the harmony.
  romantic_clodbot:{provides:[],requires:['harmony']},
  impressionist_clodbot:{provides:[],requires:['harmony']},
  jazzvoicing_clodbot:{provides:[],requires:['harmony']},
  hindemith_clodbot:{provides:[],requires:['harmony']},
  // The rhythm clodbots hear the "performer's" attacks, which the form pattern reads as offering form. They offer
  // none; they follow the meter, and the riff the harmony too.
  interlockdrum_clodbot:{provides:[],requires:['pulse']},
  riff_clodbot:{provides:[],requires:['harmony','pulse']},
  riffmotif_clodbot:{provides:[],requires:['harmony','pulse']},
  harris_clodbot:{provides:[],requires:['harmony','pulse']},
  // The form bot for rhythm sets the meter bar by bar, a home and dissonances over it, and states its first bar before
  // anybody plays, as mh_PlexBOT states its first section's.
  meterform_clodbot:{provides:['form','pulse'],requires:[],opens:['pulse']},
  feedback_clodbot:{provides:[],requires:[],opens:[]},   // a mixbot: it moves the desk, and provides no faculty
  // It listens to the performer's notes and stores phrases; it offers nothing to the room and needs nothing of it.
  motifprofiler_clodbot:{provides:[],requires:[]},
  // The singer's prose says "floating pitches" and "phrase", which the inference reads as needing tuning and form. It
  // tunes itself (just intonation where no tuning bot leads) and sings to the harmony and the beat it hears.
  clodbot_singerbot:{provides:[],requires:['harmony','pulse']},
  // It forks mh_FormBOT: the form, as its fork's; the cadence and ritardando it proposes at the end are the ending's,
  // not a harmony or a pulse it offers the room.
  form_clodbot:{provides:['form'],requires:[]},
  // The forks timed in the transport's own beats (the audit's B04; bots/lib/quarter-tempo.js) provide and require what
  // their ports do: their prose says "beats" and "bars", which the inference would read as more
  // (test/quarter-tempo-forks.test.mjs checks each against its port's).
  ornament_clodbot:{provides:[],requires:[]},
  msynth_clodbot:{provides:['form'],requires:['pulse']},
  rsynth_clodbot:{provides:['form'],requires:['pulse']},
  multisynth_clodbot:{provides:['form'],requires:[]},
  reichguitar_clodbot:{provides:['form'],requires:[]},
  methenymelody_clodbot:{provides:['form'],requires:[]},
  autechre_clodbot:{provides:['form'],requires:[]},
  wind_clodbot:{provides:[],requires:[]},
  atmosphere_clodbot:{provides:[],requires:[]},
  texture_clodbot:{provides:[],requires:[]},
  granu_clodbot:{provides:[],requires:[]},
  derivations_clodbot:{provides:[],requires:[]},
  seasonsbrokenchord_clodbot:{provides:[],requires:['harmony','form']},
  seasonsdrone_clodbot:{provides:[],requires:['harmony']},
  // The forks with the audit's other findings (B02, B06, B07) provide and require what their ports do; their prose
  // describes the fix, which the inference would read as more (test/port-forks.test.mjs checks each against its port's).
  mhdrone_clodbot:{provides:[],requires:[]},
  xbass_clodbot:{provides:[],requires:['pulse']},
  newbeat_clodbot:{provides:[],requires:['pulse']},
  chichichi_clodbot:{provides:[],requires:[]},
  valencearousal_clodbot:{provides:['form'],requires:['pulse']},
  drone_clodbot:{provides:[],requires:['harmony','form']},
  tangerinedream_clodbot:{provides:['form'],requires:['tuning','pulse']},
  // It comps its own motive or row language and needs no harmony (a root heard only moves where its classes are counted
  // from); its prose says "harmony" as what it plays, not what it offers the others.
  atonal_clodbot:{provides:[],requires:['pulse']},
  // The pitch languages' other bots hear voices, not faculties: a melody to mirror, a bass and a melody to colour; the
  // scalar layers count from a root heard, where there is one.
  mirror_clodbot:{provides:[],requires:['pulse']},
  vivier_clodbot:{provides:[],requires:[]},
  polyscalar_clodbot:{provides:[],requires:['pulse']},
  // The power-chord loop gives the band its harmony (a note pool at each change), and follows none.
  powerloop_clodbot:{provides:['harmony'],requires:['pulse']},
  // Its line and accompaniment are its own (a declared test profile); it follows the pulse only.
  modalline_clodbot:{provides:[],requires:['pulse']},
  // A melody like PAP_MelodyBot's, which restates its own theme where the form returns (it follows the harmony there).
  papmelody_clodbot:{provides:[],requires:['pulse','harmony']},
  // Another bot's audio through its effects: it needs a part to process, and plays nothing of its own.
  effects_clodbot:{provides:[],requires:[]},
  // It hears an input and says what it hears; it plays nothing and follows nothing.
  audioanalyzer_clodbot:{provides:[],requires:[]},
  // mh_HarmonyPulseBOT's fork: a harmony source that leads when nobody else does, as the bot it forks.
  harmonypulse_clodbot:{provides:['harmony'],requires:[],defers:['harmony']},
  // meterform_clodbot's fork: it sets the meter bar by bar and states its first bar before anybody plays, as the base.
  meterspace_clodbot:{provides:['form','pulse'],requires:[],opens:['pulse']},
  // A bowed string's line follows the harmony it hears (its pool), and provides none.
  bowedstring_clodbot:{provides:[],requires:['harmony']},
  // A flute's line follows the harmony it hears (its pool), and provides none.
  flute_clodbot:{provides:[],requires:['harmony']},
  // mh_TuneBOT's fork: a tuning offered to the room, as the base; it plays nothing and needs nothing.
  tunespace_clodbot:{provides:['tuning'],requires:[]},
  // A harmony source: the collection it offers is the room's harmony; it plays nothing.
  harmonyspace_clodbot:{provides:['harmony'],requires:[]},
  // The guitarist voices the room's harmony on the meter's groups; its prose (its shapes, its strums, its runs) names
  // neither.
  guitar_clodbot:{provides:[],requires:['harmony','pulse']},
  // The language line plays its own languages on the meter's felt beats; the harmony heard is one of them, not a need.
  languagespace_clodbot:{provides:[],requires:['pulse']},
  // A section of lines: it plays in the harmony it hears (micropolyphony's cantus) or none (masses); it offers none.
  mass_clodbot:{provides:[],requires:[]},
  mallets_clodbot:{provides:[],requires:['harmony','pulse']},
  kalimba_clodbot:{provides:[],requires:['harmony','pulse']},
  // A steelpan's line follows the harmony it hears (its pool), as the flute's, and provides none.
  steelpan_clodbot:{provides:[],requires:['harmony']},
  timeline_clodbot:{provides:[],requires:['pulse']},
  shaker_clodbot:{provides:[],requires:['pulse']},
  conguero_clodbot:{provides:[],requires:['pulse']},
  // A timpanist strikes the room's harmony's tonic and dominant on the meter's felt beats, and provides none.
  timpani_clodbot:{provides:[],requires:['harmony','pulse']},
  // A gong player marks the form's arrivals on the clock's phrases, and provides none.
  gong_clodbot:{provides:[],requires:['pulse']},
  // A talking drummer plays on the pulse its own drum's tones, and provides none.
  talkingdrum_clodbot:{provides:[],requires:['pulse']},
  // A harpist voices the room's harmony on the meter's felt beats, and provides none.
  harp_clodbot:{provides:[],requires:['harmony','pulse']},
  // An accordionist presses the room's harmony's bass and chord buttons on the meter's groups, and provides none.
  accordion_clodbot:{provides:[],requires:['harmony','pulse']},
  // A harpsichordist voices the room's harmony on the meter's felt beats, as the pianist, and provides none.
  harpsichord_clodbot:{provides:[],requires:['harmony','pulse']},
  // A string section's seats play the harmony heard where their textures take it (a line, a chord, a canon's cantus), and
  // provide none.
  strings_clodbot:{provides:[],requires:[]},
  // The conductorbot sets the form, the meter and the tempo, and states its first section before anybody plays, as
  // mh_PlexBOT does.
  plex_clodbot:{provides:['form','pulse'],requires:[],opens:['pulse']},
  // A profile of a person hears them as the listener does, and provides nothing a band waits on.
  profile_clodbot:{provides:[],requires:[]},
  // The pianist voices the room's harmony on the meter's felt beats; its prose (its hands, its runs, a solo's climax)
  // names neither.
  piano_clodbot:{provides:[],requires:['harmony','pulse']},
});

const PROVIDE_PATTERNS=Object.freeze({
  harmony:/broadcasts? note pools|publish(?:es|ing)? (?:current )?chords|harmony (?:and )?chord plans|chord plans?\b(?=[^.]*publish)|pitch-class probabilit|harmony planner|harmony agent/i,
  tuning:/tuning|temperament|adaptive ji|just intonation/i,
  pulse:/tempo|pulse|conductor|clock/i,
  form:/form|section|progression storage/i,
});
const REQUIRE_PATTERNS=Object.freeze({
  harmony:/following (?:floating )?note pools|follow(?:s|ing)? chord plans|note-pool fallback|walks an octave-expanded note pool|reacting to harmony|aligned with tala and density|planned harmony|plan-common pitch class|chord-plan/i,
  tuning:/microtonal|quarter-tone|floating pitch/i,
  pulse:/tala|meter|beat|pulse/i,
  form:/phrase|section|progress/i,
});

// What one bot provides and requires, inferred from its registry entry.
export function capabilitiesOf(id,definition){
  const override=OVERRIDES[id];
  const text=`${definition?.name||''} ${definition?.description||''}`;
  const provides=[],requires=[];
  for(const faculty of FACULTIES){
    if(PROVIDE_PATTERNS[faculty]?.test(text))provides.push(faculty);
    else if(REQUIRE_PATTERNS[faculty]?.test(text))requires.push(faculty);
  }
  return {
    id,
    name:definition?.name||id,
    provides:override?.provides??provides,
    requires:override?.requires??requires,
    // Faculties it provides only in the absence of another provider, and faculties it states before the downbeat.
    defers:override?.defers??[],
    opens:override?.opens??[],
    // Whether the inference was used, so a caller can tell a declaration from a guess.
    inferred:!override,
  };
}

// The whole line-up: who provides what, who needs what, and what nobody covers.
export function census(ids,agents){
  const members=[...ids].map(id=>capabilitiesOf(id,agents[id]));
  const providers={},needers={};
  for(const faculty of FACULTIES){
    providers[faculty]=members.filter(member=>member.provides.includes(faculty)).map(m=>m.id);
    needers[faculty]=members.filter(member=>member.requires.includes(faculty)).map(m=>m.id);
  }
  // What an absent faculty actually costs. Only harmony's consequence has been measured — a
  // line-up with no harmony source published nothing harmonic in 25 seconds and every consumer
  // fell back independently. The others are reasoned rather than observed, and are reported as
  // advice rather than as faults so that a confident sentence is not doing the work of
  // evidence.
  const CONSEQUENCE={
    harmony:`each will fall back to its own note pool, and independent fallbacks are what `
      +`harmonically disorganised chaos is — measured: 25 seconds, 166 messages, none harmonic`,
    tuning:`each will use the fallback tuning, which is usually fine and is why this is advice`,
    pulse:`each will follow the room clock directly rather than a shared subdivision`,
    // Measured after harmony was: a corpus harmony agent stores a progression per section and
    // stays in section A until somebody publishes a section change. 45 seconds, six chord
    // publications, one distinct progression, zero section changes. With mh_PlexBOT in the
    // room the same line-up moved to a second progression inside 50 s. A harmony source with
    // no form is a loop, so this blocks too.
    form:`the harmony source will hold one section and republish the same progression forever `
      +`— measured: 45 s, 6 publications, 1 progression, 0 section changes`,
  };
  const missing=FACULTIES
    .filter(faculty=>needers[faculty].length&&!providers[faculty].length)
    .map(faculty=>{
      const who=needers[faculty].map(id=>members.find(m=>m.id===id).name);
      const count=who.length;
      return {
        faculty,needed:needers[faculty],
        // The two whose consequence has been measured are the two that block. Tuning and
        // pulse are still reasoned rather than observed, and stay advice.
        blocking:faculty==='harmony'||faculty==='form',
        says:`${count} bot${count===1?'':'s'} follow${count===1?'s':''} ${faculty} and nobody `
          +`in this line-up publishes it — ${who.join(', ')}: ${CONSEQUENCE[faculty]}`,
      };
    });
  const gaps=missing.filter(item=>item.blocking);
  return {members,providers,needers,gaps,advice:missing.filter(item=>!item.blocking),
    ready:gaps.length===0,
    inferred:members.filter(member=>member.inferred).length};
}

// Who should publish, when more than one could. Deterministic, so two machines given the same
// line-up elect the same bot without talking: the first in the line-up's own order, because
// that is the order a person chose and the order the ensemble link preserves.
export function electProvider(census,faculty){
  const candidates=census.providers[faculty]||[];
  if(!candidates.length)return null;
  return {elected:candidates[0],others:candidates.slice(1),
    because:candidates.length===1
      ?`${candidates[0]} is the only ${faculty} source here`
      :`${candidates[0]} publishes ${faculty}; ${candidates.slice(1).join(', ')} `
        +`also could, and a room with two harmonic authorities has none`};
}

// What to add to fix a gap, from the whole catalog. Suggested rather than done: adding a bot to
// somebody's ensemble is their decision, and the ensemble is theirs.
export function suggestFor(faculty,agents,{silentFirst=true}={}){
  const candidates=Object.entries(agents)
    .map(([id,definition])=>capabilitiesOf(id,definition))
    .filter(member=>member.provides.includes(faculty));
  if(!silentFirst)return candidates;
  // A silent publisher adds harmony without adding a voice, which is usually what a line-up
  // chosen for its texture actually wants.
  const silent=candidates.filter(member=>{
    const modes=agents[member.id]?.outputModes||[];
    return modes.length===0;
  });
  return [...silent,...candidates.filter(member=>!silent.includes(member))];
}
