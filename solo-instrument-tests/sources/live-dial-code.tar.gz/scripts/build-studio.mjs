#!/usr/bin/env node
// Builds what the studio page fetches (public/studio/, research/BROWSER_RENDERING_PLAN.md "The studio page") into
// public/studio/build/, git-ignored: the engines in WebAssembly and the data they play.
//   - openwind.wasm: OpenWInD's streaming player (native/openwind, its page calls src/wasm.rs) for wasm32.
//   - ness.mjs, ness.wasm: NESS (MIT; scripts/build-ness.mjs's source, its patches applied) by Emscripten (EMSDK, else
//     ~/emsdk: 6.0.12), its XML parsers stood in for by native/ness-wasm/ (a brass's files are never XML), one
//     simulation a run as the Mac's binary is run (render/synthesis/src/ness.mjs).
//   - strings.mjs, strings.wasm: the bowed strings' render driver (native/strings-model/musebots-strings.cpp, Artifastring
//     as Musebots patch it, engine.mjs's defines and generated tables) by Emscripten, against FFTW 3.3.10 single precision
//     built by Emscripten (~/emsdk-ports/fftw-3.3.10-wasm: the Mac's own FFTW's version) and Eigen's headers.
//   - strings-tables.json: the strings' tables NESS's bowed strings are planned from in the page (render/synthesis/src/
//     ness-bowed.mjs), read from the engine's build as the Mac's worker reads them; the driver's capabilities in
//     build.json (its `bodyInput`: whether it hears NESS's forces through its body).
//   - mp3.mjs, mp3.wasm: the mix's MP3 encoder (native/mp3-wasm/mp3.c), LAME 4.0 (LGPL; the Mac's ffmpeg's, Homebrew's)
//     built by Emscripten (~/emsdk-ports/lame-4.0-wasm: `emconfigure ./configure --disable-shared --disable-frontend
//     --disable-decoder`, CFLAGS -O3 -msimd128, from lame-4.0.tar.gz, sha256 3df5124d...216eb as Homebrew's).
//   - bodies/<model>/: each woodwind's body saved for the engine (render/synthesis/tools/save_body.py, through
//     render/node/winds-stream.mjs windsBody): body.json, I.bin, D.bin, law.json, rules.json; and a reed's body as NESS
//     plays it, ness.json (render/synthesis/tools/ness_woodwind_page.py --body: workers/ness_woodwind.py page_body), its
//     instrument and scores written from it in the page (render/synthesis/src/ness-woodwind.mjs).
//   - stk.mjs, stk.wasm, stk-LICENSE.txt: STK 5.0.1's waveguides (MIT-style) as Musebots patch them, the module the Mac's
//     renders play (scripts/build-stk.mjs builds it; copied here as built), a comparison beside the others.
//   - render.js: what the page takes from render/ (render/browser.mjs), bundled by esbuild.
//   - build.json: what was built, from what, and what may not be published (NOT_PUBLISHED); each body's notes its rules'
//     table holds (`table`: the engine plays those alone until its tuned table, research/OPENWIND_REALTIME_PLAN.md
//     stage 5).
// Every step niced, two jobs at most.
//   - bodies/<model>~<set>/: each experimental set's instruments (render/synthesis/workers/instrument_sets.py), saved
//     as the played bodies are, from its set's body and chart (else the played chart), said in build.json (`experimental`).
//   node scripts/build-studio.mjs [--only render,openwind,ness,strings,mp3,stk,bodies] [--models clarinet,flute] [--sets a,b]
import {parseArgs} from 'node:util';
import {spawn,spawnSync} from 'node:child_process';
import {homedir} from 'node:os';
import {copyFileSync,existsSync,mkdirSync,readFileSync,readdirSync,statSync,writeFileSync} from 'node:fs';
import {join,isAbsolute,relative} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
import {OPENWIND_WOODWINDS} from '../render/synthesis/src/physical.mjs';
import {stkHome,buildStk} from './build-stk.mjs';

const ROOT=fileURLToPath(new URL('../',import.meta.url));
export const STUDIO_BUILD=join(ROOT,'public/studio/build');
// (Cargo's own work kept where the owner sees scratch work, beside web-musebots.)
const CARGO_TARGET=join(ROOT,'..','claude-scratch','browser-rendering','openwind-wasm-target');
const BODY_FILES=Object.freeze(['body.json','I.bin','D.bin','law.json','rules.json']);
// Bodies made from geometry that may be used here but not republished, on the owner's terms (its source named in
// render/synthesis/geometry/measured.json, never on a published page).
export const NOT_PUBLISHED=Object.freeze({bassoon:'its bore\'s source may be used here but not republished',
  contrabassoon:'its bore, the bassoon\'s scaled, may be used here but not republished'});

const sha=bytes=>createHash('sha256').update(bytes).digest('hex');

// OpenWInD's streaming player for wasm32 -- `threads`, built for wasm32-wasip1-threads, its bore stepped on several cores
// as natively, each a Worker of the page's (public/studio/engines/openwind-stream.js; a cross-origin-isolated page's).
// -> {path, bytes, sha256} or {reason} where it cannot be built here.
export function buildOpenwindWasm({out=STUDIO_BUILD,threads=false}={}){
  const target=threads?'wasm32-wasip1-threads':'wasm32-unknown-unknown';
  const built=spawnSync('nice',['-n','10','cargo','build','--release','-j','2','--lib','--target',target,...threads?['--features','threads']:[],
    '--manifest-path',join(ROOT,'native/openwind/Cargo.toml'),'--target-dir',CARGO_TARGET],
    // (Its loops vectorized by WebAssembly's 128-bit SIMD, in every browser since 2023 (Safari 16.4).)
    {encoding:'utf8',env:{...process.env,RUSTFLAGS:'-C target-feature=+simd128'}});
  if(built.error||built.status!==0)return {reason:`the winds' engine did not build for ${target}${threads&&/target may not be installed|wasm32-wasip1-threads/.test(built.stderr??'')?' (rustup target add wasm32-wasip1-threads)':''}: ${(built.error?.message??built.stderr??'').trim().slice(-400)}`};
  const from=join(CARGO_TARGET,target,'release','musebots_openwind.wasm');
  mkdirSync(out,{recursive:true});
  const path=join(out,threads?'openwind-threads.wasm':'openwind.wasm');copyFileSync(from,path);
  const bytes=readFileSync(path);
  return {path,bytes:bytes.length,sha256:sha(bytes)};
}

// NESS by Emscripten: each source compiled into the scratch folder (its native objects beside its source untouched), two
// at a time, niced, then linked as an ES module whose `callMain` runs one simulation on its own file system. -> {path,
// bytes, sha256, emscripten} or {reason}.
const EMSDK=process.env.EMSDK||join(homedir(),'emsdk');
const NESS_OBJECTS=join(ROOT,'..','claude-scratch','browser-rendering','ness-wasm-objects');
export async function buildNessWasm({out=STUDIO_BUILD}={}){
  const {synthesisHome}=await import('../render/synthesis/synthesis-home.mjs');
  const source=join(synthesisHome(),'ness-src','src'),shim=join(ROOT,'native/ness-wasm'),emcc=join(EMSDK,'upstream/emscripten/emcc'),empp=join(EMSDK,'upstream/emscripten/em++');
  if(!existsSync(empp))return {reason:`Emscripten is not installed (${EMSDK})`};
  if(!existsSync(join(source,'Makefile.musebots')))return {reason:'NESS\'s source is not built here (node scripts/build-ness.mjs)'};
  const makefile=readFileSync(join(source,'Makefile.musebots'),'utf8'),list=name=>(makefile.match(new RegExp(`^${name}=(.*)$`,'m'))?.[1]??'').trim().split(/\s+/).filter(Boolean);
  // (Its XML parsers left out: native/ness-wasm/xml-parsers.cpp stands in for them.)
  const units=[...list('CPPSOURCES').filter(f=>!/ParserXML\.cpp$/.test(f)).map(f=>[join(source,f),empp]),[join(shim,'xml-parsers.cpp'),empp],
    ...list('CSOURCES').map(f=>[join(source,f),emcc]),...['csrmatrix','arralloc','pcg','banded'].map(f=>[join(source,'lib',`${f}.c`),emcc])];
  mkdirSync(NESS_OBJECTS,{recursive:true});
  const newestHeader=Math.max(...[source,join(source,'lib'),shim,join(shim,'libxml')].flatMap(dir=>readdirSync(dir).filter(f=>f.endsWith('.h')).map(f=>statSync(join(dir,f)).mtimeMs)));
  const flags=['-O3','-msimd128','-I',shim,'-I',source,'-I',join(source,'lib'),'-Wno-write-strings','-w'];
  const env={...process.env,EM_CONFIG:join(EMSDK,'.emscripten')};
  const compile=([file,tool])=>new Promise(resolve=>{
    const object=join(NESS_OBJECTS,file.split('/').pop().replace(/\.(cpp|c)$/,'.o'));
    // (An object newer than its source and every header kept: only what changed compiled again.)
    if(existsSync(object)&&statSync(object).mtimeMs>Math.max(statSync(file).mtimeMs,newestHeader))return resolve({object});
    const child=spawn('nice',['-n','10',tool,'-c',file,'-o',object,...flags],{env,stdio:['ignore','ignore','pipe']});let said='';
    child.stderr.on('data',chunk=>said+=chunk);child.once('exit',code=>resolve(code===0?{object}:{reason:`${file.split('/').pop()}: ${said.trim().slice(-400)}`}));
  });
  const objects=[];let next=0,failed=null;
  await Promise.all([0,1].map(async()=>{while(next<units.length&&!failed){const done=await compile(units[next++]);if(done.reason)failed=done.reason;else objects.push(done.object)}}));
  if(failed)return {reason:`NESS did not compile for WebAssembly: ${failed}`};
  mkdirSync(out,{recursive:true});
  const path=join(out,'ness.mjs'),linked=spawnSync('nice',['-n','10',empp,...objects,'-o',path,'-O3','-msimd128','-sMODULARIZE=1','-sEXPORT_ES6=1','-sEXPORT_NAME=createNess',
    '-sINVOKE_RUN=0','-sEXIT_RUNTIME=0','-sALLOW_MEMORY_GROWTH=1','-sSTACK_SIZE=8MB','-sFORCE_FILESYSTEM=1','-sEXPORTED_RUNTIME_METHODS=callMain,FS',
    '-sENVIRONMENT=web,worker,node'],{env,encoding:'utf8'});
  if(linked.status!==0)return {reason:`NESS did not link for WebAssembly: ${(linked.stderr??'').trim().slice(-400)}`};
  const wasm=readFileSync(join(out,'ness.wasm')),version=spawnSync(emcc,['--version'],{env,encoding:'utf8'}).stdout.split('\n')[0];
  return {path,bytes:wasm.length,sha256:sha(wasm),emscripten:version};
}

// The strings' render driver by Emscripten: its tables generated as the Mac's are (engine.mjs, by building its driver
// where any input changed), then one em++ with the Mac's sources and defines. -> {path, bytes, sha256} or {reason}.
const FFTW_WASM=process.env.MUSEBOTS_FFTW_WASM||join(homedir(),'emsdk-ports','fftw-3.3.10-wasm');
export async function buildStringsWasm({out=STUDIO_BUILD}={}){
  const {ENGINE,DEFINES,ensureDriver}=await import('../native/strings-model/engine.mjs');
  const empp=join(EMSDK,'upstream/emscripten/em++'),here=join(ROOT,'native/strings-model'),patched=join(ENGINE,'patched'),source=join(patched,'artifastring');
  if(!existsSync(empp))return {reason:`Emscripten is not installed (${EMSDK})`};
  if(!existsSync(join(FFTW_WASM,'lib','libfftw3f.a')))return {reason:`FFTW is not built for WebAssembly (${FFTW_WASM})`};
  if(!existsSync(patched)||!ensureDriver())return {reason:'the strings engine\'s source is not on this machine (native/strings-model/engine.mjs)'};
  const eigen=join(process.env.HOMEBREW_PREFIX??'/opt/homebrew','include','eigen3');
  mkdirSync(out,{recursive:true});
  const path=join(out,'strings.mjs'),env={...process.env,EM_CONFIG:join(EMSDK,'.emscripten')};
  const built=spawnSync('nice',['-n','10',empp,'-O2','-msimd128','-std=c++17',...DEFINES.split(/\s+/),...[here,join(ENGINE,'generated'),patched,source,join(ENGINE,'artifastring/build-direct'),eigen,join(FFTW_WASM,'include')].flatMap(dir=>['-I',dir]),
    join(here,'musebots-strings.cpp'),...['artifastring_instrument.cpp','artifastring_string.cpp','fft_convolution.cpp'].map(file=>join(source,file)),
    '-L',join(FFTW_WASM,'lib'),'-lfftw3f','-o',path,'-sMODULARIZE=1','-sEXPORT_ES6=1','-sEXPORT_NAME=createStrings','-sINVOKE_RUN=0','-sEXIT_RUNTIME=0',
    '-sALLOW_MEMORY_GROWTH=1','-sSTACK_SIZE=8MB','-sFORCE_FILESYSTEM=1','-sEXPORTED_RUNTIME_METHODS=callMain,FS','-sENVIRONMENT=web,worker,node','-w'],{env,encoding:'utf8'});
  if(built.status!==0)return {reason:`the strings driver did not build for WebAssembly: ${(built.stderr??'').trim().slice(-600)}`};
  const wasm=readFileSync(join(out,'strings.wasm'));
  // (What it can do, as it says it (its --capabilities: whether it hears another engine's forces through its body, its
  // `bodyInput`), for the page to offer what it can play: public/studio/band.js playable.)
  const [{stringsEngine},{default:createStrings}]=await Promise.all([import('../public/studio/engines/strings-run.js'),import(pathToFileURL(path).href)]);
  const capabilities=await stringsEngine(createStrings,await WebAssembly.compile(wasm)).capabilities();
  return {path,bytes:wasm.length,sha256:sha(wasm),capabilities};
}

// The strings' tables NESS's bowed strings are planned from in the page (render/synthesis/src/ness-bowed.mjs
// stringsTables: each type's strings and its rate factors, the contrabass's own), read from the engine's build as the
// Mac's worker reads them (workers/ness_bowed.py strings_of). -> {path, bytes, sha256} or {reason}.
export async function buildStringsTables({out=STUDIO_BUILD}={}){
  const {ENGINE}=await import('../native/strings-model/engine.mjs');
  const {stringsTables}=await import('../render/synthesis/src/ness-bowed.mjs');
  let tables;
  try{tables=stringsTables(file=>readFileSync(join(ENGINE,file),'utf8'))}catch(error){return {reason:`the strings engine's tables are not on this machine (${error.message})`}}
  mkdirSync(out,{recursive:true});
  const path=join(out,'strings-tables.json'),bytes=Buffer.from(JSON.stringify(tables));
  writeFileSync(path,bytes);
  return {path,bytes:bytes.length,sha256:sha(bytes)};
}

// The MP3 encoder by Emscripten: native/mp3-wasm/mp3.c against LAME built for WebAssembly. -> {path, bytes, sha256,
// lame} or {reason}.
const LAME_WASM=process.env.MUSEBOTS_LAME_WASM||join(homedir(),'emsdk-ports','lame-4.0-wasm');
export function buildMp3Wasm({out=STUDIO_BUILD}={}){
  const emcc=join(EMSDK,'upstream/emscripten/emcc');
  if(!existsSync(emcc))return {reason:`Emscripten is not installed (${EMSDK})`};
  if(!existsSync(join(LAME_WASM,'lib','libmp3lame.a')))return {reason:`LAME is not built for WebAssembly (${LAME_WASM})`};
  mkdirSync(out,{recursive:true});
  const path=join(out,'mp3.mjs'),env={...process.env,EM_CONFIG:join(EMSDK,'.emscripten')};
  const built=spawnSync('nice',['-n','10',emcc,'-O3','-msimd128','-I',join(LAME_WASM,'include'),join(ROOT,'native/mp3-wasm/mp3.c'),'-L',join(LAME_WASM,'lib'),'-lmp3lame',
    '-o',path,'-sMODULARIZE=1','-sEXPORT_ES6=1','-sEXPORT_NAME=createMp3','-sALLOW_MEMORY_GROWTH=1','-sENVIRONMENT=web,worker,node',
    '-sEXPORTED_FUNCTIONS=_malloc,_free,_mp3_open,_mp3_tag,_mp3_encode,_mp3_finish,_mp3_bytes,_mp3_version,_mp3_close','-sEXPORTED_RUNTIME_METHODS=HEAPU8,HEAPU16,HEAPF32,UTF8ToString'],{env,encoding:'utf8'});
  if(built.status!==0)return {reason:`the MP3 encoder did not build for WebAssembly: ${(built.stderr??'').trim().slice(-600)}`};
  const wasm=readFileSync(join(out,'mp3.wasm'));
  return {path,bytes:wasm.length,sha256:sha(wasm),lame:'4.0'};
}

// Each woodwind's saved body copied for the page, and a reed's as NESS plays it at the page's rate (`ness`: its bytes
// and sha256, or why not); and each experimental set's instruments of `models` beside them (`sets`: their names, every
// set where none is named; render/synthesis/workers/instrument_sets.py), each `<model>~<set>`, said what it is
// (`experimental`: its set, label and findings). -> {model or model~set: {files, sha256, table, ness, experimental?} |
// {reason}}.
export async function copyBodies(models=OPENWIND_WOODWINDS,{out=STUDIO_BUILD,sets=null}={}){
  const {windsBody}=await import('../render/node/winds-stream.mjs'),{RATE:STREAM_RATE}=await import('../public/studio/engines/openwind-stream.js'),done={};
  const {installedBackends}=await import('../render/synthesis/synthesis-home.mjs');
  const {instrumentSets,setEnvironment}=await import('../render/synthesis/src/instrument-sets.mjs');
  const python=(()=>{try{return installedBackends().backends?.openwind?.python}catch{return null}})();
  const every=instrumentSets(),wanted=Object.entries(every).filter(([name])=>!sets||sets.includes(name));
  const jobs=[...models.map(model=>({model,key:model})),
    ...wanted.flatMap(([set,entry])=>Object.entries(entry.instruments??{}).filter(([model])=>models.includes(model)).map(([model,instrument])=>(
      {model,key:`${model}~${set}`,set,experimental:{set,label:instrument.label,setLabel:entry.label,findings:instrument.findings??[],charted:instrument.charted}})))];
  for(const {model,key,set,experimental} of jobs){
    try{
      const folder=await windsBody(model,{set}),into=join(out,'bodies',key);
      mkdirSync(into,{recursive:true});
      const hash=createHash('sha256');
      for(const name of BODY_FILES){copyFileSync(join(folder,name),join(into,name));hash.update(readFileSync(join(into,name)))}
      const table=JSON.parse(readFileSync(join(into,'rules.json'),'utf8')).notes.map(note=>note.midi);
      done[key]={files:BODY_FILES,sha256:hash.digest('hex'),table,ness:nessBody(python,model,STREAM_RATE,into,set?setEnvironment(set,model):{}),
        ...(experimental?{experimental}:{}),...(NOT_PUBLISHED[model]?{notPublished:NOT_PUBLISHED[model]}:{})};
    }catch(error){done[key]={reason:String(error.message??error).slice(-300),...(experimental?{experimental}:{})}}
  }
  return done;
}

// A reed's body as NESS plays it at `rate`, beside its saved body in `into` (ness.json), `env` an experimental set's
// switches. -> {bytes, sha256} or {reason}.
function nessBody(python,model,rate,into,env={}){
  if(!python||!existsSync(python))return {reason:'OpenWInD is not installed here (the winds model\'s environment)'};
  const made=spawnSync('nice',['-n','10',python,'-W','ignore',join(ROOT,'render/synthesis/tools/ness_woodwind_page.py'),'--body',model,'--rate',String(rate)],{encoding:'utf8',maxBuffer:1<<24,env:{...process.env,...env}});
  if(made.status!==0)return {reason:(made.stderr??'').trim().split('\n').pop().slice(-300)};
  const bytes=Buffer.from(made.stdout.trim());
  writeFileSync(join(into,'ness.json'),bytes);
  return {bytes:bytes.length,sha256:sha(bytes)};
}

// STK's module as the Mac's renders play it (scripts/build-stk.mjs: built there where it is not yet), copied for the page,
// its licence beside it. -> {path, bytes, sha256, commit, patches} or {reason}.
export async function copyStk({out=STUDIO_BUILD}={}){
  if(!existsSync(join(stkHome(),'build.json'))){const built=await buildStk();if(built.reason)return {reason:built.reason}}
  const built=JSON.parse(readFileSync(join(stkHome(),'build.json'),'utf8'));
  mkdirSync(out,{recursive:true});
  for(const [from,to] of [['stk.mjs','stk.mjs'],['stk.wasm','stk.wasm'],['LICENSE.txt','stk-LICENSE.txt']])copyFileSync(join(stkHome(),from),join(out,to));
  const bytes=readFileSync(join(out,'stk.wasm'));
  if(sha(bytes)!==built.sha256)return {reason:'STK\'s module is not the one its build says (node scripts/build-stk.mjs)'};
  return {path:join(out,'stk.mjs'),bytes:bytes.length,sha256:built.sha256,commit:built.commit,patches:built.patches};
}

// The page's share of render/, bundled. -> {path, bytes} or {reason}.
export async function buildRender({out=STUDIO_BUILD}={}){
  try{
    const {build}=await import('esbuild'),path=join(out,'render.js');
    // (Read in the page's Workers too, which have no `window`: Node's `global`, which a vendored library reaches for there
    // (vendor/jzz.js), is their globalThis.)
    await build({entryPoints:[join(ROOT,'render/browser.mjs')],outfile:path,bundle:true,format:'esm',platform:'browser',target:'es2022',
      define:{global:'globalThis'},banner:{js:'// GENERATED by scripts/build-studio.mjs from render/browser.mjs.'}});
    return {path,bytes:readFileSync(path).length};
  }catch(error){return {reason:`render/ did not bundle for the page: ${String(error.message??error).slice(0,400)}`}}
}

if(process.argv[1]===fileURLToPath(import.meta.url)){
  const {values}=parseArgs({options:{only:{type:'string'},models:{type:'string'},sets:{type:'string'}}});
  const only=values.only?values.only.split(','):['render','openwind','ness','strings','mp3','stk','bodies'],models=values.models?values.models.split(','):OPENWIND_WOODWINDS;
  const manifestPath=join(STUDIO_BUILD,'build.json'),manifest=existsSync(manifestPath)?JSON.parse(readFileSync(manifestPath,'utf8')):{};
  if(only.includes('render')){delete manifest.synthesis;manifest.render=await buildRender();console.error('render:',manifest.render.reason??`${manifest.render.bytes} bytes`)}
  if(only.includes('openwind')){manifest.openwind=buildOpenwindWasm();console.error('openwind:',manifest.openwind.reason??`${manifest.openwind.bytes} bytes`)}
  if(only.includes('ness')){manifest.ness=await buildNessWasm();console.error('ness:',manifest.ness.reason??`${manifest.ness.bytes} bytes`)}
  if(only.includes('strings')){
    manifest.strings=await buildStringsWasm();console.error('strings:',manifest.strings.reason??`${manifest.strings.bytes} bytes`);
    manifest.stringsTables=await buildStringsTables();console.error('strings\' tables:',manifest.stringsTables.reason??`${manifest.stringsTables.bytes} bytes`);
  }
  if(only.includes('mp3')){manifest.mp3=buildMp3Wasm();console.error('mp3:',manifest.mp3.reason??`${manifest.mp3.bytes} bytes`)}
  if(only.includes('stk')){manifest.stk=await copyStk();console.error('stk:',manifest.stk.reason??`${manifest.stk.bytes} bytes`)}
  if(only.includes('bodies')){const copied=await copyBodies(models,{sets:values.sets?values.sets.split(','):null});manifest.bodies={...manifest.bodies,...copied};for(const [m,b] of Object.entries(copied))console.error(`body ${m}:`,b.reason??'copied')}
  manifest.builtAt=new Date().toISOString();
  // (Its files named from the build's folder, as the site serves them: never the Mac's own paths.)
  for(const entry of Object.values(manifest))if(entry?.path&&isAbsolute(entry.path))entry.path=relative(STUDIO_BUILD,entry.path);
  mkdirSync(STUDIO_BUILD,{recursive:true});writeFileSync(manifestPath,JSON.stringify(manifest,null,2)+'\n');
}
