#!/usr/bin/env node
// The live dial as a static site, for the owner's website (research/LIVE_DIAL_ON_THE_WEBSITE.md; the owner, 2 November
// 2026: "Test the github-pages-deployable version and push it to my bio website"; "Centralize in as modular an approach
// as possible, so that the same modules apply to the web versions as to other versions"): the Mac's page as it is
// (native/live/live.html, winds.js, strings.js, curves.js), its dial answered in the browser (native/live/site/page.js,
// dial-worker.js: native/openwind/dial.mjs itself) on the winds' engine built for WebAssembly twice -- threaded, its
// bore on the visitor's cores, and on one core for a page that is not cross-origin isolated (scripts/build-studio.mjs
// buildOpenwindWasm) -- and each published wind's body as the Mac's dial plays it (kept.mjs keptBody), with what the
// Mac's dial reads beside it: its rules' rows at each dynamic as its engine gives them (glides.mjs rulesRow), its neutral
// note where it holds (neutral.mjs neutralOf), its bore's impedance and the glides the Mac kept. The bowed strings by
// their dial (native/strings-model/dial.mjs, in strings-worker.js) on the Mac's live host built for WebAssembly
// (build-studio.mjs buildStringsLiveWasm), with what the Mac's dial measures as it goes measured here beforehand
// (monitor.mjs: the monitor's gains, rendered by the engine's driver; Artifastring's variants; the finger's damping).
// Each of those files gzipped (the flute's body 17 MB, 57 kB so), unpacked by the page. Cross-origin isolated by
// coi-serviceworker (public/vendor/coi-serviceworker/, MIT), a static host sending no headers. Not published: the
// bassoon and the contrabassoon (build-studio.mjs NOT_PUBLISHED). SOURCES.html and sources/ give each binary's licence and
// the GPL's corresponding source: the winds' crate, Artifastring as Musebots patch it with FFTW's release, and every file
// the page's code was bundled from (esbuild's own list).
//
//   node scripts/build-live-site.mjs [--out DIR] [--instruments a,b] [--check]
//     --out          the site (default: claude-scratch/live-dial-site, beside web-musebots); a folder this script made
//     --instruments  those winds alone (default: every one the dial plays, less those not published)
//     --check        the page tried in headless browsers on the site served plainly (scripts/test-live-site.mjs)
import {copyFileSync,existsSync,mkdirSync,readFileSync,rmSync,writeFileSync} from 'node:fs';
import {homedir} from 'node:os';
import {basename,dirname,join,relative} from 'node:path';
import {fileURLToPath} from 'node:url';
import {parseArgs} from 'node:util';
import {spawnSync} from 'node:child_process';
import {gzipSync} from 'node:zlib';
import {build,version as esbuildVersion} from 'esbuild';
import {buildOpenwindWasm,buildStringsLiveWasm,NOT_PUBLISHED} from './build-studio.mjs';
import {NODE} from './lib/pack-site.mjs';
import {packSource} from './lib/pack-sources.mjs';
import {SCRATCH} from '../render/rendered-audio.mjs';
import {INSTRUMENTS,KIND} from '../native/openwind/instruments.mjs';
import {keptBody,liveSingle} from '../native/openwind/kept.mjs';
import {neutralOf} from '../native/openwind/neutral.mjs';
import {rulesRow} from '../native/openwind/glides.mjs';
import {WindsStream,WINDS_RATE} from '../render/node/winds-stream.mjs';
import {DYNAMIC_VELOCITY} from '../public/shared/dynamics.js';
import {ENGINE as STRINGS_ENGINE} from '../native/strings-model/engine.mjs';
import {INSTRUMENTS as STRINGS,NEUTRAL_NOTES,STRINGS_START,startOf} from '../native/strings-model/dial.mjs';
import {FINGER,fittedHere,monitorDb,variantsHere} from '../native/strings-model/monitor.mjs';

const ROOT=fileURLToPath(new URL('../',import.meta.url)),LIVE=join(ROOT,'native/live');
const {values}=parseArgs({options:{out:{type:'string',default:join(SCRATCH,'live-dial-site')},instruments:{type:'string'},check:{type:'boolean'}}});
const out=values.out,work=join(SCRATCH,'live-dial-site-work');
const winds=(values.instruments?values.instruments.split(','):INSTRUMENTS).filter(model=>!(model in NOT_PUBLISHED));
// (The first taken up: the clarinet, as the Mac's dial's, where it is published.)
const FIRST=winds.includes('clarinet')?'clarinet':winds[0];

// (Its folder emptied only where this script made it: its mark inside.)
const MARK='.musebots-live-site';
if(existsSync(out)){
  if(!existsSync(join(out,MARK)))throw new Error(`${out}: not a folder this script built (no ${MARK}); give another`);
  rmSync(out,{recursive:true,force:true});
}
mkdirSync(out,{recursive:true});writeFileSync(join(out,MARK),'made by scripts/build-live-site.mjs\n');
const put=(path,data)=>{const to=join(out,path);mkdirSync(dirname(to),{recursive:true});writeFileSync(to,data)};
const packed=(path,data)=>put(`${path}.gz`,gzipSync(data,{level:9}));

// The engine, threaded and not.
const engines={};
for(const threads of [false,true]){
  const made=buildOpenwindWasm({out:work,threads});
  if(made.reason)throw new Error(made.reason);
  packed(basename(made.path),readFileSync(made.path));engines[basename(made.path)]=made;
}

// The page's code, bundled: the page (live.html's own module, after page.js), the dials' Workers and the winds' engine's
// cores'.
// Its absolute imports the Mac's server's paths (native/live/live.mjs): /strings.js, /winds.js, /curves.js beside the
// page, /public/... and /registry/... in the repository.
const resolved={name:'live-dial',setup(b){
  b.onResolve({filter:/^\/(strings|winds|curves|players)\.js$/},args=>({path:join(LIVE,args.path.slice(1))}));
  b.onResolve({filter:/^\/(public|registry)\//},args=>({path:join(ROOT,args.path.slice(1))}));
  b.onResolve({filter:NODE},args=>({path:args.path,namespace:'node'}));
  b.onLoad({filter:/.*/,namespace:'node'},args=>({contents:`throw new Error(${JSON.stringify(`${args.path} is not in a browser`)})`,loader:'js'}));
}};
const html=readFileSync(join(LIVE,'live.html'),'utf8'),scripts=[...html.matchAll(/<script type="module">([\s\S]*?)<\/script>/g)];
if(scripts.length!==1)throw new Error(`live.html: one module script expected, ${scripts.length} found`);
// (Node's `global` the page's globalThis, as the studio's render bundle has it: JZZ's (public/shared/ump.js) asked for
// where there is no window -- the strings' Worker.)
const inputs=new Set,warnings=[];
async function bundled(name,options){
  const result=await build({bundle:true,format:'esm',platform:'browser',target:'es2022',write:false,metafile:true,plugins:[resolved],
    logLevel:'silent',legalComments:'inline',charset:'utf8',absWorkingDir:ROOT,define:{global:'globalThis'},...options});
  for(const file of Object.keys(result.metafile.inputs))if(!file.startsWith('node:'))inputs.add(file);
  warnings.push(...result.warnings.map(w=>`${name}: ${w.location?.file??''}:${w.location?.line??''} ${w.text}`));
  put(name,result.outputFiles[0].text);
}
await bundled('live.js',{stdin:{contents:`import './native/live/site/page.js';\n${scripts[0][1]}`,resolveDir:ROOT,sourcefile:'native/live/live.html',loader:'js'}});
await bundled('dial-worker.js',{entryPoints:[join(LIVE,'site/dial-worker.js')]});
await bundled('strings-worker.js',{entryPoints:[join(LIVE,'site/strings-worker.js')]});
await bundled('openwind-thread.js',{entryPoints:[join(ROOT,'public/studio/engines/openwind-thread.js')]});
// (Isolation first, then the page, under the website's name for it (the owner, 2 November 2026: "rename the page";
// "solo instrument tests"): the Mac's own is the live dial.)
const NAME='Solo Instrument Tests';
put('index.html',html.replace(scripts[0][0],'<script type="module" src="live.js"></script>')
  .replace(/<head>/,'<head>\n<script src="coi-settings.js"></script>\n<script src="coi-serviceworker.js"></script>')
  .replace(/<title>[^<]*<\/title>/,`<title>${NAME}</title>`).replace(/<h1>[^<]*<\/h1>/,`<h1>${NAME[0]+NAME.slice(1).toLowerCase()}</h1>`));
copyFileSync(join(LIVE,'site/coi-settings.js'),join(out,'coi-settings.js'));
copyFileSync(join(ROOT,'public/vendor/coi-serviceworker/coi-serviceworker.js'),join(out,'coi-serviceworker.js'));
copyFileSync(join(ROOT,'public/vendor/coi-serviceworker/LICENSE'),join(out,'coi-serviceworker-LICENSE.txt'));

// Each wind as the Mac's dial plays it.
const instruments=[],lacking={};
const FILES=['body.json','I.bin','D.bin','law.json','rules.json'];
for(const model of winds){
  const {folder}=await keptBody(model),name=basename(folder),kind=KIND[model],brass=kind==='lips',files=[];
  const to=file=>{files.push(file);return `winds/${model}/${file}`};
  for(const file of [...FILES,...brass?['attacks.json']:[]])packed(to(file),readFileSync(join(folder,file)));
  const neutral=neutralOf(folder);
  if(neutral)packed(to('neutral.json'),JSON.stringify(neutral));else (lacking[model]??=[]).push('its neutral note (none holds: the dial takes it up on its chart\'s)');
  const impedance=brass?join(folder,'impedance.json'):join(SCRATCH,'winds-live',`impedance-${name}.json`);
  if(existsSync(impedance))packed(to('impedance.json'),readFileSync(impedance));else (lacking[model]??=[]).push('its bore\'s impedance (not yet exported on the Mac)');
  const glides=join(SCRATCH,'winds-glides',`${name}.json`);
  if(existsSync(glides))packed(to('glides.json'),readFileSync(glides));else if(!brass)(lacking[model]??=[]).push('glides (none kept: a pitch between charted notes their rows blended)');
  // (A woodwind's rules' rows, every charted note at every dynamic, from its engine: what the Mac's dial asks of it.)
  if(!brass){
    const stream=new WindsStream({model,folder,rate:WINDS_RATE,origin:0,single:liveSingle(model),priority:'background',onError:said=>console.error(`  ${model}: ${said}`)});
    try{
      await stream.ready;
      const notes=JSON.parse(readFileSync(join(folder,'rules.json'),'utf8')).notes.map(n=>n.midi),rows={};
      for(const dynamic of Object.keys(DYNAMIC_VELOCITY)){rows[dynamic]={};for(const midi of notes)rows[dynamic][String(midi)]=await rulesRow(stream,model,midi,dynamic)}
      packed(to('rows.json'),JSON.stringify(rows));
    }finally{stream.close()}
  }
  instruments.push({model,kind,name,single:liveSingle(model),files});
  console.error(`  the ${model}: ${name}`);
}
put('winds/manifest.json.gz',gzipSync(JSON.stringify({builtAt:new Date().toISOString(),first:FIRST,instruments,
  strings:STRINGS,
  withheld:Object.fromEntries(Object.entries(NOT_PUBLISHED).filter(([model])=>INSTRUMENTS.includes(model))),lacking})));

// The bowed strings as the Mac's dial plays them: its host, from the Mac's source (Emscripten's loader as it is, its
// binary gzipped), and what the Mac's dial measures as it goes (live.mjs) measured here: the started note's monitor gain
// and each instrument's neutral note's (their sounds in claude-scratch/strings-live/site-*.wav, apart from the Mac's
// dial's), Artifastring's variants, whether the body's radiation is fitted, the finger's damping.
const live=await buildStringsLiveWasm({out:work});
if(live.reason)throw new Error(live.reason);
copyFileSync(live.path,join(out,'strings-live.js'));packed('strings-live.wasm',readFileSync(join(work,'strings-live.wasm')));engines['strings-live.wasm']=live;
const {type,variant,seed}=STRINGS_START,from=join(ROOT,STRINGS_START.from);
const neutralDb=Object.fromEntries(STRINGS.filter(name=>NEUTRAL_NOTES[name]).map(name=>[name,
  monitorDb(join(ROOT,'..',NEUTRAL_NOTES[name].actions),{type:STRINGS.indexOf(name),variant:NEUTRAL_NOTES[name].variant,seed,wav:`site-${name}-neutral.wav`})]));
put('strings/manifest.json.gz',gzipSync(JSON.stringify({builtAt:new Date().toISOString(),
  dial:{type,variant,seed,from:basename(from),start:startOf(readFileSync(from,'utf8'),from),variants:variantsHere(),fitted:fittedHere(),
    gainDb:monitorDb(from,{type,variant,seed,wav:'site-start.wav'}),finger:FINGER},neutralDb})));
console.error(`  the strings: ${STRINGS.join(', ')}, from ${basename(from)}`);

// Each binary's licence and source: FFTW's release as fetched (FFTW_SOURCE), else said where it is.
const FFTW_SOURCE=join(homedir(),'emsdk-ports/downloads/fftw-3.3.10.tar.gz');
const commit=spawnSync('git',['rev-parse','HEAD'],{cwd:ROOT,encoding:'utf8'}).stdout.trim();
const uncommitted=[...inputs].filter(file=>spawnSync('git',['diff','--quiet','HEAD','--',file],{cwd:ROOT}).status!==0);
const sources={engine:packSource(out,'openwind-engine.tar.gz',join(ROOT,'native/openwind'),['Cargo.toml','Cargo.lock','src']),
  // (Artifastring's notices, its source as Musebots patch it -- not the patching's backups -- with its build's config and
  // the engine's generated tables.)
  strings:packSource(out,'strings-engine.tar.gz',dirname(dirname(STRINGS_ENGINE)),['artifastring/COPYING','artifastring/AUTHORS','artifastring/README',
    'artifastring/build-direct/config.h',...['patched','generated'].map(dir=>join(relative(dirname(dirname(STRINGS_ENGINE)),STRINGS_ENGINE),dir))],
    {exclude:['*.before-*','*.orig','*.rej','*.cells-zero-rule']}),
  code:packSource(out,'live-dial-code.tar.gz',ROOT,[...[...inputs].sort(),'scripts/build-live-site.mjs','scripts/build-studio.mjs','scripts/lib/pack-sources.mjs','scripts/lib/pack-site.mjs','native/live/site',
    'native/strings-model/musebots-strings-live.cpp','native/strings-model/musebots-body.h','native/strings-model/musebots-instruments.h','native/strings-model/musebots-noise.h',
    'native/strings-model/musebots-player.h','native/strings-model/musebots-player-noise.h','native/strings-model/patches','native/strings-model/engine.mjs',
    'native/strings-model/monitor.mjs','native/strings-model/starts'])};
mkdirSync(join(out,'sources'),{recursive:true});
const fftw=existsSync(FFTW_SOURCE)?(copyFileSync(FFTW_SOURCE,join(out,'sources',basename(FFTW_SOURCE))),`sources/${basename(FFTW_SOURCE)}`):null;
// (A page of its own, not Markdown: GitHub Pages' Jekyll renders a .md file to .html, and a link to it would fail.)
const link=path=>`<a href="${path}"><code>${path}</code></a>`;
put('SOURCES.html',`<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="color-scheme" content="light dark">
<title>${NAME}: Sources</title>
<style>body{font:15px/1.5 system-ui,sans-serif;max-width:60rem;margin:0 auto;padding:16px}table{border-collapse:collapse;width:100%}
th,td{border:1px solid #8884;padding:6px 8px;text-align:left;vertical-align:top}code{font-size:.92em;overflow-wrap:anywhere}</style>
</head>
<body>
<h1>Sources of the ${NAME.toLowerCase()}</h1>
<p>Built ${new Date().toISOString()} from the Musebots repository at ${commit}${uncommitted.length?' (with changes not yet committed)':''} by
<code>scripts/build-live-site.mjs</code>. The page is the Mac's own live dial (<code>native/live/live.html</code>, <code>winds.js</code>, <code>strings.js</code>), its
dials run in the browser (<code>native/live/site/</code>, <code>native/openwind/dial.mjs</code>, <code>native/strings-model/dial.mjs</code>).</p>
<table>
<tr><th>File</th><th>What it is</th><th>Licence</th><th>Source</th></tr>
<tr><td><code>openwind-threads.wasm.gz</code>, <code>openwind.wasm.gz</code></td><td>OpenWInD's scheme as the Musebots streaming player for winds, built for WebAssembly with and without threads (Rust's wasm32-wasip1-threads and wasm32-unknown-unknown, SIMD128)</td><td>GPL-3.0-or-later (its crate's)</td><td>${link(sources.engine)}</td></tr>
<tr><td><code>strings-live.js</code>, <code>strings-live.wasm.gz</code></td><td>Artifastring (G. Percival) as Musebots patch it, played by the Musebots live host (<code>native/strings-model/musebots-strings-live.cpp</code>), with FFTW 3.3.10 single precision and Eigen 5.0.1's headers, built for WebAssembly by Emscripten 6.0.12</td><td>GPL-3.0-or-later (Artifastring's; FFTW's GPL-2.0-or-later taken under it; Eigen's MPL-2.0)</td><td>${link(sources.strings)}, ${link(sources.code)}; FFTW 3.3.10: ${fftw?link(fftw):'<a href="https://www.fftw.org/fftw-3.3.10.tar.gz">fftw.org/fftw-3.3.10.tar.gz</a>'} (sha256 56c932549852cddcfafdab3820b0200c7742675be92179e59e6215b340e26467), built <code>--enable-float --disable-shared</code> by Emscripten; Eigen 5.0.1: <a href="https://gitlab.com/libeigen/eigen/-/releases/5.0.1">gitlab.com/libeigen/eigen</a>, unchanged</td></tr>
<tr><td><code>live.js</code>, <code>dial-worker.js</code>, <code>strings-worker.js</code>, <code>openwind-thread.js</code></td><td>the page's code, bundled by esbuild ${esbuildVersion} from the files packed in <code>${sources.code}</code></td><td>the Musebots project's</td><td>${link(sources.code)}</td></tr>
<tr><td><code>coi-serviceworker.js</code></td><td>coi-serviceworker 0.1.7 (G. Zuidhof and contributors): the page's cross-origin isolation, a static host sending no headers</td><td>MIT (${link('coi-serviceworker-LICENSE.txt')})</td><td><a href="https://github.com/gzuidhof/coi-serviceworker">github.com/gzuidhof/coi-serviceworker</a></td></tr>
<tr><td><code>winds/&lt;instrument&gt;/</code></td><td>each instrument's body, laid out for the engine from OpenWInD's (GPL-3.0-or-later) scheme of its bore, gzipped</td><td>the Musebots project's</td><td>made by <code>native/openwind/make-bodies.mjs</code></td></tr>
<tr><td><code>strings/manifest.json.gz</code></td><td>what the Mac's strings dial measures as it goes, measured beforehand: the monitor's gains (notes rendered by the engine's driver), Artifastring's variants, the started note's bowing</td><td>the Musebots project's</td><td>made by <code>scripts/build-live-site.mjs</code> (<code>native/strings-model/monitor.mjs</code>)</td></tr>
</table>
<p>Not published here: ${Object.entries(NOT_PUBLISHED).map(([model,why])=>`the ${model} (${why})`).join('; ')}.</p>
</body>
</html>
`);

console.log(JSON.stringify({out,instruments:instruments.map(i=>i.model),strings:STRINGS,neutralDb,lacking,engines:Object.fromEntries(Object.entries(engines).map(([k,v])=>[k,v.bytes])),
  sources,warnings,...(uncommitted.length?{warning:`its code carries files not as committed (${uncommitted.map(f=>relative(ROOT,join(ROOT,f))).join(', ')}): build again from main before publishing`}:{})},null,1));

if(values.check)process.exitCode=spawnSync(process.execPath,[join(ROOT,'scripts/test-live-site.mjs'),'--site',out],{stdio:'inherit'}).status;
