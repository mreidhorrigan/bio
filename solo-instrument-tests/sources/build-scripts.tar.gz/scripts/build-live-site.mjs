#!/usr/bin/env node
// The live dial as a static site, for the owner's website (research/LIVE_DIAL_ON_THE_WEBSITE.md; the owner, 2 November
// 2026: "Test the github-pages-deployable version and push it to my bio website"; "Centralize in as modular an approach
// as possible, so that the same modules apply to the web versions as to other versions"): the Mac's page as it is
// (native/live/live.html, winds.js, strings.js, curves.js), its dial answered in the browser (native/live/site/page.js,
// dial-worker.js: native/openwind/dial.mjs itself) on the winds' engine built for WebAssembly twice -- threaded, its
// bore on the visitor's cores, and on one core for a page that is not cross-origin isolated (scripts/build-studio.mjs
// buildOpenwindWasm) -- and each published wind's body as the Mac's dial plays it: its type's instance the page plays
// (docs/WIND_TYPES.md, "A type's instances": a body found with its player's settings, its settings by pitch packed
// beside it -- played.mjs playedBody -- else its made body as the batch keeps it, kept.mjs keptBody), with what the
// Mac's dial reads beside it: its rules' rows at each dynamic as its engine gives them (glides.mjs rulesRow), its neutral
// note where it holds (neutral.mjs neutralOf), its bore's impedance and the glides the Mac kept. The bowed strings by
// their dial (native/strings-model/dial.mjs, in strings-worker.js) on the Mac's live host built for WebAssembly
// (build-studio.mjs buildStringsLiveWasm), with what the Mac's dial measures as it goes measured here beforehand
// (monitor.mjs: the monitor's gains, rendered by the engine's driver; Artifastring's variants; the finger's damping).
// Each of those files gzipped (the flute's body 17 MB, 57 kB so), unpacked by the page. The musebot players -- the
// winds' and the strings' (native/openwind/soloist.mjs, native/strings-model/soloist.mjs: their band's bots, which a
// dial takes up when a piece is first asked for) -- each bundled by itself beside the dials' Workers, its MIDI 2.0 codec and the bots' planning core in WebAssembly beside it. Cross-origin isolated by
// coi-serviceworker (public/vendor/coi-serviceworker/, MIT), a static host sending no headers. Not published: any body
// build-studio.mjs NOT_PUBLISHED names (none now). The page is its `website` edition (native/live/page.json: page.mjs
// puts it together from its frame, live.html, and the modules that edition has; --edition names another), its Band,
// the studio, among them since the owner's yes of 17 November 2026: the studio's code and files laid beside the page.
//
// Published so that it is hard to read back, under the most restrictive terms the engines' licences leave room for
// (the owner, 17 November 2026: "compiled in a way that resists decompilation to the extent possible without reducing
// the efficiency of the code, and that carries do-not-train restrictions and restrictive licensing to the extent
// possible while still respecting the licenses of VTL and Openwind"; docs/SITE_LICENSING.md):
//   an engine's tier   what is linked with a GPL engine in that engine's own Worker -- the winds' dial on OpenWInD's
//                      scheme, the strings' on Artifastring, each dial's musebot player's line, the Band's engines'
//                      Workers: GPL-3.0-or-later, its complete source in sources/ with the script that builds it again
//                      (scripts/lib/engine-bundles.mjs, scripts/build-engine-bundles.mjs). SOURCES.html says each.
//   the owner's tier   everything else -- the page, the Band, the bots (which compose for a dial's musebot in a Worker
//                      of their own: native/live/site/composer-worker.js), their cores, the bodies and every other
//                      data file: all rights reserved, no source published, no training (LICENSE.html).
// Every script minified, the project's WebAssembly without its names (scripts/lib/site-protect.mjs), each file under its
// tier's notice, each page saying in its head that nothing here is offered for training or mining.
//
//   node scripts/build-live-site.mjs [--out DIR] [--instruments a,b] [--edition website] [--committed] [--check]
//     --edition      the page's modules as that edition of it has them (native/live/page.json)
//     --out          the site (default: claude-scratch/live-dial-site, beside web-musebots); a folder this script made
//     --instruments  those winds alone (default: every one the dial plays, less those not published)
//     --committed    the page's code as main has it (git HEAD), whatever the tree holds besides: another session's work
//                    in progress left out, each file so said; the engines' sources, built from the tree, as committed
//     --check        what the site is published with read off it (scripts/check-site-protection.mjs), then the page
//                    tried in headless browsers on the site served plainly (scripts/test-live-site.mjs), by main's
//                    check where it is built --committed
import {copyFileSync,existsSync,mkdirSync,readFileSync,rmSync,statSync,writeFileSync} from 'node:fs';
import {homedir} from 'node:os';
import {basename,dirname,extname,join,relative} from 'node:path';
import {fileURLToPath} from 'node:url';
import {parseArgs} from 'node:util';
import {spawnSync} from 'node:child_process';
import {gzipSync} from 'node:zlib';
import {version as esbuildVersion} from 'esbuild';
import {buildOpenwindWasm,buildStringsLiveWasm,NOT_PUBLISHED} from './build-studio.mjs';
import {packSource} from './lib/pack-sources.mjs';
import {SCRATCH} from '../render/rendered-audio.mjs';
import {INSTRUMENTS,KIND,chartOf} from '../native/openwind/instruments.mjs';
import {alternatesOf} from '../native/openwind/alternates.mjs';
import {geometryMade,impedanceFile,impedanceMade,keptBody,liveSingle} from '../native/openwind/kept.mjs';
import {playedBody} from '../native/openwind/played.mjs';
import {assemble,modulesOf,modulesScript} from '../native/live/page.mjs';
import {studioFiles,layTree,studioSources,engineFiles} from './lib/studio-site-files.mjs';
import {ENGINE_BUNDLES,siteBundle} from './lib/engine-bundles.mjs';
import {ENGINE_NOTICE,HOLDER,NAMED,OWN_NOTICE,YEAR,compactJson,minifyCss,minifyHtml,minifyJs,stripWasm} from './lib/site-protect.mjs';
import {playedInstance} from '../registry/registry.js';
import {BRASS_MUTES} from '../render/synthesis/src/brass-mutes.mjs';
import {neutralOf} from '../native/openwind/neutral.mjs';
import {jointsOf} from '../native/openwind/tune-joints.mjs';
import {rulesRow} from '../native/openwind/glides.mjs';
import {WindsStream,WINDS_RATE} from '../render/node/winds-stream.mjs';
import {DYNAMIC_VELOCITY} from '../public/shared/dynamics.js';
import {ENGINE as STRINGS_ENGINE} from '../native/strings-model/engine.mjs';
import {INSTRUMENTS as STRINGS,NEUTRAL_NOTES,STRINGS_START,startOf} from '../native/strings-model/dial.mjs';
import {FINGER,fittedHere,monitorDb,variantsHere} from '../native/strings-model/monitor.mjs';

const ROOT=fileURLToPath(new URL('../',import.meta.url)),LIVE=join(ROOT,'native/live');
const {values}=parseArgs({options:{out:{type:'string',default:join(SCRATCH,'live-dial-site')},instruments:{type:'string'},edition:{type:'string',default:'website'},committed:{type:'boolean'},check:{type:'boolean'}}});
const out=values.out,work=join(SCRATCH,'live-dial-site-work');

// (Built --committed: each file the page's code is bundled from that the tree holds changed, bundled as HEAD has it and
// kept so in work/committed/ for its sources; one not committed at all refused, as are changes not committed in the
// engines' sources, which are built from the tree.)
const git=(...args)=>spawnSync('git',args,{cwd:ROOT,encoding:'utf8',maxBuffer:1<<28});
const listed=args=>new Set(git(...args).stdout.split('\n').filter(Boolean));
const changed=values.committed?listed(['diff','--name-only','--relative','HEAD']):new Set,untracked=values.committed?listed(['ls-files','--others','--exclude-standard']):new Set;
const committed=new Map;
if(values.committed){
  const engines=git('status','--porcelain','--','native/openwind/Cargo.toml','native/openwind/Cargo.lock','native/openwind/src','native/strings-model/musebots-strings-live.cpp',
    'native/strings-model/patches',...['body','instruments','noise','player','player-noise'].map(name=>`native/strings-model/musebots-${name}.h`),'public/wasm/midi2.wasm','public/wasm/musical-core','public/wasm/body-view',
    // (The voice's engine, the Band's choir's: its programs are built from the tree by scripts/build-studio.mjs.)
    ...['Cargo.toml','Cargo.lock','build.rs','src','languages','acoustics','voices'].map(name=>`native/vocaltract/${name}`)).stdout.trim();
  if(engines)throw new Error(`--committed: the engines are built from the tree, whose sources hold changes not committed:\n${engines}`);
}
const asCommitted=path=>{
  const contents=git('show',`HEAD:./${path}`).stdout;
  committed.set(path,contents);const kept=join(work,'committed',path);mkdirSync(dirname(kept),{recursive:true});writeFileSync(kept,contents);
  return contents;
};
// (A file of the tree's, as it will be published; `read`, the same for what the page is put together from, one not
// committed refused as the bundles refuse theirs.)
const source=path=>changed.has(relative(ROOT,path))?asCommitted(relative(ROOT,path)):readFileSync(path,'utf8');
const read=path=>{if(untracked.has(relative(ROOT,path)))throw new Error(`--committed: ${relative(ROOT,path)} is not committed`);return source(path)};
// (The repository as HEAD has it, for what lists the Band's files and its engines' (scripts/lib/studio-site-files.mjs):
// a file there where HEAD holds it, read as HEAD has it where the tree holds it changed. What another session has
// begun in the tree -- a file changed, a file added, an import of it -- is then no part of a site built from main: on
// 18 November 2026 the Band's list was read from the tree, reached a file a session had just begun, and the build
// stopped at it.)
// (A file git ignores -- a third party's package under public/vendor/, what a build made -- is the tree's all the
// same: it is no session's work, and is neither in HEAD nor among the files not committed.)
const headFiles=values.committed?listed(['ls-tree','-r','--name-only','HEAD']):null;
const inHead=path=>{const file=relative(ROOT,path);return headFiles.has(file)||existsSync(path)&&!untracked.has(file)&&!changed.has(file)};
const asHead=values.committed?{has:inHead,read:source}:{};
// (Winds held back from the site until they pass its check, each with why: native/live/site/held-back.json. One asked
// for by name (--instruments) is built all the same, to try it.)
const HELD_BACK=JSON.parse(source(join(LIVE,'site/held-back.json'))).instruments;
const winds=(values.instruments?values.instruments.split(','):INSTRUMENTS.filter(model=>!(model in HELD_BACK))).filter(model=>!(model in NOT_PUBLISHED));
for(const [model,why] of Object.entries(HELD_BACK))if(!winds.includes(model))console.error(`  the ${model}: held back from the site -- ${why}`);
// (The first taken up: the clarinet, as the Mac's dial's, where it is published.)
const FIRST=winds.includes('clarinet')?'clarinet':winds[0];

// (Its folder emptied only where this script made it: its mark inside.)
const MARK='.musebots-live-site';
if(existsSync(out)){
  if(!existsSync(join(out,MARK)))throw new Error(`${out}: not a folder this script built (no ${MARK}); give another`);
  rmSync(out,{recursive:true,force:true});
}
mkdirSync(out,{recursive:true});writeFileSync(join(out,MARK),'made by scripts/build-live-site.mjs\n');
const put=(path,data)=>{const to=join(out,path);mkdirSync(dirname(to),{recursive:true});writeFileSync(to,data)};
const packed=(path,data)=>put(`${path}.gz`,gzipSync(data,{level:9}));
// (The project's WebAssembly without its names and its makers' marks: site-protect.mjs stripWasm. `stripped`: the bytes
// each lost.)
const stripped={};
const wasm=(name,bytes)=>{const made=stripWasm(bytes);stripped[name]=made.dropped.reduce((sum,d)=>sum+d.bytes,0);return Buffer.from(made.bytes)};

// The engine, threaded and not.
const engines={};
for(const threads of [false,true]){
  const made=buildOpenwindWasm({out:work,threads});
  if(made.reason)throw new Error(made.reason);
  packed(basename(made.path),wasm(basename(made.path),readFileSync(made.path)));engines[basename(made.path)]=made;
}

// The page's code, bundled (scripts/lib/engine-bundles.mjs siteBundle: its imports resolved as the Mac's server serves
// them, minified): the engines' tier -- the dials' Workers, the winds' engine's cores', each dial's musebot player's
// line -- and the owner's -- the page (live.html's own module, after page.js) and the band of bots that composes for a
// dial's musebot, in a Worker of its own. Built --committed: a file the tree holds changed is bundled as HEAD has it,
// one not committed refused.
const load=values.committed?path=>{
  if(untracked.has(path))throw new Error(`--committed: ${path} is not committed`);
  return changed.has(path)?asCommitted(path):undefined;
}:null;
// (The page's modules' code as its edition has them, one module made from its manifest (native/live/page.mjs), and a
// module's own code beside its parts of the page.)
const pageModules={name:'page-modules',setup(b){
  b.onResolve({filter:/^\/modules\.js$/},()=>({path:'modules.js',namespace:'page-modules'}));
  b.onLoad({filter:/.*/,namespace:'page-modules'},()=>({contents:modulesScript({edition:values.edition,read}),resolveDir:ROOT,loader:'js'}));
  b.onResolve({filter:/^\/modules\//},args=>({path:join(LIVE,args.path.slice(1))}));
}};
// (The page as its edition has it: its frame, each slot filled by the edition's modules (native/live/page.mjs). Where
// it has the Band, the studio's code and files are laid beside the page below, as the repository has them.)
const MODULES=modulesOf(values.edition,{read}).has.map(module=>module.name);
const whole=assemble({edition:values.edition,read});
// (The house style written into the page: on the Mac the page links public/house.css, every page's; the site has it
// in its one page.)
const HOUSE='<link rel="stylesheet" href="public/house.css">';
if(whole.split(HOUSE).length!==2)throw new Error('live.html: the house style\'s link not found once');
const html=whole.replace(HOUSE,()=>`<style>\n${source(join(ROOT,'public/house.css')).trimEnd()}\n</style>`),scripts=[...html.matchAll(/<script type="module">([\s\S]*?)<\/script>/g)];
if(scripts.length!==1)throw new Error(`live.html: one module script expected, ${scripts.length} found`);
// (Each tier's files, as esbuild lists what it bundled: the engines' are packed as their source, the owner's are not.)
const inputs={engine:new Set,own:new Set},warnings=[];
async function bundled(bundle,tier){
  const made=await siteBundle(ROOT,{...bundle,load,...tier==='own'?{notice:OWN_NOTICE,names:true,plugins:[pageModules]}:{}});
  for(const file of made.inputs)inputs[tier].add(file);
  warnings.push(...made.warnings);put(bundle.name,made.text);
}
// (The engines' tier: a dial's Worker at the site's own folder, its musebot player's line in soloist/ -- there, a
// module that finds a file from its own place, as in the repository, finds it at wasm/.)
for(const bundle of ENGINE_BUNDLES)await bundled(bundle,'engine');
// (The owner's: the page; and the band of bots, in soloist/ beside the players that ask it, its planning core and the
// MIDI 2.0 codec found at wasm/ from there.)
await bundled({name:'live.js',stdin:{contents:`import './native/live/site/page.js';\n${scripts[0][1]}`,resolveDir:ROOT,sourcefile:'native/live/live.html',loader:'js'}},'own');
await bundled({name:'soloist/composer.js',entry:'native/live/site/composer-worker.js'},'own');
const shared=[...inputs.own].filter(file=>inputs.engine.has(file));
for(const file of ['midi2.wasm','musical-core/musical_core.wasm','score-core/score_core.wasm','body-view/body_view.wasm'])put(`wasm/${file}`,wasm(file,readFileSync(join(ROOT,'public/wasm',file))));
// (Isolation first -- after only the page's start afresh on a reload, which must see the reload before isolation marks
// its own -- then the page, under the website's name for it (the owner, 2 November 2026: "rename the page";
// "solo instrument tests"): the Mac's own is the live dial.)
const NAME='Solo Instrument Tests',afresh=html.match(/<script id="afresh">[\s\S]*?<\/script>/)?.[0];
if(!afresh)throw new Error('live.html: no <script id="afresh"> to put isolation after');
put('index.html',await minifyHtml(html.replace(scripts[0][0],'<script type="module" src="live.js"></script>')
  .replace(afresh,`${afresh}\n<script src="coi-settings.js"></script>\n<script src="coi-serviceworker.js"></script>`)
  .replace(/<title>[^<]*<\/title>/,`<title>${NAME}</title>`).replace(/<h1>[^<]*<\/h1>/,`<h1>${NAME[0]+NAME.slice(1).toLowerCase()}</h1>`)));
put('coi-settings.js',await minifyJs(source(join(LIVE,'site/coi-settings.js')),{module:false}));
copyFileSync(join(ROOT,'public/vendor/coi-serviceworker/coi-serviceworker.js'),join(out,'coi-serviceworker.js'));
copyFileSync(join(ROOT,'public/vendor/coi-serviceworker/LICENSE'),join(out,'coi-serviceworker-LICENSE.txt'));

// Each wind as the Mac's dial plays it.
const instruments=[],lacking={};
const FILES=['body.json','I.bin','D.bin','law.json','rules.json'];
// (Its body's shape as its maker handed it to OpenWInD, for the page's view of it in three dimensions: the Mac's, kept
// beside its impedance, read here where the Mac has not read it yet -- kept.mjs geometryMade.)
async function shapeOf(model,folder,{mute=null,to,what,spec=null}){
  try{packed(to('geometry.json'),readFileSync(await geometryMade(model,folder,{mute,background:true,spec})))}
  catch(error){(lacking[model]??=[]).push(`${what} shape (${error.message.split('\n')[0]})`)}
}
// (A brass body's own files, packed at `under`: its tables, rules, attacks, vibrato, neutral note, impedance and shape.
// -> the files packed.)
async function brassFiles(model,folder,under,what,mute=null){
  const files=[],to=file=>{files.push(file);return `${under}/${file}`};
  for(const file of [...FILES,'attacks.json','vibrato.json','impedance.json'])packed(to(file),readFileSync(join(folder,file)));
  const neutral=neutralOf(folder);
  if(neutral)packed(to('neutral.json'),JSON.stringify(neutral));else (lacking[model]??=[]).push(`${what}'s neutral note (none holds: the dial takes it up on its chart's)`);
  await shapeOf(model,folder,{mute,to,what});
  return files;
}
for(const model of winds){
  // (Its body found with its player's settings, where the page plays one: the Mac's dial's, live.mjs --played.)
  const kind=KIND[model],brass=kind==='lips',played=brass?null:await playedBody(model,{log:said=>console.error(said)});
  const {folder}=played??await keptBody(model),name=basename(folder),files=[];
  const to=file=>{files.push(file);return `winds/${model}/${file}`};
  // (A brass instrument's mutes: each body with a mute in its bell the Mac has made, beside its open one; one not made
  // said so.)
  const mutes={};
  if(brass){
    files.push(...await brassFiles(model,folder,`winds/${model}`,'its'));
    for(const mute of Object.keys(BRASS_MUTES[model]??{})){
      try{const muted=(await keptBody(model,{mute})).folder;mutes[mute]={name:basename(muted),files:await brassFiles(model,muted,`winds/${model}/muted/${mute}`,`its ${mute} mute`,mute)}}
      catch(error){(lacking[model]??=[]).push(`its ${mute} mute's body (${error.message.split(' -- ')[0]})`)}
    }
  }else{
    for(const file of FILES)packed(to(file),readFileSync(join(folder,file)));
    if(played)packed(to('played.json'),JSON.stringify({instance:played.instance,when:played.when,heard:played.heard,flow:played.flow,mark:played.mark,settings:[...played.settings]}));
    // (Its fingerings among which its player chooses by where its fingers stand, from the chart its body was made from:
    // alternates.mjs.)
    packed(to('alternates.json'),JSON.stringify(alternatesOf(chartOf(model))));
    const neutral=neutralOf(folder);
    if(neutral)packed(to('neutral.json'),JSON.stringify(neutral));else (lacking[model]??=[]).push('its neutral note (none holds: the dial takes it up on its chart\'s)');
    // (Its players' joints found on its body, where it is made with joints: tune-joints.mjs jointsOf.)
    const joints=jointsOf(folder);
    if(joints)packed(to('joints.json'),JSON.stringify(joints));
    else if(JSON.parse(readFileSync(join(folder,'body.json'),'utf8')).points?.joints?.length)(lacking[model]??=[]).push('its players\' joints (none found on it holds: the dial takes it up with them closed)');
    // (A body found with its player's settings: its impedance and its shape read from the spec it was made from, as
    // the Mac's dial reads them -- live.mjs playedSpec -- its impedance exported here where the Mac has not yet.)
    const spec=played?join(folder,'spec.json'):null,impedance=impedanceFile(folder);
    if(played&&!existsSync(impedance))await impedanceMade(model,folder,{background:true,spec}).catch(error=>console.error(`  the ${model}'s impedance: ${error.message.split('\n')[0]}`));
    if(existsSync(impedance))packed(to('impedance.json'),readFileSync(impedance));else (lacking[model]??=[]).push('its bore\'s impedance (not yet exported on the Mac)');
    await shapeOf(model,folder,{to,what:'its',spec});
  }
  const glides=join(SCRATCH,'winds-glides',`${name}.json`);
  if(existsSync(glides))packed(to('glides.json'),readFileSync(glides));else if(!brass)(lacking[model]??=[]).push('glides (none kept: a pitch between charted notes their rows blended)');
  // (What the Mac's ear found each note's lip and breath to be, a single reed's: ear-tunings.mjs.)
  const tunings=join(SCRATCH,'winds-tunings',`${name}.json`);
  if(existsSync(tunings))packed(to('tunings.json'),readFileSync(tunings));else if(!brass)(lacking[model]??=[]).push('tunings (none kept: its ear tunes each note from its own lip and breath)');
  // (A woodwind's rules' rows, every charted note at every dynamic, from its engine: what the Mac's dial asks of it.)
  if(!brass){
    const stream=new WindsStream({model,folder,rate:WINDS_RATE,origin:0,single:liveSingle(model),priority:'background',onError:said=>console.error(`  ${model}: ${said}`)});
    try{
      await stream.ready;
      const notes=JSON.parse(readFileSync(join(folder,'rules.json'),'utf8')).notes.map(n=>n.midi),rows={};
      for(const dynamic of Object.keys(DYNAMIC_VELOCITY)){rows[dynamic]={};for(const midi of notes)rows[dynamic][String(midi)]=await rulesRow(stream,model,midi,dynamic)}
      packed(to('rows.json'),JSON.stringify(rows));
    }finally{stream.close()}
  }
  instruments.push({model,kind,name,instance:playedInstance(model,'live'),single:liveSingle(model),files,...brass?{mutes}:{}});
  console.error(`  the ${model}: ${name}${played?`, ${playedInstance(model,'live')} with its ${played.settings.size} notes' settings`:''}`);
}
put('winds/manifest.json.gz',gzipSync(JSON.stringify({builtAt:new Date().toISOString(),edition:values.edition,modules:MODULES,first:FIRST,instruments,
  strings:STRINGS,
  withheld:Object.fromEntries(Object.entries(NOT_PUBLISHED).filter(([model])=>INSTRUMENTS.includes(model))),
  heldBack:Object.fromEntries(Object.entries(HELD_BACK).filter(([model])=>!winds.includes(model))),lacking})));

// The bowed strings as the Mac's dial plays them: its host, from the Mac's source (Emscripten's loader as it is, its
// binary gzipped), and what the Mac's dial measures as it goes (live.mjs) measured here: the started note's monitor gain
// and each instrument's neutral note's (their sounds in claude-scratch/strings-live/site-*.wav, apart from the Mac's
// dial's), Artifastring's variants, whether the body's radiation is fitted, the finger's damping.
const live=await buildStringsLiveWasm({out:work});
if(live.reason)throw new Error(live.reason);
copyFileSync(live.path,join(out,'strings-live.js'));packed('strings-live.wasm',wasm('strings-live.wasm',readFileSync(join(work,'strings-live.wasm'))));engines['strings-live.wasm']=live;
const {type,variant,seed}=STRINGS_START,from=join(ROOT,STRINGS_START.from);
const neutralDb=Object.fromEntries(STRINGS.filter(name=>NEUTRAL_NOTES[name]).map(name=>[name,
  monitorDb(join(ROOT,'..',NEUTRAL_NOTES[name].actions),{type:STRINGS.indexOf(name),variant:NEUTRAL_NOTES[name].variant,seed,wav:`site-${name}-neutral.wav`})]));
put('strings/manifest.json.gz',gzipSync(JSON.stringify({builtAt:new Date().toISOString(),
  dial:{type,variant,seed,from:basename(from),start:startOf(readFileSync(from,'utf8'),from),variants:variantsHere(),fitted:fittedHere(),
    gainDb:monitorDb(from,{type,variant,seed,wav:'site-start.wav'}),finger:FINGER},neutralDb})));
console.error(`  the strings: ${STRINGS.join(', ')}, from ${basename(from)}`);

// Each engine's licence and its source: what the GPL asks for is packed under sources/, and nothing of the owner's tier
// is (docs/SITE_LICENSING.md). FFTW's release as fetched (FFTW_SOURCE), else said where it is.
const FFTW_SOURCE=join(homedir(),'emsdk-ports/downloads/fftw-3.3.10.tar.gz');
const commit=spawnSync('git',['rev-parse','HEAD'],{cwd:ROOT,encoding:'utf8'}).stdout.trim();
const uncommitted=[...new Set([...inputs.engine,...inputs.own])].filter(file=>!committed.has(file)&&spawnSync('git',['diff','--quiet','HEAD','--',file],{cwd:ROOT}).status!==0);
// (A core in WebAssembly is an engine's where one of the engines' files loads it -- the MIDI 2.0 codec, which a dial's
// Worker reads its musebot's line with -- and is then packed with its source; a core none of them loads is the owner's.)
const CORES={'wasm/midi2.wasm':{loader:'public/shared/midi2-core.js',source:['wasm/midi2-core','scripts/build-midi2-core.mjs','scripts/build-midi2.mjs']},
  'wasm/musical-core/musical_core.wasm':{loader:'public/shared/musical-core.js',source:['wasm/musical-core','scripts/build-musical-core.mjs']},
  'wasm/score-core/score_core.wasm':{loader:'public/notation/score-core.js',source:['wasm/score-core','scripts/build-score-core.mjs']},
  'wasm/body-view/body_view.wasm':{loader:'native/live/body-view.js',source:['wasm/body-view','scripts/build-body-view.mjs']}};
const engineCore=file=>inputs.engine.has(CORES[file].loader);
// (The engines' tier's code: what esbuild bundled into the engines' bundles, what bundles them again
// (build-engine-bundles.mjs), what builds the engines and lays this site, the strings' live host that Artifastring is
// built with, and the engines' cores.)
const enginePaths=[...[...inputs.engine].sort(),'scripts/build-engine-bundles.mjs','scripts/lib/engine-bundles.mjs','scripts/lib/site-protect.mjs','scripts/build-studio.mjs','scripts/build-live-site.mjs',
  ...Object.keys(CORES).filter(engineCore).flatMap(file=>CORES[file].source),
  'native/strings-model/musebots-strings-live.cpp','native/strings-model/musebots-body.h','native/strings-model/musebots-instruments.h','native/strings-model/musebots-noise.h',
  'native/strings-model/musebots-player.h','native/strings-model/musebots-player-noise.h','native/strings-model/patches','native/strings-model/engine.mjs',
  'native/strings-model/monitor.mjs','native/strings-model/starts'];
const sources={engine:packSource(out,'openwind-engine.tar.gz',join(ROOT,'native/openwind'),['Cargo.toml','Cargo.lock','src']),
  // (Artifastring's notices, its source as Musebots patch it -- not the patching's backups -- with its build's config and
  // the engine's generated tables.)
  strings:packSource(out,'strings-engine.tar.gz',dirname(dirname(STRINGS_ENGINE)),['artifastring/COPYING','artifastring/AUTHORS','artifastring/README',
    'artifastring/build-direct/config.h',...['patched','generated'].map(dir=>join(relative(dirname(dirname(STRINGS_ENGINE)),STRINGS_ENGINE),dir))],
    {exclude:['*.before-*','*.orig','*.rej','*.cells-zero-rule']}),
  // (A file bundled as HEAD has it is packed so; none that is not the engines' is added with them.)
  code:packSource(out,'dial-engines-code.tar.gz',ROOT,enginePaths,{replaced:{dir:join(work,'committed'),paths:[...committed.keys()].filter(path=>inputs.engine.has(path))}})};
mkdirSync(join(out,'sources'),{recursive:true});
// (The GNU GPL's own text, version 3, as Artifastring carries it: given with what is conveyed under it.)
const GPL=join(dirname(dirname(STRINGS_ENGINE)),'artifastring/COPYING');
if(!existsSync(GPL))throw new Error(`the GNU GPL's text not found (${GPL}): it is published with the engines`);
copyFileSync(GPL,join(out,'sources/GPL-3.0.txt'));
// The Band, where the page's edition has it: the studio's code and files beside the page as the repository has them
// -- public/, experiments/ and registry/ -- so that every module's imports resolve as they do on disk, in the site's
// own folder (scripts/lib/studio-site-files.mjs; until 17 November 2026 the studio's files were laid only with public/
// at a site's root, and an edition with the Band was refused here). Each file as it is published: a script minified
// under its tier's notice -- the engines' Workers' the engines' (studio-site-files.mjs engineFiles), the rest the
// owner's, the bots' own code keeping its names (site-protect.mjs NAMED) -- a sheet and a page minified, data made
// compact, the project's WebAssembly without its names; third parties' files (public/vendor/), Emscripten's loaders
// and the bodies as they are. Its binaries' licences and sources in a page of their own beside this site's. Built
// --committed: a file of the repository's that the tree holds changed laid as HEAD has it, one not committed refused;
// what scripts/build-studio.mjs built is laid as it is, as the engines are.
let band=null;
if(MODULES.includes('band')){
  const {files,missing,build:built}=studioFiles(asHead);
  if(missing.length)throw new Error(`the Band's files not found: ${missing.join(', ')}`);
  const theirs=new Set(engineFiles(asHead)),counts={minified:0,compact:0,asTheyAre:0};
  // (Its engines' files the tree holds changed, kept as HEAD has them for their pack, as the dials' are.)
  if(values.committed)for(const path of theirs)if(changed.has(path)&&!committed.has(path))asCommitted(path);
  const published=async(path,raw)=>{
    const kind=extname(path),text=()=>raw().toString('utf8');
    if(/^public\/vendor\//.test(path))return null;
    if(kind==='.wasm')return wasm(path,raw());
    if(/^public\/studio\/build\//.test(path)&&(kind==='.mjs'||path.includes('/bodies/')))return null;
    if(kind==='.js'||kind==='.mjs'){counts.minified++;return minifyJs(text(),{names:NAMED.test(path),notice:theirs.has(path)?ENGINE_NOTICE:OWN_NOTICE})}
    if(kind==='.css'){counts.minified++;return minifyCss(text())}
    if(kind==='.html'){counts.minified++;return minifyHtml(text(),{licence:`${'../'.repeat(path.split('/').length-1)}LICENSE.html`})}
    if(kind==='.json'){counts.compact++;return compactJson(text())}
    return null;
  };
  const served=[];
  for(const file of files){
    const path=relative(ROOT,file.from);
    if(untracked.has(path))throw new Error(`--committed: ${path} is not committed`);
    const head=changed.has(path)&&file.text==null;
    const raw=()=>file.text!=null?Buffer.from(file.text):head?spawnSync('git',['show',`HEAD:./${path}`],{cwd:ROOT,maxBuffer:1<<28}).stdout:readFileSync(file.from);
    let made;
    try{made=await published(path,raw)}catch(error){throw new Error(`${path}: not published (${String(error.message).split('\n')[0]})`)}
    if(made==null)counts.asTheyAre++;
    served.push(made!=null?{...file,text:made}:head?{...file,text:raw()}:file);
  }
  const laid=layTree(served,out);
  studioSources(out,{build:built,prefix:'public/',name:'SOURCES-band.txt',engines:[...theirs],
    replaced:values.committed?{dir:join(work,'committed'),paths:[...committed.keys()].filter(path=>theirs.has(path))}:null,scripts:['scripts/build-studio.mjs','scripts/build-live-site.mjs','scripts/lib/studio-site-files.mjs','scripts/lib/pack-sources.mjs'],
    carried:'Laid beside the page by `scripts/build-live-site.mjs` as the repository has them, under `public/`, `experiments/` and `registry/`: its scripts minified, each under its notice.'});
  band={files:laid,...counts,megabytes:+(served.reduce((sum,file)=>sum+(file.text!=null?file.text.length:statSync(file.from).size),0)/1e6).toFixed(1)};
}
const fftw=existsSync(FFTW_SOURCE)?(copyFileSync(FFTW_SOURCE,join(out,'sources',basename(FFTW_SOURCE))),`sources/${basename(FFTW_SOURCE)}`):null;
// (Pages of their own, not Markdown: GitHub Pages' Jekyll renders a .md file to .html, and a link to it would fail.)
const link=path=>`<a href="${path}"><code>${path}</code></a>`;
const OWNED=`&copy; ${YEAR} ${HOLDER}, all rights reserved (${link('LICENSE.html')})`,WITHHELD='not published';
const coreRow=(file,what,third='')=>`<tr><td><code>${file}</code></td><td>${what}</td><td>${engineCore(file)?`the Musebots project's, conveyed here with the engines it is loaded beside: GPL-3.0-or-later${third}`:`${OWNED}${third}`}</td><td>${engineCore(file)?link(sources.code):WITHHELD}</td></tr>`;
const PAGE_STYLE='<style>body{font:15px/1.5 system-ui,sans-serif;max-width:60rem;margin:0 auto;padding:16px}table{border-collapse:collapse;width:100%}\nth,td{border:1px solid #8884;padding:6px 8px;text-align:left;vertical-align:top}code{font-size:.92em;overflow-wrap:anywhere}</style>';
const pageHead=title=>`<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="color-scheme" content="light dark">
<title>${NAME}: ${title}</title>
${PAGE_STYLE}
</head>`;
put('SOURCES.html',await minifyHtml(`${pageHead('Sources')}
<body>
<h1>Sources of the ${NAME.toLowerCase()}</h1>
<p>Built ${new Date().toISOString()} from the Musebots repository at ${commit}${uncommitted.length?' (with changes not yet committed)':''}${committed.size?' as committed there':''}.
This page says, file by file, what each part of the site is, under which licence it is here, and where its source is. The terms are in ${link('LICENSE.html')}.</p>
<p>Two kinds of file are here. An <b>engine's program</b> is a physical model published under the GNU General Public License together with the code that is linked
with it in its own Worker: you may use, change and pass it on under that licence, and its complete source is in <code>sources/</code>, with the licence's text
(${link('sources/GPL-3.0.txt')}). <b>Everything else</b> &ndash; the page, the band of bots and their cores, the studio, each instrument's body and its player's settings
&ndash; is ${HOLDER}'s own, exchanges only messages and data with the engines, and is not offered under any open licence: its source is not published.</p>
<table>
<tr><th>File</th><th>What it is</th><th>Licence</th><th>Source</th></tr>
<tr><td><code>openwind-threads.wasm.gz</code>, <code>openwind.wasm.gz</code></td><td>OpenWInD's scheme (Inria) as the Musebots streaming player for winds, built for WebAssembly with and without threads (Rust's wasm32-wasip1-threads and wasm32-unknown-unknown, SIMD128)</td><td>GPL-3.0-or-later (its crate's)</td><td>${link(sources.engine)}</td></tr>
<tr><td><code>strings-live.js</code>, <code>strings-live.wasm.gz</code></td><td>Artifastring (G. Percival) as Musebots patch it, played by the Musebots live host (<code>native/strings-model/musebots-strings-live.cpp</code>), with FFTW 3.3.10 single precision and Eigen 5.0.1's headers, built for WebAssembly by Emscripten 6.0.12</td><td>GPL-3.0-or-later (Artifastring's; FFTW's GPL-2.0-or-later taken under it; Eigen's MPL-2.0)</td><td>${link(sources.strings)}, ${link(sources.code)}; FFTW 3.3.10: ${fftw?link(fftw):'<a href="https://www.fftw.org/fftw-3.3.10.tar.gz">fftw.org/fftw-3.3.10.tar.gz</a>'} (sha256 56c932549852cddcfafdab3820b0200c7742675be92179e59e6215b340e26467), built <code>--enable-float --disable-shared</code> by Emscripten; Eigen 5.0.1: <a href="https://gitlab.com/libeigen/eigen/-/releases/5.0.1">gitlab.com/libeigen/eigen</a>, unchanged</td></tr>
<tr><td>${ENGINE_BUNDLES.map(bundle=>`<code>${bundle.name}</code>`).join(', ')}</td><td>the dials: what plays each engine in its own Worker, with each dial's musebot player's line, bundled and minified by esbuild ${esbuildVersion} from the ${inputs.engine.size} files packed in <code>${sources.code}</code> (<code>node scripts/build-engine-bundles.mjs --out DIR</code> there makes them again)</td><td>GPL-3.0-or-later, as linked with the engines</td><td>${link(sources.code)}</td></tr>
<tr><td><code>index.html</code>, <code>live.js</code>, <code>coi-settings.js</code>, <code>soloist/composer.js</code></td><td>the page; and the band of bots that composes a piece for a dial's musebot, in a Worker of its own, asked by message and answering with the piece's notes</td><td>${OWNED}</td><td>${WITHHELD}</td></tr>
${coreRow('wasm/midi2.wasm','MIDI 2.0\'s core in Rust: clip files read and written, MIDI 1.0 translated, a line\'s notes traced')}
${coreRow('wasm/body-view/body_view.wasm','the view of a wind\'s shape in three dimensions: its mesh, camera and picking in Rust, no dependencies')}
${coreRow('wasm/musical-core/musical_core.wasm','the bots\' planning core in Rust, with the num-bigint and num-integer crates','; num-bigint and num-integer &copy; The Rust Project Developers, MIT or Apache-2.0')}
${coreRow('wasm/score-core/score_core.wasm','the MusicXML reader and the scores\' timing in Rust, with the num-bigint crate','; num-bigint &copy; The Rust Project Developers, MIT or Apache-2.0')}
<tr><td><code>coi-serviceworker.js</code></td><td>coi-serviceworker 0.1.7 (G. Zuidhof and contributors): the page's cross-origin isolation, a static host sending no headers</td><td>MIT (${link('coi-serviceworker-LICENSE.txt')})</td><td><a href="https://github.com/gzuidhof/coi-serviceworker">github.com/gzuidhof/coi-serviceworker</a></td></tr>
<tr><td><code>winds/&lt;instrument&gt;/</code></td><td>each instrument's body and its player's settings: data the winds' engine is given, gzipped</td><td>${OWNED}</td><td>data, as it is</td></tr>
<tr><td><code>strings/manifest.json.gz</code></td><td>what the strings' dial measures beforehand: the monitor's gains, Artifastring's variants, the started note's bowing</td><td>${OWNED}</td><td>data, as it is</td></tr>
</table>
${band?`<p>The page's Band is the Musebots studio, served under <code>public/</code>, <code>experiments/</code> and <code>registry/</code>: its engines' Workers (<code>public/studio/engines/</code>) and binaries are engines' programs, each with its licence and source in ${link('SOURCES-band.txt')}; the rest of it is ${HOLDER}'s own, as above.</p>`:''}
${Object.keys(NOT_PUBLISHED).length?`<p>Not published here: ${Object.entries(NOT_PUBLISHED).map(([model,why])=>`the ${model} (${why})`).join('; ')}.</p>`:''}
</body>
</html>
`));
// The terms, in a page of their own: what is reserved, what is not offered for training or mining, and what stands
// under its own licence whatever these terms say (the engines, and third parties' work).
const TERMS=`<h1>Terms and licences</h1>
<p>Copyright &copy; ${YEAR} ${HOLDER}. All rights reserved.</p>
<p>These terms apply to this site's folder and everything in it, whatever licence the website or the repository that holds it gives its other contents.</p>
<h2>What is reserved</h2>
<p>This site and everything served from it, other than the parts listed under &ldquo;Parts under their own licences&rdquo; below, are ${HOLDER}'s own work: the page and its
code; the Musebots &ndash; the bots, their planning and scoring cores, and the studio that composes, engraves and plays a piece; each instrument's body, its player's settings and
every other data file; and the text.</p>
<p>You may open the site in a web browser and use it there. No other permission is given. In particular, without ${HOLDER}'s written permission you may not:</p>
<ul>
<li>copy, host, redistribute, sublicense or sell them, in whole or in part;</li>
<li>modify them or make works derived from them;</li>
<li>decompile, disassemble or otherwise reverse engineer them, except to the extent the law allows this whatever a licence says;</li>
<li>use them, or any part of them, to train, fine-tune, evaluate or otherwise develop a machine-learning or artificial-intelligence model or system, or include them in a dataset made for that;</li>
<li>crawl, scrape or mine them by automated means. Text and data mining rights are expressly reserved, including under Article 4(3) of Directive (EU) 2019/790; each page says so to machines (<code>tdm-reservation: 1</code>, <code>robots: noai, noimageai</code>).</li>
</ul>
<h2>Parts under their own licences</h2>
<p>The physical models that sound here are built on free software, and stay free. Each engine, together with the code linked with it in its own Worker, is published under the
GNU General Public License, version 3 or later (${link('sources/GPL-3.0.txt')}): you may use, study, change and pass on those parts under that licence, and nothing above restricts
that. Their complete source is in <code>sources/</code>; ${link('SOURCES.html')}${band?` and ${link('SOURCES-band.txt')}`:''} say which files they are, file by file.</p>
<ul>
<li>The winds' engine: OpenWInD's scheme (Inria), in Rust for WebAssembly. GPL-3.0-or-later.</li>
<li>The bowed strings' engine: Artifastring (G. Percival), GPL-3.0-or-later, with FFTW (GPL-2.0-or-later) and Eigen (MPL-2.0).</li>
<li>The code that plays each of them in its Worker. GPL-3.0-or-later.</li>
${band?`<li>In the Band: LilyPond in WebAssembly (GPL-3.0-or-later), which engraves the score as a program of its own; LAME (LGPL-2.0); NESS (MIT); the Synthesis ToolKit (its own MIT-style licence); JZZ and fflate (MIT).</li>`:''}
<li>coi-serviceworker (MIT); the num-bigint and num-integer crates (MIT or Apache-2.0).</li>
</ul>
<p>These are separate works. Their being served beside ${HOLDER}'s own gives no licence to anything else here, and ${HOLDER}'s terms take nothing from the rights their licences give you.</p>
<h2>No warranty</h2>
<p>The site is provided as it is, without warranty of any kind.</p>`;
put('LICENSE.html',await minifyHtml(`${pageHead('Terms and licences')}
<body>
${TERMS}
<p><a href="./">Back to the page</a>.</p>
</body>
</html>
`));
// (The same in plain text, for whoever reads the folder where it is kept and not the site: a repository's own licence
// at its root does not speak for this folder.)
const plain=html=>html.replace(/<h[12]>/g,'\n\n').replace(/<\/h[12]>/g,'\n').replace(/<li>/g,'\n  - ').replace(/<\/?(p|ul)>/g,'\n').replace(/<[^>]+>/g,'')
  .replace(/&copy;/g,'(c)').replace(/&[lr]dquo;/g,'"').replace(/&ndash;/g,'-').replace(/&amp;/g,'&').split('\n').map(line=>line.replace(/\s+/g,' ').trimEnd()).join('\n').replace(/\n{3,}/g,'\n\n').trim();
put('LICENSE.txt',`${NAME} (Musebots)\n\n${plain(TERMS)}\n`);

console.log(JSON.stringify({out,edition:values.edition,modules:MODULES,...(band?{band}:{}),instruments:instruments.map(i=>i.model),heldBack:Object.keys(HELD_BACK).filter(model=>!winds.includes(model)),strings:STRINGS,neutralDb,lacking,engines:Object.fromEntries(Object.entries(engines).map(([k,v])=>[k,v.bytes])),
  sources,protection:{engineFiles:inputs.engine.size,ownFiles:inputs.own.size,inBoth:shared.length,wasmBytesDropped:stripped,engineCores:Object.keys(CORES).filter(engineCore)},warnings,...(committed.size?{asCommitted:[...committed.keys()]}:{}),...(uncommitted.length?{warning:`its code carries files not as committed (${uncommitted.map(f=>relative(ROOT,join(ROOT,f))).join(', ')}): build again from main before publishing`}:{})},null,1));

// (Checked: what it is published with, read off the site as it stands (check-site-protection.mjs); then the page tried
// in a headless browser. Built from main, checked by main's check: test-live-site.mjs --committed. Both run, whatever
// the first finds; it fails where either does.)
if(values.check){
  const run=script=>spawnSync(process.execPath,[join(ROOT,'scripts',script),'--site',out,...values.committed?['--committed']:[]],{stdio:'inherit'}).status;
  const protection=run('check-site-protection.mjs'),page=run('test-live-site.mjs');
  process.exitCode=protection||page;
}
