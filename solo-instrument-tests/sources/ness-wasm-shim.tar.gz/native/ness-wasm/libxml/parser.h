/* The types NESS's XML parsers' headers name, for its build in WebAssembly (scripts/build-studio.mjs, the studio page):
   no libxml2 there, and a brass instrument and score are Matlab-style files, never XML. xml-parsers.cpp stands in for the
   parsers themselves. Not libxml2's own declarations: only the names the headers need. */
#ifndef MUSEBOTS_NESS_WASM_LIBXML_PARSER_H
#define MUSEBOTS_NESS_WASM_LIBXML_PARSER_H
typedef unsigned char xmlChar;
typedef struct _xmlNode xmlNode;
typedef xmlNode *xmlNodePtr;
typedef struct _xmlDoc xmlDoc;
typedef xmlDoc *xmlDocPtr;
#endif
