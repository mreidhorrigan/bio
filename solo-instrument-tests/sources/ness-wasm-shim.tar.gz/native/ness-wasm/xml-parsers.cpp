// NESS's XML instrument and score parsers in its WebAssembly build (scripts/build-studio.mjs, the studio page), in place
// of InstrumentParserXML.cpp and ScoreParserXML.cpp: the brass's files are Matlab-style (InstrumentParserBrass,
// ScoreParserBrass), so an XML file is refused, as a file of another kind is, and NESS tries its next parser -- without
// building libxml2 for the browser. NESS's own sources otherwise as the Mac builds them (scripts/build-ness.mjs).
#include "InstrumentParserXML.h"
#include "ScoreParserXML.h"
#include "Logger.h"

InstrumentParserXML::InstrumentParserXML(string filename) : InstrumentParser(filename) {}
InstrumentParserXML::~InstrumentParserXML() {}
Instrument *InstrumentParserXML::parse()
{
    logMessage(1, "XML instruments are not read by this build of NESS (WebAssembly)");
    return NULL;
}

ScoreParserXML::ScoreParserXML(string filename) : ScoreParser(filename) {}
ScoreParserXML::~ScoreParserXML() {}
bool ScoreParserXML::parse(Instrument *instrument)
{
    logMessage(1, "XML scores are not read by this build of NESS (WebAssembly)");
    return false;
}
// (No duration, as a file that does not parse as XML has none: NESS reads it as its next kind.)
double ScoreParserXML::getDuration()
{
    logMessage(1, "Failed to parse score file as XML");
    return -1.0;
}
