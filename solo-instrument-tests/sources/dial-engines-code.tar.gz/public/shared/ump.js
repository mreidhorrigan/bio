// Toolkit-neutral UMP boundary. Word arrays are authoritative; decoded fields
// are transient views. Network/persistence encoding uses arrays of uint32s.
// The packets the bots send are made and read here, as the UMP specification lays them out (M2-104-UM v1.1.2,
// research-downloads/midi2/): a few shifts, wanted at once in every host the bots run in, the native plug-in's QuickJS
// among them. What reads, writes, translates and traces MIDI 2.0 -- clip files, MIDI 1.0, a sequence's notes -- is
// Rust (shared/midi2-core.js, wasm/midi2-core; the owner, 13 November 2026: "Do likewise for our MIDI 2.0 handling").
// Until that day these packets were made by JZZ (which no longer comes with this module: public/vendor/jzz.js), or after initializeMidi2 by a C99 module (wasm/midi2/bridge.c over
// S. Verissimo's midi2_msg.h), both archived in research/rust-port-archive/; test/ump.test.mjs holds the words made
// here to JZZ's.
import {midi2Core,installMidi2Core,loadMidi2Core,midi2CoreReady} from './midi2-core.js';

export const UMP_VERSION = '1.1.2';
export const DEFAULT_TPQ = 9600;
export const WORD_COUNTS = Object.freeze([1,1,1,2,2,4,1,1,2,2,2,3,3,4,4,4]);
export const integer = (value, max, name) => {
  if (!Number.isInteger(value) || value < 0 || value > max) throw new RangeError(`${name} must be an integer in 0..${max}`);
  return value;
};
export function umpPacket(words) {
  if (!Array.isArray(words) && !(words instanceof Uint32Array)) throw new TypeError('UMP requires an array of uint32 words');
  if (!words.length || words.length !== WORD_COUNTS[words[0] >>> 28]) throw new RangeError('UMP packet length does not match its message type');
  return Uint32Array.from(words, word => integer(word, 0xffffffff, 'UMP word'));
}
// A Set Tempo (UMP Flex Data, sent whole to `group`: status bank 0, status 0) at `bpm` quarters a minute: its word the
// quarter's length in tens of nanoseconds.
export const setTempo = (bpm, group=0) => [(0xD0100000|integer(group,15,'group')<<24)>>>0, Math.round(6e9/bpm)>>>0, 0, 0];
// A Set Time Signature (Flex Data, status bank 0, status 1, §7.5.4) sent whole to `group`: its numerator, its
// denominator's power of two and its 32nd notes a bar, as JZZ's umpTimeSignature wrote it; one Flex Data cannot carry
// (a numerator outside 1..255, a denominator not a power of two, 256 32nds a bar or more) refused in JZZ's words.
export function timeSignature(numerator, denominator, group=0) {
  integer(group,15,'group');
  if(Number.isInteger(numerator)&&numerator>0&&numerator<256&&Number.isInteger(denominator)&&denominator>0&&!(denominator&(denominator-1))){
    const power=Math.log2(denominator),thirtySeconds=Math.round(numerator*32/denominator);
    if(thirtySeconds<256)return [(0xD0100001|group<<24)>>>0,(numerator<<24|power<<16|thirtySeconds<<8)>>>0,0,0];
  }
  throw new RangeError(`Wrong time signature ${numerator}/${denominator}`);
}
// A Set Tempo's quarter note in units of 10 ns (Flex Data, Status Bank 0, Status 0, sent whole), on whichever Group a
// clip sends it -- until 13 November 2026 only Group 0's was read, and only addressed as this project writes it -- or
// null for any other packet.
export const tempoWord = packet => {
  const w0=packet[0]>>>0,w1=packet[1]>>>0;
  return w0>>>28===0xD&&((w0>>>22)&3)===0&&(w0&0xffff)===0&&packet.length>=2&&w1>0?w1:null;
};
// A Set Tempo's quarters a minute, or null for any other packet.
export const tempoOf = packet => {const word=tempoWord(packet);return word===null?null:6e9/word};
export function serializeUMP(words) {
  const packet = umpPacket(words), bytes = new Uint8Array(packet.length * 4), view = new DataView(bytes.buffer);
  packet.forEach((word,index) => view.setUint32(index*4,word,false));
  return bytes;
}
export function deserializeUMP(bytes) {
  bytes = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  if (!bytes.length || bytes.length % 4) throw new RangeError('UMP byte length must be a nonzero multiple of four');
  const view = new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);
  return umpPacket(Array.from({length:bytes.length/4}, (_,i) => view.getUint32(i*4,false)));
}
export function pitch79(pitch) {
  // Name the value. "Pitch 7.9" is the MIDI 2 fixed-point format, not the offending number,
  // and an error that does not say what it rejected sends whoever reads it looking for a note
  // at 7.9 semitones — which is where this one was found, in a page log, unreportable.
  if (!Number.isFinite(pitch) || pitch < 0 || pitch > 65535/512)
    throw new RangeError(`Pitch ${pitch} cannot be encoded as MIDI 2 Pitch 7.9, `
      +`which spans 0..127.998046875 semitones`);
  return Math.round(pitch * 512);
}
export function bend32(semitones, range=48) {
  if (!Number.isFinite(semitones) || !Number.isFinite(range) || range <= 0 || Math.abs(semitones) > range) throw new RangeError('Per-note bend exceeds its specified range');
  return Math.round(0x80000000 + semitones / range * (semitones < 0 ? 0x80000000 : 0x7fffffff));
}
export function bendSemitones(value, range=48) {
  return (value-0x80000000)/(value < 0x80000000 ? 0x80000000 : 0x7fffffff)*range;
}
const checkAddress = (group,channel,note) => [integer(group,15,'group'),integer(channel,15,'channel'),integer(note,127,'note index')];
// A MIDI 2.0 Channel Voice packet (MT 0x4): its status nibble, Group, Channel, the two bytes after (a note or an index,
// and an attribute or an index), and its data word.
const voice = (status,group,channel,byte2,byte3,data) =>
  Uint32Array.of((0x40000000|group<<24|status<<20|channel<<16|byte2<<8|byte3)>>>0,data>>>0);

let core=null;
export const midi2Backend = () => core?'midi2-core':'none';
// One MIDI 1.0 Channel Voice packet (MT 0x2) upgraded on its own to MIDI 2.0 (UMP v1.1.2 Appendix D), or null.
export const upgradeMidi1Channel = word => midi2Core().upgrade(integer(word>>>0,0xffffffff,'MIDI 1 UMP'));
// A MIDI 1.0 message's bytes as UMP on `group`, unchanged in protocol: MT 0x2, 0x1 or SysEx7 packets.
export const packMidi1 = (bytes,group=0) => midi2Core().pack(bytes,integer(group,15,'group'));
// Installs MIDI 2.0's core (shared/midi2-core.js) from its module's bytes or URL, once: pages and workers wait for it
// before they read a clip, translate MIDI 1.0 or trace notes. It answers {name, core, fromMidi1}.
export async function initializeMidi2({bytes,url='wasm/midi2.wasm'}={}) {
  if(!core){
    let loaded=await midi2CoreReady.catch(()=>null);
    if(!loaded){
      if(!bytes){const response=await fetch(url);if(!response.ok)throw new Error(`MIDI 2 WASM HTTP ${response.status}`);bytes=await response.arrayBuffer()}
      loaded=installMidi2Core(await loadMidi2Core({bytes}));
    }
    core=loaded;
  }
  return {name:'midi2-core',core,fromMidi1:word=>core.upgrade(word>>>0)};
}
export function noteOn({group=0,channel=0,note,pitch=note,velocity=0xffff,attribute=3,attributeData}={}) {
  checkAddress(group,channel,note);integer(velocity,65535,'velocity');integer(attribute,255,'attribute');
  const data=integer(attributeData??(attribute===3?pitch79(pitch):0),65535,'attribute data');
  return voice(9,group,channel,note,attribute,velocity<<16|data);
}
export function noteOff({group=0,channel=0,note,velocity=0,attribute=0,attributeData=0}={}) {
  checkAddress(group,channel,note);integer(velocity,65535,'release velocity');integer(attribute,255,'attribute');integer(attributeData,65535,'attribute data');
  return voice(8,group,channel,note,attribute,velocity<<16|attributeData);
}
export function perNoteBend({group=0,channel=0,note,value=0x80000000}={}) {
  checkAddress(group,channel,note);return voice(6,group,channel,note,0,integer(value,0xffffffff,'bend'));
}
// Polyphonic (per-note) pressure, status 0xA.
export function perNotePressure({group=0,channel=0,note,value=0}={}) {
  checkAddress(group,channel,note);return voice(10,group,channel,note,0,integer(value,0xffffffff,'pressure'));
}
// A Registered Per-Note Controller (status 0x0).
export function perNoteController({group=0,channel=0,note,index=74,value=0}={}) {
  checkAddress(group,channel,note);
  return voice(0,group,channel,note,integer(index,255,'controller'),integer(value,0xffffffff,'controller value'));
}
// An Assignable Per-Note Controller (status 0x1): one its receiver defines, as a family's table names it
// (docs/MIDI2_SYNTH_INPUT.md: only where no registered controller or profile names the thing).
export function assignablePerNoteController({group=0,channel=0,note,index=0,value=0}={}) {
  checkAddress(group,channel,note);
  return voice(1,group,channel,note,integer(index,255,'controller'),integer(value,0xffffffff,'controller value'));
}
// Per-Note Management (status 0xF): D detaches the note's controllers, S resets them.
export function perNoteManagement({group=0,channel=0,note,detach=true,reset=true}={}) {
  checkAddress(group,channel,note);return voice(15,group,channel,note,(detach?2:0)|(reset?1:0),0);
}
// The Registered Controller for Sensitivity of Per-Note Pitch Bend (RPN 0/7, §7.4.13): 7.25 fixed point semitones.
export function perNoteBendRange({group=0,channel=0,range=48}={}) {
  checkAddress(group,channel,0);
  if(!Number.isFinite(range)||range<0||range>=128)throw new RangeError('Per-note bend sensitivity must be in 0..128 semitones');
  return voice(2,group,channel,0,7,Math.round(range*0x2000000));
}
// Bank Select and RPN/NRPN data entry are not Control Changes in the MIDI 2.0 Protocol: a bank goes with its Program
// Change, RPN and NRPN are Registered and Assignable Controllers (§7.4.6-7.4.9; JZZ refused them too).
const NOT_CONTROL_CHANGES=new Set([0,6,32,38,98,99,100,101]);
export function channelControl({group=0,channel=0,index,value=0}={}) {
  checkAddress(group,channel,0);integer(index,127,'controller');integer(value,0xffffffff,'controller value');
  if(NOT_CONTROL_CHANGES.has(index))throw new RangeError(`Bad MIDI value: Control Change ${index} is not sent in the MIDI 2.0 Protocol`);
  return voice(11,group,channel,index,0,value);
}
// A Registered Controller (status 0x2: an RPN's bank and index, §7.4.7) or an Assignable one (0x3: an NRPN's), each
// a 32-bit value.
export function registeredController({group=0,channel=0,bank=0,index=0,value=0}={}) {
  checkAddress(group,channel,0);
  return voice(2,group,channel,integer(bank,127,'bank'),integer(index,127,'index'),integer(value,0xffffffff,'controller value'));
}
export function assignableController({group=0,channel=0,bank=0,index=0,value=0}={}) {
  checkAddress(group,channel,0);
  return voice(3,group,channel,integer(bank,127,'bank'),integer(index,127,'index'),integer(value,0xffffffff,'controller value'));
}
// Channel Pressure (status 0xD) and Pitch Bend (0xE), 32 bits each.
export function channelPressure({group=0,channel=0,value=0}={}) {
  checkAddress(group,channel,0);return voice(13,group,channel,0,0,integer(value,0xffffffff,'pressure'));
}
export function channelBend({group=0,channel=0,value=0x80000000}={}) {
  checkAddress(group,channel,0);return voice(14,group,channel,0,0,integer(value,0xffffffff,'bend'));
}
// A MIDI 2 Program Change, no bank (the channel's bank stays as it is).
export function programChange({group=0,channel=0,program}={}) {
  checkAddress(group,channel,0);integer(program,127,'program');
  return voice(12,group,channel,0,0,program<<24);
}
const KINDS=Object.freeze({0:'perNoteController',1:'assignablePerNoteController',2:'registeredController',3:'assignableController',4:'relativeRegisteredController',5:'relativeAssignableController',6:'perNoteBend',8:'noteOff',9:'noteOn',10:'perNotePressure',11:'control',12:'program',13:'channelPressure',14:'channelBend',15:'perNoteManagement'});
export function inspectUMP(words) {
  const packet=umpPacket(words),w0=packet[0],w1=packet.length>1?packet[1]:0;
  const fields={type:w0>>>28,group:(w0>>>24)&15,status:(w0>>>16)&255,channel:(w0>>>16)&15,note:(w0>>>8)&255,velocity:w1>>>16,data:w1};
  const result={...fields,packet,statusNibble:fields.status>>4,kind:'unknown'};
  if(fields.type===4) {
    result.attribute=w0&255;result.attributeData=w1&65535;
    result.key=`${fields.group}:${fields.channel}:${fields.note}`;
    result.kind=KINDS[result.statusNibble]||'unknown';
    if(result.kind==='noteOn') result.pitch=result.attribute===3?result.attributeData/512:fields.note;
  }
  return result;
}
export function timedUMP(events,{maxEvents=131072}={}) {
  if(!Array.isArray(events)||events.length>maxEvents)throw new RangeError(`UMP sequence needs 0..${maxEvents} events`);
  let previous=-Infinity;
  return events.map(event=>{
    if(!Number.isFinite(event.time)||event.time<0||event.time<previous)throw new RangeError('UMP event times must be finite, nonnegative and ordered');
    previous=event.time;
    return Object.freeze({time:event.time,packet:Object.freeze(Array.from(umpPacket(event.packet)))});
  });
}
