// A wind player's vocal tract (research/MODELING_GAPS.md, "No vocal tract"): an impedance upstream of the reed, in series
// with the bore, a sum of resonances -- each its frequency, its Q and its impedance at its peak (Pa s/m^3), a parallel
// resonance's, Z(f) = peak / (1 + jQ (f/f0 - f0/f)) -- which the engine steps inside the oscillation (native/openwind
// src/tract.rs), so that it bends a note, holds a register or chooses another, as no filter on the sound after it can.
// Written once for every wind and brass player; its measured ranges the registry's (registry/players/winds.json:
// Fritz & Wolfe 2005, Chen, Smith & Wolfe 2009), on the player's node, and the tract its players keep a shape's, its
// resonances, their heights and widths, given by its physics, not set by hand (vocal-tract-played.js, vocal-tract-
// shape.js: a measured speaker's shapes).
import {player,playerEntry} from '../../../registry/registry.js';
import {playedTract} from './vocal-tract-played.js';

export class VocalTract {
  constructor(resonances=[]){this.resonances=resonances.map(r=>({frequency:r.frequency,q:r.q,peak:r.peak}))}
  // The tract as the instrument's players keep it in normal playing at a note sounding at `hz`: the shape whose
  // resonance is held where they hold it under the notes it does not follow, and over them follows the note, some way
  // above it (Chen, Smith & Wolfe 2009 III.C: held near 600 Hz under notes of about 450 Hz, about 150 Hz above the note
  // over them, at about 9 MPa s/m^3), with every other resonance that shape has.
  static normal(instrument,hz){
    return new VocalTract(playedTract('normal',Math.max(player(instrument,'tract.normal.held'),hz+player(instrument,'tract.normal.offset'))));
  }
  // The tract bending a note: the shape whose resonance stands at `frequency` at the height bends and glissandi were
  // measured at (Chen, Smith & Wolfe 2009 III.B), the nearest the shapes come where they come no nearer.
  static bent(instrument,frequency){
    playerEntry(instrument,'tract.bend.peak');
    return new VocalTract(playedTract('bend',frequency));
  }
  // Its impedance at `hz` (complex, Pa s/m^3): what the reed meets upstream, in series with the bore's.
  impedance(hz){
    let re=0,im=0;
    for(const {frequency,q,peak} of this.resonances){
      const x=q*(hz/frequency-frequency/hz),d=1+x*x;re+=peak/d;im-=peak*x/d;
    }
    return {re,im};
  }
  magnitude(hz){const {re,im}=this.impedance(hz);return Math.hypot(re,im)}
  // As the engine's streaming player is told it (stream.rs TractLine): moved to over `seconds`.
  line(seconds){return {resonances:this.resonances,seconds}}
}
