// A wind player's vocal tract from its shape: its area function, glottis to lips, a cylinder each slice, and the
// impedance it gives at the mouth as Fritz & Wolfe 2005 computed it (doi:10.1121/1.2041287, Sec. IV) -- each slice's
// walls yielding as Sondhi & Schroeter's (1987, doi:10.1109/TASSP.1987.1165240: their wall's resistance to its mass
// r = 130 pi rad/s, its resonance 15 Hz, the tract's closed-closed breathing mode 203 Hz, its thermal and viscous
// correction 4 rad/s), the glottis a slit with its end correction and the resistance they added to meet the measured
// heights, the lungs an endless trachea, the mouthpiece put into the mouth so that the air around it between its tip
// and the lips is a branch closed at the lips, and the reed's end correction -- so that the tract's resonances, their
// frequencies, heights and widths, are its shape's, not set by hand (vocal-tract.js). Read off as the engine steps a
// tract (native/openwind src/tract.rs): a sum of parallel resonances, fitted to the impedance its shape gives.

// (Air in the mouth, warm and humid, as Story's tract models take it: 1.14 kg/m^3, 350 m/s.)
const RHO=1.14,C=350;
const WALL={resistance:130*Math.PI,resonance:30*Math.PI,breathing:406*Math.PI,thermal:4};
// (Fritz & Wolfe 2005 IV.B-D: an expert's glottis a 10 x 1.5 mm slit 3 mm thick (Mukai 1992), its end correction
// 0.85 of its equivalent radius; 1.5 MPa s/m^3 at it; a trachea of radius 9 mm; the mouthpiece some 10 mm into the
// mouth; the reed's end correction that of a baffled piston of radius 3.9 mm.)
export const AIRWAY={glottis:{area:15e-6,thickness:3e-3,resistance:1.5e6},trachea:9e-3,insertion:10e-3,piston:3.9e-3};
// (The boundary layer's constants, warm humid air: its kinematic viscosity (m^2/s), its Prandtl number and its ratio of
// specific heats -- Zwikker & Kosten's laws, as VocalWind's passive core takes them: research/VOCALWIND_BOUNDARY_LAYER.md.)
const NU=1.67e-5,PRANDTL=.71,HEATS=1.4;
// (VocalTractLab 2.4's subglottal tube (native/vocaltract src/v24/tube.rs init_static_sections): 23 sections of 1 cm,
// from the lungs 4 and 3 cm^2 then 2.5 cm^2 up to the glottis; the lungs a source of pressure, so that its lower end is
// open to sound.)
export const TRACHEA_VTL=Object.freeze({areas:Object.freeze([4,3,...Array(21).fill(2.5)].map(cm2=>cm2*1e-4)),slice:.01});

// A shape at `coords` in the space of shapes (vocal-tract-space.json space: a measured speaker's vowels' mean equivalent
// diameters and their principal shapes, each coordinate its weight on one) -> its areas (m^2), glottis to lips, each
// diameter no narrower than the space's narrowest.
export function shapeOf(coords,space){
  return space.mean.map((d,k)=>{const x=d+coords.reduce((s,c,m)=>s+c*space.modes[m][k],0);return Math.PI/4*Math.max(x,space.narrowest)**2});
}

const add=(a,b)=>[a[0]+b[0],a[1]+b[1]],mul=(a,b)=>[a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]];
const div=(a,b)=>{const d=b[0]*b[0]+b[1]*b[1];return [(a[0]*b[0]+a[1]*b[1])/d,(a[1]*b[0]-a[0]*b[1])/d]};
const sqrt=([re,im])=>{const m=Math.hypot(re,im),r=Math.sqrt((m+re)/2),i=Math.sqrt(Math.max(0,(m-re)/2));return [r,im<0?-i:i]};
const cosh=([re,im])=>[Math.cosh(re)*Math.cos(im),Math.sinh(re)*Math.sin(im)];
const sinh=([re,im])=>[Math.sinh(re)*Math.cos(im),Math.cosh(re)*Math.sin(im)];

// A slice's propagation at w (rad/s): Sondhi & Schroeter's gamma (its characteristic impedance's share of rho c / A)
// and sigma (s c its propagation constant, where s is jw for a rigid, lossless tube). With `losses` {boundary: K}, the
// slice's `area` (m^2) given: the air's viscous and thermal losses those of its boundary layer on the slice's own
// circumference (its equal-area circle's; Zwikker & Kosten's wide-duct laws: the series term (1 + j) w dv / r, the
// shunt's (heats - 1) (1 + j) w dt / r), K times, in place of Sondhi's one correction for every slice (WALL.thermal):
// losses that grow as a slice narrows. Its walls' yielding Sondhi's either way: `losses.walls` any of WALL's breathing,
// resistance and resonance (rad/s) in place of theirs.
export function wall(w,area=null,losses=null){
  const jw=[0,w],{breathing,resistance,resonance}={...WALL,...losses?.walls};
  const yielding=div([0,w*breathing**2],add(mul(add(jw,[resistance,0]),jw),[resonance**2,0]));
  let series,shunt;
  if(losses?.boundary!=null&&area>0){
    const r=Math.sqrt(area/Math.PI),dv=Math.sqrt(2*NU/w),viscous=losses.boundary*w*dv/r,thermal=losses.boundary*(HEATS-1)*w*dv/Math.sqrt(PRANDTL)/r;
    series=[viscous,viscous];shunt=add(yielding,[thermal,thermal]);
  }else{
    const alpha=sqrt([0,w*WALL.thermal]);
    series=alpha;shunt=add(yielding,alpha);
  }
  const gamma=sqrt(div(add(series,jw),add(shunt,jw)));
  return {gamma,sigma:mul(gamma,add(shunt,jw))};
}
// (The impedance at a slice's near end, `load` at its far end -- null a closed end.)
function through(load,area,length,{gamma,sigma}){
  const s=mul(sigma,[length/C,0]),z0=mul([RHO*C/area,0],gamma),ch=cosh(s),sh=sinh(s);
  if(load==null)return div(mul(z0,ch),sh);
  return div(add(mul(ch,load),mul(z0,sh)),add(div(mul(sh,load),z0),ch));
}

// The impedance at the mouth (Pa s/m^3, [re, im]) at each of `freqs` (Hz) of a tract whose `areas` (m^2, glottis to
// lips) are each `slice` long (m), with `airway` (AIRWAY's parts, any replaced); with the reed's end correction, or
// without it (`reed` false). `airway.losses` ({boundary: K}): each slice's losses its boundary layer's, K times (wall);
// `airway.subglottal` ({areas, slice}: TRACHEA_VTL): the lungs' end of the trachea open, its sections from it up to the
// glottis, in place of an endless trachea; `airway.glottis.area` none: the glottis shut.
export function mouthImpedance(areas,slice,freqs,airway=AIRWAY,{reed=true}={}){
  const {glottis,trachea,insertion,piston,losses=null,subglottal=null}={...AIRWAY,...airway,glottis:{...AIRWAY.glottis,...airway.glottis}};
  const around=Math.min(areas.length-1,Math.max(0,Math.round(insertion/slice)));
  const effective=glottis.area>0?glottis.thickness+.85*Math.sqrt(glottis.area/Math.PI):0;
  return freqs.map(f=>{
    const w=2*Math.PI*f,sondhi=losses?null:wall(w),waves=area=>sondhi??wall(w,area,losses);
    let z=null;
    if(glottis.area>0){
      if(subglottal){z=[0,0];for(const a of subglottal.areas)z=through(z,a,subglottal.slice,waves(a))}
      else z=[RHO*C/(Math.PI*trachea*trachea),0];
      z=add(through(z,glottis.area,effective,waves(glottis.area)),[glottis.resistance,0]);
    }
    for(let k=0;k<areas.length-around;k++)z=through(z,areas[k],slice,waves(areas[k]));
    let branch=null;
    for(let k=areas.length-1;k>=areas.length-around;k--)branch=through(branch,areas[k],slice,waves(areas[k]));
    const parallel=around?div(mul(z,branch),add(z,branch)):z;
    return reed?add(parallel,[0,w*RHO*.85*piston/(Math.PI*piston*piston)]):parallel;
  });
}

// Its peaks, lowest first, below `top` Hz: each its frequency, its height (Pa s/m^3) and its width as a Q (its
// half-power points' on |Z|).
export function impedancePeaks(freqs,z,top=3000){
  const m=z.map(([re,im])=>Math.hypot(re,im)),out=[];
  for(let k=1;k<freqs.length-1&&freqs[k]<=top;k++){
    if(!(m[k]>m[k-1]&&m[k]>=m[k+1]))continue;
    const half=m[k]/Math.SQRT2,edge=step=>{let j=k;while(j+step>=0&&j+step<freqs.length&&m[j]>half)j+=step;
      const a=m[j],b=m[j-step];return freqs[j]+(freqs[j-step]-freqs[j])*(half-a)/(b-a)};
    const lo=edge(-1),hi=edge(1),
      // (Its frequency between grid points: the parabola through it and its neighbours.)
      d=(m[k-1]-m[k+1])/(2*(m[k-1]-2*m[k]+m[k+1])),f=freqs[k]+d*(freqs[k+1]-freqs[k-1])/2;
    out.push({frequency:f,peak:m[k],q:f/(hi-lo)});
  }
  return out;
}

// (A sum of parallel resonances' impedance at f: tract.rs's, vocal-tract.js impedance.)
const resonating=(resonances,f)=>resonances.reduce(([re,im],{frequency,q,peak})=>{
  const x=q*(f/frequency-frequency/f),d=1+x*x;return [re+peak/d,im-peak*x/d]},[0,0]);

// The resonances the engine steps (tract.rs: each its frequency, Q and peak) whose sum is nearest the impedance `z` a
// shape gives at `freqs` (mouthImpedance's, without the reed's end correction: the reed's own inertance, not the
// tract's) from `bottom` to `top` Hz, and less and less from `top` to `fade` -- so that the next resonance's rising tail
// is not forced onto those within the band: started from its peaks from `bottom` to halfway through the fade -- a
// resonance just past the band, its tail in it, stands where it is (impedancePeaks) -- and from each
// of `seeds` (resonances, each its frequency, Q and peak) no peak is within a third of an octave of -- a resonance every
// shape has that a stronger one beside it can leave a shoulder of, not a peak; each kept within a third of an octave of
// where it began and under `fade`, its Q from 0.3 to 100. Fitted by Levenberg-Marquardt, each frequency's misfit absolute below `floor`
// Pa s/m^3 and a share of its impedance above it -- what the reed meets is the bore's impedance and the tract's in
// series, the bore's 2-90 MPa s/m^3, so that a few tenths of one matter alike wherever they are -> {resonances, misfit
// (its rms over the band, a share of the larger of the impedance and floor)}.
export function resonancesOf(freqs,z,{bottom=60,top=3200,fade=top,floor=1e7,seeds=[]}={}){
  const at=freqs.map((f,k)=>k).filter(k=>freqs[k]>=bottom&&freqs[k]<=Math.max(top,fade));
  const peaks=impedancePeaks(freqs,z,(top+fade)/2);
  const start=[...peaks,...seeds.filter(s=>!peaks.some(p=>Math.abs(Math.log2(p.frequency/s.frequency))<1/3))].sort((a,b)=>a.frequency-b.frequency);
  const bounded=(u,lo,hi)=>lo+(hi-lo)/(1+Math.exp(-u)),unbounded=(v,lo,hi)=>Math.log((v-lo)/(hi-v));
  const range=start.map(r=>({f:[r.frequency*2**(-1/3),Math.min(r.frequency*2**(1/3),Math.max(top,fade))],q:[Math.log(.3),Math.log(100)],p:[Math.log(r.peak/10),Math.log(r.peak*10)]}));
  const unpack=t=>range.map((b,i)=>({frequency:bounded(t[3*i],...b.f),q:Math.exp(bounded(t[3*i+1],...b.q)),peak:Math.exp(bounded(t[3*i+2],...b.p))}));
  let theta=start.flatMap((r,i)=>[0,unbounded(Math.log(Math.min(Math.max(r.q,.31),99)),...range[i].q),0]);
  // (Above `top` to `fade`, its weight falling as a raised cosine to none.)
  const faded=f=>f<=top?1:Math.cos(Math.PI/2*Math.min((f-top)/(fade-top),1))**2;
  const weight=at.map(k=>faded(freqs[k])/Math.max(Math.hypot(...z[k]),floor));
  const residual=t=>{const r=unpack(t),out=[];at.forEach((k,i)=>{const m=resonating(r,freqs[k]);out.push((m[0]-z[k][0])*weight[i],(m[1]-z[k][1])*weight[i])});return out};
  const cost=r=>r.reduce((s,v)=>s+v*v,0);
  let r=residual(theta),c=cost(r),lambda=1e-2;
  for(let it=0;it<80&&theta.length;it++){
    const J=theta.map((_,j)=>{const t=theta.slice();t[j]+=1e-6;return residual(t).map((v,i)=>(v-r[i])/1e-6)});
    const n=theta.length,A=Array.from({length:n},(_,a)=>Array.from({length:n},(_,b)=>J[a].reduce((s,v,i)=>s+v*J[b][i],0)));
    const g=Array.from({length:n},(_,a)=>J[a].reduce((s,v,i)=>s+v*r[i],0));
    let improved=false;
    for(let tries=0;tries<8&&!improved;tries++){
      const M=A.map((row,a)=>row.map((v,b)=>a===b?v*(1+lambda)+1e-12:v)),step=solve(M,g.map(v=>-v));
      const t=theta.map((v,j)=>v+step[j]),rt=residual(t),ct=cost(rt);
      if(ct<c){improved=c-ct>1e-9*c;theta=t;r=rt;c=ct;lambda=Math.max(lambda/3,1e-7)}else lambda*=4;
    }
    if(!improved)break;
  }
  // (Its misfit over the band, where it is weighed in full.)
  const band=at.map((k,i)=>freqs[k]<=top?i:-1).filter(i=>i>=0),inBand=r.filter((v,i)=>band.includes(i>>1));
  return {resonances:unpack(theta),misfit:Math.sqrt(inBand.reduce((s,v)=>s+v*v,0)/(2*band.length))};
}
// (Gaussian elimination with partial pivoting.)
function solve(A,b){
  const n=b.length,M=A.map((row,i)=>[...row,b[i]]);
  for(let i=0;i<n;i++){let p=i;for(let k=i+1;k<n;k++)if(Math.abs(M[k][i])>Math.abs(M[p][i]))p=k;[M[i],M[p]]=[M[p],M[i]];
    for(let k=i+1;k<n;k++){const f=M[k][i]/M[i][i];for(let j=i;j<=n;j++)M[k][j]-=f*M[i][j]}}
  const x=new Array(n).fill(0);for(let i=n-1;i>=0;i--){let s=M[i][n];for(let j=i+1;j<n;j++)s-=M[i][j]*x[j];x[i]=s/M[i][i]}
  return x;
}
