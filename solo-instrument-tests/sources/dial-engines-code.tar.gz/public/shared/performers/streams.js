// Auditory streaming: where a figure's notes hold together as one line and where they split into voices, a compound
// melody (the owner, 5 November 2026: "the 'musically correct' way to conceptualize two alternating notes far apart from
// each other (really, this intuition applies the more the further the notes are from each other and the faster they
// move/alternate) is as a compound melody"; "there is a threshold past which ornamentation transitions to compound
// melody"). One continuum, measured (registry/perception/streaming.json): van Noorden (1975) found two boundaries for a
// tone between two others --
//   - **the fission boundary** (about a semitone): below it the three always hold together, one stream;
//   - **the temporal coherence boundary**: above it they never do, its interval rising with the gap from the end of the
//     tone before to the start of the tone after (2T - D for equal tones: Fig. 5.11) -- so the faster the notes, and the
//     longer each sounds into the next (legato, overlapping), the narrower it is;
// and between them either, as the listener attends -- one line, as a listener in general tries to hear (his section
// 4.6), but for attending to one string alone. A note is judged apart (a voice of its own) past the registry's threshold,
// a share from the one boundary to the other: at the coherence boundary, where Miller and Heise's (1950) trill threshold
// stands at its gap (a trill heard as two tones past 2 to 3 semitones, legato at 10 notes a second). He explains the
// boundary as a tracker following the tones' pitch only so fast (his section 5.0): so a note goes on from one before it,
// past the notes between, where the tracker reaches it from that note in the time between them and each note between
// leaves the line from the one to the other by more than it can follow -- for two notes alternating, the interval between
// them, his measured case; for a note on a scale or an arpeggio, which lies within the line it is on, never, as such a
// line holds together however fast (his three-tone sequences: the tone after next decides). The room's reverberation,
// which lengthens what sounds of every note, is not heard here (research/MODELING_GAPS.md).
import {perception,setting} from '../../../registry/registry.js';

const FISSION=perception('fission-boundary');
const COHERENCE=perception('temporal-coherence-boundary');
const THRESHOLD=setting('streaming','threshold');

// The temporal coherence boundary (semitones) at a gap (s): read between the measured points, and on beyond the last
// at its last slope.
export function coherenceBoundary(gap){
  const at=Math.max(0,Number(gap)||0);
  let k=1;while(k<COHERENCE.length-1&&at>COHERENCE[k][0])k++;
  const [x0,y0]=COHERENCE[k-1],[x1,y1]=COHERENCE[k];
  return y0+(y1-y0)*(at-x0)/(x1-x0);
}
// The boundaries at a gap, the narrower first (where the coherence boundary falls below the fission boundary, at the
// shortest gaps, they meet).
const bounds=gap=>{const c=coherenceBoundary(gap);return [Math.min(FISSION,c),Math.max(FISSION,c)]};
// How far apart a note stands from its neighbours (0 to 1): 0 at or below the fission boundary, 1 at or above the
// coherence boundary, between as far as its interval (semitones) is between them.
export function apartness(interval,gap){
  const [low,high]=bounds(gap),size=Math.abs(interval);
  if(high<=low)return size>low?1:0;
  return Math.max(0,Math.min(1,(size-low)/(high-low)));
}
// The least interval heard apart at a gap: the threshold's place between the boundaries.
export function streamingInterval(gap){const [low,high]=bounds(gap);return low+(high-low)*THRESHOLD}
// Whether a note stands apart: its interval past the threshold.
export const streams=(interval,gap)=>Math.abs(interval)>streamingInterval(gap);
// The gap of notes `seconds` apart, each sounding `sounding` (s): from the end of the note before to the start of the
// note after.
export const gapOf=(seconds,sounding=seconds)=>seconds+seconds-sounding;

// How far a pitch leaves the line between two others (semitones): none within their span, else its distance outside it.
const outside=(pitch,a,b)=>Math.max(0,Math.min(a,b)-pitch,pitch-Math.max(a,b));
// Whether a note alone between two others is heard apart from the line they make (as streamsOf hears it): the one
// reached from the other across the gap between them (s), and the note leaving that line by more than can be followed.
export const heardApart=(before,pitch,after,gap)=>!streams(after-before,gap)&&streams(outside(pitch,before,after),gap);
// Whether a line's note `n` is heard going on from its note `m`, past the notes between: reached from it in the gap from
// its end, and each note between apart from the line from the one to the other.
function goesOn(notes,m,n){
  const from=notes[m],to=notes[n],gap=to.start-from.end;
  if(streams(to.pitch-from.pitch,gap))return false;
  for(let k=m+1;k<n;k++)if(!streams(outside(notes[k].pitch,from.pitch,to.pitch),gap))return false;
  return true;
}
// The voices a line's notes are heard in: [{pitch, start, end} (semitones, s)] -> a voice's number for each note, the
// first 0. A note goes on from the nearest note before it it is heard going on from past others, else from the note
// before it; a note another goes on from past it begins a voice of its own -- one note alone where nothing goes on from
// it (a fast arpeggio's peak, heard apart). As many voices as the line makes: past the three a listener follows
// (registry/perception/polyphony.json) they are heard as a texture, not each, but heard apart from one another still.
export function streamsOf(notes){
  const before=notes.map((_,n)=>{for(const m of [...Array(Math.max(0,n-1)).keys()].reverse())if(goesOn(notes,m,n))return m;return n-1});
  const next=new Map;
  before.forEach((m,n)=>{if(m>=0)next.set(m,Math.max(next.get(m)??n,n))});
  const labels=[];let voices=0;
  before.forEach((m,n)=>labels.push(m>=0&&next.get(m)===n?labels[m]:voices++));
  return labels;
}
