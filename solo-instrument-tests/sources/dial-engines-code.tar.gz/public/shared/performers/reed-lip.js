// A single reed's lip pressed or eased from a note's own (the owner, 7 November 2026: "we need that lip bending added";
// "loosening the embouchure would allow the note to bend down"): its players' lip (registry/players/winds.json
// reed-woodwind lip) moving the reed as a clarinet's on an artificial mouth was measured to move (A. Almeida, D. George,
// J. Smith & J. Wolfe 2013, doi:10.1121/1.4816538). The lip's force closes the reed's tip as the mouth's pressure does
// over the reed's equivalent area -- its opening at rest h0 = h00 - F/(Ka Ar) (Gaillard, Koehl & Gazengel 2024, eq. 4) -- so that a
// newton more closes it by its opening over its closing pressure times that area; and eased, the reed lifts off the lay,
// its vibrating length the longer by `lengthening` a newton (fitted), its pulsation as the square of the length's
// inverse and its moving mass and area as the length, a cantilever's. Pressed harder than the note's own, the reed lies
// on the lay to the lip already: its length held. On a kernel row (the engine's reed columns, openwind controls.rs
// Reed::Physical), its breath held as its share of the closing pressure, as the dial's breath is.
import {playerEntry} from '../../../registry/registry.js';

// Its players' lip: {area (m^2), lengthening (1/N)}, or null where the registry has none for it.
export function reedLip(model){
  try{return {area:playerEntry(model,'lip.area').value,lengthening:playerEntry(model,'lip.lengthening').value}}catch{return null}
}

// The most a lip may press past the note's own: this share of the force that shuts the reed's tip.
export const PRESSED_MOST=.9;
// The force (N) past a note's own that shuts its reed: its closing pressure over the lip's area.
export const shutting=(closing,lip)=>closing*lip.area;

// A kernel row with its lip `force` N past the note's own (negative: eased): `at` its reed's columns by name
// (gamma, zeta, kappa, qfactor, pulsation, contact_stifness, closing_pressure), `sized` its reed's scale ({zc, rho,
// width}: its bore's characteristic impedance, its air's density, its reed's width), `damping` its lip's damping
// (law.json lipDamping {tip, exponent}: woodwind_reeds.py lip_damping) or none. Pressed no further than PRESSED_MOST of
// the force that shuts it.
export function lippedRow(row,at,sized,lip,force,damping=null){
  if(!force)return row;
  const {zc,rho,width}=sized,pc=row[at.closing_pressure],wr=row[at.pulsation];
  const y0=row[at.zeta]*Math.sqrt(rho*pc/2)/(zc*width),sr=row[at.kappa]*pc/(y0*zc*wr),g=wr/row[at.qfactor];
  const f=Math.min(force,PRESSED_MOST*shutting(pc,lip)),lambda=1+lip.lengthening*Math.max(0,-f);
  // (Its stiffness, mass times pulsation squared, as the length's inverse cubed; its closing pressure, stiffness times
  // opening over area, as its fourth power.)
  const y=y0*(1-f/shutting(pc,lip)),w=wr/lambda**2,s=sr*lambda,closing=pc*y/(y0*lambda**4);
  const damped=damping?g*((damping.tip-y)/(damping.tip-y0))**damping.exponent:g;
  const out=[...row];
  out[at.closing_pressure]=closing;out[at.pulsation]=w;out[at.qfactor]=w/damped;
  out[at.zeta]=zc*y*width*Math.sqrt(2/(rho*closing));out[at.kappa]=y*zc*s*w/closing;
  out[at.contact_stifness]=row[at.contact_stifness]*(wr/w)**2;
  return out;
}
