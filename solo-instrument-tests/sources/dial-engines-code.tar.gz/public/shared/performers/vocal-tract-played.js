// The vocal tract as clarinettists keep it as they play (vocal-tract-space.json, baked by scripts/build-vocal-tract-
// space.mjs from a measured speaker's shapes): in normal playing, its resonance kept at a frequency at the height they
// were measured keeping it, and bending a note, at a bend's (Chen, Smith & Wolfe 2009) -- each a shape, its resonances
// as the engine steps them (native/openwind src/tract.rs; vocal-tract.js). Between two baked rows, their geometric
// blend: each resonance matched by its place, and one only one row has brought in as that row is neared. And a
// player's tract as its own shape gives it round the mouthpiece (research/PLAYER_TRACT_PLAN.md, A): the resonances the
// engine steps for a shape, as each note of a player's settings is found at one (shapedTract).
import SPACE from './vocal-tract-space.json' with {type:'json'};
import {impedancePeaks,mouthImpedance,resonancesOf,shapeOf,TRACHEA_VTL} from './vocal-tract-shape.js';

// The resonances of the tract `how` ('normal' or 'bend') whose kept resonance is at `target` Hz: the first row's below
// the first, the last's (the nearest the shapes come) above the last.
export function playedTract(how,target,baked=SPACE){
  const {rows}=baked[how],step=rows[1].target-rows[0].target;
  const at=Math.min(Math.max((target-rows[0].target)/step,0),rows.length-1),k=Math.min(Math.floor(at),rows.length-2),share=at-k;
  const [a,b]=[rows[k].resonances,rows[k+1].resonances],blend=(u,v)=>u**(1-share)*v**share;
  return Array.from({length:Math.max(a.length,b.length)},(_,i)=>{
    const p=a[i],q=b[i];
    if(p&&q)return {frequency:blend(p.frequency,q.frequency),q:blend(p.q,q.q),peak:blend(p.peak,q.peak)};
    const only=p??q;
    return {...only,peak:only.peak*(p?1-share:share)};
  }).filter(r=>r.peak>0);
}

// (The air round the inserted mouthpiece, from the reed's tip to the lips, a slice of the space's (some 4 mm) each:
// some 2.0 cm^2, as Fritz & Wolfe 2005 found it by inverting two players' measured curves, "ee" and "aw" alike, and
// the lips sealed on it -- "At the mouth end, the area function is set equal to the cross section of the clarinet
// mouthpiece, 15 mm from the end" (IV.E; their Figs. 10 and 11: 1.52 and 1.8 cm^2): a player's mouth opens no wider
// than its mouthpiece (the owner, 14 November 2026: "a player cannot open their mouth beyond the mouthpiece while
// playing"). Three slices: the mouthpiece put 10 mm into the mouth (vocal-tract-shape.js AIRWAY).)
export const FRONT=Object.freeze([2.0e-4,2.0e-4,1.52e-4]);
// (An expert's glottis, a slit of 15 mm^2 (Mukai 1992, as Fritz & Wolfe 2005 IV.B take it): the measured players'
// curves are a nearly shut glottis's, and opening it moves our airway's peaks 1 to 3 dB (research/MODELING_GAPS.md).)
export const GLOTTIS=15e-6;
// (The airway's losses held to living tracts (research/player-tract/walls-fit.mjs, its result walls-fit-20261114.json:
// Hanna, Smith & Wolfe 2016's seven men, the glottis shut, through lips sealed on an impedance head): the boundary
// layer on each slice's circumference 6.044 times; the walls' breathing mode 1389.1 rad/s (221 Hz) and their
// resistance to their mass 626.93 /s. Behind the glottis VocalTractLab 2.4's trachea, its lungs' end open; no
// resistance fitted at the glottis (research/MODELING_GAPS.md, "The airway's losses stand at the glottis, not in the
// tract"; research/player-tract/glottis-check.mjs).)
export const LOSSES=Object.freeze({boundary:6.044,walls:Object.freeze({breathing:1389.1,resistance:626.93})});
export const PLAYERS_AIRWAY=Object.freeze({glottis:Object.freeze({area:GLOTTIS,thickness:3e-3,resistance:0}),losses:LOSSES,subglottal:TRACHEA_VTL});
// (A shape's resonances fitted on 260 frequencies from 100 Hz to 4 kHz, evenly in octaves, as the baked tracks' rows
// were (scripts/build-vocal-tract-space.mjs) and the compiled fit takes them (tract_shape.rs fit_grid), seeded with the
// middle shape's first resonance, which every player's has (Fritz & Wolfe 2005, III; Space::baked).)
const FIT=Array.from({length:260},(_,k)=>100*2**(k/259*Math.log2(4000/100)));
const seeds=new WeakMap();
const seedOf=baked=>{
  if(!seeds.has(baked)){const {space}=baked;seeds.set(baked,impedancePeaks(FIT,mouthImpedance(shapeOf(space.modes.map(()=>0),space),space.slice,FIT,space.airway,{reed:false})).slice(0,1))}
  return seeds.get(baked);
};

// The bounds of a tract's coordinates: each the widest of the speaker's eleven vowels' (Story 2008) and the shapes
// that give the resonances clarinettists were measured keeping in normal playing and in a bend (vocal-tract-space.json
// `normal`, `bend`: Chen, Smith & Wolfe 2009) -- 39 of the normal track's 56 shapes stand past the vowels', up to 1.6 of
// their spreads on the fourth coordinate: a player's mouth round a mouthpiece is no speaker's vowel (the owner, 14
// November 2026: "our model might need to allow for further variation beyond the sparse examples of the measured
// clarinettists, provided that the variation we allow follows accurately formulated physiology"). The joint finding's
// (native/openwind/joint.mjs) -> [lo, hi] each.
export function tractBounds(baked=SPACE){
  const rows=[...baked.normal.rows,...baked.bend.rows];
  return baked.space.span.map(([lo,hi],k)=>[Math.min(lo,...rows.map(r=>r.coords[k])),Math.max(hi,...rows.map(r=>r.coords[k]))]);
}

// The eleven measured vowels' spread along each of the space's coordinates (vocal-tract-space.json `locations`: Story
// 2008's): a tract's move in units of it, as the joint finding (native/openwind/joint.mjs) and the dial's held note
// (dial.mjs heldPlayer) move a shape.
export function vowelSpread(baked=SPACE){
  const all=Object.values(baked.space.locations),n=all.length;
  return baked.space.span.map((_,k)=>{const mean=all.reduce((s,c)=>s+c[k],0)/n;return Math.sqrt(all.reduce((s,c)=>s+(c[k]-mean)**2,0)/(n-1))});
}

// A tract's resonances put in the places another's stand in (`places`, each a resonance: frequency, Q and peak), so that
// the engine, which pairs a tract's resonances by their order (native/openwind src/tract.rs set; its orbit's state each
// one's section, orbit.rs), carries each to its own: each matched one to one with the nearest place within a third of an
// octave -- the reach a fit keeps each resonance within (resonancesOf) -- the nearest pairs first; a place it lacks held
// at no peak, at that place's frequency and Q, as the engine brings a resonance in or out; one that no place holds put
// after them, a place of its own. Its impedance is the resonances' own: a resonance at no peak adds nothing. Two
// shapes a little apart can be fitted with a weak resonance more or less (the clarinet's 83 has one, 0.05 MPa s/m^3 at
// 1.5 kHz, that a move of a thousandth of a vowel's spread takes out) -> {places: `places`, then those it brought,
// resonances: `resonances` in them}.
export function placedTract(resonances,places){
  const near=[];
  resonances.forEach((r,i)=>places.forEach((p,k)=>{const apart=Math.abs(Math.log2(r.frequency/p.frequency));if(apart<1/3)near.push({apart,i,k})}));
  near.sort((a,b)=>a.apart-b.apart);
  const placeOf=resonances.map(()=>-1),taken=new Set();
  for(const {i,k} of near)if(placeOf[i]<0&&!taken.has(k)){placeOf[i]=k;taken.add(k)}
  const all=[...places];
  resonances.forEach((r,i)=>{if(placeOf[i]<0){placeOf[i]=all.length;all.push(r)}});
  const out=all.map(p=>({frequency:p.frequency,q:p.q,peak:0}));
  resonances.forEach((r,i)=>{out[placeOf[i]]={frequency:r.frequency,q:r.q,peak:r.peak}});
  return {places:all,resonances:out};
}

// Whether `shape` ({coords, glottis}: its coordinates in the baked space, its glottis's opening, m^2) is one a player's
// tract may take, as its notes' shapes are found: each coordinate within its bounds (tractBounds), its glottis within
// `glottis` ([least, most] m^2, its players': registry/players/winds.json tract.glottis).
export function holdsShape(shape,glottis,baked=SPACE){
  const bounds=tractBounds(baked);
  return Array.isArray(shape?.coords)&&shape.coords.length===bounds.length&&shape.coords.every((c,m)=>Number.isFinite(c)&&c>=bounds[m][0]&&c<=bounds[m][1])&&
    Number.isFinite(shape.glottis)&&shape.glottis>=glottis[0]&&shape.glottis<=glottis[1];
}

// The resonances the engine steps for a player's tract at `shape`, as a player's mouth round its mouthpiece makes them:
// its areas the shape's (shapeOf), its front the mouthpiece's (FRONT), its glottis opened as the shape's before
// VocalTractLab's trachea, no resistance at it, the airway's losses a living tract's (PLAYERS_AIRWAY); fitted to its
// impedance without the reed's end correction over 0.1-3 kHz, fading to 4 kHz -- as the compiled finder fits each shape
// it tries (native/openwind-tuner src/shape.rs Playing's areas and airway; tract_shape.rs Space::fitted). Some
// milliseconds; tens, and a few hundred for a few shapes, where it holds many resonances.
export function shapedTract(shape,baked=SPACE){
  const {space}=baked,areas=shapeOf(shape.coords,space),k=Math.min(FRONT.length,areas.length);
  const sealed=[...areas.slice(0,areas.length-k),...FRONT.slice(FRONT.length-k)];
  const airway={...space.airway,...PLAYERS_AIRWAY,glottis:{...PLAYERS_AIRWAY.glottis,area:shape.glottis}};
  return resonancesOf(FIT,mouthImpedance(sealed,space.slice,FIT,airway,{reed:false}),{bottom:100,top:3000,fade:4000,seeds:seedOf(baked)}).resonances;
}
