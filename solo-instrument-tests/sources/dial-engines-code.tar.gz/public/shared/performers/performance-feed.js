// A performance's notes fed to its synthesizer, by itself: what a live dial's musebot player needs of the performers'
// code to send its line (native/openwind/soloist.mjs, native/strings-model/soloist.mjs), with none of what composes or
// reads a score beside it -- so that a dial's own Worker on a website carries the feed alone, its band of bots in a
// Worker of theirs (native/live/site/solo-band-remote.js). musicxml-performer.js gives it on as its own.
// A performance sent to its synthesizer a little ahead of its time, each note whole -- its Per-Note Management to its
// Note Off -- as a musebot sends its line (dial-midi2.js). `start`: the piece's start on the synthesizer's clock; `lead`:
// how far ahead of a note's onset it is sent (s; on the winds' dial no less than its stroke: its /state strokeLeast).
export class PerformanceFeed{
  constructor(notes,{start=0,lead}){
    if(!(lead>=0))throw new RangeError('PerformanceFeed: a lead, s, to send each note ahead');
    Object.assign(this,{notes,start,lead,next:0});
  }
  due(now){
    const out=[];
    while(this.next<this.notes.length&&this.start+this.notes[this.next].at<=now+this.lead){
      for(const {seconds,packet} of this.notes[this.next++].events)out.push({seconds:+(this.start+seconds).toFixed(9),packet});
    }
    return out;
  }
  get done(){return this.next>=this.notes.length}
}
