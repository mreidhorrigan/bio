// A woodwind's notes as MIDI 2.0: what its player plays, as any winds synth takes it (docs/MIDI2_SYNTH_INPUT.md; the owner,
// 17 October 2026: "Musebots don't produce bow strokes. They produce MIDI 2.0"). The engine writes each note's UMP as it
// writes every note's (audio.js captureUMP: its Per-Note Management, its articulation -- its attack time (#73) and release
// time (#72), its breath's rise and fall -- its pitch as Pitch 7.9, its dynamic as a 16-bit velocity, its pitch's path
// as Per-Note Pitch Bend, its swell as Per-Note Pressure, its end as a Note Off) and, for a winds synth, what its breath
// needs besides (windControllers): whether it is slurred to the note before and whether its player says where its slurs
// are -- assignable Per-Note Controllers of ours until the Orchestral Articulation Profile's codes (M2-123-UM:
// articulations, legato) are read -- its attack and release where its articulation did not say them, and its extended
// technique: a flutter, a hum or a growl and its parameters, a brass player's mute (techniques.js windTechniqueAt), a
// woodwind's fingered multiphonic (techniques.js windMultiphonicNear). A winds synth reads them back (WindDecoder) into
// the engine's own events, which the renders' compiler makes a part's notes of (render/synthesis/physical-events.mjs
// compilePhysicalEvents): the bridge's live player (render/node/winds-stream.mjs) and, from the engine's stage 7, a
// render's alike. (A multiphonic carried, its live player does not shape it yet: OPENWIND_REALTIME_PLAN.md.)
import {perNoteController,assignablePerNoteController,perNoteManagement,perNotePressure,noteOn,noteOff,inspectUMP,bendSemitones} from '../ump.js';
import {ARTICULATION_CONTROLLERS,timeToBipolar,bipolarToTime,bipolar32,bipolarFrom32,unit32,rampedControls} from '../articulation.js';

// Each parameter: its message, its index (a controller's), how its value is written. `reference`: a time's, the centre
// of its log scale (articulation.js timeToBipolar): the engine's own articulation's (ARTICULATION_CONTROLLERS).
export const WIND_MIDI2=Object.freeze({
  pitch:{message:'noteOn',attribute:3,encoding:'Pitch 7.9: semitones, 1/512 of one'},
  velocity:{message:'noteOn',encoding:'16-bit: its dynamic, 0 to 1'},
  end:{message:'noteOff',encoding:'its time; the earliest sent for a note is its end'},
  bend:{message:'perNoteBend',encoding:'semitones from the note at its time (the channel\'s range, RPN 0/7): its pitch\'s path -- on a fixed-pitch model its median held and its sway breathed as its vibrato'},
  pressure:{message:'perNotePressure',encoding:'unit: its swell through the note, each point at its time (its performance\'s pressureCurve, the engine\'s evenly over the note as its player meant it)'},
  attack:{message:'perNoteController',index:73,registered:true,reference:ARTICULATION_CONTROLLERS.attack.reference,encoding:'bipolar time: its breath\'s rise, octaves from the reference over 4'},
  release:{message:'perNoteController',index:72,registered:true,reference:ARTICULATION_CONTROLLERS.release.reference,encoding:'bipolar time: its breath\'s fall at its group\'s end'},
  // (Assignable Per-Note Controllers of ours, until the profile's are read.)
  tongue:{message:'assignablePerNoteController',index:16,values:['tongued','slurred','portato'],profile:'articulation, legato; portato a slur legato-tongued'},
  phrased:{message:'assignablePerNoteController',index:17,values:[false,true],encoding:'its player says where its slurs are'},
  // (Its extended technique, its parameters each relative to the note or a reference: techniques.js windTechniqueAt.)
  technique:{message:'assignablePerNoteController',index:18,values:[null,'flutter','hum','growl'],profile:'articulation: flutter-tongue, sing and play, growl'},
  rate:{message:'assignablePerNoteController',index:19,reference:25,encoding:'bipolar: a flutter\'s rate, octaves from the reference (Hz) over 4'},
  interval:{message:'assignablePerNoteController',index:20,span:48,encoding:'bipolar: a hum\'s or growl\'s sung pitch, semitones from the note over the span'},
  level:{message:'assignablePerNoteController',index:21,encoding:'unit: a hum\'s or growl\'s level, a flutter\'s depth'},
  rough:{message:'assignablePerNoteController',index:22,encoding:'unit: a growl\'s roughness'},
  mute:{message:'assignablePerNoteController',index:23,values:[null,'straight','cup','harmon-stem-in','harmon-stem-out','stopped'],profile:'mute'},
  // (A fingered multiphonic in place of the note, its Note On its lowest pitch: as the strings' #23, its measured one.)
  multiphonic:{message:'assignablePerNoteController',index:24,encoding:'its measured fingering\'s number: n of its instrument\'s m<n> (its body\'s multiphonics, wind-multiphonics.json)'},
});
const T=WIND_MIDI2;
// (The engine's capture: its ticks a second, audio.js captureUMP; Pitch 7.9's steps a semitone.)
const CAPTURE_TICKS=9600,PITCH_STEPS=512;
const midiHz=pitch=>440*2**((pitch-69)/12);

// What a winds synth's breath needs of a note beyond its UMP (an engine event's: whether it is slurred and phrased, and
// its performance's attack and release where `said` -- the controllers its UMP set already -- lacks them), as Per-Note
// Controllers for `identity` ({group, channel, note}): sent after its Per-Note Management and before its Note On, so
// that they are the state it begins in. -> packets.
export function windControllers(event,identity,said=new Set){
  const out=[],performance=event.performance??{};
  if(Number(performance.attackSeconds)>0&&!said.has(T.attack.index))out.push(perNoteController({...identity,index:T.attack.index,value:bipolar32(timeToBipolar(Number(performance.attackSeconds),T.attack.reference))}));
  if(Number(performance.releaseSeconds)>0&&!said.has(T.release.index))out.push(perNoteController({...identity,index:T.release.index,value:bipolar32(timeToBipolar(Number(performance.releaseSeconds),T.release.reference))}));
  if(event.slurred===true)out.push(assignablePerNoteController({...identity,index:T.tongue.index,value:event.portato===true?2:1}));
  if(event.phrased===true)out.push(assignablePerNoteController({...identity,index:T.phrased.index,value:1}));
  out.push(...techniqueControllers(event,identity));
  return out.map(packet=>Array.from(packet));
}

// (A note's extended technique as its controllers: which, and its parameters -- a flutter's rate and depth, a hum's or
// growl's sung pitch from the note's own and its level, a growl's roughness -- a brass player's mute and a woodwind's
// multiphonic.)
function techniqueControllers(event,identity){
  const x=event.extended??{},kind=T.technique.values.find(name=>name&&x[name]),out=[],set=(name,value)=>out.push(assignablePerNoteController({...identity,index:T[name].index,value}));
  if(kind){
    const t=x[kind];set('technique',T.technique.values.indexOf(kind));
    if(kind==='flutter'){if(t.hz>0)set('rate',bipolar32(timeToBipolar(t.hz,T.rate.reference)));if(Number.isFinite(t.depth))set('level',unit32(t.depth))}
    else{
      const hz=event.frequency??midiHz(event.note);
      if(t.hz>0&&hz>0)set('interval',bipolar32(12*Math.log2(t.hz/hz)/T.interval.span));
      if(Number.isFinite(t.level))set('level',unit32(t.level));
      if(kind==='growl'&&Number.isFinite(t.rough))set('rough',unit32(t.rough));
    }
  }
  const mute=T.mute.values.indexOf(x.mute?.kind??null);
  if(mute>0)set('mute',mute);
  if(x.multiphonic)set('multiphonic',multiphonicNumber(x.multiphonic.id));
  return out;
}

// (A measured multiphonic's id as its number: each body's are m1, m2, ... in its order -- design_openwind_clarinet.py,
// design_openwind_woodwind.py.)
const multiphonicNumber=id=>{
  const n=/^m([1-9][0-9]*)$/.exec(String(id))?.[1];
  if(!n)throw new Error(`wind-midi2: a multiphonic's id is m<n> (its body's), not ${JSON.stringify(id)}`);
  return Number(n);
};

// A note's UMP (audio.js captureUMP's batch: [{time, packet}], each time from its start) with its winds controllers
// in, at `start` (s, the engine's clock). -> [{seconds, packet}].
export function windEvents(batch,event,start){
  const out=[],said=new Set;
  for(const {time,packet} of batch){
    const m=inspectUMP(packet);
    if(m.kind==='perNoteController')said.add(m.attribute);
    if(m.kind==='noteOn'){for(const extra of windControllers(event,{group:m.group,channel:m.channel,note:m.note},said))out.push({seconds:+(start+time).toFixed(6),packet:extra})}
    out.push({seconds:+(start+time).toFixed(6),packet:Array.from(packet)});
  }
  return out;
}

// A part's UMP as the engine captured it (audio.js captureUMP, its Note Offs captureRelease's: [{seconds, packet}], the
// band's own -- a render's or a page's, whose synth takes the engine's events, not MIDI 2.0) as a winds synth is sent
// it: before each Note On, what its breath needs besides (windControllers), from its engine event (`events`: the
// engine's, physical-capture.js; its first for an identity its attack) -- the attack at its Note On's time, within the
// capture's tick, of its pitch. So the part's MIDI 2.0, written out or edited, says its slurs. -> [{seconds, packet}].
export function withWindControllers(ump,events){
  const seen=new Set,attacks=[];
  for(const event of events)if(!event.action&&!seen.has(event.identity)){seen.add(event.identity);attacks.push(event)}
  const used=new Set,said=new Map,out=[];
  for(const {seconds,packet} of ump){
    const m=inspectUMP(packet);
    if(m.kind==='perNoteManagement'||m.type===4&&m.statusNibble===15)said.set(m.key,new Set);
    else if(m.kind==='perNoteController')(said.get(m.key)??said.set(m.key,new Set).get(m.key)).add(m.attribute);
    else if(m.kind==='noteOn'){
      // (Its attack: at its time, within a tick of the capture's, 9600 a second; of its pitch, Pitch 7.9's.)
      const attack=attacks.find(e=>!used.has(e)&&Math.abs(e.atSeconds-seconds)<=1/CAPTURE_TICKS&&Math.abs(12*Math.log2(e.frequency/440)+69-m.pitch)<=.5/PITCH_STEPS);
      if(attack){used.add(attack);for(const extra of windControllers(attack,{group:m.group,channel:m.channel,note:m.note},said.get(m.key)??new Set))out.push({seconds,packet:extra})}
    }
    out.push({seconds,packet:Array.from(packet)});
  }
  return out;
}

// One planned note -- {note (semitones, Pitch 7.9's), seconds, velocity (0 to 1), slurred?, portato?, phrased?,
// performance: {attackSeconds?, releaseSeconds?, pressureCurve? (unit points evenly through it)}} -- as a winds synth is
// sent it whole (docs/MIDI2_SYNTH_INPUT.md 5, 6): its Per-Note Management, what its breath needs (windControllers), its Note
// On, its swell's points, its Note Off -- what the engine's capture writes of a note, from a planned one: an instrument's
// test passages (scripts/make-instrument-midi2.mjs). -> [{time, packet}], each time in seconds from its Note On.
export function windNoteEvents(g,{group=0,channel=0,note}={}){
  const id={group,channel,note},events=[],at=(time,packet)=>events.push({time:+time.toFixed(9),packet:Array.from(packet)});
  at(0,perNoteManagement(id));
  for(const packet of windControllers(g,id))at(0,packet);
  at(0,noteOn({...id,pitch:g.note,attribute:3,velocity:Math.round(Math.max(0,Math.min(1,g.velocity??0))*65535)}));
  const swell=g.performance?.pressureCurve;
  if(swell?.length)Array.from(swell).forEach((value,k)=>at(swell.length>1?k*g.seconds/(swell.length-1):0,perNotePressure({...id,value:Math.round(Math.max(0,Math.min(1,value))*0xffffffff)})));
  at(g.seconds,noteOff(id));
  return events;
}

// A note let go before its end: its Note Off then.
export const windRelease=(identity,at)=>[{seconds:+at.toFixed(6),packet:Array.from(noteOff(identity))}];

// A winds synth's reading of its notes: each Note On a note, with what came for its note since its Per-Note Management,
// and what comes for it after (its pitch's path, its swell, an earlier Note Off). take(events) -- each {seconds,
// packet}, the stream's time -- -> the notes it touched, each as the engine's event of it (audio.js scheduleDsp's, as the
// renders' compiler takes it): {identity, frequency, duration, atSeconds, velocity, musicalVelocity, controls, slurred?,
// phrased?, performance: {attackSeconds?, releaseSeconds?, pressureCurve?, pressureTimes? (s from its onset: each point's)}}; one
// not yet ended its duration Infinity.
export class WindDecoder{
  constructor(){this.next=1;this.notes=new Map;this.pending=new Map;this.ranges=new Map}
  take(events){
    const touched=new Map;
    for(const {seconds,packet} of [...events].sort((a,b)=>a.seconds-b.seconds)){
      const m=inspectUMP(packet),key=m.key;
      if(m.kind==='registeredController'&&m.note===0&&m.attribute===7){this.ranges.set(`${m.group}:${m.channel}`,m.data/0x2000000);continue}
      if(!key)continue;
      if(m.kind==='perNoteManagement'||m.type===4&&m.statusNibble===15){this.notes.delete(key);this.pending.set(key,{controls:{},bend:[],pressure:[]});continue}
      const range=this.ranges.get(`${m.group}:${m.channel}`)??48;
      if(m.kind==='noteOn'){
        const before=this.pending.get(key)??{controls:{},bend:[],pressure:[]};this.pending.delete(key);
        // (Its bend and swell as they stood before it: the last of each sent.)
        const note={id:this.next++,at:seconds,pitch:m.pitch,end:Infinity,velocity:m.velocity/65535,controls:before.controls,bend:before.bend.slice(-1).map(([,v])=>[0,v]),pressure:before.pressure.slice(-1).map(([,v])=>[0,v])};
        this.notes.set(key,note);touched.set(note.id,note);continue;
      }
      const note=this.notes.get(key),control=m.kind==='perNoteController'||m.kind==='assignablePerNoteController'?`${m.kind==='perNoteController'?'r':'a'}${m.attribute}`:null;
      if(m.kind==='noteOff'){if(note){note.end=Math.min(note.end,seconds);touched.set(note.id,note)}continue}
      // (A controller is a note's as it stood at its Note On -- its attack, its tongue, its slur -- but its release time,
      // read at its end; one sent after its Note Off is its key's next note's, as after Per-Note Management, the state that
      // note begins in. So a stream that detaches no note, as an editor writes a key's controllers -- lanes through its
      // notes and the rests between them -- gives no note another's. Its curves go on through its release.)
      if(control&&note&&(seconds>=note.end||control!==`r${T.release.index}`)){
        if(seconds>=note.end)(this.pending.get(key)??this.pending.set(key,{controls:{},bend:[],pressure:[]}).get(key)).controls[control]=m.data;
        continue;
      }
      const target=note??(this.pending.get(key)??this.pending.set(key,{controls:{},bend:[],pressure:[]}).get(key)),time=note?seconds-note.at:0;
      if(m.kind==='perNoteBend')target.bend.push([time,bendSemitones(m.data,range)]);
      else if(m.kind==='perNotePressure')target.pressure.push([time,m.data/0xffffffff]);
      else if(control)target.controls[control]=m.data;
      if(note)touched.set(note.id,note);
    }
    return [...touched.values()].map(note=>this.eventOf(note));
  }
  // (A note as the engine's event of it.)
  eventOf(n){
    const c=n.controls,performance={};
    if(c[`r${T.attack.index}`]!=null)performance.attackSeconds=bipolarToTime(bipolarFrom32(c[`r${T.attack.index}`]),T.attack.reference);
    if(c[`r${T.release.index}`]!=null)performance.releaseSeconds=bipolarToTime(bipolarFrom32(c[`r${T.release.index}`]),T.release.reference);
    // (Its swell's points at their times -- an editor's lane through it, unevenly spaced, as much as the engine's own; its
    // breath cuts it where the note ends: breath.mjs swellOf.)
    if(n.pressure.length){const points=[...n.pressure].sort((a,b)=>a[0]-b[0]);performance.pressureCurve=points.map(([,v])=>v);performance.pressureTimes=points.map(([t])=>+t.toFixed(9))}
    // (Its pitch's path as the engine's controls: action 1, semitones, ramped between its points as the engine ramps
    // them -- audio.js engineControl, articulation.js rampedControls.)
    const controls=rampedControls(n.bend.map(([seconds,value])=>({seconds,action:1,value})));
    const extended=this.extendedOf(n);
    return {identity:n.id,frequency:midiHz(n.pitch),duration:n.end-n.at,atSeconds:n.at,velocity:n.velocity,musicalVelocity:n.velocity,controls,
      ...(c[`a${T.tongue.index}`]>=1?{slurred:true,...(c[`a${T.tongue.index}`]===2?{portato:true}:{})}:{}),...(c[`a${T.phrased.index}`]===1?{phrased:true}:{}),
      ...(extended?{extended}:{}),performance};
  }
  // (Its extended technique, mute and multiphonic as the engine's `extended`, or null.)
  extendedOf(n){
    const c=n.controls,a=name=>c[`a${T[name].index}`],kind=T.technique.values[a('technique')]??null,mute=T.mute.values[a('mute')]??null,out={};
    const unit=name=>a(name)!=null?+(a(name)/0xffffffff).toFixed(6):undefined,defined=o=>Object.fromEntries(Object.entries(o).filter(([,v])=>v!==undefined));
    if(kind==='flutter')out.flutter=defined({hz:a('rate')!=null?+bipolarToTime(bipolarFrom32(a('rate')),T.rate.reference).toFixed(4):undefined,depth:unit('level')});
    else if(kind){
      const hz=a('interval')!=null?+midiHz(n.pitch+bipolarFrom32(a('interval'))*T.interval.span).toFixed(3):undefined;
      out[kind]=defined({hz,level:unit('level'),...(kind==='growl'?{rough:unit('rough')}:{})});
    }
    if(mute)out.mute={kind:mute};
    if(a('multiphonic')>0)out.multiphonic={id:`m${a('multiphonic')}`};
    return Object.keys(out).length?out:null;
  }
}
