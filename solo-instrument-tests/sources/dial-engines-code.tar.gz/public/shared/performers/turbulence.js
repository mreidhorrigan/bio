// A reed's or the lips' flow's turbulence: its players' level (registry/players/winds.json flow.turbulence), the share of
// the flow its fluctuation is per root hertz, white to the engine's own rate. The winds' engine's hosts give it to the
// engine as they give it its player's tract (native/openwind src/stream.rs turbulence; render/node/winds-stream.mjs,
// native/openwind/dial.mjs, public/studio/engines/openwind-stream.js), and a player's facts tell it
// (instrument-facts.js). It reads the registry alone, so that the hosts need nothing else to give it.
import {playerEntry} from '../../../registry/registry.js';

// Its entry, null for a jet's -- whose turbulence is its law's (openwind_engine.py noiseLevel) -- or a model the
// registry does not have.
export function turbulenceEntry(model){
  let entry;try{entry=playerEntry(model,'flow.turbulence')}catch{return null}
  return {value:entry.value,unit:entry.unit,kind:entry.kind,what:'its flow\'s turbulent fluctuation, a share of the flow per root hertz'};
}
export const turbulenceOf=model=>turbulenceEntry(model)?.value??null;
