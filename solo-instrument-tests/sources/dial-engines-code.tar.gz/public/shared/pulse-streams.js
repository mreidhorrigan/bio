// Exact pulse streams, groupings and the operations between them: the core a drummer's rhythms -- and any part's pulse --
// are to be built from (research: "Pan-meter rhythm primitives and composition recipes", 7 October 2026, MIT;
// research/PANMETER_RHYTHM_CORE_PLAN.md). Every time is a Rational (transcript/rational.js) in one unit its caller
// declares; nothing here chooses a meter, a grouping, a mask, an accent or a style: those are a bot's, drawn in
// performance. An event is {time, span, part, ...}: its onset and its logical slot, not how long it sounds.
import {Rational,gcd,lcm} from '../transcript/rational.js';

const q=value=>Rational.of(value);
const positive=(value,what)=>{const r=q(value);if(r.sign()<=0)throw new RangeError(`${what} must be positive, not ${r}`);return r};
// (Exact ceilings: a float quotient can round across an integer near the safe range.)
const ceilOf=r=>{const n=BigInt(r.n),d=BigInt(r.d),t=n/d;return Number(n>0n&&n%d!==0n?t+1n:t)};
const modulo=(value,divisor)=>((value%divisor)+divisor)%divisor;
const event=(time,span,part,extra={})=>Object.freeze({time,span,part,...extra});
const objectNode=node=>node!==null&&typeof node==='object'&&!(node instanceof Rational)&&!Array.isArray(node);

// A span divided by a tree of positive weights: an array of weights or {weight, children?, rest?} nodes, each child a
// share of its parent's span, nested as deep as it goes (a tuplet within a group within a bar). A rest keeps its time;
// `path` names each leaf by its place in the tree, a rest never renumbering its siblings. -> its leaves' events.
export function subdivide(tree,span,{start=0,part='pulse'}={}){
  const out=[];
  const visit=(nodes,time,duration,path)=>{
    if(!Array.isArray(nodes)||!nodes.length)throw new TypeError('A subdivision needs a nonempty array of nodes');
    const weights=nodes.map(node=>positive(objectNode(node)?node.weight:node,'A weight')),total=weights.reduce((a,b)=>a.add(b),Rational.ZERO);
    let cursor=time;
    nodes.forEach((node,k)=>{
      const share=duration.mul(weights[k]).div(total),here=[...path,k];
      if(objectNode(node)&&node.rest!==undefined&&typeof node.rest!=='boolean')throw new TypeError('rest is true or false');
      if(!(objectNode(node)&&node.rest)){
        if(objectNode(node)&&node.children!==undefined)visit(node.children,cursor,share,here);
        else out.push(event(cursor,share,part,{path:Object.freeze(here)}));
      }
      cursor=cursor.add(share);
    });
  };
  visit(tree,q(start),positive(span,'A span'),[]);
  return out;
}
// n equal slots across a span the caller states (a tuplet's ratio alone does not say what it spans).
export function tuplets(n,span,options){
  if(!Number.isSafeInteger(n)||n<=0)throw new RangeError('A tuplet count is a positive integer');
  return subdivide(Array.from({length:n},()=>1),span,options);
}
// Additive groups' starts and spans: [2,2,3] of a unit 1/8 spans 7/8.
export function groupStarts(groups,unit,options){
  if(!Array.isArray(groups)||!groups.length)throw new TypeError('Groups are a nonempty array');
  const span=groups.map(size=>positive(size,'A group')).reduce((a,b)=>a.add(b),Rational.ZERO).mul(positive(unit,'A unit'));
  return subdivide(groups,span,options);
}

// A periodic stream queried over [start, end): its pulses at origin + k*step, k counted from its origin whatever the
// window, each sounding where its onset mask says (mask[k mod its length]) and carrying its accent cycle's value
// (accents[k mod its length]) whether or not it sounds -- the mask says what sounds, the accents how strongly, each its
// own cycle. Windows that meet at a boundary never repeat its onset. -> events with their pulse's index.
export function pulses({step,origin=0,mask=[true],accents,part='pulse'},start,end){
  const spacing=positive(step,'A step'),phase=q(origin),from=q(start),until=q(end);
  if(until.lt(from))throw new RangeError('A window ends before it starts');
  if(!Array.isArray(mask)||!mask.length||mask.some(value=>typeof value!=='boolean'))throw new TypeError('A mask is a nonempty array of true and false');
  if(accents!==undefined&&(!Array.isArray(accents)||!accents.length))throw new TypeError('An accent cycle is a nonempty array');
  if(!mask.some(Boolean))return [];
  const first=ceilOf(from.sub(phase).div(spacing)),limit=ceilOf(until.sub(phase).div(spacing)),out=[];
  for(let k=first;k<limit;k++){
    if(!mask[modulo(k,mask.length)])continue;
    out.push(event(phase.add(spacing.mul(k)),spacing,part,{pulseIndex:k,...(accents?{accent:accents[modulo(k,accents.length)]}:{})}));
  }
  return out;
}
// The same stream begun again at each of `boundaries` (bar lines, a phrase's downbeats): its origin each window's
// start, its mask and its accents from their first again -- where `pulses` alone continues across them. Eighths with an
// accent every third, begun again each bar of 7/8, group it 3+3+1; continued, they meet its downbeat again only after
// three bars (jointPeriod).
export function restarting(stream,boundaries,start,end){
  const from=q(start),until=q(end),cuts=[...new Set([from,...boundaries.map(q),until].filter(t=>t.ge(from)&&t.le(until)).map(String))].map(q).sort((a,b)=>a.cmp(b));
  return cuts.slice(0,-1).flatMap((at,k)=>pulses({...stream,origin:at},at,cuts[k+1]));
}
// A stream carried through a change of its step by `scale` at `at` (a metric modulation keeping its pulses' physical
// spacing, newStep = scale x step, or a change of subdivision): its carrier coordinate kept, so that its next pulse
// keeps its ordinal -- its mask and accents go on where they were -- and a cut between two pulses keeps its fraction.
export function repivot(stream,at,scale){
  const step=positive(stream.step,'A step'),factor=positive(scale,'A scale'),cut=q(at),carrier=cut.sub(q(stream.origin??0)).div(step),next=step.mul(factor);
  return {...stream,step:next,origin:cut.sub(carrier.mul(next))};
}
// Events moved and stretched in time: each onset scaled about zero and shifted, its span scaled.
export function affine(events,scale,shift=0){
  const factor=positive(scale,'A scale'),offset=q(shift);
  return events.map(e=>Object.freeze({...e,time:q(e.time).mul(factor).add(offset),span:q(e.span).mul(factor)}));
}
// Layers laid together, every simultaneous onset kept, in time and then in the layers' and their own order.
export function stack(...layers){
  return layers.flatMap((events,layer)=>events.map((value,order)=>({value,layer,order})))
    .sort((a,b)=>q(a.value.time).cmp(q(b.value.time))||a.layer-b.layer||a.order-b.order).map(item=>item.value);
}
// When cycles of these periods stand in their first phases together again: lcm of their numerators over gcd of their
// denominators, each period reduced (a phrase's plan; a performance never builds that grid).
export function jointPeriod(periods){
  if(!periods.length)throw new TypeError('Periods are a nonempty list');
  const reduced=periods.map(period=>positive(period,'A period'));
  return new Rational(reduced.map(r=>r.n).reduce(lcm),reduced.map(r=>r.d).reduce(gcd));
}
