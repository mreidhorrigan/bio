// MIDI 2.0's core in Rust, from JavaScript (the owner, 13 November 2026: "Do likewise for our MIDI 2.0 handling: We need
// our MIDI 2.0 processing to be able to ingest arbitrary MIDI 2.0 files from other pieces of software, in addition to
// those produced internally"; "Lose none of our current Musebot functionality in the process"): the WASM module
// wasm/midi2-core builds (public/wasm/midi2.wasm, scripts/build-midi2-core.mjs, the C99 module's name and place), where MIDI Clip Files
// are read and written (midi-files.js), MIDI 1.0 is translated into MIDI 2.0 (midi-files.js midi1StreamConverter,
// ump.js upgradeMidi1Channel and packMidi1), a UMP sequence's notes are traced (ump-notes.js) and Flex Data texts --
// lyrics among them -- are written and put back together (render/synthesis/src/ump.mjs) -- their JavaScript, JZZ's Clip
// and the C99 module archived in research/rust-port-archive/.
//
// In Node the module is compiled the first time it is called (midi2Core); a page loads it before anything reads a clip
// or traces notes (midi2CoreReady, which ump.js initializeMidi2 waits for), from the bytes a bundle carries
// (globalThis.MUSEBOTS_WASM_ASSETS) or else fetched. The native plug-in's QuickJS has no WebAssembly: there the plug-in
// links the same Rust and hands it over as __musebotsHost.midi2 (native/plugin/src/decisions.rs).
//   midi2Core() -> {readClip, writeClip, clipListing, describe, readSmf, upgrade, pack, converter, tracker, trace, flexText, lyric,
//     textAssembler, smfTimeline, clipTimeline}
//   midi2CoreReady: a promise of the core installed, or null where it cannot be
export const MIDI2_CORE_ABI=1;
export const MIDI2_CORE_ASSET='wasm/midi2.wasm';
const ERRORS=Object.freeze({Error,RangeError,TypeError});
let encoder=null,decoder=null;
const coders=()=>{encoder??=new TextEncoder();decoder??=new TextDecoder()};
const EMPTY=new Uint8Array(0);

// The calls, over the module's exports: the name and the call's bytes into the input bytes, its packets' words and times
// into theirs; the answer's text (or a file's bytes), words and times read back. A call that fails throws its error.
function wasmCall(exports){
  const abi=exports.m2_abi_version();
  if(abi!==MIDI2_CORE_ABI)throw new Error(`midi2.wasm speaks ABI ${abi}, midi2-core.js ${MIDI2_CORE_ABI}: build it again (node scripts/build-midi2-core.mjs)`);
  const names=new Map;
  return (name,{bytes=EMPTY,words=null,times=null,a=0,b=0}={})=>{
    let label=names.get(name);if(!label){coders();label=encoder.encode(name);names.set(name,label)}
    const into=exports.m2_in_bytes(label.length+bytes.length),memory=()=>exports.memory.buffer;
    new Uint8Array(memory(),into,label.length+bytes.length).set(label);
    new Uint8Array(memory(),into+label.length,bytes.length).set(bytes);
    if(words?.length){const at=exports.m2_in_words(words.length);new Uint32Array(memory(),at,words.length).set(words)}
    if(times?.length){const at=exports.m2_in_times(times.length);new Float64Array(memory(),at,times.length).set(times)}
    const status=exports.m2_call(label.length,bytes.length,words?.length??0,times?.length??0,a,b);
    const out=new Uint8Array(memory(),exports.m2_out(),exports.m2_out_len()).slice();
    if(status!==0){coders();const {kind,message}=JSON.parse(decoder.decode(out));throw new (ERRORS[kind]??Error)(message)}
    return {out,words:new Uint32Array(memory(),exports.m2_out_words(),exports.m2_out_words_len()).slice(),
      times:new Float64Array(memory(),exports.m2_out_times(),exports.m2_out_times_len()).slice()};
  };
}
// The same calls through the plug-in's binding (native/plugin/src/decisions.rs): host.midi2(name, bytes, words, times,
// a, b) -> {status, out, words, times} as JSON text, its lists arrays of numbers.
function hostCall(midi2){
  return (name,{bytes=EMPTY,words=null,times=null,a=0,b=0}={})=>{
    const answer=JSON.parse(midi2(name,Array.from(bytes),Array.from(words??[]),Array.from(times??[]),a,b)),out=Uint8Array.from(answer.out);
    if(answer.status!==0){coders();const {kind,message}=JSON.parse(decoder.decode(out));throw new (ERRORS[kind]??Error)(message)}
    return {out,words:Uint32Array.from(answer.words),times:Float64Array.from(answer.times)};
  };
}

const text=out=>{coders();return decoder.decode(out)};
const json=answer=>JSON.parse(text(answer.out));
// Packets laid end to end, each its message type's length, with their times.
const WORDS=[1,1,1,2,2,4,1,1,2,2,2,3,3,4,4,4];
function timed({words,times}){
  const out=new Array(times.length);
  for(let i=0,at=0;i<times.length;i++){const n=WORDS[words[at]>>>28];out[i]={time:times[i],packet:words.slice(at,at+n)};at+=n}
  return out;
}
function flatten(packets){
  let total=0;for(const packet of packets)total+=packet.length;
  const words=new Uint32Array(total);let at=0;
  for(const packet of packets){words.set(packet,at);at+=packet.length}
  return words;
}
// (A number JSON cannot hold -- NaN, an infinity -- goes as text, which the Rust refuses where it wants a number, as the
// JavaScript refused it: JSON.stringify would have made it null.)
const finiteOnly=(key,value)=>typeof value==='number'&&!Number.isFinite(value)?`\u0000${value}`:value;
const encodeJson=value=>{coders();return encoder.encode(JSON.stringify(value,finiteOnly))};
// A handle freed when what holds it is collected, where the host can say so.
const freeing=typeof FinalizationRegistry==='function'?new FinalizationRegistry(free=>free()):null;

function coreOf(call){
  return {
    // A MIDI Clip File -> {ticksPerQuarterNote, headerTicks, endTime, warnings, preamble: [packet], header and events:
    // [{time, packet}], flexData: what its Flex Data says (src/signs.rs read: {tempi, timeSignatures, keySignatures, chords,
    // texts, lyrics, unread})}; one that cannot be read throws "Invalid MIDI Clip: ...", unless `repair` asks it read as JZZ
    // repaired it (the MIDI 2.0 editor's), what was repaired in its warnings.
    readClip(bytes,{repair=false}={}){
      const answer=call('read_clip',{bytes,b:repair?1:0}),meta=json(answer),all=timed(answer);
      return {...meta,preamble:all.slice(0,meta.preamble).map(event=>event.packet),header:all.slice(meta.preamble,meta.preamble+meta.header),
        events:all.slice(meta.preamble+meta.header)};
    },
    // A MIDI Clip File listed as JZZ's Clip listed one: a message a line, its tick, its words in hex and its name.
    clipListing(bytes){return text(call('clip_listing',{bytes}).out)},
    // Packets, each as that listing writes it.
    describe(packets){return json(call('describe',{words:flatten(packets)}))},
    // The file's bytes from the same fields (times whole ticks; packets arrays or Uint32Arrays); `flexData` the piece's
    // signs, written as Flex Data by the core (src/signs.rs): {group, timeSignatures: [{time, numerator, denominator}],
    // keySignatures: [{time, fifths, mode}], texts: [{kind ('composition name', 'clip name', ...), text}]}.
    writeClip({ticksPerQuarterNote,headerTicks=0,endTime=0,preamble=[],header=[],events=[],flexData=null}){
      const packets=[...preamble,...header.map(e=>e.packet),...events.map(e=>e.packet)];
      const times=Float64Array.from([...preamble.map(()=>0),...header.map(e=>e.time),...events.map(e=>e.time)]);
      return call('write_clip',{bytes:encodeJson({ticksPerQuarterNote,headerTicks,endTime,preamble:preamble.length,header:header.length,events:events.length,flexData}),
        words:flatten(packets),times}).out;
    },
    // A Standard MIDI File -> {ticksPerQuarterNote, sourceType, sourceTimebase, warnings, sequences: [{endTime,
    // smfMetadata, notes, events: [{time, packet}]}]}, at `ticksPerQuarterNote` where the file is SMPTE-timed; one that
    // cannot be read throws as JZZ threw ("Not a MIDI file", "Invalid MIDI file: ...").
    readSmf(bytes,ticksPerQuarterNote){
      const answer=call('read_smf',{bytes,a:ticksPerQuarterNote}),meta=json(answer),all=timed(answer);
      let at=0;
      return {...meta,sequences:meta.sequences.map(sequence=>({...sequence,events:all.slice(at,at+=sequence.events)}))};
    },
    // A file's events in playing order with their seconds, as JZZ's player timed them (timeline.rs): a Standard MIDI
    // File's (a type 2's `sequence` alone) -> {format, timebase, durationSeconds, events: [{track, index, tick, seconds,
    // velocity}]}, `velocity` a sounding Note On's, else 0; a clip's -> {ticksPerQuarterNote, durationSeconds, events:
    // [{time, packet, seconds}]}.
    smfTimeline(bytes,sequence=0){
      const answer=json(call('smf_timeline',{bytes,a:sequence}));
      return {...answer,events:answer.events.map(([track,index,tick,seconds,velocity])=>({track,index,tick,seconds,velocity}))};
    },
    clipTimeline(bytes){
      const answer=call('clip_timeline',{bytes}),{seconds,...meta}=json(answer);
      return {...meta,events:timed(answer).map((event,i)=>({...event,seconds:seconds[i]}))};
    },
    // One MIDI 1.0 Channel Voice packet as MIDI 2.0, on its own; null for any other packet.
    upgrade(word){const {words}=call('upgrade',{a:word>>>0});return words.length?words:null},
    // A MIDI 1.0 message's bytes as UMP on `group`, unchanged in protocol.
    pack(bytes,group=0){const {words}=call('pack',{bytes:Uint8Array.from(bytes),a:group});return timed({words,times:new Float64Array(countPackets(words))}).map(e=>e.packet)},
    // A MIDI 1.0 stream's translator on `group`.
    converter(group=0){
      const handle=Number(text(call('converter_new',{a:group}).out)),owner={};
      const free=()=>call('converter_free',{a:handle});
      freeing?.register(owner,free);
      return Object.assign(owner,{
        convert:(bytes,time)=>timed(call('converter_convert',{bytes:Uint8Array.from(bytes),a:handle,b:time})),
        flush:()=>timed(call('converter_flush',{a:handle})),
        checkpoint:()=>json(call('converter_checkpoint',{a:handle})),
        restore:value=>{call('converter_restore',{bytes:encodeJson(value),a:handle})},
      });
    },
    // A note tracker: {ticksPerQuarterNote, bendRange, retainHistory, maxActiveNotes}.
    tracker(config){
      const handle=Number(text(call('tracker_new',{bytes:encodeJson(config)}).out)),owner={};
      freeing?.register(owner,()=>call('tracker_free',{a:handle}));
      return Object.assign(owner,{
        // `stamp`: whether the packet is a clip header's, then the index its caller knows the event by (ump-notes.js).
        consume:(time,packet,stamp=EMPTY)=>{call('tracker_consume',{bytes:stamp,words:packet,a:handle,b:time})},
        snapshot:()=>json(call('tracker_snapshot',{a:handle})),
        checkpoint:()=>json(call('tracker_checkpoint',{a:handle})),
        restore:value=>{call('tracker_restore',{bytes:encodeJson(value),a:handle})},
        finish:end=>json(call('tracker_finish',{a:handle,b:end})),
      });
    },
    // A whole trace: the header's events and the clip's -> the notes, as notes.rs notes_json writes them.
    trace(config,header,events,endTime){
      const all=[...header,...events];
      return json(call('trace',{bytes:encodeJson({...config,header:header.length,endTime}),words:flatten(all.map(e=>e.packet)),
        times:Float64Array.from(all,e=>e.time)}));
    },
    // A text as one Flex Data message (flex.rs): `head` its first word's Group, Address, Channel, Status Bank and Status
    // -> its packets, arrays of four words. The text in Normalization Form C is the caller's (UMP v1.1.2 §1.8).
    flexText(text,head){
      coders();const {words}=call('flex_text',{bytes:encoder.encode(text),a:head>>>0});
      return Array.from({length:words.length/4},(_,i)=>Array.from(words.subarray(4*i,4*i+4)));
    },
    // A sung note's syllable as MIDI 2.0 sends it with the note (signs.rs lyric): `lyric` the score's record (notation/
    // lyrics.js), `language` the singer's where it changes -> packets, its Lyric Language first where given.
    lyric({group=0,channel=0,lyric,language=null}){
      const {words}=call('lyric',{bytes:encodeJson({group,channel,lyric,language})});
      return Array.from({length:words.length/4},(_,i)=>Array.from(words.subarray(4*i,4*i+4)));
    },
    // Flex Data texts put back together from their packets (flex.rs Assembler), a message at most `mostBytes` long: a
    // packet from `endpoint` -> its message's text where it ends one, else null.
    textAssembler(mostBytes=65536){
      const handle=Number(text(call('text_new',{a:mostBytes}).out)),owner={};
      freeing?.register(owner,()=>call('text_free',{a:handle}));
      return Object.assign(owner,{
        push:(packet,endpoint='local')=>{coders();return json(call('text_push',{bytes:encoder.encode(endpoint),words:packet,a:handle}))?.text??null},
        open:()=>Number(text(call('text_open',{a:handle}).out)),
        reset:()=>{call('text_reset',{a:handle})},
      });
    },
  };
}
function countPackets(words){let n=0;for(let at=0;at<words.length;at+=WORDS[words[at]>>>28])n++;return n}

// The core from its module's bytes, compiled at once (Node); or loaded as a page loads a module.
export const midi2CoreFrom=bytes=>coreOf(wasmCall(new WebAssembly.Instance(new WebAssembly.Module(bytes),{}).exports));
export async function loadMidi2Core({bytes=null,url=null}={}){
  if(!bytes){
    url??=new URL(`../${MIDI2_CORE_ASSET}`,import.meta.url);
    const fs=globalThis.process?.getBuiltinModule?.('node:fs/promises');
    if(fs&&url.protocol==='file:')bytes=await fs.readFile(url);
    else{const response=await fetch(url);if(!response.ok)throw new Error(`midi2.wasm HTTP ${response.status}`);bytes=await response.arrayBuffer()}
  }
  const {instance}=await WebAssembly.instantiate(bytes,{});
  return coreOf(wasmCall(instance.exports));
}

let installed=null;
export const installMidi2Core=core=>{installed=core;return core};
// The bytes a bundle carries (globalThis.MUSEBOTS_WASM_ASSETS, base64), or null.
const carriedBytes=()=>{const carried=globalThis.MUSEBOTS_WASM_ASSETS?.[MIDI2_CORE_ASSET];return carried?Uint8Array.from(atob(carried),c=>c.charCodeAt(0)):null};
// The core MIDI 2.0 is read and traced with: the one installed; else the plug-in's own; else the one a bundle carries,
// compiled at once (an Ableton device's: Max's v8 object has no file to read, and a bot calls this before a promise can
// settle; a page's main thread, which may not compile so large a module at once, waits for midi2CoreReady); else, in
// Node, the repository's, compiled at once and installed.
export function midi2Core(){
  if(installed)return installed;
  const host=globalThis.__musebotsHost?.midi2;
  if(typeof host==='function')return installMidi2Core(coreOf(hostCall(host)));
  try{const bytes=typeof WebAssembly==='undefined'?null:carriedBytes();if(bytes)return installMidi2Core(midi2CoreFrom(bytes))}catch{}
  const url=new URL(`../${MIDI2_CORE_ASSET}`,import.meta.url),fs=globalThis.process?.getBuiltinModule?.('node:fs');
  if(fs&&url.protocol==='file:')return installMidi2Core(midi2CoreFrom(fs.readFileSync(url)));
  throw new Error('midi2.wasm is not loaded yet: what reads a MIDI clip or traces its notes in a page waits for midi2CoreReady (shared/midi2-core.js), as ump.js initializeMidi2 does');
}
// Installed wherever this module is loaded: in Node and the plug-in at once; in a page when it has it. Not had, it says
// so once where the host has a console, and resolves null.
export const midi2CoreReady=(()=>{
  const declined=error=>{globalThis.console?.warn?.(`midi2.wasm is not installed (${error?.message??error}): no MIDI clip can be read and no notes traced here`);return null};
  try{
    if(installed)return Promise.resolve(installed);
    if(typeof globalThis.__musebotsHost?.midi2==='function')return Promise.resolve(midi2Core());
    if(typeof WebAssembly==='undefined')return Promise.resolve(declined('no WebAssembly here'));
    // (Carried: compiled at once where the host allows it, as an Ableton device's does; else as a page loads a module,
    // and where midi2Core installed the carried core first meanwhile, that one stays.)
    const carried=carriedBytes();
    if(carried){
      try{return Promise.resolve(installMidi2Core(midi2CoreFrom(carried)))}catch{}
      return loadMidi2Core({bytes:carried}).then(core=>installed??installMidi2Core(core),declined);
    }
    const url=new URL(`../${MIDI2_CORE_ASSET}`,import.meta.url),fs=globalThis.process?.getBuiltinModule?.('node:fs');
    if(fs&&url.protocol==='file:')return Promise.resolve(installMidi2Core(midi2CoreFrom(fs.readFileSync(url))));
    // (A page's own fetch can miss where a bundle moved it; initializeMidi2 then loads it from the bytes it is given.)
    return loadMidi2Core({url}).then(installMidi2Core,()=>null);
  }catch(error){return Promise.resolve(declined(error))}
})();
