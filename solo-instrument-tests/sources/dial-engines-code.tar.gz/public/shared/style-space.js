// A style space. The owner, 4 November 2026: "we would want 'impressionism' instead to be a location within a vector
// space"; "integrate all other hardcoded 'styles' using our vectorization/parameterization method, adding parameters where
// necessary but consolidating where possible"; "The cost-table approach might already do some of this (if the items of
// the table are changeable)". A style is a point in a space: one value for every parameter its choices read (the space's
// dimensions), each a number or a list of numbers (a register's ranges), every number in it moved alike. The named
// styles are locations in the space; a player stands at one, at a blend of several, or anywhere else, and every point
// between two locations is a style too (CLAUDE.md: "Everything is interpolable"). The voice leaders' space
// (voice-leader-space.js) and the counterpoint planner's (conducting/counterpoint.js) are made by this.

const finite=value=>typeof value==='number'&&Number.isFinite(value);
// The same shape: two numbers, or two lists of the same length whose members have the same shape.
const sameShape=(a,b)=>finite(a)?finite(b):Array.isArray(a)&&Array.isArray(b)&&a.length===b.length&&a.every((value,i)=>sameShape(value,b[i]));
const frozen=value=>Array.isArray(value)?Object.freeze(value.map(frozen)):value;
// Values of one shape mixed by weight (weights summing to 1).
const mixed=(values,weights)=>finite(values[0])?values.reduce((sum,value,i)=>sum+weights[i]*value,0):Object.freeze(values[0].map((_,k)=>mixed(values.map(value=>value[k]),weights)));
// Every number in a value, in order.
export const numbersOf=value=>finite(value)?[value]:value.flatMap(numbersOf);
// The named locations each point stands between, by weight (summing to 1), each with the dimensions set apart from them
// (mixtureOf). A point given whole stands at itself alone.
const mixtures=new WeakMap();
// Locations named from others (the owner, 9 November 2026, of a style that inherits: "1 and 3 : yes"), baked once as a
// space is made: a location given as `{from: {parent: weight, ...}, ...its changes}` (its parents named locations of the
// same space, each weight 0 or more, some above 0) is `derive(place, [[parent baked, weight summing to 1], ...],
// changes)`, its parents baked first; any other is `whole(place, location)`. A parent not named, a weight that is none,
// or a location its own ancestor throws a TypeError. -> {baked {place: location, in the order given}, lineage {place:
// {from: {parent: weight, summing to 1}, changes: [what it gives that its parents' mix does not]}}, the derived ones',
// frozen}.
function inherited(name,locations,{whole,derive}){
  const baked={},lineage={},under=[];
  const bake=place=>{
    if(Object.hasOwn(baked,place))return baked[place];
    const location=locations[place];
    if(!(location&&typeof location==='object'&&Object.hasOwn(location,'from')))return baked[place]=whole(place,location);
    if(under.includes(place))throw new TypeError(`${name} space: ${place} derives from itself (${[...under.slice(under.indexOf(place)),place].join(' from ')})`);
    const {from,...changes}=location;
    if(!from||typeof from!=='object'||Array.isArray(from))throw new TypeError(`${name} space: ${place}'s "from" names its parents by weight`);
    for(const [parent,weight] of Object.entries(from)){
      if(!Object.hasOwn(locations,parent))throw new TypeError(`${name} space: ${place} derives from "${parent}", no location of it`);
      if(!finite(weight)||weight<0)throw new TypeError(`${name} space: ${place}'s weight of "${parent}" is a number, 0 or more`);
    }
    const parents=Object.entries(from).filter(([,weight])=>weight>0),total=parents.reduce((sum,[,weight])=>sum+weight,0);
    if(!total)throw new TypeError(`${name} space: ${place} weighs some parent above 0`);
    under.push(place);const weighed=parents.map(([parent,weight])=>[bake(parent),weight/total]);under.pop();
    const made=derive(place,weighed,changes),base=derive(place,weighed,{}),same=key=>JSON.stringify(made[key])===JSON.stringify(base[key]);
    lineage[place]=Object.freeze({from:Object.freeze(Object.fromEntries(parents.map(([parent,weight])=>[parent,weight/total]))),changes:Object.freeze(Object.keys(changes).filter(key=>!same(key)))});
    return baked[place]=made;
  };
  for(const place of Object.keys(locations))bake(place);
  return {baked:Object.fromEntries(Object.keys(locations).map(place=>[place,baked[place]])),lineage:Object.freeze(lineage)};
}

// A space: `dimensions` {name: what it does}, `locations` {name: {dimension: value}}, each location giving every
// dimension, of the shape the first gives it, or derived from others (`from`: inherited), every dimension its parents'
// mixed by weight but those it gives; `name` says whose space it is in errors. A location derived is a location of its
// own, as any named one: a draw at it falls in it, never in its parents. -> {dimensions, names, locations, lineage,
// locate, between, mixtureOf, drawn}.
export function styleSpace({name,dimensions,locations:given}){
  const names=Object.freeze(Object.keys(dimensions)),named=Object.keys(given);
  if(!named.length)throw new TypeError(`${name} style space names a location`);
  for(const key of names)if(given[key])throw new TypeError(`${name} style space: "${key}" names both a dimension and a location`);
  if(dimensions.from)throw new TypeError(`${name} style space: "from" names a location's parents, never a dimension`);
  const {baked:locations,lineage}=inherited(`${name} style`,given,{whole:(place,location)=>location,
    derive:(place,weighed,changes)=>({...Object.fromEntries(names.map(key=>{
      if(!weighed.every(([parent])=>sameShape(weighed[0][0][key],parent[key])))throw new TypeError(`${name} style space: ${place}'s parents' "${key}" are numbers, or lists shaped alike`);
      return [key,mixed(weighed.map(([parent])=>parent[key]),weighed.map(([,weight])=>weight))];
    })),...changes})});
  const first=locations[named[0]];
  for(const [place,location] of Object.entries(locations)){
    for(const key of names)if(!(finite(location[key])||Array.isArray(location[key]))||!sameShape(first[key],location[key]))throw new TypeError(`${name} style space: ${place}'s "${key}" is a number, or a list shaped as ${named[0]}'s`);
    for(const key of Object.keys(location))if(!dimensions[key])throw new TypeError(`${name} style space: ${place} gives "${key}", no dimension of it`);
  }
  const shaped=Object.freeze(Object.fromEntries(Object.entries(locations).map(([place,location])=>[place,Object.freeze(Object.fromEntries(names.map(key=>[key,frozen(location[key])])))])));
  // A location: a named one ('romantic'), a blend of named ones by weight ({romantic: .3, impressionist: .7}), either
  // with any dimensions set apart ({romantic: 1, replaning: .2}), or every dimension given. -> the vector, frozen.
  function locate(location){
    if(typeof location==='string'){
      if(!shaped[location])throw new TypeError(`A location in ${name} style space is one of ${named.join(', ')}, a blend of them, or a vector`);
      return shaped[location];
    }
    if(!location||typeof location!=='object'||Array.isArray(location))throw new TypeError(`A location in ${name} style space is a name, a blend of named locations, or a vector`);
    const weights={},set={};
    for(const [key,value] of Object.entries(location)){
      if(shaped[key]){if(!finite(value)||value<0)throw new TypeError(`A named location's weight is a number, 0 or more ("${key}")`);weights[key]=value}
      else if(dimensions[key]){if(!sameShape(first[key],value))throw new TypeError(`A location's "${key}" is shaped as ${named[0]}'s`);set[key]=frozen(value)}
      else throw new TypeError(`"${key}" is neither a named location nor a dimension of ${name} style space`);
    }
    const blend=Object.keys(weights),total=blend.reduce((sum,key)=>sum+weights[key],0);
    if(!total&&Object.keys(set).length<names.length)throw new TypeError(`A location in ${name} style space gives named locations to blend, or every dimension`);
    const base=total?Object.fromEntries(names.map(key=>[key,mixed(blend.map(place=>shaped[place][key]),blend.map(place=>weights[place]/total))])):{};
    const point=Object.freeze({...base,...set});
    if(total)mixtures.set(point,Object.freeze(blend.filter(place=>weights[place]>0).map(place=>Object.freeze({weight:weights[place]/total,location:Object.keys(set).length?Object.freeze({...shaped[place],...set}):shaped[place]}))));
    return point;
  }
  // The point `t` of the way from `a` to `b` (vectors), each number moved alike, t held within 0 to 1.
  function between(a,b,t){
    const amount=Math.max(0,Math.min(1,t)),point=Object.freeze(Object.fromEntries(names.map(key=>[key,mixed([a[key],b[key]],[1-amount,amount])])));
    mixtures.set(point,Object.freeze([...mixtureOf(a).map(part=>({...part,weight:part.weight*(1-amount)})),...mixtureOf(b).map(part=>({...part,weight:part.weight*amount}))]
      .filter(part=>part.weight>0).map(part=>Object.freeze(part))));
    return point;
  }
  // Points mixed by weight ([[point, weight], ...], each weight 0 or more, some above 0), each number moved alike, and
  // the locations each stands between composed by its weight, as `between` composes two's.
  function blend(entries){
    const given=entries.filter(([,weight])=>finite(weight)&&weight>0),total=given.reduce((sum,[,weight])=>sum+weight,0);
    if(!total)throw new TypeError(`A blend in ${name} style space weighs some point above 0`);
    const point=Object.freeze(Object.fromEntries(names.map(key=>[key,mixed(given.map(([at])=>at[key]),given.map(([,weight])=>weight/total))])));
    mixtures.set(point,Object.freeze(given.flatMap(([at,weight])=>mixtureOf(at).map(part=>Object.freeze({...part,weight:part.weight*weight/total})))));
    return point;
  }
  // The locations a point stands between, by weight: [{weight, location}], the named locations of a blend (each with
  // the dimensions set apart from them), those of both ends of the points between two, a point given whole its own.
  function mixtureOf(point){return mixtures.get(point)??Object.freeze([Object.freeze({weight:1,location:point})])}
  // One draw (0 to 1) for a choice made whole, a count or a chance (a chord's, a bar's): the location among those the
  // point stands between that it falls in, by weight, and the draw within that location (0 to 1). A chord between two
  // locations is one location's chord at a time, its chances falling together, as often as the point stands nearer it:
  // halfway between the Romantic and jazz, half its chords are jazz's and half the Romantic's, never each chord half of
  // each. -> {location, draw}.
  function drawn(point,draw){
    const parts=mixtureOf(point);let from=0;
    for(const part of parts){if(draw<from+part.weight||part===parts.at(-1))return {location:part.location,draw:Math.max(0,Math.min(1-1e-12,(draw-from)/part.weight))};from+=part.weight}
  }
  return Object.freeze({name,dimensions:Object.freeze({...dimensions}),names,locations:shaped,lineage,locate,between,blend,mixtureOf,drawn});
}

// Spaces joined (the owner, 8 November 2026: a style such as the impressionist one location across the voice leaders',
// the counterpoint planner's, the feels' and the other spaces, "OK to have some locations give a 0 for some parameters,
// in the case of a style that has nothing of that parameter"). Each of its parts is a style space; a style gives each
// part a location in it, or nothing (null: a style with nothing of that part, its player standing where it stands of
// its own). A point of the joined space is, for each part, how much of it the style holds (`share`: 1 where it gives
// the part, 0 where it gives nothing, a blend's between) and where (`at`, a point of that part's space, null where the
// share is 0). Every point between two styles is a style: each part's share moved alike, and its point the blend of
// theirs by each one's weight times its share there, the locations each stands between composed, so that a part's
// draws (drawn) fall as they fall in its own space. `parts` {name: a style space}; `locations` {style: {part: a
// location in its space, or null}}, every style naming every part, or derived from others (`from`: inherited), its
// parts theirs blended by weight as a blend of styles is (locate), each part's draws falling in each parent's, but those
// it gives; `name` says whose space it is in errors. -> {parts, names, locations, lineage, locate, between, standAt,
// mixtureOf}.
export function joinedSpace({name,parts,locations}){
  const names=Object.freeze(Object.keys(parts)),styles=Object.keys(locations);
  if(!styles.length)throw new TypeError(`${name} space names a style`);
  for(const key of names)if(locations[key])throw new TypeError(`${name} space: "${key}" names both a part and a style`);
  if(parts.from)throw new TypeError(`${name} space: "from" names a style's parents, never a part`);
  const NOTHING=Object.freeze({share:0,at:null});
  // A part given: a location in its space (its name, a blend, a vector), or null.
  const partAt=(part,given)=>given===null?NOTHING:Object.freeze({share:1,at:parts[part].locate(given)});
  // Points mixed by weight, each part as the joined space's doc above says.
  const mixedParts=entries=>Object.freeze(Object.fromEntries(names.map(key=>{
    const held=entries.map(([point,weight])=>[point[key],weight]),total=held.reduce((sum,[,weight])=>sum+weight,0),share=held.reduce((sum,[part,weight])=>sum+weight*part.share,0)/total;
    const weighed=held.filter(([part,weight])=>part.share>0&&weight>0).map(([part,weight])=>[part.at,weight*part.share]);
    return [key,weighed.length?Object.freeze({share,at:parts[key].blend(weighed)}):NOTHING];
  })));
  // Parts set apart from a style (a part's location, or null), each checked a part.
  const apartFrom=(style,given)=>Object.fromEntries(Object.entries(given).map(([key,value])=>{if(!parts[key])throw new TypeError(`${name} space: ${style} gives "${key}", no part of it`);return [key,partAt(key,value)]}));
  const {baked,lineage}=inherited(name,locations,{
    whole:(style,location)=>{
      for(const key of names)if(!(key in location))throw new TypeError(`${name} space: ${style} names no location in "${key}" (null where it has nothing of it)`);
      const given=apartFrom(style,location);return Object.freeze(Object.fromEntries(names.map(key=>[key,given[key]])));
    },
    derive:(style,weighed,changes)=>Object.freeze({...mixedParts(weighed),...apartFrom(style,changes)})});
  const shaped=Object.freeze(baked);
  // A style: a named one ('impressionist'), a blend of named ones by weight ({impressionist: .7, romantic: .3}), either
  // with any part set apart ({impressionist: 1, feel: 'jazz'}: a location in that part's space, or null for nothing of
  // it). -> the point, frozen.
  function locate(style){
    if(typeof style==='string'){
      if(!shaped[style])throw new TypeError(`A style in ${name} space is one of ${styles.join(', ')}, or a blend of them`);
      return shaped[style];
    }
    if(!style||typeof style!=='object'||Array.isArray(style))throw new TypeError(`A style in ${name} space is a name, or a blend of named styles`);
    const weights=[],apart={};
    for(const [key,value] of Object.entries(style)){
      if(shaped[key]){if(!finite(value)||value<0)throw new TypeError(`A named style's weight is a number, 0 or more ("${key}")`);if(value>0)weights.push([shaped[key],value])}
      else if(parts[key])apart[key]=partAt(key,value);
      else throw new TypeError(`"${key}" is neither a named style nor a part of ${name} space`);
    }
    if(!weights.length)throw new TypeError(`A style in ${name} space weighs some named style above 0`);
    return Object.freeze({...mixedParts(weights),...apart});
  }
  // The point `t` of the way from `a` to `b` (points), each part moved alike, t held within 0 to 1.
  function between(a,b,t){const amount=Math.max(0,Math.min(1,t));return mixedParts([[a,1-amount],[b,amount]].filter(([,weight])=>weight>0))}
  // Where a player of `part` stands under a style (`point`): its own location in the part's space (`own`, a point of
  // it) moved toward the style's as far as the style's share of the part -- all the way where the style gives it, not at
  // all where it has nothing of it.
  function standAt(own,point,part){
    const {share,at}=point[part];
    return share>=1?at:share>0?parts[part].blend([[own,1-share],[at,share]]):own;
  }
  // The locations a part of a point stands between, by weight, in its own space ([] where the style has nothing of it).
  const mixtureOf=(point,part)=>point[part].share>0?parts[part].mixtureOf(point[part].at):Object.freeze([]);
  return Object.freeze({name,parts:Object.freeze({...parts}),names,locations:shaped,lineage,locate,between,standAt,mixtureOf});
}
