#!/usr/bin/env node
// Builds MIDI 2.0's core in Rust (wasm/midi2-core: MIDI Clip Files read and written, MIDI 1.0 translated, a clip's notes
// traced; ported from public/shared/midi-files.js, JZZ's Clip, wasm/midi2/bridge.c and public/shared/ump-notes.js) to
// public/wasm/midi2.wasm (the name the C99 module had, so every page, worker and bundle that carries it carries
// this), which public/shared/midi2-core.js loads. The repository keeps the built module,
// so no page or test needs a Rust toolchain; rebuild it after changing the crate -- a comment too, since a panic's
// location is in the module's bytes:
//   node scripts/build-midi2-core.mjs
// As the scores' core's (scripts/build-score-core.mjs): the build tree in the user's cache, not beside the crate (this
// folder is synced; CARGO_TARGET_DIR moves it); wasm/midi2-core/BUILT.json records what the module was built from, and
// test/midi2-core.test.mjs fails if the crate has changed since, so a stale module cannot pass for the source.
// Built with two jobs at a lowered priority: the machine is shared with longer work.
import {execFileSync} from 'node:child_process';
import {chmodSync,copyFileSync,mkdirSync,readFileSync,readdirSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {homedir,platform} from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

const root=fileURLToPath(new URL('../',import.meta.url)),crate=path.join(root,'wasm','midi2-core');
// Its sources: the manifest, the lock and every Rust file under src/; and the shared crate's it links (wasm/core-base,
// with the scores' core: its JSON), so that a change there makes this module stale too.
const rustFiles=folder=>readdirSync(folder,{recursive:true}).filter(file=>file.endsWith('.rs')).map(file=>file.split(path.sep).join('/')).sort();
export const MIDI2_CORE_SOURCES=['Cargo.toml','Cargo.lock',...rustFiles(path.join(crate,'src')).map(file=>`src/${file}`),
  '../core-base/Cargo.toml',...rustFiles(path.join(crate,'..','core-base','src')).map(file=>`../core-base/src/${file}`)];
export const MIDI2_CORE_MODULE='public/wasm/midi2.wasm';
const cache=platform()==='darwin'?path.join(homedir(),'Library','Caches'):process.env.XDG_CACHE_HOME||path.join(homedir(),'.cache');
// One target directory a checkout (two worktrees never share a build).
export const MIDI2_CORE_TARGET=process.env.CARGO_TARGET_DIR||path.join(cache,'musebots-cargo',`midi2-core-${createHash('sha256').update(crate).digest('hex').slice(0,12)}`);
const sha256=data=>createHash('sha256').update(data).digest('hex');
// What the crate's sources are now, as BUILT.json records them.
export const midi2CoreSources=()=>Object.fromEntries(MIDI2_CORE_SOURCES.map(file=>[file,sha256(readFileSync(path.join(crate,file)))]));

if(process.argv[1]===fileURLToPath(import.meta.url)){
  execFileSync('nice',['-n','10','cargo','build','-j','2','--manifest-path',path.join(crate,'Cargo.toml'),'--target','wasm32-unknown-unknown','--release'],
    {stdio:'inherit',env:{...process.env,CARGO_TARGET_DIR:MIDI2_CORE_TARGET}});
  const out=path.join(root,MIDI2_CORE_MODULE);
  mkdirSync(path.dirname(out),{recursive:true});
  copyFileSync(path.join(MIDI2_CORE_TARGET,'wasm32-unknown-unknown','release','midi2_core.wasm'),out);
  chmodSync(out,0o644); // cargo's output is executable; the module is data
  const bytes=readFileSync(out),rustc=execFileSync('rustc',['--version'],{encoding:'utf8'}).trim();
  const built={module:MIDI2_CORE_MODULE,bytes:bytes.length,sha256:sha256(bytes),rustc,target:'wasm32-unknown-unknown',sources:midi2CoreSources()};
  writeFileSync(path.join(crate,'BUILT.json'),`${JSON.stringify(built,null,2)}\n`);
  console.log(`${MIDI2_CORE_MODULE}: ${bytes.length} bytes, sha256 ${built.sha256} (${rustc})`);
}
