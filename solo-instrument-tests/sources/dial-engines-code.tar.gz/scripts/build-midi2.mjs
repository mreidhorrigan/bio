// MIDI 2.0's builds: its core in Rust (wasm/midi2-core -> public/wasm/midi2.wasm, scripts/build-midi2-core.mjs; until
// 13 November 2026 a C99 module, wasm/midi2/bridge.c over midi2_msg.h, built here and archived in
// research/rust-port-archive/c/), and the pinned JZZ bundle the MIDI 2.0 editor edits its clips with and some research
// scripts read files with (public/vendor/jzz.js; no bot's module imports it since 13 November 2026), with the notices of
// what is bundled.
import {build} from 'esbuild';
import {execFileSync} from 'node:child_process';
import {mkdirSync,readFileSync} from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {writeThirdPartyNotices} from './third-party-notices.mjs';

const root=fileURLToPath(new URL('../',import.meta.url));
execFileSync(process.execPath,[path.join(root,'scripts/build-midi2-core.mjs')],{stdio:'inherit'});
mkdirSync(path.join(root,'public/vendor'),{recursive:true});
await build({
  stdin: {contents:"import JZZ from 'jzz'; import SMF from 'jzz-midi-smf'; SMF(JZZ); export default JZZ;", resolveDir:root},
  bundle:true, platform:'browser', format:'esm', target:'es2020',
  outfile:path.join(root, 'public/vendor/jzz.js'), legalComments:'eof',
  banner:{js:'/*!\n'+['jzz','jzz-midi-smf'].map(name=>`${name}\n${readFileSync(path.join(root,'node_modules',name,'LICENSE.md'),'utf8').replace(/\r/g,'')}`).join('\n')+'\n*/'},
});
writeThirdPartyNotices(root);
console.log('Built MIDI 2.0\'s core in Rust and the pinned JZZ bundle.');
