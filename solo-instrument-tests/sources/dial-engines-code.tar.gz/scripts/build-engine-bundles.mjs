#!/usr/bin/env node
// The engines' bundles of the live dial's site made again from their source: each file a GPL engine's Worker runs
// (scripts/lib/engine-bundles.mjs ENGINE_BUNDLES), bundled and minified as scripts/build-live-site.mjs bundles it.
// Packed with that source in the site's sources/dial-engines-code.tar.gz, so that whoever has the site can change the
// engines' program and build it: unpack it, `npm install esbuild@<the version SOURCES.html names>` beside it, and
//   node scripts/build-engine-bundles.mjs --out DIR [--inputs FILE.json]
// writes dial-worker.js, strings-worker.js, openwind-thread.js and soloist/ there, to put in the site's place of each.
// The engines themselves are built from sources/openwind-engine.tar.gz (cargo, wasm32) and sources/strings-engine.tar.gz
// (Emscripten), as SOURCES.html says.
import {mkdirSync,writeFileSync} from 'node:fs';
import {dirname,join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {parseArgs} from 'node:util';
import {ENGINE_BUNDLES,siteBundle} from './lib/engine-bundles.mjs';

const ROOT=fileURLToPath(new URL('../',import.meta.url));
const {values}=parseArgs({options:{out:{type:'string'},inputs:{type:'string'}}});
if(!values.out){console.error('node scripts/build-engine-bundles.mjs --out DIR [--inputs FILE.json]');process.exit(2)}
const read=new Set;
for(const bundle of ENGINE_BUNDLES){
  const {text,inputs,warnings}=await siteBundle(ROOT,bundle);
  for(const file of inputs)read.add(file);
  const to=join(values.out,bundle.name);
  mkdirSync(dirname(to),{recursive:true});writeFileSync(to,text);
  console.log(`${bundle.name}: ${text.length} bytes from ${inputs.length} files${warnings.length?`; ${warnings.length} warnings`:''}`);
}
// (--inputs: every file the bundles were made from, as esbuild lists them.)
if(values.inputs)writeFileSync(values.inputs,JSON.stringify([...read].sort()));
