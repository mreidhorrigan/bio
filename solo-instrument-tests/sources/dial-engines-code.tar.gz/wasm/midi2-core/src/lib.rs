//! MIDI 2.0 in Rust (the owner, 13 November 2026: "Do likewise for our MIDI 2.0 handling: We need our MIDI 2.0
//! processing to be able to ingest arbitrary MIDI 2.0 files from other pieces of software, in addition to those produced
//! internally"; "Lose none of our current Musebot functionality in the process"). MIDI Clip Files read from any writer
//! and written as the project wrote them (clip.rs), Standard MIDI Files read (smf.rs), MIDI 1.0 packed and translated
//! into MIDI 2.0 (translate.rs), a UMP sequence's notes traced, whole or live (notes.rs), Flex Data texts written and put
//! back together (flex.rs), and a file's events timed as JZZ's player timed them (timeline.rs) -- ported from
//! public/shared/midi-files.js, JZZ's Clip, SMF and player, the C99 bridge (wasm/midi2/bridge.c),
//! public/shared/ump-notes.js and the synthesis package's render/synthesis/src/ump.mjs, whose JavaScript is archived in
//! research/rust-port-archive/. The packets the bots make stay in public/shared/ump.js: a few shifts, needed at once in
//! every host, the plug-in's QuickJS among them.
//!
//! The browser and Node load the crate as WASM through the plain C exports below (public/shared/midi2-core.js); the
//! native plug-in links the rlib and hands its QuickJS the same calls (native/plugin/src/decisions.rs, `call`). Bytes, a
//! packet's words and times go in through the input buffers; an answer comes back as JSON text in the output bytes, and
//! packets with their times in the output words and times. A call returns 0, or 1 with {kind, message} as its answer.

pub mod clip;
pub mod flex;
// JSON, shared with the scores' core (wasm/core-base); its answers written by write_shortest, as JSON.parse alone reads
// them.
pub use core_base::json;
pub mod notes;
pub mod signs;
pub mod smf;
pub mod timeline;
pub mod translate;
pub mod ump;

use json::Json;

/// The C interface's version (m2_abi_version): bumped when a call's layout or what a call does changes.
pub const ABI_VERSION: u32 = 1;

/// An error as JavaScript throws it: its class's name and its message.
#[derive(Clone, Debug, PartialEq)]
pub struct JsError { pub kind: &'static str, pub message: String }

/// A clip writer's signs (write_clip's `flexData`) as signs.rs writes them.
fn signs_of(f: &Json) -> Result<signs::Writing, JsError> {
    let list = |key: &str| f.get(key).and_then(Json::items).unwrap_or(&[]);
    let whole = |v: &Json, key: &str| -> Result<f64, JsError> {
        match v.num(key) { Some(x) if x.fract() == 0.0 && x >= 0.0 => Ok(x), _ => Err(JsError::type_error(format!("flexData: each sign's {} a whole number", key))) }
    };
    Ok(signs::Writing {
        group: f.num("group").unwrap_or(0.0) as u32,
        meters: list("timeSignatures").iter().map(|m| Ok((whole(m, "time")? as u64, whole(m, "numerator")? as u32, whole(m, "denominator")? as u32))).collect::<Result<_, JsError>>()?,
        keys: list("keySignatures").iter().map(|k| Ok((whole(k, "time")? as u64, k.num("fifths").filter(|x| x.fract() == 0.0).ok_or_else(|| JsError::type_error("flexData: a key's fifths a whole number"))? as i32,
            k.get("mode").and_then(Json::text) == Some("minor")))).collect::<Result<_, JsError>>()?,
        texts: list("texts").iter().map(|t| (t.get("kind").and_then(Json::text).unwrap_or("").to_string(), t.get("text").and_then(Json::text).unwrap_or("").to_string())).collect(),
    })
}
impl JsError {
    pub fn range(message: impl Into<String>) -> JsError { JsError { kind: "RangeError", message: message.into() } }
    pub fn type_error(message: impl Into<String>) -> JsError { JsError { kind: "TypeError", message: message.into() } }
    pub fn error(message: impl Into<String>) -> JsError { JsError { kind: "Error", message: message.into() } }
    pub fn json(&self) -> String { json::obj(vec![("kind", json::text(self.kind)), ("message", json::text(&self.message))]).write_shortest() }
}

/// What a call gives back: JSON text (or a file's bytes), and packets with their times.
#[derive(Default)]
pub struct Answer { pub text: String, pub bytes: Option<Vec<u8>>, pub words: Vec<u32>, pub times: Vec<f64> }
impl Answer {
    fn text(text: String) -> Answer { Answer { text, ..Default::default() } }
    fn timed(timed: Vec<(f64, Vec<u32>)>) -> Answer {
        let mut a = Answer::default();
        for (time, packet) in timed { a.times.push(time); a.words.extend(packet); }
        a
    }
}

/// The calls, as both hosts make them: `name`, the input bytes (a file, a MIDI 1.0 message, or JSON text), the input
/// words and times, and the numbers the C interface passes beside them.
pub struct Core { converters: Vec<Option<translate::Converter>>, trackers: Vec<Option<notes::Tracker>>, texts: Vec<Option<flex::Assembler>> }
impl Default for Core { fn default() -> Core { Core { converters: Vec::new(), trackers: Vec::new(), texts: Vec::new() } } }

fn parse(bytes: &[u8]) -> Result<Json, JsError> {
    let text = std::str::from_utf8(bytes).map_err(|_| JsError::type_error("a text not UTF-8"))?;
    Json::parse(text).map_err(JsError::type_error)
}
// Packets laid end to end, each its message type's length.
fn split(words: &[u32]) -> Result<Vec<&[u32]>, JsError> {
    let mut out = Vec::new();
    let mut at = 0;
    while at < words.len() {
        let n = ump::words_of(words[at]);
        if at + n > words.len() { return Err(JsError::range("UMP packet length does not match its message type")); }
        out.push(&words[at..at + n]);
        at += n;
    }
    Ok(out)
}
fn slot<T>(list: &mut Vec<Option<T>>, value: T) -> u32 {
    match list.iter().position(Option::is_none) { Some(i) => { list[i] = Some(value); i as u32 + 1 } None => { list.push(Some(value)); list.len() as u32 } }
}
fn get<T>(list: &mut [Option<T>], handle: u32) -> Result<&mut T, JsError> {
    list.get_mut((handle as usize).wrapping_sub(1)).and_then(Option::as_mut).ok_or_else(|| JsError::error("midi2-core: no such handle (freed?)"))
}

impl Core {
    pub fn call(&mut self, name: &str, bytes: &[u8], words: &[u32], times: &[f64], a: f64, b: f64) -> Result<Answer, JsError> {
        match name {
            // A MIDI Clip File's bytes -> {ticksPerQuarterNote, headerTicks, endTime, warnings, preamble, header, events}
            // (the counts of each, whose packets and times follow one another in the output); `b` 1 repairs what cannot be
            // read as it stands, as JZZ repaired it, and says so in warnings.
            "read_clip" => {
                let c = if b == 1.0 { clip::read_repairing(bytes)? } else { clip::read(bytes)? };
                let mut a = Answer::default();
                for p in &c.preamble { a.times.push(0.0); a.words.extend(p); }
                for (t, p) in c.header.iter().chain(c.events.iter()) { a.times.push(*t as f64); a.words.extend(p); }
                a.text = json::obj(vec![("ticksPerQuarterNote", json::num(c.ticks_per_quarter as f64)), ("headerTicks", json::num(c.header_ticks as f64)),
                    ("endTime", json::num(c.end as f64)), ("warnings", Json::Array(c.warnings.iter().map(|w| json::text(w)).collect())),
                    ("preamble", json::num(c.preamble.len() as f64)), ("header", json::num(c.header.len() as f64)), ("events", json::num(c.events.len() as f64)),
                    ("flexData", signs::read(&c.header, &c.events))]).write_shortest();
                Ok(a)
            }
            // {ticksPerQuarterNote, headerTicks, endTime, preamble, header, events} and the packets with their times -> the
            // file's bytes (in the output text's place).
            "write_clip" => {
                let spec = parse(bytes)?;
                let packets = split(words)?;
                let count = |k: &str| spec.num(k).unwrap_or(0.0) as usize;
                let (np, nh, ne) = (count("preamble"), count("header"), count("events"));
                if np + nh + ne != packets.len() || packets.len() != times.len() { return Err(JsError::error("midi2-core: write_clip's counts and packets disagree")); }
                let number = |k: &str| match spec.get(k) { Some(Json::Number(x)) => *x, _ => f64::NAN };
                // (The piece's signs, where the writer gives them -- {group, timeSignatures: [{time, numerator, denominator}],
                // keySignatures: [{time, fifths, mode}], texts: [{kind, text}]} -- written as Flex Data: the texts in the
                // header, each sign before the events at its tick.)
                let (sign_header, sign_events) = match spec.given("flexData") { Some(f) => signs::packets(&signs_of(f)?)?, None => (Vec::new(), Vec::new()) };
                let mut events: Vec<(f64, &[u32])> = Vec::with_capacity(packets.len() + sign_events.len());
                let mut signed = sign_events.iter().peekable();
                for i in np + nh..packets.len() {
                    while let Some((tick, p)) = signed.next_if(|(tick, _)| (*tick as f64) <= times[i]) { events.push((*tick as f64, p.as_slice())); }
                    events.push((times[i], packets[i]));
                }
                for (tick, p) in signed { events.push((*tick as f64, p.as_slice())); }
                let w = clip::Writing { ticks_per_quarter: number("ticksPerQuarterNote"), preamble: packets[..np].to_vec(),
                    header: (np..np + nh).map(|i| (times[i], packets[i])).chain(sign_header.iter().map(|(t, p)| (*t as f64, p.as_slice()))).collect(), header_ticks: number("headerTicks"),
                    events, end: number("endTime") };
                Ok(Answer { bytes: Some(clip::write(&w)?), ..Default::default() })
            }
            // A Standard MIDI File's bytes, and the ticks a quarter an SMPTE-timed one is read at (`a`) -> {ticksPerQuarterNote,
            // sourceType, sourceTimebase, warnings, sequences: [{endTime, smfMetadata, notes, events}]}, each sequence's
            // events (its count) following the one before's in the output packets and times.
            "read_smf" => {
                let file = smf::parse(bytes)?;
                let tpq = file.ppqn.map(|p| p as f64).unwrap_or(a);
                let sequences = smf::import(&file, tpq)?;
                let mut answer = Answer::default();
                let mut listed = Vec::new();
                for sequence in &sequences {
                    for (time, packet) in &sequence.events { answer.times.push(*time); answer.words.extend(packet); }
                    listed.push(json::obj(vec![("endTime", json::num(sequence.end)), ("events", json::num(sequence.events.len() as f64)),
                        ("notes", Json::Array(sequence.notes.iter().map(|n| json::text(n)).collect())),
                        ("smfMetadata", Json::Array(sequence.meta.iter().map(|(time, track, kind, data)| json::obj(vec![("time", json::num(*time)),
                            ("track", json::num(*track as f64)), ("type", json::num(*kind as f64)),
                            ("data", Json::Array(data.iter().map(|&b| json::num(b as f64)).collect()))])).collect()))]));
                }
                let timebase = match file.ppqn { Some(p) => json::obj(vec![("ppqn", json::num(p as f64))]),
                    None => json::obj(vec![("fps", json::num(file.fps as f64)), ("ppf", json::num(file.ppf as f64))]) };
                answer.text = json::obj(vec![("ticksPerQuarterNote", json::num(tpq)), ("sourceType", json::num(file.format as f64)), ("sourceTimebase", timebase),
                    ("warnings", Json::Array(file.warnings().iter().map(|w| json::text(w)).collect())), ("sequences", Json::Array(listed))]).write_shortest();
                Ok(answer)
            }
            // Packets laid end to end -> each as JZZ's listing wrote it, its words in hex and its name (ump.rs listed).
            "describe" => Ok(Answer::text(Json::Array(split(words)?.iter().map(|p| json::text(&ump::listed(p))).collect()).write_shortest())),
            // A MIDI Clip File listed as JZZ listed one (clip.rs listing), repaired where it must be -> the text.
            "clip_listing" => Ok(Answer::text(clip::listing(&clip::read_repairing(bytes)?))),
            // A Standard MIDI File's events as its player plays them (timeline.rs), a type 2's sequence `a` alone ->
            // {format, timebase, durationSeconds, events: [[track, index, tick, seconds, velocity]]}.
            "smf_timeline" => {
                let file = smf::parse(bytes)?;
                let t = timeline::smf(&file, a as usize);
                let timebase = match file.ppqn { Some(p) => json::obj(vec![("ppqn", json::num(p as f64))]),
                    None => json::obj(vec![("fps", json::num(file.fps as f64)), ("ppf", json::num(file.ppf as f64))]) };
                Ok(Answer::text(json::obj(vec![("format", json::num(file.format as f64)), ("timebase", timebase), ("durationSeconds", json::num(t.seconds)),
                    ("events", Json::Array(t.events.iter().map(|e| Json::Array(vec![json::num(e.track as f64), json::num(e.index as f64),
                        json::num(e.tick as f64), json::num(e.seconds), json::num(e.velocity as f64)])).collect()))]).write_shortest()))
            }
            // A MIDI Clip File's events as its player plays them -> {ticksPerQuarterNote, durationSeconds, seconds: [each
            // event's]}, the events' packets and ticks in the output words and times (as read_clip's events).
            "clip_timeline" => {
                let c = clip::read(bytes)?;
                let t = timeline::clip(&c);
                let mut answer = Answer::default();
                for (tick, packet) in &c.events { answer.times.push(*tick as f64); answer.words.extend(packet); }
                answer.text = json::obj(vec![("ticksPerQuarterNote", json::num(c.ticks_per_quarter as f64)), ("durationSeconds", json::num(t.seconds)),
                    ("seconds", Json::Array(t.events.iter().map(|e| json::num(e.seconds)).collect()))]).write_shortest();
                Ok(answer)
            }
            // One MIDI 1.0 Channel Voice packet upgraded on its own -> its MIDI 2.0 packet, or none.
            "upgrade" => Ok(Answer { words: translate::upgrade(a as u32).map(|p| p.to_vec()).unwrap_or_default(), ..Default::default() }),
            // A MIDI 1.0 message's bytes as UMP on Group `a`, unchanged in protocol.
            "pack" => Ok(Answer { words: translate::pack(bytes, a as u32).concat(), ..Default::default() }),
            "converter_new" => Ok(Answer::text(slot(&mut self.converters, translate::Converter::new(a as u32)).to_string())),
            "converter_free" => { if let Some(s) = self.converters.get_mut((a as usize).wrapping_sub(1)) { *s = None; } Ok(Answer::default()) }
            "converter_convert" => Ok(Answer::timed(get(&mut self.converters, a as u32)?.convert(bytes, b)?)),
            "converter_flush" => Ok(Answer::timed(get(&mut self.converters, a as u32)?.flush())),
            "converter_checkpoint" => Ok(Answer::text(get(&mut self.converters, a as u32)?.checkpoint().write_shortest())),
            "converter_restore" => { let value = parse(bytes)?; get(&mut self.converters, a as u32)?.restore(&value)?; Ok(Answer::default()) }
            // {ticksPerQuarterNote, bendRange, retainHistory, maxActiveNotes} -> a tracker's handle.
            "tracker_new" => { let t = notes::Tracker::from_json(&parse(bytes)?)?; Ok(Answer::text(slot(&mut self.trackers, t).to_string())) }
            "tracker_free" => { if let Some(s) = self.trackers.get_mut((a as usize).wrapping_sub(1)) { *s = None; } Ok(Answer::default()) }
            // One packet at time `b`; a header's (at time 0, its notes not played) where the input bytes' first says so,
            // and the index the caller knows its event by in the next four (little-endian).
            "tracker_consume" => {
                let source = bytes.get(1..5).map(|b| u32::from_le_bytes([b[0], b[1], b[2], b[3]]) as usize).unwrap_or(0);
                get(&mut self.trackers, a as u32)?.consume(b, words, bytes.first() == Some(&1), source)?;
                Ok(Answer::default())
            }
            "tracker_snapshot" => Ok(Answer::text(get(&mut self.trackers, a as u32)?.snapshot().write_shortest())),
            "tracker_checkpoint" => Ok(Answer::text(get(&mut self.trackers, a as u32)?.checkpoint()?.write_shortest())),
            "tracker_restore" => { let value = parse(bytes)?; get(&mut self.trackers, a as u32)?.restore(&value)?; Ok(Answer::default()) }
            "tracker_finish" => { let t = get(&mut self.trackers, a as u32)?; let n = t.finish_all(b)?; Ok(Answer::text(notes::notes_json(&n).write_shortest())) }
            // A whole trace (traceUmpNotes): the configuration and {header, endTime} as JSON, the header's packets then the
            // events' with their times -> the notes.
            "trace" => {
                let spec = parse(bytes)?;
                let mut t = notes::Tracker::from_json(&spec)?;
                let packets = split(words)?;
                let header = spec.num("header").unwrap_or(0.0) as usize;
                if packets.len() != times.len() || header > packets.len() { return Err(JsError::error("midi2-core: trace's counts and packets disagree")); }
                for (i, p) in packets.iter().enumerate() { t.consume(times[i], p, i < header, i)?; }
                let end = match spec.get("endTime") { Some(Json::Number(x)) => *x, _ => f64::NAN };
                let n = t.finish_all(end)?;
                Ok(Answer::text(notes::notes_json(&n).write_shortest()))
            }
            // A text's UTF-8 as one Flex Data message, `a` its first word (Group, Address, Channel, Status Bank, Status) -> its
            // packets.
            "flex_text" => Ok(Answer { words: flex::packets(a as u32, bytes)?.concat(), ..Default::default() }),
            // A sung note's syllable: {group, channel, lyric: the score's record (notation/lyrics.js: text, syllable,
            // syllables, continues, melisma), language? (where the singer's changes)} -> its Lyric Language where given and
            // its Lyric Data, as packets (signs.rs lyric): its word ended where it is the word's last syllable or the word
            // goes no further.
            "lyric" => {
                let spec = parse(bytes)?;
                let record = spec.get("lyric").unwrap_or(&Json::Null);
                let syllable = record.num("syllable").unwrap_or(0.0);
                let ends_word = record.get("continues").and_then(Json::boolean) == Some(false) || syllable >= record.num("syllables").unwrap_or(1.0) - 1.0;
                let packets = signs::lyric(spec.num("group").unwrap_or(0.0) as u32, spec.num("channel").unwrap_or(0.0) as u32, record.get("text").and_then(Json::text).unwrap_or(""),
                    ends_word, record.get("melisma").and_then(Json::boolean).unwrap_or(false), spec.get("language").and_then(Json::text))?;
                Ok(Answer { words: packets.concat(), ..Default::default() })
            }
            // Flex Data texts put back together: `a` the bytes a message may gather -> an assembler's handle; one packet
            // from the endpoint the input bytes name -> {text} where it ends a message, else null.
            "text_new" => Ok(Answer::text(slot(&mut self.texts, flex::Assembler::new(a)).to_string())),
            "text_free" => { if let Some(s) = self.texts.get_mut((a as usize).wrapping_sub(1)) { *s = None; } Ok(Answer::default()) }
            "text_push" => {
                let endpoint = std::str::from_utf8(bytes).map_err(|_| JsError::type_error("an endpoint not UTF-8"))?;
                Ok(Answer::text(match get(&mut self.texts, a as u32)?.push(words, endpoint)? {
                    Some(text) => json::obj(vec![("text", json::text(&text))]).write_shortest(), None => "null".to_string() }))
            }
            "text_open" => Ok(Answer::text(get(&mut self.texts, a as u32)?.open().to_string())),
            "text_reset" => { get(&mut self.texts, a as u32)?.reset(); Ok(Answer::default()) }
            _ => Err(JsError::error(format!("midi2-core: no call {}", name))),
        }
    }
}
// ---- The C interface (the WASM host's) --------------------------------------------------------------------------------
// Input buffers the caller writes into, and the last answer's buffers it reads; reused call to call (single-threaded).
struct Io { bytes: Vec<u8>, words: Vec<u32>, times: Vec<f64>, out: Vec<u8>, out_words: Vec<u32>, out_times: Vec<f64>, core: Option<Core> }
static mut IO: Io = Io { bytes: Vec::new(), words: Vec::new(), times: Vec::new(), out: Vec::new(), out_words: Vec::new(), out_times: Vec::new(), core: None };
fn io() -> &'static mut Io { unsafe { &mut *std::ptr::addr_of_mut!(IO) } }

#[no_mangle] pub extern "C" fn m2_abi_version() -> u32 { ABI_VERSION }
#[no_mangle] pub extern "C" fn m2_in_bytes(n: u32) -> *mut u8 { let io = io(); io.bytes.resize(n as usize, 0); io.bytes.as_mut_ptr() }
#[no_mangle] pub extern "C" fn m2_in_words(n: u32) -> *mut u32 { let io = io(); io.words.resize(n as usize, 0); io.words.as_mut_ptr() }
#[no_mangle] pub extern "C" fn m2_in_times(n: u32) -> *mut f64 { let io = io(); io.times.resize(n as usize, 0.0); io.times.as_mut_ptr() }
#[no_mangle] pub extern "C" fn m2_out() -> *const u8 { io().out.as_ptr() }
#[no_mangle] pub extern "C" fn m2_out_len() -> u32 { io().out.len() as u32 }
#[no_mangle] pub extern "C" fn m2_out_words() -> *const u32 { io().out_words.as_ptr() }
#[no_mangle] pub extern "C" fn m2_out_words_len() -> u32 { io().out_words.len() as u32 }
#[no_mangle] pub extern "C" fn m2_out_times() -> *const f64 { io().out_times.as_ptr() }
#[no_mangle] pub extern "C" fn m2_out_times_len() -> u32 { io().out_times.len() as u32 }
/// The name (its UTF-8 in the input bytes' first `name` bytes, the call's own bytes after it), and the call's input
/// lengths: its answer, or its error, in the output buffers.
#[no_mangle] pub extern "C" fn m2_call(name: u32, bytes: u32, words: u32, times: u32, a: f64, b: f64) -> u32 {
    let io = io();
    let core = io.core.get_or_insert_with(Core::default);
    let (name_bytes, rest) = io.bytes.split_at(name as usize);
    let name = std::str::from_utf8(name_bytes).unwrap_or("");
    let result = core.call(name, &rest[..bytes as usize], &io.words[..words as usize], &io.times[..times as usize], a, b);
    io.out.clear(); io.out_words.clear(); io.out_times.clear();
    match result {
        Ok(answer) => {
            match answer.bytes { Some(file) => io.out = file, None => io.out.extend_from_slice(answer.text.as_bytes()) }
            io.out_words = answer.words; io.out_times = answer.times;
            0
        }
        Err(error) => { io.out.extend_from_slice(error.json().as_bytes()); 1 }
    }
}
