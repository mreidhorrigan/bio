//! A file's events laid out and timed for playback, as JZZ's player laid them out and timed them (its Player `_timing`
//! and `tick2ms`, JZZ 1.9.6 with jzz-midi-smf 1.9.9): for experiments/input-influence/recording-input.mjs, which replays
//! a recording's attacks at the times the file encodes, and until 13 November 2026 took them from JZZ (the owner: "fix
//! these"). The arithmetic is JZZ's, operation for operation, so a recording's times come out to the last bit as before.
//!
//! In quarter-note time a tick lasts 500 ms a quarter until a tempo says otherwise; each tempo holds from its tick, in
//! the file's order, the later of two at one tick winning; a clip's header sets the tempo it opens at, its last Set Tempo
//! (§6.1's own timeline aside, as JZZ read it). In SMPTE time a tick is a fixed share of a second, 29 frames a second
//! meaning 29.97, drop-frame (the experiment's own reading, which it did not leave to JZZ's player: that took 29 as 29).
//! A file plays to its last event's tick.
//!
//! Changed from JZZ, as the core reads a clip: a Set Tempo is one on any Group and Address (§7.5.3; JZZ heard only those
//! sent to a Group) and a tempo of 0 is none (JZZ took it as 1, ten nanoseconds a quarter, and the rest of the clip
//! passed in an instant). A Standard MIDI File's tempo of 0, or one cut short of three bytes, is still JZZ's 1
//! microsecond a quarter: that is how the recordings already prepared were timed.

use crate::clip::Clip;
use crate::smf::{Message, Smf};
use crate::ump;

/// Milliseconds from ticks, piecewise: from each tick, a tempo's ticks a millisecond (JZZ's `_ttt`).
#[derive(Clone, Debug)]
pub struct TempoMap { segments: Vec<(f64, f64, f64)>, duration: f64, duration_ms: f64 }
impl TempoMap {
    /// Quarter-note time at `ppqn`: the header's tempo (ticks a millisecond) where a clip has one, then each change in
    /// the data in order (its tick, its ticks a millisecond), to `duration` ticks.
    pub fn quarters(ppqn: f64, header: Option<f64>, changes: &[(f64, f64)], duration: f64) -> TempoMap {
        let mut m = header.unwrap_or(ppqn / 500.0);
        let (mut t, mut ms) = (0.0, 0.0);
        let mut segments = vec![(0.0, m, 0.0)];
        for &(tick, next) in changes {
            ms += (tick - t) / m;
            t = tick;
            m = next;
            segments.push((t, m, ms));
        }
        ms += (duration - t) / m;
        segments.push((duration, 0.0, ms));
        TempoMap { segments, duration, duration_ms: if ms == 0.0 || ms.is_nan() { 1.0 } else { ms } }
    }
    /// A tick's milliseconds (JZZ's tick2ms): 0 at or before the start, the whole length at or after the end.
    pub fn ms(&self, t: f64) -> f64 {
        if t <= 0.0 { return 0.0; }
        if t >= self.duration { return self.duration_ms; }
        let i = self.segments.iter().position(|s| s.0 >= t).unwrap_or(self.segments.len()) - 1;
        let (from, m, ms) = self.segments[i];
        ms + (t - from) / m
    }
}

/// A Standard MIDI File's tempo meta event as JZZ's getTempo read it: microseconds a quarter from its first three bytes,
/// and 1 where it has fewer or says 0.
fn smf_tempo(data: &[u8]) -> f64 {
    if data.len() < 3 { return 1.0; }
    let tempo = (data[0] as u32) << 16 | (data[1] as u32) << 8 | data[2] as u32;
    if tempo == 0 { 1.0 } else { tempo as f64 }
}

/// One event of a timeline: its track and place there, its tick and seconds, and the velocity of a MIDI 1.0 Note On
/// that sounds (0 for anything else).
#[derive(Clone, Debug, PartialEq)]
pub struct Timed { pub track: usize, pub index: usize, pub tick: u64, pub seconds: f64, pub velocity: u8 }
/// A file's events in playing order, with the seconds the whole lasts.
#[derive(Clone, Debug, PartialEq)]
pub struct Timeline { pub events: Vec<Timed>, pub seconds: f64 }

/// A Standard MIDI File's events as its player plays them: a type 2's `sequence`'s track alone, any other's every track,
/// merged by tick, then track, then place in its track (JZZ's sort for a type 1). Seconds from the tempo meta events in
/// that order (quarter-note time), or from the frame rate (SMPTE time: 29 frames read as 29.97).
pub fn smf(file: &Smf, sequence: usize) -> Timeline {
    let tracks: Vec<usize> = if file.format == 2 { file.tracks.get(sequence).map(|_| vec![sequence]).unwrap_or_default() } else { (0..file.tracks.len()).collect() };
    let mut order: Vec<(u64, usize, usize)> = tracks.iter().flat_map(|&k| file.tracks[k].iter().enumerate().map(move |(i, e)| (e.tick, k, i))).collect();
    order.sort();
    let duration = order.last().map(|o| o.0).unwrap_or(0) as f64;
    let seconds: Box<dyn Fn(u64) -> f64> = match file.ppqn {
        Some(ppqn) => {
            let ppqn = ppqn as f64;
            let changes: Vec<(f64, f64)> = order.iter().filter_map(|&(tick, k, i)| match &file.tracks[k][i].message {
                Message::Meta(0x51, data) => Some((tick as f64, ppqn * 1e3 / smf_tempo(data))), _ => None }).collect();
            let map = TempoMap::quarters(ppqn, None, &changes, duration);
            Box::new(move |tick| map.ms(tick as f64) / 1000.0)
        }
        None => {
            let (fps, ppf) = (file.fps as f64, file.ppf as f64);
            let rate = (if file.fps == 29 { 30000.0 / 1001.0 } else { fps }) * ppf;
            Box::new(move |tick| tick as f64 / rate)
        }
    };
    let events = order.iter().map(|&(tick, k, i)| {
        let velocity = match &file.tracks[k][i].message {
            Message::Midi(b) if b.len() >= 2 && b[0] & 0xF0 == 0x90 => b.get(2).copied().unwrap_or(0),
            _ => 0,
        };
        Timed { track: k, index: i, tick, seconds: seconds(tick), velocity }
    }).collect();
    Timeline { events, seconds: seconds(duration as u64) }
}

/// A clip's events as its player plays them, in the clip's order: seconds from its header's last Set Tempo and each in
/// its data, to End of Clip.
pub fn clip(c: &Clip) -> Timeline {
    let ppqn = c.ticks_per_quarter as f64;
    let per_ms = |tempo: u32| ppqn * 1e5 / tempo as f64;
    let header = c.header.iter().filter_map(|(_, p)| ump::tempo(p)).last().map(per_ms);
    let changes: Vec<(f64, f64)> = c.events.iter().filter_map(|(tick, p)| ump::tempo(p).map(|tempo| (*tick as f64, per_ms(tempo)))).collect();
    let map = TempoMap::quarters(ppqn, header, &changes, c.end as f64);
    let events = c.events.iter().enumerate().map(|(i, (tick, _))| Timed { track: 0, index: i, tick: *tick, seconds: map.ms(*tick as f64) / 1000.0, velocity: 0 }).collect();
    Timeline { events, seconds: map.ms(c.end as f64) / 1000.0 }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn a_tempo_holds_from_its_tick_and_the_later_of_two_wins() {
        // 480 a quarter: 500 ms a quarter, then from tick 480 a second a quarter (twice at that tick: the later holds).
        let map = TempoMap::quarters(480.0, None, &[(480.0, 480.0 * 1e3 / 2_000_000.0), (480.0, 480.0 * 1e3 / 1_000_000.0)], 1920.0);
        assert_eq!([0.0, 240.0, 480.0, 960.0, 1920.0, 5000.0].map(|t| map.ms(t)), [0.0, 250.0, 500.0, 1500.0, 3500.0, 3500.0]);
    }

    #[test]
    fn an_empty_file_lasts_jzzs_millisecond_but_reads_0_at_its_start() {
        let map = TempoMap::quarters(96.0, None, &[], 0.0);
        assert_eq!((map.ms(0.0), map.ms(1.0)), (0.0, 1.0));
    }

    #[test]
    fn a_short_or_zero_tempo_is_jzzs_microsecond() {
        assert_eq!([smf_tempo(&[7, 0xa1]), smf_tempo(&[0, 0, 0]), smf_tempo(&[7, 0xa1, 0x20, 9])], [1.0, 1.0, 500_000.0]);
    }
}
