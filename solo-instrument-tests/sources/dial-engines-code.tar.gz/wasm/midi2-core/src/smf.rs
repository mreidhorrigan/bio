//! Standard MIDI Files (the MIDI 1.0 file format, types 0, 1 and 2, and RIFF RMID around one), read and brought into
//! MIDI 2.0 (public/shared/midi-files.js importMidi1File; ported 13 November 2026 from JZZ.MIDI.SMF 1.9.9, which had
//! parsed them, and from the importer's JavaScript). Read as JZZ read them -- the same events at the same ticks, its
//! repairs (a data byte over 127 read as 0), its warnings in its words and its order, the lint of its validation among
//! them (an unused Bank Select, RPN or NRPN) -- and imported as the JavaScript imported them: tracks merged in time order
//! (type 2's each its own sequence), SMPTE time made musical at the tempo then in force, a tempo and a time signature as
//! Flex Data, every meta event kept as metadata, System Exclusive gathered across its packets, and the MIDI 1.0 stream
//! translated (translate.rs Converter).
//!
//! What it does that JZZ and the JavaScript did not: a header longer than six bytes is read, its extra skipped (the SMF
//! specification lets it grow; JZZ refused the file); a track count of 256 or more is counted rightly (JZZ multiplied its
//! high byte by 16); a time signature Flex Data cannot carry -- a numerator of 0, more than 255 32nds a bar (the ASAP
//! scores' 65/4 and 175/4 cadenzas), a denominator's power over 30 -- is kept as metadata alone, where JZZ refused the
//! whole file or, at a power of 31, never returned; a tempo meta event too short, or a tempo of 0 in an SMPTE-timed
//! file, does not make every later time NaN or infinite; an F7 escape that continues no System Exclusive is read as the
//! whole message it carries (a real-time, common or channel message, or a System Exclusive), where the JavaScript refused
//! the file. A file cut off is read as far as JZZ read it -- a meta event or System Exclusive kept as far as it goes, a
//! message's missing data as zeros -- and, where JZZ said "Incomplete", refused, its warnings all said.

use crate::translate::Converter;
use crate::JsError;

#[derive(Clone, Debug, PartialEq)]
pub enum Message {
    /// A channel voice message, or a system common or real-time one: its status and data bytes.
    Midi(Vec<u8>),
    /// A meta event: its type and data.
    Meta(u8, Vec<u8>),
    /// System Exclusive: F0 or F7, then its bytes.
    Sysex(Vec<u8>),
}
#[derive(Clone, Debug)]
pub struct Event { pub tick: u64, pub offset: usize, pub track: usize, pub message: Message }

/// A warning as JZZ made it: its byte offset, track and tick (by which they are sorted, as JZZ sorts them) and words.
#[derive(Clone, Debug)]
struct Warning { offset: usize, track: Option<usize>, tick: Option<i64>, message: String }

#[derive(Clone, Debug, Default)]
pub struct Smf {
    /// The file's type (0, 1 or 2) as JZZ took it: a type over 2, or a type 0 of several tracks, read as 1.
    pub format: u32,
    pub ppqn: Option<u32>,
    pub fps: u32,
    pub ppf: u32,
    pub tracks: Vec<Vec<Event>>,
    warnings: Vec<Warning>,
    // (Each track's own, which JZZ lists after the file's.)
    track_warnings: Vec<Warning>,
}
impl Smf { pub fn warnings(&self) -> Vec<String> { self.warnings.iter().map(|w| w.message.clone()).collect() } }

const HEADER: &[u8; 8] = b"MThd\0\0\0\x06";

fn msg_len(status: u8) -> usize {
    match status & 0xF0 { 0x80 | 0x90 | 0xA0 | 0xB0 | 0xE0 => return 2, 0xC0 | 0xD0 => return 1, _ => {} }
    match status { 0xF1 | 0xF3 => 1, 0xF2 => 2, _ => 0 }
}

/// A file's bytes read, or why they cannot be: not a MIDI file, a header with no timebase, no tracks (JZZ's errors), or
/// data cut off (JZZ's "Incomplete" warnings, which the importer refused).
pub fn parse(bytes: &[u8]) -> Result<Smf, JsError> {
    let mut smf = Smf::default();
    let mut s = bytes;
    let mut off = 0usize;
    // RIFF RMID: the SMF in its "data" chunk.
    if s.len() >= 20 && &s[0..4] == b"RIFF" && &s[8..16] == b"RMIDdata" {
        let len = u32::from_le_bytes([s[16], s[17], s[18], s[19]]) as usize;
        off = 20;
        s = &s[20..(20 + len).min(s.len())];
    }
    // A header of length 6, or longer (its extra skipped).
    let header_at = |s: &[u8]| s.windows(8).position(|w| &w[..4] == b"MThd" && u32::from_be_bytes([w[4], w[5], w[6], w[7]]) >= 6);
    let longer = s.len() >= 8 && &s[..4] == b"MThd" && &s[..8] != HEADER;
    if &s.get(..8).unwrap_or(&[]) != HEADER {
        match s.windows(8).position(|w| w == HEADER).or_else(|| header_at(s)) {
            Some(0) => {}
            Some(z) => { smf.warn(off, None, None, "Extra leading characters"); s = &s[z..]; off += z; }
            None => return Err(JsError::error("Not a MIDI file")),
        }
    }
    if s.len() < 14 { return Err(JsError::error("Invalid MIDI header")); }
    let header_len = u32::from_be_bytes([s[4], s[5], s[6], s[7]]) as usize;
    if longer && header_len > 6 { smf.warn(off + 4, None, None, &format!("a header {} bytes long: its last {} skipped", header_len, header_len - 6)); }
    let mut format = (s[8] as u32) << 8 | s[9] as u32;
    let declared = (s[10] as usize) << 8 | s[11] as usize;
    if s[12] > 0x7F { smf.fps = 0x100 - s[12] as u32; smf.ppf = s[13] as u32; } else { smf.ppqn = Some((s[12] as u32) << 8 | s[13] as u32); }
    if format > 2 { smf.warn(8 + off, None, None, "Invalid MIDI file type"); }
    else if format == 0 && declared > 1 { smf.warn(10 + off, None, None, "Wrong number of tracks for the type 0 MIDI file"); }
    if smf.ppf == 0 && smf.ppqn.unwrap_or(0) == 0 { return Err(JsError::error("Invalid MIDI header")); }
    let mut incomplete = false;
    let mut found = 0usize;
    let mut p = 8 + header_len.max(6);
    while p + 8 < s.len() {
        let offset = p + off;
        let kind = &s[p..p + 4];
        let mut len = u32::from_be_bytes([s[p + 4], s[p + 5], s[p + 6], s[p + 7]]) as i64;
        if len > i32::MAX as i64 { len -= 1 << 32; }
        if len <= 0 { len = (s.len() - p - 8) as i64; smf.warn(p + off + 4, None, None, "Invalid track length"); }
        let len = len as usize;
        p += 8;
        let data = &s[p..(p + len).min(s.len())];
        if kind == b"MTrk" {
            let track = smf.tracks.len();
            let (events, cut) = smf.track(data, offset, track);
            incomplete |= cut;
            smf.tracks.push(events);
            found += 1;
        }
        if kind == b"MThd" { smf.warn(offset, None, None, "Unexpected chunk type"); }
        p += len;
    }
    if found != declared { smf.warn(off + 10, None, None, "Incorrect number of tracks"); }
    if found == 0 { return Err(JsError::error("No MIDI tracks")); }
    if format == 0 && found > 1 || format > 2 { format = 1; }
    smf.format = format;
    if p < s.len() { smf.warn(off + p, None, None, "Extra trailing characters"); }
    if p > s.len() { smf.warn(off + s.len(), None, None, "Incomplete data"); incomplete = true; }
    smf.lint();
    if incomplete {
        return Err(JsError::error(format!("Invalid MIDI file: {}", smf.warnings().join("; "))));
    }
    Ok(smf)
}

impl Smf {
    fn warn(&mut self, offset: usize, track: Option<usize>, tick: Option<i64>, message: &str) {
        self.warnings.push(Warning { offset, track, tick, message: message.to_string() });
    }

    // A variable-length quantity at `at`, as JZZ reads one (up to four bytes, a byte the track lacks read as 0): its length
    // and value, None where no byte of it is there; non-minimal forms said, and one never ended ("Bad byte sequence").
    // Its warning's tick is the event's, the quantity added where it is a delta time.
    fn vlq(&mut self, s: &[u8], at: usize, offset: usize, track: usize, tick: u64, delta: bool) -> Option<(usize, u64)> {
        if at >= s.len() { return None; }
        let mut x: u64 = 0;
        for i in 0..4 {
            let present = s.get(at + i).copied();
            let byte = present.unwrap_or(0);
            let ended = present.map_or(false, |b| b < 0x80);
            // (JZZ adds a delta time to its warning's tick, the never-ended one negative, as it read it.)
            let tick_of = |x: u64, bad: bool| Some(tick as i64 + if !delta { 0 } else if bad { -(x as i64) } else { x as i64 });
            if i == 3 || ended {
                x += (byte & if ended { 0xFF } else { 0x7F }) as u64;
                // (One never ended whose bits are all 0 JZZ reads as -0, which is no less than 0: a long one, to it.)
                if !ended && x > 0 { self.track_warnings.push(Warning { offset, track: Some(track), tick: tick_of(x, true), message: "Bad byte sequence".into() }); }
                else if !ended { self.track_warnings.push(Warning { offset, track: Some(track), tick: tick_of(0, false), message: "Long VLQ value".into() }); }
                else if (i == 3 && x < 0x200000) || (i == 2 && x < 0x4000) || (i == 1 && x < 0x80) {
                    self.track_warnings.push(Warning { offset, track: Some(track), tick: tick_of(x, false), message: "Long VLQ value".into() });
                }
                return Some((i + 1, x));
            }
            x = (x + (byte & 0x7F) as u64) << 7;
        }
        unreachable!()
    }

    // A track's events (JZZ's MTrk): delta times, meta events, System Exclusive, and MIDI messages with running status;
    // and whether a message's data was cut off (JZZ's "Incomplete track data", which the importer refused). A meta event
    // or System Exclusive the track's end cuts off is kept as far as it goes, as JZZ kept it.
    fn track(&mut self, s: &[u8], chunk: usize, track: usize) -> (Vec<Event>, bool) {
        let mut events = Vec::new();
        let base = chunk + 8;
        let (mut p, mut t, mut status, mut running) = (0usize, 0u64, 0u8, false);
        // (A delta time's warning carries the previous event's offset -- the track's start for the first -- as JZZ's do:
        // it updates its offset only after reading the delta.)
        let mut offset = base;
        while p < s.len() {
            let (n, delta) = self.vlq(s, p, offset, track, t, true).unwrap();
            p += n;
            t += delta;
            offset = p + base;
            match s.get(p).copied() {
                Some(0xFF) => {
                    running = false;
                    if p + 2 > s.len() { self.complain(offset, track, t); return (events, true); }
                    let kind = s[p + 1];
                    p += 2;
                    let (n, len) = self.vlq(s, p, offset + 2, track, t, false).unwrap_or((0, 0));
                    p += n;
                    let data = s.get(p..(p + len as usize).min(s.len())).unwrap_or(&[]).to_vec();
                    events.push(Event { tick: t, offset, track, message: Message::Meta(kind, data) });
                    p += len as usize;
                    if n == 0 { break; }
                }
                Some(first @ (0xF0 | 0xF7)) => {
                    running = false;
                    p += 1;
                    let (n, len) = self.vlq(s, p, offset + 1, track, t, false).unwrap_or((0, 0));
                    p += n;
                    let mut bytes = vec![first];
                    bytes.extend_from_slice(s.get(p..(p + len as usize).min(s.len())).unwrap_or(&[]));
                    events.push(Event { tick: t, offset, track, message: Message::Sysex(bytes) });
                    p += len as usize;
                    if n == 0 { break; }
                }
                first if first.map_or(false, |b| b & 0x80 != 0) || status & 0x80 != 0 => {
                    let explicit = first.map_or(false, |b| b & 0x80 != 0);
                    if explicit { status = first.unwrap(); p += 1; }
                    else if !running { self.track_warnings.push(Warning { offset, track: Some(track), tick: Some(t as i64), message: "Interrupted running status".into() }); }
                    running = true;
                    let m = msg_len(status);
                    if status > 0xF0 { self.track_warnings.push(Warning { offset, track: Some(track), tick: Some(t as i64), message: "Unexpected MIDI message".into() }); }
                    let data_at = if explicit { offset + 1 } else { offset };
                    // (Data cut off: said, zeros in its place, and the event kept, as JZZ keeps it -- the file is refused.)
                    let cut = p + m > s.len();
                    if cut { self.complain(data_at, track, t); }
                    let mut bytes = vec![status];
                    for i in 0..m {
                        let byte = s.get(p + i).copied().unwrap_or(0);
                        if byte > 127 {
                            self.track_warnings.push(Warning { offset: data_at + i, track: Some(track), tick: Some(t as i64), message: "Bad MIDI value set to 0".into() });
                            bytes.push(0);
                        } else { bytes.push(byte); }
                    }
                    events.push(Event { tick: t, offset, track, message: Message::Midi(bytes) });
                    p += m;
                    if cut { return (events, true); }
                }
                // (A data byte with no status before it is read as the next delta time, as JZZ reads it.)
                _ => {}
            }
        }
        (events, false)
    }
    fn complain(&mut self, offset: usize, track: usize, tick: u64) {
        self.track_warnings.push(Warning { offset, track: Some(track), tick: Some(tick as i64), message: "Incomplete track data".into() });
    }

    // JZZ's validation of the events (SMF.validate): its meta event checks and its lint of Bank Select, RPN and NRPN,
    // over the events in the order it took them (a type 1's tracks merged by time, others' one after another); then
    // every warning in the order it sorts them, by offset, track and tick.
    fn lint(&mut self) {
        let order: Vec<(usize, usize)> = if self.format != 1 {
            self.tracks.iter().enumerate().flat_map(|(k, t)| (0..t.len()).map(move |i| (k, i))).collect()
        } else {
            let mut out = Vec::new();
            let mut at = vec![0usize; self.tracks.len()];
            let mut time = 0u64;
            loop {
                let mut next: Option<u64> = None;
                for (k, track) in self.tracks.iter().enumerate() {
                    while at[k] < track.len() && track[at[k]].tick == time { out.push((k, at[k])); at[k] += 1; }
                    if at[k] >= track.len() { continue; }
                    let t = track[at[k]].tick;
                    next = Some(next.map_or(t, |n: u64| n.min(t)));
                }
                match next { Some(t) => time = t, None => break }
            }
            out
        };
        let mut found: Vec<Warning> = Vec::new();
        let mut state = Lint::default();
        let first_track = self.format == 1;
        for &(k, i) in &order {
            let e = &self.tracks[k][i];
            if let Some(message) = meta_issue(e, first_track) { found.push(Warning { offset: e.offset, track: Some(e.track), tick: Some(e.tick as i64), message }); }
            state.update(e, &mut found);
        }
        state.reset(&mut found);
        let mut all = std::mem::take(&mut self.warnings);
        all.append(&mut self.track_warnings);
        all.extend(found);
        // (JavaScript's sort is stable: those equal keep their order.)
        all.sort_by_key(|w| (w.offset, w.track.unwrap_or(0), w.tick.unwrap_or(0)));
        self.warnings = all;
    }
}

// A meta event's problem, in JZZ's words (_validate_midi).
fn meta_issue(e: &Event, first_track: bool) -> Option<String> {
    let Message::Meta(kind, d) = &e.message else { return None };
    let len = |name: &str, want: usize| -> Option<String> {
        if d.len() < want { Some(format!("Invalid {} meta event: {}", name, if d.is_empty() { "no data" } else { "data too short" })) }
        else if d.len() > want { Some(format!("Invalid {} meta event: data too long", name)) } else { None }
    };
    let elsewhere = |name: &str| (first_track && e.track != 0).then(|| format!("{} meta events must be in the first track", name));
    let byte = |i: usize| d.get(i).copied().unwrap_or(0);
    match *kind {
        k if k > 0x7F => Some("Invalid meta event".into()),
        0 => len("Sequence Number", 2),
        1..=9 => d.is_empty().then(|| "Invalid Text meta event: no data".into()),
        32 => len("Channel Prefix", 1).or_else(|| (byte(0) > 15).then(|| "Invalid Channel Prefix meta event: incorrect data".into())),
        33 => len("MIDI Port", 1).or_else(|| (byte(0) > 127).then(|| "Invalid MIDI Port meta event: incorrect data".into())),
        47 => len("End of Track", 0),
        81 => len("Tempo", 3).or_else(|| elsewhere("Tempo")),
        84 => len("SMPTE", 5).or_else(|| {
            if (byte(0) & 0x1F) >= 24 || byte(1) >= 60 || byte(2) >= 60 || byte(3) >= 30 || byte(4) >= 200 || byte(4) % 25 != 0 {
                Some("Invalid SMPTE meta event: incorrect data".into())
            } else if byte(0) >> 5 > 3 { Some("Invalid SMPTE meta event: incorrect format".into()) } else { elsewhere("SMPTE") }
        }),
        88 => len("Time Signature", 4).or_else(|| if byte(1) > 8 { Some("Invalid Time Signature meta event: incorrect data".into()) } else { elsewhere("Time Signature") }),
        89 => len("Key Signature", 2).or_else(|| (byte(1) > 1 || (byte(0) > 7 && byte(0) < 249)).then(|| "Invalid Key Signature meta event: incorrect data".into())),
        127 => None,
        _ => Some("Unknown meta event".into()),
    }
}

// JZZ's lint state per channel (_update_state, _reset_state, _check_unused): each selection's event and whether it was
// used -- Bank Select MSB and LSB (bm, bl), NRPN MSB and LSB (nm, nl), RPN MSB and LSB (rm, rl).
#[derive(Default)]
struct Lint { channels: [[Option<(usize, u8, bool)>; 6]; 16], events: Vec<(usize, usize, i64)> }
const BM: usize = 0; const BL: usize = 1; const NM: usize = 2; const NL: usize = 3; const RM: usize = 4; const RL: usize = 5;
impl Lint {
    // (Each kept as the index of its event in `events`, its value, and whether it was used.)
    fn unused(&mut self, ch: usize, x: usize, out: &mut Vec<Warning>) {
        if let Some((e, _, false)) = self.channels[ch][x] {
            let (offset, track, tick) = self.events[e];
            let message = match x { BM | BL => "Unnecessary Bank Select", NM | NL => "Unnecessary NRPN", _ => "Unnecessary RPN" };
            out.push(Warning { offset, track: Some(track), tick: Some(tick), message: message.into() });
            self.channels[ch][x] = None;
        }
    }
    fn reset(&mut self, out: &mut Vec<Warning>) {
        for ch in 0..16 {
            if let (Some(rm), Some(rl)) = (self.channels[ch][RM], self.channels[ch][RL]) {
                if rm.1 == 0x7F && rl.1 == 0x7F { self.channels[ch][RM].as_mut().unwrap().2 = true; self.channels[ch][RL].as_mut().unwrap().2 = true; }
            }
            for x in [BM, BL, NM, NL, RM, RL] { self.unused(ch, x, out); }
            self.channels[ch] = [None; 6];
        }
    }
    fn update(&mut self, e: &Event, out: &mut Vec<Warning>) {
        let bytes = match &e.message { Message::Midi(b) | Message::Sysex(b) => b, Message::Meta(..) => return };
        if bytes.is_empty() || bytes[0] < 0x80 { return; }
        if is_reset(bytes) { self.reset(out); return; }
        let (st, ch) = ((bytes[0] >> 4) as usize, (bytes[0] & 15) as usize);
        let warn = |out: &mut Vec<Warning>, at: (usize, usize, i64), message: &str| out.push(Warning { offset: at.0, track: Some(at.1), tick: Some(at.2), message: message.into() });
        let here = (e.offset, e.track, e.tick as i64);
        let index = self.events.len();
        let select = |this: &mut Lint, x: usize| { this.events.push(here); this.channels[ch][x] = Some((index, bytes.get(2).copied().unwrap_or(0), false)); };
        if st == 0xB {
            match bytes.get(1).copied().unwrap_or(0) {
                0 => { self.unused(ch, BM, out); select(self, BM); }
                0x20 => { self.unused(ch, BL, out); select(self, BL); }
                0x62 => { for x in [NL, RM, RL] { self.unused(ch, x, out); } select(self, NL); }
                0x63 => { for x in [NM, RM, RL] { self.unused(ch, x, out); } select(self, NM); }
                0x64 => { for x in [RL, NM, NL] { self.unused(ch, x, out); } select(self, RL); }
                0x65 => { for x in [RM, NM, NL] { self.unused(ch, x, out); } select(self, RM); }
                0x06 | 0x26 | 0x60 | 0x61 => {
                    let c = &mut self.channels[ch];
                    let at = |slot: Option<(usize, u8, bool)>, events: &Vec<(usize, usize, i64)>| events[slot.unwrap().0];
                    if c[RM].is_some() && c[RL].is_some() { c[RM].as_mut().unwrap().2 = true; c[RL].as_mut().unwrap().2 = true; }
                    if c[RM].is_some() && c[RL].is_none() && !c[RM].unwrap().2 { warn(out, at(c[RM], &self.events), "No matching RPN LSB"); c[RM].as_mut().unwrap().2 = true; }
                    if c[RM].is_none() && c[RL].is_some() && !c[RL].unwrap().2 { warn(out, at(c[RL], &self.events), "No matching RPN MSB"); c[RL].as_mut().unwrap().2 = true; }
                    if c[NM].is_some() && c[NL].is_some() { c[NM].as_mut().unwrap().2 = true; c[NL].as_mut().unwrap().2 = true; }
                    if c[NM].is_some() && c[NL].is_none() && !c[NM].unwrap().2 { warn(out, at(c[NM], &self.events), "No matching NRPN LSB"); c[NM].as_mut().unwrap().2 = true; }
                    if c[NM].is_none() && c[NL].is_some() && !c[NL].unwrap().2 { warn(out, at(c[NL], &self.events), "No matching NRPN MSB"); c[NL].as_mut().unwrap().2 = true; }
                    if c[RM].is_none() && c[RL].is_none() && c[NM].is_none() && c[NL].is_none() { warn(out, here, "RPN/NRPN not set"); }
                    if let (Some(rm), Some(rl)) = (c[RM], c[RL]) { if rm.1 == 0x7F && rl.1 == 0x7F { warn(out, here, "RPN/NRPN not set"); } }
                }
                _ => {}
            }
            return;
        }
        if st == 0xC {
            let c = &mut self.channels[ch];
            if let Some(bm) = c[BM].as_mut() { bm.2 = true; }
            if let Some(bl) = c[BL].as_mut() { bl.2 = true; }
            if c[BL].is_some() && c[BM].is_none() { warn(out, self.events[c[BL].unwrap().0], "No matching Bank Select MSB"); }
            if c[BM].is_some() && c[BL].is_none() { warn(out, self.events[c[BM].unwrap().0], "No matching Bank Select LSB"); }
        }
    }
}
// A GM, GS or XG reset (JZZ's isGmReset, isGsReset, isXgReset: its pattern's bytes, some masked, from the first).
fn is_reset(b: &[u8]) -> bool {
    let matches = |pattern: &[(u8, u8)]| pattern.iter().enumerate().all(|(i, &(v, mask))| b.get(i).map_or(false, |&x| x & mask == v & mask));
    matches(&[(0xF0, 0xFF), (0x7E, 0xFF), (0, 0), (0x09, 0xFF), (0, 0), (0xF7, 0xFF)])
        || matches(&[(0xF0, 0xFF), (0x41, 0xFF), (0, 0), (0x42, 0xFF), (0x12, 0xFF), (0x40, 0xFF), (0, 0xFF), (0x7F, 0xFF), (0, 0xFF), (0x41, 0xFF), (0xF7, 0xFF)])
        || matches(&[(0xF0, 0xFF), (0x43, 0xFF), (0x10, 0xF0), (0x4C, 0xFF), (0, 0xFF), (0, 0xFF), (0x7E, 0xFF), (0, 0xFF), (0xF7, 0xFF)])
}

/// A sequence imported (importMidi1File's motif before its identity): its events as MIDI 2.0 at their ticks, its end, and
/// every meta event as metadata {time, track, type, data}.
pub struct Sequence { pub events: Vec<(f64, Vec<u32>)>, pub end: f64, pub meta: Vec<(f64, usize, u8, Vec<u8>)>, pub notes: Vec<String> }

/// The file's sequences as the importer made them: one, its tracks merged in time order, or one for each track of a
/// type 2; at `ticks_per_quarter` (the file's own, or the caller's for an SMPTE-timed file).
pub fn import(smf: &Smf, ticks_per_quarter: f64) -> Result<Vec<Sequence>, JsError> {
    let groups: Vec<Vec<usize>> = if smf.format == 2 { (0..smf.tracks.len()).map(|k| vec![k]).collect() } else { vec![(0..smf.tracks.len()).collect()] };
    let mut out = Vec::with_capacity(groups.len());
    for group in groups {
        let mut convert = Converter::new(0);
        let mut events: Vec<(f64, Vec<u32>)> = Vec::new();
        let mut meta = Vec::new();
        let mut notes = Vec::new();
        // Every message of the group's tracks by tick, then track, then its place in its track.
        let mut source: Vec<(usize, usize, &Event)> = group.iter().enumerate()
            .flat_map(|(gi, &k)| smf.tracks[k].iter().enumerate().map(move |(i, e)| (gi, i, e))).collect();
        source.sort_by_key(|&(gi, i, e)| (e.tick, gi, i));
        let (mut previous, mut musical, mut micros, mut end) = (0u64, 0f64, 500000f64, 0f64);
        let mut pending: std::collections::HashMap<usize, Vec<u8>> = std::collections::HashMap::new();
        for (gi, _, e) in source {
            let mut time = e.tick as f64;
            if smf.ppqn.is_none() {
                let fps = if smf.fps == 29 { 30000.0 / 1001.0 } else { smf.fps as f64 };
                musical += (e.tick - previous) as f64 / (fps * smf.ppf as f64) * 1e6 / micros * ticks_per_quarter;
                previous = e.tick;
                time = musical.round();
            }
            end = if time > end { time } else { end };
            match &e.message {
                Message::Meta(kind, data) => {
                    meta.push((time, gi, *kind, data.clone()));
                    if *kind == 0x51 && data.len() >= 3 {
                        let tempo = (data[0] as u32) << 16 | (data[1] as u32) << 8 | data[2] as u32;
                        if tempo > 0 || smf.ppqn.is_some() { micros = tempo as f64; }
                        events.push((time, vec![0xD010_0000, tempo * 100, 0, 0]));
                    } else if *kind == 0x58 && data.len() >= 2 {
                        match time_signature(data[0], data[1]) {
                            Some(packet) => events.push((time, packet.to_vec())),
                            None => notes.push(format!("a time signature {}/2^{} at tick {} kept as metadata alone: Flex Data cannot carry it", data[0], data[1], e.tick)),
                        }
                    }
                }
                Message::Sysex(bytes) => {
                    if bytes[0] == 0xF0 { pending.insert(gi, vec![0xF0]); }
                    match pending.get_mut(&gi) {
                        Some(gathered) => {
                            gathered.extend_from_slice(&bytes[1..]);
                            if gathered.last() != Some(&0xF7) { continue; }
                            let whole = pending.remove(&gi).unwrap();
                            events.extend(convert.convert(&whole, time)?);
                        }
                        // An F7 escape continuing nothing: the bytes it carries, sent as they are -- a System Exclusive
                        // begun by them gathered as one is.
                        None => {
                            let carried = &bytes[1..];
                            if carried.first() == Some(&0xF0) {
                                if carried.last() == Some(&0xF7) { events.extend(convert.convert(carried, time)?); } else { pending.insert(gi, carried.to_vec()); }
                            } else if carried.first().map_or(false, |&b| b >= 0x80 && b != 0xF7) && carried.len() == 1 + msg_len(carried[0]) {
                                events.extend(convert.convert(carried, time)?);
                            }
                            // (What makes no whole message -- data bytes, a message cut short -- is skipped, as JZZ's packer
                            // skipped what it could not send.)
                        }
                    }
                }
                Message::Midi(bytes) => events.extend(convert.convert(bytes, time)?),
            }
        }
        if !pending.is_empty() { return Err(JsError::error("MIDI file ends inside a SysEx message")); }
        events.extend(convert.flush());
        // (Stable: those at one time keep their order.)
        events.sort_by(|a, b| a.0.partial_cmp(&b.0).unwrap_or(std::cmp::Ordering::Equal));
        out.push(Sequence { events, end, meta, notes });
    }
    Ok(out)
}

// A time signature as Flex Data (JZZ's umpTimeSignature: its numerator, its denominator's power of 2, and its 32nds a
// bar, nn x 32 / 2^dd), or None where Flex Data cannot carry it: a numerator of 0, more than 255 32nds a bar, or a
// power over 30.
fn time_signature(numerator: u8, power: u8) -> Option<[u32; 4]> {
    if numerator == 0 || power > 30 { return None; }
    let thirty_seconds = (numerator as f64 * 32.0 / (1u64 << power) as f64).round();
    if thirty_seconds >= 256.0 { return None; }
    Some([0xD010_0001, (numerator as u32) << 24 | (power as u32) << 16 | (thirty_seconds as u32) << 8, 0, 0])
}

#[cfg(test)]
mod tests {
    use super::*;
    fn file(format: u16, division: u16, tracks: &[&[u8]]) -> Vec<u8> {
        let mut b = b"MThd\0\0\0\x06".to_vec();
        b.extend_from_slice(&format.to_be_bytes()); b.extend_from_slice(&(tracks.len() as u16).to_be_bytes()); b.extend_from_slice(&division.to_be_bytes());
        for t in tracks { b.extend_from_slice(b"MTrk"); b.extend_from_slice(&(t.len() as u32).to_be_bytes()); b.extend_from_slice(t); }
        b
    }
    #[test]
    fn a_type_0_file_reads_with_running_status() {
        let track: &[u8] = &[0, 0x90, 60, 100, 0x60, 60, 0, 0, 0xFF, 0x2F, 0];
        let smf = parse(&file(0, 96, &[track])).unwrap();
        assert_eq!(smf.tracks[0].len(), 3);
        assert_eq!(smf.tracks[0][1].tick, 96);
        assert_eq!(smf.tracks[0][1].message, Message::Midi(vec![0x90, 60, 0]));
        assert!(smf.warnings().is_empty(), "{:?}", smf.warnings());
        let seqs = import(&smf, 96.0).unwrap();
        assert_eq!(seqs[0].events.len(), 2);
        assert_eq!(seqs[0].end, 96.0);
    }
    #[test]
    fn a_cut_track_is_refused() {
        let track: &[u8] = &[0, 0x90, 60];
        assert!(parse(&file(0, 96, &[track])).unwrap_err().message.contains("Incomplete"));
    }
    #[test]
    fn an_unused_bank_select_is_said() {
        let track: &[u8] = &[0, 0xB0, 0, 1, 0, 0x90, 60, 100, 0, 0xFF, 0x2F, 0];
        assert_eq!(parse(&file(0, 96, &[track])).unwrap().warnings(), ["Unnecessary Bank Select"]);
    }
    #[test]
    fn time_signatures_flex_can_carry() {
        assert_eq!(time_signature(7, 3), Some([0xD0100001, 0x07031C00, 0, 0]));
        assert_eq!(time_signature(0, 2), None);
        assert_eq!(time_signature(255, 0), None);
        assert_eq!(time_signature(3, 31), None);
    }
}
