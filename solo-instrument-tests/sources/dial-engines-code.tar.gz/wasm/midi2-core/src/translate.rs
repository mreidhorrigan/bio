//! MIDI 1.0 into MIDI 2.0: a MIDI 1.0 message's bytes packed into UMP as they stand (what JZZ.M1M2 did for
//! public/shared/midi-files.js and estimation/midi-observer.js), one MIDI 1.0 Channel Voice packet upgraded on its own
//! (the C99 bridge's ump_from_midi1, wasm/midi2/bridge.c, with its corrections), and the stateful translation of a MIDI
//! 1.0 stream (midi-files.js midi1StreamConverter): bank selects held for the Program Change, RPN and NRPN data entry
//! gathered into one Registered or Assignable Controller (UMP v1.1.2 Appendix D.3.3-D.3.4). Ported 13 November 2026.

use crate::json::{self, Json};
use crate::ump;
use crate::JsError;

/// A MIDI 1.0 message's bytes as UMP, unchanged in protocol (JZZ.M1M2): a Channel Voice message as one MIDI 1.0 Channel
/// Voice packet (MT 0x2), a System Common or Real Time one as MT 0x1, a whole System Exclusive message as 7-bit Data
/// packets (MT 0x3) of six bytes each, its F0 and F7 dropped (D.3.7); anything else (a SysEx unfinished, a lone F7, a
/// data byte) as nothing.
pub fn pack(bytes: &[u8], group: u32) -> Vec<Vec<u32>> {
    let g = group & 15;
    let byte = |i: usize| bytes.get(i).copied().unwrap_or(0) as u32;
    let word = |mt: u32| (mt << 28 | g << 24 | byte(0) << 16 | byte(1) << 8 | byte(2)) as u32;
    match bytes.first().copied() {
        Some(0x80..=0xEF) => vec![vec![word(2)]],
        Some(0xF1..=0xFF) if bytes[0] != 0xF7 => vec![vec![word(1)]],
        Some(0xF0) if bytes.len() >= 2 && bytes[bytes.len() - 1] == 0xF7 => {
            let data = &bytes[1..bytes.len() - 1];
            let chunks: Vec<&[u8]> = if data.is_empty() { vec![&[][..]] } else { data.chunks(6).collect() };
            let n = chunks.len();
            chunks.iter().enumerate().map(|(i, chunk)| {
                let status = if n == 1 { 0 } else if i == 0 { 1 } else if i == n - 1 { 3 } else { 2 };
                let mut b = [0u8; 8];
                b[0] = 0x30 | g as u8; b[1] = (status << 4 | chunk.len()) as u8; b[2..2 + chunk.len()].copy_from_slice(chunk);
                vec![u32::from_be_bytes([b[0], b[1], b[2], b[3]]), u32::from_be_bytes([b[4], b[5], b[6], b[7]])]
            }).collect()
        }
        _ => Vec::new(),
    }
}

/// One MIDI 1.0 Channel Voice packet (MT 0x2) as a MIDI 2.0 one (MT 0x4), on its own (D.3): a Note On of velocity 0 a
/// Note Off of velocity 0x8000 (D.3.1, as UMP v1.1.2 has it), velocities, pressures, controllers and bends scaled up by
/// Min-Center-Max (D.1.3), a Program Change with no bank. None for any other packet.
pub fn upgrade(word: u32) -> Option<[u32; 2]> {
    if ump::mt(word) != 2 { return None; }
    let (group, status, channel, a, b) = ((word >> 24) & 15, (word >> 16) & 0xF0, (word >> 16) & 15, (word >> 8) & 127, word & 127);
    Some(match status {
        0x90 if b == 0 => ump::note_off(group, channel, a, 0x8000),
        0x90 => ump::note_on(group, channel, a, ump::scale_up(b, 7, 16)),
        0x80 => ump::note_off(group, channel, a, if b == 0 { 0 } else { ump::scale_up(b, 7, 16) }),
        0xA0 => ump::poly_pressure(group, channel, a, ump::scale_up(b, 7, 32)),
        0xB0 => ump::control(group, channel, a, ump::scale_up(b, 7, 32)),
        0xC0 => ump::program(group, channel, a, None),
        0xD0 => ump::channel_pressure(group, channel, ump::scale_up(a, 7, 32)),
        0xE0 => ump::channel_bend(group, channel, ump::scale_up(b << 7 | a, 14, 32)),
        _ => return None,
    })
}

#[derive(Clone, Copy, Debug, PartialEq)]
enum Parameter { Rpn, Nrpn }
/// One channel's selections, as midi1StreamConverter keeps them and its checkpoint writes them.
#[derive(Clone, Debug, PartialEq)]
struct Channel { bank: [u32; 2], bank_set: bool, rpn: [u32; 2], nrpn: [u32; 2], kind: Option<Parameter>, msb: Option<u32>, pending: Option<f64> }
impl Default for Channel {
    fn default() -> Channel { Channel { bank: [0, 0], bank_set: false, rpn: [127, 127], nrpn: [127, 127], kind: None, msb: None, pending: None } }
}

/// A MIDI 1.0 stream's translator: sixteen channels' bank, RPN and NRPN selections. Every packet it makes is on `group`.
#[derive(Clone, Debug, PartialEq)]
pub struct Converter { channels: Vec<Channel>, pub group: u32 }
pub type Timed = (f64, Vec<u32>);

impl Converter {
    pub fn new(group: u32) -> Converter { Converter { channels: vec![Channel::default(); 16], group: group & 15 } }
    /// True where nothing has been selected yet (a translator a checkpoint need not mention).
    pub fn is_fresh(&self) -> bool { self.channels.iter().all(|c| *c == Channel::default()) }

    // A gathered RPN or NRPN (D.3.3): its 14 bits of data scaled up to 32; nothing while its number is unknown, its data
    // not begun, or it is the null function (127, 127).
    fn parameter(&self, channel: usize, time: f64, lsb: u32) -> Vec<Timed> {
        let state = &self.channels[channel];
        let (Some(kind), Some(msb)) = (state.kind, state.msb) else { return Vec::new() };
        let selected = if kind == Parameter::Rpn { state.rpn } else { state.nrpn };
        if selected == [127, 127] { return Vec::new(); }
        let value = ump::scale_up(msb << 7 | lsb, 14, 32);
        vec![(time, ump::controller(self.group, channel as u32, kind == Parameter::Rpn, selected[0], selected[1], value).to_vec())]
    }
    // Data entry begun (CC 6) and not yet ended by its LSB (CC 38) goes out, at the time it began, when anything else
    // arrives on its channel.
    fn flush_channel(&mut self, channel: usize) -> Vec<Timed> {
        let Some(time) = self.channels[channel].pending.take() else { return Vec::new() };
        self.parameter(channel, time, 0)
    }
    /// Everything still pending, every channel's (midi1StreamConverter's convert.flush).
    pub fn flush(&mut self) -> Vec<Timed> { (0..16).flat_map(|c| self.flush_channel(c)).collect() }
    /// Data entry begun before `time` and not yet ended, sent now that time has moved on: the short timeout after a CC 6
    /// the specification allows a translator, "as some MIDI 1.0 Devices do not transmit CC 38" (D.3.3). The note
    /// tracer's (notes.rs), for a clip's MIDI 1.0 packets: an MPE Configuration Message is sent on its zone's Manager
    /// Channel and nothing more may come there, while its notes come on the Member Channels.
    pub fn flush_before(&mut self, time: f64) -> Vec<Timed> {
        let due: Vec<usize> = (0..16).filter(|&c| self.channels[c].pending.map_or(false, |at| at < time)).collect();
        due.into_iter().flat_map(|c| self.flush_channel(c)).collect()
    }

    /// A MIDI 1.0 message's bytes at `time` -> the MIDI 2.0 packets it makes now (midi1StreamConverter's convert).
    pub fn convert(&mut self, bytes: &[u8], time: f64) -> Result<Vec<Timed>, JsError> {
        let status_byte = bytes.first().copied().unwrap_or(0) as u32;
        if !(0x80..0xF0).contains(&status_byte) {
            return Ok(pack(bytes, self.group).into_iter().map(|packet| (time, packet)).collect());
        }
        let (channel, status) = ((status_byte & 15) as usize, status_byte >> 4);
        let (number, value) = (bytes.get(1).copied().unwrap_or(0) as u32, bytes.get(2).copied().unwrap_or(0) as u32);
        if status == 11 {
            match number {
                0 | 32 => { let s = &mut self.channels[channel]; s.bank[(number == 32) as usize] = value; s.bank_set = true; return Ok(self.flush_channel(channel)); }
                98..=101 => {
                    let before = self.flush_channel(channel);
                    let s = &mut self.channels[channel];
                    let kind = if number >= 100 { Parameter::Rpn } else { Parameter::Nrpn };
                    s.kind = Some(kind);
                    let slot = if number == 101 || number == 99 { 0 } else { 1 };
                    if kind == Parameter::Rpn { s.rpn[slot] = value } else { s.nrpn[slot] = value }
                    return Ok(before);
                }
                6 => { let before = self.flush_channel(channel); let s = &mut self.channels[channel]; s.msb = Some(value); s.pending = Some(time); return Ok(before); }
                38 => { self.channels[channel].pending = None; return Ok(self.parameter(channel, time, value)); }
                // CC 96 and 97 stay Control Changes: never MIDI 2.0's relative controllers (D.3.3).
                _ => {}
            }
        }
        let mut out = self.flush_channel(channel);
        if status == 12 && self.channels[channel].bank_set {
            out.push((time, ump::program(self.group, channel as u32, number, Some(self.channels[channel].bank)).to_vec()));
            return Ok(out);
        }
        let raw = 0x2000_0000 | self.group << 24 | status_byte << 16 | number << 8 | value;
        let packet = upgrade(raw).ok_or_else(|| JsError::error("Unsupported MIDI 1 channel voice message"))?;
        out.push((time, packet.to_vec()));
        Ok(out)
    }

    /// The selections as midi1StreamConverter's channelCheckpoint writes them (before frozenJson freezes them).
    pub fn checkpoint(&self) -> Json {
        let pair = |p: [u32; 2]| Json::Array(vec![json::num(p[0] as f64), json::num(p[1] as f64)]);
        json::obj(vec![("version", json::num(1.0)), ("kind", json::text("midi1-channel-conversion")),
            ("channels", Json::Array(self.channels.iter().map(|c| json::obj(vec![
                ("bank", pair(c.bank)), ("bankSet", Json::Bool(c.bank_set)), ("rpn", pair(c.rpn)), ("nrpn", pair(c.nrpn)),
                ("kind", match c.kind { None => Json::Null, Some(Parameter::Rpn) => json::text("rpn"), Some(Parameter::Nrpn) => json::text("nrpn") }),
                ("msb", c.msb.map(|m| json::num(m as f64)).unwrap_or(Json::Null)), ("pendingTime", json::opt(c.pending)),
            ])).collect()))])
    }
    /// The selections a checkpoint holds, every channel checked before any is taken (restoreChannelCheckpoint: its
    /// refusals in its words).
    pub fn restore(&mut self, value: &Json) -> Result<(), JsError> {
        known(value, &["version", "kind", "channels"], "MIDI 1 channel checkpoint")?;
        let channels = value.get("channels").and_then(Json::items);
        if value.num("version") != Some(1.0) || value.get("kind").and_then(Json::text) != Some("midi1-channel-conversion") || channels.map_or(true, |c| c.len() != 16) {
            return Err(JsError::type_error("Invalid MIDI 1 channel checkpoint"));
        }
        let byte = |v: &Json| v.number().map_or(false, |x| x.fract() == 0.0 && (0.0..=127.0).contains(&x));
        let pair = |v: Option<&Json>| -> Option<[u32; 2]> {
            let items = v?.items()?;
            (items.len() == 2 && items.iter().all(byte)).then(|| [items[0].number().unwrap() as u32, items[1].number().unwrap() as u32])
        };
        let mut restored = Vec::with_capacity(16);
        for state in channels.unwrap() {
            known(state, &["bank", "bankSet", "rpn", "nrpn", "kind", "msb", "pendingTime"], "MIDI 1 channel state")?;
            let invalid = || JsError::type_error("Invalid MIDI 1 channel state");
            let (bank, rpn, nrpn) = (pair(state.get("bank")), pair(state.get("rpn")), pair(state.get("nrpn")));
            let bank_set = state.get("bankSet").and_then(Json::boolean);
            let kind = match state.get("kind") { Some(Json::Null) => Some(None), Some(Json::Str(s)) if s == "rpn" => Some(Some(Parameter::Rpn)),
                Some(Json::Str(s)) if s == "nrpn" => Some(Some(Parameter::Nrpn)), _ => None };
            let msb = match state.get("msb") { Some(Json::Null) => Some(None), Some(v) if byte(v) => Some(Some(v.number().unwrap() as u32)), _ => None };
            let pending = match state.get("pendingTime") { Some(Json::Null) => Some(None), Some(Json::Number(x)) if x.is_finite() => Some(Some(*x)), _ => None };
            let (Some(bank), Some(rpn), Some(nrpn), Some(bank_set), Some(kind), Some(msb), Some(pending)) = (bank, rpn, nrpn, bank_set, kind, msb, pending) else { return Err(invalid()) };
            if pending.is_some() && msb.is_none() { return Err(invalid()); }
            restored.push(Channel { bank, bank_set, rpn, nrpn, kind, msb, pending });
        }
        self.channels = restored;
        Ok(())
    }
}

/// planning-data.js knownFields: a record with no key outside `fields`, else its error in its words.
pub fn known(value: &Json, fields: &[&str], label: &str) -> Result<(), JsError> {
    match value.entries() {
        Some(entries) if entries.iter().all(|(k, _)| fields.contains(&k.as_str())) => Ok(()),
        _ => Err(JsError::error(format!("Unknown required {} semantics", label))),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn notes_upgrade_as_ump_1_1_2_says() {
        assert_eq!(upgrade(0x21953c00), Some([0x41853c00, 0x80000000]));
        assert_eq!(upgrade(0x20903c01), Some([0x40903c00, 0x02000000]));
        assert_eq!(upgrade(0x20903c7f), Some([0x40903c00, 0xffff0000]));
        assert_eq!(upgrade(0x20803c00), Some([0x40803c00, 0]));
        assert_eq!(upgrade(0x20e00040), Some([0x40e00000, 0x80000000]));
        assert_eq!(upgrade(0x20f80000), None);
    }
    #[test]
    fn data_entry_gathers_into_one_controller() {
        let mut c = Converter::new(0);
        for (n, v) in [(101u8, 0u8), (100, 0), (6, 12)] { assert!(c.convert(&[0xb0, n, v], 0.0).unwrap().is_empty()); }
        let out = c.convert(&[0xb0, 38, 50], 1.0).unwrap();
        assert_eq!(out, vec![(1.0, vec![0x40200000, ump::scale_up(12 << 7 | 50, 14, 32)])]);
        // CC 6 alone goes out with the next message on its channel, at its own time.
        c.convert(&[0xb0, 6, 2], 2.0).unwrap();
        let out = c.convert(&[0x90, 60, 100], 3.0).unwrap();
        assert_eq!(out[0], (2.0, vec![0x40200000, 2 << 25]));
        assert_eq!(out[1].1[0], 0x40903c00);
    }
    #[test]
    fn sysex_packs_six_bytes_a_packet() {
        assert_eq!(pack(&[0xf0, 0xf7], 0), vec![vec![0x30000000, 0]]);
        let p = pack(&[0xf0, 1, 2, 3, 4, 5, 6, 7, 0xf7], 2);
        assert_eq!(p, vec![vec![0x32160102, 0x03040506], vec![0x32310700, 0]]);
        assert_eq!(pack(&[0xf8], 0), vec![vec![0x10f80000]]);
        assert!(pack(&[0xf7], 0).is_empty());
    }
}
