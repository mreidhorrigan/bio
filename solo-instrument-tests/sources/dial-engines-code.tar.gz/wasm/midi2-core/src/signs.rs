//! A piece's signs in a clip's Flex Data (M2-104-UM v1.1.2 §7.5; research-downloads/midi2/ump.txt, its Appendix F's
//! layouts): written from what the score says -- each time signature where the meter changes, the key, the piece's and
//! the clip's names -- and read from any clip -- its tempi, time signatures, key signatures, chord names, metadata texts
//! and lyrics -- as the scores and their MIDI 2.0 meet (the owner, 14 November 2026, of the MIDI 2.0 and score cores'
//! integration: "Meter and key in clips"; "Lyrics as MIDI 2.0"; "we are using Rust to the extent possible"). A clip from
//! other software had kept these packets as they came and read none of them but its tempo.
//!
//!   packets(&Writing) -> the header's texts and the sequence's signs, each at its tick, to merge with a clip's
//!   read(header, events) -> what a clip's Flex Data says, as JSON (midi-files.js importMidi2Clip: metadata.flexData)

use crate::flex;
use crate::json::{self, Json};
use crate::ump;
use crate::JsError;

const SETUP: u32 = 0x00;
const TEMPO: u32 = 0x00;
const TIME_SIGNATURE: u32 = 0x01;
const KEY_SIGNATURE: u32 = 0x05;
const CHORD_NAME: u32 = 0x06;
const METADATA_TEXT: u32 = 0x01;
const PERFORMANCE_TEXT: u32 = 0x02;
/// A Flex Data message's first word, its Format the writer's: to the Group (Address 1) or a Channel (Address 0).
fn head(group: u32, channel: Option<u32>, bank: u32, status: u32) -> u32 {
    0xD000_0000 | (group & 0xF) << 24 | match channel { None => 1 << 20, Some(c) => (c & 0xF) << 16 } | bank << 8 | status
}

/// The Status Bank 1 texts (§7.5.9.1, Table 16), by the name the score knows them by.
const METADATA: [(u32, &str); 13] = [(0x00, "unknown"), (0x01, "project name"), (0x02, "composition name"), (0x03, "clip name"), (0x04, "copyright"),
    (0x05, "composer"), (0x06, "lyricist"), (0x07, "arranger"), (0x08, "publisher"), (0x09, "primary performer"), (0x0A, "accompanying performer"),
    (0x0B, "recording date"), (0x0C, "recording location")];
/// The Status Bank 2 texts.
const PERFORMANCE: [(u32, &str); 5] = [(0x00, "unknown"), (0x01, "lyrics"), (0x02, "lyrics language"), (0x03, "ruby"), (0x04, "ruby language")];
/// The chord types (§7.5.8, Table 14).
const CHORD_TYPES: [&str; 28] = ["no chord", "major", "major 6th", "major 7th", "major 9th", "major 11th", "major 13th", "minor", "minor 6th",
    "minor 7th", "minor 9th", "minor 11th", "minor 13th", "dominant", "dominant 9th", "dominant 11th", "dominant 13th", "augmented",
    "augmented 7th", "diminished", "diminished 7th", "half diminished", "minor-major", "pedal", "power", "suspended 2nd", "suspended 4th",
    "7 suspended 4th"];
const ALTERATIONS: [&str; 5] = ["none", "add", "subtract", "raise", "lower"];
/// The letters a Tonic Note field names (0 unknown).
const LETTERS: [&str; 8] = ["", "A", "B", "C", "D", "E", "F", "G"];
/// Each key's major tonic's letter by its fifths, -7 to 7 ("CGDAEBF" round the circle; its relative minor three fifths on).
const CIRCLE: &[u8] = b"CGDAEBFCGDAEBFCGDA";

/// A signed 4-bit field (§7.5.7: -8 unknown).
fn signed4(x: u32) -> i32 { let v = (x & 0xF) as i32; if v >= 8 { v - 16 } else { v } }

// ---- written ------------------------------------------------------------------------------------------------------------

/// What a clip writer says of its piece: its time signatures (each bar's, written where the meter changes), its keys, and
/// its texts (Status Bank 1 by name: "composition name", "clip name", ...), on one Group.
pub struct Writing { pub group: u32, pub meters: Vec<(u64, u32, u32)>, pub keys: Vec<(u64, i32, bool)>, pub texts: Vec<(String, String)> }

/// A Set Time Signature (§7.5.4): to the Group, its denominator a power of two by its power (else 0, non-standard: a 3/10
/// bar's), its 1/32 notes the eight in 24 MIDI Clocks, a quarter, as the specification counts them; None where the
/// numerator is past the field's (1 to 255).
pub fn time_signature(group: u32, numerator: u32, denominator: u32) -> Option<[u32; 4]> {
    if numerator == 0 || numerator > 255 || denominator == 0 { return None; }
    let power = if denominator.is_power_of_two() { denominator.trailing_zeros() } else { 0 };
    Some([head(group, None, SETUP, TIME_SIGNATURE), numerator << 24 | power << 16 | 8 << 8, 0, 0])
}
/// A Set Key Signature (§7.5.7): its sharps (flats negative) and its tonic's letter, a major key's or its relative minor's
/// (the field names the letter; the sharps and flats its accidental); None past seven either way.
pub fn key_signature(group: u32, fifths: i32, minor: bool) -> Option<[u32; 4]> {
    if !(-7..=7).contains(&fifths) { return None; }
    let letter = CIRCLE[(fifths + 7 + if minor { 3 } else { 0 }) as usize];
    let tonic = LETTERS.iter().position(|l| l.as_bytes() == [letter]).unwrap_or(0) as u32;
    Some([head(group, None, SETUP, KEY_SIGNATURE), ((fifths as u32) & 0xF) << 28 | tonic << 24, 0, 0])
}

/// Its packets: the header's texts at its start, and each time signature where the meter changes and each key, at their
/// ticks, in time order. -> (header, events)
pub fn packets(w: &Writing) -> Result<(Vec<(u64, Vec<u32>)>, Vec<(u64, Vec<u32>)>), JsError> {
    let mut header = Vec::new();
    for (kind, text) in &w.texts {
        let status = METADATA.iter().find(|(_, name)| name == kind).map(|(s, _)| *s)
            .ok_or_else(|| JsError::range(format!("No metadata text is named \"{}\" (Flex Data Status Bank 1)", kind)))?;
        for packet in flex::packets(head(w.group, None, METADATA_TEXT, status), text.as_bytes())? { header.push((0, packet.to_vec())); }
    }
    let mut events: Vec<(u64, Vec<u32>)> = Vec::new();
    let mut last: Option<(u32, u32)> = None;
    let mut meters = w.meters.clone();
    meters.sort_by_key(|m| m.0);
    for (tick, numerator, denominator) in meters {
        if last == Some((numerator, denominator)) { continue; }
        if let Some(p) = time_signature(w.group, numerator, denominator) { events.push((tick, p.to_vec())); last = Some((numerator, denominator)); }
    }
    for &(tick, fifths, minor) in &w.keys { if let Some(p) = key_signature(w.group, fifths, minor) { events.push((tick, p.to_vec())); } }
    events.sort_by_key(|e| e.0);
    Ok((header, events))
}

/// A sung note's syllable as MIDI 2.0 sends it with the note (§7.5.10-7.5.11), to a Channel: its Lyric Language (BCP 47)
/// first where `language` is given -- the singer's, where it changes -- then the syllable, a space after it where it ends
/// its word; a note it is held over (a melisma: `melisma`, or no text) a Complete packet of 0x00. The score's lyric
/// (notation/lyrics.js: its text, its word's syllables) says which; a melisma's word end stays on its syllable, as the
/// singer reports one note at a time.
pub fn lyric(group: u32, channel: u32, text: &str, ends_word: bool, melisma: bool, language: Option<&str>) -> Result<Vec<[u32; 4]>, JsError> {
    let mut out = Vec::new();
    if let Some(language) = language.filter(|l| !l.is_empty()) { out.extend(flex::packets(head(group, Some(channel), PERFORMANCE_TEXT, 0x02), language.as_bytes())?); }
    let sung = text.trim();
    if melisma || sung.is_empty() { out.extend(flex::packets(head(group, Some(channel), PERFORMANCE_TEXT, 0x01), b"")?); return Ok(out); }
    let syllable = if ends_word { format!("{} ", sung) } else { sung.to_string() };
    out.extend(flex::packets(head(group, Some(channel), PERFORMANCE_TEXT, 0x01), syllable.as_bytes())?);
    Ok(out)
}

// ---- read ---------------------------------------------------------------------------------------------------------------

fn pitch(sharps: i32, letter: u32) -> Json {
    match LETTERS.get(letter as usize).filter(|l| !l.is_empty()) {
        None => Json::Null,
        Some(l) => json::text(&format!("{}{}", l, match sharps { 2 => "𝄪", 1 => "♯", -1 => "♭", -2 => "𝄫", _ => "" })),
    }
}
fn alterations(byte_pairs: &[u32]) -> Json {
    Json::Array(byte_pairs.iter().filter(|&&b| b >> 4 != 0).map(|&b| json::obj(vec![
        ("alter", json::text(ALTERATIONS.get((b >> 4) as usize).copied().unwrap_or("reserved"))), ("degree", json::num((b & 0xF) as f64))])).collect())
}
fn type_name(t: u32) -> Json { json::text(CHORD_TYPES.get(t as usize).copied().unwrap_or("reserved")) }

/// What a clip's Flex Data says, its header's and its sequence's, each where it is -- {tempi, timeSignatures,
/// keySignatures, chords, texts, lyrics}, each item its tick (`time`), `header` where the header holds it, its Group, and
/// its Channel where it is sent to one: a tempo's quarter in seconds; a time signature's numerator and denominator (null:
/// non-standard) and its 1/32 notes; a key's fifths (null: unknown or non-standard), its tonic's letter and its mode,
/// major or minor, where the letter is one of the two; a chord's tonic and bass (null: none), type and alterations; a text's
/// kind and its words, each message's packets put together (a lyric's Language and Ruby among the texts, kinds of their
/// own). A message it cannot read as the specification writes it is passed over, and said so in `unread`.
pub fn read(header: &[(u64, Vec<u32>)], events: &[(u64, Vec<u32>)]) -> Json {
    let (mut tempi, mut meters, mut keys, mut chords, mut texts, mut lyrics, mut unread) = (vec![], vec![], vec![], vec![], vec![], vec![], vec![]);
    let mut assembler = flex::Assembler::new(65536.0);
    for (in_header, list) in [(true, header), (false, events)] {
        for (tick, packet) in list {
            let Some(f) = ump::flex(packet[0]) else { continue };
            if packet.len() != 4 { continue; }
            let mut placed = vec![("time", json::num(*tick as f64))];
            if in_header { placed.push(("header", Json::Bool(true))); }
            placed.push(("group", json::num(f.group as f64)));
            if f.address == 0 { placed.push(("channel", json::num(f.channel as f64))); }
            let with = |mut fields: Vec<(&'static str, Json)>| { let mut all = placed.clone(); all.append(&mut fields); json::obj(all) };
            let (w1, w2, w3) = (packet[1], packet[2], packet[3]);
            match (f.bank, f.status) {
                (SETUP, TEMPO) if f.format == 0 => if w1 > 0 { tempi.push(with(vec![("quarterSeconds", json::num(w1 as f64 * 1e-8))])); },
                (SETUP, TIME_SIGNATURE) if f.format == 0 => {
                    let (numerator, power, thirty_seconds) = (w1 >> 24, w1 >> 16 & 0xFF, w1 >> 8 & 0xFF);
                    meters.push(with(vec![("numerator", json::num(numerator as f64)),
                        ("denominator", if power == 0 || power > 31 { Json::Null } else { json::num((1u64 << power) as f64) }), ("thirtySeconds", json::num(thirty_seconds as f64))]));
                }
                (SETUP, KEY_SIGNATURE) if f.format == 0 => {
                    let (fifths, letter) = (signed4(w1 >> 28), w1 >> 24 & 0xF);
                    let known = fifths != -8;
                    let mode = known.then(|| {
                        let at = |minor: bool| CIRCLE[(fifths + 7 + if minor { 3 } else { 0 }) as usize];
                        let l = LETTERS.get(letter as usize).and_then(|l| l.bytes().next());
                        if l == Some(at(false)) { Some("major") } else if l == Some(at(true)) { Some("minor") } else { None }
                    }).flatten();
                    keys.push(with(vec![("fifths", if known { json::num(fifths as f64) } else { Json::Null }),
                        ("tonic", LETTERS.get(letter as usize).filter(|l| !l.is_empty()).map(|l| json::text(l)).unwrap_or(Json::Null)),
                        ("mode", mode.map(json::text).unwrap_or(Json::Null))]));
                }
                (SETUP, CHORD_NAME) if f.format == 0 => {
                    let bass_same = signed4(w3 >> 28) == -8;
                    chords.push(with(vec![("tonic", pitch(signed4(w1 >> 28), w1 >> 24 & 0xF)), ("type", type_name(w1 >> 16 & 0xFF)),
                        ("alterations", alterations(&[w1 >> 8 & 0xFF, w1 & 0xFF, w2 >> 24, w2 >> 16 & 0xFF])),
                        ("bass", if bass_same { Json::Null } else { pitch(signed4(w3 >> 28), w3 >> 24 & 0xF) }),
                        ("bassType", if w3 >> 16 & 0xFF == 0 { Json::Null } else { type_name(w3 >> 16 & 0xFF) }),
                        ("bassAlterations", alterations(&[w3 >> 8 & 0xFF, w3 & 0xFF]))]));
                }
                (METADATA_TEXT | PERFORMANCE_TEXT, status) => {
                    match assembler.push(packet, if in_header { "header" } else { "clip" }) {
                        Ok(None) => {}
                        Ok(Some(text)) => {
                            let names: &[(u32, &str)] = if f.bank == METADATA_TEXT { &METADATA } else { &PERFORMANCE };
                            let kind = names.iter().find(|(s, _)| *s == status).map(|(_, n)| *n).unwrap_or("reserved");
                            if f.bank == PERFORMANCE_TEXT && status == 0x01 { lyrics.push(with(vec![("text", json::text(&text))])); }
                            else { texts.push(with(vec![("kind", json::text(kind)), ("text", json::text(&text))])); }
                        }
                        Err(e) => { unread.push(json::text(&format!("at {}: {}", tick, e.message))); assembler.reset(); }
                    }
                }
                _ => {}
            }
        }
    }
    if assembler.open() > 0 { unread.push(json::text("a text begun and never ended")); }
    json::obj(vec![("tempi", Json::Array(tempi)), ("timeSignatures", Json::Array(meters)), ("keySignatures", Json::Array(keys)), ("chords", Json::Array(chords)),
        ("texts", Json::Array(texts)), ("lyrics", Json::Array(lyrics)), ("unread", Json::Array(unread))])
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn signs_written_as_the_specification_lays_them_out_and_read_back() {
        // (Appendix F, Table 32: a time signature's numerator, denominator's power and 1/32 notes in word 2's high bytes; a key's
        // sharps and flats and tonic in its top byte.)
        assert_eq!(time_signature(0, 7, 8), Some([0xD010_0001, 0x0703_0800, 0, 0]));
        assert_eq!(time_signature(2, 3, 10), Some([0xD210_0001, 0x0300_0800, 0, 0]), "a 3/10 bar's denominator non-standard");
        assert_eq!(time_signature(0, 256, 4), None);
        assert_eq!(key_signature(0, -3, false), Some([0xD010_0005, 0xD500_0000, 0, 0]), "E flat major: three flats, E");
        assert_eq!(key_signature(0, -3, true), Some([0xD010_0005, 0xD300_0000, 0, 0]), "C minor: three flats, C");
        let w = Writing { group: 0, meters: vec![(0, 5, 8), (480, 5, 8), (960, 3, 10)], keys: vec![(0, 2, true)],
            texts: vec![("composition name".into(), "Op. 3.1".into()), ("clip name".into(), "Violas".into())] };
        let (header, events) = packets(&w).unwrap();
        let read = read(&header, &events).write_shortest();
        assert!(read.contains(r#""timeSignatures":[{"time":0,"group":0,"numerator":5,"denominator":8,"thirtySeconds":8},{"time":960,"group":0,"numerator":3,"denominator":null,"thirtySeconds":8}]"#), "{}", read);
        assert!(read.contains(r#""keySignatures":[{"time":0,"group":0,"fifths":2,"tonic":"B","mode":"minor"}]"#), "{}", read);
        assert!(read.contains(r#"{"time":0,"header":true,"group":0,"kind":"composition name","text":"Op. 3.1"}"#), "{}", read);
        // A chord name as another writer sends it: C sharp minor 7th, its 9th added, over E.
        let chord = vec![(0u64, vec![0xD010_0006, 0x1309_1900, 0, 0x0500_0000])];
        let read = super::read(&[], &chord).write_shortest();
        assert!(read.contains(r#""tonic":"C♯","type":"minor 7th","alterations":[{"alter":"add","degree":9}],"bass":"E","bassType":null"#), "{}", read);
    }
    #[test]
    fn a_sung_syllable_with_its_note() {
        // (Group 0 to Channel 2: its language, then "Nacht " ending its word; a held note's melisma, 0x00.)
        let sent = lyric(0, 2, "Nacht", true, false, Some("de")).unwrap();
        assert_eq!(sent, vec![[0xD002_0202, 0x6465_0000, 0, 0], [0xD002_0201, 0x4E61_6368, 0x7420_0000, 0]]);
        assert_eq!(lyric(0, 2, "", false, true, None).unwrap(), vec![[0xD002_0201, 0, 0, 0]]);
        let events: Vec<(u64, Vec<u32>)> = sent.iter().map(|p| (0, p.to_vec())).collect();
        let read = read(&[], &events).write_shortest();
        assert!(read.contains(r#""lyrics":[{"time":0,"group":0,"channel":2,"text":"Nacht "}]"#) && read.contains(r#""kind":"lyrics language","text":"de""#), "{}", read);
    }
}
