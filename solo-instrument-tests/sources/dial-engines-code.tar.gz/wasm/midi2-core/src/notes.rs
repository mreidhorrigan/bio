//! A UMP sequence's notes: public/shared/ump-notes.js's tracker (traceUmpNotes, createUmpNoteTracker), ported 13
//! November 2026. Each note's pitch, velocity, release, the per-note and channel expression that reached it and the
//! controls it was heard with, as the JavaScript computed them, in the same order of operations (every number the same
//! double); a live tracker's snapshot, checkpoint and restore, its refusals in its words.
//!
//! Notes are matched to their releases first in, first out by Group, Channel and Note Number; per-note state persists
//! between notes until Per-Note Management detaches or resets it; the sustain pedal holds released notes; All Sound
//! Off, All Notes Off and Reset All Controllers act as the JavaScript had them act.
//!
//! What it does that the JavaScript did not: MIDI 1.0 Channel Voice packets (MT 0x2), as clips from other software
//! carry them, are translated as a stream (translate.rs Converter, one for each Group) -- the JavaScript upgraded each
//! packet alone, and only where the C99 module had been loaded, so a Bank Select, an RPN's or NRPN's data entry (a
//! channel's bend range among them) reached it as plain Control Changes, and without the module no MIDI 1.0 note at all.
//! And MPE, as other software writes it, reaches the notes' pitch: an MPE Configuration Message (RPN 0/6 on channel 1 or
//! 16) sets up its zone, its Manager Channel's bend sensitivity 2 semitones and its Member Channels' 48, and a bend
//! sensitivity sent to any Member Channel is the whole zone's (MPE v1.0, MMA RP-053, 2018, §2.1.1, §2.4); a MIDI-CI Set
//! Profile On for the MIDI 2.0 MPE Profile (a clip's preamble carries it) sets up its channels at 48, a sensitivity sent
//! to its Manager Channel theirs (M2-120-UM v2.0.3, §3.5). research-downloads/midi2/.

use std::collections::{BTreeMap, HashMap, VecDeque};
use crate::json::{self, Json};
use crate::translate::{self, Converter};
use crate::ump::{self, Kind};
use crate::JsError;

const ARTICULATION: [u32; 5] = [10, 71, 72, 73, 75];
fn bipolar(value: u32) -> f64 { (value as f64 - 2147483648.0) / if value < 0x8000_0000 { 2147483648.0 } else { 2147483647.0 } }
fn bend_semitones(value: f64, range: f64) -> f64 { (value - 2147483648.0) / if value < 2147483648.0 { 2147483648.0 } else { 2147483647.0 } * range }
/// Math.max of two numbers (NaN if either is; +0 above -0).
fn js_max(a: f64, b: f64) -> f64 {
    if a.is_nan() || b.is_nan() { f64::NAN } else if a > b { a } else if b > a { b } else if a == 0.0 && a.is_sign_negative() { b } else { a }
}

type Key = (u32, u32, u32);
fn key_text(k: Key) -> String { format!("{}:{}:{}", k.0, k.1, k.2) }

/// The state a Note Number carries between notes (ump-notes.js `defaults`, slide unset).
#[derive(Clone, Debug, PartialEq)]
pub struct PerNote { bend: f64, pressure: f64, slide: Option<f64>, pitch: Option<f64>, volume: f64, expression: f64, timbre: f64, pan: f64, articulation: BTreeMap<u32, f64> }
impl PerNote {
    fn fresh() -> PerNote { PerNote { bend: 0.0, pressure: 1.0, slide: None, pitch: None, volume: 1.0, expression: 1.0, timbre: 0.5, pan: 0.0, articulation: BTreeMap::new() } }
    fn set(&mut self, field: Field, value: f64) {
        match field { Field::Bend => self.bend = value, Field::Pressure => self.pressure = value, Field::Slide => self.slide = Some(value),
            Field::Pitch => self.pitch = Some(value), Field::Volume => self.volume = value, Field::Expression => self.expression = value,
            Field::Timbre => self.timbre = value, Field::Pan => self.pan = value }
    }
    fn json(&self) -> Json {
        json::obj(vec![("bend", json::num(self.bend)), ("pressure", json::num(self.pressure)), ("slide", json::opt(self.slide)),
            ("pitch", json::opt(self.pitch)), ("volume", json::num(self.volume)), ("expression", json::num(self.expression)),
            ("timbre", json::num(self.timbre)), ("pan", json::num(self.pan)), ("articulation", articulation_json(&self.articulation))])
    }
}
fn articulation_json(a: &BTreeMap<u32, f64>) -> Json { Json::Object(a.iter().map(|(k, v)| (k.to_string(), json::num(*v))).collect()) }
#[derive(Clone, Copy)]
enum Field { Bend, Pressure, Slide, Pitch, Volume, Expression, Timbre, Pan }

#[derive(Clone, Debug)]
struct Channel {
    group: u32, channel: u32, notes: Vec<usize>,
    bend: f64, bend_range: f64, per_note_range: f64, pressure: f64, slide: f64, volume: f64, expression: f64, sustain: bool, fine: f64, coarse: f64,
}

/// A message as received: its time, its packet, and where it came from among those consumed (the caller's event, by
/// the order they were consumed in), so the caller can give a note its own event objects back.
#[derive(Clone, Debug)]
pub struct Stamp { pub time: f64, pub packet: Vec<u32>, pub source: Option<usize> }

/// Expression a note received (retained with history): `semitones` a per-note bend's.
#[derive(Clone, Debug)]
pub struct Expression { pub at: f64, pub time: f64, pub kind: Kind, pub index: u32, pub value: u32, pub semitones: Option<f64>, pub source: Option<usize> }

#[derive(Clone, Debug)]
pub struct Note {
    pub at: f64, pub duration: f64, pub pitch: f64, pub velocity: f64, pub group: u32, pub channel: u32, pub note: u32,
    pub on: Stamp, pub off: Option<Stamp>, pub release_velocity: Option<f64>, pub end_time: Option<f64>,
    pub expression: Vec<Expression>, pub controls: Vec<(f64, u32, f64)>, pub articulation: BTreeMap<u32, f64>,
    channel_index: usize, per_note: PerNote, last: [Option<f64>; 8], detached: bool, held: bool,
}
impl Note { fn key(&self) -> Key { (self.group, self.channel, self.note) } }

/// ump-notes.js createUmpNoteTracker.
pub struct Tracker {
    ticks_per_quarter: f64, bend_range: f64, retain: bool, max_active: usize,
    channels: Vec<Channel>, channel_index: HashMap<(u32, u32), usize>,
    per_notes: Vec<(Key, PerNote)>, per_note_index: HashMap<Key, usize>,
    waiting: HashMap<Key, VecDeque<usize>>,
    notes: Vec<Option<Note>>, free: Vec<usize>, history: Vec<usize>,
    active: usize, finished: bool,
    midi1: Vec<Option<Converter>>,
    mpe: Vec<Mpe>, sysex: Vec<Option<Vec<u8>>>,
}

/// A Group's MPE zones: MPE v1.0's Lower and Upper Zones by their Member Channels' count (0, none), and the MIDI 2.0
/// MPE Profile's, each its Manager Channel (its lowest) and its channels' count.
#[derive(Clone, Debug, Default, PartialEq)]
pub struct Mpe { lower: u32, upper: u32, profiles: Vec<(u32, u32)> }
impl Mpe {
    /// The channels that share a bend sensitivity sent to `channel` -- an MPE v1.0 zone's Member Channels, a Profile's
    /// every channel when sent to its Manager -- or none.
    fn shared(&self, channel: u32) -> Option<std::ops::RangeInclusive<u32>> {
        if self.lower > 0 && (1..=self.lower).contains(&channel) { return Some(1..=self.lower); }
        if self.upper > 0 && (15 - self.upper..=14).contains(&channel) { return Some(15 - self.upper..=14); }
        self.profiles.iter().find(|&&(manager, _)| manager == channel).map(|&(manager, count)| manager..=(manager + count - 1).min(15))
    }
    fn json(&self) -> Json {
        json::obj(vec![("lower", json::num(self.lower as f64)), ("upper", json::num(self.upper as f64)),
            ("profiles", Json::Array(self.profiles.iter().map(|&(m, n)| Json::Array(vec![json::num(m as f64), json::num(n as f64)])).collect()))])
    }
}
const MPE_PROFILE: [u8; 5] = [0x7E, 0x31, 0x00, 0x01, 0x01];

fn invalid_configuration() -> JsError { JsError::type_error("Invalid live note projection configuration") }

impl Tracker {
    pub fn new(ticks_per_quarter: f64, bend_range: f64, retain: bool, max_active: f64) -> Result<Tracker, JsError> {
        if !(ticks_per_quarter.is_finite() && ticks_per_quarter > 0.0 && bend_range.is_finite() && bend_range > 0.0
            && max_active.fract() == 0.0 && (1.0..=32768.0).contains(&max_active)) { return Err(invalid_configuration()); }
        Ok(Tracker { ticks_per_quarter, bend_range, retain, max_active: max_active as usize, channels: Vec::new(), channel_index: HashMap::new(),
            per_notes: Vec::new(), per_note_index: HashMap::new(), waiting: HashMap::new(), notes: Vec::new(), free: Vec::new(), history: Vec::new(),
            active: 0, finished: false, midi1: vec![None; 16], mpe: vec![Mpe::default(); 16], sysex: vec![None; 16] })
    }
    /// A tracker from its configuration as JSON {ticksPerQuarterNote, bendRange, retainHistory, maxActiveNotes}.
    pub fn from_json(config: &Json) -> Result<Tracker, JsError> {
        let n = |key: &str| match config.get(key) { Some(Json::Number(x)) => *x, _ => f64::NAN };
        let retain = config.get("retainHistory").and_then(Json::boolean).unwrap_or(false);
        Tracker::new(n("ticksPerQuarterNote"), n("bendRange"), retain, n("maxActiveNotes"))
    }

    fn note(&self, id: usize) -> &Note { self.notes[id].as_ref().unwrap() }
    fn note_mut(&mut self, id: usize) -> &mut Note { self.notes[id].as_mut().unwrap() }
    fn channel_for(&mut self, group: u32, channel: u32) -> usize {
        if let Some(&i) = self.channel_index.get(&(group, channel)) { return i; }
        self.channels.push(Channel { group, channel, notes: Vec::new(), bend: 2147483648.0, bend_range: 2.0, per_note_range: self.bend_range,
            pressure: 1.0, slide: 0.5, volume: 1.0, expression: 1.0, sustain: false, fine: 0.0, coarse: 0.0 });
        self.channel_index.insert((group, channel), self.channels.len() - 1);
        self.channels.len() - 1
    }
    fn per_note_for(&mut self, key: Key) -> usize {
        if let Some(&i) = self.per_note_index.get(&key) { return i; }
        self.per_notes.push((key, PerNote::fresh()));
        self.per_note_index.insert(key, self.per_notes.len() - 1);
        self.per_notes.len() - 1
    }

    // The controls a note is heard with now (ump-notes.js `controls`): its pitch's offset, pressure, slide, gain, timbre
    // and pan, each kept where it changed.
    fn controls(&mut self, id: usize, time: f64) {
        let retain = self.retain;
        let note = self.notes[id].as_ref().unwrap();
        let c = &self.channels[note.channel_index];
        let p = &note.per_note;
        let values = [
            (1u32, p.pitch.unwrap_or(note.pitch) - note.pitch + p.bend + bend_semitones(c.bend, c.bend_range) + c.fine + c.coarse),
            (2, p.pressure * c.pressure), (3, p.slide.unwrap_or(c.slide)), (5, p.volume * p.expression * c.volume * c.expression),
            (6, p.timbre), (7, p.pan),
        ];
        let note = self.notes[id].as_mut().unwrap();
        for (action, value) in values {
            if note.last[action as usize].map_or(true, |last| last != value) {
                if retain { note.controls.push((time, action, value)); }
                note.last[action as usize] = Some(value);
            }
        }
    }

    fn finish(&mut self, id: usize, time: f64) {
        let tpq = self.ticks_per_quarter;
        let note = self.notes[id].as_mut().unwrap();
        if note.end_time.is_some() { return; }
        note.end_time = Some(time);
        note.duration = js_max(0.0, time / tpq - note.at);
        let (channel, key) = (note.channel_index, note.key());
        self.channels[channel].notes.retain(|&n| n != id);
        self.active -= 1;
        if let Some(queue) = self.waiting.get_mut(&key) {
            queue.retain(|&n| n != id);
            if queue.is_empty() { self.waiting.remove(&key); }
        }
        if !self.retain { self.notes[id] = None; self.free.push(id); }
    }

    fn add_note(&mut self, note: Note) -> usize {
        match self.free.pop() { Some(id) => { self.notes[id] = Some(note); id } None => { self.notes.push(Some(note)); self.notes.len() - 1 } }
    }

    /// One message (ump-notes.js consume): `header` a clip header's, at time 0, whose notes are not played; `source`
    /// the index its caller knows the event by.
    pub fn consume(&mut self, time: f64, packet: &[u32], header: bool, source: usize) -> Result<(), JsError> {
        if self.finished { return Err(JsError::error("A finished UMP trace cannot consume more events")); }
        let stamp = Stamp { time, packet: packet.to_vec(), source: Some(source) };
        match ump::mt(packet[0]) {
            2 => {
                let w = packet[0];
                let group = (w >> 24 & 15) as usize;
                let bytes = [(w >> 16 & 0xFF) as u8, (w >> 8 & 0x7F) as u8, (w & 0x7F) as u8];
                let converter = self.midi1[group].get_or_insert_with(|| Converter::new(group as u32));
                let mut made = converter.flush_before(time);
                made.extend(converter.convert(&bytes, time)?);
                for (_, made) in made { if ump::mt(made[0]) == 4 { self.message(&stamp, &made, header)?; } }
                Ok(())
            }
            3 => { self.sysex7(packet); Ok(()) }
            4 => self.message(&stamp, packet, header),
            _ => Ok(()),
        }
    }

    // A SysEx7 packet, gathered with its Group's others into a whole message; a whole one read for MIDI-CI's Set Profile On
    // and Off of the MPE Profile (M2-120-UM v2.0.3 A.3: 7E, its Manager Channel, 0D, 22 or 23, the version, two MUIDs,
    // the Profile's id, and from version 2 the channels' count, 14 bits low first).
    fn sysex7(&mut self, packet: &[u32]) {
        let group = (packet[0] >> 24 & 15) as usize;
        let (status, n) = (packet[0] >> 20 & 15, (packet[0] >> 16 & 15).min(6) as usize);
        let b = [(packet[0] >> 8) as u8, packet[0] as u8, (packet[1] >> 24) as u8, (packet[1] >> 16) as u8, (packet[1] >> 8) as u8, packet[1] as u8];
        let data = &b[..n];
        let whole = match status {
            0 => { self.sysex[group] = None; Some(data.to_vec()) }
            1 => { self.sysex[group] = Some(data.to_vec()); None }
            2 => { if let Some(gathered) = self.sysex[group].as_mut() { gathered.extend_from_slice(data); } None }
            3 => self.sysex[group].take().map(|mut gathered| { gathered.extend_from_slice(data); gathered }),
            _ => None,
        };
        let Some(m) = whole else { return };
        if m.len() < 18 || m[0] != 0x7E || m[1] > 15 || m[2] != 0x0D || !(m[3] == 0x22 || m[3] == 0x23) || m[13..18] != MPE_PROFILE { return; }
        let manager = m[1] as u32;
        let zones = &mut self.mpe[group];
        zones.profiles.retain(|&(other, _)| other != manager);
        if m[3] == 0x23 { return; }
        let count = if m.len() >= 20 { (m[18] as u32 | (m[19] as u32) << 7).clamp(1, 16 - manager) } else { 16 - manager };
        zones.profiles.push((manager, count));
        for channel in manager..manager + count { let c = self.channel_for(group as u32, channel); self.channels[c].bend_range = 48.0; }
    }
    // An MPE Configuration Message (RPN 0/6) on a zone's Manager Channel, 1 or 16 (MPE v1.0 §2.1.1): its zone's Member
    // Channels, the newest message taking channels another zone held (and its Manager, closing that zone), its Manager's
    // bend sensitivity 2 semitones and its Members' 48 (§2.4).
    fn configure_mpe(&mut self, group: u32, channel: u32, members: u32) {
        let zones = &mut self.mpe[group as usize];
        let members = members.min(15);
        if channel == 0 {
            zones.lower = members;
            if zones.upper > 0 && members >= 15 - zones.upper { zones.upper = if members >= 14 { 0 } else { 14 - members }; }
        } else if channel == 15 {
            zones.upper = members;
            if zones.lower > 0 && zones.lower >= 15 - members { zones.lower = if members >= 14 { 0 } else { 14 - members }; }
        } else { return; }
        if members == 0 { return; }
        let manager = self.channel_for(group, channel);
        self.channels[manager].bend_range = 2.0;
        let range = if channel == 0 { 1..=members } else { 15 - members..=14 };
        for member in range { let c = self.channel_for(group, member); self.channels[c].bend_range = 48.0; }
    }

    // A MIDI 2.0 Channel Voice message, `stamp` the event it came in.
    fn message(&mut self, stamp: &Stamp, packet: &[u32], header: bool) -> Result<(), JsError> {
        let m = ump::fields(packet);
        let kind = Kind::of(m.status >> 4);
        let time = if header { 0.0 } else { stamp.time };
        let at = time / self.ticks_per_quarter;
        let c = self.channel_for(m.group, m.channel);
        let key = (m.group, m.channel, m.note);
        let state = self.per_note_for(key);
        match kind {
            Kind::NoteOn if !header => {
                if self.active >= self.max_active { return Err(JsError::range("Live note projection budget exhausted")); }
                let pitch = if m.attribute == 3 { (packet[1] & 0xFFFF) as f64 / 512.0 } else { self.per_notes[state].1.pitch.unwrap_or(m.note as f64) };
                let per_note = PerNote { pitch: None, ..self.per_notes[state].1.clone() };
                let note = Note { at, duration: 0.0, pitch, velocity: m.velocity as f64 / 65535.0, group: m.group, channel: m.channel, note: m.note,
                    on: stamp.clone(), off: None, release_velocity: None, end_time: None, expression: Vec::new(), controls: Vec::new(),
                    articulation: per_note.articulation.clone(), channel_index: c, per_note, last: [None; 8], detached: false, held: false };
                let id = self.add_note(note);
                self.waiting.entry(key).or_default().push_back(id);
                self.channels[c].notes.push(id);
                self.active += 1;
                if self.retain { self.history.push(id); }
                self.controls(id, time);
            }
            Kind::NoteOff if !header => {
                let released = self.waiting.get_mut(&key).and_then(VecDeque::pop_front);
                if let Some(id) = released {
                    let sustain = self.channels[c].sustain;
                    let note = self.note_mut(id);
                    note.off = Some(stamp.clone());
                    note.release_velocity = Some(m.velocity as f64 / 65535.0);
                    if !sustain { self.finish(id, time); } else { self.note_mut(id).held = true; }
                }
                if self.waiting.get(&key).map_or(true, VecDeque::is_empty) { self.waiting.remove(&key); }
            }
            Kind::PerNoteManagement => {
                let ids: Vec<usize> = self.channels[c].notes.clone();
                if m.attribute & 2 != 0 { for &id in &ids { if self.note(id).key() == key { self.note_mut(id).detached = true; } } }
                if m.attribute & 1 != 0 {
                    self.per_notes[state].1 = PerNote::fresh();
                    let reset = self.per_notes[state].1.clone();
                    for &id in &ids {
                        if self.note(id).key() == key && !self.note(id).detached { self.note_mut(id).per_note = reset.clone(); self.controls(id, time); }
                    }
                }
            }
            Kind::PerNoteBend | Kind::PerNotePressure | Kind::PerNoteController => {
                let (field, value) = match kind {
                    Kind::PerNoteBend => (Some(Field::Bend), bend_semitones(m.data as f64, self.channels[c].per_note_range)),
                    Kind::PerNotePressure => (Some(Field::Pressure), m.data as f64 / 4294967295.0),
                    _ if ARTICULATION.contains(&m.attribute) => {
                        let amount = bipolar(m.data);
                        self.per_notes[state].1.articulation.insert(m.attribute, amount);
                        match m.attribute { 71 => (Some(Field::Timbre), 0.5 + amount / 2.0), 10 => (Some(Field::Pan), amount), _ => (None, amount) }
                    }
                    _ => (match m.attribute { 3 => Some(Field::Pitch), 7 => Some(Field::Volume), 11 => Some(Field::Expression), 74 => Some(Field::Slide), _ => None },
                        if m.attribute == 3 { m.data as f64 / 33554432.0 } else { m.data as f64 / 4294967295.0 }),
                };
                if let Some(f) = field { self.per_notes[state].1.set(f, value); }
                let retain = self.retain;
                for id in self.channels[c].notes.clone() {
                    if self.note(id).key() != key || self.note(id).detached { continue; }
                    let note = self.note_mut(id);
                    if retain {
                        let at = at - note.at;
                        note.expression.push(Expression { at, time, kind, index: m.attribute, value: m.data,
                            semitones: (kind == Kind::PerNoteBend).then_some(value), source: stamp.source });
                    }
                    if let Some(f) = field { note.per_note.set(f, value); }
                    self.controls(id, time);
                }
            }
            Kind::ChannelBend | Kind::ChannelPressure | Kind::Control | Kind::RegisteredController => {
                {
                    let ch = &mut self.channels[c];
                    match kind {
                        Kind::ChannelBend => ch.bend = m.data as f64,
                        Kind::ChannelPressure => ch.pressure = m.data as f64 / 4294967295.0,
                        Kind::RegisteredController if m.note == 0 => match m.attribute {
                            0 => ch.bend_range = (m.data >> 25) as f64 + ((m.data >> 18) & 127) as f64 / 100.0,
                            1 => ch.fine = bend_semitones(m.data as f64, 1.0),
                            2 => ch.coarse = (m.data >> 25) as f64 - 64.0,
                            7 => ch.per_note_range = m.data as f64 / 33554432.0,
                            _ => {}
                        },
                        _ => {}
                    }
                }
                if kind == Kind::RegisteredController && m.note == 0 && (m.attribute == 0 || m.attribute == 6) {
                    // MPE: an MCM sets up its zone; a bend sensitivity is its zone's, each of whose notes is heard anew.
                    if m.attribute == 6 { self.configure_mpe(m.group, m.channel, m.data >> 25); }
                    let shared = if m.attribute == 0 { self.mpe[m.group as usize].shared(m.channel) } else { None };
                    if let Some(range) = shared {
                        let value = self.channels[c].bend_range;
                        for member in range.filter(|&k| k != m.channel) {
                            let other = self.channel_for(m.group, member);
                            self.channels[other].bend_range = value;
                            for id in self.channels[other].notes.clone() { self.controls(id, time); }
                        }
                    }
                    if m.attribute == 6 {
                        for other in 0..self.channels.len() {
                            if other != c && self.channels[other].group == m.group { for id in self.channels[other].notes.clone() { self.controls(id, time); } }
                        }
                    }
                }
                if kind == Kind::Control {
                    let value = m.data as f64 / 4294967295.0;
                    match m.note { 7 => self.channels[c].volume = value, 11 => self.channels[c].expression = value, 74 => self.channels[c].slide = value, _ => {} }
                    if m.note == 64 {
                        self.channels[c].sustain = m.data >= 0x8000_0000;
                        if !self.channels[c].sustain { for id in self.channels[c].notes.clone() { if self.note(id).held { self.finish(id, time); } } }
                    }
                    if m.note == 120 || m.note == 123 {
                        for id in self.channels[c].notes.clone() {
                            if m.note == 123 && self.channels[c].sustain {
                                // All Notes Off releases keys even while the pedal keeps sounding them. A subsequent
                                // same-key Note Off belongs to the new attack.
                                self.note_mut(id).held = true;
                                let k = self.note(id).key();
                                self.waiting.remove(&k);
                            } else { self.finish(id, time); }
                        }
                    }
                    if m.note == 121 {
                        let ch = &mut self.channels[c];
                        ch.bend = 2147483648.0; ch.pressure = 1.0; ch.expression = 1.0; ch.sustain = false;
                        for id in self.channels[c].notes.clone() { if self.note(id).held { self.finish(id, time); } }
                    }
                }
                let retain = self.retain;
                for id in self.channels[c].notes.clone() {
                    if retain {
                        let note = self.note_mut(id);
                        let at = at - note.at;
                        note.expression.push(Expression { at, time, kind, index: m.note, value: m.data, semitones: None, source: stamp.source });
                    }
                    self.controls(id, time);
                }
            }
            _ => {}
        }
        Ok(())
    }

    /// Every note still sounding ended at `end` (or at its own attack, if later): the trace's notes (finish).
    pub fn finish_all(&mut self, end: f64) -> Result<Vec<&Note>, JsError> {
        if !end.is_finite() { return Err(JsError::type_error("A clip view needs its finite end time")); }
        for c in 0..self.channels.len() {
            for id in self.channels[c].notes.clone() { let time = js_max(self.note(id).on.time, end); self.finish(id, time); }
        }
        self.finished = true;
        Ok(self.history.iter().map(|&id| self.note(id)).collect())
    }

    /// The notes sounding now, as snapshot() gives them.
    pub fn snapshot(&self) -> Json {
        let mut out = Vec::new();
        for c in &self.channels {
            for &id in &c.notes {
                let n = self.note(id);
                let last = |a: usize| n.last[a];
                let offset = last(1).filter(|v| *v != 0.0 && !v.is_nan()).unwrap_or(0.0);
                out.push(json::obj(vec![("group", json::num(n.group as f64)), ("channel", json::num(n.channel as f64)), ("note", json::num(n.note as f64)),
                    ("at", json::num(n.at)), ("pitch", json::num(n.pitch + offset)), ("velocity", json::num(n.velocity)),
                    ("pressure", json::num(last(2).unwrap_or(1.0))), ("slide", json::num(last(3).unwrap_or(0.5))), ("gain", json::num(last(5).unwrap_or(1.0))),
                    ("timbre", json::num(last(6).unwrap_or(0.5))), ("pan", json::num(last(7).unwrap_or(0.0))), ("articulation", articulation_json(&n.articulation)),
                    ("keyDown", Json::Bool(n.off.is_none() && !n.held)), ("pedalHeld", Json::Bool(n.held)), ("onPacket", packet_json(&n.on.packet))]));
            }
        }
        Json::Array(out)
    }

    /// A live tracker's state (checkpoint), before frozenJson freezes it. `midi1` is new: the MIDI 1.0 translators'
    /// selections, written only where a Group's has made one (so a checkpoint without MIDI 1.0 is as it was).
    pub fn checkpoint(&self) -> Result<Json, JsError> {
        if self.retain || self.finished { return Err(JsError::error("Only an unfinished live UMP projection can be checkpointed")); }
        let event = |s: &Stamp| json::obj(vec![("time", json::num(s.time)), ("packet", packet_json(&s.packet))]);
        let mut fields = vec![("version", json::num(1.0)), ("kind", json::text("ump-live-note-state")),
            ("ticksPerQuarterNote", json::num(self.ticks_per_quarter)), ("bendRange", json::num(self.bend_range)), ("maxActiveNotes", json::num(self.max_active as f64)),
            ("perNotes", Json::Array(self.per_notes.iter().map(|(k, p)| Json::Array(vec![Json::Str(key_text(*k)), p.json()])).collect())),
            ("channels", Json::Array(self.channels.iter().map(|c| json::obj(vec![
                ("key", Json::Str(format!("{}:{}", c.group, c.channel))),
                ("state", json::obj(vec![("bend", json::num(c.bend)), ("bendRange", json::num(c.bend_range)), ("perNoteRange", json::num(c.per_note_range)),
                    ("pressure", json::num(c.pressure)), ("slide", json::num(c.slide)), ("volume", json::num(c.volume)), ("expression", json::num(c.expression)),
                    ("sustain", Json::Bool(c.sustain)), ("fine", json::num(c.fine)), ("coarse", json::num(c.coarse))])),
                ("notes", Json::Array(c.notes.iter().map(|&id| { let n = self.note(id); json::obj(vec![
                    ("on", event(&n.on)), ("off", n.off.as_ref().map(event).unwrap_or(Json::Null)), ("pitch", json::num(n.pitch)),
                    ("perNoteState", n.per_note.json()), ("held", Json::Bool(n.held)), ("detached", Json::Bool(n.detached))]) }).collect())),
            ])).collect()))];
        let midi1: Vec<Json> = self.midi1.iter().flatten().filter(|c| !c.is_fresh())
            .map(|c| Json::Array(vec![json::num(c.group as f64), c.checkpoint()])).collect();
        if !midi1.is_empty() { fields.push(("midi1", Json::Array(midi1))); }
        let mpe: Vec<Json> = self.mpe.iter().enumerate().filter(|(_, z)| **z != Mpe::default())
            .map(|(g, z)| Json::Array(vec![json::num(g as f64), z.json()])).collect();
        if !mpe.is_empty() { fields.push(("mpe", Json::Array(mpe))); }
        let sysex: Vec<Json> = self.sysex.iter().enumerate().filter_map(|(g, b)| b.as_ref().map(|b| (g, b)))
            .map(|(g, b)| Json::Array(vec![json::num(g as f64), Json::Array(b.iter().map(|&x| json::num(x as f64)).collect())])).collect();
        if !sysex.is_empty() { fields.push(("sysex", Json::Array(sysex))); }
        Ok(json::obj(fields))
    }

    /// A checkpoint's state, all of it checked before any of it replaces this tracker's (restore: its refusals in its
    /// words, in its order).
    pub fn restore(&mut self, value: &Json) -> Result<(), JsError> {
        if self.retain || self.finished { return Err(JsError::error("Restore requires an unfinished live UMP projection")); }
        translate::known(value, &["version", "kind", "ticksPerQuarterNote", "bendRange", "maxActiveNotes", "perNotes", "channels", "midi1", "mpe", "sysex"], "UMP note checkpoint")?;
        let channels = value.get("channels").and_then(Json::items);
        let per_notes = value.get("perNotes").and_then(Json::items);
        if value.num("version") != Some(1.0) || value.get("kind").and_then(Json::text) != Some("ump-live-note-state")
            || value.num("ticksPerQuarterNote") != Some(self.ticks_per_quarter) || value.num("bendRange") != Some(self.bend_range)
            || value.num("maxActiveNotes") != Some(self.max_active as f64) || channels.map_or(true, |c| c.len() > 256)
            || per_notes.map_or(true, |p| p.len() > 65536) { return Err(JsError::type_error("Invalid UMP note checkpoint configuration/budget")); }
        let (channels, per_notes) = (channels.unwrap(), per_notes.unwrap());
        let mut fresh = Tracker::new(self.ticks_per_quarter, self.bend_range, false, self.max_active as f64)?;
        for pair in per_notes {
            let Some([key, state]) = pair.items().and_then(|i| <&[Json; 2]>::try_from(i).ok()) else { return Err(JsError::type_error("Invalid per-note checkpoint entry")) };
            let key = checked_key(key, 3)?;
            if fresh.per_note_index.contains_key(&key) { return Err(JsError::type_error("Duplicate per-note checkpoint key")); }
            let state = per_note(state)?;
            fresh.per_notes.push((key, state));
            fresh.per_note_index.insert(key, fresh.per_notes.len() - 1);
        }
        let mut count = 0usize;
        for entry in channels {
            translate::known(entry, &["key", "state", "notes"], "channel checkpoint")?;
            let key = checked_key(entry.get("key").unwrap_or(&Json::Null), 2)?;
            let notes = entry.get("notes").and_then(Json::items);
            if fresh.channel_index.contains_key(&(key.0, key.1)) || notes.is_none() { return Err(JsError::type_error("Invalid channel checkpoint entry")); }
            let state = entry.get("state").unwrap_or(&Json::Null);
            translate::known(state, &["bend", "bendRange", "perNoteRange", "pressure", "slide", "volume", "expression", "sustain", "fine", "coarse"], "channel checkpoint state")?;
            let num = |k: &str| match state.get(k) { Some(Json::Number(x)) => Some(*x), _ => None };
            for k in ["bend", "bendRange", "perNoteRange", "pressure", "slide", "volume", "expression", "sustain", "fine", "coarse"] {
                let ok = if k == "sustain" { matches!(state.get(k), Some(Json::Bool(_))) } else { num(k).is_some() };
                if !ok { return Err(JsError::type_error("Invalid channel checkpoint value")); }
            }
            let g = |k: &str| num(k).unwrap();
            let bend = g("bend");
            if bend.fract() != 0.0 || bend < 0.0 || bend > 4294967295.0 || g("bendRange") < 0.0 || g("perNoteRange") < 0.0 {
                return Err(JsError::type_error("Invalid channel checkpoint bend"));
            }
            let unit = |k: &str| (0.0..=1.0).contains(&g(k));
            if !(unit("pressure") && unit("slide") && unit("volume") && unit("expression")) || g("fine") < -1.0 || g("fine") > 1.0
                || g("coarse").fract() != 0.0 || g("coarse") < -64.0 || g("coarse") > 63.0 {
                return Err(JsError::type_error("Channel checkpoint value outside MIDI range"));
            }
            let c = fresh.channel_for(key.0, key.1);
            {
                let ch = &mut fresh.channels[c];
                ch.bend = bend; ch.bend_range = g("bendRange"); ch.per_note_range = g("perNoteRange"); ch.pressure = g("pressure"); ch.slide = g("slide");
                ch.volume = g("volume"); ch.expression = g("expression"); ch.sustain = state.get("sustain").and_then(Json::boolean).unwrap(); ch.fine = g("fine"); ch.coarse = g("coarse");
            }
            for item in notes.unwrap() {
                count += 1;
                if count > self.max_active { return Err(JsError::range("Live note checkpoint budget exhausted")); }
                translate::known(item, &["on", "off", "pitch", "perNoteState", "held", "detached"], "active note checkpoint")?;
                let (on, m) = read_event(item.get("on").unwrap_or(&Json::Null), Kind::NoteOn)?;
                let pitch = item.num("pitch");
                let held = item.get("held").and_then(Json::boolean);
                let detached = item.get("detached").and_then(Json::boolean);
                let (Some(pitch), Some(held), Some(detached)) = (pitch.filter(|p| p.is_finite() && *p >= 0.0 && *p < 128.0), held, detached)
                    else { return Err(JsError::type_error("Invalid active note checkpoint")) };
                if (m.group, m.channel) != (key.0, key.1) { return Err(JsError::type_error("Invalid active note checkpoint")); }
                let per_note = per_note(item.get("perNoteState").unwrap_or(&Json::Null))?;
                let note_key = (m.group, m.channel, m.note);
                let mut note = Note { at: on.time / self.ticks_per_quarter, duration: 0.0, pitch, velocity: m.velocity as f64 / 65535.0,
                    group: m.group, channel: m.channel, note: m.note, on, off: None, release_velocity: None, end_time: None, expression: Vec::new(), controls: Vec::new(),
                    articulation: per_note.articulation.clone(), channel_index: c, per_note, last: [None; 8], detached, held };
                if !fresh.per_note_index.contains_key(&note_key) { return Err(JsError::type_error("Missing persistent per-note state")); }
                match item.get("off") {
                    Some(Json::Null) => {}
                    off => {
                        let (off, release) = read_event(off.unwrap_or(&Json::Null), Kind::NoteOff)?;
                        if (release.group, release.channel, release.note) != note_key || off.time < note.on.time || !held {
                            return Err(JsError::type_error("Invalid held note release"));
                        }
                        note.release_velocity = Some(release.velocity as f64 / 65535.0);
                        note.off = Some(off);
                    }
                }
                if held && !fresh.channels[c].sustain { return Err(JsError::type_error("Held note requires an active sustain pedal")); }
                let (time, waits) = (note.on.time, !note.held && note.off.is_none());
                let id = fresh.add_note(note);
                fresh.channels[c].notes.push(id);
                fresh.active += 1;
                fresh.controls(id, time);
                // Waiting is the FIFO of unreleased keys. Channel insertion order is exactly attack order, also for
                // overlapping/detached same-key notes.
                if waits { fresh.waiting.entry(note_key).or_default().push_back(id); }
            }
        }
        for (key, _) in &fresh.per_notes {
            if !fresh.channel_index.contains_key(&(key.0, key.1)) { return Err(JsError::type_error("Persistent per-note state requires its channel")); }
        }
        if let Some(midi1) = value.get("midi1") {
            let items = midi1.items().ok_or_else(|| JsError::type_error("Invalid MIDI 1 translation checkpoint"))?;
            for item in items {
                let pair = item.items().filter(|p| p.len() == 2).ok_or_else(|| JsError::type_error("Invalid MIDI 1 translation checkpoint"))?;
                let group = pair[0].number().filter(|g| g.fract() == 0.0 && (0.0..16.0).contains(g)).ok_or_else(|| JsError::type_error("Invalid MIDI 1 translation checkpoint"))? as usize;
                if fresh.midi1[group].is_some() { return Err(JsError::type_error("Invalid MIDI 1 translation checkpoint")); }
                let mut converter = Converter::new(group as u32);
                converter.restore(&pair[1])?;
                fresh.midi1[group] = Some(converter);
            }
        }
        let invalid_mpe = || JsError::type_error("Invalid MPE checkpoint");
        let whole = |v: &Json, most: f64| v.number().filter(|x| x.fract() == 0.0 && (0.0..=most).contains(x)).map(|x| x as u32);
        fn grouped(v: &Json) -> Option<(usize, &Json)> {
            let p = v.items().filter(|p| p.len() == 2)?;
            let g = p[0].number().filter(|x| x.fract() == 0.0 && (0.0..=15.0).contains(x))?;
            Some((g as usize, &p[1]))
        }
        if let Some(items) = value.get("mpe") {
            for item in items.items().ok_or_else(invalid_mpe)? {
                let (group, zones) = grouped(item).ok_or_else(invalid_mpe)?;
                translate::known(zones, &["lower", "upper", "profiles"], "MPE checkpoint")?;
                let (lower, upper) = (zones.get("lower").and_then(|v| whole(v, 15.0)), zones.get("upper").and_then(|v| whole(v, 15.0)));
                let profiles: Option<Vec<(u32, u32)>> = zones.get("profiles").and_then(Json::items).and_then(|list| list.iter().map(|p| {
                    let p = p.items().filter(|p| p.len() == 2)?; Some((whole(&p[0], 15.0)?, whole(&p[1], 16.0).filter(|n| *n >= 1)?)) }).collect());
                let (Some(lower), Some(upper), Some(profiles)) = (lower, upper, profiles) else { return Err(invalid_mpe()) };
                fresh.mpe[group] = Mpe { lower, upper, profiles };
            }
        }
        if let Some(items) = value.get("sysex") {
            for item in items.items().ok_or_else(invalid_mpe)? {
                let (group, bytes) = grouped(item).ok_or_else(invalid_mpe)?;
                let bytes: Option<Vec<u8>> = bytes.items().and_then(|b| b.iter().map(|x| whole(x, 127.0).map(|x| x as u8)).collect());
                fresh.sysex[group] = Some(bytes.filter(|b| b.len() <= 65536).ok_or_else(invalid_mpe)?);
            }
        }
        // No original controller/note state changes until the entire graph passes.
        *self = fresh;
        Ok(())
    }
}

fn packet_json(packet: &[u32]) -> Json { Json::Array(packet.iter().map(|&w| json::num(w as f64)).collect()) }

// ump-notes.js checkedKey: "group:channel" or "group:channel:note", each part as String(Number) writes it.
fn checked_key(value: &Json, parts: usize) -> Result<Key, JsError> {
    let invalid = || JsError::type_error("Invalid UMP state key");
    let text = value.text().ok_or_else(invalid)?;
    let numbers: Vec<&str> = text.split(':').collect();
    if numbers.len() < 2 || numbers.len() > 3 || numbers.iter().any(|n| n.is_empty() || !n.bytes().all(|b| b.is_ascii_digit())) { return Err(invalid()); }
    if numbers.len() != parts || numbers.iter().any(|n| n.len() > 1 && n.starts_with('0')) { return Err(invalid()); }
    let n: Vec<u64> = numbers.iter().map(|n| n.parse::<u64>().unwrap_or(u64::MAX)).collect();
    if n[0] > 15 || n[1] > 15 || parts == 3 && n[2] > 255 { return Err(invalid()); }
    Ok((n[0] as u32, n[1] as u32, if parts == 3 { n[2] as u32 } else { 0 }))
}

// ump-notes.js perNote: a note's or a Note Number's checkpointed state, timbre, pan and articulation at their defaults
// where a checkpoint from before them leaves them out.
fn per_note(value: &Json) -> Result<PerNote, JsError> {
    translate::known(value, &["bend", "pressure", "slide", "pitch", "volume", "expression", "timbre", "pan", "articulation"], "per-note checkpoint state")?;
    let articulation = match value.get("articulation") {
        None => BTreeMap::new(),
        Some(Json::Object(entries)) => {
            let mut a = BTreeMap::new();
            for (index, amount) in entries {
                let number = index.parse::<u32>().ok().filter(|n| n.to_string() == *index && ARTICULATION.contains(n));
                let amount = amount.number().filter(|x| x.is_finite() && (-1.0..=1.0).contains(x));
                let (Some(number), Some(amount)) = (number, amount) else { return Err(JsError::type_error("Invalid per-note checkpoint articulation")) };
                a.insert(number, amount);
            }
            a
        }
        Some(_) => return Err(JsError::type_error("Invalid per-note checkpoint articulation")),
    };
    let finite = |k: &str, default: Option<f64>| -> Result<f64, JsError> {
        match value.get(k) { Some(Json::Number(x)) => Ok(*x), None if default.is_some() => Ok(default.unwrap()), _ => Err(JsError::type_error("Invalid per-note checkpoint value")) }
    };
    let nullable = |k: &str| -> Result<Option<f64>, JsError> {
        match value.get(k) { Some(Json::Number(x)) => Ok(Some(*x)), Some(Json::Null) => Ok(None), _ => Err(JsError::type_error("Invalid per-note checkpoint value")) }
    };
    let (bend, pressure, slide, pitch, volume, expression) = (finite("bend", None)?, finite("pressure", None)?, nullable("slide")?, nullable("pitch")?, finite("volume", None)?, finite("expression", None)?);
    let (timbre, pan) = (finite("timbre", Some(0.5))?, finite("pan", Some(0.0))?);
    let unit = |x: f64| (0.0..=1.0).contains(&x);
    if !(unit(pressure) && unit(volume) && unit(expression)) || slide.map_or(false, |s| !unit(s)) || pitch.map_or(false, |p| !(0.0..128.0).contains(&p))
        || !unit(timbre) || !(-1.0..=1.0).contains(&pan) { return Err(JsError::type_error("Per-note checkpoint value outside MIDI range")); }
    Ok(PerNote { bend, pressure, slide, pitch, volume, expression, timbre, pan, articulation })
}

/// A packet as JSON numbers, checked as public/shared/ump.js umpPacket checks one (its errors in its words).
pub fn packet_of(value: &Json) -> Result<Vec<u32>, JsError> {
    let items = value.items().ok_or_else(|| JsError::type_error("UMP requires an array of uint32 words"))?;
    let first = items.first().and_then(Json::number).map(|x| if x.is_finite() { x.trunc().rem_euclid(4294967296.0) as u32 } else { 0 }).unwrap_or(0);
    if items.is_empty() || items.len() != ump::words_of(first) { return Err(JsError::range("UMP packet length does not match its message type")); }
    items.iter().map(|w| match w.number() {
        Some(x) if x.fract() == 0.0 && (0.0..=4294967295.0).contains(&x) => Ok(x as u32),
        _ => Err(JsError::range("UMP word must be an integer in 0..4294967295")),
    }).collect()
}

// ump-notes.js readEvent: a checkpointed note's Note On or Note Off, a MIDI 1.0 one upgraded on its own.
fn read_event(value: &Json, kind: Kind) -> Result<(Stamp, ump::Fields), JsError> {
    translate::known(value, &["time", "packet"], "note checkpoint event")?;
    let time = value.num("time").filter(|t| t.is_finite()).ok_or_else(|| JsError::type_error("Invalid note checkpoint time"))?;
    let packet = packet_of(value.get("packet").unwrap_or(&Json::Null))?;
    let decoded: Vec<u32> = if ump::mt(packet[0]) == 2 { translate::upgrade(packet[0]).map(|p| p.to_vec()).unwrap_or_else(|| packet.clone()) } else { packet.clone() };
    let m = ump::fields(&decoded);
    if m.mt != 4 || Kind::of(m.status >> 4) != kind { return Err(JsError::type_error("Invalid note checkpoint packet")); }
    Ok((Stamp { time, packet, source: None }, m))
}

// ---- A trace's notes as JSON for public/shared/ump-notes.js, which gives each its own event objects back -----------
/// The notes, each [at, duration, pitch, velocity, group, channel, note, on, off, releaseVelocity, endTime, articulation,
/// expression, controls]: `on`, `off` and each expression's last item the index of the event it came in (in the order
/// consumed: a trace's header first), null where none; expression as [at, time, kind, index, value, semitones]; controls
/// as [time, action, value].
pub fn notes_json(notes: &[&Note]) -> Json {
    Json::Array(notes.iter().map(|n| Json::Array(vec![
        json::num(n.at), json::num(n.duration), json::num(n.pitch), json::num(n.velocity), json::num(n.group as f64), json::num(n.channel as f64),
        json::num(n.note as f64), json::opt(n.on.source.map(|s| s as f64)), json::opt(n.off.as_ref().and_then(|o| o.source).map(|s| s as f64)),
        json::opt(n.release_velocity), json::opt(n.end_time), articulation_json(&n.articulation),
        Json::Array(n.expression.iter().map(|e| Json::Array(vec![json::num(e.at), json::num(e.time), Json::Str(e.kind.name().into()),
            json::num(e.index as f64), json::num(e.value as f64), json::opt(e.semitones), json::opt(e.source.map(|s| s as f64))])).collect()),
        Json::Array(n.controls.iter().map(|&(t, a, v)| Json::Array(vec![json::num(t), json::num(a as f64), json::num(v)])).collect()),
    ])).collect())
}

#[cfg(test)]
mod tests {
    use super::*;
    fn on(note: u32, pitch: f64) -> Vec<u32> { vec![0x40900003 | note << 8, 0xffff0000 | (pitch * 512.0).round() as u32] }
    fn off(note: u32) -> Vec<u32> { vec![0x40800000 | note << 8, 0] }
    #[test]
    fn a_tuned_note_and_its_bend() {
        let mut t = Tracker::new(1.0, 48.0, true, 32768.0).unwrap();
        t.consume(0.0, &on(60, 60.25), false, 0).unwrap();
        t.consume(1.0, &[0x40603c00, 0xc0000000], false, 1).unwrap();
        t.consume(2.0, &off(60), false, 2).unwrap();
        let notes = t.finish_all(2.0).unwrap();
        assert_eq!(notes.len(), 1);
        assert_eq!(notes[0].pitch, 60.25);
        assert_eq!(notes[0].duration, 2.0);
        assert_eq!(notes[0].expression[0].semitones, Some(bend_semitones(3221225472.0, 48.0)));
        assert_eq!(notes[0].controls.iter().filter(|c| c.1 == 1).count(), 2);
    }
    #[test]
    fn midi1_bend_range_set_by_rpn_reaches_the_notes() {
        // A MIDI 1.0 clip's RPN 0 (CC 101, 100, 6, no 38) of 12 semitones, then a note bent all the way up.
        let mut t = Tracker::new(1.0, 48.0, true, 32768.0).unwrap();
        for (i, w) in [0x20b06500u32, 0x20b06400, 0x20b0060c, 0x20903c64, 0x20e07f7f].iter().enumerate() { t.consume(i as f64, &[*w], false, i).unwrap(); }
        let notes = t.finish_all(9.0).unwrap();
        let bent = notes[0].controls.iter().rev().find(|c| c.1 == 1).unwrap().2;
        assert!((bent - 12.0).abs() < 1e-6, "{}", bent);
    }
    #[test]
    fn an_mpe_zone_bends_its_members_48_semitones() {
        // MPE v1.0, as MIDI 1.0 in a clip: the Lower Zone's MCM (7 members) on channel 1, then a note on channel 2 bent
        // all the way up -- 48 semitones -- and a sensitivity of 12 sent to channel 3 that is channel 2's too.
        let mut t = Tracker::new(1.0, 48.0, true, 32768.0).unwrap();
        let mt2 = |status: u32, a: u32, b: u32| 0x2000_0000 | status << 16 | a << 8 | b;
        let words = [mt2(0xb0, 100, 6), mt2(0xb0, 101, 0), mt2(0xb0, 6, 7), mt2(0x91, 60, 100), mt2(0xe1, 127, 127),
            mt2(0xb2, 101, 0), mt2(0xb2, 100, 0), mt2(0xb2, 6, 12), mt2(0xb2, 38, 0)];
        for (i, w) in words.iter().enumerate() { t.consume(i as f64, &[*w], false, i).unwrap(); }
        let notes = t.finish_all(20.0).unwrap();
        let pitch: Vec<f64> = notes[0].controls.iter().filter(|c| c.1 == 1).map(|c| c.2).collect();
        assert!((pitch[1] - 48.0).abs() < 1e-6 && (pitch[2] - 12.0).abs() < 1e-6, "{:?}", pitch);
    }
    #[test]
    fn the_mpe_profile_set_on_in_a_preamble_bends_at_48() {
        // A Set Profile On for the MPE Profile, Manager Channel 1, 4 channels (MIDI-CI version 2), as two SysEx7 packets.
        let message: Vec<u8> = vec![0x7E, 0x00, 0x0D, 0x22, 0x02, 1, 2, 3, 4, 0x7F, 0x7F, 0x7F, 0x7F, 0x7E, 0x31, 0x00, 0x01, 0x01, 4, 0];
        let mut t = Tracker::new(1.0, 48.0, true, 32768.0).unwrap();
        let chunks: Vec<&[u8]> = message.chunks(6).collect();
        for (i, chunk) in chunks.iter().enumerate() {
            let status = if i == 0 { 1 } else if i == chunks.len() - 1 { 3 } else { 2 };
            let mut b = [0u8; 8]; b[0] = 0x30; b[1] = (status << 4 | chunk.len()) as u8; b[2..2 + chunk.len()].copy_from_slice(chunk);
            t.consume(0.0, &[u32::from_be_bytes([b[0], b[1], b[2], b[3]]), u32::from_be_bytes([b[4], b[5], b[6], b[7]])], true, i).unwrap();
        }
        t.consume(1.0, &[0x40933c00, 0xffff0000], false, 9).unwrap();
        t.consume(2.0, &[0x40e30000, 0xffffffff], false, 10).unwrap();
        let notes = t.finish_all(3.0).unwrap();
        let bent = notes[0].controls.iter().rev().find(|c| c.1 == 1).unwrap().2;
        assert!((bent - 48.0).abs() < 1e-6, "{}", bent);
    }
    #[test]
    fn checkpoints_round_trip() {
        let mut t = Tracker::new(1.0, 48.0, false, 16.0).unwrap();
        t.consume(0.0, &[0x40b04000, 0xffffffff], false, 0).unwrap();
        t.consume(1.0, &on(60, 60.125), false, 1).unwrap();
        t.consume(2.0, &off(60), false, 2).unwrap();
        t.consume(3.0, &[0x20b06500], false, 3).unwrap();
        let checkpoint = t.checkpoint().unwrap();
        let mut u = Tracker::new(1.0, 48.0, false, 16.0).unwrap();
        u.restore(&Json::parse(&checkpoint.write_shortest()).unwrap()).unwrap();
        assert_eq!(u.checkpoint().unwrap().write_shortest(), checkpoint.write_shortest());
        assert_eq!(u.snapshot().write_shortest(), t.snapshot().write_shortest());
    }
}
