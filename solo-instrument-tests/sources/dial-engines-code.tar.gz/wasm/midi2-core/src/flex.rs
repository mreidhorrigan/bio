//! Flex Data text (M2-104-UM v1.1.2 §7.5.1, §7.5.9-7.5.12; research-downloads/midi2/ump.txt): a text written as one Flex
//! Data message, and a received message's packets put back together into its text -- lyrics (Status Bank 2, Status 1)
//! and the other texts of Status Banks 1 and 2. Ported from the synthesis package's flexText and FlexTextAssembler
//! (render/synthesis/src/ump.mjs; its JavaScript archived in research/rust-port-archive/), whose timed-UMP projection and
//! collector use them, and here for anything else that reads or writes a clip's texts.
//!
//! Changed from the JavaScript, each by the specification: a message is at most 32 packets (§7.5.1), 384 bytes of text,
//! where the JavaScript wrote up to 65,536 bytes in 5,462 packets that no receiver need take; text carries no Byte Order
//! Mark (§1.8), and one leading the text is left out, as a reader's UTF-8 decoding leaves it out; and a message sent to
//! its Group ignores its Channel field (§7.5.1, Table 10), so its packets are one message whatever a writer left there.
//! Normalization Form C (§1.8) is the caller's to give: Rust's library has no normalizer, and every host's JavaScript has
//! one (the synthesis package's flexText normalizes).

use crate::ump;
use crate::JsError;

/// The most packets one Flex Data message may take (§7.5.1): a Start, 30 Continues and an End.
pub const MOST_PACKETS: usize = 32;
/// The bytes of text each packet carries (§7.5.9): its last three words.
pub const PAYLOAD: usize = 12;
const BOM: &[u8] = &[0xEF, 0xBB, 0xBF];

/// A text as one Flex Data message: `head` its first word's Group, Address, Channel, Status Bank and Status (its Format
/// the packets' own), the text's UTF-8 the payload, 12 bytes a packet, the last packet's rest 0x00 (§7.5.9). A text with
/// a NUL in it cannot be sent (0x00 ends it); nor one longer than 32 packets.
pub fn packets(head: u32, text: &[u8]) -> Result<Vec<[u32; 4]>, JsError> {
    let f = ump::flex(head).ok_or_else(|| JsError::type_error("A Flex Data message's first word required"))?;
    let text = text.strip_prefix(BOM).unwrap_or(text);
    if text.contains(&0) { return Err(JsError::type_error("Text must be NUL-free")); }
    if std::str::from_utf8(text).is_err() { return Err(JsError::type_error("Text must be UTF-8")); }
    let count = text.len().div_ceil(PAYLOAD).max(1);
    if count > MOST_PACKETS {
        return Err(JsError::range(format!("Text too long: a Flex Data message is at most {} packets, {} bytes (UMP §7.5.1), and this is {} bytes",
            MOST_PACKETS, MOST_PACKETS * PAYLOAD, text.len())));
    }
    // Sent to the Group, the Channel field is reserved, 0 (§7.5.1).
    let channel = if f.address == 0 { f.channel } else { 0 };
    let head = head & !(3 << 22 | 0xF << 16) | channel << 16;
    Ok((0..count).map(|i| {
        let format = if count == 1 { 0 } else if i == 0 { 1 } else if i == count - 1 { 3 } else { 2 };
        let mut b = [0u8; PAYLOAD];
        let chunk = &text[(i * PAYLOAD).min(text.len())..((i + 1) * PAYLOAD).min(text.len())];
        b[..chunk.len()].copy_from_slice(chunk);
        let word = |k: usize| u32::from_be_bytes([b[k], b[k + 1], b[k + 2], b[k + 3]]);
        [head | format << 22, word(0), word(4), word(8)]
    }).collect())
}

// Where a message is open: its endpoint, Group, Address, Channel (0 when sent to the Group), Status Bank and Status.
#[derive(Clone, PartialEq)]
struct Place { endpoint: String, group: u32, address: u32, channel: u32, bank: u32, status: u32 }

/// Flex Data text messages put back together from their packets as they arrive, one open at each place at a time.
/// Reassembly comes before UTF-8 decoding: a character may straddle packets.
pub struct Assembler { most: f64, open: Vec<(Place, Vec<u8>)> }
impl Assembler {
    /// `most`: the bytes a message may gather before it is refused.
    pub fn new(most: f64) -> Assembler { Assembler { most, open: Vec::new() } }
    /// How many messages are begun and not ended.
    pub fn open(&self) -> usize { self.open.len() }
    pub fn reset(&mut self) { self.open.clear(); }
    /// One Flex Data text packet (Status Bank 1 or 2: the caller sorts out the rest) from `endpoint`: its message's text
    /// when it ends one, else None. A packet that continues nothing, a Start where a message is open, a reserved Address,
    /// a message over `most` bytes, a NUL before the end of its text or text not UTF-8 is refused, in the JavaScript's
    /// words.
    pub fn push(&mut self, packet: &[u32], endpoint: &str) -> Result<Option<String>, JsError> {
        let f = match packet { [first, _, _, _] => ump::flex(*first), _ => None }.ok_or_else(|| JsError::type_error("A Flex Data packet required"))?;
        if f.address > 1 { return Err(JsError::error("Reserved Flex Data address")); }
        let place = Place { endpoint: endpoint.to_string(), group: f.group, address: f.address, channel: if f.address == 0 { f.channel } else { 0 },
            bank: f.bank, status: f.status };
        let mut payload = Vec::with_capacity(PAYLOAD);
        for word in &packet[1..] { payload.extend_from_slice(&word.to_be_bytes()); }
        let at = self.open.iter().position(|(p, _)| *p == place);
        let mut b = match (f.format, at) {
            (0 | 1, Some(_)) => return Err(JsError::error("Interrupted Flex text sequence; reset explicitly")),
            (0 | 1, None) => payload,
            (_, None) => return Err(JsError::error("Orphan Flex text continuation")),
            (_, Some(i)) => { let mut prior = self.open.swap_remove(i).1; prior.extend_from_slice(&payload); prior }
        };
        if b.len() as f64 > self.most { return Err(JsError::error("Flex text exceeds size limit")); }
        if f.format == 1 || f.format == 2 { self.open.push((place, b)); return Ok(None); }
        if let Some(nul) = b.iter().position(|&x| x == 0) {
            if b[nul..].iter().any(|&x| x != 0) { return Err(JsError::error("Embedded NUL in Flex text")); }
            b.truncate(nul);
        }
        let text = String::from_utf8(b).map_err(|_| JsError::type_error("The encoded data was not valid for encoding utf-8"))?;
        Ok(Some(text.strip_prefix('\u{FEFF}').map(str::to_string).unwrap_or(text)))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    const LYRIC: u32 = 0xD000_0201; // Group 0, to Channel 1, Status Bank 2 (performance text), Status 1 (lyric)
    fn read(packets: &[[u32; 4]]) -> Result<Option<String>, JsError> {
        let mut a = Assembler::new(65536.0);
        let mut last = Ok(None);
        for p in packets { last = a.push(p, "local"); }
        last
    }

    #[test]
    fn a_lyric_is_written_as_the_javascript_wrote_it() {
        assert_eq!(packets(LYRIC, b"hello").unwrap(), vec![[0xd000_0201, 0x6865_6c6c, 0x6f00_0000, 0]]);
        // Start, Continues, End; a text filling its last packet has no 0x00 after it.
        let p = packets(LYRIC, &[b'a'; 36]).unwrap();
        assert_eq!(p.iter().map(|w| w[0] >> 22 & 3).collect::<Vec<_>>(), vec![1, 2, 3]);
        assert_eq!(p[2][3], 0x6161_6161);
        // A melisma (§7.5.10.1): a Complete packet of 0x00.
        assert_eq!(packets(LYRIC, b"").unwrap(), vec![[LYRIC, 0, 0, 0]]);
        assert_eq!(read(&packets(LYRIC, b"").unwrap()).unwrap().as_deref(), Some(""));
    }

    #[test]
    fn a_message_is_at_most_32_packets() {
        let longest = "é".repeat(MOST_PACKETS * PAYLOAD / 2);
        let p = packets(LYRIC, longest.as_bytes()).unwrap();
        assert_eq!(p.len(), MOST_PACKETS);
        assert_eq!(read(&p).unwrap().as_deref(), Some(longest.as_str()));
        let error = packets(LYRIC, &[b'a'; MOST_PACKETS * PAYLOAD + 1]).unwrap_err();
        assert_eq!((error.kind, error.message.contains("at most 32 packets")), ("RangeError", true));
    }

    #[test]
    fn no_byte_order_mark_and_no_nul_is_sent() {
        assert_eq!(packets(LYRIC, "\u{FEFF}la".as_bytes()).unwrap(), packets(LYRIC, b"la").unwrap());
        assert_eq!(packets(LYRIC, b"a\0b").unwrap_err().message, "Text must be NUL-free");
        assert_eq!(packets(LYRIC, &[0xff]).unwrap_err().kind, "TypeError");
        // One received is left out, as the JavaScript's TextDecoder left it out.
        assert_eq!(read(&[[LYRIC, 0xefbb_bf6c, 0x6100_0000, 0]]).unwrap().as_deref(), Some("la"));
    }

    #[test]
    fn a_message_to_the_group_ignores_its_channel_field() {
        let group = 0xD010_0101; // Address 1 (the Group), Status Bank 1, Status 1 (project name)
        let p = packets(group | 0x5 << 16, &[b'x'; 20]).unwrap();
        assert!(p.iter().all(|w| w[0] >> 16 & 0xF == 0));
        // A writer that left a Channel in one packet of a message to its Group: still one message.
        let mut stray = p.clone();
        stray[0][0] |= 0x7 << 16;
        assert_eq!(read(&stray).unwrap().as_deref(), Some("xxxxxxxxxxxxxxxxxxxx"));
    }

    #[test]
    fn refusals_in_the_javascripts_words() {
        let p = packets(LYRIC, &[b'a'; 30]).unwrap();
        let mut a = Assembler::new(65536.0);
        assert_eq!(a.push(&p[1], "A").unwrap_err().message, "Orphan Flex text continuation");
        assert_eq!(a.push(&p[0], "A").unwrap(), None);
        assert_eq!(a.push(&p[0], "A").unwrap_err().message, "Interrupted Flex text sequence; reset explicitly");
        // Endpoints apart: B's continuation is not A's.
        assert_eq!(a.push(&p[1], "B").unwrap_err().message, "Orphan Flex text continuation");
        assert_eq!(a.open(), 1);
        a.reset();
        assert_eq!(a.open(), 0);
        assert_eq!(read(&[[LYRIC | 2 << 20, 0, 0, 0]]).unwrap_err().message, "Reserved Flex Data address");
        assert_eq!(read(&[[LYRIC, 0x6100_6200, 0, 0]]).unwrap_err().message, "Embedded NUL in Flex text");
        assert_eq!(read(&[[LYRIC, 0xc300_0000, 0, 0]]).unwrap_err().kind, "TypeError");
        let mut small = Assembler::new(20.0);
        assert_eq!(small.push(&p[0], "local").unwrap(), None);
        assert_eq!(small.push(&p[1], "local").unwrap_err().message, "Flex text exceeds size limit");
        assert_eq!(small.open(), 0);
    }

    #[test]
    fn a_character_straddling_packets_is_whole() {
        let text = "abcdefghijké 世界 🎼 choir";
        assert_eq!(read(&packets(LYRIC, text.as_bytes()).unwrap()).unwrap().as_deref(), Some(text));
    }
}
