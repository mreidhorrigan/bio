//! The Universal MIDI Packet's words as the UMP specification lays them out (M2-104-UM v1.1.2, 27 October 2023;
//! research-downloads/midi2/): how many words each message type takes, the fields public/shared/ump.js inspectUMP reads,
//! Min-Center-Max upscaling (Appendix D.1.3) and the few messages this crate writes itself.

/// Words in a packet, by message type (§2.1.4: 0x0-0x2, 0x6, 0x7 one word; 0x3, 0x4, 0x8-0xA two; 0xB, 0xC three; 0x5,
/// 0xD-0xF four). A reserved type keeps its length, so a reader steps over what it does not know.
pub const WORD_COUNTS: [usize; 16] = [1, 1, 1, 2, 2, 4, 1, 1, 2, 2, 2, 3, 3, 4, 4, 4];
pub fn words_of(first: u32) -> usize { WORD_COUNTS[(first >> 28) as usize] }
pub fn mt(first: u32) -> u32 { first >> 28 }

// ---- Utility messages (MT 0x0, §7.2), whose Group bits UMP 1.1 reserves: read whatever a 1.0 writer put there --------
pub fn utility_status(first: u32) -> Option<u32> { if mt(first) == 0 { Some((first >> 20) & 0xF) } else { None } }
pub const NOOP: u32 = 0;
pub fn is_noop(first: u32) -> bool { utility_status(first) == Some(0) }
/// Delta Clockstamp (DCS, §7.2.3.2): 20 bits of ticks since the last event.
pub fn is_delta(first: u32) -> bool { utility_status(first) == Some(4) }
pub fn delta_ticks(first: u32) -> u32 { first & 0xF_FFFF }
pub fn delta(ticks: u32) -> u32 { 0x0040_0000 | (ticks & 0xF_FFFF) }
pub const MAX_DELTA: u32 = 0xF_FFFF;
/// Delta Clockstamp Ticks Per Quarter Note (DCTPQ, §7.2.3.1): 1-65535, 0 reserved.
pub fn is_ticks_per_quarter(first: u32) -> bool { utility_status(first) == Some(3) }
pub fn ticks_per_quarter(first: u32) -> u32 { first & 0xFFFF }
pub fn ticks_per_quarter_message(tpq: u32) -> u32 { 0x0030_0000 | (tpq & 0xFFFF) }

// ---- UMP Stream (MT 0xF, §7.1): a 10-bit status after the 2-bit Format -----------------------------------------------
pub fn stream_status(first: u32) -> Option<u32> { if mt(first) == 0xF { Some((first >> 16) & 0x3FF) } else { None } }
pub const START_OF_CLIP: [u32; 4] = [0xF020_0000, 0, 0, 0];
pub const END_OF_CLIP: [u32; 4] = [0xF021_0000, 0, 0, 0];
pub fn is_start_of_clip(first: u32) -> bool { stream_status(first) == Some(0x20) }
pub fn is_end_of_clip(first: u32) -> bool { stream_status(first) == Some(0x21) }

// ---- Flex Data (MT 0xD, §7.5) ----------------------------------------------------------------------------------------
/// A Flex Data packet's Format (0 complete, 1 start, 2 continue, 3 end), Address (0 channel, 1 group), Channel, Status
/// Bank and Status.
pub struct Flex { pub group: u32, pub format: u32, pub address: u32, pub channel: u32, pub bank: u32, pub status: u32 }
pub fn flex(first: u32) -> Option<Flex> {
    if mt(first) != 0xD { return None; }
    Some(Flex { group: (first >> 24) & 0xF, format: (first >> 22) & 3, address: (first >> 20) & 3, channel: (first >> 16) & 0xF,
        bank: (first >> 8) & 0xFF, status: first & 0xFF })
}
/// A Set Tempo's quarter note in units of 10 ns (§7.5.3: Status Bank 0, Status 0, sent complete), on any Group: None for
/// any other packet, or a tempo of 0.
pub fn tempo(packet: &[u32]) -> Option<u32> {
    let f = flex(packet[0])?;
    (f.format == 0 && f.bank == 0 && f.status == 0 && packet.len() == 4 && packet[1] > 0).then_some(packet[1])
}

// ---- Fields as public/shared/ump.js inspectUMP reads them (the C99 bridge's ump_field and JZZ's alike) ---------------
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Fields { pub mt: u32, pub group: u32, pub status: u32, pub channel: u32, pub note: u32, pub velocity: u32, pub data: u32, pub attribute: u32 }
pub fn fields(packet: &[u32]) -> Fields {
    let (w0, w1) = (packet[0], packet.get(1).copied().unwrap_or(0));
    Fields { mt: w0 >> 28, group: (w0 >> 24) & 15, status: (w0 >> 16) & 255, channel: (w0 >> 16) & 15, note: (w0 >> 8) & 255,
        velocity: w1 >> 16, data: w1, attribute: w0 & 255 }
}

/// A MIDI 2.0 Channel Voice message's kind (MT 0x4, by its status nibble), as inspectUMP names it.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Kind {
    PerNoteController, AssignablePerNoteController, RegisteredController, AssignableController, RelativeRegisteredController,
    RelativeAssignableController, PerNoteBend, NoteOff, NoteOn, PerNotePressure, Control, Program, ChannelPressure,
    ChannelBend, PerNoteManagement, Unknown,
}
impl Kind {
    pub fn of(status_nibble: u32) -> Kind {
        match status_nibble {
            0 => Kind::PerNoteController, 1 => Kind::AssignablePerNoteController, 2 => Kind::RegisteredController,
            3 => Kind::AssignableController, 4 => Kind::RelativeRegisteredController, 5 => Kind::RelativeAssignableController,
            6 => Kind::PerNoteBend, 8 => Kind::NoteOff, 9 => Kind::NoteOn, 10 => Kind::PerNotePressure, 11 => Kind::Control,
            12 => Kind::Program, 13 => Kind::ChannelPressure, 14 => Kind::ChannelBend, 15 => Kind::PerNoteManagement,
            _ => Kind::Unknown,
        }
    }
    pub fn name(self) -> &'static str {
        match self {
            Kind::PerNoteController => "perNoteController", Kind::AssignablePerNoteController => "assignablePerNoteController",
            Kind::RegisteredController => "registeredController", Kind::AssignableController => "assignableController",
            Kind::RelativeRegisteredController => "relativeRegisteredController", Kind::RelativeAssignableController => "relativeAssignableController",
            Kind::PerNoteBend => "perNoteBend", Kind::NoteOff => "noteOff", Kind::NoteOn => "noteOn", Kind::PerNotePressure => "perNotePressure",
            Kind::Control => "control", Kind::Program => "program", Kind::ChannelPressure => "channelPressure", Kind::ChannelBend => "channelBend",
            Kind::PerNoteManagement => "perNoteManagement", Kind::Unknown => "unknown",
        }
    }
}

// ---- Min-Center-Max upscaling (Appendix D.1.3) -----------------------------------------------------------------------
/// `value` of `from` bits to `to` bits: shifted up to the centre, the bits below the top repeated above it, so the
/// lowest, the centre and the highest values stay so (scaleUp, as the specification writes it).
pub fn scale_up(value: u32, from: u32, to: u32) -> u32 {
    let shift = to - from;
    let (centre, shifted) = (1u32 << (from - 1), value << shift);
    if value <= centre { return shifted; }
    let repeat_bits = from - 1;
    let mut repeat = value & ((1u32 << repeat_bits) - 1);
    if shift > repeat_bits { repeat <<= shift - repeat_bits; } else { repeat >>= repeat_bits - shift; }
    let mut out = shifted;
    while repeat != 0 { out |= repeat; repeat >>= repeat_bits; }
    out
}

// ---- The MIDI 2.0 Channel Voice messages this crate writes (§7.4) ----------------------------------------------------
fn cv(group: u32, status: u32, channel: u32, byte2: u32, byte3: u32) -> u32 {
    0x4000_0000 | (group & 15) << 24 | (status & 15) << 20 | (channel & 15) << 16 | (byte2 & 255) << 8 | (byte3 & 255)
}
pub fn note_on(group: u32, channel: u32, note: u32, velocity: u32) -> [u32; 2] { [cv(group, 9, channel, note, 0), velocity << 16] }
pub fn note_off(group: u32, channel: u32, note: u32, velocity: u32) -> [u32; 2] { [cv(group, 8, channel, note, 0), velocity << 16] }
pub fn poly_pressure(group: u32, channel: u32, note: u32, value: u32) -> [u32; 2] { [cv(group, 10, channel, note, 0), value] }
pub fn control(group: u32, channel: u32, index: u32, value: u32) -> [u32; 2] { [cv(group, 11, channel, index, 0), value] }
pub fn channel_pressure(group: u32, channel: u32, value: u32) -> [u32; 2] { [cv(group, 13, channel, 0, 0), value] }
pub fn channel_bend(group: u32, channel: u32, value: u32) -> [u32; 2] { [cv(group, 14, channel, 0, 0), value] }
/// A Program Change, its bank sent (option flag B) only where one was selected.
pub fn program(group: u32, channel: u32, program: u32, bank: Option<[u32; 2]>) -> [u32; 2] {
    let [msb, lsb] = bank.unwrap_or([0, 0]);
    [cv(group, 12, channel, 0, bank.is_some() as u32), (program & 127) << 24 | (msb & 127) << 8 | (lsb & 127)]
}
/// A Registered (RPN) or an Assignable (NRPN) Controller: its bank (the MSB) and index (the LSB).
pub fn controller(group: u32, channel: u32, registered: bool, bank: u32, index: u32, value: u32) -> [u32; 2] {
    [cv(group, if registered { 2 } else { 3 }, channel, bank & 127, index & 127), value]
}

// ---- A packet named as JZZ's listing named it (UMP.prototype._string, JZZ 1.9.6), for public/midi2-editor.html -----
const SYSTEM: &[(u8, &str)] = &[(241, "MIDI Time Code"), (242, "Song Position"), (243, "Song Select"), (244, "Undefined"), (245, "Undefined"),
    (246, "Tune request"), (248, "Timing clock"), (249, "Undefined"), (250, "Start"), (251, "Continue"), (252, "Stop"), (253, "Undefined"),
    (254, "Active Sensing"), (255, "Reset")];
const CONTROLLERS: &[(u8, &str)] = &[(0, "Bank Select MSB"), (1, "Modulation Wheel MSB"), (2, "Breath Controller MSB"), (4, "Foot Controller MSB"),
    (5, "Portamento Time MSB"), (6, "Data Entry MSB"), (7, "Channel Volume MSB"), (8, "Balance MSB"), (10, "Pan MSB"),
    (11, "Expression Controller MSB"), (12, "Effect Control 1 MSB"), (13, "Effect Control 2 MSB"), (16, "General Purpose Controller 1 MSB"),
    (17, "General Purpose Controller 2 MSB"), (18, "General Purpose Controller 3 MSB"), (19, "General Purpose Controller 4 MSB"), (31, "Karaoke"),
    (32, "Bank Select LSB"), (33, "Modulation Wheel LSB"), (34, "Breath Controller LSB"), (36, "Foot Controller LSB"), (37, "Portamento Time LSB"),
    (38, "Data Entry LSB"), (39, "Channel Volume LSB"), (40, "Balance LSB"), (42, "Pan LSB"), (43, "Expression Controller LSB"),
    (44, "Effect control 1 LSB"), (45, "Effect control 2 LSB"), (48, "General Purpose Controller 1 LSB"), (49, "General Purpose Controller 2 LSB"),
    (50, "General Purpose Controller 3 LSB"), (51, "General Purpose Controller 4 LSB"), (64, "Damper Pedal"), (65, "Portamento"), (66, "Sostenuto"),
    (67, "Soft Pedal"), (68, "Legato"), (69, "Hold 2"), (70, "Sound Variation"), (71, "Filter Resonance"), (72, "Release Time"), (73, "Attack Time"),
    (74, "Brightness"), (75, "Decay Time"), (76, "Vibrato Rate"), (77, "Vibrato Depth"), (78, "Vibrato Delay"), (79, "Sound Controller 10"),
    (80, "General Purpose Controller 5"), (81, "General Purpose Controller 6"), (82, "General Purpose Controller 7"),
    (83, "General Purpose Controller 8"), (84, "Portamento Control"), (88, "High Resolution Velocity Prefix"), (91, "Effects 1 Depth"),
    (92, "Effects 2 Depth"), (93, "Effects 3 Depth"), (94, "Effects 4 Depth"), (95, "Effects 5 Depth"), (96, "Data Increment"),
    (97, "Data Decrement"), (98, "Non-Registered Parameter Number LSB"), (99, "Non-Registered Parameter Number MSB"),
    (100, "Registered Parameter Number LSB"), (101, "Registered Parameter Number MSB"), (120, "All Sound Off"), (121, "Reset All Controllers"),
    (122, "Local Control On/Off"), (123, "All Notes Off"), (124, "Omni Mode Off"), (125, "Omni Mode On"), (126, "Mono Mode On"),
    (127, "Poly Mode On")];
fn named(table: &[(u8, &'static str)], key: u8) -> Option<&'static str> { table.iter().find(|(k, _)| *k == key).map(|(_, n)| *n) }
// JavaScript's Math.round (half up, toward +infinity), as JZZ's tempo in BPM.
fn js_round(x: f64) -> f64 { if x - x.floor() >= 0.5 { x.ceil() } else { x.floor() } }
fn js_number(x: f64) -> String { if x == 0.0 { "0".into() } else if x.fract() == 0.0 && x.abs() < 1e21 { format!("{}", x as i64) } else { format!("{}", x) } }

/// A MIDI 1.0 message's name (JZZ's MIDI.prototype._string, for its status and two data bytes), or none.
fn midi1_name(status: u8, data1: u8, data2: u8) -> Option<String> {
    if let Some(name) = named(SYSTEM, status) { return Some(name.into()); }
    match status >> 4 {
        8 => Some("Note Off".into()), 10 => Some("Aftertouch".into()), 12 => Some("Program Change".into()),
        13 => Some("Channel Aftertouch".into()), 14 => Some("Pitch Wheel".into()),
        9 => Some(if data2 != 0 { "Note On" } else { "Note Off" }.into()),
        11 => {
            let name = named(CONTROLLERS, data1).map(str::to_string);
            let name = match (name, (64..=69).contains(&data1)) {
                (Some(n), true) => format!("{}{}", n, if data2 < 64 { " Off" } else { " On" }),
                (Some(n), false) => n, (None, _) => "Undefined".into() };
            Some(name)
        }
        _ => None,
    }
}

/// A packet's name as JZZ's listing gave it -- "Note On", "Tempo 90 BPM", "Registered Controller: Pitch Bend
/// Sensitivity", "Start of Clip" -- or none where JZZ gave none (its words alone are listed). A time signature not
/// addressed to its Group, which JZZ's listing threw on, is named as any other.
pub fn describe(packet: &[u32]) -> Option<String> {
    let b: Vec<u8> = packet.iter().flat_map(|w| w.to_be_bytes()).collect();
    let byte = |i: usize| b.get(i).copied().unwrap_or(0);
    let name: Option<String> = match byte(0) >> 4 {
        1 | 2 => midi1_name(byte(1), byte(2), byte(3)),
        0 => ["NOOP", "JR Clock", "JR Timestamp", "Ticks Per Quarter Note", "Delta Ticks"].get((byte(1) >> 4) as usize).map(|s| s.to_string()),
        3 => Some("SysEx".into()),
        5 => Some("Data".into()),
        4 => {
            let status = byte(1) >> 4;
            let base = ["Registered Per-Note Controller", "Assignable Per-Note Controller", "Registered Controller", "Assignable Controller",
                "Relative Registered Controller", "Relative Assignable Controller", "Per-Note Pitch Bend", "", "Note Off", "Note On",
                "Poly Pressure", "Control Change", "Program Change", "Channel Pressure", "Pitch Bend", "Per-Note Management"][status as usize];
            match status {
                7 => None,
                11 if byte(2) == 84 => Some("Portamento".into()),
                2 => {
                    let rpn = match (byte(2), byte(3)) { (0, 0) => Some("Pitch Bend Sensitivity"), (0, 1) => Some("Fine Tuning"),
                        (0, 2) => Some("Coarse Tuning"), (0, 3) => Some("Select Tuning Program"), (0, 4) => Some("Select Tuning Bank"),
                        (0, 5) => Some("Vibrato Depth Range"), (0x7f, 0x7f) => Some("NONE"), _ => None };
                    Some(match rpn { Some(r) => format!("{}: {}", base, r), None => base.into() })
                }
                _ => Some(base.into()),
            }
        }
        13 => match (byte(2), byte(3)) {
            (0, 0) => {
                // (JZZ's tempo: its four bytes as JavaScript's << makes them, read only where sent whole to the Group.)
                let whole = byte(1) >> 4 == 1;
                let tempo = ((byte(4) as i32) << 24) as f64 + ((byte(5) as u32) << 16 | (byte(6) as u32) << 8 | byte(7) as u32) as f64;
                Some(if whole && tempo != 0.0 { format!("Tempo {} BPM", js_number(js_round(6e9 / tempo))) } else { "Tempo undefined BPM".into() })
            }
            (0, 1) => Some(format!("Time Signature {}/{}", byte(4), 1i32.wrapping_shl(byte(5) as u32))),
            (0, 2) => Some("Metronome".into()), (0, 5) => Some("Key Signature".into()), (0, 6) => Some("Chord Name".into()),
            (1, status) => Some(["Metadata", "Project Name", "Composition Name", "Clip Name", "Copyright", "Composer Name", "Lyricist Name",
                "Arranger Name", "Publisher Name", "Primary Performer Name", "Accompanying Performer Name", "Recording Date",
                "Recording Location"].get(status as usize).copied().unwrap_or("Unknown Text").into()),
            (2, status) => Some(["Text", "Lyrics", "Lyrics Language", "Ruby", "Ruby Language"].get(status as usize).copied().unwrap_or("Unknown Text").into()),
            _ => None,
        },
        15 => match byte(1) { 32 => Some("Start of Clip".into()), 33 => Some("End of Clip".into()), _ => None },
        _ => None,
    };
    name.filter(|n| !n.is_empty())
}
/// A packet as JZZ's listing wrote it: its words in hex, then its name after " -- " where it has one.
pub fn listed(packet: &[u32]) -> String {
    let words = packet.iter().map(|w| format!("{:08x}", w)).collect::<Vec<_>>().join(" ");
    match describe(packet) { Some(name) => format!("{} -- {}", words, name), None => words }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn the_specifications_examples_scale() {
        // Appendix D.1.3's numerical examples, and its 7-to-16 shortcut over every value.
        assert_eq!([10, 64, 87, 127].map(|v| scale_up(v, 7, 16)), [0x1400, 0x8000, 0xaeba, 0xffff]);
        for v in 0..128u32 { let low = v & 63; assert_eq!(scale_up(v, 7, 16), v << 9 | if v > 64 { low << 3 | low >> 3 } else { 0 }); }
        assert_eq!(scale_up(1, 7, 16), 0x0200);
        assert_eq!(scale_up(0x2000, 14, 32), 0x8000_0000);
        assert_eq!(scale_up(0x3fff, 14, 32), 0xffff_ffff);
        assert_eq!(scale_up(127, 7, 32), 0xffff_ffff);
    }

    #[test]
    fn packets_are_named_as_jzz_named_them() {
        assert_eq!(listed(&[0xd010_0000, 0x03f9_40ab, 0, 0]), "d0100000 03f940ab 00000000 00000000 -- Tempo 90 BPM");
        assert_eq!(listed(&[0xd010_0001, 0x0703_1c00, 0, 0]), "d0100001 07031c00 00000000 00000000 -- Time Signature 7/8");
        assert_eq!(listed(&[0x4090_3c03, 0x9c40_7800]), "40903c03 9c407800 -- Note On");
        assert_eq!(listed(&[0x4020_0007, 0x0600_0000]), "40200007 06000000 -- Registered Controller");
        assert_eq!(listed(&[0x4020_0000, 0x0600_0000]), "40200000 06000000 -- Registered Controller: Pitch Bend Sensitivity");
        assert_eq!(listed(&[0x2090_3c00]), "20903c00 -- Note Off");
        assert_eq!(listed(&[0x20b0_4040]), "20b04040 -- Damper Pedal On");
        assert_eq!(listed(&[0x10f8_0000]), "10f80000 -- Timing clock");
        assert_eq!(listed(&[0x4070_0000, 0]), "40700000 00000000");
        assert_eq!(listed(&[0xd000_0201, 0x6c61_0000, 0, 0]), "d0000201 6c610000 00000000 00000000 -- Lyrics");
        assert_eq!(listed(&[0xd000_0000, 0x0007_a120, 0, 0]), "d0000000 0007a120 00000000 00000000 -- Tempo undefined BPM");
        assert_eq!(listed(&START_OF_CLIP), "f0200000 00000000 00000000 00000000 -- Start of Clip");
    }
}
