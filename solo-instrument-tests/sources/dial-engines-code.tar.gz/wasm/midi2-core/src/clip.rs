//! MIDI Clip Files (M2-116-U v1.0, 11 May 2023; research-downloads/midi2/): read from any writer's bytes and written as
//! public/shared/midi-files.js wrote them through JZZ, byte for byte (ported 13 November 2026).
//!
//! A file is "SMF2CLIP", its Clip Configuration Header (any Set Profile On messages with no Delta Clockstamp, then the
//! DCTPQ, then messages to set a receiver up, each after a Delta Clockstamp) and its Clip Sequence Data (Start of Clip,
//! the music, End of Clip, each after one). A message's time is the sum of the Delta Clockstamps before it (§3.2.2); the
//! header has its own timeline, whose length is its Delta Clockstamps' sum through the one before Start of Clip (§6.1),
//! and the sequence's runs from Start of Clip.
//!
//! Read: what a writer may do that the specification does not ask for is read and said (`warnings`) -- a message with no
//! Delta Clockstamp of its own (simultaneous events sharing one, as some writers do), two Delta Clockstamps in a row
//! (their ticks summed), messages after End of Clip, a series (SysEx, Flex Data) left open, a second DCTPQ (the clip's
//! times rescaled to one timebase that holds both exactly). What cannot be read without guessing -- a file cut inside a
//! packet, no DCTPQ or a DCTPQ of 0, no Start or no End of Clip, a second Start or End -- is refused, as the JavaScript
//! refused it ("Invalid MIDI Clip"). Every packet is kept, a reserved message type at its own length.

use crate::ump;
use crate::JsError;

pub const SIGNATURE: &[u8; 8] = b"SMF2CLIP";

/// A clip as read: its packets with their ticks, its timebase, the header's length and the clip's end.
#[derive(Clone, Debug, Default, PartialEq)]
pub struct Clip {
    pub ticks_per_quarter: u64,
    /// Messages before the DCTPQ, with no Delta Clockstamp (§6: Set Profile On), written back first as they came.
    pub preamble: Vec<Vec<u32>>,
    /// The Clip Configuration Header's other messages, at their ticks on its own timeline.
    pub header: Vec<(u64, Vec<u32>)>,
    /// The header's length: its Delta Clockstamps' sum through the one before Start of Clip.
    pub header_ticks: u64,
    /// The Clip Sequence Data's messages, Start and End of Clip and DCTPQs aside, at their ticks from Start of Clip.
    pub events: Vec<(u64, Vec<u32>)>,
    /// End of Clip's tick (with any Delta Clockstamps after it).
    pub end: u64,
    pub warnings: Vec<String>,
}

fn gcd(a: u64, b: u64) -> u64 { if b == 0 { a } else { gcd(b, a % b) } }

/// A clip from a file's bytes, or why it cannot be read.
pub fn read(bytes: &[u8]) -> Result<Clip, JsError> { read_as(bytes, false) }

/// A clip from a file's bytes, repaired where it cannot be read as it stands, as JZZ's Clip repaired it for the MIDI
/// 2.0 editor (public/midi2-editor.html): what `read` refuses is said in `warnings` in the same words, and the clip read
/// as far as it goes -- a packet cut off left out, a DCTPQ missing or of 0 read as 96 ticks a quarter, a second Start or
/// End of Clip and an End of Clip in the header passed over, a missing End of Clip at the last tick. A clip with no Start
/// of Clip has its messages after the DCTPQ as its sequence (JZZ left it empty). Only a timebase no 32 bits can hold is
/// still refused.
pub fn read_repairing(bytes: &[u8]) -> Result<Clip, JsError> { read_as(bytes, true) }

fn read_as(bytes: &[u8], repair: bool) -> Result<Clip, JsError> {
    let mut clip = Clip::default();
    let mut refusals: Vec<String> = Vec::new();
    let start = match bytes.windows(8).position(|w| w == SIGNATURE) {
        Some(0) => 8,
        Some(at) => { clip.warnings.push(format!("Extra leading characters: {} bytes before SMF2CLIP", at)); at + 8 }
        None => return Err(JsError::error("Invalid MIDI Clip: no SMF2CLIP file header")),
    };
    // The packets, each at its byte offset.
    let mut packets: Vec<(usize, Vec<u32>)> = Vec::new();
    let mut at = start;
    while at < bytes.len() {
        let length = ump::WORD_COUNTS[(bytes[at] >> 4) as usize] * 4;
        if at + length > bytes.len() {
            refusals.push(format!("Incomplete message at byte {}: {} of its {} bytes", at, bytes.len() - at, length));
            break;
        }
        packets.push((at, bytes[at..at + length].chunks(4).map(|b| u32::from_be_bytes([b[0], b[1], b[2], b[3]])).collect()));
        at += length;
    }
    // One timebase for every DCTPQ the file declares: their least common multiple, so every tick stays whole.
    let declared: Vec<u64> = packets.iter().filter(|(_, p)| ump::is_ticks_per_quarter(p[0])).map(|(_, p)| ump::ticks_per_quarter(p[0]) as u64).collect();
    if declared.iter().any(|&tpq| tpq == 0) { refusals.push("Bad Ticks PQN value: 0".into()); }
    let timebase = declared.iter().filter(|&&tpq| tpq > 0).fold(1u64, |l, &tpq| l / gcd(l, tpq) * tpq);
    let timebase = if repair && !declared.iter().any(|&tpq| tpq > 0) { 96 } else { timebase };
    if timebase > u32::MAX as u64 { return Err(JsError::error(format!("Invalid MIDI Clip: its Ticks PQN values {:?} have no common timebase below 2^32", declared))); }
    if declared.len() > 1 {
        clip.warnings.push("Multiple Ticks PQN message".into());
        if declared.iter().any(|&tpq| tpq != declared[0]) {
            clip.warnings.push(format!("its timebase changes ({:?} ticks a quarter): every time read at {} ticks a quarter", declared, timebase));
        }
    }
    let (mut tpq, mut scale) = (0u64, 1u64);
    let (mut in_header, mut ended, mut previous_delta, mut any) = (true, false, false, false);
    let mut tick = 0u64;
    for (offset, packet) in packets {
        let first = packet[0];
        if ump::is_delta(first) {
            if previous_delta { clip.warnings.push(format!("Consequential Delta Ticks message at byte {}", offset)); }
            tick += ump::delta_ticks(first) as u64 * scale;
            previous_delta = true;
            continue;
        }
        // (Before the DCTPQ, a message has no Delta Clockstamp of its own: §6.)
        if any && !previous_delta && tpq > 0 { clip.warnings.push(format!("Missing Delta Ticks message at byte {}", offset)); }
        previous_delta = false;
        any = true;
        if ump::is_ticks_per_quarter(first) {
            let value = ump::ticks_per_quarter(first) as u64;
            if value > 0 { tpq = value; scale = timebase / value; }
            if !in_header { clip.warnings.push(format!("a DCTPQ in the Clip Sequence Data at byte {}", offset)); }
            continue;
        }
        if in_header {
            if ump::is_start_of_clip(first) { clip.header_ticks = tick; tick = 0; in_header = false; }
            else if ump::is_end_of_clip(first) { refusals.push("Unexpected End of Clip message".into()); }
            else if tpq == 0 && clip.header.is_empty() { clip.preamble.push(packet); }
            else { clip.header.push((tick, packet)); }
        } else if ump::is_start_of_clip(first) {
            refusals.push("Repeated Start of Clip message".into());
        } else if ump::is_end_of_clip(first) {
            if ended { refusals.push("Repeated End of Clip message".into()); }
            ended = true;
        } else {
            if ended { clip.warnings.push(format!("a message after End of Clip at byte {}", offset)); }
            clip.events.push((tick, packet));
        }
    }
    clip.end = tick;
    if declared.is_empty() { refusals.push("Missing Ticks PQN message".into()); }
    if in_header { refusals.push("No Start of Clip message".into()); } else if !ended { refusals.push("No End of Clip message".into()); }
    if !refusals.is_empty() && !repair { return Err(JsError::error(format!("Invalid MIDI Clip: {}", refusals.join("; ")))); }
    if repair {
        if in_header { clip.events = std::mem::take(&mut clip.header); }
        clip.warnings.extend(refusals);
    }
    clip.ticks_per_quarter = timebase;
    series(&clip.events, &mut clip.warnings);
    Ok(clip)
}

/// A clip listed as JZZ's Clip listed one (its toString), for the MIDI 2.0 editor: "SMF2CLIP", its header (the DCTPQ,
/// then each message at its tick), its data (Start of Clip, each event at its tick, End of Clip at the clip's end), a
/// message a line: its words in hex and its name (ump.rs listed).
pub fn listing(c: &Clip) -> String {
    let mut lines = vec!["SMF2CLIP".to_string(), "Header".to_string(), format!("  0: {}", ump::listed(&[ump::ticks_per_quarter_message(c.ticks_per_quarter as u32)]))];
    lines.extend(c.preamble.iter().map(|p| format!("  0: {}", ump::listed(p))));
    lines.extend(c.header.iter().map(|(t, p)| format!("  {}: {}", t, ump::listed(p))));
    lines.push("Data".into());
    lines.push(format!("  0: {}", ump::listed(&ump::START_OF_CLIP)));
    lines.extend(c.events.iter().map(|(t, p)| format!("  {}: {}", t, ump::listed(p))));
    lines.push(format!("  {}: {}", c.end, ump::listed(&ump::END_OF_CLIP)));
    lines.join("\n")
}

// A series of packets that make one message -- a SysEx (7-bit or 8-bit) or a Flex Data text -- begun and not ended, or
// continued and never begun (JZZ's validation of a clip's series, its words).
fn series(events: &[(u64, Vec<u32>)], warnings: &mut Vec<String>) {
    let mut open: Vec<(u32, u64)> = Vec::new();
    for (tick, packet) in events {
        let w = packet[0];
        let (key, step) = match w >> 28 {
            0xD => (0xD00 | (w >> 24 & 15) | (w >> 16 & 0x3F) << 4, w >> 22 & 3),
            // (A Mixed Data Set's header and payloads, statuses 8 and 9, are no SysEx8 series.)
            0x5 if w >> 20 & 15 <= 3 => (0x500 | (w >> 24 & 15), w >> 20 & 3),
            0x3 => (0x300 | (w >> 24 & 15), w >> 20 & 3),
            _ => continue,
        };
        let begun = open.iter().position(|&(k, _)| k == key);
        match (begun, step) {
            (Some(i), 0 | 1) => { warnings.push(format!("Missing series end (the series begun at tick {})", open[i].1)); open.remove(i); }
            (None, 2 | 3) => warnings.push(format!("Missing series start at tick {}", tick)),
            _ => {}
        }
        if let Some(i) = open.iter().position(|&(k, _)| k == key) { open.remove(i); }
        if step == 1 || step == 2 { open.push((key, *tick)); }
    }
    for (_, tick) in open { warnings.push(format!("Missing series end (the series begun at tick {})", tick)); }
}

/// What to write: a timebase, the messages before the DCTPQ, the header's and the sequence's messages at their ticks,
/// the header's length and the clip's end.
pub struct Writing<'a> {
    pub ticks_per_quarter: f64,
    pub preamble: Vec<&'a [u32]>,
    pub header: Vec<(f64, &'a [u32])>,
    pub header_ticks: f64,
    pub events: Vec<(f64, &'a [u32])>,
    pub end: f64,
}

fn integer_ticks(time: f64) -> Result<u64, JsError> {
    if time.fract() == 0.0 && time >= 0.0 && time <= 9_007_199_254_740_991.0 { Ok(time as u64) }
    else { Err(JsError::range("Clip timestamps must be integer ticks; rescale the timebase explicitly before export")) }
}
fn structural(packet: &[u32]) -> bool {
    let w = packet[0];
    ump::is_delta(w) || ump::is_ticks_per_quarter(w) || ump::is_start_of_clip(w) || ump::is_end_of_clip(w)
}
fn check(time: f64, packet: &[u32]) -> Result<u64, JsError> {
    let tick = integer_ticks(time)?;
    if structural(packet) { return Err(JsError::error("Clip structural messages belong in the timebase/header, not musical events")); }
    Ok(tick)
}

/// The file's bytes: the File Header, any preamble, a Delta Clockstamp of 0 and the DCTPQ, each header message after
/// its Delta Clockstamp, the rest of the header's length and Start of Clip, each event after its own Delta Clockstamp,
/// and End of Clip at the clip's end. A gap wider than a Delta Clockstamp holds (1,048,575 ticks) is crossed by NOOPs
/// (§3.2.2), and the header's messages are kept in time order, those at one time as they came (JZZ's Clip.add).
pub fn write(w: &Writing) -> Result<Vec<u8>, JsError> {
    let tpq = w.ticks_per_quarter;
    if !(tpq.fract() == 0.0 && (1.0..=65535.0).contains(&tpq)) { return Err(JsError::range("MIDI Clip ticks per quarter note must be 1..65535")); }
    let mut header = Vec::with_capacity(w.header.len());
    for &(time, packet) in &w.header { header.push((check(time, packet)?, packet)); }
    header.sort_by_key(|&(tick, _)| tick);
    let mut events = Vec::with_capacity(w.events.len());
    for &(time, packet) in &w.events { events.push((check(time, packet)?, packet)); }
    for packet in &w.preamble { if structural(packet) { return Err(JsError::error("Clip structural messages belong in the timebase/header, not musical events")); } }
    let end = if w.end.is_finite() && w.end > 0.0 { integer_ticks(w.end)? } else { 0 };
    let header_ticks = if w.header_ticks.is_finite() && w.header_ticks > 0.0 { integer_ticks(w.header_ticks)? } else { 0 };

    let mut out: Vec<u8> = Vec::with_capacity(16 + 12 * (header.len() + events.len()) + 64);
    out.extend_from_slice(SIGNATURE);
    let put = |out: &mut Vec<u8>, words: &[u32]| for word in words { out.extend_from_slice(&word.to_be_bytes()); };
    // A Delta Clockstamp from `from` to `to`, NOOPs carrying the count across a gap too wide for one.
    let advance = |out: &mut Vec<u8>, from: u64, to: u64| {
        let mut at = from;
        while to - at > ump::MAX_DELTA as u64 { put(out, &[ump::delta(ump::MAX_DELTA), ump::NOOP]); at += ump::MAX_DELTA as u64; }
        put(out, &[ump::delta((to - at) as u32)]);
    };
    for packet in &w.preamble { put(&mut out, packet); }
    put(&mut out, &[ump::delta(0), ump::ticks_per_quarter_message(tpq as u32)]);
    let mut tick = 0u64;
    for (at, packet) in &header { advance(&mut out, tick, *at); put(&mut out, packet); tick = *at; }
    advance(&mut out, tick, header_ticks.max(tick));
    put(&mut out, &ump::START_OF_CLIP);
    tick = 0;
    for (at, packet) in &events { advance(&mut out, tick, *at); put(&mut out, packet); tick = *at; }
    advance(&mut out, tick, end.max(tick));
    put(&mut out, &ump::END_OF_CLIP);
    Ok(out)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn a_damaged_clip_is_repaired_where_asked_and_listed_as_jzz_listed() {
        // No End of Clip, and a Start of Clip twice: refused as it stands, read repaired with both said.
        let mut bytes = SIGNATURE.to_vec();
        for w in [ump::delta(0), ump::ticks_per_quarter_message(96), ump::delta(0), ump::START_OF_CLIP[0], 0, 0, 0, ump::delta(0), ump::START_OF_CLIP[0], 0, 0, 0,
                  ump::delta(10), 0x4090_3c03, 0x9c40_7800] { bytes.extend(w.to_be_bytes()); }
        assert!(read(&bytes).unwrap_err().message.starts_with("Invalid MIDI Clip: Repeated Start of Clip message; No End of Clip message"));
        let c = read_repairing(&bytes).unwrap();
        assert_eq!((c.events.len(), c.end), (1, 10));
        assert!(c.warnings.iter().any(|w| w == "No End of Clip message"));
        assert_eq!(listing(&c), "SMF2CLIP\nHeader\n  0: 00300060 -- Ticks Per Quarter Note\nData\n  0: f0200000 00000000 00000000 00000000 -- Start of Clip\n  10: 40903c03 9c407800 -- Note On\n  10: f0210000 00000000 00000000 00000000 -- End of Clip");
        // No DCTPQ and no Start of Clip: 96 ticks a quarter, the messages its sequence.
        let mut bare = SIGNATURE.to_vec();
        for w in [ump::delta(0), ump::START_OF_CLIP[0], 0, 0, 0] { bare.extend(w.to_be_bytes()); }
        let mut lost = SIGNATURE.to_vec();
        for w in [ump::delta(0), ump::ticks_per_quarter_message(480), ump::delta(5), 0x4090_3c03, 0x9c40_7800] { lost.extend(w.to_be_bytes()); }
        assert_eq!(read_repairing(&bare).unwrap().ticks_per_quarter, 96);
        let l = read_repairing(&lost).unwrap();
        assert_eq!((l.events.len(), l.events[0].0, l.header.len()), (1, 5, 0));
    }
    fn file(words: &[u32]) -> Vec<u8> { let mut b = SIGNATURE.to_vec(); for w in words { b.extend_from_slice(&w.to_be_bytes()); } b }
    #[test]
    fn a_minimal_clip_reads_and_writes_back() {
        let words = [0x00400000, 0x00300060, 0x00400000, 0xF0200000, 0, 0, 0, 0x00400000, 0x40903c00, 0xc0000000,
            0x00400060, 0x40803c00, 0, 0x00400000, 0xF0210000, 0, 0, 0];
        let clip = read(&file(&words)).unwrap();
        assert_eq!(clip.ticks_per_quarter, 96);
        assert_eq!(clip.events.iter().map(|(t, _)| *t).collect::<Vec<_>>(), [0, 96]);
        assert_eq!(clip.end, 96);
        assert!(clip.warnings.is_empty());
        let w = Writing { ticks_per_quarter: 96.0, preamble: vec![], header: vec![], header_ticks: 0.0,
            events: clip.events.iter().map(|(t, p)| (*t as f64, &p[..])).collect(), end: 96.0 };
        assert_eq!(write(&w).unwrap(), file(&words));
    }
    #[test]
    fn profiles_before_the_dctpq_and_shared_clockstamps_are_read() {
        // A Set Profile On (two SysEx7 packets, no Delta Clockstamp), the DCTPQ, a tempo in the header 10 ticks in, the
        // header 20 ticks long, and a chord whose second note shares the first's Delta Clockstamp.
        let words = [0x30167E7F, 0x0D220100, 0x30340000, 0x00000000, 0x00400000, 0x003001E0, 0x0040000A, 0xD0100000, 50_000_000, 0, 0,
            0x0040000A, 0xF0200000, 0, 0, 0, 0x00400000, 0x40903c00, 0x80000000, 0x40904000, 0x80000000,
            0x004001E0, 0xF0210000, 0, 0, 0];
        let clip = read(&file(&words)).unwrap();
        assert_eq!(clip.preamble.len(), 2);
        assert_eq!(clip.header, vec![(10, vec![0xD0100000, 50_000_000, 0, 0])]);
        assert_eq!(clip.header_ticks, 20);
        assert_eq!(clip.events.len(), 2);
        assert_eq!(clip.end, 480);
        assert_eq!(clip.warnings.len(), 1, "{:?}", clip.warnings);
    }
    #[test]
    fn a_second_timebase_is_read_exactly() {
        let words = [0x00400000, 0x00300060, 0x00400000, 0xF0200000, 0, 0, 0, 0x00400060, 0x40903c00, 0, 0x00400000, 0x003001E0,
            0x004001E0, 0x40803c00, 0, 0x00400000, 0xF0210000, 0, 0, 0];
        let clip = read(&file(&words)).unwrap();
        assert_eq!(clip.ticks_per_quarter, 480);
        assert_eq!(clip.events.iter().map(|(t, _)| *t).collect::<Vec<_>>(), [480, 960]);
    }
    #[test]
    fn what_cannot_be_read_is_refused() {
        let good = [0x00400000, 0x00300060, 0x00400000, 0xF0200000, 0, 0, 0, 0x00400000, 0xF0210000, 0, 0, 0];
        assert!(read(&file(&good)).is_ok());
        let cut = file(&good); assert!(read(&cut[..cut.len() - 5]).unwrap_err().message.contains("Incomplete"));
        assert!(read(&file(&good[..7])).unwrap_err().message.contains("No End of Clip"));
        assert!(read(&file(&good[2..])).unwrap_err().message.contains("Missing Ticks PQN"));
    }
    #[test]
    fn a_long_silence_is_crossed_by_noops() {
        let note = [0x40903c00u32, 0x80000000];
        let w = Writing { ticks_per_quarter: 9600.0, preamble: vec![], header: vec![], header_ticks: 0.0, events: vec![(2_500_000.0, &note[..])], end: 2_600_000.0 };
        let clip = read(&write(&w).unwrap()).unwrap();
        assert_eq!(clip.events.last().unwrap().0, 2_500_000);
        assert_eq!(clip.end, 2_600_000);
        assert!(clip.warnings.is_empty());
    }
}
