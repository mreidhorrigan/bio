// The audio engine's performed events to external physical controls. These seconds
// never become written beats: symbolic time remains in the original render logs.
import {followsPitch,breathesVibrato,realizes} from './src/physical.mjs';
import {curveAt} from './src/pitch.mjs';
import {BREATH} from './src/breath.mjs';
import {VIBRATO_SHARE} from './src/openwind-passages.mjs';
const finite=(n,name)=>{if(!Number.isFinite(n))throw new TypeError(`${name} must be finite`);return n};
const clone=value=>structuredClone(value);

// AudioParam-style ramps, including a later command interrupting an earlier ramp.
// Repeated time points represent steps; physical engines receive a one-sample ramp
// at the discontinuity, with the conversion recorded in the diagnostics.
export function controlCurve(commands,start,end,initial,{sampleRate=48000,scale=1}={}){
  const points=[{seconds:start,value:initial}];
  const at=t=>{
    for(let i=1;i<points.length;i++)if(t<points[i].seconds){const a=points[i-1],b=points[i];return a.value+(b.value-a.value)*(t-a.seconds)/(b.seconds-a.seconds)}
    return points.at(-1).value;
  };
  for(const c of commands.map((c,i)=>({...c,i})).sort((a,b)=>a.atSeconds-b.atSeconds||a.i-b.i)){
    const t=Math.max(start,finite(c.atSeconds,'control time'));if(t>end)continue;
    const held=at(t),value=finite(c.value,'control value')*scale,ramp=Math.max(0,c.ramp??0);
    while(points.length&&points.at(-1).seconds>=t)points.pop();
    points.push({seconds:t,value:held});
    if(ramp===0&&t===start)points[points.length-1].value=value;
    else points.push({seconds:t+Math.max(1/sampleRate,ramp),value});
  }
  const last=at(end);while(points.length&&points.at(-1).seconds>=end)points.pop();points.push({seconds:end,value:last});
  return points;
}

// The cents a note's piecewise-linear pitch curve holds between start and end, for a model that sounds one pitch a
// note: where it holds still -- a scoop or a glide into the note arrived, a bend held, a microtone held throughout -- the
// median over the time it holds still; where it never holds still, the note's own pitch. A scoop or a glide decays into
// the note, a vibrato and a player's drift sway about it (shared/expression.js performanceTimeline), so a curve still on
// its way, or swaying, holds no pitch of its own. (Where it ended had held a short note gliding in from a fifth above 40
// cents sharp, its glide still on its way; its median over the note, a slurred A4 15.6 cents sharp, its glide in from E5
// and its vibrato's first half-cycle summed -- the winds stream's clarinet, off its rules' table, 31 October 2026. Its
// median alone before had held a woodwind's 0.14 to 0.16 s scooped notes 1.4 to 1.9 cents flat.) A pitch is heard over
// its periods: a hold shorter than one of the note's (`period`, s) sounds none of its own -- a vibrato's last ramp, its
// times on the capture's ticks, ended 3 to 49 microseconds before its note's own end, and held there, had held the winds
// MIDI 2.0 test's notes at its last value, 1.5 to 8.9 cents off.
export function heldCents(curve,start,end,{period=0}={}){
  const points=[{seconds:start,cents:curveAt(curve,start)},...curve.filter(p=>p.seconds>start&&p.seconds<end),{seconds:end,cents:curveAt(curve,end)}];
  const still=points.slice(1).flatMap((p,k)=>p.seconds-points[k].seconds>=period&&p.cents===points[k].cents?[[p.cents,p.seconds-points[k].seconds]]:[]).sort((a,b)=>a[0]-b[0]);
  let half=still.reduce((sum,[,seconds])=>sum+seconds,0)/2;
  for(const [k,[cents,seconds]] of still.entries()){half-=seconds;if(half<-1e-9)return cents;if(half<=1e-9)return (cents+(still[k+1]?.[0]??cents))/2}
  return 0;
}

// A note's pitch curve as its breath sways it, on a woodwind whose vibrato is its breath's (openwind-passages.mjs
// VIBRATO_SHARE; the dial's swell, dial-midi2.mjs): [{seconds, cents}] about the pitch it holds (`held`: heldCents's), but
// for its arrival -- from its start to where it first reaches that pitch -- held there where its fingers make it, not its
// breath: a slurred note's glide in from the note before (its fingers' change, the slur), or an arrival from further than
// its breath bends it (`reach`, cents: the breath's swell, BREATH.swell of itself, a cent's VIBRATO_SHARE -- a glissando's
// slide). (Breathed, a slur's glide in had moved its breath by its interval: the website's clarinet's breath held at the
// dial's most through a slur up a fourth and at none through the slur back, its tone stopped -- 5 November 2026.)
export const BREATHED_REACH=BREATH.swell/VIBRATO_SHARE;
export function breathedCents(curve,start,end,{held=heldCents(curve,start,end),slurred=false,reach=BREATHED_REACH}={}){
  const points=[{seconds:start,cents:curveAt(curve,start)},...curve.filter(p=>p.seconds>start&&p.seconds<end),{seconds:end,cents:curveAt(curve,end)}]
    .map(p=>({seconds:p.seconds,cents:p.cents-held}));
  const first=points[0].cents;
  if(!first||!(slurred||Math.abs(first)>reach))return points;
  const k=points.findIndex(p=>Math.sign(p.cents)!==Math.sign(first));
  if(k<0)return [{seconds:start,cents:0},{seconds:end,cents:0}];
  const a=points[k-1],b=points[k],at=a.seconds+(b.seconds-a.seconds)*a.cents/(a.cents-b.cents);
  return [{seconds:start,cents:0},...at>start?[{seconds:at,cents:0}]:[],...points.slice(k).filter(p=>p.seconds>at)];
}

export function compilePhysicalEvents(events,{id,physical,sampleRate=48000}={}){
  const attacks=new Map,updates=new Map,losses=[];
  for(const event of events){
    if(!event.action){
      if(event.drum)throw new Error(`${id}: drum events require a percussion-specific physical adapter`);
      if(attacks.has(event.identity))throw new Error(`${id}: reused physical voice identity ${event.identity}`);
      if(!(event.frequency>0&&event.duration>0))throw new Error(`${id}: invalid physical note`);
      attacks.set(event.identity,clone(event));
    }else{if(!updates.has(event.identity))updates.set(event.identity,[]);updates.get(event.identity).push(clone(event))}
  }
  const notes=[];
  for(const [identity,event] of attacks){
    const start=finite(event.atSeconds,'note time');let end=start+event.duration;
    const controls=[...(event.controls??[]).map(c=>({...c,atSeconds:start+c.seconds})),...(updates.get(identity)??[])];
    for(const c of controls)if(c.action===4)end=Math.min(end,Math.max(start,c.atSeconds));
    if(end-start<1/sampleRate)continue;
    let pitchCurve=controlCurve(controls.filter(c=>c.action===1),start,end,0,{sampleRate,scale:100}).map(p=>({seconds:p.seconds,cents:p.value})),baseHz=event.frequency;
    if(pitchCurve.every(p=>p.cents===0))pitchCurve=[];
    // A model of one pitch a note (FIXED_PITCH) sounds it at the pitch the curve settles at (heldCents), so a
    // synthesizer's scoop into the attack or a vibrato leaves it where it settles. What it could not
    // follow is reported, never silently dropped.
    // (A woodwind's curve kept as its breath's sway, about that pitch, its arrival its fingers' where they make it: its
    // vibrato is its breath's -- openwind-passages.mjs, breathedCents.)
    let breathVibrato=null;
    if(pitchCurve.length&&!followsPitch(physical.backend,physical.model)){
      const held=heldCents(pitchCurve,start,end,{period:1/event.frequency}),span=Math.max(...pitchCurve.map(p=>p.cents))-Math.min(...pitchCurve.map(p=>p.cents)),breathed=breathesVibrato(physical.backend,physical.model);
      const sway=breathed&&span>1e-9?breathedCents(pitchCurve,start,end,{held,slurred:event.slurred===true}).map(p=>({seconds:p.seconds,cents:+p.cents.toFixed(3)})):[];
      if(sway.some(p=>p.cents!==0))breathVibrato=sway;
      const fingered=sway.length>0&&Math.abs(pitchCurve[0].cents-held-sway[0].cents)>1e-3;
      baseHz=event.frequency*2**(held/1200);pitchCurve=[];
      if(span>1e-9)losses.push({identity,controls:[1],heldCents:held,spanCents:span,reason:breathed?`${physical.backend} ${physical.model} sounds one pitch a note: held where its curve holds still, ${held.toFixed(2)} cents, its ${span.toFixed(2)}-cent curve breathed as its vibrato${fingered?', its arrival its fingers\'':''}`:`${physical.backend} ${physical.model} sounds one pitch a note: held where its curve holds still, ${held.toFixed(2)} cents, its ${span.toFixed(2)}-cent curve not followed`});
    }
    // Pressure/brightness/timbre/pan describe the previous synthesizer's controls.
    // They have no calibrated physical interpretation yet and are retained as a
    // projection ledger rather than called breath, lip pressure or bow force.
    const unsupported=[...new Set(controls.filter(c=>![1,4].includes(c.action)).map(c=>c.action))];
    if(unsupported.length)losses.push({identity,controls:unsupported,reason:'no calibrated physical mapping; source controls retained in events.json'});
    // (Its player's extended technique, where the model realizes it; else reported, the note played ordinarily.)
    const asked=event.extended&&typeof event.extended==='object'?Object.keys(event.extended):[],kept=asked.filter(name=>realizes(physical.backend,physical.model,name));
    if(asked.length>kept.length)losses.push({identity,controls:[],techniques:asked.filter(name=>!kept.includes(name)),reason:`${physical.backend} ${physical.model} does not realize ${asked.filter(name=>!kept.includes(name)).join(', ')}: played ordinarily`});
    const technique=kept.length?Object.fromEntries(kept.map(name=>[name,clone(event.extended[name])])):null;
    const velocity=Math.max(0,Math.min(1,finite(event.musicalVelocity??event.performance?.velocity??event.velocity,'velocity')));
    // (Its loudness its velocity, which its player blows or bows it by: never a level its sound is brought to -- the owner,
    // 10 October 2026: "Gain is never per-note".)
    notes.push({id:`${id}-n${identity}`,baseHz,velocity,
      startSeconds:start,endSeconds:end,startFrame:Math.round(start*sampleRate),endFrame:Math.round(end*sampleRate),pitchCurve,...(breathVibrato?{breathVibrato}:{}),...(technique?{technique}:{}),
      // (Slurred to the note before, where its player says so: its breath goes on from that note's, never begun again --
      // legato-tongued there where its player says that too (portato: wind-seat.js), its tongue dipping it, breath.mjs.)
      ...(event.slurred===true?{slurred:true,...(event.portato===true?{portato:true}:{})}:{}),
      // (Its length as its player meant it, before any early release: its swell's, cut where it ends -- breath.mjs noteSwell.)
      source:{identity,frequency:event.frequency,duration:event.duration,performance:clone(event.performance??{})}});
  }
  if(physical.unsupportedControls==='error'&&losses.length)throw new Error(`${id}: physical backend cannot map control actions ${[...new Set(losses.flatMap(l=>l.controls))].join(', ')}`);
  return {id,kind:'instrument',renderer:physical.backend,physical:{model:physical.model,...physical.controls},gain:1,pan:0,
    notes:notes.sort((a,b)=>a.startSeconds-b.startSeconds||a.id.localeCompare(b.id)),phonemes:[],projectionLosses:losses};
}
