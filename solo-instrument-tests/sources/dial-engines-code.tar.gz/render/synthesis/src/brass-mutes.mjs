// A brass mute set in its instrument's bell, as its players' kit has it (geometry/brass-mutes.json: makers' dimensions
// where they give them, the rest within what mutes of its kind are made within, fitted to what was measured of mutes in
// their bells: tools/fit_mutes.py). A straight mute pushed in until its corks touch -- the deepest it goes with the ring
// between it and the bell, where that is narrowest, its corks' thickness each side -- the sound on through that ring,
// a circle of its area, to the bell's rim; its hollow a cavity opening into the bell at its tip. A cup mute the same,
// the sound then into its bowl past the rim and out through the ring between the bowl's rim and the bell. A harmon
// sealed where its cork meets the bell, the sound through its chamber and out of its front hole, or its stem's tube and
// little bell. A stopping hand closing the bell to a ring. One geometry for both engines: NESS's 1D bore takes the
// sound's path alone (a branch it cannot hold: its cavity left out, said so in ness.mjs), OpenWInD's the path and the
// cavity, a closed side branch whose chimney is the mute's hollow cone (tools/save_brass_body.py).
//   muteIn(bore, model, mute[, values]) -> {bore: [[x, diameter]] mm, cavity: {at, length, diameter, diameterOut} mm or
//   null, inside: mm of the mute within the bell}
import MUTES from '../geometry/brass-mutes.json' with {type:'json'};

export const BRASS_MUTES=MUTES.instruments;
// (A mute's dimensions, each its value -- or `values`' where given, as a fit tries them.)
export function muteOf(model,mute,values={}){
  const given=BRASS_MUTES[model]?.[mute];
  if(!given)throw new RangeError(`${model} has no ${mute} mute (${Object.keys(BRASS_MUTES[model]??{}).join(', ')||'none'})`);
  return Object.fromEntries(Object.entries(given).map(([k,v])=>[k,values[k]??(v&&typeof v==='object'&&'value' in v?v.value:v)]));
}

const diameterAt=(bore,x)=>{const k=bore.findIndex(([at])=>at>=x);if(k<=0)return bore[Math.max(0,k)][1];if(k<0)return bore.at(-1)[1];const [x0,d0]=bore[k-1],[x1,d1]=bore[k];return d0+(d1-d0)*(x-x0)/((x1-x0)||1)};
// (A ring between two diameters as the 1D bore takes it: the circle of its area.)
const ring=(outer,inner)=>Math.sqrt(Math.max(outer*outer-inner*inner,0));
// (A step in a bore drawn as two places STEP mm apart, as OpenWInD's meshes take a step (tools/fit_lips.py STEP_MM),
// and a ring sampled every SAMPLED mm or closer.)
const STEP=.01,SAMPLED=5;

export function muteIn(bore,model,mute,values={}){
  const m=muteOf(model,mute,values),end=bore.at(-1)[0];
  const sealedAt=width=>{const at=bore.findIndex(([,d])=>d>=width);if(at<1)throw new RangeError(`${model}'s bell is nowhere ${width} mm wide`);
    const [x0,d0]=bore[at-1],[x1,d1]=bore[at];return {at,x:x0+(x1-x0)*(width-d0)/(d1-d0)}};
  if(m.kind==='hand'){
    const {at,x}=sealedAt(m.cork),opening=2*Math.sqrt(m.cork*m.gap);
    return {bore:[...bore.slice(0,at),[x,m.cork],[x+STEP,opening],[end,opening]],cavity:null,inside:end-x};
  }
  if(m.kind==='harmon'){
    const {at,x}=sealedAt(m.cork),[chamber,deep]=m.chamber,[exit,neck]=m.exit;
    const steps=[[8,chamber],[deep,chamber],[8,exit],[neck,exit],...(m.bell?[[m.bell[1],m.bell[0]]]:[])];
    let along=x;
    return {bore:[...bore.slice(0,at),[x,m.cork],...steps.map(([length,diameter])=>[along+=length,diameter])],cavity:null,inside:end-x};
  }
  // (Its cone's outer diameter `s` mm from its tip; the narrowest ring along it, its tip at `tip`: mm each side.)
  const outer=s=>m.tip+(m.base-m.tip)*Math.min(Math.max(s,0),m.length)/m.length;
  const along=(from,to)=>[from,...bore.map(([x])=>x).filter(x=>x>from&&x<to),to];
  const clearance=tip=>Math.min(...along(tip,Math.min(end,tip+m.length)).map(x=>(diameterAt(bore,x)-outer(x-tip))/2));
  // (Drawn out, a widening bell's ring only widens: in from its rim until its corks touch.)
  if(!(clearance(end)>=m.gap))throw new RangeError(`${model}'s ${mute} mute's tip (${m.tip} mm) does not enter its bell`);
  let deeper=bore[0][0],out=end;
  for(let i=0;i<60;i++){const mid=(deeper+out)/2;if(clearance(mid)>=m.gap)out=mid;else deeper=mid}
  const tip=out,base=tip+m.length,k=bore.findIndex(([x])=>x>tip);
  const places=along(tip,end).flatMap((x,i,all)=>{if(!i)return [];const n=Math.max(1,Math.ceil((x-all[i-1])/SAMPLED));return Array.from({length:n},(_,j)=>all[i-1]+(x-all[i-1])*(j+1)/n)});
  const path=places.flatMap(x=>{const d=diameterAt(bore,x);
    if(x<=base)return [[x,ring(d,outer(x-tip))]];
    return x-STEP<=base?[]:[[x,d]];
  });
  // (Its base within the bell: the bell's whole width again after it.)
  const past=base<end?[[base,ring(diameterAt(bore,base),m.base)],[base+STEP,diameterAt(bore,base+STEP)]]:[];
  // (The bell whole where its hollow opens into it -- a side branch joins a bore of one width there -- the ring from its
  // next place on.)
  let main=[...bore.slice(0,k).filter(([x])=>x<tip),[tip,diameterAt(bore,tip)],...[...path,...past].filter(([x])=>x>tip+5*STEP).sort((a,b)=>a[0]-b[0])];
  if(m.kind==='cup'){
    // (Out of the bell into its bowl -- past the rim, round its cone -- and out by the ring its rim leaves.)
    const bowl=m.cup-2*m.wall,cone=outer(end-tip),exit=2*Math.sqrt(bowl*m.rimGap);
    main=[...main,[end+STEP,ring(bowl,cone)],[end+m.depth,ring(bowl,cone)],[end+m.depth+STEP,exit],[end+m.depth+m.overlap,exit]];
  }
  return {bore:main,cavity:{at:tip,length:m.length-m.wall,diameter:m.tip-2*m.wall,diameterOut:m.base-2*m.wall},inside:end-tip};
}
