// A wind player's body on the live dial (the owner, 8 November 2026: "We need the site to show what the range of
// parameters is that players can physically do. This will make sliders depend on each other in an implicit vector
// space. Moving one slider to an extreme should pull others, if necessary, to keep the whole within what a player's
// physiology allows"): what its controls reach together, each given where the others stand, and where the others
// follow one moved (dial.mjs, its player held within it). As measured:
//   - the pressure in its mouth no more than the most measured in a wind player's, a trumpeter's 25 kPa (Fletcher &
//     Tarnopolsky 1999: brass-breath.mjs MOST) -- a reed's or the lips' breath, a share of the pressure that shuts them,
//     the less as the lip or the reed's dials raise that pressure;
//   - a single reed's lip from none at all, its players' some 2 N for the note eased right off (Almeida, George, Smith &
//     Wolfe 2013, doi:10.1121/1.4816538), to pressing short of shutting its reed (reed-lip.js PRESSED_MOST); and its
//     reed's opening at rest and its damping the lip's, since players move them by nothing else (reed-lip.js
//     lippedRow): either one set, the lip found that gives it, and the other with it;
//   - notes repeated no faster than double tonguing's fastest, about 11.5 a second (Bertsch & Hoole 2014), each
//     stroke of the tongue within 0.7 of a repeated note's time, as the dial plays it.
// Nobody has measured a double reed's lip, nor a player's reach of the jet's or the lips' other dials: those free. How
// fast a breath may be drawn in for its size waits on its source (SOURCES_TO_FETCH.md).
import {MOST} from '../../render/synthesis/src/brass-breath.mjs';
import {PRESSED_MOST,lippedRow,shutting} from '../../public/shared/performers/reed-lip.js';

export const BODY=Object.freeze({mouth:MOST,lipOwn:2,repeat:11.5,strokeShare:.7});
// (A single reed's columns its lip moves, and a player by nothing else.)
export const LIP_HELD=Object.freeze(['zeta','qfactor']);

// A single reed's lip's reach, N from the note's own, on the note's row `rules` (its reed's columns `at`, its players'
// `lip`), within the dial's `span`: from none at all to short of shutting the reed -> [low, high].
export function lipReach(rules,at,lip,span){
  return [Math.max(span[0],-BODY.lipOwn),Math.max(span[0],Math.min(span[1],PRESSED_MOST*shutting(rules[at.closing_pressure],lip)))];
}

// (The lip's forces through its reach, and a column's value at each: `sized` the reed's scale, `damping` its lip's. The
// note's own lip among them, where pressing turns to easing: its damping at its most there.)
const STEPS=400;
function along(rules,at,sized,lip,damping,name,reach){
  const forces=Array.from({length:STEPS+1},(_,i)=>reach[0]+(reach[1]-reach[0])*i/STEPS);
  if(reach[0]<0&&reach[1]>0&&!forces.includes(0))forces.splice(forces.findIndex(f=>f>0),0,0);
  return {forces,values:forces.map(f=>lippedRow(rules,at,sized,lip,f,damping)[at[name]])};
}
// The values column `name` takes as the lip goes through its reach -> [least, most].
export function lipSpan(rules,at,sized,lip,damping,name,reach){
  const {values}=along(rules,at,sized,lip,damping,name,reach);
  return [Math.min(...values),Math.max(...values)];
}
// The lip's force within `reach` that gives column `name` the value `value` -- of the forces that give it, the nearest
// `from` -- or, where none within it does, the force giving the nearest value. (Between the two forces of the grid
// either side of it, halved HALVINGS times.)
const HALVINGS=40;
export function lipGiving(rules,at,sized,lip,damping,name,value,reach,from=0){
  const {forces,values}=along(rules,at,sized,lip,damping,name,reach),off=values.map(v=>Math.log(v/value));
  let found=null;
  for(let i=0;i<forces.length;i++){
    const crossed=off[i]===0?[forces[i],forces[i]]:i<forces.length-1&&off[i]*off[i+1]<0?[forces[i],forces[i+1]]:null;
    if(crossed&&(found==null||Math.abs((crossed[0]+crossed[1])/2-from)<Math.abs((found[0]+found[1])/2-from)))found=crossed;
  }
  if(!found)return forces[off.reduce((b,d,i)=>Math.abs(d)<Math.abs(off[b])?i:b,0)];
  const of=f=>Math.log(lippedRow(rules,at,sized,lip,f,damping)[at[name]]/value);
  let [a,b]=found,fa=of(a);
  for(let k=0;k<HALVINGS&&a!==b;k++){const m=(a+b)/2,fm=of(m);if(fm===0)return m;if(fa*fm<0)b=m;else{a=m;fa=fm}}
  return (a+b)/2;
}

// The most of a reed's or the lips' breath, a share of the pressure `closing` (Pa) that shuts them.
export const breathMost=closing=>BODY.mouth/closing;
// The longest stroke of the tongue on notes repeated `rate` a second (s).
export const strokeMost=rate=>BODY.strokeShare/rate;
