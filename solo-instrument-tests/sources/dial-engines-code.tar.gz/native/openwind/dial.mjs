// The winds' live dial (native/openwind/live.mjs's, and the page's, live.html winds.js): a wind instrument played live
// on OpenWInD's engine, its reed, jet or lips, fingers and vocal tract dialled by ear -- every route the page takes,
// behind an environment the one running it hands it: its instruments, each one's body and engine, its glides, its
// neutral note, its bore's impedance, and where a setting kept goes. The Mac's server runs it on the stream binary and
// the bodies the batch made (live.mjs); a page by itself is to run it on the engine in WebAssembly and the bodies packed
// with the page (the owner, 1 November 2026: "can we then prepare this page for push to my website?"; "The website is
// static ... so it's WASM-focussed": research/LIVE_DIAL_ON_THE_WEBSITE.md) -- one dial, the same on both.
//
// Every wind the engine plays is chosen on the page, and every one plays live (the owner, 31 October 2026: "ALL
// instruments need to play live in live-dial. ALL"; "Every physically-modeled instrument we have needs to be
// live-dialable"): the reed woodwinds and the flutes with a fingering chart, their bodies made and their glides and
// impedance kept as for the first, and the brass with a scheme for the engine. One whose engine one core steps slower
// than it sounds is stepped on several, its bore split by pipes (src/parallel.rs; the same sound, bit for bit): THREADS
// below, or --threads N for each. Its engine's pace is shown as it plays.
//
// The brass (the owner, 31 October 2026: OpenWInD's brass "opens the door to adding brass to a realtime dashboard for
// similar testing"), each its lips and its bore (render/synthesis/tools/save_brass_body.py, realtime-schemes.json
// `brass`): the engine has no law for lips, so the dial holds their row itself -- the lips' values at the lip frequency
// asked, from the rows saved every few cents over their reach, and the breath its players blow there at the dynamic
// (src/brass-breath.mjs speakingBreath) -- and the pitch dialled is the lips': where the charted partials' lips stand to
// the pitches they sound, the partial heard the one the bore locks to. Blown from rest, its lips attack where the engine
// finds the partial from at that dynamic, and settle to their own once its oscillation has grown (render/node/
// brass-attacks.mjs: at mf and over, the trombone's lips set for a partial attack the one above it). A valved one's
// valves each a column pair of its row (save_brass_body.py: OpenWInD's deviation pipe and its two switches), set by its
// players' chart for each charted note (brass-standard-fingerings.json, the standard fingering), each dialled between
// raised and pressed -- a half-valve -- until the pitch moves; a pitch between two charted notes on the nearer's
// fingering, the partial heard the one that fingering's bore locks to (the owner, 31 October 2026: "Show all instrument
// parameters there, including valves"). The trombone's slide drawn as its players draw it (render/synthesis/tools/
// save_slide_body.py: its slide's pipe stretched in the engine as it moves, kernel.rs Player::stretch; the owner, 1 November
// 2026: "we do need that trombone slide fully functioning in the manner of a trombone"): each charted note at its
// position, standard or alternate, where its partial plays it in tune; a pitch between them on the partial its players
// play there, the slide placed where that partial sounds it -- a glissando, slurred; each move at its players' speed
// (SLIDE_SPEED), a tongued or legato-tongued note's stroke lasting while it moves; the slide drawn by itself, its lips
// held, the bore giving the pitch. Its mutes (the owner, 3 November 2026: "We're also missing functional brass mutes"),
// each its players' kit (render/synthesis/src/brass-mutes.mjs): a body of its own, its bell with that mute in it -- the
// sound's path round it, its hollow a closed side branch (save_brass_body.py, MUSEBOTS_BRASS_MUTE) -- put in or taken
// out between notes as its players do it, at the first frame its bell has rung down after its breath is let go: taken
// up behind the page the first time it is asked, and kept beside the one played, so that the next time is at once, its
// note, its dynamic and the page's dials kept (`/mute`).
//
// Its player's tongue, its repeated notes and its vibrato, as the renders' players have them (the owner, 31 October 2026:
// "the parameters related to tonguing, note repetition, and player vibrato (as per the strings' live-dial page)"): a note
// changed while it is blown is slurred, legato-tongued or tongued, as the page says -- a slurred note on the same pitch
// legato-tongued, a half attack, as the renders play it (breath.mjs samePitch); a reed player's tongue holds its reed
// shut (its scaled opening, zeta, a share of itself: TONGUE below, the renders' openwind_worker.py TONGUE_SHUT and
// TONGUE_SOFT), a flutist's and a brass player's stops its air or, legato, dips it (breath.mjs BREATH softDip) -- a brass
// player's closing the air off before its lips as a reed player's tongue closes its reed, their flow (their zeta) and the
// pressure across them (their gamma) both a share of themselves, the cavity between tongue and lips no longer fed --
// each let go into the attack's curve over the tongue's release, the breath behind it all the while (the owner, 2
// November 2026: "Tonguing,
// even with me tinkering with the settings, doesn't seem able to produce sharp enough attacks": a brass player's breath
// had fallen and risen again over its own times with its lips' flow open, the bore ringing through, its oscillation
// grown again over some 40 ms); its stroke as long as the page sets, from the measured contact times the page shows; a
// note repeated by itself, so many a second; a vibrato in its breath (a woodwind's, VIBRATO_SHARE a cent of its curve,
// as the renders sway it: openwind-passages.mjs) or in its lips' frequency (a brass player's), its width and rate the
// page's. Each change is made at the frame it falls on, the engine's sound pulled to there and no further before it
// (`pulled`). Its attack a curve the page draws (the owner, 1 November 2026: "attacks usually involve a curve where a
// parameter peaks over the settling value, before settling ... An analogous situation is likely true around tonguing
// for the aerophones"): its breath at a note's start a multiple of the breath held, its points each a move of the
// engine (attack-curves.js) -- from rest, its first segment as long as the note's rise; after a tongued stroke, as the
// tongue's release. Its player breathes (the owner, 1 November 2026: "have the live-dial perform note reattacks for winds similarly to
// strings (rather than one continuous stream of breath) which might require a concept of performer lung capacity"): a
// breath as deep as wind players take one, spent as its engine says its reed, lips or jet let air into its bore
// (stream.rs Air), then the note let go, a breath taken in and the note attacked again as from rest -- as the
// strings' dial turns its bow. Off here until the page turns it on: one breath without end, as the neutral notes were
// found (neutral.mjs). Its player flutters, hums and growls through it (the owner, 1 November 2026: "growl, flutter, and
// humming through the instrument"; "these need to be supported live"), as the renders' players do, by its engine's own
// source of them (src/technique.rs, the renders' openwind_worker.py mouth_pressure and voice_source): a flutter its
// breath closed off and let go `hz` times a second, riding on whatever moves under it; a hum its breath swung by the
// player's voice at the hummed pitch, an interval under the note folded into the voice (techniques.js windTechniqueAt),
// its partials and all, beside the vibrato; a growl that voice made rough, its period doubled, with breath noise -- the
// growl played where both are on. Each off until the page turns it on. Its player's breath and,
// a brass player's, lips are never held exactly (the owner, 1 November 2026: "Noise is necessary anywhere a human player
// acts"): each a seeded stream in the engine (src/noise.rs PlayerNoise; public/shared/performers/player-noise.js), its
// temperature the page's under the player's, a measured player's (1) until the page says.
//
// The page is served at once and an instrument taken up behind it, its body the one the batch made (kept.mjs: never made
// here, a page load no making), its taking up said as it goes (`loading`); another
// chosen meanwhile is taken up next, the latest chosen winning; the one playing silenced while the next is made, let go
// once it is ready, and kept where it fails, with why. Each is taken up on its neutral note, one it sounds, at its
// dynamic (neutral.mjs, found by make-bodies.mjs). Each change the page makes names the instrument it was made for
// (`version`), and one made for an instrument no longer played is refused, so that no column of one is dialled on
// another (the owner, 31 October 2026, on the page's "counterintuitive behaviour ... around instrument loading").
//
//   const dial=windsDial(environment); dial.choose(model);
//   await dial.handle(method, path, query (URLSearchParams), given) -> {status, json} or {status, samples, headers}
// `environment`: {instruments, kinds, body(model, {mute}) -> {folder, name, rules, law (its law.json), laid, attacks, vibrato, alternates (a woodwind's:
// alternates.mjs alternatesOf, from its chart)}, engine({model, folder,
// onError}) -> its engine (winds-stream.mjs WindsStream's ready, threads, columns(), hold, vibrato, technique, tract,
// turbulence, noise, slide, pullPoints(pulls), render(frames), air(), close()), glides({model, folder, columns, shaded}) (blend.mjs GlideBook's), rulesRow(engine, model, midi,
// dynamic), neutral(folder) (neutral.mjs neutralOf's), joints(folder) (its players' joints found on the body, where its
// joints are: tune-joints.mjs jointsOf's), impedance(made, {current}) (sets made.impedance, now or when
// made), geometry(made, {current}) (sets made.geometry, its body's shape as its maker handed it to OpenWInD, for the
// page's view of it: kept.mjs geometryMade; or made.shapeless, why it has none), keep(record) -> where it went, log, warn,
// quietDial(model, {threads, mute}) (quiet-dial.mjs's: a second dial of its own, which the solver blows on -- the Mac's
// server's; none in a browser, where this module is bundled and nothing of Node's may be imported: the website's page
// has no solver)}.
import {WINDS_RATE,lipsColumn,lipsDirection,lipsRow,noteKey,rowLayout} from './rows.mjs';
import {speakingBreath} from '../../render/synthesis/src/brass-breath.mjs';
import {BREATH} from '../../render/synthesis/src/breath.mjs';
import ARTICULATION from '../../render/synthesis/winds-articulation.json' with {type:'json'};
import {DYNAMIC_VELOCITY} from '../../public/shared/dynamics.js';
import {transition} from '../../public/shared/performers/transitions.js';
import {lipsAperture,tongueLetGo} from '../../public/shared/performers/brass-tongue.js';
import {curveAt,curveOf,firstEndingAt} from '../../public/shared/performers/attack-curves.js';
import {BREATH_LITRES,LUNGS,Lungs,airflow} from '../../public/shared/performers/lungs.js';
import {FLUTTER_HZ,windTechniqueAt} from '../../public/shared/performers/techniques.js';
import {VocalTract} from '../../public/shared/performers/vocal-tract.js';
import {holdsShape,placedTract,shapedTract,tractBounds,vowelSpread} from '../../public/shared/performers/vocal-tract-played.js';
import {lippedRow,reedLip} from '../../public/shared/performers/reed-lip.js';
import {BODY,LIP_HELD,breathMost,lipGiving,lipReach,lipSpan,strokeMost} from './body.mjs';
import {WINDS_NOISE,windsNoiseKinds} from '../../public/shared/performers/player-noise.js';
import {DEFAULT_SEED} from '../../public/shared/opening-time.js';
import {player,playerEntry} from '../../registry/registry.js';
// (What it plays with besides its rows -- its tract, turbulence, noise and vibrato -- as every fit's probe plays it.)
import {NOISE_TEMPERATURES,RAISES,breathVibrato,noiseLines,playersTract,tractMeasured,turbulenceLevel,vibratoOf} from './standing.mjs';
import {BRASS_MUTES} from '../../render/synthesis/src/brass-mutes.mjs';
import {LEVERS,TONE_RANGES} from '../../public/shared/performers/personality.js';
import {LINE} from '../../public/shared/performers/line.js';
import {measuredAbout,provisionalRow,rowSounding,shadedColumns} from './blend.mjs';
import {SERIES,seriesPitch} from '../../public/shared/estimation/harmonic-series.js';
import {sha1Hex} from '../../public/shared/sha1.js';
import {fingeringAmong,fingeringAt} from './alternates.mjs';
import DIAL_REACH from './dial-reach.json' with {type:'json'};
import TRACT_SPACE from '../../public/shared/performers/vocal-tract-space.json' with {type:'json'};
import {windsRanges} from '../live/players-ranges.mjs';

// (How far a column the page multiplies is dialled: from 1/REACH to REACH times its rules' value -- one reach with the
// body's jet memory, laid out to hold the longest delay it can ask: dial-reach.json, openwind_bodies.py ring_of.)
export const REACH=DIAL_REACH.factor;
// (How far a single reed's lip is pressed or eased from each note's own, N: eased as far as a clarinet on an artificial
// mouth was measured to play its note from where it is usually played, about 2 N down to 0.3 (Almeida et al. 2013, Figs.
// 3 and 4), and pressed a newton, the reed shut short of it where it shuts sooner: reed-lip.js.)
export const LIP_FORCE=Object.freeze([-2,1]);
// (Its player's ear on a reed's note (the owner, 7 November 2026: "make sure we're successfully hitting that note
// in-tune, and bending it to make any necessary microtone"; "I can tune G4 correctly by adjusting the settings of
// 'Breath and embouchure'"): its lip -- its force, its players' lip law moving the reed's opening, damping and length
// together (reed-lip.js) -- and its breath, as a player lips a note; its embouchure for its lip where none is measured.
// Its pitch heard over SERIES.reading samples, `listen` s, once a move has had `settle` s, the first `first` s after the
// note is taken up; in tune within `cents`; at most `moves` moves; each dial nudged alone first, `nudge` of its span
// toward the pitch (a lip pressed and a breath raised raise it: the clarinet's G4, 7 November 2026), then all moved
// together by the least move, in shares of their spans, their slopes say sounds the pitch, none more than `step` of its
// span; a note heard more than `most` semitones off its pitch off its regime, a squeak, and a move that silenced or
// squeaked it undone and tried at half its size -- a nudge the other way first -- `misses` times; heard below its regime
// or silent before it was heard in it, its player's tract raised toward it a step first (tractRaised). The page's own dials,
// holes, lip and tract leave the note to the page until the pitch moves (EAR_LEFT).)
const EAR=Object.freeze({listen:SERIES.reading/WINDS_RATE,settle:.2,first:.4,cents:.5,moves:30,step:.15,nudge:.04,most:1,misses:6});
const EAR_LEFT=new Set(['/dial','/hole','/lip','/tract']);
const least=kind=>transition(kind).least;

// The tongue, as the renders' players tongue (breath.mjs passageBreath; openwind_passages.py, openwind_worker.py): a reed
// held shut to `shut` of its opening, touched lightly to `soft` for a legato tongue, touched and let go over the
// tongue's least (transitions.js tongueTouch, tongueRelease) -- a brass player's let go at its measured opening rate,
// in series with its lips (brass-tongue.js); a flutist's or brass player's air stopped over
// `fall` (transitions.js tongueStop), dipped to `dip` of itself for a legato tongue; a stroke `stroke` s long by default
// (breath.mjs tongueStop: the air cut that long before a tongued note), a legato tongue `softSeconds`; a slurred note
// within `samePitch` cents of the one before it, legato-tongued. And the measured contact times the page shows its
// dial against, each DOI checked on Crossref: clarinettists' portato 37 ms (sd 14), their staccato 115 ms at four notes
// a second and 347 ms at two (the registry's, registry/players/winds.json reed-woodwind tongue: M. Pàmies-Vilà, A.
// Hofmann & V. Chatziioannou 2018, doi:10.3389/fpsyg.2018.00617); saxophonists' 25.5 ms
// (A. Hofmann & W. Goebl 2014, "Production and perception of legato, portato, and staccato articulation in saxophone
// playing", Front. Psychol. 5:690, doi:10.3389/fpsyg.2014.00690); and single tonguing to some 8 notes a second, double
// some 11.5 (M. Bertsch & P. Hoole 2014, "Tonguing on brass instruments -- high speed ultrasound study", ISMA 2014,
// no DOI).
// A tongue on a single reed stills it: its effective mass some 5 times and its damping some 333 times their own at the
// height of a portato's contact (0.033 to 0.165 kg/m^2, 3000 to 10^6 s^-1, its stiffness unchanged), its reed channel
// not closed completely -- fitted to a professional player's tongue-separated tones, its mouth pressure, mouthpiece
// pressure and reed bending measured (V. Chatziioannou & A. Hofmann 2015, "Physics-based analysis of articulatory
// player actions in single-reed woodwind instruments", Acta Acustica united with Acustica 101(2) 292-299,
// doi:10.3813/AAA.918827, Fig. 9). Its reed's resonance over its damping (the rows' qfactor) the less by its damping's rise and by
// the root of its mass, its resonance the less. (Its shares and its contact the winds' players' articulation's, written
// once with the passage player's and the Rust maker's: render/synthesis/winds-articulation.json `tongue`.)
export const TONGUE=Object.freeze({shut:ARTICULATION.tongue.shut,soft:ARTICULATION.tongue.soft,
  contact:Object.freeze({mass:ARTICULATION.tongue.contact.mass,damping:ARTICULATION.tongue.contact.damping}),touch:least('tongueTouch'),release:least('tongueRelease'),fall:least('tongueStop'),dip:BREATH.softDip,
  stroke:BREATH.tongueStop,softSeconds:BREATH.softSeconds,samePitch:BREATH.samePitch,
  measured:Object.freeze({portato:[player('reed-woodwind','tongue.portato.contact'),playerEntry('reed-woodwind','tongue.portato.contact').sd],
    staccato:player('reed-woodwind','tongue.staccato.contact'),saxophone:.0255,single:8,double:11.5})});
// (A flute's jet given the solver never under this share of its note's -- the breath under it its presence's, its
// drive fading with it: openwind_worker.py JET_FLOOR, law.rs the same.)
export const JET_FLOOR=.01;
// (A breath's rise from rest by default, s: the renders' tuning probe's (breath.mjs probeRise), the standard a tone's
// speaking is measured against.)
export const RISE=BREATH.probeRise;
// A trombone's slide moved as its players move it: along the raised cosine, its hand travelling half the tube it adds --
// its slide's two legs -- over SLIDE_LEAST s, or a longer move at a peak of SLIDE_SPEED m/s. Fast slide moves accelerate
// over some 0.1 s and speeds of some 2 m/s are sometimes exceeded, the peak speed going roughly with the distance (J.
// Kemp, A. López-Carromero, A. Woolley & M. Campbell 2015, "Experimental investigation of Doppler shift and infrasound
// generation during wave propagation within the bore of the trombone during slide movement", Proceedings of the Third
// Vienna Talk on Music Acoustics, no DOI; their [2], W. J. Wadman, J. J. D. van der Gon, R. H. Geuze & C. R. Mol 1979,
// "Control of fast goal-directed arm movements", Journal of Human Movement Studies 5(1) 3-17); a hand's first position to
// seventh some 0.6 m (G. Ekdahl 2001, "A simple model of the mechanics of trombone playing", KTH Department of Mechanics
// technical report).
export const SLIDE_SPEED=2,SLIDE_LEAST=.2;
// A flutter, a hum and a growl as the renders' players play them, each its default and its reach the renders'
// (openwind_worker.py techniques, technique.rs Techniques: a flutter 5 to 60 times a second, by default the middle of
// the renders' flutters, speakers' measured voiceless trills (techniques.js FLUTTER_HZ), closing off 0.7 of the breath,
// none to all; a voice's level 0.2 of the breath by default, none to all of it, and a growl's roughness none to all) --
// the hummed pitch an octave under the note by default, the middle of what the renders' hummers draw (techniques.js
// windTechniqueOf: a fifth to an octave and a fourth under), from three octaves under it to an octave over, folded into
// the player's voice; a growl's an octave under too, the middle of theirs (eleven to thirteen semitones under), as rough
// as theirs halfway (0.3 to 0.9).
export const TECHNIQUE=Object.freeze({flutter:Object.freeze({hz:(FLUTTER_HZ[0]+FLUTTER_HZ[1])/2,depth:.7,hzReach:[5,60],depthReach:[0,1]}),
  hum:Object.freeze({interval:-12,level:.2,intervalReach:[-36,12],levelReach:[0,1]}),
  growl:Object.freeze({interval:-12,level:.2,rough:.6,intervalReach:[-36,12],levelReach:[0,1],roughReach:[0,1]})});
const slideSeconds=(from,to)=>{const travel=Math.abs(to-from)/2;return travel>0?Math.max(SLIDE_LEAST,Math.PI*travel/(2*SLIDE_SPEED)):0};

export function windsDial(env){
const {log=console.log,warn=console.error}=env;
// The instrument played (`current`): its model and kind, its body, its notes, its engine and the frames pulled from it,
// its columns, and what is measured of it as it plays (each dynamic's rows, its glides, its bore's impedance) -- all
// made again when another is chosen. A brass instrument's `lips`: its rules.json (their rows over their reach, its
// partials), `attacks`, its attacks.json (each partial's attack at each dynamic), and `vibrato`, its vibrato.json (each
// partial's swing heard at each depth of its lips' sway); null for a woodwind.
let current=null,version=0;
// Every change made on the instrument since it was taken up, at the frame it was made on -- its route and what was sent
// -- so that a saved file carries the whole way to a sound, which native/openwind/replay.mjs makes again move for move
// (the owner, 7 November 2026: "we won't be able to do this investigation properly until the site is synchronized with
// the development version here"): near the top of the clarinet the note heard hangs on the way there, which a setting
// alone does not say. MOVES_MOST at most, those after it counted as dropped.
const MOVES_MOST=200000;
let moves=[],movesDropped=0;
const moved=(frame,path,given)=>{const {version:_,at:__,...sent}=given??{};if(moves.length<MOVES_MOST)moves.push({frame,path,given:sent});else movesDropped++};
// A brass instrument's bodies taken up (`bodies`, by its mute: null none), the one played among them, each kept once it
// is taken up; `muting`, the mute asked and its body as it is taken up, put in once its body is ready and the bell is
// quiet -- `quiet`, the frame by which the breath last let go has rung down (RUNG s after its fall: chosen, a mute
// taking its players longer than that to put in).
const bodies=new Map;
let muting=null,quiet=0;
const RUNG=.5;
// What the page dials: a note (the charted note nearest `pitch`), its dynamic, the rules' row there, the row held
// (`row`: the rules' with the page's dials -- each reed or jet column `x`, -1 to 1, 1/REACH to REACH times the rules'
// value; each hole the page moved its own until the pitch moves), whether it is blown, the tract; its articulation,
// its tongue's stroke, its breath's rise and its attack's curve (`breathAttack`: its first segment the rise; by default
// the rise alone), its repeats, its vibrato and its breathing (`breathing`: off, one breath without end; on, a breath
// `litres` deep, taken in over `inhale` s); its flutter, its hum and its growl (TECHNIQUE); and its player's swell through a note
// (`swell`, a share of the row's breath: /swell); its player's noise (`noise`: the player's temperature, and each kind's
// under it).
// (As the dial begins, and again as the page is reloaded: afresh.)
const begun=()=>({midi:null,note:null,pitch:null,dynamic:'mf',rules:null,row:null,x:{},pulled:{},fingers:{},between:null,blowing:false,tract:null,shape:null,tractFollows:false,raised:null,turbulence:0,lip:null,lipDialled:false,bend:0,lipForce:0,ear:null,earX:{},heard:null,tuning:null,valves:null,within:true,
  slide:null,slideDialled:false,barrel:null,articulation:'tongued',stroke:TONGUE.stroke,softSeconds:TONGUE.softSeconds,rise:RISE,breathAttack:[[0,0],[RISE,1]],repeat:{on:false,rate:4},vibrato:{on:false,width:0,rate:5},
  breathing:{on:false,litres:BREATH_LITRES,inhale:LUNGS.inhale.seconds},
  flutter:{on:false,hz:TECHNIQUE.flutter.hz,depth:TECHNIQUE.flutter.depth},hum:{on:false,interval:TECHNIQUE.hum.interval,level:TECHNIQUE.hum.level},
  growl:{on:false,interval:TECHNIQUE.growl.interval,level:TECHNIQUE.growl.level,rough:TECHNIQUE.growl.rough},swell:1,
  noise:{...NOISE_TEMPERATURES}});
const state=begun();
// How the row is held now: its breath's share (0 to 1) and how much of the reed's opening the tongue leaves.
const held={breath:0,tongue:1};
// Its player's lungs (lungs.js): the air left in its breath, and whether it is taking one.
const lungs=new Lungs();
// (Each instrument's airflow: the air it takes at a dynamic, a pitch and a breath setting.)
const flows=new Map;
const airflowOf=model=>{if(!flows.has(model))flows.set(model,airflow(model));return flows.get(model)};

// ---- the row ----
const columnName=k=>current.columns[k][2];
// (Which kind of motion each column's change is: the breath's, the lips' on the reed or jet, a finger's on a key or a
// valve.)
const fingered=()=>current.lips?'valve':'key';
const kindOf=k=>k===current.breath?'breath':current.columns[k][0]==='opening'?fingered():'lips';
// (A column the page dials: a reed's or a jet's, but not what follows from another -- a jet's derivative and next value,
// its presence -- nor a reed's model; the lips' frequency dialled by itself, in Hz.)
const DERIVED=new Set(['model','dUj','next_Uj','presence']);
const dialled=k=>['reed','flute'].includes(current.columns[k][0])&&!DERIVED.has(columnName(k));
// (A dial's place x, -1 to 1: 1/REACH to REACH times the rules' value; the reed's contact exponent three either side of
// it, a jet's offset from the edge one of its widths -- each of these may stand at nothing.)
const ADDITIVE={contact_exponent:3,y0:1};
const ofDial=(k,v,x)=>!x||!dialled(k)||current.lips&&columnName(k)==='pulsation'?v:columnName(k) in ADDITIVE?v+ADDITIVE[columnName(k)]*x:v>0?v*REACH**x:v;
// (A single reed's lip pressed or eased `lipForce` N from each note's own, its players' (reed-lip.js), before the
// dials: kept from note to note, as the player's embouchure is.)
const lipped=rules=>{const force=state.lipForce+(state.earX.lip??0);return current.reedLip&&force?lippedRow(rules,current.reedAt,current.sized,current.reedLip,force,current.lipDamping):rules};
// The row the page sets: the rules' at the pitch, the lip on it, each dial's share on it, each hole the page moved.
const composed=()=>(withinBody(),lipped(state.rules)).map((v,k)=>current.columns[k][0]==='opening'?state.fingers[k]??v:ofDial(k,v,placed(k)));
// (A dial's place: the page's, and its player's ear's on it, together within the dial's reach.)
const placed=k=>Math.max(-1,Math.min(1,(state.x[k]??0)+(state.earX[k]??0)));
// (The place of a reed's or the lips' breath at the most a player's mouth holds (body.mjs), with the lip and the reed's
// dials where they stand; null where its body has no pressure that shuts it, or a jet's.)
function breathPlace(){
  const b=current.breath,shut=current.columns.findIndex(c=>c[0]==='reed'&&c[2]==='closing_pressure');
  if(current.kind==='air'||b==null||shut<0||!dialled(b))return null;
  const row=lipped(state.rules),pc=ofDial(shut,row[shut],placed(shut));
  return pc>0&&row[b]>0?Math.log(breathMost(pc)/row[b])/Math.log(REACH):null;
}
// (A single reed's lip's reach now, N from the note's own (body.mjs), or null where it has none.)
const lipNow=()=>current.reedLip&&current.sized?lipReach(state.rules,current.reedAt,current.reedLip,LIP_FORCE):null;
// What starts the note at its pitch (`given.hz`, else the note's), computed backward on the engine's own equations
// (starts.rs): at the note's own row, its players' lip's law from LIP_FORCE's easing to the most its law presses, and
// their tract in every shape they keep it in (vocal-tract-played.js's, where their tract is measured) as well as it
// stands, `given.tractCents` apart; growing from rest as fast as its players' notes grow (`given.attack`, ATTACK_GROWTH's,
// normal where none is given), or at `given.growth` (its amplitude's rate, 1/s; 0: neither growing nor dying).
// (How fast players' notes grow from rest, their fundamental's level in dB/s, as clarinettists' attacks were measured:
// W. Li, A. Almeida, J. Smith & J. Wolfe 2016, "How clarinettists articulate", JASA 139, 825-838, doi:10.1121/1.4941660
// -- normal and staccato 800, accented and sforzando 1300, the minimal attack 250.)
const ATTACK_GROWTH=Object.freeze({normal:800,accented:1300,minimal:250});
const growthAsked=given=>{
  if(given.growth!=null){if(!Number.isFinite(Number(given.growth)))throw new Error('a growth in 1/s');return Number(given.growth)}
  const db=ATTACK_GROWTH[given.attack??'normal'];
  if(db==null)throw new Error(`an attack ${Object.keys(ATTACK_GROWTH).join(', ')}`);
  return db*Math.LN10/20;
};
const TRACT_SHAPES=Object.freeze(Object.fromEntries(['normal','bend'].map(how=>[how,{rows:TRACT_SPACE[how].rows.map(({target,resonances})=>({target,resonances}))}])));
const startsAsked=given=>({hz:given.hz??440*2**((state.pitch-69)/12),row:state.rules,
  lip:current.reedLip&&current.sized?{...current.sized,...current.reedLip,damping:current.lipDamping??null}:null,forces:[LIP_FORCE[0],Number.MAX_VALUE],
  forceSteps:given.forceSteps,openingSteps:given.openingSteps,overtones:given.overtones,checked:Boolean(given.checked),
  tract:tractMeasured(current.model)?TRACT_SHAPES:null,tractCents:given.tractCents,growth:growthAsked(given)});
// Its player held within a player's body (body.mjs), `within` it: a single reed's opening or damping dialled found on
// its lip, the dial given back to the lip; its lip within its reach; its breath under the most a mouth holds, the page's
// breath pulled down under its ear's as far as it must be -- its body's pull, the page's own dial kept under it (`pulled`):
// a note taken up after begins from the page's own, its ear's to tune where the page has not dialled it, and is pulled
// again only as far as that note must be (the oboe's charted rows from E6 up ask 29 kPa at mf, pulled to 25: the breath
// of every note after was held out of its ear, 8 November 2026). Each pulled as the others move.
function withinBody(){
  if(!state.within||!state.rules)return;
  const reach=lipNow();
  if(reach){
    for(const name of LIP_HELD){
      const k=current.reedAt[name];
      if(!state.x[k])continue;
      const force=lipGiving(state.rules,current.reedAt,current.sized,current.reedLip,current.lipDamping,name,ofDial(k,state.rules[k],state.x[k]),reach,state.lipForce+(state.earX.lip??0));
      state.x[k]=0;delete state.earX[k];delete state.earX.lip;state.lipForce=force;
    }
    const force=state.lipForce+(state.earX.lip??0),kept=Math.min(reach[1],Math.max(reach[0],force));
    if(kept!==force)state.lipForce=kept-(state.earX.lip??0);
  }
  const most=breathPlace(),b=current.breath;
  if(most!=null&&placed(b)>most){if(!(b in state.pulled))state.pulled[b]=state.x[b]??0;state.x[b]=Math.max(-1,most)-(state.earX[b]??0)}
}
// (Its tongue within a player's: repeats no faster than its body's fastest; on repeats, its stroke within its share of
// a note -- the stroke shortened as the repeats quicken, or, the stroke `moved`, the repeats slowed for it.)
function tongueWithin(moved=false){
  if(!state.within)return;
  state.repeat.rate=Math.min(state.repeat.rate,BODY.repeat);
  if(!state.repeat.on)return;
  if(moved)state.repeat.rate=Math.max(.5,Math.min(state.repeat.rate,BODY.strokeShare/state.stroke));
  else state.stroke=Math.min(state.stroke,Math.max(LIMITS().stroke[0],strokeMost(state.repeat.rate)));
}
// What its player's body reaches now, each with the others where they stand: a single reed's lip (N from the note's
// own), the places its opening and damping reach on it, its breath's place, its repeats a second, its stroke on them
// (s) -- shown on the page's sliders, within it or not.
function reachOf(){
  if(!current||!state.rules)return null;
  const lip=lipNow(),breath=breathPlace(),place=(k,v)=>Math.log(v/state.rules[k])/Math.log(REACH);
  const held=lip?Object.fromEntries(LIP_HELD.map(name=>{const k=current.reedAt[name];
    return [k,lipSpan(state.rules,current.reedAt,current.sized,current.reedLip,current.lipDamping,name,lip).map(v=>place(k,v))]})):{};
  const [low,high]=LIMITS().stroke;
  return {lip,held,breath:breath==null?null:[-1,breath],repeat:[.5,BODY.repeat],
    stroke:state.repeat.on?[low,Math.min(high,Math.max(low,strokeMost(Math.min(state.repeat.rate,BODY.repeat))))]:null};
}
// The row as its player holds it: its breath `breath` of itself (a reed's or the lips' gamma; a jet's speed), its reed's
// opening, or while its tongue is shut its lips' flow, `tongue` of itself (zeta) -- a brass player's tongue, closing the
// air off before its lips, holding back the pressure across them too, its breath behind it; let go, the pressure across
// them alone its share, their flow through the tongue's opening and their own in series following it (brass-tongue.js).
function played(row,{breath=held.breath,tongue=held.tongue}={}){
  const out=[...row],{breath:b,zeta,damping,resonance}=current,lips=current.kind==='lips';
  out[b]=row[b]*breath*state.swell*(lips?tongue:1);
  if(zeta!=null)out[zeta]=row[zeta]*(lips&&tongue>TONGUE.shut?1:tongue);
  // (A reed's tongue on it stills it as well as closing it: TONGUE.contact, its mass and damping raised as far as its
  // share of the reed it shuts. Its row's qfactor is its resonance over its damping (OpenWInD's Q_r, g = omega_r / Q_r:
  // the engine's step damps by 1 / Q_r), so the tongue lowers it. Until 15 November 2026 it was raised by that much,
  // and a tongued reed rang nearly undamped, 745 times its own Q, where it was measured stilled.)
  if(damping!=null&&tongue<1){
    const c=Math.min(1,(1-tongue)/(1-TONGUE.shut)),mass=1+(TONGUE.contact.mass-1)*c;
    out[damping]=row[damping]/((1+(TONGUE.contact.damping-1)*c)*Math.sqrt(mass));
    out[resonance]=row[resonance]/Math.sqrt(mass);
  }
  return out;
}
// The row held, moved to over `seconds`, as its player holds it (`how`: played's); a jet's speed, once its vibrato has
// swayed it, never under JET_FLOOR of the one dialled, the rest of its breath its presence's -- floored in the engine,
// after the sway, as the renders' law floors it (stream.rs HeldLine; law.rs), so its vibrato never takes the jet under it.
const holdAs=(row,seconds,how)=>send(played(row,how),seconds,current.presence!=null?JET_FLOOR*row[current.breath]:undefined);
const hold=(row,seconds)=>holdAs(row,seconds);
// (The row held as the engine moves it, stream.rs HeldLine: from where it stood to the row sent along the raised
// cosine, its techniques on its breath -- a flutter riding on whatever moves under it.)
const send=(row,seconds,floor)=>current.stream.hold(row,seconds,floor);

// ---- what the player does at frames to come: each at the frame it falls on (`pulled`) ----
let queue=[];
function after(seconds,run,tag='tongue'){
  const at=current.frames+Math.max(1,Math.round(seconds*WINDS_RATE));
  queue.push({at,run,tag});queue.sort((a,b)=>a.at-b.at);
}
const cancel=tag=>{queue=queue.filter(e=>e.tag!==tag)};
const tonguing=()=>queue.some(e=>e.tag==='tongue');

// ---- the musebot player: a piece its band composes for the wind played, its line sent as the sound is pulled ----
// (soloist.mjs, imported when a piece is first asked for: its band and its bots. `given`: {on, seed, seconds (the most
// it plays), personality (its levers, grammars and tone ranges given: soloist.mjs playerSettingsOf), line (a line given
// whole, played in place of a piece composed: soloist.mjs givenSolo)}, each left out its last; its player told, through its instrument's MCP server, the dial's compass, the engine's notes, and what the dial
// plays of its wind (soloist.mjs windsEngineOf). Each note sent whole a pull ahead of its stroke, the dial's /state strokeLeast, so
// that none comes late; let go, what it sent still to come withdrawn and its breath let go. Its last piece, played or
// let go, said in /state, with its personality as it drew it.)
// (The most frames a pull of sound asks.)
const PULL_MOST=16384;
let soloist=null;
// (Its player's settings, the last given -- a page's, a file's -- kept across instruments: its seed the band's own until
// one is given (opening-time.js DEFAULT_SEED), every lever drawn from it.)
let playerSettings={seed:DEFAULT_SEED,seconds:60,personality:{}};
// (Shown with what can be given: its personality's levers, motif grammars and tone ranges.)
const playerShown=()=>({...playerSettings,levers:LEVERS,grammars:LINE.grammars,ranges:TONE_RANGES});
async function solo(given){
  const now=current.frames/WINDS_RATE;
  if(soloist?.line){soloist={said:soloist.line.shown(now),playing:false};withdrawn({by:'soloist',from:now});if(state.blowing)await change('/blow',{on:false});await givenBack()}
  if(!given.on)return {status:200,json:{...playing(),soloist}};
  pageOwn=ownOf();
  const {composeSolo,givenSolo,SoloLine,playerSettingsOf,windsEngineOf}=await import('./soloist.mjs');
  const of=name=>given[name]===undefined?playerSettings[name]:name==='personality'?given[name]:Number(given[name]);
  let composed;
  if(given.line){try{composed=givenSolo({model:current.model,kind:current.kind,line:given.line})}catch(error){return {status:400,json:{error:error.message}}}}
  else{
    playerSettings=playerSettingsOf({seed:of('seed'),seconds:of('seconds'),personality:of('personality')});
    composed=await composeSolo({model:current.model,kind:current.kind,...playerSettings,compass:compassNow(),engine:windsEngineOf(shown())});
  }
  const dial=shown(),lead=Math.max(dial.strokeLeast.tongued,dial.strokeLeast.legato)+PULL_MOST/WINDS_RATE,start=current.frames/WINDS_RATE+lead;
  const send=async(path,asked)=>{try{return path==='/withdraw'?withdrawn(asked):await later(path,asked)}catch(error){return {status:400,json:{error:error.message}}}};
  soloist={line:new SoloLine(composed,{dial,send,start,lead}),playing:true};
  return {status:200,json:{...playing(),soloist:{said:soloist.line.shown(start),playing:true}}};
}
// (The notes the dial plays, [low, high].)
const compassNow=()=>[Math.min(...current.notes),Math.max(...current.notes)];
const soloShown=()=>soloist&&{said:soloist.line?soloist.line.shown(current.frames/WINDS_RATE):soloist.said,playing:soloist.playing};

// A stroke's length, s, as `how` asks it ('tongued' or 'legato'): the page's stroke or legato tongue's (`asked`), no
// shorter than its tongue and fingers allow -- what a player sending its notes ahead counts back from (`strokeLeast`).
const strokeLength=(how,asked=how==='legato'?state.softSeconds:state.stroke)=>how==='legato'?Math.max(asked,2*TONGUE.fall,current.kind==='reed'?least('breathRise'):0)
  :Math.max(asked,TONGUE.touch+least(fingered()));
// A stroke of the tongue now, from row `before` (the row held before it) to the page's, as `how` says: 'tongued' (the
// reed held shut, the air closed off before the lips, or a flute's air stopped, for the page's stroke, the fingers moving
// behind it) or 'legato' (a touch, or a dip of the air, for a legato tongue's length); tongued, let go into the
// attack's curve -- a reed player's tongue over its release, a brass player's as it opens (released) -- a brass
// instrument's lips attacking as from rest; a trombone's stroke lasting while its slide moves (`moving` s), the note let
// go as it arrives.
function stroke(before,how,moving=0){
  cancel('tongue');cancel('attack');
  const kind=current.kind,legato=how==='legato';
  const seconds=Math.max(moving,strokeLength(how));
  // (A repeat's stroke no longer than most of its time: what the faster staccato measured leaves -- 115 ms of 250.)
  const length=state.repeat.on&&state.blowing?Math.min(seconds,strokeMost(state.repeat.rate)):seconds;
  // (Its fingers moved as late as they may and still be there as the tongue lets go, over their least, from `stopped`
  // s at the soonest -- the note before's tone rung down under the tongue, as the renders move a passage's keys about
  // the next note's onset (openwind_passages.py passage_breath). Moved as soon as the air was stopped, the bore still
  // rang as they moved, its ring gliding from the one fingering's resonance to the next's -- the owner, 5 November 2026:
  // "watery 'plops' at the end of some piccolo notes similar to what I noticed from the clarinet": the website's
  // piccolo's E6, its E fingering ringing at 1307 Hz, rose to the next note's G#'s 1653 Hz as it died.)
  const fingers=stopped=>{const from=Math.max(stopped,length-least(fingered()));after(from,()=>hold(state.row,Math.max(length-from,least(fingered()))))};
  if(kind==='reed'||kind==='lips'&&!legato){
    // (A brass player's tongue before its lips: the pressure across them left as their flow is.)
    const touch=TONGUE.touch,left=legato?TONGUE.soft:TONGUE.shut;
    held.tongue=left;holdAs(before,touch);
    fingers(touch);
    // (Tongued, let go into the attack's curve, its first segment the tongue's release; legato-tongued, a half attack,
    // let go plainly.)
    after(length,()=>{if(legato){held.tongue=1;hold(state.row,TONGUE.release)}else if(kind==='lips')attackNow(TONGUE.release,{shut:0});else{held.tongue=1;attackNow(TONGUE.release)}});
    return length;
  }
  if(legato){
    held.breath=TONGUE.dip;holdAs(before,length/2);
    after(length/2,()=>{held.breath=1;hold(state.row,length/2)});
    return length;
  }
  held.breath=0;holdAs(before,TONGUE.fall);
  fingers(TONGUE.fall);
  after(length,()=>attackNow(TONGUE.release));
  return length;
}
// (A tongue let go: its share of the row (held.tongue) `since` s after, and the times since then its moves end at
// -- a brass player's along the pressure its opening leaves across the lips, in series with their aperture at the row
// held, its course's moves; a reed player's whole at once, over the tongue's release (brass-tongue.js tongueLetGo).)
function released(){
  const {zeta,closing,reed}=current,aperture=current.kind==='lips'&&reed&&closing!=null?lipsAperture(state.row[zeta],state.row[closing],reed):0;
  return tongueLetGo(aperture,TONGUE.shut,TONGUE.release);
}
// The breath let go into the row held along the page's attack (state.breathAttack): its first segment over `seconds`,
// each after it over its own time, each a move of the engine made at its frame; a reed or the air before the lips held
// shut by the tongue until `shut` s (a note from rest: its tongue let go as its breath has risen; a brass player's
// tongued stroke, at once), then let go (released); a brass instrument's lips attacking from where its attack is found
// at that dynamic and settled to their own once its oscillation has grown (brass-attacks.mjs: that long after its
// breath is let go -- its tongue's release, where it has one) -- each of these a move of its own, the breath carried on
// along its curve across it.
function attackNow(seconds,{shut=null}={}){
  cancel('attack');
  const attack=attackHeld(),lips=current.lips&&attack&&attack.share!==1?attack:null,settle=lips?(shut??0)+lips.settleAfter:null;
  // (The row held at `t` s, moved to over `span` s: a brass instrument's lips where its attack holds them until they
  // settle.)
  const holdAt=(t,span)=>{
    if(lips&&t<=settle){
      const own=lipsRow(current.lips,state.lip,1,state.valves),from=lipsRow(current.lips,state.lip*lips.share,1,state.valves);
      send(played(state.row).map((v,k)=>own[k]?v*from[k]/own[k]:v),span);
    }else hold(state.row,span);
  };
  const tongue=shut!=null?released():null;
  // (The rise alone -- the curve as it starts -- one move, as the breath has always risen: the neutral notes were found
  // so (neutral.mjs).)
  if(state.breathAttack.length===2){
    held.breath=1;held.tongue=shut!=null?TONGUE.shut:1;
    holdAt(0,seconds);
    if(tongue)tongue.times.forEach((t,k)=>{const from=k?tongue.times[k-1]:0;after(shut+from,()=>{held.tongue=tongue.at(t);holdAt(shut+from,t-from)},'attack')});
    if(lips)after(settle,()=>hold(state.row,least('lips')),'attack');
    return;
  }
  const curve=firstEndingAt(state.breathAttack,seconds);
  const times=[...new Set([...curve.slice(1).map(p=>p[0]),...lips?[settle,settle+least('lips')]:[],...tongue?[shut,...tongue.times.map(t=>shut+t)]:[]])]
    .filter(t=>t>0).sort((a,b)=>a-b);
  // (Where the row stands at `t` s, moved to over `span` s.)
  const move=(t,span)=>{
    held.breath=curveAt(curve,t);held.tongue=tongue?tongue.at(t-shut):1;
    holdAt(t,span);
  };
  times.forEach((t,k)=>{const from=k?times[k-1]:0;if(k)after(from,()=>move(t,t-from),'attack');else move(t,t)});
}
// A change the page made to the row held (`before` the row before it): moved to, as its player moves -- blown, a new
// pitch is slurred, legato-tongued or tongued as the page says (a slurred note on the same pitch legato-tongued); else
// moved over the longest least of the kinds of what changed, its breath held where its tongue holds it; a trombone's lips
// moving with its slide (`moving` s), a slurred note a glissando.
function changed(before,{pitch=null,moving=0}={}){
  if(state.blowing&&!lungs.taking&&pitch!==null){
    const how=state.articulation==='slurred'&&Math.abs(100*(pitch.to-pitch.from))<TONGUE.samePitch?'legato':state.articulation;
    if(how!=='slurred'){stroke(before,how,moving);return}
  }
  const kinds=new Set(state.row.map((v,k)=>v!==before[k]?kindOf(k):null).filter(Boolean));
  const breath=current.breath,rising=state.row[breath]>before[breath];
  hold(state.row,Math.max(moving,...[...kinds].map(kind=>kind==='breath'?least(rising?'breathRise':'breathFall'):least(kind))));
}
// Blown or not: from rest, a reed's tongue on its reed as the breath rises (the renders' first note: breath.mjs), let
// go as it has risen, and a brass player's before its lips; a flute's air let go into its rise; stopped, the breath
// falling over its least.
function blow(on){
  if(on===state.blowing)return;
  state.blowing=on;cancel('tongue');cancel('repeat');cancel('attack');cancel('breath');lungs.filled();
  if(on){
    fromRest();
    repeating();
  }else{held.breath=0;held.tongue=1;hold(state.row,least('breathFall'));quiet=current.frames+Math.round((least('breathFall')+RUNG)*WINDS_RATE)}
  techniques();sway();
}
// (A note from rest: a reed's tongue on its reed as the breath rises, let go as it has risen, and a brass player's
// before its lips -- the air built up behind it and let go, as brass players tongue (the owner, 2 November 2026: "The
// brass attacks are still missing the characteristic brass spittiness": blown from rest over its rise, the trumpet's
// fundamental had taken some 400 ms to grow); a flute's air let go into its rise.)
function fromRest(){
  if(current.kind==='reed'||current.kind==='lips')attackNow(state.rise,{shut:state.rise});
  else{held.tongue=1;attackNow(state.rise)}
}
// Whether its breath is spent now: while it is blown and its player breathes, not while a breath is taken (`pulled`
// spends the air its engine let in meanwhile).
const spends=()=>Boolean(current&&state.pitch!=null&&state.row&&state.breathing.on&&state.blowing&&!lungs.taking);
// What its players spend as its note is held, L/s: their measured airflow at the dynamic and pitch (lungs.js airflow),
// at its breath setting over the rules' there -- shown beside its model's own.
function playersSpend(){
  if(!current||state.pitch==null||!state.row)return 0;
  const b=current.breath,rules=state.rules?.[b],share=rules>0?state.row[b]*state.swell/rules:1;
  return airflowOf(current.model).of({dynamic:state.dynamic,midi:state.pitch,share});
}
// Its breath spent: the note let go as blowing stops, a breath taken in, and the note attacked again as from rest -- its
// tongue, its repeats and its vibrato stopped meanwhile.
function breathe(){
  cancel('tongue');cancel('repeat');cancel('attack');
  lungs.breathe();techniques();held.breath=0;held.tongue=1;hold(state.row,least('breathFall'));sway();
  after(least('breathFall')+lungs.inhale,()=>{lungs.filled();fromRest();repeating();techniques();sway()},'breath');
}
// The note repeated by itself while it is blown, `rate` a second: each a stroke as the page says, a slurred one a
// legato tongue's.
function repeating(){
  cancel('repeat');
  if(!(state.repeat.on&&state.blowing)||lungs.taking)return;
  const next=()=>{stroke(state.row,state.articulation==='tongued'?'tongued':'legato');after(1/state.repeat.rate,next,'repeat')};
  after(1/state.repeat.rate,next,'repeat');
}
// The vibrato held: a woodwind's in its breath (VIBRATO_SHARE of it a cent of its curve, half the width each way), a
// brass player's along its embouchure's way (rows.mjs lipsDirection: the mouthpiece pressed into the lips and eased),
// its lips as deep as sways the partial held half the width each way as it is heard (pressed; `heard`, the width it
// is heard, the widest its partial holds where it holds no wider; null where its swing is not measured); none
// unblown. Swayed again as the pitch, the dynamic or the lips move.
function sway(seconds=.2){
  const sounding=state.blowing&&!lungs.taking;
  const {on,width,rate}=state.vibrato,v=on&&sounding?width/2:0;
  if(current.lips){
    const way=lipsDirection(current.lips,state.lip,1,state.valves),got=on&&width>0?pressed(width/2):null,depth=v&&got?got.depth:0;
    current.heard=got&&2*got.heard;
    current.stream.vibrato({columns:way.columns,depths:way.slopes.map(s=>s*depth),cents:way.columns.map(()=>true),rate,seconds});
  }
  else current.stream.vibrato(breathVibrato(current.breath,{width:2*v,rate},seconds));
}
// A voice's pitch, Hz: the page's interval under the note, folded into the player's voice (techniques.js windTechniqueAt).
const voiced=kind=>windTechniqueAt({kind,...state[kind]},state.pitch)[kind];
const hummed=kind=>voiced(kind).hz;
// Its techniques on its breath while it is blown, none while a breath is taken (stream.rs Stream::technique: a flutter
// the tongue's roll closing it off `hz` times a second, `depth` of it, its curve squared as the renders' is; a hum or a
// growl the player's voice at its pitch, `level` of it), each moved in or out over the technique's least -- the engine
// moving them on under every row it is sent, so that an attack, a stroke or a breath moves on under them. Sent again as
// the pitch moves the voice's.
function techniques(){
  const sounding=state.blowing&&!lungs.taking&&state.pitch!=null,on=kind=>sounding&&state[kind].on,floor=on('flutter')?speaksAt():null;
  current.stream.technique({column:current.breath,seconds:least('technique'),...on('hum')?{hum:voiced('hum')}:{},...on('growl')?{growl:voiced('growl')}:{},
    ...on('flutter')?{flutter:{hz:state.flutter.hz,depth:state.flutter.depth}}:{},...floor!=null?{floor}:{}});
}
// Where the note held stops speaking, a gamma, its breath's column's (rules.json `speaks`: openwind_passages.py speaks_of)
// -- a reed's, between its charted neighbours at its dynamic as the engine's rules draw a note's values between
// velocities -- for its flutter to close off only the breath over it, its tone kept; null for a jet or the lips.
function speaksAt(){
  const {speaks,velocities:v}=current;if(!speaks||state.pitch==null)return null;
  const x=Math.min(Math.max(DYNAMIC_VELOCITY[state.dynamic],v[0]),v.at(-1));let j=0;while(j<v.length-2&&v[j+1]<=x)j++;
  const w=v[j+1]>v[j]?(x-v[j])/(v[j+1]-v[j]):0,at=midi=>{const g=speaks[current.notes.indexOf(midi)];return g&&g[j]!=null&&g[j+1]!=null?g[j]+(g[j+1]-g[j])*w:null};
  const {low=state.midi,high=state.midi,share=0}=state.between??{},a=at(low),b=at(high);
  return a==null||b==null?null:a+(b-a)*share;
}

// ---- the notes: every charted note's row as the engine's rules give it at a dynamic, once; a brass partial's, its lips
// where they sound it and its players' breath ----
async function rowsOf(made,dynamic){
  const rows=[];
  for(const [k,midi] of made.notes.entries())rows.push(made.lips?lipsRow(made.lips,made.lips.notes[k].lip,made.lips.notes[k].pressures[dynamic],made.lips.notes[k].valves):await env.rulesRow(made.stream,made.model,midi,dynamic));
  return rows;
}
// A pitch on a brass instrument's lips: their frequency where the charted partials' lips stand to the pitches they
// sound, drawn between the nearest two by the logarithm, and its players' breath at it, its valves the nearer one's
// fingering; the partial heard the one the bore locks to there.
function onLips(pitch,dynamic){
  if(current.lips.slide)return onSlide(pitch,dynamic);
  const hz=440*2**((pitch-69)/12),notes=current.lips.notes,{k,share}=charted(pitch),of=n=>Math.log(n.lip/n.hz);
  const lip=hz*Math.exp(of(notes[k])+(notes.length<2?0:(of(notes[k+1])-of(notes[k]))*share));
  const valves=notes[share<.5?k:Math.min(k+1,notes.length-1)].valves??null;
  return {low:notes[k].midi,high:notes[Math.min(k+1,notes.length-1)].midi,share,sounds:null,lip,valves,row:lipsRow(current.lips,lip,lipsBreath(pitch,dynamic,{a:notes[k],b:notes[Math.min(k+1,notes.length-1)],share}),valves)};
}
// (The breath a brass pitch is blown with at `dynamic`: its players', drawn up over its onset where they blow under it,
// as its charted partials' rows are (brass-breath.mjs speakingBreath; save_brass_body.py) -- its onset its two charted
// partials' about it (`a`, `b`, `share` toward b), drawn between them by the logarithm as their lips are.)
function lipsBreath(pitch,dynamic,{a,b,share}){
  const onset=a.threshold>0&&b.threshold>0?a.threshold*(b.threshold/a.threshold)**share:a.threshold||b.threshold||null;
  return speakingBreath(440*2**((pitch-69)/12),DYNAMIC_VELOCITY[dynamic],onset);
}
// The pitch whose lips on the instrument stand at lip frequency `lip` (onLips turned about: found by halving, within its
// charted partials' pitches): the partial whose lips they are, for its attack, where the lips are dialled by themselves.
function pitchOfLips(lip,dynamic){
  let [low,high]=[current.notes[0],current.notes.at(-1)];
  if(lip<=onLips(low,dynamic).lip)return low;if(lip>=onLips(high,dynamic).lip)return high;
  for(let k=0;k<40;k++){const mid=(low+high)/2;onLips(mid,dynamic).lip<lip?low=mid:high=mid}
  return (low+high)/2;
}
// (The pitch the lips held sound: the pitch's, or where the lips were dialled by themselves, the partial's whose lips
// they are -- a trombone's, the pitch's, its slide where it stands for it; and a trombone's charted note at its own
// position -- an alternate's too -- that note's own.)
function lipsHeld(){
  const own=current.lips.slide&&state.note!=null&&current.notes[state.note]===state.pitch?current.lips.notes[state.note]:null;
  return {pitch:state.lipDialled&&!current.lips.slide?pitchOfLips(state.lip,state.dynamic):state.pitch,own};
}
// (The attack the lips held are blown with from rest.)
const attackHeld=()=>{
  if(!(current?.lips&&state.lip))return null;
  const {pitch,own}=lipsHeld();
  return attackOn(pitch,state.dynamic,own);
};
// ---- a trombone's slide ----
// (Its charted notes its players play at their standard positions -- and its open partials beyond its chart -- in order
// of pitch: where a pitch between them is played.)
function standardOf(rules){
  const charted=rules.notes.filter(n=>n.names?.length).map(n=>n.midi),[low,high]=[Math.min(...charted),Math.max(...charted)];
  return rules.notes.filter(n=>!n.alternate&&(n.names?.length||n.midi<low||n.midi>high));
}
// (The notes on partial `n` about a pitch, in order of pitch -- k at or under it, the lowest where none is -- and how far
// it stands toward the next.)
function about(notes,pitch){
  const k=Math.max(0,Math.min(notes.length-2,notes.findLastIndex(n=>n.midi<=pitch))),a=notes[k],b=notes[Math.min(k+1,notes.length-1)];
  return {a,b,share:a===b?0:Math.min(Math.max((pitch-a.midi)/(b.midi-a.midi),0),1)};
}
// (The tube that has partial `n` play `hz`: its resonance where its notes on that partial play their pitch over theirs,
// drawn between theirs by the logarithm, and that resonance found among its positions' (rules.json `slide`), drawn
// between the two about it by the logarithm -- past its first position or its seventh as the nearest two stand.)
function tubeFor(n,hz){
  const rules=current.lips,on=rules.notes.filter(m=>m.partial===n).sort((x,y)=>x.hz-y.hz),{a,b,share}=about(on,69+12*Math.log2(hz/440));
  const over=Math.exp(Math.log(a.hz/a.resonance)+(Math.log(b.hz/b.resonance)-Math.log(a.hz/a.resonance))*share),r=hz/over;
  const ps=rules.slide.positions.filter(p=>p.resonances.length>=n).map(p=>({out:p.out,r:p.resonances[n-1]}));
  const i=Math.min(Math.max(ps.findIndex(p=>p.r<=r),1),ps.length-1)||ps.length-1,[p,q]=[ps[i-1],ps[i]];
  return p.out+(q.out-p.out)*Math.log(r/p.r)/Math.log(q.r/p.r);
}
// A pitch on a trombone: on the partial of the nearer of the standard notes about it, or the other's where the nearer's
// slide cannot reach it; its slide where that partial plays it (tubeFor), within its reach; its lips where that partial's
// notes' lips stand to the pitches they sound, drawn between the nearest two by the logarithm, and its players' breath at
// it.
function onSlide(pitch,dynamic){
  const rules=current.lips,hz=440*2**((pitch-69)/12),{a,b,share}=about(standardOf(rules),pitch),most=rules.slide.most;
  const tried=(share<.5?[a,b]:[b,a]).map(n=>({partial:n.partial,out:tubeFor(n.partial,hz)}));
  const {partial,out}=tried.find(t=>t.out>=0&&t.out<=most)??tried[0];
  const on=about(rules.notes.filter(n=>n.partial===partial).sort((x,y)=>x.hz-y.hz),pitch),of=n=>Math.log(n.lip/n.hz);
  const lip=hz*Math.exp(of(on.a)+(of(on.b)-of(on.a))*on.share);
  return {low:on.a.midi,high:on.b.midi,share:on.share,sounds:null,lip,valves:null,out:Math.min(Math.max(out,0),most),partial,on,
    row:lipsRow(rules,lip,lipsBreath(pitch,dynamic,on),null)};
}
// (Where its slide stands as a position: drawn between its positions' tube, past its seventh as its sixth and seventh
// stand apart.)
function positionAt(out){
  const ps=current.lips.slide.positions,k=Math.max(0,Math.min(ps.length-2,ps.findLastIndex(p=>p.out<=out)));
  return ps[k].position+(out-ps[k].out)/(ps[k+1].out-ps[k].out);
}
// Its slide drawn to `out` m of tube as its players draw it. -> the seconds it takes.
function slideTo(out){
  const seconds=slideSeconds(state.slide??out,out);
  state.slide=out;current.stream.slide(out,seconds);
  return seconds;
}
// (The charted partial at or under a pitch, k -- the lowest where none is -- and how far it stands toward the next.)
function charted(pitch){
  const notes=current.lips.notes,k=Math.max(0,Math.min(notes.length-2,notes.findLastIndex(n=>n.midi<=pitch)));
  return {k,share:notes.length<2?0:Math.min(Math.max((pitch-notes[k].midi)/(notes[k+1].midi-notes[k].midi),0),1)};
}
// The attack a pitch on the lips is blown with from rest at a dynamic: their share of their own lips and how long after
// the breath's start they settle to them (brass-attacks.mjs), drawn between the nearest two charted partials' as their
// lips are -- where one's attack does not find it at that dynamic, the other's; null where neither's does.
function attackOn(pitch,dynamic,own=null){
  const at=n=>{const a=current.attacks?.notes.find(a=>noteKey(a)===noteKey(n))?.dynamics[dynamic];return a?.share!=null?a:null};
  const {a:na,b:nb,share}=partialsAbout(pitch,dynamic,own),a=at(na),b=at(nb);
  const kept=g=>g&&{share:g.share,settleAfter:g.settleAfter};
  if(!a||!b||share===0||share===1)return kept(share===1?b??a:a??b);
  return {share:Math.exp(Math.log(a.share)+(Math.log(b.share)-Math.log(a.share))*share),settleAfter:a.settleAfter+(b.settleAfter-a.settleAfter)*share};
}
// (The two charted partials about a pitch on the lips, and how far it stands toward the second: a trombone's two on the
// partial it is played on, or `own`, its note at its own position.)
function partialsAbout(pitch,dynamic,own=null){
  const notes=current.lips.notes,{k,share}=charted(pitch);
  return own?{a:own,b:own,share:0}:current.lips.slide?onSlide(pitch,dynamic).on:{a:notes[k],b:notes[Math.min(k+1,notes.length-1)],share};
}
// The lips' depth, cents each way along their embouchure's way, that sways the partial held `half` cents each way as it
// is heard (vibrato.json: render/node/brass-vibrato.mjs) -- each charted partial's measured swings drawn between at the
// dynamic's pressure, between the two measured about it by the logarithm, and between the two partials about the pitch
// as their lips are; the deepest its partial holds where it is not heard so wide. -> {depth, heard: cents each way},
// or null where no swing of it is measured.
function pressed(half){
  const law=current.vibrato,{pitch,own}=lipsHeld(),{a,b,share}=partialsAbout(pitch,state.dynamic,own);
  const at=n=>{
    const p=n.pressures[state.dynamic],by=Object.values(law?.notes.find(m=>noteKey(m)===noteKey(n))?.dynamics??{}).filter(d=>d.heard?.[0]!=null)
      .map(d=>({p:d.pressure,...heardAs(law.depths,d.heard,half)})).sort((x,y)=>x.p-y.p),j=by.findIndex(d=>d.p>=p);
    if(!by.length)return null;
    if(j<=0)return by.at(j);
    const [x,y]=[by[j-1],by[j]],s=Math.log(p/x.p)/Math.log(y.p/x.p);
    return {depth:x.depth+(y.depth-x.depth)*s,heard:x.heard+(y.heard-x.heard)*s};
  };
  const [x,y]=[at(a),at(b)];
  if(!x||!y||share===0||share===1)return share===1?y??x:x??y;
  return {depth:x.depth+(y.depth-x.depth)*share,heard:x.heard+(y.heard-x.heard)*share};
}
// (On one measured swing, the depth heard `half` cents each way: drawn between the depths about it, from none; the
// deepest it held where none is heard so wide.)
function heardAs(depths,heard,half){
  let [d0,h0]=[0,0];
  for(const [k,h] of heard.entries()){
    if(h==null)break;
    if(h>=half)return {depth:d0+(depths[k]-d0)*(half-h0)/(h-h0),heard:half};
    [d0,h0]=[depths[k],h];
  }
  return {depth:d0,heard:h0};
}
// The row found sounding a pitch: the glides about it measured as it is first asked for, and the rest of the dynamic's
// after.
// Where its glides are not yet measured, the two charted rows about it blended by its place between their pitches, at
// once, and the row measured to sound it taken up as soon as they are: the page's sound never waits on a measurement (2
// November 2026: the clarinet's sound stopped each time a pitch between two charted notes was asked, every pull of sound
// held behind up to four glides, each measured on an engine of its own).
async function sounding(pitch,dynamic){
  if(current.lips)return onLips(pitch,dynamic);
  const made=current,rows=made.rows.get(dynamic),asked={notes:made.notes,rows,columns:made.columns,shaded:made.shaded,glides:made.glides};
  const measured=measuredAbout(pitch,asked),found=measured?rowSounding(pitch,asked):null;
  if(!made.glided.has(dynamic)){made.glided.add(dynamic);const order=made.notes.map((m,k)=>k).sort((a,b)=>made.notes[a]-made.notes[b]);
    for(let i=1;i<order.length;i++)made.glides.glide(rows[order[i-1]],rows[order[i]]).catch(error=>{if(current===made)warn(`  a glide: ${error.message}`)})}
  if(measured)return await found;
  const still=()=>current===made&&state.pitch===pitch&&state.dynamic===dynamic&&state.between?.provisional;
  rowSounding(pitch,asked).then(found=>still()&&serial(()=>still()?settleAt(made,pitch,dynamic,false,null,found):null)).catch(error=>{if(current===made)warn(`  a glide: ${error.message}`)});
  return provisionalRow(pitch,asked);
}
// A pitch taken up: the row found sounding it (`charted`, a charted note's own), the page's dials on it, its fingers
// the row's; moved to as its player moves.
// `note`: the charted note chosen by its place among them (a trombone's alternate positions too).
async function toPitch(pitch,dynamic,charted=false,note=null,fingering=null){
  const made=current,[low,high]=[Math.min(...made.notes),Math.max(...made.notes)];
  if(note!==null){if(!(Number.isInteger(note)&&note>=0&&note<made.notes.length))throw new Error('no such charted note');pitch=made.notes[note];charted=true}
  if(!(pitch>=low&&pitch<=high)||!(dynamic in DYNAMIC_VELOCITY))throw new Error(`a pitch from ${low} to ${high}, and a dynamic`);
  if(charted&&!made.notes.includes(pitch))throw new Error('no such charted note');
  // (A reed's charted pitch on its own fingering, as its players play it, its player's ear bringing it into tune.)
  if(!charted&&made.kind==='reed'&&made.notes.includes(pitch))charted=true;
  const k=note??made.notes.indexOf(pitch);
  const found=charted?{low:pitch,high:pitch,share:0,sounds:null,row:made.rows.get(dynamic)[k],lip:made.lips?made.lips.notes[k].lip:null,valves:made.lips?.notes[k].valves??null,
    out:made.lips?.notes[k].out??null}
    :await sounding(pitch,dynamic);
  settleAt(made,pitch,dynamic,charted,k,found,fingering);
}
// (The row `found` for a pitch taken up: the page's dials on it, its fingers the row's -- `fingering`, a place among its
// note's fingerings, asked: alternates.mjs fingeringAt.)
function settleAt(made,pitch,dynamic,charted,k,found,fingering=null){
  if(current!==made)throw new Error('another instrument was taken up');
  const before=state.row,from=state.pitch,near=made.notes.reduce((a,m,j)=>Math.abs(m-pitch)<Math.abs(made.notes[a]-pitch)?j:a,0);
  // (A woodwind's note fingered as its fingers stand: of its fingerings, the one that moves the fewest holes from the row
  // held, its standard where none moves fewer -- alternates.mjs.)
  const among=made.alternates?.[made.notes[charted?k:near]],asked=fingering==null?null:fingeringAt(among,found.row,made.columns,made.holes,fingering);
  if(fingering!=null&&!asked)throw new Error(`the note has no fingering ${fingering}: ${among?.length??1} of them`);
  // (A charted note taken up at its player's settings, where its body is played with them: atSettings. A fingering the
  // page or a tool asks by its place is theirs, at its rules.)
  const set=charted&&fingering==null?made.played?.settings.get(pitch)??null:null;
  const own=asked??(set?atSettings(made,set,fingeringAt(among,found.row,made.columns,made.holes,0)??{row:found.row,documented:null},k)
    :made.alternates?fingeringAmong(among,found.row,before,made.columns,made.holes,{charted}):{row:found.row,documented:null});
  // (Its player's ear on the note, a reed's: its embouchure, then its breath, those the page has not dialled, from where
  // its ear found this note -- this pitch, on this fingering, at this dynamic -- in tune before, on whatever reed: a reed
  // changed or wetted since, its player begins where it was and its ear makes up the difference, as players do (the
  // owner, 8 November 2026: "Human players change reeds, and also change their behaviour by wetting them").)
  for(const [c,x] of Object.entries(state.pulled))if(x)state.x[c]=x;else delete state.x[c];
  state.pulled={};
  const key=made.kind==='reed'?sha1Hex(JSON.stringify({dynamic,pitch,fingering:own.documented??null,...(state.barrel!=null?{barrel:state.barrel}:{})})).slice(0,20):null,order=key?[made.reedLip?'lip':made.zeta,made.breath].filter(c=>c!=null&&!state.x[c]):[];
  // (Begun from a kept tuning only where it was heard on this engine (`cents`): one a solver wrote and nobody heard --
  // the reeds' of 8 November 2026, found by harmonic balance on an exported bore, which stood tens of cents from the
  // engine -- is no place its ear found, and its note begins at its rules' own (17 November 2026: research/
  // KNOWN_ISSUES.md MB-WIND-024).)
  const kept=key?made.tunings.kept[key]:null,was=kept?.cents!=null?kept:null;
  Object.assign(state,{earX:Object.fromEntries(Object.entries(was?.x??{}).filter(([c])=>order.map(String).includes(c))),heard:null,raised:was?.tract?.raised??null,
    tuning:order.length?{key,order}:null,ear:order.length&&!set?earOn(made,pitch,key,order):null});
  Object.assign(state,{pitch,dynamic,midi:made.notes[charted?k:near],note:charted?k:near,rules:[...own.row],fingered:own.documented,fingers:{},lip:found.lip??null,lipDialled:false,bend:0,
    valves:found.valves??null,slideDialled:false,
    between:{low:found.low,high:found.high,share:found.share,sounds:found.sounds,...found.provisional?{provisional:true}:{}}});
  state.row=composed();
  changed(before,{pitch:{from,to:pitch},moving:found.out!=null?slideTo(found.out):0});
  // (A tract dialled the page's until the pitch moves, as its holes and lips are: the pitch takes its players' tract
  // there -- the owner, 7 November 2026: "adjusting some meta-controls - pitch, especially - doesn't adjust all the
  // corresponding underlying controls, leading to a disconnect and failure to play higher pitches". Raised as it was
  // where its player was found to raise it to tune the note: tuning-solver.mjs, kept with its lip and breath.)
  state.tractFollows=tractMeasured(made.model);followed(made.model,pitch,state.raised);
  if(set?.tract){state.tractFollows=false;tract(set.tract,set.shape)}
  if(made.lips)sway();
  if(state.hum.on||state.growl.on||state.flutter.on)techniques();
}
// A charted note's row at its player's settings (research/OPENWIND_REALTIME_PLAN.md, design 10, 6; played.mjs: `set`,
// {force, pascals, tract, holes, documented}), of `own`, its row on its first fingering at the dynamic taken up, `k`
// its place among its charted notes: on the fingering its settings were found on where they name one, its lip their
// force past its rules' own (reed-lip.js), its breath their pascals over the pressure that shuts its reed at that lip
// -- found at one dynamic (`mark`), so at another its rules' breath there in the same proportion -- and its reed's
// motion's flow their share of its rules': the row its settings were heard on (tune-body.mjs settled, blownAt), the
// note's own now, from which the page's dials and its lip move it. Its ear is left off as it is taken up -- its
// settings were found by what speaks, and are played as found; the page's ear takes it from there where it is asked.
function atSettings(made,set,own,k){
  const at=made.reedAt,pressed=row=>made.reedLip&&set.force?lippedRow(row,at,made.sized,made.reedLip,set.force,made.lipDamping):row;
  const fingered=[...own.row];
  if(set.holes)made.columns.forEach((c,j)=>{if(c[0]==='opening')fingered[j]=set.holes[made.holes[c[1]]]??0});
  const row=[...pressed(fingered)],mark=made.rows.get(made.played.mark)[k];
  if(set.pascals!=null&&at?.closing_pressure!=null)row[made.breath]*=set.pascals/pressed(mark)[at.closing_pressure]/mark[made.breath];
  if(made.played.flow!=null&&at?.kappa!=null)row[at.kappa]*=made.played.flow;
  return {row,documented:set.holes?set.documented:own.documented};
}
// (Its players' tract at a pitch where the registry has their tract measured -- the reed woodwinds', theirs the
// clarinettists' so far (registry/players/winds.json) -- else none (standing.mjs playersTract): their normal tract, or
// raised toward a charted note where its fitted player raises it (its rules' values' `tract`, openwind_engine.py
// note_values); following each pitch taken up, as theirs follows the note (Chen, Smith & Wolfe 2009), a tract dialled
// held until the pitch moves, and theirs again when the page asks it to.)
const raisedAt=pitch=>{const k=current.raised?current.notes.indexOf(Math.round(pitch)):-1;return k<0?null:current.raised[k]};
const followed=(of,pitch,raised=null)=>tract(playersTract(of,440*2**((pitch-69)/12),raised??raisedAt(pitch)));
// (The tract set: its resonances as the engine steps them, and the shape they are of where they are a shape's -- a note
// of its player's settings, or one the page or a tool asks for (/tract) -- else none: its players' tract followed is
// still the baked tracks' resonances, found on the airway before a player's mouth was sealed on its mouthpiece
// (research/PLAYER_TRACT_PLAN.md, A, what is left).)
function tract(resonances,shape=null){state.tract=new VocalTract(resonances);state.shape=shape;current.stream.tract(state.tract.resonances,least('tract'))}
// (Its reed's or lips' flow's turbulence: its players' (registry/players/winds.json flow.turbulence) as it is taken up,
// none for a jet's -- whose turbulence is its law's -- and as the page dials it.)
function turbulence(level){state.turbulence=level;current.stream.turbulence(level)}
const TURBULENCE_MOST=.01;
// (Its player's noise, each kind its body's player has -- its breath's pressure, a brass player's lips' tension -- at
// the player's temperature times its own, from none to NOISE_MOST; seeded, as it is taken up, by the band's own seed
// (opening-time.js DEFAULT_SEED), each stream drawn on from there however its temperatures move.)
const NOISE_MOST=5;
function noise(temperatures,seeded=false){state.noise={...state.noise,...temperatures};
  noiseLines(current.kind,state.noise,seeded).forEach(line=>current.stream.noise(line))}

// The bore's input impedance for each charted fingering, as the reed meets it (export_impedance.py), made once a body
// and read into its instrument's `impedance` while it is still the one played; a brass instrument's its one, saved with
// its body.

// ---- an instrument taken up: behind the page, said as it goes ----
// (`wanted`: the one last chosen; `loading`: the one being made and how far it has come; `failed`: the last that could
// not be, and why, until another is chosen.)
let wanted=null,loading=null,failed=null,loader=null;
const step=said=>{if(loading)Object.assign(loading,{step:said})};
function choose(model){
  if(!env.instruments.includes(model))throw new Error(`one of ${env.instruments.join(', ')}`);
  wanted=model;failed=null;
  loader??=(async()=>{
    while(wanted&&wanted!==current?.model){
      const model=wanted;loading={model,step:'its body',since:Date.now()};
      try{await takeUp(model)}catch(error){if(wanted===model){failed={model,error:error.message};wanted=current?.model??null;warn(`The ${model}: ${error.message}`)}}
    }
    loading=null;loader=null;
  })();
}
// Its body made (or read), a fresh engine and every dynamic's rows found on it, all before a sound -- given up where
// another is chosen meanwhile -- then taken up between two of the page's pulls of sound: the one before silenced and let
// go, its neutral note as its rules play it at its dynamic (else the middle of its charted notes at the dynamic
// dialled), its players' normal tract, silent until blown.
async function takeUp(model){
  log(`The ${model}'s body ...`);
  // (Silent while the next is made: what the one played was doing let go.)
  if(current&&state.blowing)await serial(()=>{cancel('repeat');cancel('tongue');cancel('attack');cancel('breath');lungs.filled();state.blowing=false;techniques();held.breath=0;held.tongue=1;hold(state.row,least('breathFall'));sway()});
  const made=await bodyOf(model,null,()=>wanted===model,step);
  if(!made)return;
  await serial(()=>{
    const before=current;
    givenBack({played:false});
    current=made;version++;queue=[];refused=[];pace=null;soloist=null;muting=null;quiet=0;making.clear();moves=[{frame:0,path:'/within',given:{on:state.within}}];movesDropped=0;
    for(const kept of new Set([before,...bodies.values()]))if(kept&&kept!==made){kept.glides?.stop();kept.stream.close()}
    bodies.clear();bodies.set(null,made);
    atNeutral(made);
  });
  log(`  the ${model} ready${made.stream.threads>1?`, its engine on ${made.stream.threads} cores`:''}`);
}
// (`made` on its neutral note as it is first taken up, every dial the rules' and its lip its own, silent until blown.)
function atNeutral(made){
  const model=made.model;
  // (Its joints as its players set them on this body before they play, closed as made where none was found: a page
  // reloaded takes its instrument up as it was set.)
  const j=made.joints;
  if(j){j.pulls=[...j.players];made.stream.pullPoints(j.pulls).then(at=>{j.pulls=at},error=>warn(`  its joints not pulled: ${error.message}`))}
  Object.assign(state,{x:{},pulled:{},fingers:{},blowing:false,lip:null,lipDialled:false,bend:0,lipForce:0,ear:null,earX:{},heard:null,tuning:null,valves:null,slide:null,slideDialled:false,barrel:null,vibrato:{on:false,...vibratoOf(model)},row:null,pitch:null});
  Object.assign(held,{breath:0,tongue:1});
  // (Its neutral note at its dynamic, a note it sounds (neutral.mjs); where none has been found on this body, the
  // middle of its charted notes at the dynamic dialled, the page saying so.)
  if(made.neutral)state.dynamic=made.neutral.dynamic;
  const k=made.neutral?made.neutral.note:Math.floor(made.notes.length/2),middle=made.notes[k];
  // (At its player's settings where its body is played with them, as any charted note taken up: atSettings.)
  const set=made.played?.settings.get(middle)??null,own=made.rows.get(state.dynamic)[k];
  Object.assign(state,{pitch:middle,midi:middle,note:k,rules:[...(set?atSettings(made,set,{row:own,documented:null},k).row:own)],lip:made.lips?made.lips.notes[k].lip:null,valves:made.lips?.notes[k].valves??null,
    between:{low:middle,high:middle,share:0,sounds:null}});
  // (Its breath where its neutral note was found to sound: its players', or dialled from theirs.)
  if(made.neutral?.breath&&!set)state.x[made.breath]=made.neutral.breath;
  state.row=composed();state.vibrato.on=state.vibrato.width>0;
  holdAs(state.row,0);
  if(made.lips?.slide)slideTo(made.lips.notes[k].out);
  state.tractFollows=tractMeasured(model);followed(model,middle);
  if(set?.tract){state.tractFollows=false;tract(set.tract,set.shape)}
  turbulence(turbulenceLevel(model));noise({},true);sway(0);
}
// The page reloaded (live.html): its instrument as it was first taken up, and its player's settings -- its tongue, its
// breathing, its techniques, its noise, held within its body -- as the dial begins (the owner, 7 November 2026: "hard
// refresh should reset"); a soloist stopped, what was sent ahead let go.
async function afresh(){
  if(soloist?.line)await solo({on:false});
  if(state.blowing){cancel('repeat');cancel('tongue');cancel('attack');cancel('breath');lungs.filled();state.blowing=false;techniques();held.breath=0;held.tongue=1;hold(state.row,least('breathFall'));sway()}
  queue=[];refused=[];
  Object.assign(state,begun());moves=[{frame:0,path:'/within',given:{on:state.within}}];movesDropped=0;
  atNeutral(current);tongueWithin();techniques();
  return playing();
}
// (A body of `model`'s -- with `mute` in its bell, a brass one's -- as the batch made it, with a brass body's attacks
// and its neutral note, taken up at once and never made here (kept.mjs, make-bodies.mjs): its engine and every dynamic's
// rows found on it, `said` told each step; given up, null, where `still()` no longer holds.)
async function bodyOf(model,mute,still,said){
  const kind=env.kinds[model],brass=kind==='lips';
  const body=await env.body(model,{mute}),folder=body.folder;
  if(!still())return null;
  said('its engine');
  const stream=env.engine({model,folder,onError:said=>warn(`  the engine: ${said}`)});
  try{
    await stream.ready;
    const columns=await stream.columns(),rules=body.rules;
    // (A brass body's rows are its lips' columns, its valves' switches' and a mute's hollow's, in the engine's order.)
    const width=brass?rowLayout(rules)?.width??rules.columns.length:null;
    if(brass&&!(width===columns.length&&rules.columns.every(name=>columns[lipsColumn(rules,name)]?.[0]==='reed'&&columns[lipsColumn(rules,name)][2]===name)
      &&[...(rules.valves?.columns??[]).flat(),...rowLayout(rules)?.closed??[]].every(k=>columns[k]?.[0]==='opening')))throw new Error(`the ${model}'s saved rows are not its engine's columns`);
    const at=(kind_,name)=>{const k=columns.findIndex(c=>c[0]===kind_&&c[2]===name);return k<0?null:k};
    const laid=body.laid;
    // (A reed's scale as its law makes its columns -- its bore's characteristic impedance, the air's density, the reed's
    // width (law.json, controls.rs Reed::Physical) -- so that the page writes its opening in millimetres and its breath
    // in kilopascals; none for a reed given scaled, a jet or the lips.)
    const sized=!brass&&laid.reed?.kind==='physical'&&body.law?.reed?.width>0?{zc:laid.reed.zc,rho:laid.reed.rho,width:body.law.reed.width}:null;
    // (Its reed's columns by name, and its players' lip and its lip's damping (law.json lipDamping), where its lip is
    // pressed and eased by its force: reed-lip.js.)
    const reedAt=sized?Object.fromEntries(columns.map((c,k)=>[c,k]).filter(([c])=>c[0]==='reed').map(([c,k])=>[c[2],k])):null;
    const lip=reedAt&&['closing_pressure','pulsation','zeta','kappa','qfactor','contact_stifness'].every(n=>n in reedAt)?reedLip(model):null;
    const players=!brass&&laid.points?.joints?.length?env.joints?.(folder)??null:null;
    const made={model,kind,mute,folder,name:body.name,stream,columns,frames:0,flow:0,blown:null,notes:rules.notes.map(n=>n.midi),lips:brass?rules:null,sized,
      // (A reed's joints, where its body was made with them (body.json `points`: the Rust maker's, make.rs points): each
      // one's name, the range it is pulled within and the span its players set it in (m); where its players were found to
      // set it on this body (env.joints: tune-joints.mjs playersJoints), closed as made where none was, and by which notes
      // and how near (`found`); and where it stands. Its barrel the one so named, which the page pulls (/barrel).)
      joints:!brass&&laid.points?.joints?.length?{names:laid.points.joints.map(p=>p.name),range:laid.points.joints.map(p=>p.range),normal:laid.points.joints.map(p=>p.normal),
        players:laid.points.joints.map(p=>players?.pulls?.[p.name]??0),pulls:laid.points.joints.map(()=>0),found:players?{by:players.by,tuned:players.tuned}:null}:null,
      reedAt,reedLip:lip,lipDamping:lip?body.law?.lipDamping??null:null,
      // (Where each charted note stops speaking at each of its rules' velocities, a reed's: speaksAt.)
      speaks:!brass&&rules.notes.some(n=>n.values?.some(x=>x.speaks!=null))?rules.notes.map(n=>n.values.map(x=>x.speaks??null)):null,velocities:rules.velocities??null,
      // (The tract its fitted player raises at each charted note, where it raises one: standing.mjs playersTract.)
      raised:!brass&&rules.notes.some(n=>n.values?.some(x=>x.tract?.raised))?rules.notes.map(n=>n.values.find(x=>x.tract?.raised)?.tract.raised??null):null,
      attacks:brass?body.attacks:null,vibrato:brass?body.vibrato:null,heard:null,holes:laid.holes,
      // (How its body is laid out for the engine -- its losses, its mesh, its elements' order, its precision and rates:
      // the page's physics.)
      layout:{losses:laid.losses,mesh:laid.mesh,order:laid.order,single:laid.single,rate:laid.rate,ratio:laid.ratio,unknowns:laid.ni,entries:laid.nd,madeFrom:laid.madeFrom},
      breath:kind==='air'?at('flute','Uj'):at('reed','gamma'),presence:kind==='air'?at('flute','presence'):null,zeta:kind==='air'?null:at('reed','zeta'),
      // (A reed's damping and resonance, which its player's tongue on it changes: played.)
      damping:kind==='reed'?at('reed','qfactor'):null,resonance:kind==='reed'?at('reed','pulsation'):null,
      // (A brass body's lips' closing pressure and its bore's entrance -- its characteristic impedance and its air's
      // density -- their aperture's: brass-tongue.js lipsAperture.)
      closing:brass?at('reed','closing_pressure'):null,reed:brass?laid.reed??null:null,
      rows:new Map,glided:new Set,impedance:null,geometry:null,shapeless:null,
      // (Its player's settings by pitch, where its body is the one they were found on and is played with them
      // (played.mjs: {flow, mark, settings}): atSettings.)
      played:body.played??null,
      // (What players were measured doing with its dials, drawn on them: players-ranges.mjs.)
      players:windsRanges(model,kind)};
    // (The holes its fingers cover themselves, which a pitch between charted notes may hold part-way; its padded keys'
    // open or shut: blend.mjs.)
    made.shaded=brass?null:shadedColumns(model,columns,laid.holes);
    // (Each note's fingerings among which its player chooses by where its fingers stand: alternates.mjs.)
    made.alternates=brass?null:body.alternates??null;
    made.glides=brass?null:env.glides({model,folder,columns,shaded:made.shaded});
    // (What its player's ear found each note's lip and breath to be, kept: {kept, keep(kept)} -- the Mac's written as it
    // finds them, the page's those the Mac kept.)
    made.tunings=env.tunings?.(folder)??{kept:{}};
    // (Its neutral note, where make-bodies.mjs found one on this body and these rules: neutral.mjs.)
    made.neutral=env.neutral(folder);
    if(made.neutral&&made.notes[made.neutral.note]!==made.neutral.midi)made.neutral=null;
    // (Every dynamic's rows found now, before a sound: asked of the engine while it plays, a dynamic's took it some 50 ms
    // from its sound, a stutter each time a new one was dialled.)
    for(const dynamic of Object.keys(DYNAMIC_VELOCITY)){
      said(`its notes at ${dynamic}`);made.rows.set(dynamic,await rowsOf(made,dynamic));
      if(!still()){stream.close();return null}
    }
    env.impedance(made,{current:()=>current===made});
    env.geometry?.(made,{current:()=>current===made});
    return made;
  }catch(error){stream.close();throw error}
}
// A mute put in, or taken out (null), as its players do it: asked now, its body taken up behind the page where none of
// it is kept yet (readied), and put in at the first frame both it is ready and the bell is quiet (`pulled`:
// changedOver). `ready`: its body only made ready, as a player takes the mute out onto its stand for a passage to come,
// the one in kept.
function muteTo(mute,{ready=false}={}){
  const model=current.model,own=BRASS_MUTES[model]??{};
  if(mute!==null&&!Object.hasOwn(own,mute))throw new Error(Object.keys(own).length?`the ${model}'s mutes: ${Object.keys(own).join(', ')}, or none`:`the ${model} takes no mute`);
  if(ready){readied(mute).catch(error=>warn(`The ${model}'s ${mute} mute: ${error.message}`));return}
  if(mute===current.mute){muting=null;return}
  const asked={mute,made:bodies.get(mute)??null,error:null,since:Date.now()};
  muting=asked;
  if(asked.made)return;
  readied(mute).then(made=>{if(muting===asked&&made)asked.made=made},error=>{asked.error=error.message;if(muting===asked)warn(`The ${model}'s ${mute} mute: ${error.message}`)});
}
// (A mute's body for the one played, kept beside it once made (`bodies`), each made once however often it is asked
// meanwhile (`making`: its step); null where another instrument is taken up first.)
const making=new Map;
let closed=false;
function readied(mute){
  if(bodies.has(mute))return Promise.resolve(bodies.get(mute));
  if(making.has(mute))return making.get(mute).promise;
  const model=current.model,kept=()=>!closed&&current?.model===model,job={step:'its body'};
  const done=()=>{if(making.get(mute)===job)making.delete(mute)};
  job.promise=bodyOf(model,mute,kept,said=>{job.step=said}).then(made=>{
    done();
    if(!made)return null;
    if(kept()&&!bodies.has(mute)){bodies.set(mute,made);return made}
    made.stream.close();return kept()?bodies.get(mute)??null:null;
  },error=>{done();throw error});
  making.set(mute,job);
  return job.promise;
}
// (The mute asked put in now: its body played from this frame, the dial's clock going on, its note -- the charted note
// it was, or the pitch on its lips -- its dynamic and every dial the page set kept on its rows, its tract, turbulence,
// player's noise, techniques and vibrato its engine's too, silent until blown; the body before kept as it is.)
function changedOver(){
  const from=current,to=muting.made;muting=null;
  to.frames=from.frames;to.flow=0;to.blown=null;current=to;
  const [low,high]=[Math.min(...to.notes),Math.max(...to.notes)],pitch=Math.min(Math.max(state.pitch,low),high);
  const k=state.midi===state.pitch?to.notes.indexOf(pitch):-1;
  const found=k>=0?{row:to.rows.get(state.dynamic)[k],lip:to.lips.notes[k].lip,valves:to.lips.notes[k].valves??null,out:to.lips.notes[k].out??null,low:pitch,high:pitch,share:0,sounds:null}
    :onLips(pitch,state.dynamic);
  const near=to.notes.reduce((a,m,j)=>Math.abs(m-pitch)<Math.abs(to.notes[a]-pitch)?j:a,0);
  Object.assign(state,{pitch,midi:to.notes[k>=0?k:near],note:k>=0?k:near,rules:[...found.row],lip:state.lipDialled?state.lip:found.lip,bend:0,valves:found.valves??null,
    between:{low:found.low,high:found.high,share:found.share,sounds:found.sounds}});
  state.row=composed();
  holdAs(state.row,0);
  // (A trombone's slide where the partial sounds the pitch with the mute in -- its players set it there by ear -- or
  // where the page drew it.)
  if(to.lips.slide){state.slide=state.slideDialled||found.out==null?state.slide:found.out;if(state.slide!=null)to.stream.slide(state.slide,0)}
  tract(state.tract.resonances,state.shape);turbulence(state.turbulence);noise({},true);techniques();sway(0);
  log(`  the ${to.model} ${to.mute?`with its ${to.mute} mute in`:'open'}`);
}

// (The engine's work one at a time -- its sound, and an instrument taken up between two pulls of it -- one that fails
// not stopping the next.)
let rendering=Promise.resolve();
const serial=job=>rendering=rendering.catch(()=>{}).then(job);
// Its sound pulled to `frames` more, each change to come made at the frame it falls on. Its pace: the seconds its engine
// takes for a block of sound over the block's own, averaged over the last score or so, shown on the page; begun again for
// each instrument. None played yet: silence.
let pace=null;
async function pulled(frames){
  if(!current)return new Float32Array(frames);
  // (The musebot playing: what of its line is due sent first, to the frames it falls on; said once it has played it.)
  if(soloist?.line){const now=current.frames/WINDS_RATE;await soloist.line.take(now);if(soloist.line.done(now)){soloist={said:soloist.line.shown(now),playing:false};await givenBack()}}
  const t=performance.now(),out=new Float32Array(frames);
  let made=current;
  // (A mute asked put in at the first frame its body is ready and the bell quiet: between a frame's changes, those
  // after it -- a note begun -- played on it.)
  const changing=()=>Boolean(muting?.made)&&!state.blowing,over=()=>{if(changing()&&made.frames>=quiet){changedOver();made=current}};
  for(let got=0;got<frames;){
    over();
    while(queue.length&&queue[0].at<=made.frames){await queue.shift().run();over()}
    // (Its breath spent as it plays: the air its engine let into its bore meanwhile, rendered to the frame where it runs
    // out at the flow it last let in.)
    const spending=spends(),flow=made.flow;
    const next=Math.min(frames-got,queue.length?queue[0].at-made.frames:frames-got,spending&&flow>0?Math.max(1,Math.ceil(lungs.secondsLeft(flow)*WINDS_RATE)):Infinity,
      changing()&&quiet>made.frames?quiet-made.frames:Infinity);
    out.set(await made.stream.render(next),got);got+=next;made.frames+=next;
    const air=await made.stream.air();
    if(air.seconds>0)made.flow=air.litres/air.seconds;
    // (The flow it last let in as it was blown, as the page shows it.)
    if(state.blowing&&!lungs.taking&&made.flow>0)made.blown=made.flow;
    if(spending&&current===made&&lungs.spend(made.flow,air.seconds))breathe();
  }
  listened(out);
  // (The solver's sound in place of the engine's, where asked: the engine played on beneath it, its ear on it.)
  if(hearing&&solved?.model===current.model){const s=solved.samples;for(let k=0;k<frames;k++){out[k]=s[solved.at];solved.at=(solved.at+1)%s.length}}
  const taken=(performance.now()-t)/1000/(frames/WINDS_RATE);
  pace=pace==null?taken:.9*pace+.1*taken;return out;
}
// ---- the solver at what the page plays (the owner, 8 November 2026: "Before launching the solver, we must make sure
// everything is using the same code by having me create sounds using the dial-in page and determining whether they match
// what the solver can calculate"; "Not just the pitch - this will be a test of whether what I hear matches what the
// solver calculates"; "I'm going to test the dynamic range of the instrument also"): the page's settings -- the ear's
// moves and the tract as they stand -- taken up by a dial of the solver's own, the same code on one core, heard nowhere;
// its note blown there from rest as the page blows one, and its oscillation then found on that engine (orbit.rs). Its
// pitch, level and harmonics beside those of the sound heard here now, both read alike; the two rows compared column by
// column; and its sound, a whole number of its periods, heard in place of this dial's where asked, through this dial's
// own output, at its level. ----
// (Its dial's breath off `rest` s before, its note blown `blown` s; its orbit warmed `warm` s at its row, so many
// multipliers sought, `seconds` of its sound; harmonics read to the `harmonics`th.)
const SOLVE=Object.freeze({rest:.5,blown:1,warm:.1,multipliers:8,seconds:4,harmonics:12});
let solver=null,solving=false,solved=null,hearing=false;
// (`sound`'s level -- its root mean square, dB of full scale -- and, at `hz`, each harmonic's: its Hann-windowed share at
// that frequency, under 0.45 of the rate.)
function readOf(sound,hz){
  const n=sound.length,w=Float64Array.from({length:n},(_,k)=>.5-.5*Math.cos(2*Math.PI*k/(n-1))),sw=w.reduce((a,b)=>a+b,0),harmonics=[];
  for(let h=1;hz&&h<=SOLVE.harmonics&&h*hz<.45*WINDS_RATE;h++){
    const a=2*Math.PI*h*hz/WINDS_RATE;let re=0,im=0;
    for(let k=0;k<n;k++){const v=sound[k]*w[k];re+=v*Math.cos(a*k);im-=v*Math.sin(a*k)}
    harmonics.push(+(20*Math.log10(2*Math.hypot(re,im)/sw)).toFixed(1));
  }
  return {hz:hz??null,midi:hz?69+12*Math.log2(hz/440):null,level:+(10*Math.log10(sound.reduce((a,x)=>a+x*x,0)/n)).toFixed(1),harmonics};
}
async function solve(){
  if(solving)throw new Error('the solver is still at the last sound');
  // (The dial's own sound heard again until the new one is asked for.)
  solving=true;hearing=false;
  try{
    const model=current.model,mute=current.mute??null,since=performance.now(),settings=settingsOf(),name=k=>current.columns[k].join(':');
    // (The ear's moves in its dials and its lip; the tract as it stands, raised or dialled, not the players' again.)
    for(const k of Object.keys(state.earX))if(k!=='lip')settings.dials[name(k)]=placed(Number(k));
    if(settings.lipForce!=null)settings.lipForce+=state.earX.lip??0;
    Object.assign(settings,{tractFollows:false,tract:state.tract?.resonances??[]});
    const blowing=state.blowing&&!lungs.taking,hz=blowing?seriesPitch(recent,WINDS_RATE).hz:null,dial=readOf(recent.slice(),hz);
    if(solver&&(solver.model!==model||solver.mute!==mute)){await solver.dial.close();solver=null}
    if(!env.quietDial)throw new Error('The solver blows the note on a second dial beside this one, which this page has not.');
    solver??={model,mute,dial:await env.quietDial(model,{threads:1,mute})};
    const d=solver.dial;
    await d.post('/blow',{on:false});await d.pull(SOLVE.rest);
    const {loaded}=await d.post('/settings',{settings});
    await d.post('/blow',{on:true});await d.pull(SOLVE.blown);
    const its=(await d.get('/settings')).plays.row,ours=settings.plays.row;
    const rows=Object.keys(ours).filter(c=>its[c]!==ours[c]).map(c=>({column:c,dial:ours[c],solver:its[c]}));
    const o=await d.post('/orbit',{warm:SOLVE.warm,multipliers:SOLVE.multipliers,seconds:SOLVE.seconds});
    const bytes=Buffer.from(o.sound??'','base64'),samples=new Float32Array(bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.length));
    solved=o.sounds&&samples.length?{model,samples,at:0}:null;if(!solved)hearing=false;
    const found=o.sounds?{...readOf(samples.subarray(0,Math.min(samples.length,SERIES.reading)),o.hz),heard:seriesPitch(samples,WINDS_RATE).hz,holds:o.holds,multipliers:o.multipliers,closing:o.closing,closings:o.closings,linear:o.linear,newton:o.newton,maps:o.maps}:{why:o.why};
    return {pitch:state.pitch,blowing,dial,solver:{sounds:o.sounds,...found},rows,refused:loaded.refused,hearing,seconds:+((performance.now()-since)/1000).toFixed(1)};
  }finally{solving=false}
}
// ---- the note held at its pitch and its level: its controls and its orbit solved together, along a path ----
// (The owner, 8 November 2026, of a start found growing at its pitch that sounded 57 cents flat once loud: "how do we
// compute the correct values for the player to fix this?"; 9 November 2026: "The solver needs to solve"; "We need to
// compute the solution, not apply trial and error"; design approved: "Yes, build that, and ABSOLUTELY NO BRUTE FORCE";
// "Ok, continue building".) The note held at its player's lip, breath and tract -- its orbit on the engine's one-period
// map -- followed along a path from where it sounds to what is asked: its pitch and its level moved together, a share of
// the way at a time, its controls by the least move, each over its span, that keeps it on them (orbit.rs tune's
// tangent). Each step goes as far as the path's own bend allows -- the second derivative of its pitch and its level
// along its tangent, read on the engine's map where it stands (orbit.rs bend) -- so that its prediction stands within
// HELD.error of the path; there Newton's method closes it on the path, its orbit and its controls solved together
// (orbit.rs tune), within HELD.cents and HELD.level. Nothing in it is tried and taken back, and no step's length depends
// on where a step before landed. A control that meets its player's reach (its lip from none at all to short of shutting
// its reed, body.mjs lipReach; its breath to the most a mouth holds; its tract's kept resonance over its shapes) is
// stepped to it and held there, the others solved for; where too few are left for both, or its controls no longer move
// its pitch and its level apart, its level is left free: the note in tune as loud or as soft as its reach allows. Begun
// from the note's own controls -- the page's, its ear's moves left out -- and its note picked up as it sounds there,
// its period sought near the pitch its start from silence grows at (starts.rs grows), never across every pitch: a
// near-silent sound's 163 Hz was once taken for the clarinet's E6. Its lip and its breath's place as the page composes
// its row; its tract's kept resonance -- its second, the one players keep (Chen, Smith & Wolfe 2009) -- moved alone,
// where its players' tract is measured, or, where its tract is a shape's, the shape's four coordinates (heldPlayer).
// Each rate read from the map moved HELD.moves either side of the note: a newton of lip, the breath's place, an octave
// of the tract's resonance, a vowels' spread along each coordinate, or a shaded hole's opening's root -- the clarinet's
// G4's so read agree with the held notes the engine plays either side within a thousandth of a cent and of a decibel
// (test/audio/winds-dial-held.test.mjs). Asked to shade (`given.shade`: a bend), each finger hole its fingering leaves
// open is a control too (heldPlayer). At each point it closes on, its multipliers are held within 1 (research/
// PLAYER_TRACT_PLAN.md, Proposed 10; orbit.rs tune): one past 1, or one its step would take past 1, held at
// HELD.holding -- a disturbance's share left after a period, so that one dies away to 1/e within a hundred periods --
// as a control is held at its reach, the rest solved for; one its tangent would grow, standing within HELD.edge of that,
// held where it stands; and a step along its path going no further than takes one it does not hold to HELD.holding.
// Where nothing is left free to hold them, its path ends at the furthest point that holds, and says so.
const HELD=Object.freeze({warm:.1,multipliers:48,points:100,corrections:6,turns:8,error:{cents:1,level:.25},cents:.1,level:.1,moves:{lip:5e-3,breath:5e-3,tract:5e-3,hole:5e-3},
  holding:.99,edge:.005});
// (A dial's place as the page has it, its ear's moves left out.)
const ownPlaced=k=>Math.max(-1,Math.min(1,state.x[k]??0));
// (The row the page would hold at the lip `lip` (N from the note's own) and the breath's place `breath`, the holes'
// columns `holes` at their openings ({column: opening}), its other dials and holes at their own places.)
function heldRowAt(lip,breath,holes={}){
  const rules=state.rules,b=current.breath;
  const lipped=current.reedLip&&lip?lippedRow(rules,current.reedAt,current.sized,current.reedLip,lip,current.lipDamping):rules;
  return played(lipped.map((v,k)=>current.columns[k][0]==='opening'?holes[k]??state.fingers[k]??v:ofDial(k,v,k===b?breath:ownPlaced(k))));
}
// (The columns of the holes named in `holes` ({label: opening}, body.json's labels), at those openings: every column of
// a hole together, as /hole sets them.)
const holesOpened=holes=>Object.fromEntries(holes?current.columns.flatMap((c,k)=>c[0]==='opening'&&holes[current.holes[c[1]]]!=null?[[k,Number(holes[current.holes[c[1]]])]]:[]):[]);
// (The finger holes a held note's player may shade: those its fingers cover themselves (blend.mjs shadedColumns) that
// its fingering leaves open and the page has not shut -> [{name: its label, columns, open: its opening in the rules}].)
function fingersOpen(){
  const holes=new Map;
  current.columns.forEach((c,k)=>{
    if(c[0]!=='opening'||!current.shaded?.has(k)||!(state.rules[k]>0)||state.fingers[k]===0)return;
    const name=current.holes[c[1]];
    if(!holes.has(name))holes.set(name,{name,columns:[],open:0});
    const h=holes.get(name);h.columns.push(k);h.open=Math.max(h.open,state.rules[k]);
  });
  return [...holes.values()];
}
// (The kept resonance's frequencies over its shapes, the shapes' whole span of it in octaves.)
const keptSpan=()=>{const fs=Object.values(TRACT_SHAPES).flatMap(s=>s.rows.map(r=>r.resonances[1]?.frequency).filter(Boolean));return Math.log2(Math.max(...fs)/Math.min(...fs))};
// (Its player's controls as the solve takes them: their names, each one's span, reach and move, and where `c` -- {lip,
// breath, tract}, the tract's kept resonance in Hz, or {lip, breath, coord0 ... coord3}, its shape's coordinates, and,
// asked to shade (`shade`), each open finger hole's opening under its label -- stands in their units (its kept
// resonance's in octaves, a hole's opening's root); the row and the tract at `c`, and moved either side.)
function heldPlayer({shade=false}={}){
  // (A tract that is a shape's -- a note of its player's settings -- moved as its shape: its four coordinates, each
  // within its bounds (tractBounds) and over the vowels' spread along it (vowelSpread), as the joint finding moves them;
  // each move's resonances its shape's own (shapedTract, each fitted once a solve), every tract one engine call is given
  // put in the same places, its own first (placedTract): the engine carries a tract's resonances by their order. Not
  // its second resonance moved alone: there its second is its mouth's own, sealed on the mouthpiece, not the one its
  // players keep (research/KNOWN_ISSUES.md MB-WIND-021; research/PLAYER_TRACT_PLAN.md, Proposed 9).)
  const measured=tractMeasured(current.model)&&state.tract?.resonances?.length>1;
  const shape=measured&&state.shape?state.shape:null;
  const tractNow=measured&&!shape?state.tract.resonances.map(r=>({...r})):null;
  const reach=lipNow(),most=breathPlace(),spread=vowelSpread(),bounds=tractBounds();
  const coords=shape?shape.coords.map((_,k)=>`coord${k}`):[],coordAt=new Map(coords.map((n,k)=>[n,k]));
  // (Each finger hole its fingering leaves open, asked to shade: its opening moved from where it stands toward shut,
  // over its whole opening -- in its opening's root, as the engine's radiation takes it (kernel.rs
  // radiation_coefficients: its loss on the root of its opening), so that its rates read as well near shut as open --
  // from a move's width above shut, so that its rates are read either side, to as open as its fingering leaves it.)
  const holes=shade?fingersOpen():[],holeAt=new Map(holes.map(h=>[h.name,h]));
  const names=['lip','breath','tract',...coords,...holes.map(h=>h.name)].filter(n=>n==='lip'?current.reedLip:n==='tract'?tractNow:true);
  const spans={lip:reach?reach[1]-reach[0]:LIP_FORCE[1]-LIP_FORCE[0],breath:2,tract:keptSpan(),...Object.fromEntries(coords.map((n,k)=>[n,spread[k]])),
    ...Object.fromEntries(holes.map(h=>[h.name,Math.sqrt(h.open)]))};
  const reaches={lip:current.reedLip&&current.sized?lipReach(state.rules,current.reedAt,current.reedLip,[-Infinity,Infinity]):null,breath:[-1,most],tract:tractNow?tractReach():null,
    ...Object.fromEntries(coords.map((n,k)=>[n,bounds[k]])),...Object.fromEntries(holes.map(h=>[h.name,[HELD.moves.hole**2,h.open]]))};
  const unit=(n,v)=>n==='tract'?Math.log2(v):holeAt.has(n)?Math.sqrt(v):v,value=(n,u)=>n==='tract'?2**u:holeAt.has(n)?Math.max(0,u)**2:u;
  const tracts=c=>tractNow&&tractNow.map((r,k)=>k===1?{...r,frequency:c.tract}:r);
  // (The columns of its shaded holes at `c`'s openings.)
  const opened=c=>Object.fromEntries(holes.flatMap(h=>c[h.name]==null?[]:h.columns.map(k=>[k,c[h.name]])));
  const rowAt=c=>heldRowAt(c.lip,c.breath,opened(c));
  // (Its shape at `c`, and its resonances there, fitted once.)
  const shapeAt=c=>shape&&{coords:coords.map(n=>c[n]),glottis:shape.glottis};
  const fits=new Map(shape?[[shape.coords.join(),state.tract.resonances]]:[]);
  const fitted=c=>{const s=shapeAt(c),k=s.coords.join();if(!fits.has(k))fits.set(k,shapedTract(s));return fits.get(k)};
  // (The tracts at `cs`, the first the one the call stands at, in the same places: the page's own first, each place then
  // standing where that first tract has it; each tract given every place, one it lacks at no peak.)
  let places=shape?state.tract.resonances.map(r=>({...r})):null;
  const placed=cs=>{
    if(!shape)return cs.map(c=>tracts(c)||null);
    const lists=cs.map((c,i)=>{const p=placedTract(fitted(c),places);places=i?p.places:p.places.map((q,k)=>p.resonances[k].peak>0?p.resonances[k]:q);return p.resonances});
    return lists.map(l=>[...l,...places.slice(l.length).map(p=>({frequency:p.frequency,q:p.q,peak:0}))]);
  };
  const tracted=n=>n==='tract'||coordAt.has(n);
  // (A control's value `v` moved `d` of its units.)
  const shifted=(n,v,d)=>n==='tract'?v*2**d:holeAt.has(n)?Math.max(0,Math.sqrt(v)+d)**2:v+d;
  const moved=(c,n,s,by)=>({...c,[n]:shifted(n,c[n],s*by)});
  const reach_=names.map(n=>{const r=reaches[n];return r?[r[0]!=null&&Number.isFinite(r[0])?unit(n,r[0]):null,r[1]!=null&&Number.isFinite(r[1])?unit(n,r[1]):null]:[null,null]});
  const at=c=>names.map(n=>unit(n,c[n]));
  return {names,spans,reaches,tractNow,shape,holes,unit,value,at,reach:reach_,shapeAt,
    // (The row and the tract at `c`.)
    rows:c=>({row:rowAt(c),tract:placed([c])[0]}),
    // (Each control's move: HELD.moves's, a coordinate's its tract's share of the vowels' spread along it.)
    moves:m=>Object.fromEntries(names.map(n=>[n,coordAt.has(n)?m.tract*spread[coordAt.get(n)]:holeAt.has(n)?m.hole:m[n]])),
    // (The row and the tract at `c`, and each control moved either side by `moves`: its row, or its tract.)
    rated:(c,moves)=>{
      const sides=names.map(n=>[1,-1].map(s=>moved(c,n,s,moves[n]))),lists=placed([c,...sides.flatMap((p,j)=>tracted(names[j])?p:[])]);
      let k=1;
      return {row:rowAt(c),tract:lists[0],moved:sides.map((p,j)=>p.map(m=>tracted(names[j])?{tract:lists[k++]}:{row:rowAt(m)}))};
    },
    // (The row and the tract at `c`, and at each of the controls `cs` along its path.)
    along:(c,cs)=>{const lists=placed([c,...cs]);return {row:rowAt(c),tract:lists[0],along:cs.map((m,i)=>({row:rowAt(m),...(lists[i+1]?{tract:lists[i+1]}:{})}))}},
    // (Its controls as the page shows them, {lip, breath, coords, holes: {label: opening}}, and taken from it.)
    shown:c=>{
      if(!shape&&!holes.length)return c;
      const o={...c};for(const n of [...coords,...holeAt.keys()])delete o[n];
      return {...o,...(shape?{coords:coords.map(n=>c[n])}:{}),...(holes.length?{holes:Object.fromEntries(holes.map(h=>[h.name,c[h.name]]))}:{})};
    },
    taken:c=>{const o={...c};delete o.coords;delete o.holes;if(shape&&Array.isArray(c.coords))coords.forEach((n,k)=>{o[n]=c.coords[k]});
      for(const [n,v] of Object.entries(c.holes??{}))if(holeAt.has(n)&&v!=null)o[n]=Number(v);return o},
    // (Its controls moved by `d`, in their units.)
    step:(c,d)=>({...c,...Object.fromEntries(names.map((n,j)=>[n,shifted(n,c[n],d[j])]))}),
    // (Those at their reach, within a millionth of their span.)
    held:c=>names.filter((n,j)=>{const v=at(c)[j],[lo,hi]=reach_[j],near=1e-6*spans[n];return lo!=null&&v-lo<=near||hi!=null&&hi-v<=near})};
}
// (The note's own controls: its lip and its breath's place as the page has them, its ear's moves left out, and its
// tract's kept resonance, or its shape's coordinates; and the openings of the holes it shades, as the page has them.)
const heldNow=(player,b=current.breath)=>({lip:current.reedLip?state.lipForce:0,breath:ownPlaced(b),...(player.tractNow?{tract:player.tractNow[1].frequency}:{}),
  ...(player.shape?player.taken({coords:player.shape.coords}):{}),...Object.fromEntries(player.holes.map(h=>[h.name,state.fingers[h.columns[0]]??state.rules[h.columns[0]]]))});
// The lip, breath and tract that hold its note at `given.hz` (the note's own where none) at the level it sounds at, or
// at `given.level` (dB, as its orbits read it), found along its path (above) -> its steps (each closed on the path, and
// each predicted along it), the points it closed on, the controls found, its pitch, level, rates and multipliers there,
// those held at their reach, and whether its level was left free; or why none -- a shape's coordinates as `coords`, each
// one's rates, reach and pin under its name, coord0 to coord3. `given.at`: begun from those of its lip, breath and tract,
// or its shape's `coords` (the rest its own); `given.begin`: begun from the orbit saved under that name, its pitch
// `given.fromHz` and level `given.fromLevel` -- a held note followed from one found before, as its player moves from
// where it last sounded (held-ranges.mjs) -- not from the note as it sounds; `given.save`: the orbit found saved under
// that name; `given.apply`: the page moved to its controls along its path -- to the furthest point that holds, where
// its path ends there -- its ear's moves set aside; `given.shade`: its open finger holes shaded too, each one's opening
// under its label in `holes` (a bend); `given.holding` false: its multipliers not held within 1, its note checked at its
// end alone; `given.moves`, `given.warm`, `given.multipliers`: in place of HELD's.
async function heldAt(given){
  if(!current?.stream||!state.rules)throw new Error('a note taken up first');
  if(current.kind!=='reed'||current.breath==null)throw new Error('a reed\'s note: held by its lip and its breath');
  if(!given.begin&&(!state.blowing||lungs.taking))throw new Error('its note blown: its held note is picked up from it as it sounds');
  // (Its ear's search left: these moves are its player's.)
  state.ear=null;
  const since=performance.now(),hz=Number(given.hz??440*2**((state.pitch-69)/12)),b=current.breath,player=heldPlayer({shade:Boolean(given.shade)}),{names}=player;
  // (Its multipliers held within 1, unless asked not to: those held at the point before (their values there), followed.)
  const holding=given.holding===false||Number(given.multipliers??HELD.multipliers)<=0?null:HELD.holding;
  let held=[];
  const holdingAsked=()=>holding?{holding,holding_near:HELD.edge,held}:{};
  const heldOf=t=>(t.watched??[]).filter(m=>m.held||m.tangent_held).map(m=>m.value);
  const moves=player.moves({...HELD.moves,...given.moves}),spans=names.map(n=>player.spans[n]);
  let at=heldNow(player,b);
  const begun=player.taken(given.at??{});
  for(const n of Object.keys(begun))if(n in at&&begun[n]!=null)at[n]=Number(begun[n]);
  const finite=r=>[r.row,...(r.moved??[]).flat().map(m=>m.row??[]),...(r.along??[]).map(m=>m.row??[])].every(row=>row.every(Number.isFinite));
  const unrowed={found:null,why:'its row has no value there: its lip past the force that shuts its reed',kind:'sounds no more'};
  // (Its note picked up where it sounds, or the orbit it begins from.)
  let fromHz,fromLevel=null,picked=null;
  if(given.begin!=null){
    fromHz=Number(given.fromHz);fromLevel=Number(given.fromLevel);
    if(!(fromHz>0)||given.fromLevel==null||!Number.isFinite(fromLevel))throw new Error('the pitch and the level of the orbit begun from, `fromHz` and `fromLevel`');
  }else{
    if(!finite(player.rows(at)))return {hz,level:given.level??null,...unrowed,steps:[],points:[],reaches:player.reaches,seconds:(performance.now()-since)/1000};
    const g=await current.stream.grows({...player.rows(at),hz}),near=g.hz>0?g.hz:hz;
    const o=await current.stream.pick({...player.rows(at),warm:given.warm??HELD.warm,near});
    picked={near,grows:g.hz!=null,hz:o.hz??null,level:o.sounds?o.level:null,why:o.why??null};
    if(!o.sounds)return {hz,level:given.level??null,found:null,why:`its note at its controls: ${o.why}`,kind:'sounds no more',picked,steps:[],points:[],reaches:player.reaches,seconds:(performance.now()-since)/1000};
    await current.stream.saveOrbit(HELD_ORBIT,true);
    fromHz=o.hz;fromLevel=o.level;
  }
  const from=given.begin!=null?String(given.begin):HELD_ORBIT;
  // (Its path: from the note as it is to the pitch and level asked, its aim the point on it it is closed on next: the
  // share `share` of the way from the point closed last, `anchor`, to its end, in its period and its level -- `progress`
  // of the whole way, the anchor's. Each step of Newton's method solves for that share too, a share weighed as its
  // controls' move along its tangent (`weight`).)
  const goal={hz,level:given.level!=null?Number(given.level):fromLevel};
  let anchor={hz:fromHz,level:fromLevel},share=0,progress=0,weight=0,face=null,test=null,levelFree=false,orbit=from,found=null,why=null,kind=null,t=null;
  const aimAt=(s=share)=>s>=1?{...goal,level:levelFree?null:goal.level}:{hz:1/(1/anchor.hz+s*(1/goal.hz-1/anchor.hz)),level:levelFree?null:anchor.level+s*(goal.level-anchor.level)};
  const ends=aim=>aim.hz===goal.hz&&(levelFree||aim.level===goal.level);
  const steps=[],points=[];
  const ask=(extra,c=at)=>({...player.rated(c,moves),moves:names.map(n=>moves[n]),at:player.at(c),spans,reach:player.reach,
    cents:HELD.cents,decibels:HELD.level,from:orbit,save:HELD_ORBIT,...extra});
  // (Where its note leaves what its rates and second derivatives said of the step that took it there -- read further
  // from its pitch or its level predicted than the whole move predicted, and than HELD.error -- it is extremely
  // sensitive there: flagged speculative, its tolerance stated (each control's move it was taken across, the most it can
  // be there), and its path ends there, not mapped further (the owner, 9 November 2026: "these zones of extreme
  // sensitivity can be of interest for extended techniques but we should flag them as speculative ... whether to
  // actually map and compose for them precisely is for later artistic work"; "This is why we need to state parameter
  // tolerances when we're mapping multiphonics and extended techniques"). `expect`: the step's prediction, from where.)
  const speculative=[];let expect=null;
  const jumped=r=>{
    if(!expect||!r.sounds)return false;
    const x=expect,dc=1200*Math.log2(r.hz/x.hz),dl=r.level-x.level,cc=1200*Math.log2(x.hz/x.from.hz),cl=x.level-x.from.level;
    if(!(Math.abs(dc)>Math.max(Math.abs(cc),HELD.error.cents)||Math.abs(dl)>Math.max(Math.abs(cl),HELD.error.level)))return false;
    const moved=player.at(x.to),was=player.at(x.from.at);
    speculative.push({...x.to,hz:r.hz,level:r.level,predicted:{hz:x.hz,level:x.level},from:{...x.from.at,hz:x.from.hz,level:x.from.level},
      tolerance:Object.fromEntries(names.map((n,j)=>[n,Math.abs(moved[j]-was[j])]))});
    return true;
  };
  const flagged=()=>{const z=speculative.at(-1);return `its note leaves what its rates and second derivatives say there, ${z.hz.toFixed(3)} Hz and ${z.level.toFixed(2)} dB for ${z.predicted.hz.toFixed(3)} Hz and ${z.predicted.level.toFixed(2)} dB: extremely sensitive, flagged speculative, its tolerance under ${names.map(n=>`${z.tolerance[n].toExponential(1)} of its ${n}`).join(', ')}`};
  // (Where its path turns back, solved: the most of its way its note is held on it, those controls held at their reach
  // as they are -- where the controls `free` left no longer move its pitch and its level apart. Its pitch's and its
  // level's multipliers ν turn their rates to nothing (Gᵀν = 0, and aᵀν = -1, `a` the path's own rates over its share)
  // with its note on the path there (F = 0): Newton's method on all of them, begun from `c` at the share `s`, its
  // controls' second derivatives read on the engine's map as its bend is (orbit.rs bend), each control moved alone and
  // each pair together, its multipliers begun from the least ones its rates allow. A control that leaves its reach is
  // held there and the rest solved for again. -> its controls there, its share and its note read there; `past`: its path
  // turns back nowhere before its end; or why none.)
  const turnAt=async(c,s,free)=>{
    let nu=null,last=null;
    for(let i=0;i<HELD.turns;i++){
      const aim=aimAt(s),e=await current.stream.tune(ask({from_hz:fromHz,hz:aim.hz,level:aim.level,stay:true,multipliers:Number(given.watch??0)},c));
      orbit=HELD_ORBIT;
      if(!e.sounds)return {why:e.why};
      if(jumped(e))return {why:flagged(),speculative:true};
      fromHz=e.hz;
      const rows=levelFree?1:2,F=[e.cents,e.off].slice(0,rows);
      const a=[-1200*(1/goal.hz-1/anchor.hz)*aim.hz/Math.LN2,goal.level-anchor.level].slice(0,rows);
      const G=free.map(j=>e.rates[j].slice(0,rows)),n=free.length;
      steps.push({...c,kind:'turning',share:s,hz:e.hz,cents:e.cents,level:e.level,rates:e.rates,free:free.map(j=>names[j]),multipliers:e.multipliers,maps:e.maps});
      if(last&&F.every((f,r)=>Math.abs(f)<=(r?HELD.level:HELD.cents)&&Math.abs(last*a[r])<=(r?HELD.level:HELD.cents)))return {at:c,share:s,e};
      // (Its second derivatives: each control's move its rates' own, alone and with each other.)
      const m=free.map(j=>moves[names[j]]),moved=v=>[1,-1].map(g=>player.step(c,names.map((_,j)=>g*(v[free.indexOf(j)]??0))));
      const second=async v=>{const b=await current.stream.bend({...player.along(c,moved(v)),share:1,most:1,from_hz:e.hz,cents:1,decibels:1,from:HELD_ORBIT,save:HELD_BENT});
        if(!b.sounds)throw new Error(`its second derivative read where its path turns: ${b.why}`);return [b.bend_cents,b.bend_level]};
      const H=[0,1].map(()=>free.map(()=>free.map(()=>0)));
      for(let q=0;q<n;q++){const b=await second(free.map((_,r)=>r===q?m[q]:0));for(let r=0;r<rows;r++)H[r][q][q]=b[r]/m[q]**2}
      for(let q=0;q<n;q++)for(let p=q+1;p<n;p++){
        const b=await second(free.map((_,r)=>r===q?m[q]:r===p?m[p]:0));
        for(let r=0;r<rows;r++)H[r][q][p]=H[r][p][q]=(b[r]-m[q]**2*H[r][q][q]-m[p]**2*H[r][p][p])/(2*m[q]*m[p]);
      }
      if(!nu){
        const w=free.map(j=>spans[j]**2),M=[0,1].slice(0,rows).map(r=>[0,1].slice(0,rows).map(u=>G.reduce((t,g,q)=>t+w[q]*g[r]*g[u],0)));
        const Ma=linear(M,a);nu=Ma&&Ma.map(v=>-v/a.reduce((t,x,r)=>t+x*Ma[r],0));
        if(!nu||!nu.every(Number.isFinite))return {why:'its path\'s rates over its share move no condition its controls do'};
      }
      // (Newton's step on its controls, its share and its multipliers: [ΣνH, 0, Gᵀ; 0, 0, aᵀ; G, -a, 0].)
      const N=n+1+rows,J=Array.from({length:N},()=>new Array(N).fill(0)),R=new Array(N).fill(0);
      for(let q=0;q<n;q++){
        R[q]=G[q].reduce((t,g,r)=>t+g*nu[r],0);
        for(let p=0;p<n;p++)J[q][p]=nu.reduce((t,v,r)=>t+v*H[r][q][p],0);
        for(let r=0;r<rows;r++)J[q][n+1+r]=G[q][r];
      }
      R[n]=1+a.reduce((t,x,r)=>t+x*nu[r],0);
      for(let r=0;r<rows;r++)J[n][n+1+r]=a[r];
      for(let r=0;r<rows;r++){R[n+1+r]=F[r];for(let q=0;q<n;q++)J[n+1+r][q]=G[q][r];J[n+1+r][n]=-a[r]}
      const full=linear(J,R.map(v=>-v));
      if(!full||!full.every(Number.isFinite))return {why:'its turning point\'s equations have no step here'};
      // (As far as its second derivatives say the note moves within HELD.error of what its rates say, as each step along
      // its path goes.)
      const bend=[0,1].slice(0,rows).map(r=>Math.abs(free.reduce((t,_,q)=>t+full[q]*free.reduce((u,_,p)=>u+H[r][q][p]*full[p],0),0))/2/(r?HELD.error.level:HELD.error.cents));
      const part=Math.min(1,1/Math.sqrt(Math.max(...bend))),d=full.map(v=>part*v);
      s+=d[n];last=part<1?null:d[n];nu=nu.map((v,r)=>v+d[n+1+r]);
      if(s>=1)return {past:true};
      const from=c;
      c=player.step(c,names.map((_,j)=>d[free.indexOf(j)]??0));
      const quad=r=>free.reduce((t,_,q)=>t+d[q]*free.reduce((u,_,p)=>u+H[r][q][p]*d[p],0),0)/2;
      expect={hz:e.hz*2**((free.reduce((t,j,q)=>t+e.rates[j][0]*d[q],0)+quad(0))/1200),level:e.level+free.reduce((t,j,q)=>t+e.rates[j][1]*d[q],0)+(rows>1?quad(1):0),
        from:{hz:e.hz,level:e.level,at:from},to:c};
      // (A control past its reach held at it.)
      const placed=player.at(c),out=free.filter(j=>{const [lo,hi]=player.reach[j];return lo!=null&&placed[j]<lo||hi!=null&&placed[j]>hi});
      for(const j of out){const [lo,hi]=player.reach[j],to=placed[j]<lo?lo:hi;c[names[j]]=player.value(names[j],to)}
      if(out.length){free=free.filter(j=>!out.includes(j));nu=null;last=null;if(free.length<rows)return {why:'its controls left within their reach too few where its path turns'}}
    }
    return {why:`where its path turns back not solved within ${HELD.turns} steps of Newton's method`};
  };
  // (The last point it closed on, and its note there: where its path ends short of its end, the furthest that holds.)
  let closed=null;
  path: for(let k=0;k<HELD.points;k++){
    // (Closed on the path at its aim by Newton's method: its orbit, its controls and its share of the way solved together.)
    t=null;
    for(let c=0;c<HELD.corrections&&!t?.tuned;c++){
      const aim=aimAt(),end=ends(aim);
      const asked=ask({from_hz:fromHz,hz:aim.hz,level:aim.level,goal_hz:goal.hz,goal_level:levelFree?null:goal.level,
        ...(end||!(weight>0)?{}:{anchor_hz:anchor.hz,anchor_level:anchor.level,share_weight:weight}),
        multipliers:end||holding?Number(given.multipliers??HELD.multipliers):Number(given.watch??0),...holdingAsked()});
      if(!finite(asked)){({why,kind}=unrowed);break path}
      t=await current.stream.tune(asked);orbit=HELD_ORBIT;held=heldOf(t);
      steps.push({...at,kind:'closed',share,hz:t.sounds?t.hz:null,cents:t.sounds?t.cents:null,level:t.sounds?t.level:null,closing:t.closing,tuned:t.tuned,pinned:names.filter((_,j)=>t.pinned?.[j]),
        levelFree:t.level_free,rates:t.rates,step:t.step,stepShare:t.step_share,tangent:t.tangent,turn:t.tangent_turn,multipliers:t.multipliers,values:t.values,holds:t.holds??null,
        ...(t.watched?{watched:t.watched.map(m=>({value:m.value,size:m.size,held:m.held,tangentHeld:m.tangent_held,residual:m.residual,rates:Object.fromEntries(names.map((n,j)=>[n,m.rates[j]]))}))}:{}),residuals:t.residuals,maps:t.maps});
      if(!t.sounds){why=t.why;kind='sounds no more';break path}
      if(jumped(t)){why=flagged();kind='speculative';break path}
      expect=null;
      if(t.tuned)break;
      if(t.why){why=t.why;kind=t.watched?.some(m=>m.held)?'holds no further':'reach';break path}
      const was=at;
      at=player.step(at,t.step);fromHz=t.next_hz;share=Math.min(1,share+(t.step_share??0));
      expect={hz:t.next_hz,level:t.next_level,from:{hz:t.hz,level:t.level,at:was},to:at};
    }
    if(!t.tuned){why=`not closed on its path within ${HELD.corrections} steps of Newton's method`;kind='not reached';break}
    // (Where its aim's level is past its reach, its level free from here.)
    if(t.level_free&&!levelFree){levelFree=true;anchor={hz:t.hz,level:t.level};share=0;progress=0;test=null}
    points.push({...at,hz:t.hz,level:t.level});closed={at:{...at},t};
    if(ends(aimAt())||levelFree&&aimAt().hz===goal.hz){found=t;break}
    if(t.why){why=t.why;kind='in tune no further';break}
    if(t.tangent_free&&!levelFree){levelFree=true;anchor={hz:t.hz,level:t.level};share=0;progress=0;test=null}
    const reached=progress+share*(1-progress);
    // (Where its path turns back: its controls left -- those its tangent holds at their reach aside -- moving its pitch
    // and its level apart less and less, the determinant of their rates' products (each over its span) falling to
    // nothing at the point where it turns, as the way that remains there; or the determinant of their rates turning its
    // sign, the point passed. Its level left free from there, its tangent read again so; where its level is free
    // already, its pitch goes no further. With multipliers its tangent holds, their rates among its conditions: what is
    // left to move its pitch and its level apart with them held, the determinant of all their rates' products over that
    // of the multipliers' alone (its Schur complement).)
    const kept=(t.watched??[]).filter(m=>m.tangent_held);
    const free=names.map((_,j)=>j).filter(j=>!t.tangent_pinned?.[j]),rows=levelFree?1:2;
    const gramOf=cs=>cs.map(a=>cs.map(c=>free.reduce((v,j)=>v+spans[j]**2*a[j]*c[j],0)));
    const conditions=[0,1].slice(0,rows).map(r=>t.rates.map(x=>x[r])),modes=kept.map(m=>m.rates);
    const tau=determinant(gramOf([...conditions,...modes]))/(modes.length?determinant(gramOf(modes)):1),key=[...free,levelFree,modes.length].join();
    const turnedPast=t.tangent_turn!=null&&face?.key===key&&Math.sign(t.tangent_turn)!==face.sign;
    const turnsAt=test?.key===key&&tau<test.tau?reached+tau*(reached-test.reached)/(test.tau-tau):Infinity;
    test={key,reached,tau};face=t.tangent_turn!=null?{key,sign:Math.sign(t.tangent_turn)}:null;
    // (Its tangent the whole way to the path's end; the most of the way its step may go, to where a control meets its
    // reach, or a multiplier it follows and does not hold, that its tangent grows, meets HELD.holding; its tangent's move
    // for a share small enough to read its bend, its largest control's move its rates' own.)
    const d=t.tangent,here=player.at(at);
    let most=1;
    names.forEach((n,j)=>{const [lo,hi]=player.reach[j];
      if(d[j]>0&&hi!=null)most=Math.min(most,(hi-here[j])/d[j]);else if(d[j]<0&&lo!=null)most=Math.min(most,(lo-here[j])/d[j])});
    if(holding)for(const m of t.watched??[]){
      const grows=m.tangent_held?0:m.rates.reduce((s,r,j)=>s+r*d[j],0);
      if(grows>0)most=Math.min(most,Math.max(0,(holding-m.size)/grows));
    }
    const part=1/Math.max(...names.map((n,j)=>Math.abs(d[j])/moves[n]));
    if(!Number.isFinite(part)){why='its tangent moves no control';kind='in tune no further';break}
    const asked={...player.along(at,[1,-1].map(s=>player.step(at,d.map(v=>s*part*v)))),share:part,most:Math.max(most,0),from_hz:t.hz,cents:HELD.error.cents,decibels:levelFree?null:HELD.error.level,from:orbit,save:HELD_PREDICTED};
    if(!finite(asked)){({why,kind}=unrowed);break}
    const bent=await current.stream.bend(asked);
    if(!bent.sounds){why=bent.why;kind='sounds no more';break}
    const h=bent.h;
    // (Its step reaching where its path turns, or past it: that point solved, and its level left free there. With
    // multipliers its tangent holds, its level left free at the point it stands on, and where its level is free already,
    // its path ending there, holding no further.)
    if(turnedPast||reached+h*(1-reached)>=turnsAt){
      if(modes.length){
        if(levelFree){why=`its multipliers held within 1, its controls within their reach move its pitch no further: its path holds no further than ${t.hz.toFixed(3)} Hz`;kind='holds no further';break}
        levelFree=true;anchor={hz:t.hz,level:t.level};share=0;progress=0;weight=0;test=null;face=null;fromHz=t.hz;expect=null;
        continue;
      }
      anchor={hz:t.hz,level:t.level};share=0;progress=reached;
      const turned=await turnAt({...at},0,free);
      if(!turned.past){
        if(!turned.at){why=turned.why;kind=turned.speculative?'speculative':'not reached';break}
        at=turned.at;
        const top={...at,kind:'turned',share:turned.share,hz:turned.e.hz,level:turned.e.level,levelFree};
        steps.push(top);
        if(levelFree){why=`its controls within their reach move its pitch no further: its path turns back at ${turned.e.hz.toFixed(3)} Hz`;kind='in tune no further';break}
        levelFree=true;
        t=await current.stream.tune(ask({from_hz:turned.e.hz,hz:turned.e.hz,level:null,goal_hz:goal.hz,goal_level:null,multipliers:holding?Number(given.multipliers??HELD.multipliers):0,...holdingAsked()}));
        orbit=HELD_ORBIT;held=heldOf(t);
        if(!t.sounds){why=t.why;kind='sounds no more';break}
        // (Where its multipliers held within 1 leave it not yet in tune there, closed by the path's own steps from it.)
        if(!t.tuned&&holding&&t.holds===false&&!t.why){
          anchor={hz:t.hz,level:t.level};share=0;progress=0;weight=0;test=null;face=null;
          at=player.step(at,t.step);fromHz=t.next_hz;expect=null;
          continue;
        }
        if(!t.tuned){why='not in tune where its path turns back';kind='not reached';break}
        if(t.why){why=t.why;kind='in tune no further';break}
        anchor={hz:t.hz,level:t.level};share=0;progress=0;weight=0;test=null;face=null;fromHz=t.hz;
        points.push({...at,hz:t.hz,level:t.level});closed={at:{...at},t};
        continue;
      }
      // (It turns nowhere before its path's end: the step taken as predicted, from the orbit the solve began at.)
      const again=await current.stream.bend({...asked,from:HELD_ORBIT});
      if(!again.sounds){why=again.why;kind='sounds no more';break}
      expect=null;
    }
    const was=at;
    at=player.step(at,d.map(v=>h*v));fromHz=bent.hz;orbit=HELD_PREDICTED;
    expect={hz:bent.hz,level:bent.level,from:{hz:t.hz,level:t.level,at:was},to:at};
    // (A control its step meets its reach with set on it.)
    if(h===most&&most<1)names.forEach((n,j)=>{const [lo,hi]=player.reach[j],v=player.at(at)[j],near=1e-9*spans[j];
      const to=d[j]>0&&hi!=null&&Math.abs(hi-v)<=near?hi:d[j]<0&&lo!=null&&Math.abs(v-lo)<=near?lo:null;
      if(to!=null)at[n]=player.value(n,to)});
    // (Its aim moved the same share of the way from where it was closed: its period and its level; a share weighed as
    // its controls' move along its tangent for it, each over its span.)
    anchor={hz:t.hz,level:t.level};progress=reached;share=h;weight=1/names.reduce((s,n,j)=>s+(d[j]/spans[j])**2,0);
    // (Its first difference against what its rates say of the same move, its solves' residuals and evaluations, and
    // the tracts its sides stood at: each resonance's frequency and peak.)
    steps.push({...at,kind:'predicted',h,share:part,most,hz:bent.hz,level:bent.level,movedCents:bent.moved_cents,ratedCents:names.reduce((s,_,j)=>s+t.rates[j][0]*part*d[j],0),
      bendCents:bent.bend_cents,bendLevel:bent.bend_level,residuals:bent.residuals,solves:bent.solves,maps:bent.maps,
      ...(asked.tract?{tracts:[asked.tract,...asked.along.map(a=>a.tract)].map(l=>l?.map(r=>[+r.frequency.toFixed(3),+r.peak.toPrecision(4)]))}:{})});
  }
  if(!found&&!why){why=`its path's end not reached in ${HELD.points} points`;kind='not reached'}
  // (Its multipliers read where its level was left free at the path's end, its note tuned there already.)
  if(found&&found.holds==null&&Number(given.multipliers??HELD.multipliers)>0){
    const t=await current.stream.tune(ask({from_hz:found.hz,hz:goal.hz,level:null,multipliers:Number(given.multipliers??HELD.multipliers)}));
    if(t.sounds&&t.tuned)found={...found,holds:t.holds,multipliers:t.multipliers,values:t.values};
  }
  const result=found&&{...player.shown(at),hz:found.hz,cents:found.cents,level:found.level,closing:found.closing,holds:found.holds??null,multipliers:found.multipliers??[],values:found.values??[],
    rates:Object.fromEntries(names.map((n,j)=>[n,{cents:found.rates[j][0],level:found.rates[j][1]}])),pinned:player.held(at),levelFree};
  // (Where its path ends short of its end, the furthest point it closed on -- its multipliers held within 1 there, where
  // they are held -- its pitch's cents from the pitch asked.)
  const furthest=!result&&closed?{...player.shown(closed.at),hz:closed.t.hz,cents:1200*Math.log2(closed.t.hz/hz),level:closed.t.level,holds:closed.t.holds??null,
    multipliers:closed.t.multipliers??[],values:closed.t.values??[],pinned:player.held(closed.at)}:null;
  if(result&&given.save)await current.stream.saveOrbit(String(given.save),true);
  const outside=result?names.filter(n=>{const r=player.reaches[n];return r&&(at[n]<r[0]||r[1]!=null&&at[n]>r[1])}):[];
  // (Moved there along its path's points, each in turn over HELD.warm s, its ear's moves set aside.)
  const path=given.apply&&(result||furthest)?points:[];
  cancel('held');
  const made=current,note=state.pitch;
  path.forEach((r,k)=>after(k*HELD.warm,()=>{
    if(current!==made||state.pitch!==note)return;
    const before=state.row;
    state.earX={};
    if(current.reedLip)state.lipForce=r.lip;
    state.x[b]=r.breath;delete state.pulled[b];
    for(const h of player.holes)if(r[h.name]!=null)for(const j of h.columns)state.fingers[j]=r[h.name];
    if(player.tractNow&&r.tract!=null||player.shape){state.tractFollows=false;tract(player.rows(r).tract,player.shapeAt(r))}
    state.row=composed();changed(before,{moving:HELD.warm});
  },'held'));
  return {hz,level:goal.level,found:result,why:result?null:why,kind:result?null:kind,furthest,outside,picked,steps:steps.map(player.shown),points:points.map(player.shown),reaches:player.reaches,
    moves,shape:player.shape,applied:path.length>0,moving:path.length*HELD.warm,seconds:(performance.now()-since)/1000};
}
// ---- its joints pulled to tune, where its body has them (body.json `points`: render/synthesis/geometry/
// tuning-points.json; native/openwind-maker src/make.rs points) ----
// (The pull each joint's rate is read over, mm; the cents its notes are tuned within; its steps at most.)
const JOINTS=Object.freeze({nudge:.05,cents:.1,steps:6});
const jointsShown=j=>Object.fromEntries(j.names.map((n,k)=>[n,1000*j.pulls[k]]));
// (Its barrel, the joint so named, where its body has one: its index among its joints, else -1.)
const barrelAt=made=>made?.joints?made.joints.names.indexOf('barrel'):-1;
// (Its barrel's pull as the page dialled it, mm -- none where it stands where its players set it on this body -- as its
// joints now stand: a note's tuning its ear kept is kept at each barrel apart.)
function barrelFollows(){
  const j=current.joints,k=barrelAt(current);
  state.barrel=k<0||Math.abs(j.pulls[k]-j.players[k])<1e-12?null:1000*j.pulls[k];
}
// Its joints pulled open, `given.pulls` mm by name (those not named left where they stand), at once, as its player sets
// them before playing (stream.rs pull_points) -> where they stand, mm by name.
async function jointsPulled(given){
  const j=current?.joints;if(!j)throw new Error(`the ${current?.model} has no joints to pull`);
  const pulls=j.names.map((n,k)=>given.pulls?.[n]!=null?Number(given.pulls[n])/1000:j.pulls[k]);
  if(!pulls.every(Number.isFinite))throw new Error('each pull in mm');
  j.pulls=await current.stream.pullPoints(pulls);barrelFollows();
  return {pulls:jointsShown(j)};
}
// The note as it sounds at its own controls -- its lip, its breath and its tract as the page has them, its ear's moves
// left out -- picked up near where its start grows (as heldAt picks it up) and saved under `given.name` -> its pitch, its
// level, its row and its tract, for jointsTuned; or why it does not sound.
async function jointNote(given){
  if(!current?.joints)throw new Error(`the ${current?.model} has no joints`);
  if(!state.blowing||lungs.taking)throw new Error('its note blown: its orbit is picked up from it as it sounds');
  const hz=Number(given.hz??440*2**((state.pitch-69)/12)),player=heldPlayer(),rows=player.rows(heldNow(player));
  if(!rows.row.every(Number.isFinite))return {sounds:false,why:'its row has no value there: its lip past the force that shuts its reed'};
  const g=await current.stream.grows({...rows,hz}),near=g.hz>0?g.hz:hz;
  const o=await current.stream.pick({...rows,warm:given.warm??HELD.warm,near});
  if(!o.sounds)return {sounds:false,why:o.why};
  await current.stream.saveOrbit(String(given.name),true);
  return {sounds:true,hz:o.hz,level:o.level,closing:o.closing,newton:o.newton,closings:o.closings,linear:o.linear,row:rows.row,tract:rows.tract};
}
// The row and the tract the note is held at now -- its lip, its breath and its tract as the page has them, its ear's
// moves left out, as jointNote reads them -- for its own start (points.rs: tune-body.mjs).
function startRow(){
  if(!current?.stream||!state.rules)throw new Error('a note taken up first');
  if(current.kind!=='reed'||current.breath==null)throw new Error('a reed\'s note: held by its lip and its breath');
  if(!state.blowing||lungs.taking)throw new Error('its note blown: its row then holds its breath');
  const player=heldPlayer(),rows=player.rows(heldNow(player));
  if(!rows.row.every(Number.isFinite))throw new Error('its row has no value there: its lip past the force that shuts its reed');
  return {row:rows.row,tract:rows.tract};
}
// Its joints `given.joints` (by name) pulled to tune the notes `given.notes` ({from: the orbit jointNote saved, row,
// tract, hz asked, weight}), each kept within `given.within` (mm by name; its range where none), computed on the engine
// itself (orbit.rs pull_points) -> orbit.rs Pulled, and its joints' pulls (mm by name) where it leaves them.
async function jointsTuned(given){
  const j=current?.joints;if(!j)throw new Error(`the ${current?.model} has no joints`);
  const index=n=>{const k=j.names.indexOf(n);if(k<0)throw new Error(`no joint ${n}: ${j.names.join(', ')}`);return k};
  const moved=(given.joints??[]).map(String);
  const found=await current.stream.tunePoints({notes:(given.notes??[]).map(n=>({from:String(n.from),row:n.row,tract:n.tract??null,hz:Number(n.hz),weight:Number(n.weight??1)})),
    joints:moved.map(index),within:moved.map(n=>(given.within?.[n]??j.range[index(n)].map(v=>1000*v)).map(v=>Number(v)/1000)),
    nudge:Number(given.nudge??JOINTS.nudge)/1000,cents:Number(given.cents??JOINTS.cents),steps:Number(given.steps??JOINTS.steps),warm:Number(given.warm??HELD.warm)});
  j.pulls=found.pulls;barrelFollows();
  return {...found,pulled:jointsShown(j)};
}
// (The orbit its path follows, saved under this name in its player: each step's begun from the last's; the one its
// step predicts, and the one a second derivative's read leaves.)
const HELD_ORBIT='held',HELD_PREDICTED='held-predicted',HELD_BENT='held-bent';
// (The solution of the small linear system `A` x = `b`, by elimination with its largest pivot; none where singular.)
function linear(A,b){
  const n=b.length,M=A.map((r,i)=>[...r,b[i]]);
  for(let k=0;k<n;k++){
    let p=k;for(let i=k+1;i<n;i++)if(Math.abs(M[i][k])>Math.abs(M[p][k]))p=i;
    if(!(Math.abs(M[p][k])>0))return null;
    [M[k],M[p]]=[M[p],M[k]];
    for(let i=k+1;i<n;i++){const f=M[i][k]/M[k][k];for(let j=k;j<=n;j++)M[i][j]-=f*M[k][j]}
  }
  const x=new Array(n).fill(0);
  for(let i=n-1;i>=0;i--){let v=M[i][n];for(let j=i+1;j<n;j++)v-=M[i][j]*x[j];x[i]=v/M[i][i]}
  return x;
}
// (The determinant of the small square matrix `A`, by elimination with its largest pivot.)
function determinant(A){
  const n=A.length,M=A.map(r=>[...r]);let d=1;
  for(let k=0;k<n;k++){
    let p=k;for(let i=k+1;i<n;i++)if(Math.abs(M[i][k])>Math.abs(M[p][k]))p=i;
    if(!(Math.abs(M[p][k])>0))return 0;
    if(p!==k){[M[k],M[p]]=[M[p],M[k]];d=-d}
    d*=M[k][k];
    for(let i=k+1;i<n;i++){const f=M[i][k]/M[k][k];for(let j=k;j<n;j++)M[i][j]-=f*M[k][j]}
  }
  return d;
}
// The held note at `given.at` (its lip, breath and tract, and its open finger holes' openings by label in `holes`; the
// rest where they stand) -- its orbit there begun from the one saved as `given.begin`, else from the note as it sounds,
// warmed `given.warm` s -- its pitch, level and multipliers, unmoved: what the solve's rates are checked against
// (test/audio/winds-dial-held.test.mjs).
async function heldNoteAt(given){
  if(!current?.stream||!state.rules)throw new Error('a note taken up first');
  if(current.kind!=='reed'||current.breath==null)throw new Error('a reed\'s note: held by its lip and its breath');
  const player=heldPlayer({shade:true}),at=heldNow(player),begun=player.taken(given.at??{});
  for(const n of Object.keys(begun))if(n in at&&begun[n]!=null)at[n]=Number(begun[n]);
  const o=await current.stream.rates({...player.rows(at),warm:given.warm??HELD.warm,multipliers:given.multipliers??HELD.multipliers,...(given.begin!=null?{begin:String(given.begin)}:{})});
  return {...player.shown(at),sounds:o.sounds,hz:o.sounds?o.hz:null,level:o.sounds?o.level:null,holds:o.holds??null,multipliers:o.multipliers??[],closing:o.closing,why:o.why??null};
}
// (The kept resonance's frequencies its players' shapes reach, Hz: [least, most]; and whether `f` lies within.)
const tractReach=()=>{const fs=Object.values(TRACT_SHAPES).flatMap(s=>s.rows.map(r=>r.resonances[1]?.frequency).filter(Boolean));return [Math.min(...fs),Math.max(...fs)]};
const within=(f,[low,high])=>f>=low&&f<=high;
// (The row and the tract the page would hold at a held note's controls `c` ({lip, breath, tract} or {lip, breath,
// coords}, and its shaded holes' openings by label in `holes`: heldAt's): its tract's kept resonance at c.tract, the
// others where they stand; or its shape at c.coords, its glottis as it stands, its resonances in the places the page's
// stand in (heldPlayer); none where its players' tract is not measured -> {row, tract}, and the shape where one is moved.)
function heldTract(c){
  if(state.shape&&c.tract!=null)throw new Error('its tract is a shape\'s, a note of its player\'s settings: its kept resonance is not moved alone (heldPlayer)');
  if(!state.shape&&c.coords!=null)throw new Error('its tract is not a shape\'s: there are no coordinates of one to move');
  const row=heldRowAt(current.reedLip?c.lip??0:0,c.breath??ownPlaced(current.breath),holesOpened(c.holes));
  if(state.shape){
    if(c.coords==null)return {row,tract:null,shape:null};
    const shape={coords:c.coords,glottis:state.shape.glottis},glottis=playerEntry(current.model,'tract.glottis').range;
    if(!holdsShape(shape,glottis))throw new Error(`a shape its player's tract may take: its ${TRACT_SPACE.space.span.length} coordinates, each within the measured vowels' and its players' tracks' (vocal-tract-played.js tractBounds)`);
    const player=heldPlayer();
    return {row,tract:player.rows({...heldNow(player),...player.taken({coords:c.coords})}).tract,shape:{coords:[...shape.coords],glottis:shape.glottis}};
  }
  const now=tractMeasured(current.model)&&state.tract?.resonances?.length>1?state.tract.resonances:null;
  return {row,tract:now&&c.tract!=null?now.map((r,k)=>k===1?{...r,frequency:c.tract}:{...r}):null,shape:null};
}
const heldControls=c=>{const {row,tract}=heldTract(c);return {row,tract}};
// (The page's controls put at a held note's `c`, as heldAt's path moves them, over `moving` s, its ear's moves set aside.)
function putAt(c,moving=0){
  const before=state.row,b=current.breath;
  state.earX={};
  if(current.reedLip&&c.lip!=null)state.lipForce=c.lip;
  if(c.breath!=null){state.x[b]=c.breath;delete state.pulled[b]}
  for(const [k,v] of Object.entries(holesOpened(c.holes)))state.fingers[k]=v;
  const {tract:resonances,shape}=heldTract(c);
  if(resonances){state.tractFollows=false;tract(resonances,shape)}
  state.row=composed();changed(before,{moving});
}
// ---- its player's ear: a reed's note brought into tune by its lip and its breath ----
// (Its ear put on the note `pitch` -- its tuning's `key`, the dials it moves `order` -- from where it stands.)
const earOn=(made,pitch,key,order)=>({pitch,key,order,raises:order.map(c=>c===made.zeta?-1:1),slopes:order.map(()=>null),last:null,tried:null,misses:0,moves:0,
  since:made.frames+Math.round((EAR.first-EAR.settle-EAR.listen)*WINDS_RATE)});
// (Its sound's last EAR.listen s, as its player hears it.)
const recent=new Float32Array(SERIES.reading);
// (Each block of sound heard; where its ear is on a note being blown and a move has had EAR.settle s and its sound
// EAR.listen s since, its pitch heard and its next move made.)
function listened(block){
  const n=recent.length;
  if(block.length>=n)recent.set(block.subarray(block.length-n));else{recent.copyWithin(0,block.length);recent.set(block,n-block.length)}
  const ear=state.ear;
  if(!ear||!current||!state.blowing||lungs.taking||current.frames-ear.since<Math.round((EAR.settle+EAR.listen)*WINDS_RATE))return;
  ear.since=current.frames;
  const hz=seriesPitch(recent,WINDS_RATE).hz;
  tuneBy(hz?69+12*Math.log2(hz/440):null);
}
// (Its next move from what it heard, `heard` (fractional MIDI; null, nothing). In tune within EAR.cents, or EAR.moves
// made, where it stands kept for the next time this row is asked for this pitch. Silent or off its regime after a move:
// back where it was last heard, the move tried at half its size (a nudge the other way first), EAR.misses times. Else
// each dial's slope (semitones a unit of its reach) from its nudge, then from each move heard (Broyden's update), and
// the least move along them that sounds the pitch.)
// (The reed a note's place was found on, its rules' reed columns, kept with the place: what a reed changed or wetted since
// moved it can be read from them.)
// (The tract its player raised toward the note as it was tuned, kept with where it was found: its player's own, none.)
const raisedOf=()=>state.tractFollows&&state.raised!=null?{tract:{raised:state.raised}}:{};
const reedOf=()=>Object.fromEntries(current.columns.flatMap((c,k)=>c[0]==='reed'?[[c[2],+state.rules[k].toPrecision(6)]]:[]));
function tuneBy(heard){
  const ear=state.ear,before=state.row,dials=ear.order;
  const done=()=>{const {kept,keep}=current.tunings;kept[ear.key]={x:{...state.earX},cents:state.heard==null?null:100*(state.heard-ear.pitch),reed:reedOf(),...raisedOf()};keep?.(kept,ear.key);state.ear=null};
  const to=xs=>{ear.moves++;state.earX={...state.earX,...Object.fromEntries(dials.map((k,i)=>[k,xs[i]]))};state.row=composed();changed(before)};
  const reach=state.within?reachOf():null,lips=reach?.lip??LIP_FORCE,top=k=>k===current.breath&&reach?.breath?Math.min(1,reach.breath[1]):1;
  const span=k=>k==='lip'?[lips[0]-state.lipForce,lips[1]-state.lipForce]:[-1-(state.x[k]??0),top(k)-(state.x[k]??0)],wide=k=>k==='lip'?LIP_FORCE[1]-LIP_FORCE[0]:2;
  if(!ear.last&&(heard==null||heard<ear.pitch-EAR.most)&&tractRaised(heard))return;
  if(heard==null||Math.abs(heard-ear.pitch)>EAR.most){
    if(!ear.last||!ear.tried||ear.moves>=EAR.moves||++ear.misses>EAR.misses){if(ear.last)to(ear.last.x);return done()}
    const nudging=ear.slopes.some(s=>s==null)&&ear.misses===1;
    ear.tried=ear.tried.map(d=>nudging?-d:d/2);return to(ear.last.x.map((x,i)=>x+ear.tried[i]));
  }
  const off=heard-ear.pitch,xs=dials.map(k=>state.earX[k]??0);
  state.heard=heard;
  if(100*Math.abs(off)<=EAR.cents||ear.moves>=EAR.moves)return done();
  if(ear.last){
    const d=xs.map((x,i)=>x-ear.last.x[i]),dp=heard-ear.last.heard,n=d.reduce((s,v)=>s+v*v,0),i=ear.slopes.findIndex(s=>s==null);
    if(i>=0&&d[i]&&d.every((v,j)=>j===i||!v))ear.slopes[i]=dp/d[i];
    else if(i<0&&n>0){const r=dp-d.reduce((s,v,j)=>s+v*ear.slopes[j],0);ear.slopes=ear.slopes.map((s,j)=>s+r*d[j]/n)}
  }
  ear.last={x:xs,heard};ear.misses=0;
  const i=ear.slopes.findIndex(s=>s==null),n=ear.slopes.reduce((s,v,j)=>s+((v??0)*wide(dials[j]))**2,0);
  const wanted=i>=0?xs.map((x,j)=>j===i?x-ear.raises[j]*Math.sign(off)*EAR.nudge*wide(dials[j]):x):n>0?xs.map((x,j)=>x-off*ear.slopes[j]*wide(dials[j])**2/n):xs;
  const next=wanted.map((x,j)=>{const [low,high]=span(dials[j]),most=EAR.step*wide(dials[j]);return Math.min(high,Math.max(low,Math.min(xs[j]+most,Math.max(xs[j]-most,x))))});
  ear.tried=next.map((x,j)=>x-xs[j]);
  if(ear.tried.every(d=>Math.abs(d)<1e-6))return done();
  to(next);
}
// (Heard below its regime, or silent, before it was ever heard in it: its player's tract raised toward the note a step
// from where it stands -- theirs normal, then its bending shape at each of RAISES times its frequency -- and the note
// heard again, as clarinettists raise theirs where the bore alone will not hold a note (Chen, Smith & Wolfe 2009), before
// its lip and breath tune it; no step left, the raise heard nearest the note put back, else the one it began with. The
// clarinet's A6 fingering asked for 93.43, at 372 Hz under its players' normal tract -- its bore's 374 Hz peak 58 MPa
// s/m^3 against its own at 1819 Hz's 16 -- sounded at 1222 Hz under its bending shape at the note and 1502 at 1.08
// times it, on the engine; the owner had it sound high only by pushing the tract by hand, 8 November 2026: "The page
// doesn't automatically adjust the tract to try to hit notes like this". Each raise tongued again under it, as players
// shape the tract before the note: a regime sounding holds as the tract moves under it -- that fingering stayed at
// 365 Hz as its tract was raised step by step beneath its sound.) -> whether it was raised a step.
function tractRaised(heard){
  const ear=state.ear;
  if(!state.tractFollows)return false;
  const now=state.raised??raisedAt(ear.pitch),r=ear.raising??={from:now,best:null};
  if(heard!=null&&(!r.best||Math.abs(heard-ear.pitch)<Math.abs(r.best.heard-ear.pitch)))r.best={raised:now,heard};
  const next=now==null?RAISES[0]:RAISES.find(x=>x>now),tongued=()=>state.blowing&&!lungs.taking?stroke(state.row,'tongued'):0;
  if(next==null){const back=r.best?r.best.raised:r.from;if(back!==now){state.raised=back;followed(current.model,ear.pitch,back);tongued()}return false}
  state.raised=next;followed(current.model,ear.pitch,next);
  ear.since=current.frames+Math.round((tongued()+EAR.first-EAR.settle-EAR.listen)*WINDS_RATE);
  return true;
}
// Everything the page shows: the instruments, what is being made, and the one played -- its columns, its notes, and
// what it plays now.
function shown(){
  const out={instruments:env.instruments.map(model=>({model,kind:env.kinds[model]})),wanted,loading:loading&&{model:loading.model,step:loading.step,seconds:(Date.now()-loading.since)/1000},failed,
    rate:WINDS_RATE,dynamics:Object.keys(DYNAMIC_VELOCITY),tongue:TONGUE,limits:LIMITS(),reach:REACH,version,model:current?.model??null};
  if(!current)return out;
  const {lips,attacks}=current;
  return {...out,kind:current.kind,tractMeasured:tractMeasured(current.model),columns:current.columns,breath:current.breath,holes:current.holes,notes:current.notes,reed:current.sized,
    lipForce:current.reedLip?{span:LIP_FORCE,force:state.lipForce,...current.reedLip}:null,
    dials:current.columns.map((c,k)=>dialled(k)?k:-1).filter(k=>k>=0),threads:current.stream.threads,impedance:Boolean(current.impedance),geometry:Boolean(current.geometry),shapeless:current.geometry?null:current.shapeless,
    strokeLeast:{tongued:strokeLength('tongued',0),legato:strokeLength('legato',0)},
    partials:lips?lips.notes.map(n=>n.partial):null,fingerings:lips?.valves?lips.notes.map(n=>n.fingering):null,names:lips?.valves||lips?.slide?lips.notes.map(n=>n.names??[]):null,
    positions:lips?.slide?lips.notes.map(n=>n.position):null,alternates:lips?.slide?lips.notes.map(n=>Boolean(n.alternate)):null,
    slide:lips?.slide?{most:lips.slide.most,positions:lips.slide.positions.map(p=>({position:p.position,out:p.out})),speed:SLIDE_SPEED,least:SLIDE_LEAST}:null,
    // (Its barrel, the joint so named, where its body has one: where it stands, where its players set it on this body --
    // `by` the notes they set it by and `tuned` how near they came, where it was found on it -- the range it is pulled
    // within and the span its players set it in, mm; and each of its joints' pulls, mm by name.)
    barrel:barrelAt(current)<0?null:(({pulls,players,range,normal,found},k)=>({pulled:1000*pulls[k],players:1000*players[k],least:1000*range[k][0],most:1000*range[k][1],
      normal:normal[k].map(v=>1000*v),by:found?.by?.barrel??null,tuned:found?.by?.barrel?found.tuned:null}))(current.joints,barrelAt(current)),
    joints:current.joints?jointsShown(current.joints):null,
    valves:lips?.valves?.columns??null,unplayed:lips?lips.unplayed:null,lipReach:lips?[lips.grid.lips[0],lips.grid.lips.at(-1)]:null,
    unattacked:attacks?attacks.notes.map(a=>Object.entries(a.dynamics).filter(([,g])=>g.share==null).map(([d])=>d)):null,
    // (Its mutes, the one in, the one asked and how far its body has come, and those kept taken up.)
    mute:current.mute,mutes:Object.keys(BRASS_MUTES[current.model]??{}),
    muting:muting&&{mute:muting.mute,ready:Boolean(muting.made),step:muting.made?null:making.get(muting.mute)?.step??'its body',seconds:(Date.now()-muting.since)/1000,error:muting.error},
    mutesKept:[...bodies.keys()],
    vibratoOwn:vibratoOf(current.model),layout:current.layout,players:current.players,lungs:{...LUNGS,breath:BREATH_LITRES,airflow:airflowOf(current.model).source},
    noise:{kinds:windsNoiseKinds(current.kind).map(what=>({what,sd:WINDS_NOISE.kinds[what].sd})),profile:WINDS_NOISE.profile,most:NOISE_MOST},
    neutral:current.neutral?{note:current.neutral.note,midi:current.neutral.midi,dynamic:current.neutral.dynamic,cents:current.neutral.cents,found:current.neutral.found,
      breath:current.neutral.breath??0,breathTimes:current.neutral.breathTimes??1}:null,
    // (Its body one found with its player's settings, where it is: which instance of its type, when it was found
    // and what was heard of it then -- played.mjs playedBody; docs/WIND_TYPES.md, "A type's instances".)
    found:current.played?{instance:current.played.instance??null,when:current.played.when??null,mark:current.played.mark,heard:current.played.heard??null}:null,
    played:playing(),refused,soloist:soloShown(),player:playerShown()};
}
// (What each of the page's settings may be, s, notes a second, cents and Hz: the routes below hold them to it.)
// (A breath from half a litre to the vital capacity two deviations over wind players' measured; taken in over 0.2 to 2
// s, about a catch breath's to a slow one's.)
const LIMITS=()=>({stroke:[TONGUE.touch+least('key'),.5],softSeconds:[2*TONGUE.fall,.2],rise:[least('breathRise'),.5],repeat:[.5,16],width:[0,200],rate:[.5,12],
  litres:[.5,+(LUNGS.capacity.litres+2*LUNGS.capacity.sd).toFixed(2)],inhale:[.2,2],
  flutterHz:TECHNIQUE.flutter.hzReach,flutterDepth:TECHNIQUE.flutter.depthReach,humInterval:TECHNIQUE.hum.intervalReach,humLevel:TECHNIQUE.hum.levelReach,
  growlInterval:TECHNIQUE.growl.intervalReach,growlLevel:TECHNIQUE.growl.levelReach,growlRough:TECHNIQUE.growl.roughReach,
  swell:[1/REACH,REACH]});
// (What it plays now: the page's settings and the row held, the body's mute (null none: a mute put in plays its own
// chart), a valved instrument's fingering as its valves stand in it, each pressed past half way, and its joints' pulls
// (mm by name), where its body has joints.)
const fingeringOf=row=>current?.lips?.valves?current.lips.valves.columns.map(([k])=>row[k]<.5?'1':'0').join(''):null;
const playing=()=>({...state,ear:state.ear?{pitch:state.ear.pitch,moves:state.ear.moves}:null,reach:reachOf(),
  held:state.within&&lipNow()?LIP_HELD.map(n=>current.reedAt[n]):[],mute:current?.mute??null,tract:state.tract?.resonances??[],attack:attackHeld(),fingering:state.row?fingeringOf(state.row):null,
  lungs:{air:lungs.air,taking:lungs.taking,flow:current?.blown??null,players:playersSpend()},hummed:current&&state.pitch!=null?hummed('hum'):null,growled:current&&state.pitch!=null?hummed('growl'):null,
  position:current?.lips?.slide&&state.slide!=null?positionAt(state.slide):null,vibratoHeard:current?.lips?current.heard:null,joints:current?.joints?jointsShown(current.joints):null});

// Each change the page makes, by its route -> what it plays then, or null where it makes no such change.
async function change(path,given){
  const before=state.row;
  if(EAR_LEFT.has(path))state.ear=null;
  switch(path){
    // (A pitch: the row found sounding it, or `charted`, a charted note's own.)
    // (Its player's ear put on the note again, from `start` -- {lip (N), or a reed without its players' lip its embouchure
    // (its dial's place), and breath (its dial's place)} past the page's -- as a tool gives it a place it found:
    // ear-tunings.mjs.)
    case '/ear':{
      if(!state.tuning)throw new Error('a reed\'s note taken up first');
      const named={lip:'lip',embouchure:String(current.zeta),breath:String(current.breath)},start=Object.fromEntries(Object.entries(given.start??{}).map(([n,v])=>[named[n],Number(v)]));
      if(Object.entries(start).some(([k,v])=>!k||!state.tuning.order.map(String).includes(k)||!Number.isFinite(v)))throw new Error('a start of the ear\'s own dials: lip or embouchure, and breath');
      // (`hold`: the place given held and kept as found, `cents` off as its finder heard it, the ear not moving it -- a
      // search's place nearer than where the ear came to: ear-tunings.mjs.)
      if(given.hold){
        state.earX=start;state.ear=null;state.row=composed();changed(before);
        const {kept,keep}=current.tunings;kept[state.tuning.key]={x:{...start},cents:Number.isFinite(Number(given.cents))?Number(given.cents):null,reed:reedOf(),...raisedOf()};keep?.(kept,state.tuning.key);break;
      }
      state.earX=start;state.ear=earOn(current,state.pitch,state.tuning.key,state.tuning.order);state.row=composed();changed(before);break;
    }
    // (`fingering`: its place among the note's fingerings, its standard 0, whatever the fingers held. `ear` false: its
    // player's ear left off, the note held at its rules as a tool measures it there -- its ear, moving its lip and breath
    // from the moment it is blown, had a note read a second in read wherever its search had come to by then, what was
    // played before it deciding where: the clarinet's F4 286 c off its rules' pitch a quarter second in, -0.5 c at 2.5 s.)
    case '/pitch':await toPitch(Number(given.pitch),given.dynamic??state.dynamic,Boolean(given.charted),given.note===undefined?null:Number(given.note),given.fingering==null?null:Number(given.fingering));
      if(given.ear===false)state.ear=null;break;
    // (A reed's or jet's column dialled: its share of the rules' value, -1 to 1 1/REACH to REACH times it.)
    case '/dial':{const k=Number(given.column),x=Number(given.x);
      if(!(Number.isInteger(k)&&dialled(k))||!(x>=-1&&x<=1))throw new Error('a dialled column, and a place from -1 to 1');
      state.x[k]=x;delete state.earX[k];delete state.pulled[k];state.row=composed();changed(before);break}
    // (A hole's opening, 0 closed to 1 open, or a valve's, 0 pressed to 1 raised, until the pitch moves: every column
    // of its side -- a valve's two switches -- together.)
    case '/hole':{const k=Number(given.column),v=Number(given.value);
      if(current.columns[k]?.[0]!=='opening'||!(v>=0&&v<=1))throw new Error('a hole or a valve, and its opening from 0 to 1');
      current.columns.forEach((c,j)=>{if(c[0]==='opening'&&c[1]===current.columns[k][1])state.fingers[j]=v});state.row=composed();changed(before);break}
    // (Every dial back to the rules' value at the pitch and dynamic, the holes the pitch's.)
    case '/reset':state.x={};state.pulled={};state.fingers={};state.lipForce=0;state.row=composed();changed(before);break;
    // (Its neutral note again -- read again from its body's folder, so that one found since it was taken up is played
    // -- at its dynamic and breath, every other dial the rules' there; the middle of its charted notes at the dynamic
    // dialled where none has been found.)
    case '/neutral':{
      const found=env.neutral(current.folder);
      current.neutral=found&&current.notes[found.note]===found.midi?found:null;
      const n=current.neutral,k=n?n.note:Math.floor(current.notes.length/2);
      await toPitch(current.notes[k],n?n.dynamic:state.dynamic,true,k);
      state.x=n?.breath?{[current.breath]:n.breath}:{};state.pulled={};state.fingers={};state.row=composed();changed(before);break;
    }
    // (The lips' frequency dialled by itself, the pitch asked kept: their other values those that go with it
    // (lipsRow, its register's), the breath the pitch's; the partial heard the one the bore locks to. Its attack
    // from rest the partial's whose lips these are.)
    // (A single reed's lip pressed or eased `force` N from each note's own, the pitch asked kept: LIP_FORCE's span, and
    // pressed no further than PRESSED_MOST of what shuts the note's reed.)
    case '/lip':{
      if(!current.lips&&current.reedLip&&given.force!==undefined){
        const force=Number(given.force);
        if(!(force>=LIP_FORCE[0]&&force<=LIP_FORCE[1]))throw new Error(`a lip from ${-LIP_FORCE[0]} N eased to ${LIP_FORCE[1]} N pressed`);
        delete state.earX.lip;state.lipForce=force;state.row=composed();changed(before);break;
      }
      if(!current.lips)throw new Error('only a brass instrument\'s lips are dialled by their frequency, and a single reed\'s by its force');
      const [low,high]=[current.lips.grid.lips[0],current.lips.grid.lips.at(-1)],lip=Number(given.lip);
      if(!(lip>=low&&lip<=high))throw new Error(`lips from ${low.toFixed(1)} to ${high.toFixed(1)} Hz`);
      Object.assign(state,{lip,lipDialled:true,bend:0,rules:lipsRow(current.lips,lip,lipsBreath(state.pitch,state.dynamic,partialsAbout(state.pitch,state.dynamic)),state.valves)});
      state.row=composed();changed(before);sway();break;
    }
    // (A brass player's pitch bent by the lips, as its players follow a pitch's path: `cents` from the pitch held, its
    // lips that much over or under those it holds it with -- the bore pulling its partial less far than they move --
    // moved to over `seconds`, its valves, slide and breath held: as the renders bend a brass note, its lips scaled by
    // its pitch curve over its pitch (ness.mjs), within the lips its rows reach. Undone by the next pitch.)
    case '/bend':{
      if(!current.lips)throw new Error('only a brass instrument\'s lips are bent');
      const cents=Number(given.cents),seconds=given.seconds===undefined?0:Number(given.seconds);
      if(!Number.isFinite(cents)||!(seconds>=0))throw new Error('a bend in cents, over some seconds');
      if(state.lip==null)throw new Error('a pitch to bend first');
      const [low,high]=[current.lips.grid.lips[0],current.lips.grid.lips.at(-1)],lip=Math.min(Math.max(state.lip*2**(cents/1200),low),high);
      state.bend=cents;state.rules=lipsRow(current.lips,lip,lipsBreath(state.pitch,state.dynamic,partialsAbout(state.pitch,state.dynamic)),state.valves);
      state.row=composed();
      if(!tonguing()&&!queue.some(e=>e.tag==='attack'))hold(state.row,Math.max(seconds,least('lips')));
      break;
    }
    // (A trombone's slide drawn by itself, `out` m of tube past its first position, as its players draw it: its lips
    // and breath held, the pitch the bore gives there.)
    case '/slide':{
      if(!current.lips?.slide)throw new Error('only a trombone\'s slide is drawn');
      const out=Number(given.out),most=current.lips.slide.most;
      if(!(out>=0&&out<=most))throw new Error(`a slide drawn from 0 to ${most.toFixed(3)} m of tube`);
      slideTo(out);state.slideDialled=true;break;
    }
    // (A reed's barrel pushed in or pulled out to tune, `pulled` mm out from home, as its player sets it before playing
    // (the owner, 9 November 2026: "the clarinet should start a normal position, from which players push or pull slightly
    // to tune (but they don't tune this way mid-performance)"): its joint so named pulled open at once (stream.rs
    // pull_points), a solve asked next hearing it; a note's tuning its ear kept, kept at each barrel apart.)
    case '/barrel':{
      const j=current.joints,k=barrelAt(current);if(k<0)throw new Error(`the ${current.model} has no barrel to pull`);
      const pulled=Number(given.pulled),[least,most]=j.range[k].map(v=>1000*v);
      if(!(pulled>=least-1e-9&&pulled<=most+1e-9))throw new Error(`its barrel pulled from ${least.toFixed(2)} (home) to ${most.toFixed(2)} mm`);
      const pulls=[...j.pulls];pulls[k]=Math.min(most,Math.max(least,pulled))/1000;
      j.pulls=await current.stream.pullPoints(pulls);barrelFollows();break;
    }
    // (A row of the body's columns held as it is given: the brass stream's test, a tool.)
    case '/row':
      if(!Array.isArray(given.row)||given.row.length!==current.columns.length||!given.row.every(Number.isFinite))throw new Error('a row of the body\'s columns');
      state.row=given.row;changed(before);break;
    case '/blow':blow(Boolean(given.on));break;
    // (Its player held within a player's body, or not: the page's settings then free of one another.)
    case '/within':{
      const rate=state.repeat.rate;state.within=Boolean(given.on);tongueWithin();
      const row=state.rules?composed():null;if(row?.some((v,k)=>v!==state.row?.[k])){state.row=row;changed(before)}
      if(state.repeat.on&&state.repeat.rate!==rate)repeating();break;
    }
    // (The tongue now, as the articulation says: a slurred note's a legato tongue's.)
    case '/tongue':if(state.blowing&&!lungs.taking)stroke(state.row,state.articulation==='tongued'?'tongued':'legato');break;
    case '/articulation':{
      if(given.articulation!==undefined){if(!['slurred','legato','tongued'].includes(given.articulation))throw new Error('slurred, legato or tongued');state.articulation=given.articulation}
      const within=(name,low,high)=>{if(given[name]===undefined)return;const v=Number(given[name]);if(!(v>=low&&v<=high))throw new Error(`${name} from ${low} to ${high} s`);state[name]=v};
      const limits=LIMITS();for(const name of ['stroke','softSeconds','rise'])within(name,...limits[name]);
      tongueWithin(given.stroke!==undefined);
      state.breathAttack=firstEndingAt(state.breathAttack,state.rise);
      if(state.repeat.on)repeating();
      break;
    }
    // (The breath's attack, a curve (attack-curves.js) from rest, each segment eased as the engine moves: its first
    // segment the rise, within the rise's limits.)
    case '/attack':{
      const points=curveOf(given.points,{from:0,straight:false}),[low,high]=LIMITS().rise;
      if(!(points[1][0]>=low&&points[1][0]<=high))throw new Error(`its first segment, the rise, from ${low} to ${high} s`);
      state.breathAttack=points;state.rise=points[1][0];break;
    }
    // (Its breathing: on, a breath `litres` deep taken in over `inhale` s each time it is spent; off, one breath
    // without end -- one being taken let go, the note attacked again at once.)
    case '/breathing':{
      const litres=given.litres===undefined?state.breathing.litres:Number(given.litres),inhale=given.inhale===undefined?state.breathing.inhale:Number(given.inhale);
      const limits=LIMITS();
      if(!(litres>=limits.litres[0]&&litres<=limits.litres[1]))throw new Error(`a breath from ${limits.litres[0]} to ${limits.litres[1]} L`);
      if(!(inhale>=limits.inhale[0]&&inhale<=limits.inhale[1]))throw new Error(`a breath taken in over ${limits.inhale[0]} to ${limits.inhale[1]} s`);
      const on=given.on===undefined?state.breathing.on:Boolean(given.on),begun=on&&!state.breathing.on;
      state.breathing={on,litres,inhale};lungs.set({litres,inhale});
      if(begun)lungs.filled();
      if(!on&&lungs.taking){cancel('breath');lungs.filled();if(state.blowing){fromRest();repeating();techniques();sway()}}
      break;
    }
    // (Its flutter: on while it is blown, `hz` turns of the roll a second, `depth` of the breath closed off; its hum and
    // its growl: on, the voice's pitch `interval` semitones from the note, its breath swung `level` of itself, a growl's
    // voice `rough`.)
    case '/flutter':{
      const hz=given.hz===undefined?state.flutter.hz:Number(given.hz),depth=given.depth===undefined?state.flutter.depth:Number(given.depth),limits=LIMITS();
      if(!(hz>=limits.flutterHz[0]&&hz<=limits.flutterHz[1]))throw new Error(`a flutter from ${limits.flutterHz[0]} to ${limits.flutterHz[1]} times a second`);
      if(!(depth>=limits.flutterDepth[0]&&depth<=limits.flutterDepth[1]))throw new Error(`a flutter's depth from ${limits.flutterDepth[0]} to ${limits.flutterDepth[1]}`);
      state.flutter={on:given.on===undefined?state.flutter.on:Boolean(given.on),hz,depth};techniques();break;
    }
    case '/hum':case '/growl':{
      const kind=path.slice(1),own=state[kind],limits=LIMITS(),of=name=>given[name]===undefined?own[name]:Number(given[name]);
      const interval=of('interval'),level=of('level'),rough=kind==='growl'?of('rough'):undefined;
      if(!(interval>=limits[`${kind}Interval`][0]&&interval<=limits[`${kind}Interval`][1]))throw new Error(`a ${kind}'s pitch from ${limits[`${kind}Interval`][0]} to ${limits[`${kind}Interval`][1]} semitones from the note`);
      if(!(level>=limits[`${kind}Level`][0]&&level<=limits[`${kind}Level`][1]))throw new Error(`a ${kind}'s level from ${limits[`${kind}Level`][0]} to ${limits[`${kind}Level`][1]}`);
      if(kind==='growl'&&!(rough>=limits.growlRough[0]&&rough<=limits.growlRough[1]))throw new Error(`a growl's roughness from ${limits.growlRough[0]} to ${limits.growlRough[1]}`);
      state[kind]={on:given.on===undefined?own.on:Boolean(given.on),interval,level,...kind==='growl'?{rough}:{}};techniques();break;
    }
    case '/repeat':{
      const rate=given.rate===undefined?state.repeat.rate:Number(given.rate);
      if(!(rate>=.5&&rate<=16))throw new Error('a rate from 0.5 to 16 notes a second');
      state.repeat={on:given.on===undefined?state.repeat.on:Boolean(given.on),rate};tongueWithin();repeating();break;
    }
    case '/vibrato':{
      const width=given.width===undefined?state.vibrato.width:Number(given.width),rate=given.rate===undefined?state.vibrato.rate:Number(given.rate);
      if(!(width>=0&&width<=200)||!(rate>=.5&&rate<=12))throw new Error('a width from 0 to 200 cents and a rate from 0.5 to 12 Hz');
      state.vibrato={on:given.on===undefined?state.vibrato.on:Boolean(given.on),width,rate};sway();break;
    }
    // (Its player's swell through a note: its breath `share` of the row's, the breath dialled kept, moved there over
    // `seconds` -- its expression, as the renders' players swell a note (breath.mjs swellOf) and breathe its vibrato
    // (openwind-passages.mjs VIBRATO_SHARE); taken up by the next move where its tongue or its attack is moving it.)
    case '/swell':{
      const share=Number(given.share),seconds=given.seconds===undefined?0:Number(given.seconds),[low,high]=LIMITS().swell;
      if(!(share>=low&&share<=high)||!(seconds>=0))throw new Error(`a swell from ${low.toFixed(3)} to ${high.toFixed(3)} of the breath, over some seconds`);
      const rising=share>state.swell;state.swell=share;
      if(state.blowing&&!lungs.taking&&!tonguing()&&!queue.some(e=>e.tag==='attack'))hold(state.row,Math.max(seconds,least(rising?'breathRise':'breathFall')));
      break;
    }
    // (A tract dialled, held until its players' is asked for again -- `follow`: theirs, following the note, as its rules
    // raise it; either, the raise its note's tuning was kept with left. Dialled as a shape, {coords, glottis} -- each
    // coordinate within the bounds its notes' shapes are found in (tractBounds), its glottis's opening (m^2) within its players'
    // (registry/players/winds.json tract.glottis) -- its resonances the shape's (vocal-tract-played.js shapedTract), or
    // `resonances` given with it, a setting put back as it was kept beside the shape it was found at (settingsOf); or as
    // resonances alone, the page's drawing dragged (research/PLAYER_TRACT_PLAN.md, A: what it drags is to become a shape).)
    case '/tract':
      if(given.follow===true){if(!tractMeasured(current.model))throw new Error(`no ${current.model} players' tract measured yet`);
        state.tractFollows=true;state.raised=null;followed(current.model,state.pitch);break}
      if(given.coords!==undefined){
        if(!tractMeasured(current.model))throw new Error(`no ${current.model} players' tract measured yet`);
        const shape={coords:given.coords,glottis:given.glottis},glottis=playerEntry(current.model,'tract.glottis').range;
        if(!holdsShape(shape,glottis))throw new Error(`a shape its player's tract may take: its ${TRACT_SPACE.space.span.length} coordinates, each within the measured vowels' and its players' tracks' (vocal-tract-played.js tractBounds), and its glottis's opening from ${glottis[0]} to ${glottis[1]} m^2`);
        const kept=given.resonances;
        if(kept!==undefined&&!(Array.isArray(kept)&&kept.length&&kept.every(r=>r.frequency>0&&r.q>0&&r.peak>=0)))throw new Error('resonances given with a shape, each its frequency, q and peak');
        state.tractFollows=false;state.raised=null;tract(kept??shapedTract(shape),{coords:[...shape.coords],glottis:shape.glottis});break;
      }
      if(!Array.isArray(given.resonances)||!given.resonances.every(r=>r.frequency>0&&r.q>0&&r.peak>=0))throw new Error('resonances, each its frequency, q and peak; or follow');
      state.tractFollows=false;state.raised=null;tract(given.resonances);break;
    // (Its reed's or lips' flow's turbulence, a share of the flow per root hertz -- native/openwind/turbulence-fit.mjs
    // trying levels -- none for a jet's.)
    case '/turbulence':{const level=Number(given.level);
      if(!['reed','lips'].includes(current.kind)||!(level>=0&&level<=TURBULENCE_MOST))throw new Error(`a reed's or the lips' turbulence from 0 to ${TURBULENCE_MOST}`);
      turbulence(level);break}
    // (A brass player's mute put in, or none: `mute`, one of its mutes (/state mutes), or null -- put in once its body
    // is ready and the bell has rung down after its breath (/state muting); `ready`, its body only made ready.)
    case '/mute':{
      if(!(given.mute===null||given.mute===undefined||typeof given.mute==='string'))throw new Error('a mute\'s name, or null');
      muteTo(given.mute??null,{ready:given.ready===true});break;
    }
    // (Its player's noise: the player's temperature, or a kind's its body's player has.)
    case '/noise':{const asked={};
      for(const k of ['player',...windsNoiseKinds(current.kind)])if(given[k]!==undefined)asked[k]=Number(given[k]);
      if(!Object.keys(asked).length||!Object.values(asked).every(t=>t>=0&&t<=NOISE_MOST))throw new Error(`the player's noise, or its ${windsNoiseKinds(current.kind).join(' or ')}'s, from 0 to ${NOISE_MOST}`);
      noise(asked);break}
    default:return null;
  }
  return playing();
}
// (A change given its time, `at` s on the dial's clock (its frames over WINDS_RATE, `x-seconds` with each pull of sound):
// made where its time has come, else queued to the frame it falls on, made there as the sound is pulled -- a gesture
// recorded to be played ahead of its hearing, a player's note sent before it sounds. One refused at its time is said
// in `refused`, the last ten. `by`: the player that gave it, whose changes still to come it may withdraw.)
const CHANGES=new Set(['/pitch','/ear','/dial','/hole','/reset','/neutral','/lip','/bend','/slide','/barrel','/row','/blow','/tongue','/articulation','/attack',
  '/breathing','/flutter','/hum','/growl','/repeat','/vibrato','/swell','/tract','/turbulence','/mute','/within']);
let refused=[];
async function later(path,given){
  if(!CHANGES.has(path))return {status:404};
  const seconds=Number(given.at),{at:_,by=null,...rest}=given;
  if(!(seconds>=0))throw new Error('a time from 0 s on the dial\'s clock');
  const at=Math.round(seconds*WINDS_RATE);
  if(at<=current.frames){moved(current.frames,path,given);voicing(path,rest,by);return {status:200,json:{...await change(path,rest),rules:state.rules}}}
  queue.push({at,tag:'given',by,run:()=>{moved(at,path,given);voicing(path,rest,by);return change(path,rest).catch(error=>{refused=[...refused.slice(-9),{path,at:seconds,error:error.message}]})}});
  queue.sort((a,b)=>a.at-b.at);
  return {status:200,json:{queued:path,at:seconds}};
}
// (The techniques of the player's a player turned on and has not let go -- its flutter, hum and growl -- by who turned
// each on, let go with it when it is stopped (unvoiced), as its line's own end lets them go (dial-midi2.mjs): a piece
// stopped mid-note had its growl's end withdrawn with the rest, and every wind taken up after it growled (the site's
// check, 4 November 2026).)
const VOICES=['flutter','hum','growl'],voicedBy={};
function voicing(path,given,by){const kind=path.slice(1);if(VOICES.includes(kind)&&given.on!==undefined)voicedBy[kind]=given.on?by:null}
async function unvoiced(by){for(const kind of VOICES)if(voicedBy[kind]===by){voicedBy[kind]=null;if(state[kind]?.on)await change(`/${kind}`,{on:false})}}
// (The page's own tongue, attack and swell as a piece begins -- what its line changes note by note -- given back with the
// techniques it took up as the piece ends, is stopped or its instrument is put down (`played` false: its state alone, the
// engine let go with it): a piece stopped mid-note left its swell, 1.12 of the breath, and its stroke and rise on the
// dial, and the oboe taken up after it cracked its neutral E♭5 to a different note each time (the site's check, 4
// November 2026).)
let pageOwn=null;
const ownOf=()=>({articulation:state.articulation,stroke:state.stroke,softSeconds:state.softSeconds,rise:state.rise,breathAttack:state.breathAttack,swell:state.swell});
async function givenBack({played=true}={}){
  if(!pageOwn)return;
  const {swell,...tongue}=pageOwn;pageOwn=null;
  Object.assign(state,tongue);
  if(!played){for(const kind of VOICES)if(voicedBy[kind]==='soloist'){voicedBy[kind]=null;state[kind]={...state[kind],on:false}}state.swell=swell;return}
  await unvoiced('soloist');
  if(state.repeat.on)repeating();
  if(state.swell!==swell)await change('/swell',{share:swell});
}
// (A player's changes given their times, from `from` s on the dial's clock, let go -- what it sent ahead and now plays
// otherwise: the rest of its line planned again as more of it comes, its MIDI 2.0's next note heard.)
function withdrawn({by=null,from}){
  const seconds=Number(from);
  if(!(seconds>=0))throw new Error('a time from 0 s on the dial\'s clock');
  const at=Math.round(seconds*WINDS_RATE),before=queue.length;
  queue=queue.filter(e=>!(e.tag==='given'&&e.by===by&&e.at>=at));
  return {status:200,json:{withdrawn:before-queue.length}};
}

// ---- its settings, saved and loaded as a file (the owner, 3 November 2026: "We also need a way to save and load
// settings on the web page - which will allow me to show you settings that work, including for convincing attacks,
// saving potential extensive debugging loops - and must expose the settings of the player bot") ----
// (Every setting the page makes -- its pitch and dynamic, each dial and hole moved by its column's name, the lips or the
// slide dialled, its tongue, attack, breathing, techniques, repeats, vibrato, swell, tract, turbulence, noise and mute
// -- and its player bot's; with the row they make and the rules' under it, to read. Not whether it is blown.)
function settingsOf(){
  const name=k=>current.columns[k].join(':'),named=values=>Object.fromEntries(Object.entries(values).map(([k,v])=>[name(k),v]));
  const row=values=>Object.fromEntries(current.columns.map((c,k)=>[c.join(':'),values[k]]));
  return {family:'winds',model:current.model,body:current.name,mute:current.mute??null,pitch:state.pitch,charted:state.between?.low===state.between?.high,note:state.note,
    dynamic:state.dynamic,dials:named({...state.x,...state.pulled}),holes:named(state.fingers),lip:state.lipDialled?state.lip:null,lipForce:current.reedLip?state.lipForce:null,slide:state.slideDialled?state.slide:null,barrel:barrelAt(current)<0?null:state.barrel,
    articulation:{articulation:state.articulation,stroke:state.stroke,softSeconds:state.softSeconds,rise:state.rise},attack:state.breathAttack,
    breathing:state.breathing,flutter:state.flutter,hum:state.hum,growl:state.growl,repeat:state.repeat,vibrato:state.vibrato,swell:state.swell,
    tract:state.tract?.resonances??[],shape:state.shape,tractFollows:state.tractFollows,turbulence:state.turbulence,noise:state.noise,player:playerSettings,within:state.within,
    plays:{row:row(state.row),rules:row(state.rules),fingering:fingeringOf(state.row)}};
}
// (Settings a file kept, made on the instrument taken up, in the order the page would make them -- each through its
// own route and held to its limits there: its mute, the pitch, the lips or the slide, the dials and holes, then the rest
// -- those refused said, with why; its player's kept for its next piece. The mute first and its body taken up, where the
// bell is quiet, so that the note a file names is its chart's with that mute in and the rest are made on its rows: put in
// last, behind the page, the horn's stopped note 7 had been taken on its open chart as its note 21, and the tuba's
// straight mute was not yet in when the page wrote its address (the site's check, 6 November 2026). Where it is blown,
// the mute goes in as the page puts one in, once the bell is quiet.)
async function applySettings(s){
  if(s?.family!=='winds')throw new Error('a winds dial\'s settings (family "winds")');
  if(s.model!==current.model)throw new Error(`settings for the ${s.model}: take it up first`);
  const column=name=>current.columns.findIndex(c=>c.join(':')===name),refused=[];let made=0;
  const run=async(path,given)=>{try{await change(path,given);made++}catch(error){refused.push({path,error:error.message})}};
  if((s.mute??null)!==(current.mute??null)&&BRASS_MUTES[current.model]){
    try{muteTo(s.mute??null);
      if(muting&&!state.blowing&&current.frames>=quiet){muting.made??=await readied(muting.mute);if(muting?.made)changedOver()}
      made++}catch(error){refused.push({path:'/mute',error:error.message})}
  }
  // (Its barrel first: the note's tuning its ear kept is kept at its barrel.)
  if(s.barrel!=null)await run('/barrel',{pulled:s.barrel});
  await run('/pitch',s.charted&&Number.isInteger(s.note)?{pitch:s.pitch,dynamic:s.dynamic,charted:true,note:s.note}:{pitch:s.pitch,dynamic:s.dynamic});
  // (Within a player's body as it was kept; free where it was kept before the body was.)
  await run('/within',{on:s.within??false});
  if(s.lip!=null)await run('/lip',{lip:s.lip});
  if(s.lipForce!=null)await run('/lip',{force:s.lipForce});
  if(s.slide!=null)await run('/slide',{out:s.slide});
  for(const [route,values,key] of [['/dial',s.dials,'x'],['/hole',s.holes,'value']])for(const [name,v] of Object.entries(values??{})){
    const k=column(name);if(k<0)refused.push({path:route,error:`no column ${name} on this body`});else await run(route,{column:k,[key]:v})}
  if(s.articulation)await run('/articulation',s.articulation);
  if(s.attack)await run('/attack',{points:s.attack});
  for(const what of ['breathing','flutter','hum','growl','repeat','vibrato'])if(s[what])await run(`/${what}`,s[what]);
  if(s.swell!=null)await run('/swell',{share:s.swell});
  // (The players' tract following the note, where it followed; else the tract dialled, a shape's as it was kept.)
  if(s.tractFollows)await run('/tract',{follow:true});else if(s.shape)await run('/tract',{...s.shape,...(s.tract?.length?{resonances:s.tract}:{})});
  else if(s.tract)await run('/tract',{resonances:s.tract});
  if(s.turbulence!=null&&['reed','lips'].includes(current.kind))await run('/turbulence',{level:s.turbulence});
  if(s.noise)await run('/noise',s.noise);
  if(s.player){try{const {playerSettingsOf}=await import('./soloist.mjs');playerSettings=playerSettingsOf(s.player);made++}catch(error){refused.push({path:'/soloist',error:error.message})}}
  return {status:200,json:{...playing(),rules:state.rules,loaded:{made,refused},player:playerShown()}};
}

// Each route the page takes: what it asks (`method`, `path`, `query` its URLSearchParams, `given` what it sends) ->
// {status, json} or, its sound, {status, samples, headers}.
async function handle(method,path,query,given={}){
  try{
    if(path==='/state')return {status:200,json:shown()};
    // (What it plays now alone, and the instrument's version: taken as a piece is rendered first, to be shown as it is
    // heard (prerender.js).)
    if(path==='/played')return {status:200,json:{version,played:current?playing():null}};
    // (Its musebot as a player the studio's band takes (native/live/live.html, "Add to the band"): its bot, the notes the
    // dial plays and what it plays of its wind, as its own pieces tell it.)
    if(path==='/dialled'){
      if(!current)return {status:400,json:{error:'no instrument yet'}};
      const {playerOf,windsEngineOf}=await import('./soloist.mjs');
      return {status:200,json:{player:playerOf(current.model,current.kind),compass:compassNow(),engine:windsEngineOf(shown())}};
    }
    if(path==='/impedance')return {status:200,json:current?.impedance??null};
    // (Its body's shape, as its maker handed it to OpenWInD: the page's view of it in three dimensions, body-view.js.)
    if(path==='/geometry')return {status:200,json:current?.geometry??null};
    if(path==='/settings'&&method!=='POST')return current?{status:200,json:settingsOf()}:{status:400,json:{error:'no instrument yet'}};
    if(path==='/moves'&&method!=='POST')return current?{status:200,json:{model:current.model,body:current.name,rate:WINDS_RATE,frames:current.frames,moves,dropped:movesDropped}}:{status:400,json:{error:'no instrument yet'}};
    if(path==='/audio'){
      const frames=Math.min(Math.max(1,Number(query?.get('frames'))||1024),PULL_MOST);
      const samples=await serial(()=>pulled(frames));
      return {status:200,samples,headers:{'x-pace':pace==null?'':pace.toFixed(3),'x-model':current?.model??'','x-version':String(version),
        'x-lungs':`${lungs.air.toFixed(3)} ${lungs.taking?1:0}`,'x-seconds':String((current?.frames??0)/WINDS_RATE)}};
    }
    if(method!=='POST')return {status:404};
    // (Another instrument: made behind the page, the latest chosen taken up -- the page follows /state.)
    if(path==='/instrument'){choose(given.model);return {status:200,json:shown()}}
    if(path==='/keep'){
      if(!current)throw new Error('no instrument yet');
      const named=row=>Object.fromEntries(current.columns.map((c,k)=>[c.join(':'),row[k]]));
      const kept=await env.keep({at:new Date().toISOString(),model:current.model,body:current.name,...(current.mute?{mute:current.mute}:{}),midi:state.midi,pitch:state.pitch,...(current.lips?{lip:state.lip}:{}),
        ...(current.lips?.slide?{slide:state.slide,position:positionAt(state.slide)}:{}),...(barrelAt(current)<0?{}:{barrel:1000*current.joints.pulls[barrelAt(current)]}),
        dynamic:state.dynamic,words:String(given.words??''),row:named(state.row),rules:named(state.rules),tract:state.tract.resonances,...(state.shape?{shape:state.shape}:{}),
        articulation:state.articulation,stroke:state.stroke,softSeconds:state.softSeconds,rise:state.rise,breathAttack:state.breathAttack,repeat:state.repeat,vibrato:state.vibrato,
        breathing:state.breathing,flutter:state.flutter,hum:state.hum,growl:state.growl});
      return {status:200,json:{kept}};
    }
    if(!current)throw new Error('no instrument yet');
    // (A change the page made for the instrument it was showing: refused where another has been taken up since, so that
    // no column of one is dialled on another.)
    if(given.version!==undefined&&given.version!==version)return {status:409,json:{error:'another instrument was taken up',version}};
    // (Each change the page makes, made between two of its pulls of sound, so that it falls on the frame after the last
    // one pulled -- or, given `at`, at the frame that falls on: s on the dial's own clock, as each pull of sound says it.)
    if(path==='/withdraw')return await serial(()=>{moved(current.frames,path,given);return withdrawn(given)});
    if(path==='/afresh')return {status:200,json:{...await serial(afresh),rules:state.rules}};
    // (The solver at what the page plays, its sound heard in place of the dial's or not; on the solver's own dial, its
    // orbit at the row held.)
    if(path==='/solve')return {status:200,json:await solve()};
    if(path==='/hear'){hearing=Boolean(given.solver)&&solved?.model===current.model;return {status:200,json:{hearing}}}
    if(path==='/orbit')return {status:200,json:await serial(()=>current.stream.orbit({warm:given.warm,multipliers:given.multipliers,nudged:given.nudged??null,seconds:given.seconds}))};
    if(path==='/starts')return {status:200,json:await serial(()=>current.stream.starts(startsAsked(given)))};
    if(path==='/held')return {status:200,json:await serial(()=>heldAt(given))};
    // (Its joints, where its body has them: pulled, a note's orbit picked up for their tuning, and pulled to tune notes.)
    if(path==='/joints')return {status:200,json:await serial(()=>jointsPulled(given))};
    if(path==='/joint-note')return {status:200,json:await serial(()=>jointNote(given))};
    if(path==='/tune-joints')return {status:200,json:await serial(()=>jointsTuned(given))};
    // (Its body remade in place with its makers' adjustment points set, `given.made` a body made on the layout of
    // `given.laid`'s, the one it plays: winds-stream.mjs remade.)
    if(path==='/remade')return {status:200,json:await serial(async()=>({set:await current.stream.remade(String(given.laid),String(given.made))}))};
    if(path==='/points-step')return {status:200,json:await serial(()=>current.stream.pointsStep(given))};
    // (A body's tuning by its notes as they are heard, native/openwind/tune-body.mjs: the note's row and tract as it is
    // held now, its ear's moves left out; the lines its engine was sent since this was last asked, by which the compiled
    // tuning plays a note as its player here played it (winds-stream.mjs scripted; `given.on` false: kept no more); each
    // note's own start and its makers' points' rates on it (points.rs); and the points' move for notes heard (orbit.rs
    // points_move).)
    if(path==='/start-row')return {status:200,json:await serial(()=>startRow())};
    if(path==='/script')return {status:200,json:await serial(()=>({lines:current.stream.scripted(given.on!==false)}))};
    if(path==='/start-rates')return {status:200,json:await serial(async()=>({notes:await current.stream.startRates(given)}))};
    if(path==='/points-move')return {status:200,json:await serial(()=>current.stream.pointsMove(given))};
    // (The held note at a held note's controls, unmoved: its pitch, level and multipliers.)
    if(path==='/note')return {status:200,json:await serial(()=>heldNoteAt(given))};
    // (A start from silence at a held note's controls (heldControls: given's lip, breath and tract), how fast it grows and
    // at what pitch, its root sought from `hz` or `from`; a held note's settling once moved to them from the orbit saved
    // as `from` (heldAt's `save`); the page's controls put there: held-ranges.mjs's.)
    if(path==='/grows')return {status:200,json:await serial(()=>current.stream.grows({...heldControls(given),hz:Number(given.hz),from:given.from??null,checked:Boolean(given.checked)}))};
    if(path==='/settle')return {status:200,json:await serial(()=>current.stream.settles({...heldControls(given),from:String(given.from),hz:Number(given.hz),level:Number(given.level),
      cents:Number(given.cents),decibels:Number(given.decibels),hold:Number(given.hold),horizon:Number(given.horizon)}))};
    if(path==='/put')return {status:200,json:await serial(()=>{if(current.kind!=='reed')throw new Error('a reed\'s note: held by its lip and its breath');putAt(given,Number(given.moving??0));return playing()})};
    if(path==='/soloist')return await serial(()=>{moved(current.frames,path,given);return solo(given)});
    if(path==='/settings')return await serial(()=>{moved(current.frames,path,given);return applySettings(given.settings)});
    if(given.at!=null)return await serial(()=>later(path,given));
    const answer=await serial(()=>{if(CHANGES.has(path))moved(current.frames,path,given);return change(path,given)});
    if(answer===null)return {status:404};
    return {status:200,json:{...answer,rules:state.rules}};
  }catch(error){return {status:400,json:{error:error.message}}}
}

// (Let go: the engine played stopped.)
const close=()=>{closed=true;solver?.dial.close();for(const made of new Set([current,...bodies.values()]))if(made){made.glides?.stop();made.stream.close()}};
return {choose,handle,close};
}
