// What a live dial's musebot player needs beside its band of bots (solo-band.mjs composeBand): a player's settings as a
// page gives them, what a page is shown of them, and a line's MIDI 2.0 as its notes, each whole. By themselves, with
// the performers' vocabulary and the MIDI 2.0 codec alone, so that a dial's own Worker on a website carries these and
// not the bots, which compose in a Worker of their own there (native/live/site/solo-band-remote.js: the dial's Worker
// holds its engine, OpenWInD's scheme or Artifastring, GPL-3.0-or-later, and what is linked with it in that Worker is
// conveyed under that licence with its source; the bots are a program apart, asked for a piece by message).
// solo-band.mjs gives each on as its own.
//
//   playerSettingsOf({seed, seconds, personality}) -> {seed, seconds, personality}, or why not
//   playerShown(settings) -> what a page is shown of them
//   wholeNotes(events) -> [{at, events}]: a line's MIDI 2.0 as its notes, each whole, as a musebot sends its line
import {inspectUMP} from '../../public/shared/ump.js';
import {LEVERS,TONE_RANGES} from '../../public/shared/performers/personality.js';
import {LINE} from '../../public/shared/performers/line.js';

// A player's settings as a page gives them: its seed, the most it plays, s, and the levers of its personality it is
// given, each a share 0 to 1 by its name (personality.js LEVERS) -- a motif grammar's under `grammars`, a tone range's,
// [low, high] shares, under `ranges` (TONE_RANGES) -- every other drawn from its seed. -> {seed, seconds, personality},
// or why not.
export function playerSettingsOf({seed,seconds,personality}={}){
  if(!Number.isInteger(seed)||seed<0)throw new RangeError('a seed, a whole number from 0');
  if(!(seconds>0))throw new RangeError('the most it plays, s');
  const share=v=>typeof v==='number'&&v>=0&&v<=1,given={};
  for(const [name,value] of Object.entries(personality??{})){
    if(name==='grammars'&&value&&typeof value==='object'){const grammars=Object.fromEntries(Object.entries(value).filter(([g,v])=>LINE.grammars.includes(g)&&share(v)));if(Object.keys(grammars).length)given.grammars=grammars}
    else if(name==='ranges'&&value&&typeof value==='object'){
      const ranges=Object.fromEntries(Object.entries(value).filter(([r,v])=>TONE_RANGES.includes(r)&&Array.isArray(v)&&v.length===2&&v.every(share)&&v[0]<=v[1]));
      if(Object.keys(ranges).length!==Object.keys(value).length)throw new RangeError(`a personality's tone ranges, each [low, high] shares 0 to 1, low first: ${TONE_RANGES.join(', ')}`);
      if(Object.keys(ranges).length)given.ranges=ranges}
    else if(LEVERS.includes(name)&&share(value))given[name]=value;
    else throw new RangeError(`a personality's levers, each a share 0 to 1: ${LEVERS.join(', ')}, grammars (${LINE.grammars.join(', ')}) and ranges (${TONE_RANGES.join(', ')})`);
  }
  return {seed,seconds,personality:given};
}
// (What a page is shown of a player's settings: what can be given, its personality's levers, motif grammars and tone
// ranges, with those last given.)
export const playerShown=settings=>({...settings,levers:LEVERS,grammars:LINE.grammars,ranges:TONE_RANGES});

// (A line's MIDI 2.0 as its notes, each whole: from its Per-Note Management -- or its first event on its key -- to the
// next note begun on that key, its Note Off and its release's controllers with it; what names no note -- a channel's,
// as its bend range -- with the note after it. Each at its first event's time.)
const PER_NOTE=new Set(['perNoteManagement','perNoteController','assignablePerNoteController','perNoteBend','perNotePressure','noteOn','noteOff']);
export function wholeNotes(events){
  const notes=[],open=new Map;let loose=[];
  for(const event of events){
    const m=inspectUMP(event.packet);
    if(!PER_NOTE.has(m.kind)){loose.push(event);continue}
    let note=open.get(m.key);
    if(!note||m.kind==='perNoteManagement'){note={at:loose[0]?.seconds??event.seconds,events:loose};loose=[];notes.push(note);open.set(m.key,note)}
    note.events.push(event);
  }
  if(loose.length&&notes.length)notes.at(-1).events.push(...loose);
  return notes;
}
