// A website's dial asking its band of bots for a piece, the band in a Worker of its own (the owner, 17 November 2026, of
// what goes on the website: "compiled in a way that resists decompilation to the extent possible ... and that carries
// do-not-train restrictions and restrictive licensing to the extent possible while still respecting the licenses of VTL
// and Openwind"). A dial's Worker holds its engine -- OpenWInD's scheme, or Artifastring: GPL-3.0-or-later -- and what
// is linked with an engine in its Worker is conveyed under that licence with its source (scripts/build-live-site.mjs,
// SOURCES.html). The bots that compose are no part of that program: they are a program of their own (soloist/
// composer.js: composer-worker.js, native/live/solo-band.mjs), asked for a piece by message and answering with its
// notes, as a composer hands a player a part. This module stands in solo-band.mjs's place in a dial's musebot player
// (native/openwind/soloist.mjs, native/strings-model/soloist.mjs), put there by the site's build; on the Mac the
// soloists import solo-band.mjs itself.
//
//   await composeBand(given) -> as solo-band.mjs composeBand's, its answer copied across (plain data: its player, seed,
//     length, MIDI 2.0, captured events, a bowed string's planned strokes, its personality, warnings)
let composer=null,asked=0;
const waiting=new Map;
// (The band's Worker, started when a piece is first asked for, beside this module's bundle in soloist/. One that fails
// is said to each piece waiting on it, and started again at the next.)
function band(){
  if(composer)return composer;
  composer=new Worker(new URL('./composer.js',import.meta.url),{type:'module'});
  composer.onmessage=({data:{id,composed,error,name}})=>{
    const piece=waiting.get(id);
    if(!piece)return;
    waiting.delete(id);
    if(error==null)piece.resolve(composed);else piece.reject(name==='RangeError'?new RangeError(error):new Error(error));
  };
  composer.onerror=event=>{
    const failed=new Error(`the band of bots did not start (${event?.message??'its Worker failed'})`);
    for(const piece of waiting.values())piece.reject(failed);
    waiting.clear();composer=null;
  };
  return composer;
}
export function composeBand(given){
  return new Promise((resolve,reject)=>{const id=++asked;waiting.set(id,{resolve,reject});band().postMessage({id,given})});
}
