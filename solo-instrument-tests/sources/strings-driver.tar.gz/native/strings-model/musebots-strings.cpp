// Musebots' driver for Artifastring (GPL-3.0, Graham Percival): renders one player's timed actions to a 32-bit float WAV,
// heard through its body as the live host hears it (musebots-body.h: its offset blocked, corrected to its instrument's
// radiation, radiating under its fitted corner). Built against the locally patched GPL-3.0 Artifastring by engine.mjs,
// with the live host, from one source with one set of flags; run as its own process.
//   musebots-strings ACTIONS OUT.wav TYPE VARIANT SEED [SILENT]
// TYPE as the engine has its instruments, in the registry's order (public/shared/performers/bowed-instruments.js BOWED:
// 0 violin, 1 viola, 2 cello, then each with strings of its own -- 3 the contrabass, 4 the violello --, each on the
// solver it names with its bodies scaled, at its own pitch: musebots-instruments.h).
// SILENT, where given (a build whose capabilities say ringsDown): the level of its own output under which its sound is
// lost under the file's smallest step, its caller's gain taken into account (render/node/physical-strings.mjs).
// From its last action it renders on, every released string ringing down by its own modes' losses (patches/ramps.patch:
// never turned off at once), until 10 ms of it (the window audit_renders.py hears a cut in) peak under it: a part that
// ends in silence, never cut (the owner, 16 October 2026: "make sure that renders never end with audio above zero"). At
// most as long as its slowest mode takes to fall from the part's peak to SILENT; a bow still on a string, or a string
// with a mode that never decays, is said and the part not rung down.
// Actions, one a line, times in seconds, strings 0 (lowest) to 3:
//   f t string position          a finger at `position` (0 open, fraction of the string from the nut)
//   h t string position firmness a light finger contact; firmness multiplies Artifastring's K_FINGER, not newtons
//   b t string pos force vel     the bow at `pos` (fraction from the bridge), `force` (0 lifts it), `vel` (m/s, signed)
//   a t string pos force vel acc the bow moving toward `vel` at `acc` (m/s^2)
//   p t string pos force         a pluck
//   t t string ratio             the string's tension set to sound `ratio` times its own pitch (its tension times
//                                ratio squared): a pitch nearer the open string than a finger can stably stop
//   r t string ratio             the finger's damping, `ratio` times the model's own
//   d t string ratio slope       the string's modal losses, mode n's (1-based) times ratio * n^slope: what the model
//                                lacks of a plucked string's losses to the body, measured on recorded pizzicati
//   u t string static dynamic v0 the string's friction under the bow: its static and dynamic coefficients and its
//                                hyperbolic curve's slope (Artifastring's mu_s, mu_d, v0), each times its own -- for
//                                fitting the string to strings measured bowed (research/STRINGS_FITTED_BOWING.md)
//   c t string T L d pl E r0 r2  the string itself replaced: tension (N), length (m), diameter (m), linear density (kg/m),
//                                Young's modulus (Pa), and its losses a law of each mode's frequency, r0 + r2 f^2 (1/s) --
//                                as many modes as stand under 0.45 of the string's own rate, at most the build's
//                                MAX_MODAL_DECAY_MODES: an instrument the model has no tables for (a contrabass's strings
//                                on the cello's model, played at their own pitch, never slowed; research/
//                                STRINGS_FITTED_BOWING.md)
//   x t string width [span]      the bow's hair `width` m across the string (0 the point bow), moved over `span` s: the
//                                live host's ribbon (musebots-strings-live.cpp `x`), so the renders bow as the dial does
//   q t string speed Z Q         the string's torsion (built with -DMUSEBOTS_TORSION against a source whose string has
//                                set_torsion): its torsional wave speed (m/s), its impedance at its surface (kg/s) and Q --
//                                the bow's friction twisting it as well as moving it (research/STRINGS_FITTED_BOWING.md);
//                                Z 0 none, Artifastring's own string
//   v t string T L d pl E eF eB eA  the string replaced as c replaces it, its losses C. Valette's law as H. Mansour, J.
//                                Woodhouse & G. Scavone fitted it to measured cello strings ("Enhanced wave-based
//                                modelling of musical strings. Part 1: plucked strings", Acta Acustica united with
//                                Acustica 102(6), 2016, doi:10.3813/AAA.919021, eq. 6): mode n's Q (T + EI k^2) /
//                                (T (eF + eA / w) + EI eB k^2), k = n pi / L, w its angular frequency, EI = E pi d^4 / 64
//                                -- "friction", "air" and "bending" losses
//   e t string mu_s mu_d a v1 v2 the string's friction curve a sum of two exponentials in place of Artifastring's
//                                hyperbola (built with -DMUSEBOTS_FRICTION against a source whose string has
//                                set_friction_exponential): mu = mu_d + (mu_s - mu_d)(a exp(-|dv|/v1) + (1-a) exp(-|dv|/v2))
//                                -- the measured rosins' laws among its members (research/STRINGS_FITTED_BOWING.md)
//   n t what sd temperature beta low high [tremorHz tremorQ tremorShare]
//                                the player's noise (built with -DMUSEBOTS_NOISE against a source whose string has
//                                player_noise: patches/noise.patch): `what` 0 the bow's force or 1 its speed (`sd` a share
//                                of it), 2 its place (a share of the string's length) or 3 each stopping finger's pitch
//                                (cents), a seeded stream of the profile given (Hz) times its temperature (0 none) --
//                                musebots-player-noise.h, research/NOISE_AND_TEMPERATURE.md
//   w t                          wait until t
// A trailing duration (s) on f, h, b, a, t, d or u, and after it 1 for a straight line, moves what the action sets from
// where it stands over that time, along a raised cosine (or the line: one segment of a curve sampled more finely than a
// change), every one of the instrument's samples, inside the string (built with -DMUSEBOTS_RAMPS against a source whose
// string has bow_ramp: patches/ramps.patch): nothing a player does changes in one sample (the owner, 16 October 2026:
// "making sure nothing changes instantaneously"; public/shared/performers/transitions.js, the least each change may
// take). A bow set down ramps up from no force at its new place and speed (a), or from rest (a: accelerated as asked); a
// bow moved to no force leaves the string at its end; a bow ramped on one string releases no other, so that a crossing
// leaves one as it reaches the next. A finger set on an open string presses at its place from no firmness; lifted, its
// firmness lets go at its place. Tension, friction and losses move with t, d and u. Without a duration, at once, as
// before; a duration given to a build without ramps is refused.
// Built with -DMUSEBOTS_BRIDGE_FORCE (build.mjs, MUSEBOTS_STRINGS_DEFINES) against a source whose instrument has
// wait_samples_bridge, and run with MUSEBOTS_STRINGS_BRIDGE=1, it writes the strings' forces on the bridge summed, before
// the body (N), in place of the sound: the string measured against bowed strings' measured bridge forces
// (research/STRINGS_FITTED_BOWING.md).
// A sample that runs away (not finite, or past RUNAWAY: the model unstable for a moment, as violin variant 2's E string
// bowed hard near the bridge after some notes and not others -- a bug of Artifastring's bow_accel, since patched: a stroke
// begun after a release at the bow's last place kept the release's contact point beside the finger) is not let poison the rest: the 10 ms before it faded,
// silence from it, and a fresh instrument made with every string's tension, losses, finger damping, finger and bow as
// they were, from which the part goes on; each time written to OUT.wav.recoveries, that file this render's alone. A part
// that never runs away renders as it did before.
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <string>
#include <vector>
#include <fstream>
#include "musebots-player.h"

static std::vector<float> out;
static MusebotsPlayer *player = nullptr;
// (Rendered to `t` (s): the player's samples written on from where it stands.)
static void until(double t) {
    long target = (long)(t * ARTIFASTRING_INSTRUMENT_SAMPLE_RATE + 0.5);
    const long done = player->rendered();
    if (target < done) { fprintf(stderr, "actions go back in time at %f\n", t); exit(2); }
    if (target == done) return;
    out.resize(target);
    player->render(out.data() + done, (int)(target - done));
}
static void put32(FILE *f, uint32_t v) { fwrite(&v, 4, 1, f); }
static void put16(FILE *f, uint16_t v) { fwrite(&v, 2, 1, f); }
// (Where built with the bridge's force, it says so: MUSEBOTS_STRINGS_BRIDGE=1 writes it in place of the sound.)
#ifdef MUSEBOTS_BRIDGE_FORCE
#define BRIDGE_CAPABILITY "bridgeForce\":true,\""
#else
#define BRIDGE_CAPABILITY ""
#endif
#ifdef MUSEBOTS_RAMPS
#ifdef MUSEBOTS_RINGS_DOWN
#define RAMPS_CAPABILITY "ramps\":true,\"ringsDown\":true,\"body\":true,\"" BRIDGE_CAPABILITY
#else
#define RAMPS_CAPABILITY "ramps\":true,\"body\":true,\"" BRIDGE_CAPABILITY
#endif
#else
#define RAMPS_CAPABILITY "body\":true,\"" BRIDGE_CAPABILITY
#endif
int main(int argc, char **argv) {
    if (argc == 2 && !strcmp(argv[1], "--capabilities")) {
#if defined(MUSEBOTS_TORSION) && defined(MUSEBOTS_FRICTION)
        puts("{\"actions\":[\"f\",\"h\",\"b\",\"a\",\"p\",\"t\",\"d\",\"r\",\"u\",\"c\",\"v\",\"q\",\"e\",\"w\"],\"" RAMPS_CAPABILITY "naturalHarmonicContact\":true,\"artificialHarmonicContacts\":false,\"torsion\":true,\"exponentialFriction\":true}"); return 0;
#elif defined(MUSEBOTS_TORSION)
        puts("{\"actions\":[\"f\",\"h\",\"b\",\"a\",\"p\",\"t\",\"d\",\"r\",\"u\",\"c\",\"v\",\"q\",\"w\"],\"" RAMPS_CAPABILITY "naturalHarmonicContact\":true,\"artificialHarmonicContacts\":false,\"torsion\":true}"); return 0;
#else
        puts("{\"actions\":[\"f\",\"h\",\"b\",\"a\",\"p\",\"t\",\"d\",\"r\",\"u\",\"c\",\"w\"],\"" RAMPS_CAPABILITY "naturalHarmonicContact\":true,\"artificialHarmonicContacts\":false}"); return 0;
#endif
    }
    if (argc < 6) { fprintf(stderr, "usage: musebots-strings ACTIONS OUT.wav TYPE VARIANT SEED [SILENT]\n"); return 1; }
    const int type = atoi(argv[3]), variant = atoi(argv[4]);
    if (!musebotsType(type) || variant < 0) { fprintf(stderr, "invalid TYPE or VARIANT: %s %s\n", argv[3], argv[4]); return 1; }
#ifdef MUSEBOTS_BRIDGE_FORCE
    const bool bridge = getenv("MUSEBOTS_STRINGS_BRIDGE") && !strcmp(getenv("MUSEBOTS_STRINGS_BRIDGE"), "1");
#else
    const bool bridge = false;
#endif
    // (The player's instrument made, its body heard as the live host's is by default: musebots-player.h.)
    player = new MusebotsPlayer(type, variant, bridge);
    srand((unsigned)strtoul(argv[5], NULL, 10));
    player->seed(strtoull(argv[5], NULL, 10));
    std::ifstream in(argv[1]); std::string line;
    while (std::getline(in, line)) {
        if (line.empty() || line[0] == '#') continue;
        // (Each action at its time: the part rendered to it, then the action taken. Its time read as a double, as the
        // streaming player reads it: read as a float, an action now and then fell a sample from where the stream takes it,
        // and the string's motion went its own way from there.)
        double t;
        if (sscanf(line.c_str(), "%*c\t%lf", &t) == 1) until(t);
        const int result = player->apply(line);
        if (result < 0) { fprintf(stderr, "unknown action: %s\n", line.c_str()); return 3; }
        if (result > 0) return result;
    }
    if (argc > 6) {
#if !defined(MUSEBOTS_RAMPS) || !defined(MUSEBOTS_RINGS_DOWN)
        fprintf(stderr, "this build's strings are turned off at once (no MUSEBOTS_RINGS_DOWN in its source): never rung down\n"); return 3;
#endif
        const double silent = atof(argv[6]);
        if (!(silent > 0)) { fprintf(stderr, "invalid SILENT: %s\n", argv[6]); return 3; }
        // (Its slowest mode's decay rate, each string's as its last 't' and 'd' left it, and the part's peak.)
        const double slowest = player->slowest();
        double peak = 0;
        for (float v : out) peak = std::fmax(peak, std::fabs(v));
        const long window = ARTIFASTRING_INSTRUMENT_SAMPLE_RATE / 100;
        if (slowest > 0 && peak > silent) {
            const long from = player->rendered(), most = (long) ceil(log(peak / silent) / slowest * ARTIFASTRING_INSTRUMENT_SAMPLE_RATE);
            for (;;) {
                const long done = player->rendered();
                if (done >= window) {
                    float last = 0;
                    for (long i = done - window; i < done; i++) last = std::fmax(last, std::fabs(out[i]));
                    if (last < silent) break;
                }
                if (done - from >= most) { fprintf(stderr, "not under SILENT %g after %.1f s rung down (its slowest mode's fall from its peak)\n", silent, (double) (done - from) / ARTIFASTRING_INSTRUMENT_SAMPLE_RATE); break; }
                until((double) (done + window) / ARTIFASTRING_INSTRUMENT_SAMPLE_RATE);
            }
        } else if (!(slowest > 0)) fprintf(stderr, "a mode that never decays, or a bow still on: not rung down\n");
    }
    FILE *f = fopen(argv[2], "wb"); if (!f) return 4;
    // (Its runaways this render's alone: an earlier render's to the same file let go with its sound -- a clean render had
    // stood beside the record of one that ran away, and was read as having run away itself.)
    std::remove((std::string(argv[2]) + ".recoveries").c_str());
    const uint32_t bytes = (uint32_t)(out.size() * 4), rate = ARTIFASTRING_INSTRUMENT_SAMPLE_RATE;
    fwrite("RIFF", 1, 4, f); put32(f, 36 + bytes); fwrite("WAVEfmt ", 1, 8, f); put32(f, 16); put16(f, 3); put16(f, 1);
    put32(f, rate); put32(f, rate * 4); put16(f, 4); put16(f, 32); fwrite("data", 1, 4, f); put32(f, bytes);
    fwrite(out.data(), 4, out.size(), f); fclose(f);
    if (!player->recoveries.empty()) {
        std::string path = std::string(argv[2]) + ".recoveries"; FILE *r = fopen(path.c_str(), "w");
        if (r) { for (double at : player->recoveries) fprintf(r, "%.6f\n", at); fclose(r); }
    }
    delete player;
    return 0;
}
