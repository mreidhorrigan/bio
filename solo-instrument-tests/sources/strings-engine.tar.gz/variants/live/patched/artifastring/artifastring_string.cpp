/*
 * Copyright 2010--2013 Graham Percival
 * This file is part of Artifastring.
 *
 * Artifastring is free software: you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version.
 *
 * Artifastring is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public
 * License along with Artifastring.  If not, see
 * <http://www.gnu.org/licenses/>.
 */

#include "artifastring/artifastring_string.h"

#include <math.h>
///#include <stdlib.h> // for rand()
#include <algorithm> // for std::fill

#include <iostream>
//using namespace std;
#include <stdio.h>

#if NDEBUG
#include <emmintrin.h> // for _mm_setcsr
#endif

//#define WARN_SKIP

//#define DEBUG_ONLY_SINE_OUTPUT
//#define DEBUG_ONLY_WHITE_NOISE


#define EIGEN_NO_MALLOC
#include <Eigen/LU>

#ifdef RESEARCH
const int MAX_LINE_LENGTH = 2048;
#endif

const float FLOAT_EQUALITY_ABSOLUTE_ERROR = 1e-10f;
const float PI = 3.14159265358979f;

using namespace std;

// (Musebots, live: the constants Artifastring's source fixed, here variables a live host sets while it plays, each starting
// as Artifastring has it -- artifastring_constants.h.)
float PLUCK_VELOCITY = 0.1f;
float PLUCK_DISPLACEMENT = 0.005f;
float PLUCK_SECONDS = 0.1f;
float K_PLUCK = 1e4f;
float R_PLUCK = 1e1f;
float PLUCK_WIDTH = 0.012f;
float FINGER_WIDTH = 0.01f;
float A_noise = 0.02f;


ArtifastringString::ArtifastringString(InstrumentType which_instrument,
                                       int instrument_number, int string_number,
                                       int fs_multiplication_factor)
{
    //
    //_MM_SET_FLUSH_ZERO_MODE(_MM_FLUSH_ZERO_ON);
    //_MM_SET_DENORMALS_ZERO_MODE(_MM_DENORMALS_ZERO_ON);

    // set SSE denormals
#if NDEBUG
    _mm_setcsr( _mm_getcsr() | 0x8040 );
#endif
    fs_multiplier = fs_multiplication_factor;
    fs = fs_multiplier * ARTIFASTRING_INSTRUMENT_SAMPLE_RATE;
    dt = 1.0f / fs;
    //printf("fs: %i\tmult: %i\n", fs, fs_multiplier);

    switch (which_instrument) {
    case Violin: {
        int number = instrument_number % CONSTANTS_VIOLIN_NUM;
        set_physical_constants( violin_params[number][string_number] );
        break;
    }
    case Viola: {
        int number = instrument_number % CONSTANTS_VIOLA_NUM;
        set_physical_constants( viola_params[number][string_number] );
        break;
    }
    case Cello: {
        int number = instrument_number % CONSTANTS_CELLO_NUM;
        set_physical_constants( cello_params[number][string_number] );
        break;
    }
    }
    // (Musebots: rosin's friction as measured, every string's in place of its table's, where the build has it:
    // musebots-bow.h.)
    if (MUSEBOTS_BOW_MU_S > 0.0f) {
        String_Physical measured = pc;
        measured.mu_s = MUSEBOTS_BOW_MU_S;
        measured.mu_d = MUSEBOTS_BOW_MU_D;
        measured.v0 = MUSEBOTS_BOW_V0;
        set_physical_constants(measured);
    }

#ifdef RESEARCH
    logfile = NULL;
#endif
    debug_string_num = string_number;

    // srand( time(NULL) ); (Musebots: seeded by the driver, per player)
    //srand( string_number );
    //srand( 0 );

    // must happen after opening logfile!
    reset();
}

ArtifastringString::~ArtifastringString()
{
#ifdef RESEARCH
    logfile_close();
#endif
}

void ArtifastringString::set_N(unsigned int N_next)
{
#ifdef FIXEDSIZE
    (void) N_next;
    n = AA::LinSpaced(Eigen::Sequential, MODES, 1, MODES);
#else
    N = N_next;
    // (Musebots: an array whose length changes begun at zero -- the string's modes at rest -- and one whose length stays
    // kept as it was. Eigen's resize leaves a new array's values unset: the Mac's allocator, zeroing what is freed, handed
    // back zeros, and WebAssembly's whatever had been there, so that a string given another count of modes ran away at
    // the bow's first sample (the website's live dial, 2 November 2026).)
    for (AA *x : {&sc.X1, &sc.X2, &sc.X3, &sc.Y1, &sc.Y2, &sc.Y3, &sc.G, &vc.phix0, &vc.phix1, &vc.phix2, &ss.a, &ss.ad, &ah, &adh, &fn,
                  &n, &inside_phi})
        if (x->size() != (Eigen::Index) N) x->setZero(N);
    // (Musebots: 1 to N; Eigen deprecates its Sequential form, the same numbers.)
    n = AA::LinSpaced(N, 1, N);
#endif
}

// (Its seed mixed (splitmix64) so that neighbouring seeds draw unrelated noise; never the zero state xorshift keeps.)
void ArtifastringString::set_noise_seed(unsigned long long seed)
{
    unsigned long long z = seed + 0x9E3779B97F4A7C15ULL;
    z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ULL; z = (z ^ (z >> 27)) * 0x94D049BB133111EBULL; z ^= z >> 31;
    noise_state = z ? z : 0x9E3779B97F4A7C15ULL;
}

void ArtifastringString::reset()
{
#ifdef RESEARCH
    time_seconds = 0.0;
    num_skips = 0;
#endif

    // init everything, just to be safe
    cache_pc_c();

    plucks = 0;

    vc.x0  = 0.0f;
    vc.x1  = 0.0f;
    vc.x2  = 0.0f;
    vc.y_pluck = 0.0f;
    vc.y_pluck_target = 0.0f;
    va.Fb  = 0.0f;
    va.vb  = 0.0f;
    va.vb_target = 0.0f;
    va.va = 0.0f;
    vc.pluck_samples_remaining = 0;
    vc.recache = true;

    va.finger_position = 0.0f;
    va.bow_pluck_position = 0.0f;
    va.Kf = K_FINGER;
    va.Rf = 1.0f;

    vc.K0 = 0.0f;
    vc.R0 = 0.0f;
    vc.K2 = 0.0f;
    vc.K2 = 0.0f;

    ss.actions = OFF;

    ss.a.setZero();
    ss.ad.setZero();
    ss.slipstate = 0;

    debug_ticks = 0;
}

#ifdef RESEARCH
bool ArtifastringString::set_logfile(const char *filename)
{
    logfile_close();
    if (strlen(filename) == 0) {
        return true;
    }

    logfile = fopen(filename, "w");
    if (logfile == NULL) {
        return false;
    }

    char textline[MAX_LINE_LENGTH];
    sprintf(textline, "#time\tm_y0dot_h\tdv\tF0\tslip\tskip_warning\n");
    fwrite(textline, sizeof(char), strlen(textline), logfile);

    // for recache to get init params
    vc.recache = true;

    return true;
}

void ArtifastringString::logfile_data()
{
#ifdef RESEARCH
    if (logfile != NULL) {
        char textline[MAX_LINE_LENGTH];
        sprintf(textline,
                "%g\t%g\t%g\t%g\t%i\t%i\n",
                time_seconds, m_v0h, m_dv, m_F0, ss.slipstate, m_skip);
        fwrite(textline, sizeof(char), strlen(textline), logfile);
        time_seconds += dt;
    }
#endif
}
#endif

#ifdef RESEARCH
void ArtifastringString::logfile_close()
{
    if (logfile != NULL) {
        fclose(logfile);
        logfile = NULL;
    }
}
#endif

void ArtifastringString::finger_damping(const float ratio)
{
    va.Rf = ratio;
    vc.recache = true;
}

void ArtifastringString::finger(const float ratio_from_nut,
                                const float Kf_get)
{
    assert(ratio_from_nut >= 0.0f);
    assert(ratio_from_nut <= 1.0f);
    finger_moving.length = 0;

    if (ratio_from_nut == 0.0f) {
        va.finger_position = 0.0f;
    } else {
        va.finger_position = pc.L * (1.0 - ratio_from_nut);
    }

    va.Kf = Kf_get * K_FINGER;
    /*
    if (ratio_from_nut == 0.0) {
        vc.x1 = 0; // yes, don't reverse this one; optimization
        vc.recache = true;
    } else {
        //vc.K1 = K1;
        vc.K1 = 1e4f;
        vc.x1 = pc.L * (1.0 - ratio_from_nut);
        // yes, always recache here
        vc.recache = true;
    }
    */
    vc.recache = true;
}

void ArtifastringString::pluck(const float ratio_from_bridge,
                               const float pull_distance, const int samples)
{
    assert(ratio_from_bridge > 0.0f);
    assert(ratio_from_bridge < 1.0f);
    bow_moving.length = 0;
    va.bow_pluck_position = pc.L * ratio_from_bridge;

    ss.actions = PLUCK;
    vc.pluck_samples_remaining = PLUCK_SECONDS*fs;
    vc.y_pluck = 0.0f;
    vc.y_pluck_target = pull_distance * PLUCK_DISPLACEMENT;
    //printf("pluck target: %.5g\n", vc.y_pluck_target);
    // (Musebots: given `samples`, the finger takes hold of the string and pulls it smoothly -- its grip from none, its
    // pull's speed from none and back to none at its target, along the raised cosine over at least `samples`, and over as
    // long as a straight pull at PLUCK_VELOCITY takes where that is longer. Taken at once, a still string ticked as the
    // pull began and a ringing one clicked as the grip closed on it: the pops after pizzicati, 19 October 2026. Let go
    // as before.)
    if (samples > 0) {
        pluck_grip = 0.0f;
        pluck_gripping = {0, samples, false};
        const int straight = (int) ceilf(vc.y_pluck_target / (PLUCK_VELOCITY * dt));
        pluck_pulling = {0, std::max(straight, samples * fs_multiplier), false};
    } else {
        pluck_grip = 1.0f;
        pluck_gripping.length = 0;
        pluck_pulling.length = 0;
    }

    //printf("starting initial deaden part of pluck\n");
    /*
    vc.x0 = va.bow_pluck_position;
    vc.x1 = va.bow_pluck_position + 0.01;
    */
    //vc.K0 = 1e2f;
    //vc.K1 = 1e8f;
    /*
        const float distance_from_bridge = pc.L * ratio_from_bridge;
        if (! (almostEquals(vc.x0, distance_from_bridge)) )
        {
            vc.x0  = distance_from_bridge;
            vc.recache = true;
        }
        */
    vc.recache = true;
}

void ArtifastringString::bow_hair(const float width, const int samples)
{
    hair_from = hair_width;
    hair_to = width > 0.0f ? width : 0.0f;
    if (samples > 0 && hair_from != hair_to) {
        hair_moving.done = 0;
        hair_moving.length = samples;
        hair_moving.straight = false;
    } else {
        hair_moving.length = 0;
        hair_width = hair_to;
    }
    vc.recache = true;
}

void ArtifastringString::bow(const float bow_ratio_from_bridge,
                             const float bow_force, const float bow_velocity)
{
    //printf("bow: %g %g %g   tension %g\n", bow_ratio_from_bridge, bow_force, bow_velocity, pc.T);
    bow_moving.length = 0;
    if (bow_force == 0) {
        string_release();
        return;
    }
    if (ss.actions != BOW && ss.actions != BOW_ACCEL) {
        std::fill(hair_state.begin(), hair_state.end(), 0);
        hair_force.setZero();
        std::fill(hair_eta.begin(), hair_eta.end(), 0.0);
    }
    va.Fb = bow_force;
    va.vb = bow_velocity;
    const float bow_distance_from_bridge = pc.L * bow_ratio_from_bridge;
    if ( !(almostEquals(va.bow_pluck_position, bow_distance_from_bridge))
            || (ss.actions != BOW))
    {
        va.bow_pluck_position = bow_distance_from_bridge;
        //vc.x0 = bow_distance_from_bridge;
        vc.recache = true;
        //printf("recache %i\n", debug_string_num);
    }
    ss.actions = BOW;
}

void ArtifastringString::bow_accel(const float bow_ratio_from_bridge,
                                   const float bow_force, const float bow_velocity_target,
                                   const float bow_accel)
{
    // (Musebots: recached when the string comes to the bow from another state, as bow() is -- else a stroke begun just
    // after a release, at the bow's last place, kept the release's contact point, beside the finger, and the bow's
    // coefficients from before; the two points nearly coinciding, the string ran away: violin variant 2's E string,
    // Op. 3.31's cello's A string.)
    const bool bowing = (ss.actions == BOW) || (ss.actions == BOW_ACCEL);
    bow_moving.length = 0;
    ss.actions = BOW_ACCEL;
    va.Fb = bow_force;
    // (Musebots: a bow set on a string it was not bowing starts at rest on it -- left at its last stroke's velocity, a
    // stroke begun after a lift had set off at the old stroke's full speed under a light weight, its attack never rising;
    // and the bow accelerated toward its target whichever way that lies, at the magnitude asked -- update_bow_accel
    // reaches it from below only when its step is positive, so a bow asked to slow had jumped to its target in one
    // sample: every change of bow reversed at once, never through a stop.)
    if (!bowing) {
        va.vb = 0.0f;
        std::fill(hair_state.begin(), hair_state.end(), 0);
        hair_force.setZero();
        std::fill(hair_eta.begin(), hair_eta.end(), 0.0);
    }
    va.va = (bow_velocity_target >= va.vb ? 1.0f : -1.0f) * fabsf(bow_accel) * dt;
    va.vb_target = bow_velocity_target;
    const float bow_distance_from_bridge = pc.L * bow_ratio_from_bridge;
    if (! (almostEquals(va.bow_pluck_position, bow_distance_from_bridge)) || !bowing)
    {
        va.bow_pluck_position = bow_distance_from_bridge;
        //vc.x0 = bow_distance_from_bridge;
        vc.recache = true;
    }
}

String_Physical ArtifastringString::get_physical_constants()
{
    String_Physical pc_copy = pc;
    return pc_copy;
}

void ArtifastringString::set_physical_constants(String_Physical pc_new)
{
    constants_moving.length = 0;
    pc = pc_new;
#ifdef FIXEDSIZE
    set_N(MODES);
#else
    set_N(pc.N);
#endif
    cache_pc_c();
    vc.recache = true;
}

void ArtifastringString::cache_pc_c()
{
    sc.div_pc_L = 1.0f / pc.L;
    sc.sqrt_two_div_L = sqrt( 2.0f / pc.L);
    const float I = PI * pc.d*pc.d*pc.d*pc.d / 64.0f;

#ifdef FIXEDSIZE
    const AA ones = AA::Ones();
    AA rn;
    for (unsigned int i = 0; i < MODES; ++i) {
        rn(i) = pc.rn[i];
    }
#else
    AA ones(N);
    ones.resize(N);
    ones.setOnes();

    AA rn(N);
    rn.resize(N);
    for (unsigned int i = 0; i < N; ++i) {
        rn(i) = pc.rn[i];
    }
#endif

    const AA w0 = ( (pc.T/pc.pl) * ((n*PI*sc.div_pc_L).square())
                    + (pc.E*I/pc.pl) * ((n*PI*sc.div_pc_L).square().square()) ).sqrt();
#ifdef FIXEDSIZE
    const float highest_freq = w0[MODES-1] / (2*PI);
#else
    const float highest_freq = w0[N-1] / (2*PI);
#endif
    if (highest_freq > fs/2.0) {
        cout<<"BAD FREQ!  highest freq: "<<highest_freq;
        cout<<"           Nyquist freq: "<<fs/2.0<<endl;
    }
    // (Musebots: while the bow is on the string its modes lose as a bowed string's do, beyond its own: r0 + r2 f^2 at each
    // mode's frequency (generated/musebots-bow.h) -- the losses Matusiak & Chatziioannou fitted to a bowed string with no
    // torsion, less that string's own when plucked: the bow's friction twists the string, its torsional waves losing fast,
    // and the bow's hair damps it, neither of which the model has. Its own again once the bow leaves.)
    if (losses_bowed) rn += MUSEBOTS_BOWED_LOSS_R0 + MUSEBOTS_BOWED_LOSS_R2 * (w0 / (2.0f * (float) PI)).square();
    const AA w = (w0.square() - rn.square()).sqrt();

    sc.X1 = ((w*dt).cos() + (rn/w)*((w*dt).sin())) * ((-rn*dt).exp());
    sc.X2 = ((ones / w) * (w*dt).sin()) * ((-rn*dt).exp());
    sc.X3 = (ones - sc.X1) / (pc.pl * w0.square());
    //std::cout<<"X1"<<std::endl<<sc.X1<<std::endl;
    //std::cout<<"X3"<<std::endl<<sc.X3<<std::endl;

    sc.Y1 = -(w + rn.square()/w) * (w*dt).sin() * (-rn*dt).exp();
    sc.Y2 = ((w*dt).cos() - (rn/w)*((w*dt).sin())) * (-rn*dt).exp();
    sc.Y3 = -sc.Y1 / (pc.pl * w0.square());

    // (Musebots: a mode damped to critical or past it stepped exactly too. Its damped frequency w is then imaginary, w = ik
    // with k = sqrt(rn^2 - w0^2), and the same solution's cos(w dt) and sin(w dt)/w are cosh(k dt) and sinh(k dt)/k --
    // at critical, 1 and dt. A damping laid on a ringing string (a pizzicato stopped at its end) drives its upper modes
    // there, where sqrt(w0^2 - rn^2) had been NaN and the player had cut the sound to start the instrument again: the
    // pops after pizzicati, 19 October 2026. Modes under critical keep the expressions above, bit for bit.)
    for (int i = 0; i < (int) w0.size(); ++i) {
        const double r = rn(i), w0i = w0(i), past = r * r - w0i * w0i;
        if (past < 0.0) continue;
        const double k = sqrt(past), h = (double) dt, decay = exp(-r * h);
        const double c = k > 0.0 ? cosh(k * h) : 1.0, s = k > 0.0 ? sinh(k * h) / k : h;
        sc.X1(i) = (float) ((c + r * s) * decay);
        sc.X2(i) = (float) (s * decay);
        sc.X3(i) = (float) ((1.0 - (c + r * s) * decay) / (pc.pl * w0i * w0i));
        sc.Y1(i) = (float) (-w0i * w0i * s * decay);
        sc.Y2(i) = (float) ((c - r * s) * decay);
        sc.Y3(i) = (float) (w0i * w0i * s * decay / (pc.pl * w0i * w0i));
    }

    //std::cout<<"Y3"<<std::endl<<sc.Y3<<std::endl;

    sc.G = sc.sqrt_two_div_L * (pc.T*(n*PI*sc.div_pc_L) + pc.E*I*(n*PI*sc.div_pc_L).cube());

    inside_phi = n*PI*sc.div_pc_L;
    vc.recache = true;
}

void ArtifastringString::setup_vc_positions()
{
    // (Musebots: the stopping finger's place and the bow's with the player's noise -- player_noise -- none moving either
    // where it has none; the bow never pushed past half its own distance from the bridge.)
    const float finger_position = va.finger_position * noise_finger;
    vc.x1 = finger_position;
    vc.K1 = va.Kf;
    // (Musebots: a light touch the fingertip's pad as measured, its damping in proportion to its firmness at the pad's
    // ratio, held at the pad's measured damping from the measured touch to a finger stopping the string -- where
    // Artifastring scaled its own stopping finger's, 30 kg/s, by the firmness: generated/musebots-finger.h, Wiertlewski
    // & Hayward 2012.)
    vc.R1 = fminf(va.Kf * MUSEBOTS_FINGER_PAD_SECONDS, R_FINGER) * va.Rf;

    switch(ss.actions) {
    case BOW_ACCEL:
    case BOW: {
        vc.x0 = noise_place == 0.0f ? va.bow_pluck_position
                : std::max(va.bow_pluck_position + noise_place, 0.5f * va.bow_pluck_position);
        vc.x2 = 0.0f;
        break;
    }
    case RELEASE: {
        vc.x2 = 0.0f;
        vc.K2 = 0.0f;
        vc.R2 = 0.0f;
        if (finger_position == 0 ) {
            vc.x0 = 0.0f;
            vc.K0 = 0.0f;
            vc.R0 = 0.0f;
        } else {
            vc.K0 = vc.K1;
            vc.R0 = vc.R1;
            if (finger_position < pc.L - FINGER_WIDTH) {
                vc.x0 = finger_position + FINGER_WIDTH;
            } else {
                const float remaining_string = pc.L - finger_position;
                vc.x0 = finger_position + 0.5f*remaining_string;
            }
        }
        break;
    }
    case PLUCK: {
        vc.x0 = va.bow_pluck_position;
        vc.K0 = K_PLUCK * pluck_grip;
        vc.R0 = R_PLUCK * pluck_grip;
        vc.x2 = va.bow_pluck_position + PLUCK_WIDTH;
        vc.K2 = K_PLUCK * pluck_grip;
        vc.R2 = R_PLUCK * pluck_grip;
        break;
    }
    case OFF: {
        return;
        break;
    }
    }
    //printf("setup_vc_positions st %i: x0, x1, x2:\t%.4f\t%.4f\t%.4f\n",
    //       debug_string_num, vc.x0, vc.x1, vc.x2);
}


void ArtifastringString::cache_pa_c()
{
    //printf("cache_pa_c(), string %i, state %i\n",
    //    debug_string_num, ss.actions);


    setup_vc_positions();
    //printf("Ks Rs: %g %g %g %g %g %g\n",
    //    vc.K0, vc.K1, vc.K2, vc.R0, vc.R1, vc.R2
    //    );

    //n = AA::LinSpaced(Eigen::Sequential, MODES, 1, MODES);
    vc.phix0 = sc.sqrt_two_div_L * ( vc.x0*inside_phi ).sin();
    vc.phix1 = sc.sqrt_two_div_L * ( vc.x1*inside_phi ).sin();

    const float A00 = (sc.X3 * vc.phix0 * vc.phix0).sum();
    const float A01 = (sc.X3 * vc.phix0 * vc.phix1).sum();
    const float A11 = (sc.X3 * vc.phix1 * vc.phix1).sum();

    const float B00 = (sc.Y3 * vc.phix0 * vc.phix0).sum();
    const float B01 = (sc.Y3 * vc.phix0 * vc.phix1).sum();
    const float B11 = (sc.Y3 * vc.phix1 * vc.phix1).sum();

    switch(ss.actions) {
    case BOW_ACCEL:
    case BOW: {
        /*
        const float L2 = 1.0f / (A11*B00*vc.K1 - A01*B01*vc.K1+B00);
        vc.D5 = (1.0f + vc.K1*A11) * L2;
        vc.D6 = B01*vc.K1*L2;
        vc.D7 = 1.0f / (2.0f * vc.D5);
        */

        // bow coefficients
        const float L1 = 1.0f / (
                             (B00*B11 - B01*B01)*vc.R1 + (A11*B00 - A01*B01)*vc.K1 + B00);
        //printf("L1 parts: %g %g %g\n",
        //    (B00*B11 - B01*B01)*vc.R1, (A11*B00 - A01*B01)*vc.K1, B00);
        vc.D1 = (B11*vc.R1 + A11*vc.K1 + 1.0f)*L1;
        vc.D4 = 0.5f / vc.D1;
        vc.D2 = B01 * vc.K1 * L1;
        vc.D3 = B01 * vc.R1 * L1;

        // finger-during-bowing coefficients
        const float L2 = -1.0f / (B11*vc.R1 + A11*vc.K1 + 1.0f);
        vc.D5 = (B01*vc.R1 + A01*vc.K1) * L2;
        vc.D6 = vc.R1 * L2;
        vc.D7 = vc.K1 * L2;
        cache_hair();

        /*
                printf("D1: %g\n", vc.D1);
                printf("mu_s: %g\n", pc.mu_s);
                printf("mu_d: %g\n", pc.mu_d);
                printf("mu_v0: %g\n", pc.v0);
                */

        /*
                printf("L1, D1, D2, D3, D4\n");
                printf("%g %g %g %g %g\n", L1, vc.D1, vc.D2, vc.D3, vc.D4);
                printf("L2, D5, D6, D7\n");
                printf("%g %g %g %g\n", L2, vc.D5, vc.D6, vc.D7);
        */
        break;
    }
    case PLUCK: {
        vc.phix2 = sc.sqrt_two_div_L * ( vc.x2*inside_phi ).sin();
        const float A02 = (sc.X3 * vc.phix0 * vc.phix2).sum();
        const float A12 = (sc.X3 * vc.phix1 * vc.phix2).sum();
        const float A22 = (sc.X3 * vc.phix2 * vc.phix2).sum();

        const float B02 = (sc.Y3 * vc.phix0 * vc.phix2).sum();
        const float B12 = (sc.Y3 * vc.phix1 * vc.phix2).sum();
        const float B22 = (sc.Y3 * vc.phix2 * vc.phix2).sum();

        Eigen::Matrix3f matrix_A;
        matrix_A <<
                 B00*vc.R0 + A00*vc.K0 + 1.0f, B01*vc.R0 + A01*vc.K0,        B02*vc.R0 + A02*vc.K0,
                     B01*vc.R1 + A01*vc.K1,        B11*vc.R1 + A11*vc.K1 + 1.0f, B12*vc.R1 + A12*vc.K1,
                     B02*vc.R2 + A02*vc.K2,        B12*vc.R2 + A12*vc.K2,        B22*vc.R2 + A22*vc.K2 + 1.0f;
        //qr.compute(
        //    matrix_A);

        inv_A = matrix_A.inverse();

        /*
                Eigen::Matrix2f matrix_A_release;
                matrix_A_release <<
                                 B11*vc.R1 + A11*vc.K1 + 1.0f, B12*vc.R1 + A12*vc.K1,
                                     B12*vc.R2 + A12*vc.K2,        B22*vc.R2 + A22*vc.K2 + 1.0f;
                qr2.compute(
                    matrix_A_release);
                inv_A_release = matrix_A_release.inverse();
                */
        //printf("inverse\n");
        //std::cout<< inv_A_release << std::endl;
        /*
          (Eigen::MatrixXf(3,3) << B00*vc.R0 + A00*vc.K0 + 1.0f, B01*vc.R0 + A01*vc.K0,        B02*vc.R0 + A02*vc.K0,
          B01*vc.R1 + A01*vc.K1,        B11*vc.R1 + A11*vc.K1 + 1.0f, B12*vc.R1 + A12*vc.K1,
          B02*vc.R2 + A02*vc.K2,        B12*vc.R2 + A12*vc.K2,        B22*vc.R2 + A22*vc.K2 + 1.0f).finished()
            );

        std::cout<< (Eigen::Matrix2f << 0, 1, 1, 0).finished();
        std::cout<<std::endl;
            */

        //std::cout<<A<<std::endl;
        break;
    }
    case RELEASE: {
        const float M00 = A00*vc.K1 + B00*vc.R1 + 1.0f;
        const float M01 = A01*vc.K1 + B01*vc.R1;
        const float M11 = A11*vc.K1 + B11*vc.R1 + 1.0f;

        const float L3 = -1.0f / ( M00 * M11 - M01*M01 );
        vc.D8 = -1.0 / M00;
        vc.D9 = M01 * vc.D8;
        vc.D10 = -M01 * L3;
        vc.D11 = M00 * L3;

        // extra inv_A for any remaining tick_pluck() which
        // occurs before a new buffer is called
        // (i.e. the switch/case in fill_buffer)
        Eigen::Matrix3f matrix_A;
        matrix_A <<
                 B00*vc.R0 + A00*vc.K0 + 1.0f, B01*vc.R0 + A01*vc.K0, 0.0f,
                     B01*vc.R1 + A01*vc.K1,        B11*vc.R1 + A11*vc.K1 + 1.0f, 0.0f,
                     0.0f, 0.0f, 1.0f;
        //qr.compute(
        //    matrix_A);

        inv_A = matrix_A.inverse();

        break;
    }
    case OFF: {
        break;
    }
    }

    /*
        const float L1old = -vc.K0 / (A00*A11*vc.K0*vc.K1
                                         - A01*A10*vc.K0*vc.K1
                                         + A11*vc.K1 + A00*vc.K0 + 1.0f);
        vc.D1old = -vc.K1 / (1.0f + vc.K1*A11);
        vc.D2old = A10 * vc.D1old;
        vc.D3old = (1.0f + vc.K1*A11) * L1old;
        vc.D4old = -A01*vc.K1*L1old;
    */
    /*
        if (B00 == 0.0f) {
            vc.D5 = 0.0f;
            vc.D6 = 0.0f;
            vc.D7 = 0.0f;
        } else {
            const float L2 = 1.0f / (A11*B00*vc.K1 - A10*B01*vc.K1+B00);
            vc.D5 = (1.0f + vc.K1*A11) * L2;
            vc.D6 = B01*vc.K1*L2;
            vc.D7 = 1.0f / (2.0f * vc.D5);
        }
    */
    //printf("Ds: %g %g %g %g %g %g\n", vc.D1old, vc.D2old, vc.D3old, vc.D4old, vc.D5, vc.D6);
    vc.recache = false;
}


inline float ArtifastringString::tick_bow()
{
    if (hair_wide) {
        return tick_bow_wide();
    }
    // "hands-free" modes
    ah  = sc.X1*ss.a + sc.X2*ss.ad;
    adh = sc.Y1*ss.a + sc.Y2*ss.ad;

    const float y1h = (vc.x1 > 0) ? (vc.phix1 * ah).sum() : 0;
    const float v1h = (vc.x1 > 0) ? (vc.phix1 * adh).sum() : 0;
    //const float y1h = (vc.phix1 * ah).sum();
    //const float v1h = (vc.phix1 * adh).sum();
    // Calculate excitation force
    const float v0h = (vc.phix0 * adh).sum();

    const float F0 = compute_bow(v0h, y1h, v1h);
    const float F1 = vc.D5*F0 + vc.D6*v1h + vc.D7*y1h;
    /*
    if (debug_string_num == 0) {
        //printf("%f %f %f\n", y1h, v1h, v0h);
        //printf("F0, F1\t%g %g\n", F0, F1);
        printf("%g\n", F0);
    }
    */

    {   // apply forces
        fn = vc.phix0*F0 + vc.phix1*F1;
        //std::cout<<fn<<std::endl;
        ss.a  = ah  + sc.X3*fn;
        ss.ad = adh + sc.Y3*fn;
    }

#ifdef RESEARCH
    m_F0 = F0;
    m_v0h = v0h;
#endif
    tick_output_force = F0;
    return compute_bridge_force();
}

inline float ArtifastringString::tick_pluck()
{
    // "hands-free" modes
    ah  = sc.X1*ss.a + sc.X2*ss.ad;
    adh = sc.Y1*ss.a + sc.Y2*ss.ad;

    // "hands-free" string displacement under force locations
#if 1
    const float y0h = (vc.phix0 * ah).sum();
    const float y1h = (vc.phix1 * ah).sum();
    const float y2h = (vc.phix2 * ah).sum();
    const float v0h = (vc.phix0 * adh).sum();
    const float v1h = (vc.phix1 * adh).sum();
    const float v2h = (vc.phix2 * adh).sum();
    const Eigen::Vector3f matrix_b =
        (Eigen::Vector3f() <<
         -v0h * vc.R0 - (y0h-vc.y_pluck) * vc.K0,
         -v1h * vc.R1 - y1h * vc.K1,
         -v2h * vc.R2 - (y2h-vc.y_pluck) * vc.K2
        ).finished();
#else
    const Eigen::Matrix<float, MODES, 3> vcs =
        (Eigen::Matrix<float, MODES, 3>()
         << vc.phix0, vc.phix1, vc.phix2).finished();

    const Eigen::Matrix<float, 2, MODES> ahs =
        (Eigen::Matrix<float, 2, MODES>()
         << ah.transpose(), adh.transpose()).finished();

    const Eigen::Matrix<float, Eigen::Dynamic, Eigen::Dynamic> yv = ahs * vcs;

    /*
        std::cout<< yv.rows() << "\t" << yv.cols() << std::endl;
        printf("%g %g %g\n", y0h, y1h, y2h);
        printf("%g %g %g\n", yv(0,0), yv(0,1), yv(0,2));
        //std::cout<< yv <<std::endl;
        printf("\n");
        */

    const Eigen::Vector3f matrix_b =
        (Eigen::Vector3f() <<
         -yv(1,0) * vc.R0 - (yv(0,0)-vc.y_pluck) * vc.K0,
         -yv(1,1) * vc.R1 - yv(0,1) * vc.K1,
         -yv(1,2) * vc.R2 - (yv(0,2)-vc.y_pluck) * vc.K2
        ).finished();
#endif
    // forces at those locations

    const Eigen::Vector3f Fs = inv_A * matrix_b;

    // apply forces
    fn = vc.phix0*Fs(0) + vc.phix1*Fs(1) + vc.phix2*Fs(2);
    ss.a  = ah  + sc.X3*fn;
    ss.ad = adh + sc.Y3*fn;
    return compute_bridge_force();
}

inline float ArtifastringString::tick_release()
{
    // "hands-free" modes
    ah  = sc.X1*ss.a + sc.X2*ss.ad;
    adh = sc.Y1*ss.a + sc.Y2*ss.ad;

    // "hands-free" string displacement under force locations
    const float y0h = (vc.phix0 * ah).sum();
    const float y1h = (vc.phix1 * ah).sum();
    //const float y2h = (vc.phix2 * ah).sum();
    const float v0h = (vc.phix0 * adh).sum();
    const float v1h = (vc.phix1 * adh).sum();
    //const float v2h = (vc.phix2 * adh).sum();
    /*
    const float y1h = ah.matrix().dot(vc.phix1.matrix());
    const float y2h = ah.matrix().dot(vc.phix2.matrix());
    const float v1h = adh.matrix().dot(vc.phix1.matrix());
    const float v2h = adh.matrix().dot(vc.phix2.matrix());
    */
    /*
    printf("y1h, y2h, v1h, v2h:\t%g %g %g %g\n",
        y1h, y2h, v1h, v2h);
    */

    /*
        Eigen::Vector3f matrix_b;
        matrix_b << -v0h * vc.R0 - (y0h-vc.y_pluck) * vc.K0,
                 -v1h * vc.R1 - y1h * vc.K1,
                 -v2h * vc.R2 - (y2h-vc.y_pluck) * vc.K2;
        */
    /*
    matrix_b <<
             -v1h * vc.R1 - y1h * vc.K1,
             -v2h * vc.R2 - y2h * vc.K2;
      */
    //matrix_b << 0, 0;
    //printf("matrix_b:\n");
    //std::cout<<matrix_b<<std::endl;

    //(void) inv_A;
    //(void) b;
    //std::cout<<b;
    //const Eigen::Vector2f Fs = qr2.solve(matrix_b);
    //const Eigen::Vector2f Fs = inv_A_release * matrix_b;
    //const Eigen::Vector3f Fs = inv_A * matrix_b;
    //Eigen::Vector3f Fs;
    //Fs << 0, 0, 0;

    /*
    debug_ticks++;
    std::cout<<debug_ticks<<std::endl;

    std::cout<< "---" <<std::endl;
    std::cout<< vc.y_pluck <<std::endl;
    std::cout<< b <<std::endl;
    std::cout<< Fs <<std::endl;
    */
    // external forces
    //const float F0 = vc.D3old*(y0h-vc.y0d) + vc.D4old*y1h;
    //const float F1 = vc.D1old*y1h          + vc.D2old*F0;

    const float ans0 = vc.K1*y0h + vc.R1*v0h;
    const float ans1 = vc.K1*y1h + vc.R1*v1h;

    const float F1 = ans0 * vc.D10 + ans1 * vc.D11;
    const float F0 = ans0 * vc.D8 + F1 * vc.D9;

    // apply forces
    {
        fn = vc.phix0*F0 + vc.phix1*F1;
        ss.a  = ah  + sc.X3*fn;
        ss.ad = adh + sc.Y3*fn;
    }
    return compute_bridge_force();
}

inline float ArtifastringString::tick_free()
{
    // necessary to avoid aliasing
    ah  = sc.X1*ss.a + sc.X2*ss.ad;
    adh = sc.Y1*ss.a + sc.Y2*ss.ad;
    ss.a  = ah;
    ss.ad = adh;
    return compute_bridge_force();
}


void ArtifastringString::update_bow_accel() {
    // accelerate bow
    va.vb += va.va;
    if (va.va > 0) {
        if (va.vb > va.vb_target) {
            va.vb = va.vb_target;
            ss.actions = BOW;
        }
    } else {
        if (va.vb < va.vb_target) {
            va.vb = va.vb_target;
            ss.actions = BOW;
        }
    }
    //printf("%g\t%g\n", time_seconds, va.vb);
    //printf("%g\n", va.vb);
}

void ArtifastringString::update_pluck_actions() {
    vc.pluck_samples_remaining -= 1;
    if (pluck_pulling.length > 0) {
        vc.y_pluck = vc.y_pluck_target * moved(pluck_pulling);
    } else if (vc.y_pluck < vc.y_pluck_target) {
        vc.y_pluck += PLUCK_VELOCITY*dt;
    }
    //printf("%i\t%.4f\n", vc.pluck_samples_remaining, vc.y0d);
    //vc.y0d += std::min(PLUCK_ACCELERATION, PLUCK_DISPLACEMENT - vc.y0d);
    if (vc.pluck_samples_remaining == 0) {
        // pluck stop
        string_release();
    }
}

void ArtifastringString::string_release() {
    //printf("release num %i\n", debug_string_num);
    bow_moving.length = 0;
    // (Musebots: the hair slack once the bow has left the string.)
    std::fill(hair_eta.begin(), hair_eta.end(), 0.0);
    ss.actions = RELEASE;
    vc.y_pluck = 0;
    // can't use lazy evaluation this time,
    // because we aren't guaranteed to end fill_buffer()
    // on a 1024-sample boundary!
    cache_pa_c();
}

// (Musebots: while a control moves, one of the instrument's samples at a time, its controls set before each -- the
// instrument's filters still a buffer at a time. With none moving, as before.)
void ArtifastringString::fill_buffer_forces(float *buffer, float *forces,
        const int num_samples_instrument)
{
    int i = 0;
    while (i < num_samples_instrument
            && (bow_moving.length > 0 || finger_moving.length > 0 || constants_moving.length > 0 || hair_moving.length > 0
                || pluck_gripping.length > 0 || noise_moving.length > 0)) {
        step_ramps();
        fill_buffer_now(buffer + i * fs_multiplier, forces == NULL ? NULL : forces + i * fs_multiplier, 1);
        i++;
    }
    if (i < num_samples_instrument) {
        fill_buffer_now(buffer + i * fs_multiplier, forces == NULL ? NULL : forces + i * fs_multiplier,
                        num_samples_instrument - i);
    }
}

// (Musebots: how far a moving control has come, 0 to 1, once its next sample is counted; at its end it stops.)
inline float ArtifastringString::moved(Moving &m)
{
    m.done++;
    const double x = m.done >= m.length ? 1.0 : (double) m.done / (double) m.length;
    if (m.done >= m.length) {
        m.length = 0;
    }
    return m.straight ? (float) x : (float) (0.5 - 0.5 * cos(M_PI * x));
}

void ArtifastringString::bow_ramp(const float bow_ratio_from_bridge, const float bow_force,
                                  const float bow_velocity, const int samples, const bool straight)
{
    const bool bowing = (ss.actions == BOW) || (ss.actions == BOW_ACCEL);
    if (samples <= 0 || (!bowing && bow_force == 0)) {
        bow(bow_ratio_from_bridge, bow_force, bow_velocity);
        return;
    }
    bow_moving.length = 0;
    if (!bowing) {
        // (Set down at its new place and speed, its force from none: the first sample's force comes before its tick.)
        va.bow_pluck_position = pc.L * bow_ratio_from_bridge;
        va.vb = bow_velocity;
        va.Fb = 0.0f;
        vc.recache = true;
    }
    // (Its speed now moved, not accelerated: BOW's coefficients are BOW_ACCEL's.)
    ss.actions = BOW;
    bow_from[0] = va.bow_pluck_position;
    bow_from[1] = va.Fb;
    bow_from[2] = va.vb;
    bow_to[0] = pc.L * bow_ratio_from_bridge;
    bow_to[1] = bow_force;
    bow_to[2] = bow_velocity;
    bow_moving_speed = true;
    bow_moving.done = 0;
    bow_moving.straight = straight;
    bow_moving.length = samples;
}

void ArtifastringString::bow_accel_ramp(const float bow_ratio_from_bridge, const float bow_force,
                                        const float bow_velocity_target, const float accel,
                                        const int samples, const bool straight)
{
    const bool bowing = (ss.actions == BOW) || (ss.actions == BOW_ACCEL);
    if (samples <= 0) {
        bow_accel(bow_ratio_from_bridge, bow_force, bow_velocity_target, accel);
        return;
    }
    // (A bow not on the string moved toward no force: nothing to move.)
    if (!bowing && bow_force == 0) {
        return;
    }
    const float place = bowing ? va.bow_pluck_position : pc.L * bow_ratio_from_bridge;
    const float force = bowing ? va.Fb : 0.0f;
    bow_accel(bow_ratio_from_bridge, bow_force, bow_velocity_target, accel);
    // (Its force and place where they stood -- set down, its force from none -- and moved from there.)
    if (va.bow_pluck_position != place) {
        va.bow_pluck_position = place;
        vc.recache = true;
    }
    va.Fb = force;
    bow_from[0] = place;
    bow_from[1] = force;
    bow_to[0] = pc.L * bow_ratio_from_bridge;
    bow_to[1] = bow_force;
    bow_moving_speed = false;
    bow_moving.done = 0;
    bow_moving.straight = straight;
    bow_moving.length = samples;
}

void ArtifastringString::finger_ramp(const float ratio_from_nut, const float Kf_get,
                                     const int samples, const bool straight)
{
    const float place = (ratio_from_nut == 0.0f) ? 0.0f : pc.L * (1.0 - ratio_from_nut);
    const bool was_open = (va.finger_position == 0.0f), open = (place == 0.0f);
    if (samples <= 0 || ss.actions == OFF || (was_open && open)) {
        finger(ratio_from_nut, Kf_get);
        return;
    }
    finger_moving.length = 0;
    if (was_open) {
        // (Set on an open string: at its place, from no firmness -- no finger at all until it presses.)
        va.finger_position = place;
        va.Kf = 0.0f;
    }
    finger_from[0] = va.finger_position;
    finger_from[1] = va.Kf;
    finger_to[0] = open ? va.finger_position : place;
    finger_to[1] = open ? 0.0f : Kf_get * K_FINGER;
    finger_lifting = open;
    finger_after = Kf_get * K_FINGER;
    finger_moving.done = 0;
    finger_moving.straight = straight;
    finger_moving.length = samples;
    vc.recache = true;
}

void ArtifastringString::physical_constants_ramp(String_Physical pc_new, const int samples, const bool straight)
{
    if (samples <= 0 || ss.actions == OFF || pc_new.N != pc.N || pc_new.L != pc.L || pc_new.d != pc.d
            || pc_new.pl != pc.pl || pc_new.E != pc.E) {
        set_physical_constants(pc_new);
        return;
    }
    constants_from = pc;
    constants_to = pc_new;
    constants_moving.done = 0;
    constants_moving.straight = straight;
    constants_moving.length = samples;
}

// (Musebots: every moving control set for the instrument's next sample, the string's coefficients recomputed when its
// tension, losses, finger or bow's place moved; a bow moved to no force lifted.)
void ArtifastringString::player_noise(const float force, const float speed, const float place, const float finger,
                                      const int samples)
{
    const int steps = samples * fs_multiplier;
    noise_force_to = force;
    noise_speed_to = speed;
    if (steps > 0) {
        noise_force_step = (force - noise_force) / steps;
        noise_speed_step = (speed - noise_speed) / steps;
        noise_left = steps;
    } else {
        noise_force = force;
        noise_speed = speed;
        noise_left = 0;
    }
    // (The finger and the bow's place moved as a finger glides, over the same samples, the string's coefficients recomputed
    // each of the instrument's samples (step_ramps): a place moved at once jolts the string, a click 30 dB over a damped
    // pizzicato's ring.)
    if (samples > 0 && (noise_moving.length > 0 || place != noise_place || finger != noise_finger)) {
        noise_place_from = noise_place;
        noise_finger_from = noise_finger;
        noise_place_to = place;
        noise_finger_to = finger;
        noise_moving.done = 0;
        noise_moving.length = samples;
        noise_moving.straight = true;
    } else if (samples <= 0) {
        noise_moving.length = 0;
        if (place != noise_place || finger != noise_finger) {
            noise_place = place;
            noise_finger = finger;
            vc.recache = true;
        }
    }
}

void ArtifastringString::step_ramps()
{
    bool recache = false;
    if (constants_moving.length > 0) {
        const float e = moved(constants_moving);
        const String_Physical &a = constants_from, &b = constants_to;
        pc.T = a.T + (b.T - a.T) * e;
        pc.mu_s = a.mu_s + (b.mu_s - a.mu_s) * e;
        pc.mu_d = a.mu_d + (b.mu_d - a.mu_d) * e;
        pc.v0 = a.v0 + (b.v0 - a.v0) * e;
        pc.cutoff = b.cutoff;
        for (unsigned int k = 0; k < pc.N && k < (unsigned int) MAX_MODAL_DECAY_MODES; k++) {
            pc.rn[k] = a.rn[k] + (b.rn[k] - a.rn[k]) * e;
        }
        cache_pc_c();
        recache = true;
    }
    if (pluck_gripping.length > 0) {
        pluck_grip = moved(pluck_gripping);
        recache = true;
    }
    if (finger_moving.length > 0) {
        const float e = moved(finger_moving);
        va.finger_position = finger_from[0] + (finger_to[0] - finger_from[0]) * e;
        va.Kf = finger_from[1] + (finger_to[1] - finger_from[1]) * e;
        if (finger_moving.length == 0 && finger_lifting) {
            va.finger_position = 0.0f;
            va.Kf = finger_after;
        }
        recache = true;
    }
    if (hair_moving.length > 0) {
        const float e = moved(hair_moving);
        hair_width = hair_from + (hair_to - hair_from) * e;
        recache = true;
    }
    if (noise_moving.length > 0) {
        // (Recomputed only where they move the string: a finger stopping it, a bow on it.)
        const float e = moved(noise_moving), place = noise_place, finger = noise_finger;
        noise_place = noise_place_from + (noise_place_to - noise_place_from) * e;
        noise_finger = noise_finger_from + (noise_finger_to - noise_finger_from) * e;
        if ((va.finger_position != 0.0f && noise_finger != finger)
                || ((ss.actions == BOW || ss.actions == BOW_ACCEL) && noise_place != place)) {
            recache = true;
        }
    }
    if (bow_moving.length > 0) {
        const float e = moved(bow_moving);
        const float force = bow_from[1] + (bow_to[1] - bow_from[1]) * e;
        if (force <= 0.0f) {
            // (At no force the bow leaves the string: its release recaches the rest.)
            string_release();
            return;
        }
        va.Fb = force;
        if (bow_moving_speed) {
            va.vb = bow_from[2] + (bow_to[2] - bow_from[2]) * e;
        }
        const float place = bow_from[0] + (bow_to[0] - bow_from[0]) * e;
        if (place != va.bow_pluck_position) {
            va.bow_pluck_position = place;
            recache = true;
        }
    }
    if (recache) {
        cache_pa_c();
    }
}

void ArtifastringString::fill_buffer_now(float *buffer, float *forces,
        const int num_samples_instrument)
{
    {
        // (Musebots: the string's losses a bowed string's while the bow is on it, its own once it leaves: cache_pc_c.)
        const bool bowed = ss.actions == BOW || ss.actions == BOW_ACCEL;
        if (bowed != losses_bowed && (MUSEBOTS_BOWED_LOSS_R0 != 0.0f || MUSEBOTS_BOWED_LOSS_R2 != 0.0f)) {
            losses_bowed = bowed;
            cache_pc_c();
        }
    }
    if (vc.recache) {
        cache_pa_c();
    }
    int num_samples = fs_multiplier * num_samples_instrument;
    //printf("# fill_buffer_forces()  string_num, ss.actions, ticks, num_samples_instrument, num_samples\n: %i %i %i %i %i\n",
    //    debug_string_num, ss.actions, debug_ticks, num_samples_instrument, num_samples);

#ifdef DEBUG_ONLY_WHITE_NOISE
    for (int i=0; i<num_samples; i++) {
        buffer[i] = 2.0*(double(rand()) / RAND_MAX) - 1.0;
    }
    if (forces != NULL) {
        for (int i=0; i<num_samples; i++) {
            forces[i] = 2.0*(double(rand()) / RAND_MAX) - 1.0;
        }
    }
    return;
#endif

#ifdef DEBUG_ONLY_SINE_OUTPUT
    if (va.Fb == 0) {
        for (int i=0; i<num_samples; i++) {
            buffer[i] = 0;
            if (forces != NULL) {
                forces[i] = 0;
            }
        }
        return;
    }
    for (int i=0; i<num_samples; i++) {
        buffer[i] = sin( 10000.0*2*M_PI*dt*debug_ticks);
        //printf("%g\n", buffer[i]);
        if (forces != NULL) {
            forces[i] = sin( 10000.0*2*M_PI*dt*debug_ticks);
        }
        debug_ticks++;
    }
    return;
#endif



    switch(ss.actions) {
    case BOW: {
        //assert(force_samples != NULL);
        if (forces != NULL) {
            for (int i=0; i<num_samples; i++)
            {
                step_noise();
                buffer[i] = tick_bow();
                forces[i] = tick_output_force;
                //printf("%g\n", tick_output_force);
#ifdef RESEARCH
                logfile_data();
#endif
            }
        } else {
            for (int i=0; i<num_samples; i++)
            {
                step_noise();
                buffer[i] = tick_bow();
            }
        }
        /*
        for (int i=0; i<num_samples; i++)
        {
            buffer[i] = audio_samples[i];
        }
        */

        break;
    }
    case BOW_ACCEL: {
        //assert(force_samples != NULL);
        if (forces != NULL) {
            for (int i=0; i<num_samples; i++)
            {
                step_noise();
                buffer[i] = tick_bow();
                forces[i] = tick_output_force;
                update_bow_accel();
#ifdef RESEARCH
                logfile_data();
#endif
            }
        } else {
            for (int i=0; i<num_samples; i++)
            {
                step_noise();
                buffer[i] = tick_bow();
                update_bow_accel();
            }
        }
        break;
    }
    case RELEASE: {
        if (va.finger_position == 0) {
            for (int i=0; i<num_samples; i++)
            {
                buffer[i] = tick_free();
                //debug_ticks++;
#ifdef RESEARCH
                logfile_data();
#endif
            }
        } else {
            for (int i=0; i<num_samples; i++)
            {
                buffer[i] = tick_release();
                //debug_ticks++;
#ifdef RESEARCH
                logfile_data();
#endif
            }
        }
        //if (force_samples != NULL) {
        //std::fill(force_samples, force_samples+num_samples, 0.0);
        //}
        // (Musebots: a released string is never turned off -- Artifastring's saving for realtime, its motion zeroed in one
        // sample once a buffer's sum of squares fell under the string's `cutoff`, a step 72 to 81 dB under the driver's
        // full scale wherever a string fell quiet (measured 16 October 2026 on a violin's and a cello's lowest strings,
        // open and stopped) -- but rings down by its own modes' losses, as long as they take: the owner, 16 October 2026,
        // "making sure nothing changes instantaneously". The driver ends a part once its sound is lost under the file's
        // smallest step.)
        break;
    }
    case PLUCK: {
        for (int i=0; i<num_samples; i++)
        {
            buffer[i] = tick_pluck();
            //debug_ticks++;
            if (vc.pluck_samples_remaining > 0) {
                update_pluck_actions();
            }
            // if the pluck runs out, we'll still be calling
            // tick_pluck() but that's ok because the formula is
            // sufficiently general to handle that case as long as
            // x2 = 0
#ifdef RESEARCH
            logfile_data();
#endif
        }
        //if (force_samples != NULL) {
        //std::fill(force_samples, force_samples+num_samples, 0.0);
        //}
        break;
    }
    case OFF: {
        std::fill(buffer, buffer+num_samples_instrument, 0.0);
        //if (force_samples != NULL) {
        //std::fill(force_samples, force_samples+num_samples, 0.0);
        //}

#ifdef RESEARCH
        for (int i=0; i<num_samples; i++)
        {
            logfile_data();
        }
#endif
        break;
    }
    }
    //zz
}

inline float ArtifastringString::compute_bow_force(
    const float v0h, const float y1h, const float v1h, const float dv)
{
    return vc.D1*(bow_vb() + dv - v0h) + vc.D2*y1h + vc.D3*v1h;
}
inline float ArtifastringString::compute_bow_slip_negative(
    const float v0h, const float y1h, const float v1h)
{
    // add random noise
    const float ut = (float) noise_uniform();
    const float N = 1.0f - A_noise * ut;
    const float ve0 = N*pc.v0; // "v hat 0", or "v estimate 0"

    // handle negative side of friction curve
    const float c1 = -vc.D1*( bow_vb() - v0h - ve0)
                     -vc.D2*y1h
                     - vc.D3*v1h
                     + bow_Fb()*pc.mu_d;
    const float c0 = ve0 * (vc.D1 * (bow_vb() - v0h)
                            + vc.D2*y1h
                            + vc.D3*v1h
                            - bow_Fb() * pc.mu_s);
    // a real solution exists
    const float Delta = c1*c1 + 4.0f*c0*vc.D1;
    if (Delta >= 0.0f)
    {
        return vc.D4 * (c1 - sqrt(Delta));
    } else {
        return 0.0f;
    }
}

inline float ArtifastringString::compute_bow_slip_positive(
    const float v0h, const float y1h, const float v1h)
{
    // add random noise
    const float ut = (float) noise_uniform();
    const float N = 1.0f - A_noise * ut;
    const float ve0 = N*pc.v0; // "v hat 0", or "v estimate 0"

    // handle negative side of friction curve
    const float c1 = vc.D1*( bow_vb() - v0h + ve0)
                     + vc.D2*y1h + vc.D3*v1h + bow_Fb()*pc.mu_d;
    const float c0 = ve0 * (vc.D1 * (bow_vb() - v0h) + vc.D2 * y1h
                            + vc.D3 * v1h + bow_Fb() * pc.mu_s);
    // a real solution exists
    const float Delta = c1*c1 - 4.0f*c0*vc.D1;
    if (Delta >= 0.0f)
    {
        return vc.D4 * (-c1 + sqrt(Delta));
    } else {
        return 0.0f;
    }
}



inline float ArtifastringString::compute_bow(
    const float v0h, const float y1h, const float v1h)
{
    // GIVEN: bow force is above zero
    float F0;
    float dv;
    //printf("------ slipstate %i\n", ss.slipstate);
#ifdef RESEARCH
    m_dv = 99999;
    m_skip = 0;
#endif
    const float max_stable = pc.mu_s * bow_Fb();

    if (ss.slipstate == 0)
    {
        // is sticking
        F0 = compute_bow_force(v0h, y1h, v1h, 0);
        if (abs_le(F0, max_stable))
        {
#ifdef RESEARCH
            m_dv = 0;
#endif
            return F0;
        }
        if (v0h > bow_vb())
        {
            dv = compute_bow_slip_positive(v0h, y1h, v1h);
            if (dv > 0)
            {
#ifdef RESEARCH
                m_dv = dv;
#endif
                F0 = compute_bow_force(v0h, y1h, v1h, dv);
                ss.slipstate = 1;
                return F0;
            }
            dv = compute_bow_slip_negative(v0h, y1h, v1h);
            if (dv < 0)
            {
#ifdef RESEARCH
                m_dv = dv;
#endif
                F0 = compute_bow_force(v0h, y1h, v1h, dv);
                ss.slipstate = -1;
                return F0;
            }
            printf("yikes bad stick->positive\n");
        }
        else
        {
            dv = compute_bow_slip_negative(v0h, y1h, v1h);
            if (dv < 0)
            {
#ifdef RESEARCH
                m_dv = dv;
#endif
                F0 = compute_bow_force(v0h, y1h, v1h, dv);
                ss.slipstate = -1;
                return F0;
            }
            dv = compute_bow_slip_positive(v0h, y1h, v1h);
            if (dv > 0)
            {
#ifdef RESEARCH
                m_dv = dv;
#endif
                F0 = compute_bow_force(v0h, y1h, v1h, dv);
                ss.slipstate = 1;
                return F0;
            }
            printf("yikes bad stick->negative\n");
        }
    }
    if (ss.slipstate == -1)
    {
        // is slipping
        dv = compute_bow_slip_negative(v0h, y1h, v1h);
        if (dv < 0)
        {
#ifdef RESEARCH
            m_dv = dv;
#endif
            F0 = compute_bow_force(v0h, y1h, v1h, dv);
            return F0;
        }
        F0 = compute_bow_force(v0h, y1h, v1h, 0);
        if (abs_le(F0, max_stable))
        {
#ifdef RESEARCH
            m_dv = 0;
#endif
            ss.slipstate = 0;
            return F0;
        }
        else
        {
            dv = compute_bow_slip_positive(v0h, y1h, v1h);
            if (dv > 0)
            {
#ifdef RESEARCH
                m_skip = 1;
                num_skips++;
                m_dv = dv;
#endif
#ifdef WARN_SKIP
                printf("# bow skip negative->positive, st %i\n", debug_string_num);
#endif
                F0 = compute_bow_force(v0h, y1h, v1h, dv);
                num_friction_skip_over_stick++;
                ss.slipstate = 1;
                return F0;
            }
            printf("# yikes impossible failed -1\n");
            return 0;
        }
    }
    if (ss.slipstate == 1)
    {
        // is slipping
        dv = compute_bow_slip_positive(v0h, y1h, v1h);
        if (dv > 0)
        {
#ifdef RESEARCH
            m_dv = dv;
#endif
            F0 = compute_bow_force(v0h, y1h, v1h, dv);
            return F0;
        }
        F0 = compute_bow_force(v0h, y1h, v1h, 0);
        if (abs_le(F0, max_stable))
        {
#ifdef RESEARCH
            m_dv = dv;
#endif
            ss.slipstate = 0;
            return F0;
        }
        else
        {
            dv = compute_bow_slip_negative(v0h, y1h, v1h);
            if (dv < 0)
            {
#ifdef RESEARCH
                m_skip = 1;
                num_skips++;
                m_dv = dv;
#endif
#ifdef WARN_SKIP
                printf("# bow skip positive->negative, st %i\n", debug_string_num);
#endif
                F0 = compute_bow_force(v0h, y1h, v1h, dv);
                num_friction_skip_over_stick++;
                ss.slipstate = -1;
                return F0;
            }
            printf("# yikes impossible failed 1\n");
            return 0;
        }
    }
    printf("# yikes impossible failed everything\n");
    printf("slipstate: %i\n", ss.slipstate);
    printf("v0h: %g\n", v0h);
    return 0;
}



inline float ArtifastringString::compute_bridge_force()
{
    return (ss.a * sc.G).sum();
}

inline bool ArtifastringString::abs_le(const float one, const float two)
{
    if ( (fabsf(one) - two) <= std::numeric_limits<float>::epsilon()) {
        return true;
    } else {
        return false;
    }
}

inline bool ArtifastringString::almostEquals(float one, float two)
{
    // maximum absolute error
    if (fabs(one-two) < FLOAT_EQUALITY_ABSOLUTE_ERROR)
    {
        return true;
    }
    // don't bother with relative error (yet?)
    return false;
}


// (Musebots: the hair's cells and their coefficients. The ribbon's width cut into equal cells, each carrying its share
// of the bow's force and its own friction, its mode shapes averaged over its width (a ribbon's force spread across it,
// not put at a point: sin(n pi x/L) over a cell is its middle's times sinc(n pi w/2L)). Cells no narrower than the
// shortest wavelength the string's modes hold, 2L/N: over it a cell's average holds none of the highest mode, and
// narrower ones are not told apart by the modes. Points first put every L/N were not: each moved its neighbours a
// quarter as much as itself within a step, though no wave reaches the next in one, and held together they fought --
// the ribbon's friction gave out before a point bow's would, its points sticking and slipping by turns through what
// should be the stick, the bow-bridge stretch's ripple damped, the string's harmonics 4-6 cut 10-19 dB and its level
// 2.5 dB, all at once as a second point came to carry force (measured 17 October 2026; the owner heard the hair damp
// the string). A violin's 10 mm at the live rates is one cell, its force spread over the ribbon: against Schoonderwaldt,
// Guettler & Askenfelt's bowing machine (SMAC 03, violin D, beta 1/11, 400 mN, 30 cm/s), the harmonics under the 30th
// within a few dB from 0 to 15 mm, 8 mm 3-7 dB under 4 mm over the 35th (measured: narrower 3-6 dB over above the
// 20th). More modes (a faster rate) make the cells finer, each sticking and slipping on its own: partial slips across
// the ribbon, not yet checked against measurement; the hair's own give (Pitteroff & Woodhouse 1998, as Matusiak,
// Chatziioannou & Van Walstijn 2025, doi:10.3389/frsip.2025.1525044, take it) not yet modelled. Only cells between the bridge and the finger. W = B + B_f e: the cells' velocities'
// response to their forces over a step, the finger's force eliminated as cache_pa_c's D5-D7 eliminate it for the point
// bow. A cell's state and force carried to the cell now nearest it.)
void ArtifastringString::cache_hair()
{
    const double width = hair_width;
    const double far = vc.x1 > 0 ? vc.x1 : pc.L;
    // (A cell's mode shapes: sin(n pi x/L) averaged over w about x.)
    auto cell = [&](double x, double w) -> AA {
        AA half = (0.5f * (float) w) * inside_phi, sinc = half.sin() / half;
        if (w <= 0) sinc.setOnes();
        return sc.sqrt_two_div_L * ((float) x * inside_phi).sin() * sinc;
    };
    hair_cell = 2.0 * pc.L / (double) N;
    std::vector<double> x, share;
    std::vector<AA> phi;
    if (width > 0.0) {
        const int K = std::max(1, std::min(64, (int) floor(width / hair_cell)));
        const double w = width / K;
        for (int k = 0; k < K; k++) {
            // (Each cell clipped to the string between the bridge and the finger, its share with it.)
            const double a = std::max(vc.x0 - 0.5 * width + k * w, 0.0), b = std::min(vc.x0 - 0.5 * width + (k + 1) * w, far);
            if (b > a) { x.push_back(0.5 * (a + b)); share.push_back((b - a) / width); phi.push_back(cell(0.5 * (a + b), b - a)); }
        }
    }
    if (x.empty()) {
        // (No hair: Artifastring's own point bow, its state the nearest cell's.)
        if (hair_wide && !hair_x.empty()) {
            size_t near = 0;
            for (size_t k = 1; k < hair_x.size(); k++) if (fabs(hair_x[k] - vc.x0) < fabs(hair_x[near] - vc.x0)) near = k;
            ss.slipstate = hair_state[near];
        }
        hair_wide = false;
        hair_used = 1;
        hair_x.clear();
        hair_eta.clear();
        return;
    }
    const int K = (int) x.size();
    std::vector<int> state(K, ss.slipstate);
    std::vector<double> eta(K, 0.0);
    HairVector force = HairVector::Zero(K);
    for (int k = 0; k < K; k++) {
        if (hair_wide && !hair_x.empty()) {
            size_t near = 0;
            for (size_t i = 1; i < hair_x.size(); i++) if (fabs(hair_x[i] - x[k]) < fabs(hair_x[near] - x[k])) near = i;
            state[k] = hair_state[near];
            force(k) = hair_force(near) * share[k] / hair_share[near];
            if (near < hair_eta.size()) eta[k] = hair_eta[near];
        }
    }
    hair_wide = true;
    hair_used = K;
    hair_x = x;
    hair_share = share;
    hair_state = state;
    hair_force = force;
    hair_eta = eta;
    hair_phi = phi;
    const double A11 = (sc.X3 * vc.phix1 * vc.phix1).sum(), B11 = (sc.Y3 * vc.phix1 * vc.phix1).sum();
    const double L2 = -1.0 / (B11 * vc.R1 + A11 * vc.K1 + 1.0);
    hair_W.resize(K, K);
    hair_Bf.resize(K);
    hair_e.resize(K);
    for (int k = 0; k < K; k++) {
        const double Ak1 = (sc.X3 * hair_phi[k] * vc.phix1).sum(), Bk1 = (sc.Y3 * hair_phi[k] * vc.phix1).sum();
        hair_Bf(k) = Bk1;
        hair_e(k) = L2 * (vc.K1 * Ak1 + vc.R1 * Bk1);
    }
    for (int k = 0; k < K; k++) {
        for (int j = 0; j <= k; j++) {
            const double b = (sc.Y3 * hair_phi[k] * hair_phi[j]).sum();
            hair_W(k, j) = b;
            hair_W(j, k) = b;
        }
    }
    for (int k = 0; k < K; k++) {
        for (int j = 0; j < K; j++) {
            hair_W(k, j) += hair_Bf(k) * hair_e(j);
        }
    }
}

// (Musebots: one point of the hair's force for a step, as Artifastring's compute_bow finds its point bow's -- its stick
// force P (what holds the string at the bow's speed there), its admittance's inverse D1, its share of the bow's force,
// its friction curve's v0 lowered at random by up to A_noise as Artifastring's is, and its state, sticking (0) or
// slipping (+1 the string faster than the bow, -1 slower): sticking while P is within mu_s times its share; else
// slipping, its slip the root of Artifastring's quadratic that compute_bow_slip_positive or _negative takes, the same
// order of trial from each state, so that one point is Artifastring's own bow. `kept`: the point held in its state --
// sticking, the force holding it; slipping, its slip's root on that side, else the friction at the slip's edge.)
double ArtifastringString::hair_point(const double P, const double D1, const double share, const double ve0, int &state,
                                      const bool kept)
{
    const double most = pc.mu_s * share;
    auto positive = [&]() {
        const double c1 = D1 * ve0 + P + share * pc.mu_d, c0 = ve0 * (P + share * pc.mu_s), delta = c1 * c1 - 4.0 * c0 * D1;
        return delta >= 0.0 ? (-c1 + sqrt(delta)) / (2.0 * D1) : 0.0;
    };
    auto negative = [&]() {
        const double c1 = -P + D1 * ve0 + share * pc.mu_d, c0 = ve0 * (P - share * pc.mu_s), delta = c1 * c1 + 4.0 * c0 * D1;
        return delta >= 0.0 ? (c1 - sqrt(delta)) / (2.0 * D1) : 0.0;
    };
    double dv;
    if (kept) {
        if (state == 0) return P;
        if (state == 1) return (dv = positive()) > 0 ? P + D1 * dv : -most;
        return (dv = negative()) < 0 ? P + D1 * dv : most;
    }
    if (state == 0) {
        if (fabs(P) <= most) return P;
        // (The string ahead of the bow, its stick force negative: slipping forward tried first, as compute_bow does.)
        if (P < 0) {
            if ((dv = positive()) > 0) { state = 1; return P + D1 * dv; }
            if ((dv = negative()) < 0) { state = -1; return P + D1 * dv; }
        } else {
            if ((dv = negative()) < 0) { state = -1; return P + D1 * dv; }
            if ((dv = positive()) > 0) { state = 1; return P + D1 * dv; }
        }
        return P > 0 ? most : -most;
    }
    if (state == -1) {
        if ((dv = negative()) < 0) return P + D1 * dv;
        if (fabs(P) <= most) { state = 0; return P; }
        if ((dv = positive()) > 0) { state = 1; return P + D1 * dv; }
        return P > 0 ? most : -most;
    }
    if ((dv = positive()) > 0) return P + D1 * dv;
    if (fabs(P) <= most) { state = 0; return P; }
    if ((dv = negative()) < 0) { state = -1; return P + D1 * dv; }
    return P > 0 ? most : -most;
}

// (Musebots: the hair's forces for a step, the points' velocities u before them. Each point solved as Artifastring
// solves its point bow (hair_point), the others' forces as they stand, point after point; then the points that stick
// held together at the bow's speed, exactly (a linear solve), the slipping points' forces as they stand; passes until no
// force moves (a two-block Gauss-Seidel). A sticking point's force follows its neighbours' one for one, a slipping
// point's less (its friction holds it): passing over the sticking points one at a time settles them only as fast as
// their admittances overlap -- by a quarter at the spacing the string's modes tell apart (W's neighbouring terms .32 of
// its own, five points on a violin's G string at 104 modes) -- and holding them together settles them at once. Each
// point's state changed at most once in a step, as Artifastring's point bow changes its own at most once a step: a point
// breaking away slips for the rest of the step, one sticking again sticks. Free to change at every pass, a point at the
// edge of breaking away -- held by its neighbours' forces when it sticks, freed by them when it slips -- sticks and slips
// at alternate passes and never settles. Measured 17 October 2026 on a violin's G string, hair 10 mm, 104 modes, 30 s:
// every step settled within 16 passes at a bow force of 0.5 or 1 N; at the owner's 2.6 N, 2 steps in 100 did not, the
// points' friction falling as steeply as the string gives way under them, where even one point's step has two roots
// (Artifastring choosing between them by its state) -- left at their last pass's forces, each within its friction's
// reach, counted (get_hair_unsolved). Newton's method on all the points at once, before, jumped between those roots and
// ran away: pops up to 300 times the note's level on the same setting.)
void ArtifastringString::solve_hair(const HairVector &u)
{
    const int K = hair_used;
    double ve0[64], share[64];
    int state[64], stuck[64];
    bool changed[64];
    for (int k = 0; k < K; k++) {
        changed[k] = false;
        const double ut = noise_uniform();
        ve0[k] = (1.0 - A_noise * ut) * pc.v0;
        share[k] = bow_Fb() * hair_share[k];
        state[k] = hair_state[k];
    }
    // (The hair's give: each cell's stretch a spring and a dashpot in series with its contact, K and D its share of the
    // ribbon's (generated/musebots-bow.h, per metre of its width), so that its contact moves at the bow's speed less the
    // stretch's rate, (F - K eta) / D: its admittance 1/D more, and its bow faster by K eta / D. Pitteroff & Woodhouse 1998,
    // as Matusiak & Chatziioannou 2024 fitted it to a bowing robot's attacks, doi:10.1121/10.0028228.)
    const double hairK = (double) MUSEBOTS_HAIR_STIFFNESS * hair_width, hairD = (double) MUSEBOTS_HAIR_DAMPING * hair_width;
    double give[64], vb[64];
    for (int k = 0; k < K; k++) {
        give[k] = hairD > 0.0 ? 1.0 / (hairD * hair_share[k]) : 0.0;
        vb[k] = hairD > 0.0 ? bow_vb() + hairK * hair_eta[k] / hairD : bow_vb();
    }
    HairVector F = hair_force;
    for (int pass = 0; pass < 200; pass++) {
        const HairVector before = F;
        for (int k = 0; k < K; k++) {
            const double others = hair_W.row(k).dot(F) - hair_W(k, k) * F(k);
            const double D1 = 1.0 / (hairD > 0.0 ? hair_W(k, k) + give[k] : hair_W(k, k)), P = (vb[k] - u(k) - others) * D1;
            const int was = state[k];
            F(k) = hair_point(P, D1, share[k], ve0[k], state[k], changed[k]);
            if (state[k] != was) changed[k] = true;
        }
        int S = 0;
        for (int k = 0; k < K; k++) if (state[k] == 0) stuck[S++] = k;
        if (S > 1) {
            HairMatrix A(S, S);
            HairVector b(S);
            for (int i = 0; i < S; i++) {
                const int k = stuck[i];
                b(i) = vb[k] - u(k);
                for (int j = 0; j < K; j++) if (state[j] != 0) b(i) -= hair_W(k, j) * F(j);
                for (int m = 0; m < S; m++) A(i, m) = hair_W(k, stuck[m]);
                if (hairD > 0.0) A(i, i) += give[k];
            }
            const HairVector held = A.partialPivLu().solve(b);
            for (int i = 0; i < S; i++) F(stuck[i]) = held(i);
        }
        const double moved = (F - before).cwiseAbs().maxCoeff();
        if (moved <= 1e-12 * (1e-9 + F.cwiseAbs().maxCoeff())) {
            for (int k = 0; k < K; k++) hair_state[k] = state[k];
            hair_force = F;
            if (hairD > 0.0) for (int k = 0; k < K; k++) hair_eta[k] += (double) dt * (F(k) / (hairD * hair_share[k]) - hairK / hairD * hair_eta[k]);
            return;
        }
    }
    hair_unsolved++;
    for (int k = 0; k < K; k++) hair_state[k] = state[k];
    hair_force = F;
    if (hairD > 0.0) for (int k = 0; k < K; k++) hair_eta[k] += (double) dt * (F(k) / (hairD * hair_share[k]) - hairK / hairD * hair_eta[k]);
}

// (Musebots: a bowed step with the hair's points: as tick_bow, the finger's force eliminated, each point's force its own.)
float ArtifastringString::tick_bow_wide()
{
    ah  = sc.X1*ss.a + sc.X2*ss.ad;
    adh = sc.Y1*ss.a + sc.Y2*ss.ad;
    const float y1h = (vc.x1 > 0) ? (vc.phix1 * ah).sum() : 0;
    const float v1h = (vc.x1 > 0) ? (vc.phix1 * adh).sum() : 0;
    const double e0 = (double) vc.D7 * y1h + (double) vc.D6 * v1h;
    const int K = hair_used;
    HairVector u(K);
    for (int k = 0; k < K; k++) {
        u(k) = (hair_phi[k] * adh).sum() + hair_Bf(k) * e0;
    }
    solve_hair(u);
    const double F1 = hair_e.dot(hair_force) + e0;
    fn = vc.phix1 * (float) F1;
    double total = 0;
    for (int k = 0; k < K; k++) {
        fn += hair_phi[k] * (float) hair_force(k);
        total += hair_force(k);
    }
    ss.a  = ah  + sc.X3*fn;
    ss.ad = adh + sc.Y3*fn;
    tick_output_force = (float) total;
    return compute_bridge_force();
}
