/*
 * Copyright 2010--2013 Graham Percival
 * This file is part of Artifastring.
 *
 * Artifastring is free software: you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version.
 *
 * Artifastring is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public
 * License along with Artifastring.  If not, see
 * <http://www.gnu.org/licenses/>.
 */

#ifndef ARTIFASTRING_INSTRUMENT_H
#define ARTIFASTRING_INSTRUMENT_H

#include "artifastring/artifastring_defines.h"
#include "artifastring/artifastring_constants.h"
#include "artifastring/fft_convolution.h"

class ArtifastringString;

const int NUM_VIOLIN_STRINGS = 4;
const int NUM_MULTIPLIERS = 4;


/// \brief Main class for violin synthesis (if in doubt, use only this class).
class ArtifastringInstrument {
public:
    /**
     * \brief Constructor
     * @param[in] instrument_type The member of the violin family to
     * simulate.  See \ref InstrumentType
     * @param[in] instrument_number The instrument number within the family.
     * See \ref InstrumentType
     */
    ArtifastringInstrument(InstrumentType instrument_type=Violin,
                           int instrument_number=0);
    /// \brief Destructor; nothing special
    ~ArtifastringInstrument();
    /// \brief Stops all movement
    void reset();

    /** \brief Places finger on the string.
     *
     * Finger remains in place until moved.
     * @param[in] which_string Instrument string (0,1,2,3); higher
     * string numbers are higher in pitch.
     * @param[in] ratio_from_nut Measured as a fraction of string
     * length.
     * @param[in] Kf This sets how firmly the finger is
     * pressed against the string.  1.0 indicates normal finger
     * strength, while 0.0001 indicates a very light finger
     * suitable for playing harmonic notes.
     */
    void finger(int which_string, float ratio_from_nut, float Kf=1.0);
    void finger_damping(int which_string, float ratio);
    // (Musebots: each string's noise seeded from `seed` and its number: ArtifastringString::set_noise_seed.)
    void set_noise_seed(unsigned long long seed);
    // (Musebots: the bow's hair `width` m across on a string, moved over `samples` (ArtifastringString::bow_hair); the
    // points it touches the string at.)
    void bow_hair(int which_string, float width, int samples);
    // (Musebots: the player's noise on a string's bow and finger (ArtifastringString::player_noise).)
    void player_noise(int which_string, float force, float speed, float place, float finger, int samples);
    int hair_points(int which_string);
    // (Musebots: the narrowest cells the string's modes hold apart (m).)
    float hair_cell(int which_string);
    // (Musebots: the steps whose hair's forces did not settle, counted since the string was made.)
    int hair_unsolved(int which_string);
    // (Musebots: another body in place of the instrument's own, its impulse response `count` taps at the instrument's
    // rate -- the double bass's, the cello's scaled to its size (native/strings-model/musebots-instruments.h).)
    void set_body(const float *taps, int count);

    /** \brief Plucks a string.
     *
     * The pluck is simulated like a bow that pulls until
     * it slips for the first time; as a result, you cannot
     * predict when the pluck has finished "starting".
     * @param[in] which_string Instrument string (0,1,2,3); higher
     * string numbers are higher in pitch.  0 is the G string).
     * @param[in] ratio_from_bridge Measured as a fraction of
     * string length.
     * @param[in] pull_distance Measured in units of 5mm.  This
     * number was chosen so that a normal pluck on the violin uses
     * a pull distance of 1.0.  0.0 produces no pluck at all.
     */
    // (Musebots: `samples` > 0, the finger's grip and pull taken over that many samples: ArtifastringString::pluck.)
    void pluck(int which_string, float ratio_from_bridge,
               float pull_distance, int samples=0);

    /** \brief Sets the bow's action.
     *
     * Bow actions are assumed to continue until changed.
     * @param[in] which_string Instrument string (0,1,2,3); higher
     * string numbers are higher in pitch.  0 is the G string).
     * @param[in] bow_ratio_from_bridge Measured as a fraction of
     * string length.
     * @param[in] bow_force Measured in Newtons.
     * @param[in] bow_velocity Measured in meters / second.
     */
    void bow(int which_string, float bow_ratio_from_bridge,
             float bow_force, float bow_velocity);

    /** \brief Sets the bow to accelerate to a target velocity.
     *
     * Bow actions are assumed to continue until changed.
     * @param[in] which_string Instrument string (0,1,2,3); higher
     * string numbers are higher in pitch.  0 is the G string).
     * @param[in] bow_ratio_from_bridge Measured as a fraction of
     * string length.
     * @param[in] bow_force Measured in Newtons.
     * @param[in] bow_velocity_target Measured in meters / second.
     * @param[in] bow_accel Measured in meters / second^2.
     */
    void bow_accel(int which_string, float bow_ratio_from_bridge,
                   float bow_force, float bow_velocity_target,
                   float bow_accel);

    /** \brief Advances time and writes data to a buffer.
     *
     * Recommended: use MonoWav to get the short *buffer if you
     * want to write a wav file.  For realtime use, figure out the
     * buffer on your own.  :)
     * @param[out] *buffer Place to write output.
     * @param[in] num_samples Number of samples to advance.
     * @warning You are responsible for allocating sufficient
     * memory for the buffer.
     */
    int wait_samples(short *buffer, int num_samples);
    int wait_samples_float(float *buffer, int num_samples);
    // (Musebots: the strings' forces on the bridge summed, before the body -- for measuring the string against bowed
    // strings' measured bridge forces.)
    int wait_samples_bridge(float *buffer, int num_samples);
    // (Musebots: both at once, the sound and the bridge's force -- for hearing either live, one in place of the other.)
    int wait_samples_both(float *sound, float *bridge, int num_samples);

    int wait_samples_forces(short *buffer, short *forces, int num_samples);
    int wait_samples_forces_python(
        short *buffer, int num_samples,
        short *forces, int num_samples2
    );

    /** \brief Returns a string's physical constants.
     *
     * This method is not recommended for normal use; it is merely
     * a curiosity for people wanting to experiment.
     * @param[in] which_string Instrument string (0,1,2,3); higher
     * string numbers are higher in pitch.
     */
    String_Physical get_physical_constants(int which_string);

    /** \brief Sets a string's physical constants.
     *
     * This method is not recommended for normal use; it is merely
     * a curiosity for people wanting to experiment.
     * @param[in] which_string Instrument string (0,1,2,3); higher
     * string numbers are higher in pitch.
     * @param[in] pc_new String physical constants.
     */
    void set_physical_constants(int which_string, String_Physical pc_new);
    /// \brief Musebots: a string's controls moved over time (ArtifastringString::bow_ramp and the rest); a string bowed
    /// so releases no other -- a bow crossing strings leaves one as it reaches the next.
    void bow_ramp(int which_string, float bow_ratio_from_bridge, float bow_force, float bow_velocity,
                  int samples, bool straight=false);
    void bow_accel_ramp(int which_string, float bow_ratio_from_bridge, float bow_force,
                        float bow_velocity_target, float accel, int samples, bool straight=false);
    void finger_ramp(int which_string, float ratio_from_nut, float Kf, int samples, bool straight=false);
    void physical_constants_ramp(int which_string, String_Physical pc_new, int samples, bool straight=false);

#ifdef RESEARCH
    bool set_string_logfile(int which_string, const char *filename);
    int get_num_skips(int which_string);
#endif

    /** \brief Get a pointer to the audio output of a string (pre-instrument body)
     *
     * @param[in] which_string Instrument string (0,1,2,3); higher
     * string numbers are higher in pitch.
     */
    float *get_string_buffer(int which_string);

    /** \brief Get the internal string output pre-instrument body
     * as int32.
     *
     * \warning You must allocate sufficient memory for the audio
     * and haptic output
     * @param[in] which_string Instrument string (0,1,2,3); higher
     * string numbers are higher in pitch.
     * @param[in] buffer Array for audio output
     * @param[in] num_samples Number of samples in audio output
     * @param[in] forces Array for haptic output
     * @param[in] num_samples2 Number of samples in haptic output
     */
    void get_string_buffer_int(int which_string, int *buffer,
                               int num_samples,
                               int *forces, int num_samples2);

private:
    ArtifastringString *artifastringString[NUM_VIOLIN_STRINGS];
    float string_audio_output[NUM_VIOLIN_STRINGS][NORMAL_BUFFER_SIZE];
    float string_force_output[NUM_VIOLIN_STRINGS][NORMAL_BUFFER_SIZE];

    // strings
    ArtifastringConvolution *string_audio_lowpass_convolution[NUM_VIOLIN_STRINGS];
    ArtifastringConvolution *string_force_lowpass_convolution[NUM_VIOLIN_STRINGS];
    float *string_audio_lowpass_input[NUM_VIOLIN_STRINGS];
    float *string_force_lowpass_input[NUM_VIOLIN_STRINGS];

    // body
    ArtifastringConvolution *body_audio_convolution;
    //ArtifastringConvolution *body_force_convolution;
    float *body_audio_input;
    //float *body_force_lowpass_input;
    float body_force_input[NORMAL_BUFFER_SIZE];

    InstrumentType m_instrument_type;

    // only does up to NORMAL_BUFFER_SIZE !
    void handle_buffer(short output[], short forces[], int num_samples, float float_output[]=NULL);

    float *body_in;
    float *body_out;
    float *f_hole; // output of body convolution
    int f_hole_read_index;

    float *bow_string_forces;
    float *bow_fft_output;
    float *bow_convolution_output;
    int bow_convolution_read_index;
    int bow_string;

    // fftwf_complex
    void *kernel_interim;
    void *body_interim;
    void *forces_interim;
    // fftwf_plan
    void *body_plan_f_p;
    void *body_plan_b_p;
    void *forces_plan_f_p;
    void *forces_plan_b_p;
    int forces_M;
    int body_M;

    float m_bridge_force_amplify;
    float m_bow_force_amplify;

};

#endif

