/*
 * Copyright 2010--2013 Graham Percival
 * This file is part of Artifastring.
 *
 * Artifastring is free software: you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version.
 *
 * Artifastring is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public
 * License along with Artifastring.  If not, see
 * <http://www.gnu.org/licenses/>.
 */


#ifndef ARTIFASTRING_CONSTANTS
#define ARTIFASTRING_CONSTANTS

#include "artifastring_defines.h"

/**
 * \file artifastring_constants.h
 * \brief Physical constants used in artifastring
 */

// time length of each sample, in seconds
//const float dt = 1.0f / ARTIFASTRING_SAMPLE_RATE;


constexpr int FS_MULTIPLICATION_FACTOR[3][4] = {
    {2,2,4,4},
    {1,1,3,3},
    {1,1,1,2},
};
// (Musebots: the largest of them, so that a buffer for any string has a size the compiler knows: the decimation in
// artifastring_instrument.cpp, which was a variable-length array, a Clang extension.)
constexpr int fs_multiplication_most() {
    int most = 1;
    for (const auto &row : FS_MULTIPLICATION_FACTOR) for (int factor : row) if (factor > most) most = factor;
    return most;
}
constexpr int FS_MULTIPLICATION_MOST = fs_multiplication_most();



// pluck constants, estimated from listening
extern float PLUCK_VELOCITY; // (Musebots, live: 0.1f as Artifastring has it, set while it plays: musebots-strings-live.cpp) // in m/s
extern float PLUCK_DISPLACEMENT; // (Musebots, live: 0.005f as Artifastring has it, set while it plays: musebots-strings-live.cpp) // in m
extern float PLUCK_SECONDS; // (Musebots, live: 0.1f as Artifastring has it, set while it plays: musebots-strings-live.cpp) // in seconds

const float K_FINGER = 1e5f;
// (Musebots: the stopping finger's damping a fingertip's measured, the registry's -- generated/musebots-finger.h, written
// by native/strings-model/engine.mjs from registry/players/bowed.json `stoppingFinger.damping` (Wiertlewski & Hayward
// 2012). Artifastring's own, 30.0f, unmeasured, damped a stopped note dead in 0.2 s and made the high notes' sidebands.)
#include "musebots-finger.h"
const float R_FINGER = MUSEBOTS_FINGER_DAMPING;
extern float K_PLUCK; // (Musebots, live: 1e4f as Artifastring has it, set while it plays: musebots-strings-live.cpp)
extern float R_PLUCK; // (Musebots, live: 1e1f as Artifastring has it, set while it plays: musebots-strings-live.cpp)

extern float PLUCK_WIDTH; // (Musebots, live: 0.012f as Artifastring has it, set while it plays: musebots-strings-live.cpp) // m
extern float FINGER_WIDTH; // (Musebots, live: 0.01f as Artifastring has it, set while it plays: musebots-strings-live.cpp) // m

// noise
//const float A_noise = 0.05f; // estimated from listening
extern float A_noise; // (Musebots, live: 0.02f as Artifastring has it, set while it plays: musebots-strings-live.cpp) // estimated from listening
//const float A_noise = 0.0f; // estimated from listening

//#ifdef RESEARCH
//const int MODES = 32;
//#else
//#endif
//const int MODES = 32; // keep this a multiple of four for SIMD!
//const int MODES = 64; // keep this a multiple of four for SIMD!


// string physical constants
#include "constants/strings_violin.h"
#include "constants/strings_viola.h"
#include "constants/strings_cello.h"

#endif

