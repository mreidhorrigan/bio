/*
 * Copyright 2010--2013 Graham Percival
 * This file is part of Artifastring.
 *
 * Artifastring is free software: you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version.
 *
 * Artifastring is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public
 * License along with Artifastring.  If not, see
 * <http://www.gnu.org/licenses/>.
 */

#ifndef ARTIFASTRING_STRING_H
#define ARTIFASTRING_STRING_H

//#define DEBUG

#include "artifastring/artifastring_constants.h"

#include <Eigen/Core>
#include <Eigen/LU>
#include <vector>
//#include <Eigen/QR>

#ifdef RESEARCH
// for log file
#include <stdio.h>
#endif


//#define FIXEDSIZE

// Artifastring Array
#ifdef FIXEDSIZE
const unsigned int MODES=32;
typedef Eigen::Array<float, MODES, 1> AA;
#else
typedef Eigen::Array<float, Eigen::Dynamic, 1> AA;
#endif

enum ExternalActionsType {
    OFF, RELEASE, PLUCK, BOW, BOW_ACCEL
};


struct StringConstants {
    AA X1; // displacement
    AA X2;
    AA X3;
    AA Y1; // velocity
    AA Y2;
    AA Y3;
    AA G; // bridge
    float div_pc_L;
    float sqrt_two_div_L;
};

struct ViolinistCoefficients {
    float x0;
    float x1;
    float x2;
    AA phix0; // position eigenvalues
    AA phix1;
    AA phix2;

    //float D1old, D2old, D3old, D4old; // pluck and release
    float D1, D2, D3, D4; // bow
    float D5, D6, D7; // finger during bowing

    float D8, D9, D10, D11; // pluck release

    // extra "actions"
    float K0;
    float K1;
    float K2;
    float R0;
    float R1;
    float R2;
    float y_pluck; // for pluck displacement
    float y_pluck_target;
    int pluck_samples_remaining;
    bool recache;
};

struct ViolinistActions {
    float bow_pluck_position;  // bow/pluck position
    float finger_position;  // finger position
    float Fb;  // bow force
    float vb;  // bow velocity
    // iffy actions
    float va;  // bow acceleration, per dt (unit of time)
    float vb_target; // target bow velocity, used in acceleration
    float Kf;
    float Rf; // Musebots: the finger's damping as a share of its own (1: R_FINGER)
};

struct StringState {
    AA a;
    AA ad;
    int slipstate;
    ExternalActionsType actions;
};


/// \brief Modal synthesis of a violin string.
class ArtifastringString {
public:
    EIGEN_MAKE_ALIGNED_OPERATOR_NEW
    /**
     * \brief Constructor
     * @param[in] which_instrument The member of the violin family to
     * simulate.  See \ref InstrumentType
     * @param[in] instrument_number The instrument number within the family.
     * See \ref InstrumentType
     * @param[in] string_number The string (higher numbers are
     * higher strings).  This values is also used to initializes
     * the randomness (for added noise in the model).
     * @param[in] fs_multiplication_factor This sets the sampling
     * rate of the string by multiplying the base instrument
     * sampling rate.
     */
    ArtifastringString(InstrumentType which_instrument,
                       int instrument_number, int string_number,
                       int fs_multiplication_factor);
    /// \brief Destructor; nothing special
    ~ArtifastringString();
    /// \brief Stops all movement
    void reset();
    // (Musebots: the string's own noise -- its friction's -- seeded, so that what it draws is the same however its audio
    // is asked for: from the C library's one rand(), shared by the strings, each drew in the order the blocks they were
    // asked for fell, and a part streamed live and rendered at once went their own ways.)
    void set_noise_seed(unsigned long long seed);


    /** \brief Places finger on the string.
     *
     * Finger remains in place until moved.
     * @param[in] ratio_from_nut Measured as a fraction of string
     * length.
     * @param[in] Kf_get This sets how firmly the finger is
     * pressed against the string.  1.0 indicates normal finger
     * strength, while 0.0001 indicates a very light finger
     * suitable for playing harmonic notes.
     */
    void finger(const float ratio_from_nut, const float Kf_get=1.0);
    void finger_damping(const float ratio);

    /** \brief Plucks a string.
     *
     * The pluck is simulated like a bow that pulls until
     * it slips for the first time; as a result, you cannot
     * predict when the pluck has finished "starting".
     * @param[in] ratio_from_bridge Measured as a fraction of
     * string length.
     * @param[in] pull_distance Measured in units of 5mm.  This
     * number was chosen so that a normal pluck on the violin uses
     * a pull distance of 1.0.  0.0 produces no pluck at all.
     */
    // (Musebots: `samples` > 0, the finger's grip taken and its pull begun along the raised cosine over that many of the
    // instrument's samples, never at once: ArtifastringString::pluck.)
    void pluck(const float ratio_from_bridge, const float pull_distance=1.0, const int samples=0);

    /** \brief Sets the bow's action.
     *
     * Bow actions are assumed to continue until changed.
     * @param[in] bow_ratio_from_bridge Measured as a fraction of
     * string length.
     * @param[in] bow_force Measured in Newtons.
     * @param[in] bow_velocity Measured in meters / second.
     */
    void bow(const float bow_ratio_from_bridge,
             const float bow_force, const float bow_velocity);
    void bow_accel(const float bow_ratio_from_bridge,
                   const float bow_force, const float bow_velocity_target,
                   const float bow_accel);


    /** \brief Advances time and writes data to a buffer.
     * @param[out] *buffer Place to write output.
     * @param[in] num_samples Number of samples to advance.
     * @warning You are responsible for allocating sufficient
     * memory for the buffer.
     */
    void fill_buffer(float* buffer, const int num_samples);

    void fill_buffer_forces(float* buffer, float* forces,
                            const int num_samples);


    /** \brief Returns the string physical constants.
     *
     * This method is not recommended for normal use; it is merely
     * a curiosity for people wanting to experiment.
     */
    String_Physical get_physical_constants();

    /** \brief Sets the string physical constants.
     *
     * This method is not recommended for normal use; it is merely
     * a curiosity for people wanting to experiment.
     * @param[in] pc_new String physical constants.
     */
    void set_physical_constants(String_Physical pc_new);

    // (Musebots: a change of the player's controls made over time, never at once -- the owner, 16 October 2026: "making
    // sure nothing changes instantaneously"; public/shared/performers/transitions.js, the least each may take. Each moves
    // its controls from where they stand over `samples` of the instrument's samples, set before every one of them, along
    // a raised cosine -- or, `straight`, along a line: one segment of a curve sampled more finely than a change. A new
    // action of its kind stops it where it stands, and goes on from there.)
    /// \brief Musebots: the bow moved to its place, force and speed; a bow not on the string set down at the new place
    /// and speed, its force from none; a bow moved to no force lifted at its end.
    void bow_ramp(const float bow_ratio_from_bridge, const float bow_force,
                  const float bow_velocity, const int samples, const bool straight=false);
    /// \brief Musebots: as bow_accel -- the bow's speed accelerated toward its target -- its force and place moved as
    /// bow_ramp moves them.
    void bow_accel_ramp(const float bow_ratio_from_bridge, const float bow_force,
                        const float bow_velocity_target, const float accel,
                        const int samples, const bool straight=false);
    /// \brief Musebots: the finger moved -- from one stop to another along the string, its firmness between; set on an
    /// open string, pressed at its place from no firmness; lifted, its firmness let go at its place, then gone.
    void finger_ramp(const float ratio_from_nut, const float Kf_get,
                     const int samples, const bool straight=false);
    /// \brief Musebots: the string's tension, friction and losses moved to `pc_new`'s; a change of its length,
    /// thickness, density, stiffness or number of modes, at once.
    void physical_constants_ramp(String_Physical pc_new, const int samples, const bool straight=false);
    /// \brief Musebots: the player's noise on this string (public/shared/noise.js, as musebots-player.h plays it): its
    /// bow's force and speed times `force` and `speed`, moved there from where they stand over the next `samples` of the
    /// instrument's; its bow's place `place` m from where it is asked; its stopping finger's vibrating length times
    /// `finger`. 1, 1, 0, 1 the exact machine, which plays as before, sample for sample.
    void player_noise(const float force, const float speed, const float place, const float finger, const int samples);

    // (Musebots: the bow's hair a ribbon of finite width -- H. Pitteroff & J. Woodhouse 1998, "Mechanics of the contact
    // area between a violin bow and a string", Acustica 84, Parts I-III -- `width` m across about the bow's place,
    // moved over `samples`. It touches the string at points as finely spaced as the string's modes tell apart (L/N: points
    // closer move as one), each carrying the share of the bow's force its part of the hair carries and its own friction,
    // the string's velocity at each its own, so the hair may stick in one place and slip in another. A point entering
    // at the hair's edge carries nothing at first, so the width moves smoothly; under one spacing, Artifastring's own
    // point bow.)
    void bow_hair(const float width, const int samples);
    int get_hair_points() { return hair_wide ? hair_used : 0; }
    float get_hair_cell() { return (float) hair_cell; }
    int get_hair_unsolved() { return hair_unsolved; }

#ifdef RESEARCH
    bool set_logfile(const char *filename);
    void logfile_data();
    int get_num_skips() {
        return num_skips;
    };
#endif

    void string_release();

protected:
    // physical constants
    String_Physical pc;

    void set_N(unsigned int N_next);
    unsigned int N;

    // calculated from physical constants
    void cache_pc_c();

    // (Musebots: the controls moving -- bow_ramp, finger_ramp, physical_constants_ramp: each its samples done of its
    // length, none while its length is 0.)
    struct Moving {
        int done;
        int length;
        bool straight;
    };
    Moving bow_moving = {0, 0, false};
    Moving finger_moving = {0, 0, false};
    Moving constants_moving = {0, 0, false};
    Moving hair_moving = {0, 0, false};
    // (The pluck's grip on the string, 0 to 1, taking hold over the instrument's samples; its pull, in the string's own
    // samples, along the raised cosine to its target.)
    Moving pluck_gripping = {0, 0, false};
    Moving pluck_pulling = {0, 0, false};
    float pluck_grip = 1.0f;
    // (The bow: its place (m from the bridge), force and speed, from and to; its speed moved, or accelerated.)
    float bow_from[3] = {0, 0, 0};
    // (Musebots: the player's noise as player_noise gives it -- its force's and speed's steps a sample of the string's own
    // toward their targets, and the samples left -- and the bow as the physics reads it, the asked force and speed times
    // their noise.)
    float noise_force = 1.0f, noise_speed = 1.0f, noise_place = 0.0f, noise_finger = 1.0f;
    float noise_force_to = 1.0f, noise_speed_to = 1.0f, noise_force_step = 0.0f, noise_speed_step = 0.0f;
    int noise_left = 0;
    // (Its finger's and its bow's place moved there one of the instrument's samples at a time, as a finger glides: from
    // and to.)
    float noise_place_from = 0.0f, noise_place_to = 0.0f, noise_finger_from = 1.0f, noise_finger_to = 1.0f;
    Moving noise_moving = {0, 0, true};
    inline float bow_Fb() const { return va.Fb * noise_force; }
    inline float bow_vb() const { return va.vb * noise_speed; }
    inline void step_noise() {
        if (noise_left > 0) {
            noise_force += noise_force_step;
            noise_speed += noise_speed_step;
            if (--noise_left == 0) { noise_force = noise_force_to; noise_speed = noise_speed_to; }
        }
    }
    float bow_to[3] = {0, 0, 0};
    bool bow_moving_speed = false;
    // (The finger: its place (m from the bridge) and firmness (Kf), from and to; lifted, its firmness after.)
    float finger_from[2] = {0, 0};
    float finger_to[2] = {0, 0};
    float finger_after = 0;
    bool finger_lifting = false;
    String_Physical constants_from;
    String_Physical constants_to;
    inline float moved(Moving &m);
    void step_ramps();
    void fill_buffer_now(float *buffer, float *forces, const int num_samples_instrument);

    inline void setup_vc_positions();
    inline void cache_pa_c();

    // calculated (almost) all the time
    float tick_pluck();
    float tick_release();
    float tick_free();
    float tick_bow();
    // (Musebots: the hair's cells: their coefficients, each sample's solve, the bowed tick with them.)
    typedef Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic, 0, 64, 64> HairMatrix;
    typedef Eigen::Matrix<double, Eigen::Dynamic, 1, 0, 64, 1> HairVector;
    void cache_hair();
    void solve_hair(const HairVector &u);
    double hair_point(const double P, const double D1, const double share, const double ve0, int &state, const bool kept);
    float tick_bow_wide();
    float hair_width = 0.0f, hair_from = 0.0f, hair_to = 0.0f;
    int hair_used = 1, hair_unsolved = 0;
    // (Musebots: its noise's state, xorshift64* (Vigna 2016, "An experimental exploration of Marsaglia's xorshift
    // generators, scrambled", ACM TOMS 42(4)); uniform on [0, 1), as rand() / RAND_MAX had it.)
    unsigned long long noise_state = 0x9E3779B97F4A7C15ULL;
    inline double noise_uniform() {
        noise_state ^= noise_state >> 12; noise_state ^= noise_state << 25; noise_state ^= noise_state >> 27;
        return (double) ((noise_state * 2685821657736338717ULL) >> 11) * (1.0 / 9007199254740992.0);
    }
    bool hair_wide = false;              // the hair's cells bowing, not Artifastring's point bow
    double hair_cell = 0;                // the narrowest cells the string's modes hold apart (m)
    std::vector<double> hair_x;          // each cell's middle (m from the bridge)
    std::vector<double> hair_share;      // each point's share of the bow's force
    std::vector<int> hair_state;         // each point sticking (0) or slipping (+1 the string faster than the bow, -1 slower)
    std::vector<AA> hair_phi;            // each point's mode shapes
    std::vector<double> hair_eta;        // each cell's hair stretched (m), its give in series with its contact
    bool losses_bowed = false;           // the string's modes losing as bowed (the bow on it): its losses beyond its own added
    HairMatrix hair_W;                   // the points' velocities' response to their forces over a step, the finger's eliminated
    HairVector hair_Bf, hair_e, hair_force;  // each point's response to the finger's force; the finger's force per point's; the points' forces
    float tick_output_force;

    void update_pluck_actions();
    void update_bow_accel();
    inline float compute_bow(const float v0h, const float y1h,
                             const float v1h);

    // returns INFINITY if not valid
    inline float compute_bow_force(const float v0h, const float y1h,
                                   const float v1h, const float dv);
    inline float compute_bow_slip_negative(const float v0h, const float y1h,
                                           const float v1h);
    inline float compute_bow_slip_positive(const float v0h, const float y1h,
                                           const float v1h);

    // actual output of model
    inline float compute_bridge_force();

    // floating-point equality
    inline bool abs_le(const float one, const float two);
    inline bool almostEquals(float one, float two);

    int num_friction_skip_over_stick;
#ifdef RESEARCH
    FILE *logfile;
    float time_seconds;

    void logfile_close();
    float m_v0h;
    float m_dv;
    float m_F0;
    int m_skip;
    int num_skips;
#endif
    int debug_ticks;
    int debug_string_num;


    StringConstants sc;
    ViolinistCoefficients vc;
    StringState ss;
    ViolinistActions va;

    //Eigen::ColPivHouseholderQR<Eigen::Matrix3f> qr;
    //Eigen::HouseholderQR<Eigen::Matrix3f> qr;
    //Eigen::LLT<Eigen::Matrix3f> qr;
    Eigen::Matrix3f inv_A;
    Eigen::Matrix2f inv_A_release;
    //Eigen::ColPivHouseholderQR<Eigen::Matrix2f> qr2;

    int plucks;

    int fs_multiplier;
    int fs;
    float dt;

    //Eigen::Array<float, Eigen::Dynamic, 1> *audio_samples;
    // maximum size of this buffer
    //Eigen::Array<float, NORMAL_BUFFER_SIZE*3, 1> audio_samples;
    //Eigen::Array<float, NORMAL_BUFFER_SIZE*3, 1> force_samples;
    float audio_samples[NORMAL_BUFFER_SIZE*3];
    float force_samples[NORMAL_BUFFER_SIZE*3];

    // to handle the memory alignment once
    AA ah;
    AA adh;
    AA fn;
    AA n;
    AA inside_phi;
};
#endif

