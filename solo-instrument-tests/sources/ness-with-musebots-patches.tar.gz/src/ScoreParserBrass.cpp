/*
 * NeSS Framework Code
 *
 * Copyright (c) The University of Edinburgh, 2014. All rights reserved.
 */

#include "ScoreParserBrass.h"
#include "Logger.h"
#include "MatlabParser.h"
#include "InputValve.h"
#include "InputLips.h"
#include "GlobalSettings.h"

ScoreParserBrass::ScoreParserBrass(string filename) : ScoreParser(filename)
{

}

ScoreParserBrass::~ScoreParserBrass()
{
}

double ScoreParserBrass::getDuration()
{
    durationOnly = true;
    duration = -1.0;
    parseInternal();
    return duration;
}

bool ScoreParserBrass::parse(Instrument *instrument)
{
    durationOnly = false;
    this->instrument = instrument;
    return parseInternal();
}

#define PROCESS_LIP_ARRAY(nm, vec) \
    if (arr.name == nm) { \
        for (j = 0; j < (arr.width * arr.height); j++) { \
	    vec.push_back(arr.data[j]); \
        } \
    } \

#define PROCESS_VALVE_ARRAY(nm, vec) \
    if (arr.name == nm) { \
        int arrsz = arr.width * arr.height; \
	int arrpos = 0; \
        while (arrpos < arrsz) { \
	    for (j = 0; j < Nvalve; j++) { \
	        vec[j].push_back(arr.data[arrpos]); \
		vec[j].push_back(arr.data[arrpos + j + 1]); \
	    } \
            arrpos = arrpos + Nvalve + 1; \
	} \
    } \
	
bool ScoreParserBrass::parseInternal()
{
    int i, j, k;
    logMessage(1, "ScoreParserBrass: attempting to parse %s", filename.c_str());

    MatlabParser matlabParser(filename);
    if (!matlabParser.parse()) {
	return false;
    }

    // now look for the required values
    vector<MatlabScalar> *scalars = matlabParser.getScalars();
    vector<MatlabArray> *arrays = matlabParser.getArrays();

    // scalar T is duration
    for (i = 0; i < scalars->size(); i++) {
	if (scalars->at(i).name == "T") {
	    duration = scalars->at(i).value;
	}
	if (!durationOnly) {
	    if (scalars->at(i).name == "maxout") {
		// maximum output for normalising
		GlobalSettings::getInstance()->setMaxOut(scalars->at(i).value);
	    }
	}
    }
    if (durationOnly) return true;

    // vectors for lips: Sr, mu, sigma, H, w, pressure, lip_frequency, vibamp, vibfreq, tremamp, tremfreq, noiseamp
    vector<double> Sr, mu, sigma, H, w, pressure, lip_frequency, vibamp, vibfreq, tremamp, tremfreq, noiseamp, slide;
    /* the lips' inward mode (Musebots), where the score gives one */
    vector<double> inward_frequency, inward_sigma, inward_Sr, inward_mu;
    /* a flow into the input, for an impedance, and each tone hole's opening (Musebots) */
    vector<double> flow;
    /* the inward mode's contact with what it strikes, a reed's lay (Musebots): OpenWInD's contact pulsation and exponent */
    vector<double> inward_contact_pulsation, inward_contact_exponent;
    /* its slit as measured (Musebots): a double reed's */
    vector<double> inward_slit_exponent, inward_slit_leak, inward_slit_constriction, inward_slit_recovery;

    // get number of valves
    BrassInstrument *brass = dynamic_cast<BrassInstrument*>(instrument->getComponentByName("brass"));
    if (!brass) {
	logMessage(3, "Score parser error, brass instrument not found");
	return false;
    }
    int Nvalve = brass->getNumValves();

    // vectors for valves: valvevibfreq, valvevibamp, valveopening - for each valve
    vector<double> *valvevibfreq, *valvevibamp, *valveopening;

    valvevibfreq = new vector<double>[Nvalve];
    valvevibamp = new vector<double>[Nvalve];
    valveopening = new vector<double>[Nvalve];
    int Nhole = brass->getNumHoles();
    vector<double> *holeopening = new vector<double>[Nhole];

    for (i = 0; i < arrays->size(); i++) {
	MatlabArray arr = arrays->at(i);
	PROCESS_LIP_ARRAY("Sr", Sr);
	PROCESS_LIP_ARRAY("mu", mu);
	PROCESS_LIP_ARRAY("sigma", sigma);
	PROCESS_LIP_ARRAY("H", H);
	PROCESS_LIP_ARRAY("w", w);
	PROCESS_LIP_ARRAY("pressure", pressure);
	PROCESS_LIP_ARRAY("lip_frequency", lip_frequency);
	PROCESS_LIP_ARRAY("vibamp", vibamp);
	PROCESS_LIP_ARRAY("vibfreq", vibfreq);
	PROCESS_LIP_ARRAY("tremamp", tremamp);
	PROCESS_LIP_ARRAY("tremfreq", tremfreq);
	PROCESS_LIP_ARRAY("noiseamp", noiseamp);
	PROCESS_LIP_ARRAY("slide", slide);
	PROCESS_LIP_ARRAY("inward_frequency", inward_frequency);
	PROCESS_LIP_ARRAY("inward_sigma", inward_sigma);
	PROCESS_LIP_ARRAY("inward_Sr", inward_Sr);
	PROCESS_LIP_ARRAY("inward_mu", inward_mu);
	PROCESS_VALVE_ARRAY("valvevibfreq", valvevibfreq);
	PROCESS_VALVE_ARRAY("valvevibamp", valvevibamp);
	PROCESS_VALVE_ARRAY("valveopening", valveopening);
	PROCESS_LIP_ARRAY("flow", flow);
	PROCESS_LIP_ARRAY("inward_contact_pulsation", inward_contact_pulsation);
	PROCESS_LIP_ARRAY("inward_contact_exponent", inward_contact_exponent);
	PROCESS_LIP_ARRAY("inward_slit_exponent", inward_slit_exponent);
	PROCESS_LIP_ARRAY("inward_slit_leak", inward_slit_leak);
	PROCESS_LIP_ARRAY("inward_slit_constriction", inward_slit_constriction);
	PROCESS_LIP_ARRAY("inward_slit_recovery", inward_slit_recovery);
	/* [s, opening of hole 1, ..., of hole N; ...] (Musebots) */
	if (arr.name == "holeopening") {
	    int arrsz = arr.width * arr.height, arrpos = 0;
	    if (Nhole == 0 || arrsz % (Nhole + 1) != 0) {
		logMessage(3, "Score parser error, holeopening is [s, each hole's opening; ...] for the instrument's %d holes", Nhole);
		return false;
	    }
	    while (arrpos < arrsz) {
		for (j = 0; j < Nhole; j++) {
		    holeopening[j].push_back(arr.data[arrpos]);
		    holeopening[j].push_back(arr.data[arrpos + j + 1]);
		}
		arrpos += Nhole + 1;
	    }
	}
    }

    for (j = 0; j < Nhole; j++) {
	if (holeopening[j].size() >= 2) brass->setHoleOpening(j, holeopening[j]);
    }
    delete[] holeopening;
    /* a flow into the input in place of the lips (Musebots): its impedance */
    if (flow.size() >= 2) {
	brass->addInput(new InputFlow(brass, flow));
	if (slide.size() >= 2) brass->setSlideExtension(slide);
	for (i = 0; i < Nvalve; i++) brass->addInput(new InputValve(brass, i, valveopening[i], valvevibfreq[i], valvevibamp[i]));
	delete[] valvevibfreq;
	delete[] valvevibamp;
	delete[] valveopening;
	return true;
    }
    InputLips *lips = new InputLips(brass, Sr, mu, sigma, H, w, pressure, lip_frequency, vibamp, vibfreq,
				    tremamp, tremfreq, noiseamp);
    brass->addInput(lips);
    if (inward_frequency.size() >= 2) {
	if (inward_sigma.size() < 2 || inward_Sr.size() < 2 || inward_mu.size() < 2) {
	    logMessage(3, "Score parser error, the lips' inward mode needs inward_frequency, inward_sigma, inward_Sr and inward_mu");
	    return false;
	}
	lips->setInward(inward_frequency, inward_sigma, inward_Sr, inward_mu);
	if (inward_contact_pulsation.size() >= 2) {
	    if (inward_contact_exponent.size() < 2) {
		logMessage(3, "Score parser error, the inward mode's contact needs inward_contact_pulsation and inward_contact_exponent");
		return false;
	    }
	    lips->setInwardContact(inward_contact_pulsation, inward_contact_exponent);
	}
	if (inward_slit_exponent.size() >= 2) {
	    if (inward_slit_leak.size() < 2 || inward_slit_constriction.size() < 2 || inward_slit_recovery.size() < 2) {
		logMessage(3, "Score parser error, the inward mode's slit needs inward_slit_exponent, inward_slit_leak, inward_slit_constriction and inward_slit_recovery");
		return false;
	    }
	    lips->setInwardSlit(inward_slit_exponent, inward_slit_leak, inward_slit_constriction, inward_slit_recovery);
	}
    }
    /* a slide's extension over time (Musebots): [s, mm; ...] */
    if (slide.size() >= 2) brass->setSlideExtension(slide);

    for (i = 0; i < Nvalve; i++) {
	InputValve *valve = new InputValve(brass, i, valveopening[i], valvevibfreq[i], valvevibamp[i]);
	brass->addInput(valve);
    }

    delete[] valvevibfreq;
    delete[] valvevibamp;
    delete[] valveopening;

    return true;
}
