/*
 * NeSS Framework Code
 *
 * Copyright (c) The University of Edinburgh, 2014-2015. All rights reserved.
 *
 * Component class for a brass instrument, based on Reg's Matlab code
 */

#ifndef _BRASSINSTRUMENT_H_
#define _BRASSINSTRUMENT_H_

#include "Component1D.h"
#include "Profiler.h"

#include <vector>
using namespace std;


class InputValve;

class BrassInstrument : public Component1D {
 public:
    BrassInstrument(string name, double temperature, int Nvalve, vector<double> &vpos,
		    vector<double> &vdl, vector<double> &vbl, vector<double> &bore);
    BrassInstrument(string name, double temperature, int Nvalve, vector<double> &vpos,
		    vector<double> &vdl, vector<double> &vbl, double xm, vector<double> &x0,
		    double L, double rm, vector<double> &r0, double rb, double fp);
    virtual ~BrassInstrument();

    virtual void runTimestep(int n);

    /* brass stores more timesteps of history so has a custom buffer swap */
    virtual void swapBuffers(int n);

    void setValveData(int valve, InputValve *iv);

    /*
     * A slide (Musebots): the main bore's cells between x0 and x1 (m, at its shortest, the bore as given) stretched as
     * one, its length L0 + extension (m) at each timestep -- each cell's length L/n, the pressure and velocity updates'
     * couplings through it (pmainc, vmaine) scaled by its inverse, a cell at its ends half each. Within the first
     * section (before the first valve), never shorter than given.
     */
    void setSlideRegion(double x0, double x1);
    void setSlideExtension(vector<double> &breakpoints);
    double getC1();
    double getRho() { return rho; }
    double getSmain0() { return Smain[0]; }

    int getNumValves() { return Nvalve; }

    /* a woodwind's tone holes (Musebots): side branches off the main bore, each [position mm, radius mm, chimney mm,
     * end correction in its radii (its pad's, 0.6133 the unflanged pipe's)] -- set after the bore is built */
    void setToneHoles(vector<double> &holes);
    /* the grid's Courant number (Musebots): its step c k / courant, NESS's own 1 -- a woodwind's tone holes, branches
     * at its points, need it under 1 (setToneHoles says how far); set before an instrument is built */
    static double courant;
    /* its walls' losses (Musebots), as OpenWInD's loss_factor_alphainv sets them: its Stokes numbers times wallLosses,
     * its viscosity in every loss term over its square -- below 1 lossier, NESS's own 1 */
    static double wallLosses;
    /* its walls' losses' half derivative (Musebots): the square root of s as a sum of diffusive sections, sum mu s / (s +
     * xi) -- wallPoles the xi (rad/s), wallWeights the mu (none negative: passive) -- each stepped by its bilinear
     * transform with a state a cell. None given, NESS's own filter (viscthermcoeff: the bilinear transform's s under a
     * continued fraction of 19 terms), whose low frequencies go as its rate rises: at 192 kHz a 150 Hz component's phase
     * 40.5 degrees for 45, at 864 kHz 14 */
    static vector<double> wallPoles, wallWeights;
    /* the air (Musebots): density, speed of sound, viscosity, the square root of the Prandtl number and the ratio of
     * specific heats another engine takes, in place of NESS's own from the temperature (air[0] 0: its own) */
    static double air[5];
    int getNumHoles() { return Nhole; }
    /* a hole's opening over time, [s, opening; ...]: 1 open, 0 closed, between interpolable */
    void setHoleOpening(int hole, vector<double> &breakpoints);
    /* each hole's edge losing what its jet carries off (Musebots: OpenWInD's edge_losses, Szwarcberg, Colinot, Vergez &
     * Jousserand 2024 and 2026): C of p = rho C u|u| at its open end, u the velocity it radiates at, a hole a value */
    void setHoleLosses(vector<double> &coefficients);
    /* what a woodwind's outputs read (OutputWoodwind): the radiated flow's time derivative summed over every open
     * end (m^3/s^2), the input's pressure (Pa) and the input's flow (m^3/s) */
    double getRadiated() { return radiated; }
    double getInputPressure() { return inputPressure; }
    double getInputFlow() { return inputFlow; }
    double getMainArea(int i) { return Smain[i]; }
    
    double *getVmainHist() {
	return &vmainhist[0][0];
    }

    virtual double *getEnergy();

 protected:
    void init(double temperature, int Nvalve, vector<double> &vpos, vector<double> &vdl,
	      vector<double> &vbl, vector<double> *bore);
    vector<double> *customBore(double xm, vector<double> &x0, double L, double rm,
			       vector<double> &r0, double rb, double fp);

    void viscthermcoeff(int M, int FS, int type, double *N, double *D);
    void RLCconstants(double rho, double c, double a, double *R1, double *R2, double *C, double *L);

    int Nvalve;

    int valvesSet;

    int historySize; /* M in Matlab code */

    int mainSize;
    int defaultSize;
    int bypassSize;

    InputValve **valves;

    /* scalars */
    double vr, pr;
    double ra, rb, rc, rd, re, rf, rg, rh;
    double c1;

    /* constant history-sized arrays */
    double *Adiff, *Bsum, *A, *Asum;

    /* other constant arrays */
    double *Smain, *pmaina, *pmainb, *pmainc;
    double *vmainb, *vmainc, *vmaind, *vmaine;

    /* main state arrays */
    double *pmain, *vmain;
    double *pd, *vd;
    double *pby, *vby;

    /* history arrays */
    double *pmain1, *vmain1;
    double *pd1, *vd1;
    double *pby1, *vby1;

    /* history pointer arrays */
    double **pmainhist, **vmainhist;
    double **pdhist, **vdhist;
    double **pbyhist, **vbyhist;

    /* index sets */
    int *mjin, *mjout, *djin, *djout, *byjin, *byjout;    

    /* temporary values only needed until valve setup is complete */
    int *Nd;
    double *Smainbar, *Sdbarti, *Sbybarti;
    double *Sdti, *Sbyti;
    double *hmain, *hd, *hby;
    double *B;
    double *hdvec, *hbyvec;
    double deltaT, rho, c, eta, nu, gamma;

    Profiler profiler;
    Profiler startupProfiler;

    double *valveQd;

    /* single timestep versions of arrays that were previously precomputed */
    double *tempd1, *tempdbar1, *tempby1, *tempbybar1;
    double *Sd1, *Sby1, *Sdbar1, *Sbybar1;

    /* energy check stuff */
    double *pmainvec, *vmainvec, *pdvec, *vdvec, *pbyvec, *vbyvec;
    double *pdvec1, *vdvec1, *pbyvec1, *vbyvec1;
    double bha, bhb;
    double *energy;

    /* the slide (setSlideRegion): its velocity cells, its length as given (m), the couplings as given */
    int slideFrom, slideTo;
    double slideLength0;
    double *pmainc0, *vmaine0;
    class BreakpointFunction *slideExtension;
    void applySlide();

    /* the tone holes (Musebots: setToneHoles): each a chimney's lossy flow between the bore's pressure where it stands
     * (spread over the two grid points either side of it) and its top's, its top a volume radiating through the bell's
     * network scaled to it, its admittance its opening's share */
    struct ToneHole {
	int j;
	double w0, w1;
	double S, radius, chimney, inner, series, delta, edge;
	double da, db, dc, dd, de;
	double R1, R2, Cr, Lr;
	double vr, pr;
	double opening;
	class BreakpointFunction *openings;
	double *vh, *pe;
	double flowOut;
	double *vy; /* its chimney's flow's diffusive sections' states (wallPoles), where there are any */
    };
    int Nhole;
    ToneHole *holes;
    double radiated, inputPressure, inputFlow, lastFlowOut;
    void holePressures(double kk);
    /* the walls' losses as diffusive sections (wallPoles): each section's pole a (its bilinear transform's), its share
     * of an instant g, their sum wbeta (B[0]), and their states, each pressure's and each velocity's a cell; what the
     * past adds to an update reading B[0] (diffusedPast), and a step of a cell's states (diffuse) */
    bool diffusive;
    int Kdiff;
    double *wa, *wg, wbeta, *pdiff, *vdiff;
    double diffusedPast(const double *y, double x);
    void diffuse(double *y, double now, double before);
    void holeTops(double kk);
    void holeVelocities(double kk);
    void swapHoles();

#ifdef USE_AVX
    void mainPressureUpdateAVX();
    void mainVelocityUpdateAVX();
    void bypassPressureUpdateAVX(int i);
    void bypassVelocityUpdateAVX(int i);

    /* helper arrays for AVX - contain 4 copies of each value and are 32-byte aligned */
    double *A4_orig, *Adiff4_orig, *Bsum4_orig, *Asum4_orig;
    double *A4, *Adiff4, *Bsum4, *Asum4;

    /*
     * Original pointers before we re-align them, so that they can be freed
     */
    double *pmaina_orig, *pmainb_orig, *pmainc_orig;
    double *Smain_orig;
    double *vmainb_orig, *vmainc_orig, *vmaind_orig, *vmaine_orig;

    /* pre-computed scalars for AVX (4 copies) */
    double *etaPiDivRho3, *gammaM1DivNuCC, *b0, *a0DivRhoCCkk, *invRhoCCkk;
    double *rhoDivKk, *oneP5EtaPi, *rhoEtaPi;
#endif
};

/* an output of a woodwind (Musebots): 0 its radiated flow's time derivative over every open end, 1 its input's
 * pressure, 2 its input's flow */
#include "Output.h"
class OutputWoodwind : public Output {
 public:
    OutputWoodwind(BrassInstrument *brass, int kind);
    virtual void runTimestep(int n);
 protected:
    BrassInstrument *brass;
    int kind;
};

#endif
