/*
 * NeSS Framework Code
 *
 * Copyright (c) The University of Edinburgh, 2014-2015. All rights reserved.
 */

#include "InputLips.h"
#include "MathUtil.h"
#include "GlobalSettings.h"
#include "Logger.h"

#include <cmath>
#include <cstdlib>
using namespace std;


InputLips::InputLips(Component *comp, vector<double> &Sr, vector<double> &mu, vector<double> &sigma,
		     vector<double> &H, vector<double> &w, vector<double> &pressure,
		     vector<double> &lip_frequency, vector<double> &vibamp, vector<double> &vibfreq,
		     vector<double> &tremamp, vector<double> &tremfreq, vector<double> &noiseamp)
    : Input(comp, 0.0)
{
    logMessage(1, "Entering InputLips constructor");

    double kk = GlobalSettings::getInstance()->getK();

    brass = dynamic_cast<BrassInstrument*>(comp);
    if (brass == NULL) {
	logMessage(5, "Lips input only works with brass instruments");
	exit(1);
    }

    dp = 0.0;
    y = 0.0;
    y1 = 0.0;
    y2 = 0.0;
    q = 0.0;
    q1 = 0.0;
    q2 = 0.0;
    bf_inFrequency = NULL;
    bf_inSigma = NULL;
    bf_inSr = NULL;
    bf_inMu = NULL;
    z = 0.0;
    lastStiff = 0.0;
    bf_inContact = NULL;
    bf_inExponent = NULL;
    bf_inSlit = NULL;
    bf_inLeak = NULL;
    bf_inConstriction = NULL;
    bf_inRecovery = NULL;

    // lip effective surface area
    bf_Sr = new BreakpointFunction(Sr.data(), Sr.size() / 2, kk);

    // lip effective mass
    bf_mu = new BreakpointFunction(mu.data(), mu.size() / 2, kk);

    // lip damping
    bf_sigma = new BreakpointFunction(sigma.data(), sigma.size() / 2, kk);

    // equilibrium separation
    bf_H = new BreakpointFunction(H.data(), H.size() / 2, kk);

    // width
    bf_wint = new BreakpointFunction(w.data(), w.size() / 2, kk);

    // tremolo
    bf_tremamp = new BreakpointFunction(tremamp.data(), tremamp.size() / 2, kk);
    bf_tremfreq = new BreakpointFunction(tremfreq.data(), tremfreq.size() / 2, kk);

    // noise
    bf_noise = new BreakpointFunction(noiseamp.data(), noiseamp.size() / 2, kk);

    // mouth pressure
    bf_pm = new BreakpointFunction(pressure.data(), pressure.size() / 2, kk);

    // vibrato
    bf_vibamp = new BreakpointFunction(vibamp.data(), vibamp.size() / 2, kk);
    bf_vibfreq = new BreakpointFunction(vibfreq.data(), vibfreq.size() / 2, kk);

    // lip angular frequency with vibrato added
    bf_omega = new BreakpointFunction(lip_frequency.data(), lip_frequency.size() / 2, kk);
    
    c1 = brass->getC1();
    rho = brass->getRho();
    Smain0 = brass->getSmain0();

    setFirstInputTimestep(0);
}

InputLips::~InputLips()
{
    delete bf_Sr;
    delete bf_mu;
    delete bf_sigma;
    delete bf_H;
    delete bf_wint;
    delete bf_tremamp;
    delete bf_tremfreq;
    delete bf_noise;
    delete bf_pm;
    delete bf_vibamp;
    delete bf_vibfreq;
    delete bf_omega;
    delete bf_inFrequency;
    delete bf_inSigma;
    delete bf_inSr;
    delete bf_inMu;
    delete bf_inContact;
    delete bf_inExponent;
    delete bf_inSlit;
    delete bf_inLeak;
    delete bf_inConstriction;
    delete bf_inRecovery;
}

void InputLips::setInward(vector<double> &frequency, vector<double> &sigma, vector<double> &Sr, vector<double> &mu)
{
    double kk = GlobalSettings::getInstance()->getK();
    bf_inFrequency = new BreakpointFunction(frequency.data(), frequency.size() / 2, kk);
    bf_inSigma = new BreakpointFunction(sigma.data(), sigma.size() / 2, kk);
    bf_inSr = new BreakpointFunction(Sr.data(), Sr.size() / 2, kk);
    bf_inMu = new BreakpointFunction(mu.data(), mu.size() / 2, kk);
}

void InputLips::setInwardSlit(vector<double> &exponent, vector<double> &leak, vector<double> &constriction, vector<double> &recovery)
{
    double kk = GlobalSettings::getInstance()->getK();
    bf_inSlit = new BreakpointFunction(exponent.data(), exponent.size() / 2, kk);
    bf_inLeak = new BreakpointFunction(leak.data(), leak.size() / 2, kk);
    bf_inConstriction = new BreakpointFunction(constriction.data(), constriction.size() / 2, kk);
    bf_inRecovery = new BreakpointFunction(recovery.data(), recovery.size() / 2, kk);
}

void InputLips::setInwardContact(vector<double> &pulsation, vector<double> &exponent)
{
    double kk = GlobalSettings::getInstance()->getK();
    bf_inContact = new BreakpointFunction(pulsation.data(), pulsation.size() / 2, kk);
    bf_inExponent = new BreakpointFunction(exponent.data(), exponent.size() / 2, kk);
}

double InputLips::getRand()
{
    return ((double)rand()) / ((double)RAND_MAX);
}

/*
 * Normally when this is called for an Input, s, s1, and s2 correspond to u, u1, and u2.
 * For the lips this is not the case. They are:
 *  - s = pmain
 *  - s1 = pmain1
 *  - s2 = vmain1
 */
void InputLips::runTimestep(int n, double *s, double *s1, double *s2)
{
    double kk = GlobalSettings::getInstance()->getK();

    // compute the breakpoint functions
    double H = bf_H->getValue();
    double lipa = bf_wint->getValue() * sqrt(2.0 / rho);
    double sigmaint = bf_sigma->getValue();

    double vibamp = bf_vibamp->getValue();
    double vibfreq = bf_vibfreq->getValue();
    double vibrato = 1.0 + vibamp * sin(2.0 * M_PI * vibfreq * (((double)n)*kk));
    double omega = 2.0 * M_PI * bf_omega->getValue() * vibrato;

    double Srint = bf_Sr->getValue();
    double muint = bf_mu->getValue();

    double a1, a3, b1, al;
    al = 1.0 / (1.0 / (kk*kk) + sigmaint * 0.5 / kk + 0.5 * omega * omega);
    double bl = al * (2.0 / (kk*kk));
    double cl = al * (sigmaint * 0.5 / kk - 1.0 / (kk*kk) - 0.5 * omega * omega);
    double dl = al * (Srint / muint);

    a1 = 2.0 / kk + sigmaint + kk * omega * omega;
    a3 = Srint / muint;
    b1 = Srint * a3 / a1;
    double b1c1;
    double om2 = -omega * omega * Srint / a1;
    double k2 = 0.5 * kk * kk * a1 / Srint;

    double tremamp = bf_tremamp->getValue();
    double tremfreq = bf_tremfreq->getValue();
    double trem = 1.0 + tremamp * sin(2.0 * M_PI * tremfreq * (((double)n)*kk));
    double noise = 2.0 * bf_noise->getValue() * (getRand() - 0.5);
    double pm = bf_pm->getValue() * (trem * (1.0 + noise));

    bf_H->next();
    bf_wint->next();
    bf_sigma->next();
    bf_omega->next();
    bf_vibamp->next();
    bf_vibfreq->next();
    bf_Sr->next();
    bf_mu->next();
    bf_tremamp->next();
    bf_tremfreq->next();
    bf_noise->next();
    bf_pm->next();

    /* the inward mode (Musebots), where there is one: q'' + sigma_i q' + omega_i^2 q = -(Sr_i / mu_i) dp, stepped as the
     * outward one is; its swept flow -Sr_i q' joins the outward's in the implicit flow balance (b1, b3), and the opening
     * is H + y + q */
    double b1i = 0.0, b3i = 0.0, bli = 0.0, cli = 0.0, dli = 0.0, eli = 0.0, gz = 0.0, gpi = 0.0;
    if (bf_inFrequency != NULL) {
	double omegai = 2.0 * M_PI * bf_inFrequency->getValue();
	double sigmai = bf_inSigma->getValue();
	double Sri = bf_inSr->getValue();
	double mui = bf_inMu->getValue();
	bf_inFrequency->next();
	bf_inSigma->next();
	bf_inSr->next();
	bf_inMu->next();
	/* its contact, where it has one, as OpenWInD's played reed steps it (its TemporalReed1dofScaled, as
	 * openwind_worker.py contact_kept and slit_law leave it): a force per mass K |o-|^alpha, K = omega_c^(alpha+1) /
	 * H^(alpha-1), o the opening last step; the term gp (z + z') / 2 in its equation, z' = z + gp (q - q2) / 2, gp the
	 * slope of its contact energy's root 2 K / (alpha+1) |o-|^(alpha+1) there -- its quadratization's constant none
	 * (OpenWInD's 1, scaled: the same force, its discrete energy split otherwise); z brought to K as K moves (its lips'
	 * force moving H), its energy kept; in contact, its motion critically damped by the contact's stiffness, 2 sqrt(alpha
	 * K |o-|^(alpha-1)), the lip's and lay's losses (none at a touch). None, gp and its products zero, and the step as
	 * before to the bit */
	double gp = 0.0, sigmac = 0.0;
	if (bf_inContact != NULL) {
	    double omegac = bf_inContact->getValue(), alpha = bf_inExponent->getValue();
	    bf_inContact->next();
	    bf_inExponent->next();
	    double stiff = pow(omegac, alpha + 1.0) / pow(H, alpha - 1.0);
	    if (lastStiff > 0.0 && stiff != lastStiff) z = sqrt(z * z * stiff / lastStiff);
	    lastStiff = stiff;
	    double shut = -(y1 + q1 + H);
	    if (shut > 0.0) {
		gp = -stiff * pow(shut, alpha) / sqrt(2.0 * stiff / (alpha + 1.0) * pow(shut, alpha + 1.0));
		sigmac = 2.0 * sqrt(alpha * stiff * pow(shut, alpha - 1.0));
	    }
	}
	sigmai += sigmac;
	gz = gp * z;
	double ali = 1.0 / (1.0 / (kk*kk) + sigmai * 0.5 / kk + 0.5 * omegai * omegai + 0.25 * gp * gp);
	bli = ali * (2.0 / (kk*kk));
	cli = ali * (sigmai * 0.5 / kk - 1.0 / (kk*kk) - 0.5 * omegai * omegai + 0.25 * gp * gp);
	dli = -ali * (Sri / mui);
	eli = -ali * gz;
	gpi = gp;
	double a1i = 2.0 / kk + sigmai + kk * omegai * omegai + 0.5 * kk * gp * gp;
	b1i = Sri * Sri / (mui * a1i);
	b3i = -Sri * (2.0 * (q1 - q2) / (kk*kk) - omegai * omegai * q2 - gz) / a1i;
    }
    /* pressure difference update */
    b3 = ((y1 - y2) / k2) + (om2 * y2);
    b3 += b3i;
    c2 = c1 * (pm - s1[0]) + Smain0*s2[0];
    /* kr: where its slit's staple recovers (setInwardSlit), the share of the drop across the reed that is across its
     * slit; 1 otherwise, each division by it exact */
    double kr = 1.0;
    if (bf_inSlit != NULL) {
	/* its slit as measured (setInwardSlit): OpenWInD's slit_law, its opening this step's */
	double exponent = bf_inSlit->getValue(), leak = bf_inLeak->getValue();
	double constriction = bf_inConstriction->getValue(), recovery = bf_inRecovery->getValue();
	bf_inSlit->next();
	bf_inLeak->next();
	bf_inConstriction->next();
	bf_inRecovery->next();
	double open = (y1 + q1 + H) / H, s = (open > 0.0 ? pow(open, exponent) : 0.0) + leak;
	b2 = 2.0 * H * s * lipa;
	/* its flow forward, the step's pressures setting its sign before it is solved (dp > 0 where c2 > b3): k = 1 -
	 * recovery (S/Sc)^2, past the constriction's area (1 - recovery) (S/Sc)^2, S the slit's area as its flow b2
	 * sqrt(dp) has it, b2 sqrt(rho / 2) (Almeida, Vergez & Causse 2007, JASA 121(1), eqs. 16-18); its flow sqrt(1/k)
	 * of the bare slit's, the reed and its swept flow driven by dp / k */
	if (constriction > 0.0 && recovery != 0.0 && c2 > b3) {
	    double r2 = b2 * b2 * 0.5 * rho / (constriction * constriction);
	    kr = r2 <= 1.0 ? 1.0 - recovery * r2 : r2 * (1.0 - recovery);
	    b2 = b2 / sqrt(kr);
	}
    } else {
	b2 = (y1 + q1 + H + fabs(y1 + q1 + H)) * lipa;
    }
    b1c1 = 1.0 / (-((b1 + b1i) / kr + c1));
    d1 = b2 * b1c1;
    d2 = (b3 - c2) * b1c1;
    sqrtdp = 0.5 * (d1 + sqrt(d1*d1 + 4.0*fabs(d2)));
    dp = sqrtdp * sqrtdp;
    if (d2 < 0.0) dp = -dp;
    
    /* lip update */
    y = bl*y1 + cl*y2 + dl*dp/kr;
    y2 = y1;
    y1 = y;
    if (bf_inFrequency != NULL) {
	q = bli*q1 + cli*q2 + dli*dp/kr + eli;
	z += 0.5 * gpi * (q - q2);
	q2 = q1;
	q1 = q;
    }

    /* mouthpiece input */
    s[0] = 2.0 * (pm - dp) - s1[0];
}

void InputLips::moveToGPU()
{
#ifdef USE_GPU
    // not supported on GPU, which is fine since BrassInstrument isn't
    logMessage(5, "ERROR: attempting to move lips input to GPU!");
#endif
}

InputFlow::InputFlow(Component *comp, vector<double> &flow) : Input(comp, 0.0)
{
    double kk = GlobalSettings::getInstance()->getK();
    brass = dynamic_cast<BrassInstrument*>(comp);
    if (brass == NULL) {
	logMessage(5, "A flow input only works with brass instruments");
	exit(1);
    }
    bf_flow = new BreakpointFunction(flow.data(), flow.size() / 2, kk);
    c1 = brass->getC1();
    Smain0 = brass->getSmain0();
    setFirstInputTimestep(0);
}

InputFlow::~InputFlow()
{
    delete bf_flow;
}

/* s, s1, s2 as the lips have them (pmain, pmain1, vmain1): the input's pressure set so its half cell takes in the flow
 * given less what the bore takes, U = c1 (s - s1) / 2 + S0 v */
void InputFlow::runTimestep(int n, double *s, double *s1, double *s2)
{
    double u = bf_flow->getValue();
    bf_flow->next();
    s[0] = s1[0] + 2.0 * (u - Smain0 * s2[0]) / c1;
}

