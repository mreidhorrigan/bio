/*
 * NeSS Framework Code
 *
 * Copyright (c) The University of Edinburgh, 2014-2015. All rights reserved.
 *
 * Lip input for brass instruments
 */

#ifndef _INPUTLIPS_H_
#define _INPUTLIPS_H_

#include "Input.h"
#include "BrassInstrument.h"
#include "BreakpointFunction.h"

#include <vector>
using namespace std;

class InputLips : public Input {
 public:
    InputLips(Component *comp, vector<double> &Sr, vector<double> &mu, vector<double> &sigma, vector<double> &H,
	      vector<double> &w, vector<double> &pressure, vector<double> &lip_frequency, vector<double> &vibamp,
	      vector<double> &vibfreq, vector<double> &tremamp, vector<double> &tremfreq, vector<double> &noiseamp);
    virtual ~InputLips();

    virtual void runTimestep(int n, double *s, double *s1, double *s2);
    virtual void moveToGPU();

    /* an inward-striking second mode of the lips (Musebots: Newton, Campbell & Gilbert 2008's outward-inward pair),
     * its resonance (Hz), damping (1/s), area (m^2) and mass (kg) over time: [s, value; ...] */
    void setInward(vector<double> &frequency, vector<double> &sigma, vector<double> &Sr, vector<double> &mu);
    /* the inward mode's contact with what it strikes (Musebots: a woodwind's reed beating on its mouthpiece's lay, as
     * OpenWInD's Reed1dof has it): the opening H + y + q closed, a force per mass omega_c^(alpha+1) / H^(alpha-1)
     * |H + y + q|^alpha pushing it open, critically damped, stepped as OpenWInD's played reed steps it (runTimestep);
     * its pulsation omega_c (rad/s) and exponent alpha over time: [s, value; ...] */
    void setInwardContact(vector<double> &pulsation, vector<double> &exponent);
    /* the slit the inward mode opens (Musebots: a double reed's as measured, OpenWInD's reed_law): its area w H s,
     * s = (opening / H)^exponent + leak -- the opening's power, a leak its closed blades never stop -- and its staple's
     * recovery past its constriction (m2), forward: the drop across the slit k of the whole reed's, k = 1 - recovery
     * (S/Sc)^2, past the constriction's area (1 - recovery) (S/Sc)^2 (Almeida, Vergez & Causse 2007), its flow sqrt(1/k)
     * of the bare slit's and the reed driven by dp / k; over time: [s, value; ...] */
    void setInwardSlit(vector<double> &exponent, vector<double> &leak, vector<double> &constriction, vector<double> &recovery);

 protected:
    double getRand();

    BrassInstrument *brass;
    
    double y, y1, y2;
    double q, q1, q2;
    double z, lastStiff;
    double b2, b3, c1, c2, d1, d2;
    double dp, sqrtdp;
    double Smain0;
    double rho;

    BreakpointFunction *bf_Sr, *bf_mu, *bf_sigma, *bf_H, *bf_wint;
    BreakpointFunction *bf_tremamp, *bf_tremfreq, *bf_noise, *bf_pm;
    BreakpointFunction *bf_vibamp, *bf_vibfreq, *bf_omega;
    BreakpointFunction *bf_inFrequency, *bf_inSigma, *bf_inSr, *bf_inMu;
    BreakpointFunction *bf_inContact, *bf_inExponent;
    BreakpointFunction *bf_inSlit, *bf_inLeak, *bf_inConstriction, *bf_inRecovery;
};

/* a flow into the bore's input (Musebots: a woodwind's impedance, its pressure read for a known flow): [s, m^3/s; ...],
 * the input's half cell taking what the bore does not */
class InputFlow : public Input {
 public:
    InputFlow(Component *comp, vector<double> &flow);
    virtual ~InputFlow();
    virtual void runTimestep(int n, double *s, double *s1, double *s2);
    virtual void moveToGPU() {}
 protected:
    BrassInstrument *brass;
    BreakpointFunction *bf_flow;
    double c1, Smain0;
};

#endif
