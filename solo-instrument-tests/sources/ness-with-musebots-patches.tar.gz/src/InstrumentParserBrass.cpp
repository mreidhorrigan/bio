/*
 * NeSS Framework Code
 *
 * Copyright (c) The University of Edinburgh, 2014. All rights reserved.
 */

#include "InstrumentParserBrass.h"
#include "BrassInstrument.h"
#include "MatlabParser.h"
#include "Output.h"
#include "Logger.h"
#include "GlobalSettings.h"

InstrumentParserBrass::InstrumentParserBrass(string filename) : InstrumentParser(filename)
{
}

InstrumentParserBrass::~InstrumentParserBrass()
{
}

#define SCALAR_VALUE(namestring, var) \
    if (scalars->at(i).name == namestring) { \
        var = scalars->at(i).value;	       \
    } \


#define ARRAY_VALUE(namestring, var) \
    if (arr.name == namestring) { \
        for (j = 0; j < (arr.width * arr.height); j++) { \
	    var.push_back(arr.data[j]); \
	} \
    } \


Instrument *InstrumentParserBrass::parse()
{
    int i, j;
    logMessage(1, "InstrumentParserBrass: attempting to parse %s", filename.c_str());

    instrument = new Instrument();

    // parse the Matlab file
    MatlabParser matlabParser(filename);
    if (!matlabParser.parse()) {
	delete instrument;
	instrument = NULL;
	return NULL;
    }

    // now look for the required values
    vector<MatlabScalar> *scalars = matlabParser.getScalars();
    vector<MatlabArray> *arrays = matlabParser.getArrays();

    vector<double> vpos, vdl, vbl, bore, slide;

    /* a woodwind's tone holes and its outputs (Musebots) */

    vector<double> holes, woodwind_outputs, hole_losses;
    /* its walls' losses as diffusive sections (Musebots: BrassInstrument::wallPoles, wallWeights) */
    vector<double> wall_poles, wall_weights;
    double temperature = 20.0;

    double custominstrument = 0.0;
    double xmeg = -1.0, Leg = -1.0, rmeg = -1.0, rbeg = -1.0, fbeg = -1.0;
    double FS = 44100.0;
    /* the grid's Courant number (Musebots: BrassInstrument::courant) */
    double courant = 1.0;
    /* its walls' losses (Musebots: BrassInstrument::wallLosses) */
    double wall_losses = 1.0;
    /* the air another engine takes (Musebots: BrassInstrument::air), all of it or none */
    double air_rho = 0.0, air_c = 0.0, air_eta = 0.0, air_nu = 0.0, air_gamma = 0.0;
    vector<double> x0eg, r0eg;

    for (i = 0; i < scalars->size(); i++) {
	SCALAR_VALUE("custominstrument", custominstrument);
	SCALAR_VALUE("temperature", temperature);
	SCALAR_VALUE("xmeg", xmeg);
	SCALAR_VALUE("Leg", Leg);
	SCALAR_VALUE("rmeg", rmeg);
	SCALAR_VALUE("rbeg", rbeg);
	SCALAR_VALUE("fbeg", fbeg);
	SCALAR_VALUE("FS", FS);
	SCALAR_VALUE("courant", courant);
	SCALAR_VALUE("wall_losses", wall_losses);
	SCALAR_VALUE("air_rho", air_rho);
	SCALAR_VALUE("air_c", air_c);
	SCALAR_VALUE("air_eta", air_eta);
	SCALAR_VALUE("air_nu", air_nu);
	SCALAR_VALUE("air_gamma", air_gamma);
    }

    for (i = 0; i < arrays->size(); i++) {
	MatlabArray arr = arrays->at(i);
	ARRAY_VALUE("vpos", vpos);
	ARRAY_VALUE("vdl", vdl);
	ARRAY_VALUE("vbl", vbl);
	ARRAY_VALUE("bore", bore);

	ARRAY_VALUE("x0eg", x0eg);
	ARRAY_VALUE("r0eg", r0eg);
	ARRAY_VALUE("slide", slide);
	ARRAY_VALUE("holes", holes);
	ARRAY_VALUE("woodwind_outputs", woodwind_outputs);
	ARRAY_VALUE("hole_losses", hole_losses);
	ARRAY_VALUE("wall_poles", wall_poles);
	ARRAY_VALUE("wall_weights", wall_weights);
    }

    GlobalSettings::getInstance()->setSampleRate(FS);
    if (!(courant > 0.0 && courant <= 1.0)) {
	logMessage(3, "Error parsing brass instrument file: courant is in (0, 1]");
	delete instrument;
	return NULL;
    }
    BrassInstrument::courant = courant;
    if (!(wall_losses > 0.0)) {
	logMessage(3, "Error parsing brass instrument file: wall_losses is over 0");
	delete instrument;
	return NULL;
    }
    BrassInstrument::wallLosses = wall_losses;
    if (wall_poles.size() != wall_weights.size()) {
	logMessage(3, "Error parsing brass instrument file: wall_poles and wall_weights, one weight a pole");
	delete instrument;
	return NULL;
    }
    for (i = 0; i < (int)wall_poles.size(); i++) {
	if (!(wall_poles[i] > 0.0) || !(wall_weights[i] >= 0.0)) {
	    logMessage(3, "Error parsing brass instrument file: wall_poles over 0, wall_weights not negative");
	    delete instrument;
	    return NULL;
	}
    }
    BrassInstrument::wallPoles = wall_poles;
    BrassInstrument::wallWeights = wall_weights;
    if ((air_rho > 0.0 || air_c > 0.0 || air_eta > 0.0 || air_nu > 0.0 || air_gamma > 0.0) &&
	!(air_rho > 0.0 && air_c > 0.0 && air_eta > 0.0 && air_nu > 0.0 && air_gamma > 1.0)) {
	logMessage(3, "Error parsing brass instrument file: the air is air_rho, air_c, air_eta, air_nu and air_gamma, all or none");
	delete instrument;
	return NULL;
    }
    BrassInstrument::air[0] = air_rho;
    BrassInstrument::air[1] = air_c;
    BrassInstrument::air[2] = air_eta;
    BrassInstrument::air[3] = air_nu;
    BrassInstrument::air[4] = air_gamma;

    if ((vpos.size() != vdl.size()) || (vpos.size() != vbl.size())) {
	logMessage(3, "Error parsing brass instrument file: vpos, vdl and vbl must all be same length");
	delete instrument;
	return NULL;
    }

    BrassInstrument *brass;
    if (custominstrument > 0.0) {
	if ((xmeg < 0.0) || (Leg < 0.0) || (rmeg < 0.0) || (rbeg < 0.0) || (fbeg < 0.0) ||
	    (x0eg.size() == 0) || (r0eg.size() == 0)) {
	    logMessage(3, "Error parsing brass instrument file: custom bore parameter missing");
	    delete instrument;
	    return NULL;
	}
	
	brass = new BrassInstrument("brass", temperature, vpos.size(), vpos, vdl, vbl, xmeg,
				    x0eg, Leg, rmeg, r0eg, rbeg, fbeg);
    }
    else {
	if (bore.size() == 0) {
	    logMessage(3, "Error parsing brass instrument file: no bore defined");
	    delete instrument;
	    return NULL;
	}

	brass = new BrassInstrument("brass", temperature, vpos.size(), vpos, vdl, vbl, bore);
    }
    /* a slide (Musebots): the bore's cells between its two places, mm */
    if (slide.size() == 2) {
	brass->setSlideRegion(slide[0] / 1000.0, slide[1] / 1000.0);
    }
    else if (slide.size() != 0) {
	logMessage(3, "Error parsing brass instrument file: slide is [from, to] in mm");
	delete instrument;
	return NULL;
    }
    /* a woodwind's tone holes, [position mm, radius mm, chimney mm, end correction; ...] (Musebots) */
    if (holes.size() > 0) brass->setToneHoles(holes);
    /* each hole's edge's loss coefficient (Musebots: BrassInstrument::setHoleLosses) */
    if (hole_losses.size() > 0) brass->setHoleLosses(hole_losses);
    instrument->addComponent(brass);
    /* a woodwind's outputs, each of OutputWoodwind's kinds (0 its radiated flow's derivative, 1 its input's pressure, 2
     * its input's flow), in place of the bell's pressure (Musebots) */
    if (woodwind_outputs.size() > 0) {
	for (i = 0; i < (int)woodwind_outputs.size(); i++) {
	    int kind = (int)woodwind_outputs[i];
	    if (kind < 0 || kind > 2) {
		logMessage(3, "Error parsing brass instrument file: woodwind_outputs are 0, 1 or 2");
		delete instrument;
		return NULL;
	    }
	    instrument->addOutput(new OutputWoodwind(brass, kind));
	}
    }
    else {
	instrument->addOutput(new Output(brass, 0.0, 1.0, 0.0, 0.0));
    }

    return instrument;
}
